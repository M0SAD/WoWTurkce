-- NPC konuşmaları: selamlama metni ve konuşma seçenekleri ("Train me." gibi).
-- Selamlama metinleri parmak iziyle eşleşir: G.Konusma[iz] = "Türkçe metin"
local G = WoWTurkce

local function npcAdi()
	local ad = UnitName("npc")
	local guid = UnitGUID and UnitGUID("npc")
	local id = guid and select(6, strsplit("-", guid))
	return ad, tonumber(id)
end

local function selamlamaCevir(metin)
	if not metin or metin == "" then return nil end
	local tr, iz = G.izBul(G.Konusma, metin)
	tr = tr or G.Konusma[G.iz(metin)] or (G.Soz and G.izBul(G.Soz, metin))
	if tr then return G.doldur(tr) end
	local ad, id = npcAdi()
	G.kaydetDiger("konusma", iz, { npc = ad, id = id, metin = metin })
end

local secenekCevir
secenekCevir = function(metin)
	if not metin or metin == "" then return nil end
	-- Renk kodunu ayır ("|cff000000Rude Awakening|r")
	local renk, ic = metin:match("^(|c%x%x%x%x%x%x%x%x)(.-)|r$")
	if renk then
		local tr = secenekCevir(ic)
		return tr and (renk .. tr .. "|r")
	end
	local tr = G.cevir(G.Secenek, metin) or G.GorevAdi[metin]
	if tr then return tr end
	-- Görev adları "Rude Awakening (5)" gibi seviyeyle gelebilir
	local ad, ek = metin:match("^(.-)(%s*%(%d+%))$")
	if ad and G.GorevAdi[ad] then return G.GorevAdi[ad] .. ek end
	G.kaydetDiger("secenek", metin)
end

local orijinalFont = {}
local function fontKoy(fs)
	if not fs or not fs.GetFont then return end
	if not orijinalFont[fs] then orijinalFont[fs] = { fs:GetFont() } end
	local o = orijinalFont[fs]
	if G.ayar("font") then if G.fontSerbest(fs) then fs:SetFont(G.FONT_METIN, (o[2] or 13) + 1, o[3] or "") end end
end

local function metniKoy(fs, metin)
	if fs and fs.SetText and metin then
		fontKoy(fs)
		fs:SetText(metin)
	end
end

-- Eski stil (parşömen) selamlama/gossip penceresi: Türkçe metin İngilizceden uzun olunca altındaki görev/seçenek
-- satırları yazının üstüne biniyordu. Yazıdan sonra gelen öğeleri üstten alta sırayla kontrol edip gerekirse aşağı iter.
local function altiniAc(fs, kok)
	if not (fs and kok and fs.GetBottom) then return end
	local ogeler = {}
	local function ekle(o)
		if o ~= fs and o.IsShown and o:IsShown() and o.GetTop and o.GetBottom then
			local ok, t = pcall(o.GetTop, o)
			if ok and t and o.GetNumPoints and o:GetNumPoints() > 0 then ogeler[#ogeler + 1] = { o, t } end
		end
	end
	for _, r in ipairs({ kok:GetRegions() }) do ekle(r) end
	for _, c in ipairs({ kok:GetChildren() }) do ekle(c) end
	table.sort(ogeler, function(x, y) return x[2] > y[2] end)
	local alt = fs:GetBottom()
	if not alt then return end
	local ustYazi = fs:GetTop() or alt
	for _, e in ipairs(ogeler) do
		local o = e[1]
		-- yalnızca yazının altında başlayan öğeler (üstteki başlık/ikonlara dokunma)
		if e[2] <= ustYazi + 2 then
			local top = o:GetTop()
			if top and top > alt - 6 then
				local fark = top - (alt - 8)
				local nokta, bag, bagNokta, x, y = o:GetPoint(1)
				if nokta then
					o:SetPoint(nokta, bag, bagNokta, x or 0, (y or 0) - fark)
				end
			end
			alt = o:GetBottom() or alt
		end
	end
end

local function dugmeCevir(b)
	if not b or not b.GetText or not b.SetText or b._gtrIsleniyor then return end
	local metin = b:GetText()
	local tr = secenekCevir(metin)
	if tr and tr ~= metin then
		b._gtrIsleniyor = true
		b:SetText(tr)
		if b.Resize then pcall(b.Resize, b) elseif b.SetHeight and b.GetFontString and b:GetFontString() then
			b:SetHeight(math.max(16, b:GetFontString():GetHeight() + 2))
		end
		b._gtrIsleniyor = nil
	end
end

local function gossipUygula()
	if not G.modul("konusma") then return end
	local metin = (C_GossipInfo and C_GossipInfo.GetText and C_GossipInfo.GetText()) or (GetGossipText and GetGossipText())
	local tr = selamlamaCevir(metin)
	-- Eski stil gossip penceresi
	if GossipGreetingText then
		if tr then metniKoy(GossipGreetingText, tr) end
		C_Timer.After(0.05, function() pcall(altiniAc, GossipGreetingText, GossipGreetingText:GetParent()) end)
		C_Timer.After(0.4, function() pcall(altiniAc, GossipGreetingText, GossipGreetingText:GetParent()) end)
		for i = 1, 32 do
			local b = _G["GossipTitleButton" .. i]
			if b and b:IsShown() then dugmeCevir(b) end
		end
	end
	-- Yeni stil (ScrollBox): önce veriyi çevirip yerleşimi yeniden hesaplat
	if GossipFrame and G._gossipVeri then pcall(G._gossipVeri, GossipFrame) end
	local panel = GossipFrame and GossipFrame.GreetingPanel
	local kutu = panel and panel.ScrollBox
	if kutu and kutu.ForEachFrame then
		kutu:ForEachFrame(function(fr)
			if fr.GreetingText then
				if tr then metniKoy(fr.GreetingText, tr) else fontKoy(fr.GreetingText) end
				if fr.SetSize then fr:SetSize(270, fr.GreetingText:GetHeight()) end
			else
				dugmeCevir(fr)
			end
		end)
	end
end

local function questGreetingUygula()
	if not G.modul("konusma") then return end
	local metin = GetGreetingText and GetGreetingText()
	local tr = selamlamaCevir(metin)
	if tr then
		local fs = rawget(_G, "GreetingText")
		if not (fs and fs.GetText and fs:GetText() == metin) then
			fs = nil
			-- Bazı istemcilerde yazının global adı farklı: selamlama panelindeki yazılar arasında ara
			local kok = rawget(_G, "QuestGreetingScrollChildFrame") or rawget(_G, "QuestFrameGreetingPanel")
			local function ara(cer)
				if fs or not cer then return end
				for _, r in ipairs({ cer:GetRegions() }) do
					if r.GetText and r:GetText() == metin then fs = r; return end
				end
				for _, c in ipairs({ cer:GetChildren() }) do ara(c) end
			end
			pcall(ara, kok)
		end
		if fs then
			metniKoy(fs, tr)
			C_Timer.After(0.05, function() pcall(altiniAc, fs, fs:GetParent()) end)
			C_Timer.After(0.4, function() pcall(altiniAc, fs, fs:GetParent()) end)
		end
	end
	for i = 1, 32 do
		local b = _G["QuestTitleButton" .. i]
		if b and b:IsShown() then dugmeCevir(b) end
	end
	if CurrentQuestsText and CurrentQuestsText:GetText() == "Current Quests" then CurrentQuestsText:SetText("Mevcut Görevler") end
	if AvailableQuestsText and AvailableQuestsText:GetText() == "Available Quests" then AvailableQuestsText:SetText("Alınabilir Görevler") end
end

G.basla(function()
	local f = CreateFrame("Frame")
	f:RegisterEvent("GOSSIP_SHOW")
	f:RegisterEvent("QUEST_GREETING")
	f:SetScript("OnEvent", function(_, e)
		if e == "GOSSIP_SHOW" then C_Timer.After(0, gossipUygula)
		else C_Timer.After(0, questGreetingUygula) end
	end)
	-- Yeni stil gossip penceresinde öğelerin yükseklikleri İngilizce metne göre hesaplanıyor; Türkçe metin
	-- daha uzun olunca yazılar seçeneklerin üstüne biniyordu. Bu yüzden çeviriyi veri listesine koyup
	-- listeyi yeniden kuruyoruz: yükseklikler Türkçe metne (ve yazı tipine) göre yeniden hesaplanır.
	local function veriyiCevir(self)
		if not G.modul("konusma") then return end
		local kutu = self.GreetingPanel and self.GreetingPanel.ScrollBox
		local dp = kutu and kutu.GetDataProvider and kutu:GetDataProvider()
		if not dp or not dp.Enumerate or dp._gtrYapildi then return end
		local degisti = false
		for _, e in dp:Enumerate() do
			if e.greetingTextFrame and e.text and e.text ~= "" then
				if not G.turkceMi(e.text) then
					local tr = selamlamaCevir(e.text) or G.cevir(G.Arayuz, e.text)
					if tr then e.text = tr end
				end
				-- Ölçüm yapılan gizli çerçeve de görünenle aynı yazı tipini kullansın
				local gf = e.greetingTextFrame
				fontKoy(gf.GreetingText)
				-- Metin/yazı tipi değişince ölçü eskimesin: son haliyle koyup yüksekliği yeniden ölç
				pcall(function()
					local gt = gf.GreetingText
					gt:SetText(e.text)
					local h = gt:GetHeight()
					if h and h > 0 then gf:SetHeight(h) end
				end)
				degisti = true
			elseif e.info then
				local alan = e.info.name and "name" or (e.info.title and "title")
				local m = alan and e.info[alan]
				if m and not G.turkceMi(m) then
					local tr = secenekCevir(m)
					if tr and tr ~= m then e.info[alan] = tr; degisti = true end
				end
			end
		end
		-- Selamlama satırının yüksekliğini kendimiz ölçeriz (Türkçe metin + görünen yazı tipiyle)
		pcall(function()
			local view = kutu.GetView and kutu:GetView()
			if not view or view._gtrOlcer then return end
			view._gtrOlcer = true
			local eski = view.elementExtentCalculator
			local olc = UIParent:CreateFontString(nil, "ARTWORK")
			olc:SetAlpha(0)
			olc:SetJustifyH("LEFT")
			olc:SetWordWrap(true)
			view:SetElementExtentCalculator(function(i, ed)
				if ed and ed.greetingTextFrame and ed.text then
					local gt = ed.greetingTextFrame.GreetingText
					local o = orijinalFont[gt] or { gt:GetFont() }
					local w = gt:GetWidth()
					if not w or w < 50 or w > 270 then w = 270 end
					w = w - 14
					if G.ayar("font") and G.fontSerbest(gt) then olc:SetFont(G.FONT_METIN, (o[2] or 13) + 1, o[3] or "")
					else olc:SetFont(o[1] or G.FONT_METIN, o[2] or 13, o[3] or "") end
					olc:SetSpacing(gt:GetSpacing() or 0)
					olc:SetWidth(w)
					olc:SetText(ed.text)
					return math.ceil(olc:GetStringHeight() * 1.04) + 16
				end
				if eski then return eski(i, ed) end
				return view.elementExtent or 20
			end)
		end)
		dp._gtrYapildi = true
		if degisti then kutu:SetDataProvider(dp, ScrollBoxConstants and ScrollBoxConstants.RetainScrollPosition) end
	end
	G._gossipVeri = veriyiCevir
	if GossipFrame and GossipFrame.Update then
		hooksecurefunc(GossipFrame, "Update", function(self)
			pcall(veriyiCevir, self)
			C_Timer.After(0, gossipUygula)
		end)
	end
	-- Yazılar görüntülendiğinde ölçülen yazı tipiyle aynı olsun (yeni stil)
	local panel = GossipFrame and GossipFrame.GreetingPanel
	if panel and panel.ScrollBox and ScrollUtil and ScrollUtil.AddInitializedFrameCallback then
		pcall(ScrollUtil.AddInitializedFrameCallback, panel.ScrollBox, function(_, fr)
			if fr and fr.GreetingText and G.modul("konusma") then
				fontKoy(fr.GreetingText)
				if fr.SetSize then fr:SetSize(270, fr.GreetingText:GetHeight()) end
			end
		end, GossipFrame, true)
	end
end)
G._gossip = gossipUygula
