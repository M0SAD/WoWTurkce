-- Pencere taşıma: Shift tuşuna basılı tutup sürükleyerek görev, konuşma, satıcı vb. pencereleri istediğin yere taşı.
-- Konum kaydedilir; "/wowturkce pencere sifirla" ile eski yerlerine döner.
local G = WoWTurkce

local PENCERELER = {
	"QuestFrame", "GossipFrame", "QuestLogFrame", "MerchantFrame", "ClassTrainerFrame",
	"TradeSkillFrame", "CraftFrame", "SpellBookFrame", "CharacterFrame", "FriendsFrame", "TaxiFrame", "MailFrame",
}
local kurulu = {}

local function uygula(f, ad)
	if InCombatLockdown and InCombatLockdown() then return end
	local t = G.ayar("pencereNokta")
	local n = type(t) == "table" and t[ad]
	if not n then return end
	f:ClearAllPoints()
	f:SetPoint(n[1], UIParent, n[2], n[3], n[4])
end

local function kur(ad)
	local f = _G[ad]
	if kurulu[ad] or not f or not f.HookScript or not f.SetMovable then return end
	kurulu[ad] = true
	f:SetMovable(true)
	f:SetClampedToScreen(true)
	f:HookScript("OnMouseDown", function(self, btn)
		if btn == "LeftButton" and IsShiftKeyDown() and not (InCombatLockdown and InCombatLockdown()) then
			self._gtrTasi = true
			self:StartMoving()
		end
	end)
	f:HookScript("OnMouseUp", function(self)
		if not self._gtrTasi then return end
		self._gtrTasi = nil
		self:StopMovingOrSizing()
		local p, _, rp, x, y = self:GetPoint()
		if p then
			local t = G.ayar("pencereNokta")
			t = type(t) == "table" and t or {}
			t[ad] = { p, rp, math.floor(x + 0.5), math.floor(y + 0.5) }
			G.ayarla("pencereNokta", t)
		end
	end)
	f:HookScript("OnShow", function(self)
		uygula(self, ad)
		if C_Timer and C_Timer.After then C_Timer.After(0, function() if self:IsShown() then uygula(self, ad) end end) end
	end)
end

local function hepsi() for _, ad in ipairs(PENCERELER) do kur(ad) end end

function G.pencereSifirla()
	G.ayarla("pencereNokta", nil)
	if InCombatLockdown and InCombatLockdown() then
		G.yaz("Savaştasın: konumlar silindi, pencereler savaştan sonra açıldığında varsayılan yerine döner.")
		return
	end
	for _, ad in ipairs(PENCERELER) do
		local f = _G[ad]
		if f and kurulu[ad] then
			if f:IsShown() and HideUIPanel and f.GetAttribute and f:GetAttribute("UIPanelLayout-defined") then
				HideUIPanel(f); ShowUIPanel(f)
			else
				f:SetUserPlaced(false)
			end
		end
	end
	G.yaz("Pencere konumları varsayılana döndürüldü. Açık olanlar kapanıp açılınca yerine oturur.")
end

G.basla(function()
	hepsi()
	local e = CreateFrame("Frame")
	e:RegisterEvent("ADDON_LOADED")
	e:RegisterEvent("PLAYER_ENTERING_WORLD")
	e:SetScript("OnEvent", hepsi)
end)
