-- WoWTürkçe - yaratık adları ve unvanları
-- Gösterilen yerler: fare ipucu, hedef/hedefin hedefi çerçevesi, isim plakaları, NPC konuşmaları.
local _, WT = ...

local Ad, Yaratik, Unvan = WT.Ad, WT.Yaratik, WT.Unvan
local UnitName, UnitIsPlayer, UnitExists = UnitName, UnitIsPlayer, UnitExists

-- Önce NPC ID'ye özel çeviri, yoksa İngilizce ada göre çeviri.
function WT.YaratikAdi(enAd, id)
  if not enAd then return nil end
  local tr = (id and Yaratik[id]) or Ad[enAd]
  if not tr and id then WT.Kaydet("yaratik", id, enAd) end
  return tr
end

local function birimCevir(unit)
  if not unit or not WT.Acik("yaratik") or not UnitExists(unit) or UnitIsPlayer(unit) then return end
  local id = WT.UnitNpcID(unit)
  if not id then return end
  return WT.YaratikAdi(UnitName(unit), id), UnitName(unit)
end
WT.BirimCevir = birimCevir

------------------------------------------------------------------ ipucu
local function ipucuDuzenle(tt)
  if tt ~= GameTooltip then return end
  local _, unit = tt:GetUnit()
  local tr, en = birimCevir(unit)
  local satir1 = _G[tt:GetName() .. "TextLeft1"]
  if tr and satir1 then
    local yazi = satir1:GetText()
    if yazi then
      local b, e = yazi:find(en, 1, true)
      satir1:SetText(b and (yazi:sub(1, b - 1) .. tr .. yazi:sub(e + 1)) or tr)
    end
  end
  -- Oyuncunun PvP rütbe unvanı ("Sergeant Ahmet" -> "Çavuş Ahmet")
  if unit and UnitIsPlayer(unit) and WT.Acik("yaratik") and satir1 and UnitPVPName then
    local R = _G.WoWTurkce and _G.WoWTurkce.PVP_RUTBE
    local pvp, ad = UnitPVPName(unit), UnitName(unit)
    local b = R and pvp and ad and ad ~= "" and pvp:find(ad, 1, true)
    if b and b > 1 then
      local on = pvp:sub(1, b - 1):gsub("%s+$", "")
      local trU, yazi = R[on], satir1:GetText()
      if trU and yazi then
        local s, e = yazi:find(on, 1, true)
        if s then satir1:SetText(yazi:sub(1, s - 1) .. trU .. yazi:sub(e + 1)) end
      end
    end
  end
  -- Unvan (ör. "Innkeeper") 2. satırda durur.
  if unit and not UnitIsPlayer(unit) and WT.Acik("yaratik") then
    local satir2 = _G[tt:GetName() .. "TextLeft2"]
    local yazi = satir2 and satir2:GetText()
    if yazi then
      local u = Unvan[yazi]
      if u then satir2:SetText(u)
      elseif not yazi:find("%d") then WT.Kaydet("unvan", yazi, true) end
    end
  end
  tt:Show()
end

if TooltipDataProcessor and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Unit then
  TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Unit, ipucuDuzenle)
else
  GameTooltip:HookScript("OnTooltipSetUnit", ipucuDuzenle)
end

------------------------------------------------------------------ birim çerçeveleri
local function cerceveDuzenle(frame)
  if not frame or not frame.unit then return end
  local yazi = frame.name or frame.Name
  if not yazi or not yazi.SetText then return end
  local tr = birimCevir(frame.unit)
  if tr then yazi:SetText(tr) end
end

if UnitFrame_Update then hooksecurefunc("UnitFrame_Update", cerceveDuzenle) end
if TargetFrame_Update then hooksecurefunc("TargetFrame_Update", cerceveDuzenle) end

------------------------------------------------------------------ isim plakaları
local function plakaDuzenle(frame)
  if not frame or not frame.unit or not frame.name then return end
  if frame.IsForbidden and frame:IsForbidden() then return end
  if frame.unit:sub(1, 9) ~= "nameplate" then return end
  local tr = birimCevir(frame.unit)
  if tr then frame.name:SetText(tr) end
end

if CompactUnitFrame_UpdateName then
  hooksecurefunc("CompactUnitFrame_UpdateName", plakaDuzenle)
end

local olay = CreateFrame("Frame")
olay:RegisterEvent("NAME_PLATE_UNIT_ADDED")
olay:SetScript("OnEvent", function(_, _, unit)
  local plaka = C_NamePlate and C_NamePlate.GetNamePlateForUnit(unit)
  if plaka and plaka.UnitFrame then plakaDuzenle(plaka.UnitFrame) end
end)

------------------------------------------------------------------ NPC konuşmaları (gönderen adı)
local function konusmaFiltre(_, _, msg, gonderen, ...)
  if not WT.Acik("yaratik") then return false end
  local tr = gonderen and Ad[gonderen]
  if tr then return false, msg, tr, ... end
  return false
end

for _, e in ipairs({ "CHAT_MSG_MONSTER_SAY", "CHAT_MSG_MONSTER_YELL", "CHAT_MSG_MONSTER_EMOTE",
                     "CHAT_MSG_MONSTER_WHISPER", "CHAT_MSG_RAID_BOSS_EMOTE", "CHAT_MSG_RAID_BOSS_WHISPER" }) do
  ChatFrame_AddMessageEventFilter(e, konusmaFiltre)
end
