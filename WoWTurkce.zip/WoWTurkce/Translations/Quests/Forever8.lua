if not WoWTurkce.FOREVER then return end -- yalnızca Classic Forever
-- Classic Forever'a özel görevler 8
-- b=başlık, a=açıklama, h=hedef, i=ilerleme, t=tamamlama
-- k = çevrilen İngilizce metnin parmak izi (metin değişirse çeviri gösterilmez, yeniden kaydedilir)
local V = WoWTurkce.Veri

V[79624] = { b="Herkes Yemek Yapabilir", h="Okunaksız Tarif'i okuyabilecek bir ogre bul.", k={b=1148243565, h=856873056} }
V[79974] = { b="Islak İş", h="Topraktan baş gösteren bir haberci çantasının tozunu silkelediğinde, erzakların arasına sıkışmış bir parşömen buluyorsun.", k={b=618266640, h=1205424388} }
V[79980] = { b="Telaş", h="Seni neyin beklediğini bul.", k={b=1930444494, h=2357796032} }
V[86574] = { b="Stonetalon Erzak Seferi", h="Pridewing Wyvern'lerden 6 Stonetalon Erzakı topla ve bunları Hancı Faralia'ya teslim et.", k={b=156758606, h=645890744} }
V[86576] = { b="Bloodfury Süs Eşyaları", h="15 Parıldayan Güneştaşı'nı Mor'rogal'a getir.", k={b=4111555919, h=1965003150} }
V[92519] = { b="Koğuş İkmali", h="Go'shek Farm'daki Jorell'in laboratuvarından bir kasa Paketlenmiş Tonik al ve Hammerfall'daki Doktor Gregory Victor'a dön.", k={b=1573236780, h=349452327} }
V[92707] = { b="İnindeki Dev", h="Goliath'ın Bileklikleri'ni Hammerfall'daki Drum Fel'e getir.", k={b=470301576, h=659395252} }
V[92743] = { b="Bir Fatihin Tacı", h="Magram ile itibarını koru ve Badlands'den bir Fatih Tacı'nı Magram Village'daki Warug'a getir.", k={b=538542336, h=885611735} }
V[92754] = { b="Gölge Korumasına Yeni Bir İhtiyaç", h="Magram ile itibarını koru ve 3 Büyük Gölge Koruma İksiri'ni Desolace'taki Magram Village'da bulunan Mirda'ya götür.", k={b=2328361824, h=2233184181} }
V[92755] = { b="Gizemli Mistisizm", h="Gelkis ile itibarını koru ve 3 Büyük Mistik Öz'ü Desolace'taki Gelkis Village'da bulunan Halea'ya götür.", k={b=3508481707, h=2836021232} }
V[92811] = { b="Ekonomik Savaş", k={b=3288480922} }
V[92812] = { b="Ekonomik Savaş", k={b=3288480922} }
V[92814] = { b="Bana Bir Terzi Lazım", h="Gelkis ile itibarını koru ve bir Beyaz Haydut Maskesi'ni Desolace'taki Gelkis Village'da bulunan Molkar'a götür.", k={b=3519223670, h=2057066700} }
V[92817] = { b="Deri İşçiliği Tekniği", h="Gelkis ile itibarını koru ve bir Barbar Koşum Takımı'nı Desolace'taki Gelkis Village'da bulunan Talra'ya götür.", k={b=3299752688, h=572265957} }
V[92818] = { b="Büyük, Yok, DEVASA Demir Baltalar", h="Magram ile itibarını koru ve 2 Devasa Demir Balta'yı Desolace'taki Magram Village'da bulunan Grolkar'a götür.", k={b=3792620213, h=3273060375} }
V[92867] = { b="Korunacak Topraklar", h="Stromgarde Keep'teki Boulderfist, Syndicate ve Witherbark davetsiz misafirlerini alt et ve Bahçe Bekçisi Lomar'a dön.", k={b=402605276, h=3600467519} }
V[92872] = { b="Vazifeli Adımlar", h="Mezar Tozu Kesesi'ni The Great Sea'ye at ve Stromgarde Keep mahzenindeki Bakıcı Alaric'e dön.", k={b=1540244913, h=3235443010} }
V[93044] = { b="Arındırıcı Bir Feryat", h="Gelkis ile itibarını koru ve Theradras'ın Gözyaşları'nı Gelkis Village'daki Bilge Uthek'e geri getir.", k={b=2183838344, h=1862405931} }
V[93128] = { b="Khan Jehn", h="Gelkis ile itibarını koru ve Magram Village'da Khan Jhen'i öldür. Başardığında Desolace'taki Gelkis Village'da bulunan Bilge Uthek'e rapor ver.", k={b=1797700236, h=1089757869} }
V[93176] = { b="Küçük Dostlarım", h="Böcekbilim Başlangıç Seti'ndeki eşyaları kullanarak bir Arbor Tarantula, bir Hay Weevil Örneği ve bir Flesh Picker bul ve yakala.", k={b=173909124, h=866577261} }
V[93196] = { b="Khan Jehn", h="Magram ile itibarını koru ve Khan Jehn'i diriltmek için bir nekromansi ayini gerçekleştir. Ayin alanı, Magram Village'ın ortasındaki gölün kıyısında bir çadırda bulunuyor.", k={b=1797700236, h=165205754} }
V[93224] = { b="Oyma Centaur Totemleri", h="Desolace'ın dört bir yanındaki herhangi bir klandan centaur'ları öldürerek 5 Oyma Centaur Totemi edin, ardından bunları Nijel's Point'teki Yüzbaşı Pentigast'a götür.", k={b=66450664, h=3341916114} }
V[93225] = { b="Oyma Centaur Totemleri", h="Desolace'ın dört bir yanındaki herhangi bir klandan centaur'ları öldürerek 5 Oyma Centaur Totemi edin, ardından bunları Ghost Walker Post'taki Gurda Wildmane'e götür.", k={b=66450664, h=3952238793} }
V[93226] = { b="Dostluk Satın Almak: Magram", h="Bu klandaki itibarını önemli ölçüde artırmak için Totem Torbası'nı Desolace'taki Magram Village'da bulunan Magram Levazım Subayı'na götür. Magram Clan Centaur ile en az Tarafsız itibarda olmalısın.", k={b=3119889236, h=3274465714} }
V[93227] = { b="Dostluk Satın Almak: Gelkis", h="Bu klandaki itibarını önemli ölçüde artırmak için Totem Torbası'nı Desolace'taki Gelkis Village'da bulunan Gelkis Levazım Subayı'na götür. Gelkis Clan Centaur ile en az Tarafsız itibarda olmalısın.", k={b=2889992894, h=2452337478} }
V[93429] = { b="Kanımın Kanı", h="Fallow Sanctuary'de 10 Lost One öldür.", k={b=1678980480, h=2149526893} }
V[93430] = { b="Yemi Geri Almak", h="Pelluk'un yemini çalan Lost One Fisherman'ı bul ve yemi geri al.", k={b=2614011765, h=462682587} }
V[93464] = { b="Misafir Büyücü", h="Desolace'ta draenethyst'in gücünü bilen büyücüyü bul.", k={b=2074748557, h=813576993} }
V[93465] = { b="Draenethyst Üzerine Notlar", h="Gimashi'nin Draenethyst hakkındaki notlarını al ve Azore Aldamort'a geri götür.", k={b=2720016502, h=1216637228} }
V[93585] = { b="Bu Işık Benim", h="Peder Tuttle'a Harborage'a kadar eşlik et.", k={b=3807222707, h=504391488} }
V[93663] = { b="Yolda Kaybolanlar", h="Kayıp kuryeyi bul ve Dar'ın gönderisinin Harborage'a ulaştığından emin ol.", k={b=499451587, h=2888376208} }
V[93678] = { b="Draenethyst Üzerine Özet Notlar", h="Azore'un yeniden yazdığı notları Swamp of Sorrows'taki Harborage'da bulunan Magtoor'a geri götür.", k={b=2608103208, h=4118815065} }
V[93928] = { b="Fareye Süt, Kurabiyeye Fare", h="Fareye bir kurabiye getir.", k={b=1036430104, h=669697258} }
V[94872] = { b="Dostluk Satın Almak: Magram", h="Bu klandaki itibarını önemli ölçüde artırmak için Totem Torbası'nı Desolace'taki Magram Village'da bulunan Magram Levazım Subayı'na götür. Magram Clan Centaur ile en az Tarafsız itibarda olmalısın.", k={b=3119889236, h=3274465714} }
V[94873] = { b="Dostluk Satın Almak: Gelkis", h="Bu klandaki itibarını önemli ölçüde artırmak için Totem Torbası'nı Desolace'taki Gelkis Village'da bulunan Gelkis Levazım Subayı'na götür. Gelkis Clan Centaur ile en az Tarafsız itibarda olmalısın.", k={b=2889992894, h=2452337478} }
V[95816] = { b="Beni de Yaz!", h="Doldurulmuş formu Redridge Mountains'taki Elaine Compton'a götür.", k={b=674248941, h=1269932405} }
V[95999] = { b="ARANIYOR: Yakıcı Gar'im", h="Yakıcı Gar'im'in Kırık Asası'nı Lakeshire'daki Sulh Hâkimi Solomon'a teslim et.", k={b=851929014, h=1206370739} }
V[96222] = { b="Khan Hratha", h="Maraudine Anahtar Parçası'nı Desolace'taki Umarak'a götür.", k={b=3422342015, h=1238664327} }
V[96800] = { b="Vadesi Geçmiş", h="Runemaster'ların Kayıp Büyüsü adlı kitabı Scarlet Monastery'den geri getir.", k={b=2615209371, h=2092746959} }
V[97265] = { b="Hatefury'den Nefret Et", h="Desolace'taki Sargeron'da çeşitli Hatefury satirlerini alt et, ardından Shadowprey Village'daki Aka'rai'ye dön.", k={b=3950834864, h=1339789215} }
V[97277] = { b="Grund ve Gozwin", h="Kuzeybatıdaki tepelerde Grund ile Gozwin'in kampını bul. Gozwin'in Mekanisyen Seyir Defteri'ni geri al ve Snow Leopard Prowler'ı öldür.", k={b=777032118, h=3819722866} }
V[97284] = { b="Vahlarriel'in İntikamı", h="Desolace'taki Thunder Axe Fortress'ta Burning Blade orc'larını öldür, ardından Nijel's Point'teki Vahlarriel Demonslayer'a dön.", k={b=208034990, h=1454686050} }
V[97538] = { b="Boyalar İçin Pigmentler", h="Thunder Bluff'taki Tah Winterhoof, Mirkfallon Lake'ten 30 Mirkweed Kozası istiyor.", k={b=1781176002, h=1806014053} }
V[97539] = { b="İpeksi Dikişler", h="12 Cerrahi Örümcek İpeği'ni Arathi Highlands'deki Hammerfall'da bulunan Doktor Gregory Victor'a götür.", k={b=3327931372, h=3514216603} }
V[98021] = { b="Sentinel Hill'e Yolculuk", h="Westfall'daki Sentinel Hill'de Gryan Stoutmantle'a rapor ver.", k={b=3053403071, h=2483063198} }
V[98069] = { b="Çalınan Freewind Erzakı", h="8 Çalınmış Freewind Erzakı'nı Freewind Post'taki Jandia'ya getir.", k={b=139225091, h=23547816} }
V[98070] = { b="Çığlıkları Sustur", h="5 Screeching Harpy, 5 Screeching Roguefeather Harpy ve 5 Screeching Windcaller Harpy öldür.", k={b=2323750215, h=2449057739} }
V[98155] = { b="Kusursuz Pesterhide Postları", h="5 Kusursuz Pesterhide Postu'nu Kristy Grant'e getir.", k={b=3505248648, h=3354126548} }
V[98156] = { b="Paketlenmiş Kusursuz Postlar", h="Kusursuz Post Paketi'ni Kimberly Grant'e getir.", k={b=4132321291, h=3027827725} }
V[98247] = { b="Nakliye Etiketi", h="Nakliye Etiketi'ni Redridge Mountains'taki Azeroth Commerce Authority ticaret merkezinde birine teslim et.", k={b=1480903047, h=1398024221} }
V[98248] = { b="Nakliye Etiketi", h="Nakliye Etiketi'ni Barrens'ta, Crossroads yakınlarındaki Durotar Supply and Logistics ticaret merkezinde birine teslim et.", k={b=1480903047, h=235577554} }
V[98386] = { b="Alther's Mill", h="Redridge'deki Ustabaşı Oslow için Alther's Mill'de 12 Greater Tarantula öldür ve 6 Tarantula Yumurtası'nı yok et.", k={b=1545995110, h=2158714823} }
V[98387] = { b="Blackrock Ablukası", h="8 Çalınmış Silah ve 10 Blackrock Erzakı'nı Lakeshire'daki Mareşal Marris'e getir.", k={b=2655571078, h=2134433022} }
V[98407] = { b="Güç Gösterisi", h="Lakeshire yakınlarındaki Yardımcı Feldon için Redridge Thrasher'lardan 5 Dikenli Tasma topla.", k={b=583809258, h=1843578998} }
