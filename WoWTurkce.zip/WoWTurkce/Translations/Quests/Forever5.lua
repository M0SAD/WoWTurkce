if not WoWTurkce.FOREVER then return end -- yalnızca Classic Forever
-- Classic Forever'a özel görevler 5
-- b=başlık, a=açıklama, h=hedef, i=ilerleme, t=tamamlama
-- k = çevrilen İngilizce metnin parmak izi (metin değişirse çeviri gösterilmez, yeniden kaydedilir)
local V = WoWTurkce.Veri

V[92401] = { b="Korku Dolu Bir Rica", h="Ruins of Lordaeron'da Edward Heartweaver'ın ortadan kayboluşunu araştır.", k={b=2545874287, h=3115417639} }
V[92415] = { b="Seni Sevdiğimi Unutma", h="Kana Bulanmış Mektup'u Stormwind City'deki Yetimhane Başhemşiresi Nightingale'e götür.", k={b=701676161, h=4215901373} }
V[92421] = { b="Işığın Adaleti", h="Undercity'deki Morbin Lightbane için The Ruins of Lordaeron'da 25 Sağlam Uzuv topla.", k={b=744325031, h=1286506327} }
V[92422] = { b="Rath'mael'in Gazabı", h="Brill'deki Ölüm Muhafızı Kristof için Ruins of Lordaeron'da Rath'mael'i öldür.", k={b=308566479, h=683813457} }
V[92579] = { b="Valanaar'a", h="Aonda'nın Yazılı Raporu'nu Valanaar'daki Valennia Stormfist'e teslim et.", k={b=2694590094, h=2226591784} }
V[92595] = { b="Rüzgâr Biçimciler", h="Illaya Amberwind'in söyleyeceklerini dinle.", k={b=4292445358, h=923307116} }
V[92596] = { b="Yüce Tarikat", h="Otur ve Rathiril Sunlance ile konuş.", k={b=2041314978, h=1726730770} }
V[92597] = { b="Ley Hatlarını Okumak", h="Thendal Grove'daki ley hattında Ley Hattı Okuma ırk yeteneğini kullan.", k={b=178169989, h=3826402059} }
V[92598] = { b="Gökgörü Armağanı", h="Thendal Grove'daki Elemental Birleşme Noktası'nda Gökgörü ırk yeteneğini kullan.", k={b=1366780859, h=1326323591} }
V[92640] = { b="Çaresiz Zamanlar", h="Valanaar'daki Valennia Stormfist ile konuş ve talimatlarına uy.", k={b=2848969636, h=436846053} }
V[92642] = { b="İkmali Sekteye Uğratmak", h="Gustberry Lowlands'te 4 Al'Aketh Healer ve 8 Al'Aketh Brawler öldür.", k={b=1732309759, h=994850042} }
V[92643] = { b="Hain", h="Valanaar'ın kuzeybatısında, yaylaların hemen girişindeki evde tarikattan dönen haini bul.", k={b=1089240086, h=1677873687} }
V[92644] = { b="Talihsiz Haberler", h="Parlayan kristali Valanaar'daki Talanaanis Shadowsong'a teslim et.", k={b=3251316061, h=3422129411} }
V[92645] = { b="Kırıcıyı Kırmak", h="Gustberry Lowlands'te Komutan Belguilos'u öldür.", k={b=2151959621, h=1770550781} }
V[92646] = { b="Lorthuna ile Hesaplaşma", h="Yukarıdaki Rohashi Spires'a giden geçidi kullan ve Yüce Rahibe Lorthuna ile hesaplaşmalarında Elaadrin Evengale ile Ayessa Dawnsinger'a katıl.", k={b=2598921659, h=952095275} }
V[92679] = { b="Kan Haracı", h="Alvarion Windfield'ın söyleyeceklerini dinle ve Windfield Orchard'da Aamelia Windfield'ı bul.", k={b=2834778099, h=312490636} }
V[92682] = { b="Bir İşe Yara", h="Windfield Orchard'da 10 Olgun Fırtına Elması topla ve 5 Hungry Bandit öldür.", k={b=1286726512, h=2966845469} }
V[92683] = { b="Kelebek Tozu", h="Gustberry Lowlands'teki Flutterfly'lardan 5 Kelebek Tozu topla.", k={b=2699799126, h=2144608681} }
V[92684] = { b="Huysuz mu Huysuz Galestrider'lar", h="Gustberry Lowlands'in dört bir yanında bulunan Ornery Galestrider'lardan 7 Ova Galestrider Bonfilesi topla.", k={b=612429452, h=95820310} }
V[92685] = { b="Tepelerin Gözü Var", h="Gustberry Lowlands'teki Highwayman Bandit'lerden 7 Kana Bulanmış Haydut Maskesi topla.", k={b=3645829628, h=1531357932} }
V[92693] = { b="Direnmek", h="Haydut liderinin karşısına çıkmaya hazır olduğunda Aamelia Windfield ile konuş.", k={b=166538114, h=4195401949} }
V[92698] = { b="Benim Amacım Ne?", h="Arızalı Kasırga Yapıtı hakkında Aamelia Windfield ile konuş.", k={b=1632448745, h=802084609} }
V[92699] = { b="Yüce Magister", h="Valanaar'da Elaadrin Evengale'i bul.", k={b=3011767171, h=2271767818} }
V[92700] = { b="Büyük Gökgören", h="Valanaar'da Ayessa Dawnsinger'ı bul.", k={b=2202843544, h=3241228091} }
V[92701] = { b="Valanaar'a", h="Aonda'nın Yazılı Raporu'nu Valanaar'daki Valennia Stormfist'e teslim et.", k={b=2694590094, h=2226591784} }
V[92703] = { b="Haberi İlet", h="Valanaar'daki Alvarion Windfield ile konuş.", k={b=3193111246, h=3522712708} }
V[92708] = { b="Büyük Bir Macera", h="Ayessa Dawnsinger'ın söyleyeceklerini dinle.", k={b=4033039936, h=119486831} }
V[92709] = { b="Büyük Bir Macera", h="Valanaar'daki Elaadrin Evengale'in söyleyeceklerini dinle.", k={b=4033039936, h=4077581531} }
V[92727] = { b="Kayıp Âlim", h="Fillion Flamebreeze'e ne olduğunu öğren.", k={b=1480764972, h=3290262681} }
V[92741] = { b="İstenmeyen Ziyaretçiler", h="Shadowgale Forest'a git ve Valanaar'daki Iaadaria Bitterwind için 8 Çığırtkan Pençesi topla.", k={b=2451219447, h=2410082566} }
V[92834] = { b="On Katıyla Öç", h="Valanaar'ın kuzeyinde, Gustberry Fields'ta ya da Shrine of Akir'de bulunan Al'Aketh tarikatçılarından 10 Al'Aketh Rüzgârtaşı Tılsımı topla.", k={b=1735456651, h=2276799556} }
V[92840] = { b="Rüzgârı Yakalamak", h="Index Esoteria'yı Shen'dar Highlands'teki Overlook Standing Stones'a götür ve veri toplamak için bölgedeki Rüzgârtaşı Oluşumları üzerinde kullan.", k={b=1162726136, h=1709585303} }
V[92841] = { b="Valley of Bones", h="Magram ile itibarını yükselt ve Magram Village'ın güneyinde, Valley of Bones yakınlarında Orgrul'u bul.", k={b=2086839838, h=4067285754} }
V[92844] = { b="Kemik Dağı", h="Magram ile itibarını koru ve Desolace'ta Magram Village'ın güneyindeki Orgrul'a 426 Hafifçe Lanetlenmiş Kemik getir.", k={b=3042638780, h=1028370954} }
V[92846] = { b="Sürgün Ölü Çağırıcılar", h="Magram ile itibarını koru ve Valley of Bones'ta Outcast Necromancer'ları öldür.", k={b=2678379912, h=119781278} }
V[92847] = { b="Yozlaştıran Gözyaşları", h="Magram ile itibarını koru ve Orgrul'a 3 Taşlaşmış Ağaç Kabuğu ile 3 Kudretle Dolu Gözyaşı getir.", k={b=115795857, h=1217774144} }
V[92849] = { b="Kayıp Âlim", h="Fillion Flamebreeze'i aramaya devam et.", k={b=1480764972, h=3657915636} }
V[92850] = { b="Kayıp Âlim", h="Shriekling Den'deki Shriekling Matriarch'ı öldür, ardından kafasını Valanaar'daki Fillion Flamebreeze'e götür.", k={b=1480764972, h=1381329993} }
V[92860] = { b="Zephras'ın Hizmetinde", h="Valennia Stormfist'e rapor ver ve Yüce Tarikat'ın Al'Aketh'e karşı mücadelelerinde onların yanında olduğunu bildir.", k={b=2228679135, h=3900606413} }
V[92871] = { b="Zephras'ın Hizmetinde", h="Valennia Stormfist'e rapor ver ve Rüzgâr Biçimciler'in Al'Aketh'e karşı mücadelelerinde onların yanında olduğunu bildir.", k={b=2228679135, h=3295316918} }
V[92873] = { b="Kavram Kanıtı", h="Magram Klanı ile itibarını koru, ardından başarılı bir ayinden elde edilen 426 İyice Lanetlenmiş Kemik'i Orgrul'a getir.", k={b=1839189516, h=1026658851} }
V[92880] = { b="Valanaar'a Dönüş", h="Yorna'nın Raporu'nu Valanaar'daki Valennia Stormfist'e götür.", k={b=1028777390, h=3696236072} }
V[92881] = { b="Yüce Bilge'nin Ricası", h="Valanaar'daki Talaanis Shadowsong ile konuş.", k={b=1090018830, h=112478300} }
V[92893] = { b="Zayıflara Merhamet Yok", h="Magram Klanı ile itibarını koru ve Valley of Bones'un dört bir yanına dağılmış 5 Gelkis Captive öldür. Görev tamamlandığında Orgrul'a dön.", k={b=1069920818, h=2892694081} }
V[92894] = { b="Kemik Diriltme", h="Magram Klanı ile itibarını koru ve Valley of Bones'un dört bir yanında topraktan çıkmaya çabalayan ölümsüzleri tamamen diriltmek için Güçlendirilmiş Ölü Çağırma Asası'nı kullan. Magram ordusu büyüdüğünde Orgrul'a dön.", k={b=776863734, h=126971720} }
V[92947] = { b="Harekete Geçiyoruz", h="7 Al'Aketh Guardian, 7 Al'Aketh Spiritcaller ve 7 Al'Aketh Blademaster öldür, ardından Shrine of Akir'deki Hyusaa Quickbreeze'e rapor ver.", k={b=3228287049, h=3916918408} }
V[93034] = { b="Valley of Bones", h="Gelkis ile itibarını yükselt ve Gelkis Village'ın çok doğusunda, Valley of Bones yakınlarında Nerlokh'u bul.", k={b=2086839838, h=926705561} }
V[93035] = { b="Talancıları Talan Etmek", h="Gelkis Klanı ile itibarını koru ve 6 Undead Ravager öldür, ardından Valley of Bones'un güney girişindeki Nerlokh'a dön.", k={b=3894994671, h=4028260983} }
V[93036] = { b="Tarikata Sızmak", h="Shen'dar Village'daki Sania Silverstream ile konuş.", k={b=1018097481, h=2803606018} }
V[93037] = { b="Sürgünleri Def Etmek", h="Gelkis Klanı ile itibarını koru ve Valley of Bones'un girişindeki Nerlokh'a 1 Ölü Çağırıcı Cüppesi getir.", k={b=877455281, h=3444922970} }
V[93041] = { b="Gerçekle Yüzleşmek", h="Gelkis Klanı ile itibarını koru ve Gelkis Village'daki Bilge Uthek'e bir Lanetli Kafatası ile Gelkis Ölü Çağırıcı Cüppesi getir.", k={b=1044945957, h=2967777739} }
V[93058] = { b="Kendi Halkımızı Kurtarmak", h="Gelkis klanı ile itibarını koru ve Valley of Bones'ta 5 Gelkis Esiri'ni kurtar. İşin bittiğinde girişin yakınındaki Nerlokh'a dön.", k={b=174705047, h=1887767556} }
V[93062] = { b="Kemik Gömme", h="Gelkis Klanı ile itibarını koru ve Valley of Bones'un dört bir yanındaki 8 başarısız çağrının lanetlerini kaldır.", k={b=2381809481, h=2943039498} }
V[93065] = { b="Savaşa Hazırlan", h="Gustberry Lowlands'teki Valennia Stormfist ile konuş.", k={b=2041970999, h=3385562225} }
V[93066] = { b="Bristleback Retreat", h="Magram ile itibarını koru ve Bristleback Retreat'teki quilboar'ları öldür. Ardından Desolace'ta Valley of Bones'un diğer tarafındaki Magram Front'ta bulunan Hagiak'a rapor ver.", k={b=2229097090, h=1107503286} }
V[93072] = { b="Uzun Vadeli Çözümler", h="Magram klanı ile itibarını koru ve 2 Outcast Scout, 6 Outcast Marauder ve 8 Outcast Necromancer öldür, ardından Magram Front'taki Hagiak'a dön.", k={b=1878326813, h=2334066104} }
V[93089] = { b="Sırada Ne Var", h="Zephras Isle'dan ayrılmaya hazır olduğunda Elaadrin Evengale ile konuş.", k={b=3374323695, h=1316042992} }
V[93090] = { b="Sırada Ne Var", h="Zephras Isle'dan ayrılmaya hazır olduğunda Ayessa Dawnsinger ile konuş.", k={b=3374323695, h=952104545} }
V[93159] = { b="Tuhaf Münzevi", h="Shadowgale Forest'taki Tuhaf Münzevi ile konuş ve onun hakkında daha fazlasını öğren.", k={b=824770435, h=1788089934} }
V[93160] = { b="Ormanın Bereketi", h="Shadowgale Forest'ta 8 Shadowgale Palamudu topla.", k={b=3001809069, h=1385703462} }
V[93165] = { b="Sağır Kulaklara Merhamet", h="Shadowgale Forest, Shrine of Akir ya da Gustberry Lowlands'teki Al'Aketh tarikatçılarından 10 Al'Aketh Tarikatçısı Kulağı topla.", k={b=3679012751, h=892447903} }
V[93172] = { b="Oyukları Özgür Bırak", h="Shadowgale Forest'ta 10 Wind Hollow yok et.", k={b=2611736816, h=3721490515} }
V[93317] = { b="Yengeç Mevsimi", h="6 parça Windsong Crawler Eti topla.", k={b=3045544070, h=468554383} }
V[93318] = { b="ARANIYOR: Doymak Bilmez Vulgara", h="Shen'dar Highlands'te Doymak Bilmez Vulgara'yı öldür ve kafasını Danarii Bellowveil'e götür.", k={b=3294372727, h=2080746741} }
V[93319] = { b="Çalınmış Rüzgârtaşları", h="Shen'dar Highlands'teki Highlands Bandit'lerden 10 Çalınmış Rüzgârtaşı topla.", k={b=1814652318, h=1658135712} }
V[93320] = { b="Kule Savunması", h="Gustberry Lowlands'in doğu gözetleme kulesindeki Yorana Windyreed'e rapor ver.", k={b=1781944144, h=1892839084} }
V[93459] = { b="Daha Fazla Al'Aketh Kulağı", k={b=199365533} }
V[93461] = { b="Shen'dar Village'a Hoş Geldin", h="Shen'dar Village'daki Rathiril Sunlance ve Coriella Calmbreeze ile konuş.", k={b=3590723549, h=2037160581} }
V[93552] = { b="Rüzgârtaşı Hasadı", h="Thendal Grove'daki Ham Rüzgârtaşları'ndan 15 Rüzgârtaşı Kümesi topla.", k={b=3816086510, h=3160421031} }
V[93735] = { b="Bozuk Yapıt", h="Valanaar'ın batı tarafında Riaani Nightwind'i bul.", k={b=2098018572, h=1761741703} }
V[93736] = { b="İstenmeyen Ruhlar", h="Shadowgale Forest'taki Wind Hollow'lardan 10 Rüzgâr Oyuğu Özü topla.", k={b=3230102882, h=205778393} }
V[93737] = { b="Bozuk Yapıt", h="Riaani Nightwind ile konuş ve söyleyeceklerini dinle.", k={b=2098018572, h=1298936455} }
V[93738] = { b="Bozuk Yapıt", h="Valanaar'daki Ayessa Dawnsinger'a rapor ver.", k={b=2098018572, h=3253972234} }
V[93740] = { b="Kana Kan", h="Gustberry Lowlands'teki Al'Aketh tarikatçılarının cesetlerinden 10 Al'Aketh Rüzgârtaşı Tılsımı topla.", k={b=507365516, h=4239356320} }
V[93746] = { b="Sert Bir Karşılık", h="Shrine of Akir'e giden yol boyunca Belthaan Brightwish ile yüzleş.", k={b=3256989635, h=1675172169} }
V[93835] = { b="Lorthuna ile Hesaplaşma", h="Yukarıdaki Rohashi Spires'a giden geçidi kullan ve Yüce Rahibe Lorthuna ile hesaplaşmalarında Elaadrin Evengale ile Ayessa Dawnsinger'a katıl.", k={b=2598921659, h=3200257578} }
V[93836] = { b="Zephras'ın Kaderi", h="Valanaar'daki Talaanis Shadowsong ile konuş.", k={b=1957497048, h=112478300} }
V[93926] = { b="Batı Nöbeti", h="Batı gözetleme kulesinde Barış Muhafızı Vaaniel'i bul.", k={b=1989113701, h=2230784070} }
V[93927] = { b="Son Bir Rica", h="Ölü barış muhafızının yanında bulduğun notu al ve sonraki adımlarını belirlemek için oku.", k={b=1291362371, h=1767732211} }
V[93948] = { b="Mührü Teslim Et", h="Shadowsong Ailesi Mühür Yüzüğü'nü Valanaar'daki Talaanis Shadowsong'a teslim et.", k={b=2869448091, h=2362779268} }
V[93949] = { b="Böcek Avı", h="8 Enchanted Skyhopper'ı ortadan kaldırana kadar Valanaar'daki Skyhopper'ları öldür.", k={b=4109894643, h=3196387456} }
V[93951] = { b="Küçük Bir Güzellik", h="Shen'dar Highlands'te 8 Hippogryph Kuştüyü topla.", k={b=1834013822, h=285036390} }
V[93958] = { b="İç Tapınak", h="Shrine of Akir'deki iç tapınakta Valennia Stormfist ile konuş.", k={b=3210772797, h=4016915453} }
V[94369] = { b="Zephras'ın Kaderi", h="Valanaar'daki Talaanis Shadowsong ile konuş.", k={b=1957497048, h=112478300} }
V[94411] = { b="İşgüzar Büyücüler", h="Shen'dar Highlands'te 6 High Order Apprentice öldür.", k={b=4175424977, h=1278686428} }
V[94413] = { b="Büyülü Bir Hakaret", h="Shen'dar Highlands'te 6 Windshaper Novice Seer öldür.", k={b=2830760036, h=2899027901} }
V[94414] = { b="Zephras'ın Çapaları", h="Halaan Hawk-Eye ile konuş ve uzaktaki çapa direğini görmek için onun armağanını ödünç al.", k={b=2776614694, h=4116277299} }
V[94484] = { b="Tedirgin Edici Sessizlik", h="Shadowgale Forest'ın kuzeydoğu kesiminde Elegael Thornpaw'u bul ve onunla konuş.", k={b=3682002436, h=1694677214} }
V[94485] = { b="Leydi'nin Gözyaşları", h="8 Leydi Gözyaşı Yosunu topla.", k={b=1976142052, h=2574273902} }
V[94486] = { b="Bağlama İçin Tüyler", h="Shadowgale Forest'taki Shadowgale Shriekling'lerden 20 tüy topla.", k={b=2814315897, h=392170751} }
V[94487] = { b="İstenmeyen ve Değersiz", h="Shadowgale Forest'taki Al'Aketh Footsoldier ve Al'Aketh Stormchaser'lardan 10 Kana Bulanmış Yadigâr topla.", k={b=2587738222, h=4145642656} }
V[94488] = { b="Bizi Bağlayan Bağlar", h="Komutan Haalien'i öldür ve kafasını Shadowgale Forest'taki Elegael Thornpaw'a götür.", k={b=61076073, h=1801103363} }
V[94489] = { b="İhanetin Yaraları", h="Shadowgale Forest'taki Nightfang Den'e gir, 7 druidi iyileştir ve Jorel Windsinger'ı bul.", k={b=3221470031, h=3349489395} }
V[94490] = { b="Yırtık Mektup", h="Yırtık Mektup'u Shadowgale Forest'taki Elegael Thornpaw'a götür.", k={b=4177055113, h=4105703947} }
V[94491] = { b="İnin Kaderi", h="Mektubu Valanaar'daki Lotheluum'a ver ve olup biteni ona anlat.", k={b=4252781235, h=3752867102} }
V[94493] = { b="Boşuna Bir Fedakârlık", h="Shadowgale Forest'ın kuzeydoğu kesimindeki Elegael Thornpaw ile konuş.", k={b=2011668276, h=3759821706} }
V[94568] = { b="Tarikatın Gerçek Planları", h="Talaanis Shadowsong ile konuş ve konuşmayı izle.", k={b=2554346255, h=1660945348} }
V[94896] = { b="Mültecilere Yardım", h="Ban'aethal harabelerinden 8 Terk Edilmiş Eşya topla.", k={b=1233592017, h=495340098} }
V[94897] = { b="Sevilen Birinin Kaderi", h="Ruins of Ban'aethal'da Resaan'ı bul.", k={b=1014810648, h=971628542} }
V[94946] = { b="Büyülü Şehir Dalaran", h="Zephras Isle'dan Dalaran City'ye giden gök kesici gemiye bin ve vardığında Danaaris Stargale ile konuş.", k={b=3250877205, h=628246443} }
V[95189] = { b="Lordaeron Arması", h="Lordaeron Arması'nı Stormwind City'deki Leydi Dena Kennedy'ye geri götür.", k={b=2662418017, h=1764376012} }
V[95195] = { b="Kana Bulanmış Nişan", h="10 Kana Bulanmış Nişan topla ve onları Stormwind City'deki General Marcus Jonathan'a götür.", k={b=1621144985, h=3176599055} }
V[95204] = { b="Lordaeron Arması", h="Lordaeron Arması'nı Undercity'deki Oran Snakewrithe'a götür.", k={b=2662418017, h=3693233242} }
V[95216] = { b="Yeni Veba", h="Undercity'deki Theodore Griffs için Ruins of Lordaeron'daki Witherfang'den Son Derece Zehirli Suş'u topla.", k={b=1704776974, h=60315679} }
V[95250] = { b="İğrenç Yaratıklar", h="Ruins of Lordaeron'da Baron'un Kafası'nı ele geçir ve Yüzbaşı Truman'a geri getir.", k={b=3726817053, h=1634776183} }
V[95349] = { b="Earthen Ring", h="Zephras Isle'dan Mulgore'a giden gök kesici gemiye bin ve vardığında Alaana Stormwalker ile konuş.", k={b=3225133245, h=1111828989} }
V[97288] = { b="Bitmeyen Azap", h="İğrenç Kafa'yı Undercity'deki Usta Eczacı Faranell'e teslim et.", k={b=3499235206, h=2639932764} }
V[97289] = { b="Bitmeyen Azap", h="Baron'un Kafası'nı Undercity'deki Othmar'ın cesedine götür.", k={b=3499235206, h=474969875} }
V[97291] = { b="Bitmeyen Azap", h="Undercity'deki Usta Eczacı Faranell için Trade Quarter'daki Tawny Grisette'ten bir Zehirli Kafatası Mantarı, Bitkicilik Eğitmeni'nin yakınından Kabarcıkotu ve Rogues' Quarter'daki zehir satıcısından Istırap Özü topla.", k={b=3499235206, h=759801671} }
V[97292] = { b="Bitmeyen Azap", h="Usta Eczacı Faranell için Tıslayan Serum'u Othmar'ın cesedinin üzerindeki düzeneğe enjekte et.", k={b=3499235206, h=1747495141} }
V[98512] = { b="Al'Aketh Suikastçıları", h="Shen'dar Highlands'te 10 Al'Aketh Assassin öldür.", k={b=104457399, h=3189624499} }
V[98887] = { b="Darkspear Islands'ta Çatışma", h="Savaş alanlarının dışındaki bir Horde Savaş Getiricisine 3 Darkspear Islands Şeref Nişanı getir.", k={b=1821437943, h=2804105651} }
V[98888] = { b="Darkspear Islands'ta Çatışma", k={b=1821437943} }
V[98889] = { b="Darkspear Islands'ta Çatışma", h="Savaş alanlarının dışındaki bir Horde Savaş Getiricisine 3 Darkspear Islands Şeref Nişanı getir.", k={b=1821437943, h=2804105651} }
V[98891] = { b="Darkspear Islands'ta Çatışma", h="Savaş alanlarının dışındaki bir Horde Savaş Getiricisine 3 Darkspear Islands Şeref Nişanı getir.", k={b=1821437943, h=2804105651} }
V[98893] = { b="Darkspear Islands'ta Çatışma", h="Savaş alanlarının dışındaki bir Horde Savaş Getiricisine 3 Darkspear Islands Şeref Nişanı getir.", k={b=1821437943, h=2804105651} }
V[98895] = { b="Darkspear Islands Çarpışması", h="Savaş alanlarının dışındaki bir İttifak Tuğgeneraline 3 Darkspear Islands Şeref Nişanı getir.", k={b=2876895963, h=1222847228} }
V[98896] = { b="Darkspear Islands Çarpışması", k={b=2876895963} }
V[98897] = { b="Darkspear Islands Çarpışması", h="Savaş alanlarının dışındaki bir İttifak Tuğgeneraline 3 Darkspear Islands Şeref Nişanı getir.", k={b=2876895963, h=1222847228} }
V[98899] = { b="Darkspear Islands Çarpışması", h="Savaş alanlarının dışındaki bir İttifak Tuğgeneraline 3 Darkspear Islands Şeref Nişanı getir.", k={b=2876895963, h=1222847228} }
V[98901] = { b="Darkspear Islands Çarpışması", h="Savaş alanlarının dışındaki bir İttifak Tuğgeneraline 3 Darkspear Islands Şeref Nişanı getir.", k={b=2876895963, h=1222847228} }
V[98903] = { b="Darkspear Islands Savaşı!", h="Bir Darkspear Islands savaş alanını kazan ve Northwatch Hold'daki Brelinda McFarry'nin yanına dön.", k={b=328103796, h=2432622788} }
V[98904] = { b="Darkspear Islands Savaşı!", h="Bir Darkspear Islands savaş alanını kazan ve Northwatch Hold'daki Brelinda McFarry'nin yanına dön.", k={b=328103796, h=2432622788} }
V[98905] = { b="Darkspear Islands Savaşı!", h="Bir Darkspear Islands savaş alanını kazan ve Northwatch Hold'daki Brelinda McFarry'nin yanına dön.", k={b=328103796, h=2432622788} }
V[98906] = { b="Darkspear Islands Savaşı!", h="Bir Darkspear Islands savaş alanını kazan ve The Merchant Coast'taki Nizook Boof'un yanına dön.", k={b=328103796, h=586009235} }
V[98907] = { b="Darkspear Islands Savaşı!", h="Bir Darkspear Islands savaş alanını kazan ve The Merchant Coast'taki Nizook Boof'un yanına dön.", k={b=328103796, h=586009235} }
V[98908] = { b="Darkspear Islands Savaşı!", h="Bir Darkspear Islands savaş alanını kazan ve The Merchant Coast'taki Nizook Boof'un yanına dön.", k={b=328103796, h=586009235} }
V[98910] = { b="Darkspear Temel Yardım Paketi", k={b=2986643006} }
V[98913] = { b="Theramore Temel Yardım Paketi", k={b=2395964117} }
V[99260] = { b="Fillion'un Görevi", h="Valanaar'daki Elaadrin Evengale ile konuş.", k={b=2117587783, h=381593881} }
