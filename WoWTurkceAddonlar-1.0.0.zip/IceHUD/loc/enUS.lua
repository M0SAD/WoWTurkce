local debug = false
--[==[@debug@
debug = true
--@end-debug@]==]

local L = LibStub("AceLocale-3.0"):NewLocale("IceHUD", "enUS", true, debug)

L["(De)Buff watcher"] = "(Güçlendirme/Zayıflatma) izleyici"
L["|cff8888ffIceHUD|r: Combat lockdown restriction. Leave combat and try again."] = "|cff8888ffIceHUD|r: Savaş kilidi kısıtlaması. Savaştan çık ve tekrar dene."
L[ [=[|cff9999ffLeft click|r and drag to adjust bar Offset.

Hold |cff9999ffAlt/Option|r to adjust Position instead of Offset.
Hold |cff9999ffShift|r to lock vertical position, hold |cff9999ffControl|r to lock horizontal position.

|cff9999ffMiddle click|r to reset to previous position.

|cff9999ffRight click|r to lock in place.]=] ] = [=[|cff9999ffSol tık|r ve sürükleyerek çubuk Kaymasını ayarlayın.

Kayma yerine Konumu ayarlamak için |cff9999ffAlt/Option|r basılı tutun.
Dikey konumu kilitlemek için |cff9999ffShift|r, yatay konumu kilitlemek için |cff9999ffControl|r basılı tutun.

Önceki konuma dönmek için |cff9999ffOrta tık|r.

Yerine kilitlemek için |cff9999ffSağ tık|r.]=]
L[ [=[|cff9999ffLeft click|r and drag to move. Hold |cff9999ffShift|r to lock vertical position, hold |cff9999ffControl|r to lock horizontal position.

|cff9999ffMiddle click|r to reset to previous position.

|cff9999ffRight click|r to lock in place.]=] ] = [=[|cff9999ffSol tık|r ve sürükleyerek taşıyın. Dikey konumu kilitlemek için |cff9999ffShift|r, yatay konumu kilitlemek için |cff9999ffControl|r basılı tutun.

Önceki konuma dönmek için |cff9999ffOrta tık|r.

Yerine kilitlemek için |cff9999ffSağ tık|r.]=]
L["1 combo point: yellow, max combo points: red"] = "1 kombo puanı: sarı, azami kombo puanı: kırmızı"
L["1 lacerate: yellow, 5 lacerates: red"] = "1 yırtma: sarı, 5 yırtma: kırmızı"
L["1 maelstrom: yellow, 5 maelstroms: red"] = "1 girdap: sarı, 5 girdap: kırmızı"
L["1 sunder: yellow, 5 sunders: red"] = "1 zırh delme: sarı, 5 zırh delme: kırmızı"
L["A custom bar has been created and can be configured through Module Settings => MyCustomBar. It is highly recommended that you change the bar name of this module so that it's easier to identify."] = "Özel bir çubuk oluşturuldu ve Modül Ayarları => MyCustomBar üzerinden yapılandırılabilir. Daha kolay tanımlanması için bu modülün çubuk adını değiştirmen şiddetle önerilir."
L["A custom cooldown bar has been created and can be configured through Module Settings => MyCustomCD. It is highly recommended that you change the bar name of this module so that it's easier to identify."] = "Özel bir bekleme çubuğu oluşturuldu ve Modül Ayarları => MyCustomCD üzerinden yapılandırılabilir. Daha kolay tanımlanması için bu modülün çubuk adını değiştirmen şiddetle önerilir."
L["A custom counter bar has been created and can be configured through Module Settings => MyCustomCounterBar. It is highly recommended that you change the bar name of this module so that it's easier to identify."] = "Özel bir sayaç çubuğu oluşturuldu ve Modül Ayarları => MyCustomCounterBar üzerinden yapılandırılabilir. Daha kolay tanımlanması için bu modülün çubuk adını değiştirmen şiddetle önerilir."
L["A custom counter has been created and can be configured through Module Settings => MyCustomCounter. It is highly recommended that you change the bar name of this module so that it's easier to identify."] = "Özel bir sayaç oluşturuldu ve Modül Ayarları => MyCustomCounter üzerinden yapılandırılabilir. Daha kolay tanımlanması için bu modülün çubuk adını değiştirmen şiddetle önerilir."
L["A custom health bar has been created and can be configured through Module Settings => MyCustomHealth. It is highly recommended that you change the bar name of this module so that it's easier to identify."] = "Özel bir can çubuğu oluşturuldu ve Modül Ayarları => MyCustomHealth üzerinden yapılandırılabilir. Daha kolay tanımlanması için bu modülün çubuk adını değiştirmen şiddetle önerilir."
L["A custom mana bar has been created and can be configured through Module Settings => MyCustomMana. It is highly recommended that you change the bar name of this module so that it's easier to identify."] = "Özel bir mana çubuğu oluşturuldu ve Modül Ayarları => MyCustomMana üzerinden yapılandırılabilir. Daha kolay tanımlanması için bu modülün çubuk adını değiştirmen şiddetle önerilir."
L["Abbreviate estimated health"] = "Tahmini canı kısalt"
L["Abbreviate health"] = "Canı kısalt"
L["Absorb bar alpha"] = "Emilim çubuğu saydamlığı"
L["Added strata"] = "Eklenen katman"
L["Adjust the horizontal position of the aura icon"] = "Simgenin yatay konumunu ayarla"
L["Adjust the vertical placement of this bar"] = "Bu çubuğun dikey yerleşimini ayarla"
L["Adjust the vertical position of the aura icon"] = "Simgenin dikey konumunu ayarla"
L["Adjusts the size of the aura icon for this bar"] = "Bu çubuğun simge boyutunu ayarlar"
L["Advanced Bar Settings"] = "Gelişmiş Çubuk Ayarları"
L["After spell name"] = "Büyü adından sonra"
L["Aggro Indicator alpha"] = "Saldırganlık Göstergesi saydamlığı"
L["Aggro indicator alpha (0 is disabled)"] = "Saldırganlık göstergesi saydamlığı (0 devre dışı)"
L["Alert Party"] = "Partiyi Uyar"
L["Allow click casting"] = "Tıklayarak büyü yapmaya izin ver"
L["Allow click-targeting"] = "Tıklayarak hedeflemeye izin ver"
L["Allow click-targeting in combat"] = "Savaşta tıklayarak hedeflemeye izin ver"
L["Allow custom point placement"] = "Özel nokta yerleşimine izin ver"
L["Allow mouse interaction"] = "Fare etkileşimine izin ver"
L["Alpha in combat"] = "Savaşta saydamlık"
L["Alpha OOC and not full"] = "Savaş dışında ve tam değilken saydamlık"
L["Alpha OOC and Target"] = "Savaş dışında ve hedef varken saydamlık"
L["Alpha out of combat"] = "Savaş dışında saydamlık"
L["Also show numeric"] = "Sayısal olarak da göster"
L["Always"] = "Her zaman"
L["Always display bar"] = "Çubuğu her zaman göster"
L["Always show at 100% alpha"] = "Her zaman %100 saydamlıkta göster"
L["Always shows the Druid's Energy level while in non-energy-using forms."] = "Druid'in Enerji seviyesini enerji kullanmayan formlarda da her zaman gösterir."
L["Always, when targeting"] = "Her zaman, hedef varken"
L["Anchor to"] = "Şuna bağla"
L["Animate changes"] = "Değişiklikleri canlandır"
L["Animation Duration"] = "Animasyon Süresi"
L["Animation Settings"] = "Animasyon Ayarları"
L["Answers to questions that are frequently asked."] = "Sık sorulan sorulara yanıtlar."
L[ [=[Any valid unit id such as: party1, raid14, targettarget, etc. Not guaranteed to work with all unit ids.

Remember to press ENTER after filling out this box with the name you want or it will not save.]=] ] = [=[party1, raid14, targettarget gibi geçerli herhangi bir birim kimliği. Tüm birim kimlikleriyle çalışması garanti değildir.

Bu kutuyu istediğiniz adla doldurduktan sonra ENTER tuşuna basmayı unutmayın, yoksa kaydedilmez.]=]
L["Are you sure you want to delete this module? This will remove all settings associated with it and cannot be un-done."] = "Bu modülü silmek istediğine emin misin? Bu işlem, modülle ilgili tüm ayarları kaldırır ve geri alınamaz."
L["Aura icon horizontal offset"] = "Simge yatay kayması"
L["Aura icon scale"] = "Simge ölçeği"
L["Aura icon vertical offset"] = "Simge dikey kayması"
L["Aura settings"] = "Aura ayarları"
L["Aura to track"] = "İzlenecek aura"
L["Automatically size this module to the addon's 'gap' setting"] = "Bu modülü eklentinin 'boşluk' ayarına göre otomatik boyutlandır"
L["Background Alpha"] = "Arka Plan Saydamlığı"
L["Background alpha for bars IC"] = "Savaştaki çubuklar için arka plan saydamlığı"
L["Background alpha for bars OOC and bar not full (Target takes precedence over this)"] = "Savaş dışında ve çubuk tam değilken çubuklar için arka plan saydamlığı (Hedef bundan önceliklidir)"
L["Background alpha for bars OOC and target accuired (takes precedence over Not Full)"] = "Savaş dışında ve hedef varken çubuklar için arka plan saydamlığı (Tam Değil'den önceliklidir)"
L["Background alpha for bars OOC without target"] = "Savaş dışında ve hedef yokken çubuklar için arka plan saydamlığı"
L["Background Color"] = "Arka Plan Rengi"
L["Bar Alpha"] = "Çubuk Saydamlığı"
L["Bar alpha In Combat"] = "Savaştaki çubuk saydamlığı"
L["Bar alpha Out Of Combat with target accuired (takes precedence over Not Full)"] = "Savaş dışında ve hedef varken çubuk saydamlığı (Tam Değil'den önceliklidir)"
L["Bar alpha Out Of Combat with target accuired or bar not full (Target takes precedence over this)"] = "Savaş dışında ve hedef varken veya çubuk tam değilken çubuk saydamlığı (Hedef bundan önceliklidir)"
L["Bar alpha Out Of Combat without target"] = "Savaş dışında ve hedef yokken çubuk saydamlığı"
L["Bar Background Blend Mode"] = "Çubuk Arka Planı Karışım Modu"
L["Bar background visible"] = "Çubuk arka planı görünür"
L["Bar Blend Mode"] = "Çubuk Karışım Modu"
L["Bar color"] = "Çubuk rengi"
L["Bar Font Bold"] = "Çubuk Yazı Tipi Kalın"
L["Bar Font Size"] = "Çubuk Yazı Boyutu"
L["Bar Height"] = "Çubuk Yüksekliği"
L["Bar horizontal adjust"] = "Çubuk yatay ayarı"
L["Bar name"] = "Çubuk adı"
L["Bar Proportion"] = "Çubuk Oranı"
L["Bar Settings"] = "Çubuk Ayarları"
L["Bar Space"] = "Çubuk Aralığı"
L["Bar Texture"] = "Çubuk Dokusu"
L["Bar texture height (not the actual bar!)"] = "Çubuk dokusu yüksekliği (gerçek çubuk değil!)"
L["Bar Texture Override"] = "Çubuk Dokusu Geçersiz Kılma"
L["Bar texture width (not the actual bar!)"] = "Çubuk dokusu genişliği (gerçek çubuk değil!)"
L["Bar vertical offset"] = "Çubuk dikey kayması"
L["Bar visible"] = "Çubuk görünür"
L["Bar Width"] = "Çubuk Genişliği"
L["Bar width modifier"] = "Çubuk genişlik değiştirici"
L["Bear"] = "Ayı"
L["Below spell name"] = "Büyü adının altında"
L["BG Alpha in combat"] = "Savaşta Arka Plan Saydamlığı"
L["BG Alpha OOC and not Full"] = "Savaş dışında ve tam değilken Arka Plan Saydamlığı"
L["BG Alpha OOC and Target"] = "Savaş dışında ve hedef varken Arka Plan Saydamlığı"
L["BG Alpha out of combat"] = "Savaş dışında Arka Plan Saydamlığı"
L["Blizzard currently does not provide a proper way to right-click dismiss a pet with custom unit frames."] = "Blizzard şu anda özel birim çerçeveleriyle bir evcil hayvanı sağ tıklayarak azletmek için uygun bir yol sunmuyor."
L["Blizzard currently does not provide a proper way to right-click focus with custom unit frames."] = "Blizzard şu anda özel birim çerçeveleriyle sağ tıklayarak odaklanmak için uygun bir yol sunmuyor."
L["Blizzard currently does not provide a proper way to right-click report someone AFK with custom unit frames."] = "Blizzard şu anda özel birim çerçeveleriyle birini sağ tıklayarak AFK bildirmek için uygun bir yol sunmuyor."
L["Broadcasts crowd control effects you apply to your target via the party chat channel"] = "Hedefine uyguladığın kalabalık kontrolü etkilerini parti sohbet kanalından duyurur"
L["Buff anchor to"] = "Güçlendirme bağlantısı"
L["Buff grow direction"] = "Güçlendirme büyüme yönü"
L["Buff horizontal offset"] = "Güçlendirme yatay kayması"
L["Buff or debuff?"] = "Güçlendirme mi, zayıflatma mı?"
L["Buff placement settings"] = "Güçlendirme yerleşim ayarları"
L["Buff Settings"] = "Güçlendirme Ayarları"
L["Buff size"] = "Güçlendirme boyutu"
L["Buff timer display"] = "Güçlendirme zamanlayıcı gösterimi"
L["Buff vertical offset"] = "Güçlendirme dikey kayması"
L["Buff zoom"] = "Güçlendirme yakınlaştırması"
L["Buff/debuff icon size"] = "Güçlendirme/zayıflatma simge boyutu"
L["Buff/debuff icon zoom"] = "Güçlendirme/zayıflatma simge yakınlaştırması"
L["Buff/Debuff Settings"] = "Güçlendirme/Zayıflatma Ayarları"
L["Buff/debuff size for buffs/debuffs that were applied by you, the player"] = "Oyuncu olan senin uyguladığın güçlendirme/zayıflatmaların boyutu"
L["Buffs / row"] = "Satır başına güçlendirme"
L["Cannot report AFK from addons"] = "Eklentilerden AFK bildirilemez"
L["Cast Text"] = "Büyü Yazısı"
L["Center"] = "Orta"
L["Change color"] = "Rengi değiştir"
L["Change color when not in range"] = "Menzil dışındayken rengi değiştir"
L["Changes the bar color to the CastNotInRange color when the target goes out of range for the current spell."] = "Hedef geçerli büyü için menzil dışına çıktığında çubuk rengini CastNotInRange rengine çevirir."
L[ [=[Changes the color of this bar to be the minimum health or mana color when it's below the low threshold. See the 'MinHealthColor' and 'MinManaColor' colors in the 'Colors' option page.

This option only applies to health and mana bars.]=] ] = [=[Düşük eşiğin altındayken bu çubuğun rengini asgari can veya mana rengine çevirir. 'Renkler' seçenek sayfasındaki 'MinHealthColor' ve 'MinManaColor' renklerine bakın.

Bu seçenek yalnızca can ve mana çubuklarına uygulanır.]=]
L["Checking this means that only buffs or debuffs that the player applied will trigger this bar"] = "Bunu işaretlemek, bu çubuğu yalnızca oyuncunun uyguladığı güçlendirme veya zayıflatmaların tetikleyeceği anlamına gelir"
L["Choose a marker to edit. This will place the marker's settings in the fields above here."] = "Düzenlenecek bir işaretçi seç. Bu, işaretçinin ayarlarını yukarıdaki alanlara yerleştirir."
L["Choose whether the runes use a cooldown-style wipe, simply an alpha fade to show availability or both."] = "Runelerin bekleme tarzı bir silme mi, yalnızca kullanılabilirliği göstermek için saydamlık solması mı, yoksa ikisi birden mi kullanacağını seç."
L["Choose whether the totems use a cooldown-style wipe or simply an alpha fade to show availability."] = "Totemlerin bekleme tarzı bir silme mi, yoksa yalnızca kullanılabilirliği göstermek için saydamlık solması mı kullanacağını seç."
L["Choose whether you'd like a graphical or numeric representation of the runes."] = "Runelerin grafik mi yoksa sayısal mı gösterileceğini seç."
L[ [=[Choose whether you'd like a graphical or numeric representation of the runes.

NOTE: The color of 'Numeric' mode can be controlled by the HolyPowerNumeric color.]=] ] = [=[Runelerin grafik mi sayısal mı gösterileceğini seçin.

NOT: 'Sayısal' modun rengi HolyPowerNumeric rengiyle denetlenebilir.]=]
L[ [=[Choose whether you'd like a graphical or numeric representation of the runes.

NOTE: The color of 'Numeric' mode can be controlled by the ShardCounterNumeric color.]=] ] = [=[Runelerin grafik mi sayısal mı gösterileceğini seçin.

NOT: 'Sayısal' modun rengi ShardCounterNumeric rengiyle denetlenebilir.]=]
L["Class color bar"] = "Sınıf rengi çubuk"
L["Classification icon"] = "Sınıflandırma simgesi"
L[ [=[Click the + next to |cffffdc42Module Settings|r to see the available modules that you can tweak.

Also notice that some modules have a + next to them. This will open up additional settings such as text tweaks and icon tweaks on that module.]=] ] = [=[Ayarlayabileceğiniz modülleri görmek için |cffffdc42Modül Ayarları|r yanındaki + işaretine tıklayın.

Bazı modüllerin yanında da + olduğunu fark edin. Bu, o modülün yazı ve simge ayarları gibi ek ayarlarını açar.]=]
L["Click to open IceHUD options."] = "IceHUD seçeneklerini açmak için tıkla."
L["Color"] = "Renk"
L["Color bar by health %"] = "Çubuğu can %'sine göre renklendir"
L["Color bar by mana %"] = "Çubuğu mana %'sine göre renklendir"
L["Color NPC by hostility"] = "NPC'yi düşmanlığa göre renklendir"
L["Colors"] = "Renkler"
L["Colors the health bar from MaxHealthColor to MinHealthColor based on current health %"] = "Can çubuğunu mevcut can %'sine göre MaxHealthColor'dan MinHealthColor'a renklendirir"
L[ [=[Colors the health bar from MaxHealthColor to MinHealthColor based on current health %

(Note: This overrides the 'class color bar' setting. Disable this to use class coloring)]=] ] = [=[Can çubuğunu mevcut can yüzdesine göre MaxHealthColor'dan MinHealthColor'a renklendirir

(Not: Bu 'sınıf rengi çubuğu' ayarının önüne geçer. Sınıf rengini kullanmak için bunu kapatın)]=]
L["Colors the mana bar from MaxManaColor to MinManaColor based on current mana %"] = "Mana çubuğunu mevcut mana %'sine göre MaxManaColor'dan MinManaColor'a renklendirir"
L["Combo gap"] = "Kombo boşluğu"
L["Combo Points Font Size"] = "Kombo Puanı Yazı Boyutu"
L["Configuration Mode"] = "Yapılandırma Modu"
L["Contextual Background"] = "Bağlamsal Arka Plan"
L["Controls what it means for the bar to be filled. A normal bar will grow larger as the value grows from 0% to 100%. A reversed bar will shrink as the value grows from 0% to 100%."] = "Çubuğun dolu olmasının ne anlama geldiğini belirler. Normal bir çubuk değer %0'dan %100'e çıktıkça büyür. Ters bir çubuk değer %0'dan %100'e çıktıkça küçülür."
L["Controls which direction the bar fills up. With this checked, the bar will fill opposite from normal (e.g. for health: 0% at the top, 100% at the bottom)."] = "Çubuğun hangi yöne doğru dolduğunu belirler. Bu işaretliyken çubuk normalin tersine dolar (örn. can için: üstte %0, altta %100)."
L["Cooldown"] = "Bekleme"
L["Cooldown timer display"] = "Bekleme zamanlayıcı gösterimi"
L["Cooldown type"] = "Bekleme türü"
L["Count color"] = "Sayı rengi"
L["Count minimum color"] = "Sayı asgari rengi"
L["Counter"] = "Sayaç"
L["Counter look and feel"] = "Sayaç görünümü"
L["Counter name"] = "Sayaç adı"
L["CounterBar"] = "SayaçÇubuğu"
L["Create"] = "Oluştur"
L["Create custom module"] = "Özel modül oluştur"
L["Create marker"] = "İşaretçi oluştur"
L["Create or remove markers at various points along the bar here"] = "Burada çubuk boyunca çeşitli noktalarda işaretçiler oluştur veya kaldır"
L["Creates a new marker with the chosen settings."] = "Seçilen ayarlarla yeni bir işaretçi oluşturur."
L["Creates a new module of this same type and with all the same settings."] = "Aynı türde ve aynı ayarlara sahip yeni bir modül oluşturur."
L["Creates the selected custom module"] = "Seçilen özel modülü oluşturur"
L["Custom bar settings"] = "Özel çubuk ayarları"
L["Custom CD settings"] = "Özel BK ayarları"
L["Custom color"] = "Özel renk"
L["Custom minimum color"] = "Özel asgari renk"
L["Custom unit"] = "Özel birim"
L["Debuff anchor to"] = "Zayıflatma bağlantısı"
L["Debuff grow direction"] = "Zayıflatma büyüme yönü"
L["Debuff horizontal offset"] = "Zayıflatma yatay kayması"
L["Debuff placement settings"] = "Zayıflatma yerleşim ayarları"
L["Debuff Settings"] = "Zayıflatma Ayarları"
L["Debuff size"] = "Zayıflatma boyutu"
L["Debuff vertical offset"] = "Zayıflatma dikey kayması"
L["Debugging"] = "Hata ayıklama"
L["Defines when cast bar should flash on failed spells"] = "Büyü çubuğunun başarısız büyülerde ne zaman çakacağını belirler"
L["Defines when cast bar should flash on instant spells"] = "Büyü çubuğunun anlık büyülerde ne zaman çakacağını belirler"
L["Delete me"] = "Beni sil"
L["Deletes this custom module and all associated settings. Cannot be undone!"] = "Bu özel modülü ve tüm ilgili ayarları siler. Geri alınamaz!"
L["Determines the bar width compared to the whole texture width"] = "Çubuk genişliğini tüm doku genişliğiyle karşılaştırarak belirler"
L["Display aura icon"] = "Simgeyi göster"
L["Display mode"] = "Gösterim modu"
L["Display Mode"] = "Gösterim Modu"
L["Display non-interruptible color"] = "Kesilemez rengi göster"
L["Display target details"] = "Hedef ayrıntılarını göster"
L["Display target guild"] = "Hedef loncasını göster"
L["Display target name"] = "Hedef adını göster"
L["Display when empty"] = "Boşken göster"
L["Display when targeting"] = "Hedef varken göster"
L["Distance between the left and right bars"] = "Sol ve sağ çubuklar arasındaki mesafe"
L[ [=[DogTag-formatted string to use for the bottom text line (leave blank to revert to old behavior)

Type /dogtag for a list of available tags.

Remember to press Accept after filling out this box or it will not save.]=] ] = [=[Alt yazı satırı için kullanılacak DogTag biçimli metin (eski davranışa dönmek için boş bırakın)

Kullanılabilir etiketlerin listesi için /dogtag yazın.

Bu kutuyu doldurduktan sonra Kabul'e basmayı unutmayın, yoksa kaydedilmez.]=]
L[ [=[DogTag-formatted string to use for the left side of the bar.

Type /dogtag for a list of available tags.

Remember to press Accept after filling out this box or it will not save.]=] ] = [=[Çubuğun sol tarafı için kullanılacak DogTag biçimli metin.

Kullanılabilir etiketlerin listesi için /dogtag yazın.

Bu kutuyu doldurduktan sonra Kabul'e basmayı unutmayın, yoksa kaydedilmez.]=]
L[ [=[DogTag-formatted string to use for the range display (only available if LibDogTag is being used)

Type /dogtag for a list of available tags]=] ] = [=[Menzil göstergesi için kullanılacak DogTag biçimli metin (yalnızca LibDogTag kullanılıyorsa)

Kullanılabilir etiketlerin listesi için /dogtag yazın]=]
L[ [=[DogTag-formatted string to use for the right side of the bar.

Type /dogtag for a list of available tags.

Remember to press Accept after filling out this box or it will not save.]=] ] = [=[Çubuğun sağ tarafı için kullanılacak DogTag biçimli metin.

Kullanılabilir etiketlerin listesi için /dogtag yazın.

Bu kutuyu doldurduktan sonra Kabul'e basmayı unutmayın, yoksa kaydedilmez.]=]
L[ [=[DogTag-formatted string to use for the second text line (leave blank to revert to old behavior)

Type /dogtag for a list of available tags.

Remember to press Accept after filling out this box or it will not save.]=] ] = [=[İkinci yazı satırı için kullanılacak DogTag biçimli metin (eski davranışa dönmek için boş bırakın)

Kullanılabilir etiketlerin listesi için /dogtag yazın.

Bu kutuyu doldurduktan sonra Kabul'e basmayı unutmayın, yoksa kaydedilmez.]=]
L[ [=[DogTag-formatted string to use for the third text line (leave blank to revert to old behavior)

Type /dogtag for a list of available tags.

Remember to press Accept after filling out this box or it will not save.]=] ] = [=[Üçüncü yazı satırı için kullanılacak DogTag biçimli metin (eski davranışa dönmek için boş bırakın)

Kullanılabilir etiketlerin listesi için /dogtag yazın.

Bu kutuyu doldurduktan sonra Kabul'e basmayı unutmayın, yoksa kaydedilmez.]=]
L[ [=[DogTag-formatted string to use for the top text line (leave blank to revert to old behavior)

Type /dogtag for a list of available tags.

Remember to press Accept after filling out this box or it will not save.]=] ] = [=[Üst yazı satırı için kullanılacak DogTag biçimli metin (eski davranışa dönmek için boş bırakın)

Kullanılabilir etiketlerin listesi için /dogtag yazın.

Bu kutuyu doldurduktan sonra Kabul'e basmayı unutmayın, yoksa kaydedilmez.]=]
L["Don't show"] = "Gösterme"
L["Draw Elite Icon On Top"] = "Elit Simgesini Üstte Çiz"
L["Draw PVP Icon on top"] = "PvP Simgesini üstte çiz"
L["Draw Raid Icon On Top"] = "Baskın Simgesini Üstte Çiz"
L["Duplicate me"] = "Beni çoğalt"
L["Edit Marker"] = "İşaretçiyi Düzenle"
L["Elite Icon Scale"] = "Elit Simge Ölçeği"
L["Elite Icon X Offset"] = "Elit Simge X Kayması"
L["Elite Icon Y Offset"] = "Elit Simge Y Kayması"
L["Empower stage label display"] = "Güçlendirme aşaması etiketi gösterimi"
L["Enable/disable debug messages"] = "Hata ayıklama mesajlarını aç/kapat"
L["Enable/disable IceHUD"] = "IceHUD'u etkinleştir/devre dışı bırak"
L["Enable/disable module"] = "Modülü etkinleştir/devre dışı bırak"
L["Enabled"] = "Etkin"
L["Energy Ticker Alpha"] = "Enerji Tiki Saydamlığı"
L[ [=[Enter which unit that this bar should be monitoring the health of (e.g.: focustarget, pettarget, etc.)

Remember to press ENTER after filling out this box with the name you want or it will not save.]=] ] = [=[Bu çubuğun canını izleyeceği birimi girin (örn.: focustarget, pettarget vb.)

Bu kutuyu istediğiniz adla doldurduktan sonra ENTER tuşuna basmayı unutmayın, yoksa kaydedilmez.]=]
L[ [=[Enter which unit that this bar should be monitoring the mana of (e.g.: focustarget, pettarget, etc.)

Remember to press ENTER after filling out this box with the name you want or it will not save.]=] ] = [=[Bu çubuğun manasını izleyeceği birimi girin (örn.: focustarget, pettarget vb.)

Bu kutuyu istediğiniz adla doldurduktan sonra ENTER tuşuna basmayı unutmayın, yoksa kaydedilmez.]=]
L["Error: IceHUD database not loaded correctly.  Please exit out of WoW and delete the database file (IceHUD.lua) found in: \\World of Warcraft\\WTF\\Account\\<Account Name>>\\SavedVariables\\"] = "Hata: IceHUD veritabanı doğru yüklenemedi. Lütfen WoW'dan çık ve şu konumdaki veritabanı dosyasını (IceHUD.lua) sil: \\World of Warcraft\\WTF\\Account\\<Hesap Adı>>\\SavedVariables\\"
L["Exact match only"] = "Yalnızca tam eşleşme"
L["Export profile"] = "Profili dışa aktar"
L["Exports your active profile to something you can copy and paste to another user or use on another account."] = "Etkin profilini başka bir kullanıcıya veya hesapta kopyalayıp yapıştırabileceğin bir biçime aktarır."
L["Failed"] = "Başarısız"
L["FAQs"] = "SSS"
L["Flash bar below Low Threshold"] = "Düşük Eşiğin altında çubuğu çaktır"
L["Flash Instant Spells"] = "Anlık Büyüleri Çaktır"
L["Flash on Spell Failures"] = "Büyü Başarısızlıklarında Çaktır"
L["Flash when ready"] = "Hazır olunca çaktır"
L["Flashes the bar when it is below the Low Threshold specified above"] = "Çubuğu, yukarıda belirtilen Düşük Eşiğin altına düştüğünde çaktırır"
L["Font"] = "Yazı Tipi"
L["Font Size"] = "Yazı Boyutu"
L["Force hide cooldown numbers"] = "Bekleme sayılarını zorla gizle"
L["Force Text Justification"] = "Metin Hizalamasını Zorla"
L["Friendly OOC alpha"] = "Dost savaş dışı saydamlığı"
L["Gap"] = "Boşluk"
L["Gap between Upper and Lower text vertically"] = "Üst ve Alt metin arasındaki dikey boşluk"
L["General Settings"] = "Genel Ayarlar"
L["Grow direction"] = "Büyüme yönü"
L["Height"] = "Yükseklik"
L["Hide Blizzard Buffs"] = "Blizzard Güçlendirmelerini Gizle"
L["Hide Blizzard Frame"] = "Blizzard Çerçevesini Gizle"
L["Hide Blizzard Party"] = "Blizzard Partisini Gizle"
L["Hide default mirror bar"] = "Varsayılan ayna çubuğunu gizle"
L["Hide during cataloging"] = "Kataloglama sırasında gizle"
L["Hide during pet battles"] = "Evcil hayvan savaşları sırasında gizle"
L["Hide during shell game"] = "Kabuk oyunu sırasında gizle"
L["Hide in barbershops"] = "Berber dükkânlarında gizle"
L[ [=[Hides Blizzard Arcane Charges frame and disables all events related to it.

NOTE: Blizzard attaches the arcane charges UI to the player's unitframe, so if you have that hidden in PlayerHealth, then this won't do anything.]=] ] = [=[Blizzard Arcane Charges penceresini gizler ve onunla ilgili tüm olayları kapatır.

NOT: Blizzard arcane charges arayüzünü oyuncu birim çerçevesine bağlar; onu PlayerHealth'te gizlediyseniz bu bir şey yapmaz.]=]
L["Hides Blizzard Focus frame and disables all events related to it"] = "Blizzard Odak çerçevesini gizler ve onunla ilgili tüm olayları devre dışı bırakır"
L[ [=[Hides Blizzard frame and disables all events related to it.

NOTE: Blizzard attaches this UI to the player's unitframe, so if you have that hidden in PlayerHealth, then this won't do anything.]=] ] = [=[Blizzard penceresini gizler ve onunla ilgili tüm olayları kapatır.

NOT: Blizzard bu arayüzü oyuncu birim çerçevesine bağlar; onu PlayerHealth'te gizlediyseniz bu bir şey yapmaz.]=]
L[ [=[Hides Blizzard Harmony Power frame and disables all events related to it.

NOTE: Blizzard attaches the harmony power UI to the player's unitframe, so if you have that hidden in PlayerHealth, then this won't do anything.]=] ] = [=[Blizzard Harmony Power penceresini gizler ve onunla ilgili tüm olayları kapatır.

NOT: Blizzard harmony power arayüzünü oyuncu birim çerçevesine bağlar; onu PlayerHealth'te gizlediyseniz bu bir şey yapmaz.]=]
L[ [=[Hides Blizzard Holy Power frame and disables all events related to it.

NOTE: Blizzard attaches the holy power UI to the player's unitframe, so if you have that hidden in PlayerHealth, then this won't do anything.]=] ] = [=[Blizzard Holy Power penceresini gizler ve onunla ilgili tüm olayları kapatır.

NOT: Blizzard holy power arayüzünü oyuncu birim çerçevesine bağlar; onu PlayerHealth'te gizlediyseniz bu bir şey yapmaz.]=]
L["Hides Blizzard Player frame and disables all events related to it"] = "Blizzard Oyuncu çerçevesini gizler ve onunla ilgili tüm olayları devre dışı bırakır"
L["Hides Blizzard Rune frame and disables all events related to it"] = "Blizzard Rün çerçevesini gizler ve onunla ilgili tüm olayları devre dışı bırakır"
L[ [=[Hides Blizzard Shadow Orb frame and disables all events related to it.

NOTE: Blizzard attaches the shadow orb UI to the player's unitframe, so if you have that hidden in PlayerHealth, then this won't do anything.]=] ] = [=[Blizzard Shadow Orb penceresini gizler ve onunla ilgili tüm olayları kapatır.

NOT: Blizzard shadow orb arayüzünü oyuncu birim çerçevesine bağlar; onu PlayerHealth'te gizlediyseniz bu bir şey yapmaz.]=]
L[ [=[Hides Blizzard shard frame and disables all events related to it.

NOTE: Blizzard attaches the shard UI to the player's unitframe, so if you have that hidden in PlayerHealth, then this won't do anything.]=] ] = [=[Blizzard shard penceresini gizler ve onunla ilgili tüm olayları kapatır.

NOT: Blizzard shard arayüzünü oyuncu birim çerçevesine bağlar; onu PlayerHealth'te gizlediyseniz bu bir şey yapmaz.]=]
L["Hides Blizzard Target frame and disables all events related to it"] = "Blizzard Hedef çerçevesini gizler ve onunla ilgili tüm olayları devre dışı bırakır"
L["Hides Blizzard's default buffs frame and disables all events related to it"] = "Blizzard'ın varsayılan güçlendirme çerçevesini gizler ve onunla ilgili tüm olayları devre dışı bırakır"
L["Hides Blizzard's default party frame and disables all events related to them"] = "Blizzard'ın varsayılan parti çerçevesini gizler ve onlarla ilgili tüm olayları devre dışı bırakır"
L["Horizontal offset"] = "Yatay kayma"
L["Horizontal Position"] = "Yatay Konum"
L["Horizontal position"] = "Yatay konum"
L["Horizontal position (for you dual screen freaks)"] = "Yatay konum (çift ekran delileri için)"
L["How combo points should grow. If layout is Horizontal, reversing will cause them to grow right to left. If layout is Vertical, reversing will cause them to grow bottom to top."] = "Kombo puanlarının nasıl büyüyeceği. Yerleşim Yatay ise, ters çevirmek sağdan sola büyümelerine yol açar. Yerleşim Dikey ise, ters çevirmek aşağıdan yukarı büyümelerine yol açar."
L["How far horizontally the buff frame should be offset from the anchor"] = "Güçlendirme çerçevesinin bağlantı noktasından yatay olarak ne kadar kaydırılacağı"
L["How far horizontally the debuff frame should be offset from the anchor"] = "Zayıflatma çerçevesinin bağlantı noktasından yatay olarak ne kadar kaydırılacağı"
L["How far horizontally the weapon enchant frame should be offset from the anchor"] = "Silah büyüsü çerçevesinin bağlantı noktasından yatay olarak ne kadar kaydırılacağı"
L["How far to offset the numeric display left or right."] = "Sayısal gösterimin sola veya sağa ne kadar kaydırılacağı."
L["How far to offset the numeric display up or down."] = "Sayısal gösterimin yukarı veya aşağı ne kadar kaydırılacağı."
L["How far to push the elite icon right or left"] = "Elit simgesinin sağa veya sola ne kadar itileceği"
L["How far to push the elite icon up or down"] = "Elit simgesinin yukarı veya aşağı ne kadar itileceği"
L["How far to push the raid icon right or left"] = "Baskın simgesinin sağa veya sola ne kadar itileceği"
L["How far to push the raid icon up or down"] = "Baskın simgesinin yukarı veya aşağı ne kadar itileceği"
L["How far vertically the buff frame should be offset from the anchor"] = "Güçlendirme çerçevesinin bağlantı noktasından dikey olarak ne kadar kaydırılacağı"
L["How far vertically the debuff frame should be offset from the anchor"] = "Zayıflatma çerçevesinin bağlantı noktasından dikey olarak ne kadar kaydırılacağı"
L["How far vertically the weapon enchant frame should be offset from the anchor"] = "Silah büyüsü çerçevesinin bağlantı noktasından dikey olarak ne kadar kaydırılacağı"
L["How long the animation should take to play"] = "Animasyonun oynatılmasının ne kadar süreceği"
L["How many buffs/debuffs is shown on each row"] = "Her satırda kaç güçlendirme/zayıflatma gösterileceği"
L[ [=[How many total applications of this buff/debuff can be applied. For example, only 5 sunders can ever be on a target, so this would be set to 5 for tracking Sunder.

Remember to press ENTER after filling out this box with the name you want or it will not save.]=] ] = [=[Bu güçlendirme/zayıflatmadan toplam kaç yığın uygulanabileceği. Örneğin bir hedefte en fazla 5 sunder olabilir, bu yüzden Sunder takibi için bu 5 olmalıdır.

Bu kutuyu doldurduktan sonra ENTER tuşuna basmayı unutmayın, yoksa kaydedilmez.]=]
L["How much space should be between each buff or debuff icon."] = "Her güçlendirme veya zayıflatma simgesi arasında ne kadar boşluk olacağı."
L["How much to offset the leader icon from the bar horizontally"] = "Lider simgesinin çubuktan yatay olarak ne kadar kaydırılacağı"
L["How much to offset the leader icon from the bar vertically"] = "Lider simgesinin çubuktan dikey olarak ne kadar kaydırılacağı"
L["How much to offset the loot master icon from the bar horizontally"] = "Ganimet sorumlusu simgesinin çubuktan yatay olarak ne kadar kaydırılacağı"
L["How much to offset the loot master icon from the bar vertically"] = "Ganimet sorumlusu simgesinin çubuktan dikey olarak ne kadar kaydırılacağı"
L["How much to offset the Party Role icon from the bar horizontally"] = "Parti Rolü simgesinin çubuktan yatay olarak ne kadar kaydırılacağı"
L["How much to offset the Party Role icon from the bar vertically"] = "Parti Rolü simgesinin çubuktan dikey olarak ne kadar kaydırılacağı"
L["How much to offset the PvP icon from the bar horizontally"] = "PvP simgesinin çubuktan yatay olarak ne kadar kaydırılacağı"
L["How much to offset the PvP icon from the bar vertically"] = "PvP simgesinin çubuktan dikey olarak ne kadar kaydırılacağı"
L["How much to offset the status icon (resting/combat) from the bar horizontally"] = "Durum simgesinin (dinlenme/savaş) çubuktan yatay olarak ne kadar kaydırılacağı"
L["How much to offset the status icon (resting/combat) from the bar vertically"] = "Durum simgesinin (dinlenme/savaş) çubuktan dikey olarak ne kadar kaydırılacağı"
L["How much to scale the elite icon"] = "Elit simgesinin ne kadar ölçekleneceği"
L["How much to scale the leader icon"] = "Lider simgesinin ne kadar ölçekleneceği"
L["How much to scale the loot master icon"] = "Ganimet sorumlusu simgesinin ne kadar ölçekleneceği"
L["How much to scale the Party Role icon"] = "Parti Rolü simgesinin ne kadar ölçekleneceği"
L["How much to scale the PvP icon"] = "PvP simgesinin ne kadar ölçekleneceği"
L["How much to scale the raid icon"] = "Baskın simgesinin ne kadar ölçekleneceği"
L["How much to scale the status icon"] = "Durum simgesinin ne kadar ölçekleneceği"
L["How points should grow. If orientation is Horizontal, reversing will cause them to grow right to left. If orientation is Vertical, reversing will cause them to grow bottom to top."] = "Noktaların nasıl büyüyeceği. Yönelim Yatay ise, ters çevirmek sağdan sola büyümelerine yol açar. Yönelim Dikey ise, ters çevirmek aşağıdan yukarı büyümelerine yol açar."
L["How the graphical combo points should be displayed"] = "Grafik kombo puanlarının nasıl gösterileceği"
L["How the graphical counter should be displayed"] = "Grafik sayacın nasıl gösterileceği"
L["How to display the buff timer next to the name of the buff on the bar"] = "Güçlendirme zamanlayıcısının çubuktaki güçlendirme adının yanında nasıl gösterileceği"
L["How to display the stage of an empowered spell"] = "Güçlenmiş bir büyünün aşamasının nasıl gösterileceği"
L["HUD scale"] = "HUD ölçeği"
L["IceHUD"] = true
L["IceHUD Bar Background Blend mode"] = "IceHUD Çubuk Arka Planı Karışım modu"
L["IceHUD Bar Blend mode"] = "IceHUD Çubuk Karışım modu"
L["IceHUD Bar Texture"] = "IceHUD Çubuk Dokusu"
L["IceHUD Font"] = "IceHUD Yazı Tipi"
L["Icon config mode"] = "Simge yapılandırma modu"
L["Icon gap"] = "Simge boşluğu"
L["Icon set"] = "Simge seti"
L["Icon Settings"] = "Simge Ayarları"
L["Icon size"] = "Simge boyutu"
L["Icon size for auras that were applied by you, the player"] = "Oyuncu olan senin uyguladığın auraların simge boyutu"
L["If checked, the bar will only be displayed (according to the 'Display mode' rules) when the Unit to Track exists (e.g. if set to Target and you're targeting something)."] = "İşaretliyse, çubuk yalnızca İzlenecek Birim mevcut olduğunda ('Gösterim modu' kurallarına göre) gösterilir (örn. Hedef seçiliyse ve bir şeyi hedefliyorsan)."
L["If the selected ability has a max range or only works on friendly units, this will ignore that check. Meaning you can use a CD bar for buff spells and it will display when you have an enemy targeted."] = "Seçilen yeteneğin azami menzili varsa veya yalnızca dost birimlerde çalışıyorsa, bu kontrol yok sayılır. Yani güçlendirme büyüleri için bir BK çubuğu kullanabilir ve bir düşman hedeflendiğinde de gösterebilirsin."
L["If this is checked, then a health value of 1100 will display as 1.1k, otherwise it shows the number"] = "İşaretliyse, 1100 can değeri 1,1k olarak gösterilir, aksi takdirde sayı olduğu gibi gösterilir"
L[ [=[If this is checked, then a health value of 1100 will display as 1.1k, otherwise it shows the number

Note: this only applies if you are NOT using DogTag]=] ] = [=[İşaretliyse 1100 can değeri 1.1k olarak gösterilir, değilse sayının kendisi gösterilir

Not: bu yalnızca DogTag KULLANMIYORSANIZ geçerlidir]=]
L["If this is checked, then the bar uses different colors depending on how many RtB buffs you have"] = "İşaretliyse, çubuk sahip olduğun RtB güçlendirme sayısına göre farklı renkler kullanır"
L["If this is checked, then the buff name must be entered exactly as the full buff name. Otherwise, you can use only a portion of the name such as 'Sting' to track all stings."] = "İşaretliyse, güçlendirme adı tam güçlendirme adı olarak girilmelidir. Aksi halde 'Sting' gibi adın yalnızca bir kısmını kullanarak tüm sting'leri izleyebilirsin."
L["If this is checked, then the counter will use your 'out of target' alpha when targeting someone who is friendly."] = "İşaretliyse, sayaç dost birini hedeflerken 'hedef dışı' saydamlığını kullanır."
L["If this is checked, then the RtB buff time shows as a percent of the maximum attainable (taking set bonuses and talents into account). Otherwise, the bar always goes from full to empty when applying RtB no matter the duration."] = "İşaretliyse, RtB güçlendirme süresi ulaşılabilecek azami sürenin yüzdesi olarak gösterilir (set bonusları ve yetenekler hesaba katılır). Aksi halde süreye bakılmaksızın RtB uygulandığında çubuk her zaman doludan boşa gider."
L["If this is checked, then the SnD buff time shows as a percent of the maximum attainable (taking set bonuses and talents into account). Otherwise, the bar always goes from full to empty when applying SnD no matter the duration."] = "İşaretliyse, SnD güçlendirme süresi ulaşılabilecek azami sürenin yüzdesi olarak gösterilir (set bonusları ve yetenekler hesaba katılır). Aksi halde süreye bakılmaksızın SnD uygulandığında çubuk her zaman doludan boşa gider."
L["If this is checked, then whenever the counter is maxed out it will gently pulsate to let you know it's ready to be used."] = "İşaretliyse, sayaç azami değere ulaştığında kullanıma hazır olduğunu bildirmek için hafifçe nabız atar."
L["If this is disabled, then targeting a friendly will use the 'Alpha out of combat' setting instead of 'Alpha OOC and Target'."] = "Bu devre dışıysa, dost birini hedeflemek 'Savaş dışında ve hedef varken saydamlık' yerine 'Savaş dışında saydamlık' ayarını kullanır."
L["If this is set, the numeric value of the current rune count will show on top of the runes display."] = "Bu ayarlıysa, mevcut rune sayısının sayısal değeri rune gösteriminin üzerinde görünür."
L["If you are using the 'class color bar' setting above, then enabling this will color NPC's by their hostility toward you since NPC class isn't very helpful or applicable information."] = "Yukarıdaki 'sınıf rengi çubuk' ayarını kullanıyorsan, bunu etkinleştirmek NPC'leri sana karşı düşmanlıklarına göre renklendirir; çünkü NPC sınıfı pek yararlı veya uygulanabilir bir bilgi değildir."
L["If you have game default font selected, this option has no effect"] = "Oyunun varsayılan yazı tipi seçiliyse bu seçeneğin etkisi yoktur"
L["If your class power is not full (or not empty in the case of Holy Power) then the module will always be displayed on your screen using the In Combat alpha setting. Otherwise it will fade to the OOC alpha when you leave combat."] = "Sınıf gücün dolu değilse (veya Kutsal Güç'te boş değilse) modül, Savaşta saydamlık ayarıyla ekranında her zaman görüntülenir. Aksi halde savaştan çıktığında savaş dışı saydamlığa soluklaşır."
L["Ignore range"] = "Menzili yok say"
L["Import profile"] = "Profili içe aktar"
L["Imports a profile as exported from another user's IceHUD."] = "Başka bir kullanıcının IceHUD'ından dışa aktarılmış bir profili içe aktarır."
L["Inactive mode"] = "Etkin olmayan mod"
L["Incoming heal bar alpha"] = "Gelen şifa çubuğu saydamlığı"
L["Interrupted"] = "Kesildi"
L["Invert bar"] = "Çubuğu ters çevir"
L["Item to track"] = "İzlenecek eşya"
L["Lacerate Count Font Size"] = "Yırtma Sayısı Yazı Boyutu"
L["Lacerate gap"] = "Yırtma boşluğu"
L["Lag Indicator alpha"] = "Gecikme Göstergesi saydamlığı"
L["Lag indicator alpha (0 is disabled)"] = "Gecikme göstergesi saydamlığı (0 devre dışı)"
L["Layout"] = "Düzen"
L["Leader icon"] = "Lider simgesi"
L["Leader Icon Horizontal Offset"] = "Lider Simgesi Yatay Kayması"
L["Leader Icon Scale"] = "Lider Simgesi Ölçeği"
L["Leader Icon Vertical Offset"] = "Lider Simgesi Dikey Kayması"
L["Left"] = "Sol"
L["Left Tag"] = "Sol Etiket"
L["Line 1 justification"] = "1. satır hizalaması"
L["Line 1 tag"] = "1. satır etiketi"
L["Line 2 justification"] = "2. satır hizalaması"
L["Line 2 tag"] = "2. satır etiketi"
L["Line 3 justification"] = "3. satır hizalaması"
L["Line 3 tag"] = "3. satır etiketi"
L["Line 4 justification"] = "4. satır hizalaması"
L["Line 4 tag"] = "4. satır etiketi"
L["Lock all icons to 100% alpha"] = "Tüm simgeleri %100 saydamlığa kilitle"
L["Lock Bar Text Alpha"] = "Çubuk Metni Saydamlığını Kilitle"
L["Lock Lower Text Alpha"] = "Alt Metin Saydamlığını Kilitle"
L["Lock raid icon to 100% alpha"] = "Baskın simgesini %100 saydamlığa kilitle"
L["Lock Upper Text Alpha"] = "Üst Metin Saydamlığını Kilitle"
L["Locks lower text alpha to 100%"] = "Alt metin saydamlığını %100'e kilitler"
L["Locks text alpha to 100%"] = "Metin saydamlığını %100'e kilitler"
L["Locks upper text alpha to 100%"] = "Üst metin saydamlığını %100'e kilitler"
L["Look and Feel"] = "Görünüm"
L["Loot Master icon"] = "Ganimet Sorumlusu simgesi"
L["Loot Master Icon Horizontal Offset"] = "Ganimet Sorumlusu Simgesi Yatay Kayması"
L["Loot Master Icon Scale"] = "Ganimet Sorumlusu Simgesi Ölçeği"
L["Loot Master Icon Vertical Offset"] = "Ganimet Sorumlusu Simgesi Dikey Kayması"
L["Low Threshold"] = "Düşük Eşik"
L["Low Threshold color"] = "Düşük Eşik rengi"
L["Lower Text"] = "Alt Metin"
L["Lower Text Color"] = "Alt Metin Rengi"
L["Lower text visible"] = "Alt metin görünür"
L["Maelstrom Count Font Size"] = "Girdap Sayısı Yazı Boyutu"
L["Maelstrom gap"] = "Girdap boşluğu"
L["Main Hand"] = "Ana El"
L["Make this bar wider or thinner than others"] = "Bu çubuğu diğerlerinden daha geniş veya ince yap"
L["Makes all modules visible so you can see where they're placed and find any that are overlapping."] = "Yerleşimlerini görebilmen ve üst üste binenleri bulabilmen için tüm modülleri görünür yapar."
L["Marker Settings"] = "İşaretçi Ayarları"
L["Maximum applications"] = "Azami uygulama"
L["Maximum duration"] = "Azami süre"
L[ [=[Maximum Duration for the bar (the bar will remained full if it has longer than maximum remaining).  Leave 0 for spell duration.

Remember to press ENTER after filling out this box with the name you want or it will not save.]=] ] = [=[Çubuğun en uzun süresi (kalan süre bundan uzunsa çubuk dolu kalır). Büyü süresi için 0 bırakın.

Bu kutuyu doldurduktan sonra ENTER tuşuna basmayı unutmayın, yoksa kaydedilmez.]=]
L["Minimum stacks to show"] = "Gösterilecek asgari yığın"
L["Module color configuration options"] = "Modül renk yapılandırma seçenekleri"
L["Module configuration options"] = "Modül yapılandırma seçenekleri"
L["Module options"] = "Modül seçenekleri"
L["Module Settings"] = "Modül Ayarları"
L["Module type:"] = "Modül türü:"
L["Mouse settings"] = "Fare ayarları"
L["Mouseover"] = "Fare üzerine gelince"
L["Mouseover for buffs"] = "Güçlendirmeler için fare üzerine gelince"
L["Mouseover for target"] = "Hedef için fare üzerine gelince"
L["No decoration"] = "Süsleme yok"
L["No form"] = "Form yok"
L["Number of updates per second. The higher this number is, the smoother bars will animate. However, higher settings will also use more CPU, so balance it to your liking. 30 is the recommended setting."] = "Saniyedeki güncelleme sayısı. Bu sayı ne kadar yüksekse çubuklar o kadar akıcı canlanır. Ancak yüksek ayarlar daha fazla CPU kullanır, bu yüzden zevkine göre dengele. Önerilen ayar 30'dur."
L["Numeric horizontal offset"] = "Sayısal yatay kayma"
L["Numeric vertical offset"] = "Sayısal dikey kayma"
L["Off Hand"] = "Yedek El"
L["Offset"] = "Kayma"
L["Offset of the bar"] = "Çubuğun kayması"
L["Offset of the text from the bar horizontally"] = "Metnin çubuktan yatay olarak kayması"
L["Offset of the text from the bar vertically (negative is farther below)"] = "Metnin çubuktan dikey olarak kayması (eksi değer daha aşağıya demektir)"
L["Only if unit exists"] = "Yalnızca birim mevcutsa"
L["Only show buffs by me"] = "Yalnızca benim güçlendirmelerimi göster"
L["Only show debuffs by me"] = "Yalnızca benim zayıflatmalarımı göster"
L["Only show for my debuffs"] = "Yalnızca benim zayıflatmalarım için göster"
L["Only show if target uses mana"] = "Yalnızca hedef mana kullanıyorsa göster"
L["Only show in groups"] = "Yalnızca gruplarda göster"
L["Only show the bar when the number of applications of this buff or debuff exceeds this number"] = "Çubuğu yalnızca bu güçlendirme veya zayıflatmanın uygulama sayısı bu sayıya eşit veya fazla olduğunda göster"
L["Only show the threat bar if you are in a group or you have an active pet"] = "Tehdit çubuğunu yalnızca bir grupta olduğunda veya etkin bir evcil hayvanın olduğunda göster"
L["Only show with a target selected"] = "Yalnızca bir hedef seçiliyken göster"
L["Only track auras by me"] = "Yalnızca benim auralarımı izle"
L["Other"] = "Diğer"
L["Outline"] = "Anahat"
L["Override alpha when not full"] = "Tam değilken saydamlığı geçersiz kıl"
L["Override global texture"] = "Genel dokuyu geçersiz kıl"
L["Own buff size"] = "Kendi güçlendirme boyutu"
L["Own debuff size"] = "Kendi zayıflatma boyutu"
L["Party Role icon"] = "Parti Rolü simgesi"
L["Party Role Icon Horizontal Offset"] = "Parti Rolü Simgesi Yatay Kayması"
L["Party Role Icon Scale"] = "Parti Rolü Simgesi Ölçeği"
L["Party Role Icon Vertical Offset"] = "Parti Rolü Simgesi Dikey Kayması"
L["Position (percent)"] = "Konum (yüzde)"
L["Positioning Settings"] = "Konumlandırma Ayarları"
L["Potential RtB time bar alpha"] = "Olası RtB süre çubuğu saydamlığı"
L["Potential SnD time bar alpha"] = "Olası SnD süre çubuğu saydamlığı"
L["Predefined settings for different bars"] = "Farklı çubuklar için önceden tanımlanmış ayarlar"
L["Presets"] = "Ön Ayarlar"
L["Pulse when full"] = "Dolunca nabız at"
L["Push IceHUD modules to the foreground. Increase if other addons are covering IceHUD. Requires reload."] = "IceHUD modüllerini ön plana it. Diğer eklentiler IceHUD'u örtüyorsa artır. Yeniden yükleme gerektirir."
L["PvP icon"] = "PvP simgesi"
L["PvP Icon Horizontal Offset"] = "PvP Simgesi Yatay Kayması"
L["PvP Icon Scale"] = "PvP Simgesi Ölçeği"
L["PvP Icon Vertical Offset"] = "PvP Simgesi Dikey Kayması"
L["Raid icon"] = "Baskın simgesi"
L["Raid Icon Scale"] = "Baskın Simgesi Ölçeği"
L["Raid Icon X Offset"] = "Baskın Simgesi X Kayması"
L["Raid Icon Y Offset"] = "Baskın Simgesi Y Kayması"
L["Range string"] = "Menzil dizesi"
L["Ranged"] = "Menzilli"
L["Remove"] = "Kaldır"
L["Reset custom point placement"] = "Özel nokta yerleşimini sıfırla"
L["Resets all individual points to their default location."] = "Tüm tekil noktaları varsayılan konumlarına sıfırlar."
L["Respect lag tolerance"] = "Gecikme toleransına uy"
L["Reverse channeling"] = "Kanal büyüsünü ters çevir"
L["Reverse direction"] = "Yönü ters çevir"
L["Right"] = "Sağ"
L["Right Tag"] = "Sağ Etiket"
L["Rotate 90 degrees"] = "90 derece döndür"
L["Rune cooldown mode"] = "Rune bekleme modu"
L["Rune display mode"] = "Rune gösterim modu"
L["Rune gap"] = "Rune boşluğu"
L["Rune orientation"] = "Rune yönelimi"
L["Scale"] = "Ölçek"
L["Scale for non-mana users"] = "Mana kullanmayanlar için ölçek"
L["Scale of the bar"] = "Çubuğun ölçeği"
L["Scale of the element"] = "Öğenin ölçeği"
L["Scale to health"] = "Cana göre ölçekle"
L["Second place threat alpha"] = "İkinci sıradaki tehdit saydamlığı"
L["Select a custom module that you want to create here, then press the 'Create' button."] = "Burada oluşturmak istediğin özel modülü seç, sonra 'Oluştur' düğmesine bas."
L["Select which unit that this bar should be looking for buffs/debuffs on"] = "Bu çubuğun hangi birimde güçlendirme/zayıflatma arayacağını seç"
L["Self Color"] = "Kendi Rengi"
L["Self Display Mode"] = "Kendi Gösterim Modu"
L["Set the color of the TargetTarget bar if you are your target's target."] = "Hedefin hedefi sen olduğunda HedefinHedefi çubuğunun rengini ayarla."
L["Sets the height of this module."] = "Bu modülün yüksekliğini ayarlar."
L["Sets the width of this module if 'size to gap' is not set"] = "'Boşluğa göre boyutlandır' ayarlı değilse bu modülün genişliğini ayarlar"
L["Settings for bar transparencies"] = "Çubuk saydamlıkları için ayarlar"
L["Settings related to bars"] = "Çubuklarla ilgili ayarlar"
L["Settings related to icons"] = "Simgelerle ilgili ayarlar"
L["Settings related to positioning and alpha"] = "Konumlandırma ve saydamlıkla ilgili ayarlar"
L["Settings related to texts"] = "Metinlerle ilgili ayarlar"
L["Shadow"] = "Gölge"
L["Show absorbs"] = "Emilimleri göster"
L["Show Anima-charged points"] = "Anima yüklü noktaları göster"
L["Show Anticipation"] = "Beklenti'yi göster"
L["Show bar as % of maximum"] = "Çubuğu azami değerin %'si olarak göster"
L["Show buffs"] = "Güçlendirmeleri göster"
L["Show Charged points"] = "Yüklü noktaları göster"
L["Show combat status"] = "Savaş durumunu göster"
L["Show debuffs"] = "Zayıflatmaları göster"
L["Show default cast bar"] = "Varsayılan büyü çubuğunu göster"
L["Show during cast"] = "Büyü yaparken göster"
L["Show Elite Icon"] = "Elit Simgesini Göster"
L["Show graphical or numeric combo points"] = "Grafik veya sayısal kombo puanlarını göster"
L["Show graphical or numeric counts"] = "Grafik veya sayısal sayıları göster"
L["Show graphical or numeric lacerates"] = "Grafik veya sayısal yırtmaları göster"
L["Show graphical or numeric maelstroms"] = "Grafik veya sayısal girdapları göster"
L["Show graphical or numeric sunders"] = "Grafik veya sayısal zırh delmeleri göster"
L["Show in form"] = "Formdayken göster"
L["Show incoming heals"] = "Gelen şifaları göster"
L["Show leader icon"] = "Lider simgesini göster"
L["Show loot master icon"] = "Ganimet sorumlusu simgesini göster"
L["Show Minimap Icon"] = "Mini Harita Simgesini Göster"
L["Show Party Role icon"] = "Parti Rolü simgesini göster"
L["Show points stored by the Anticipation talent"] = "Beklenti yeteneğinin depoladığı puanları göster"
L["Show PvP icon"] = "PvP simgesini göster"
L["Show Raid Icon"] = "Baskın Simgesini Göster"
L["Show raid icon"] = "Baskın simgesini göster"
L["Show resting status"] = "Dinlenme durumunu göster"
L["Show rogue/cat energy ticker"] = "Düzenbaz/kedi enerji tikini göster"
L["Show scaled threat"] = "Ölçekli tehdidi göster"
L["Show second highest threat"] = "İkinci en yüksek tehdidi göster"
L["Show spell cast time"] = "Büyü yapma süresini göster"
L["Show spell rank"] = "Büyü rütbesini göster"
L["Show stacking debuffs"] = "Birikimli zayıflatmaları göster"
L["Show stacking debuffs in ToT info"] = "Birikimli zayıflatmaları HH bilgisinde göster"
L["Show status icon"] = "Durum simgesini göster"
L["Show tank name"] = "Tank adını göster"
L["Show the tooltip for this unit when the mouse is hovering over it."] = "Fare üzerine geldiğinde bu birimin ipucunu göster."
L["Show time remaining"] = "Kalan süreyi göster"
L["Show tooltip"] = "İpucunu göster"
L["Show weapon enchants"] = "Silah büyülerini göster"
L["Show when not full"] = "Tam değilken göster"
L["Show when zero"] = "Sıfırken göster"
L["Show with no target"] = "Hedef yokken göster"
L["Shows a flash behind each holy rune when it becomes available."] = "Her kutsal rune kullanılabilir olduğunda arkasında bir flaş gösterir."
L["Shows a flash behind each shard when it becomes available."] = "Her parça kullanılabilir olduğunda arkasında bir flaş gösterir."
L["Shows the name of the threat holder colorized by his or her role"] = "Tehdit sahibinin adını rolüne göre renklendirilmiş olarak gösterir"
L["Side"] = "Yan"
L["Side of the HUD where the bar appears"] = "Çubuğun göründüğü HUD tarafı"
L["Since the last time you updated IceHUD, many significant CPU and memory optimizations have been made. If bar animation looks jumpy to you, open the /icehud configuration page and raise the 'Update Period' slider. This will cause higher CPU usage but will look nicer. Enjoy IceHUD!"] = "IceHUD'u en son güncellediğinden beri birçok önemli CPU ve bellek iyileştirmesi yapıldı. Çubuk animasyonu sana ürkek görünüyorsa /icehud yapılandırma sayfasını aç ve 'Güncelleme Aralığı' kaydırıcısını yükselt. Bu daha yüksek CPU kullanımına yol açar ama daha güzel görünür. IceHUD'un keyfini çıkar!"
L["Size and Placement"] = "Boyut ve Yerleşim"
L["Size to gap"] = "Boşluğa göre boyutlandır"
L["Sort by expiration"] = "Bitiş süresine göre sırala"
L["Space between bars on the same side"] = "Aynı taraftaki çubuklar arasındaki boşluk"
L["Space between buffs"] = "Güçlendirmeler arasındaki boşluk"
L["Spacing between each combo point (only works for graphical mode)"] = "Her kombo puanı arasındaki aralık (yalnızca grafik modda çalışır)"
L["Spacing between each icon (only works for graphical mode)"] = "Her simge arasındaki aralık (yalnızca grafik modda çalışır)"
L["Spacing between each lacerate count (only works for graphical mode)"] = "Her yırtma sayısı arasındaki aralık (yalnızca grafik modda çalışır)"
L["Spacing between each maelstrom point (only works for graphical mode)"] = "Her girdap noktası arasındaki aralık (yalnızca grafik modda çalışır)"
L["Spacing between each rune (only works for graphical mode)"] = "Her rune arasındaki aralık (yalnızca grafik modda çalışır)"
L["Spacing between each sunder count (only works for graphical mode)"] = "Her zırh delme sayısı arasındaki aralık (yalnızca grafik modda çalışır)"
L["Spacing between each totem (only works for graphical mode)"] = "Her totem arasındaki aralık (yalnızca grafik modda çalışır)"
L["Spell cast text visible"] = "Büyü yapma metni görünür"
L["Spell to track"] = "İzlenecek büyü"
L["Stack Font Size"] = "Yığın Yazı Boyutu"
L["Stage %d"] = "Aşama %d"
L["Status icon"] = "Durum simgesi"
L["Status Icon Horizontal Offset"] = "Durum Simgesi Yatay Kayması"
L["Status Icon Scale"] = "Durum Simgesi Ölçeği"
L["Status Icon Vertical Offset"] = "Durum Simgesi Dikey Kayması"
L["Sunder Count Font Size"] = "Zırh Delme Sayısı Yazı Boyutu"
L["Sunder gap"] = "Zırh delme boşluğu"
L["Text appearance"] = "Metin görünümü"
L["Text Horizontal Offset"] = "Metin Yatay Kayması"
L["Text Settings"] = "Metin Ayarları"
L["Text Vertical Gap"] = "Metin Dikey Boşluğu"
L["Text Vertical Offset"] = "Metin Dikey Kayması"
L["Texture"] = "Doku"
L["The alpha value for the second-place threat bar to be (this is multiplied by the bar's alpha so it's always proportionate)"] = "İkinci sıradaki tehdit çubuğunun saydamlık değeri (bu, çubuğun saydamlığıyla çarpılır, bu yüzden her zaman orantılıdır)"
L["The color for this bar"] = "Bu çubuğun rengi"
L["The color for this counter"] = "Bu sayacın rengi"
L["The color this marker should be."] = "Bu işaretçinin rengi."
L["The height of the marker on the bar."] = "İşaretçinin çubuk üzerindeki yüksekliği."
L[ [=[The lower text to display under this bar (accepts LibDogTag formatting)

See http://www.wowace.com/wiki/LibDogTag-2.0/ or type /dogtag for tag info.

Remember to press ENTER after filling out this box or it will not save.]=] ] = [=[Bu çubuğun altında gösterilecek alt yazı (DogTag biçimini kabul eder)

Etiket bilgisi için /dogtag yazın.

Bu kutuyu doldurduktan sonra Kabul düğmesine basmayı unutmayın, yoksa kaydedilmez.]=]
L[ [=[The lower text to display under this bar.

NOTE: this text block does NOT support DogTags.

Remember to press ENTER/Accept after filling out this box or it will not save.]=] ] = [=[Bu çubuğun altında gösterilecek alt yazı.

NOT: bu yazı bloğu DogTag DESTEKLEMEZ.

Bu kutuyu doldurduktan sonra Kabul düğmesine basmayı unutmayın, yoksa kaydedilmez.]=]
L["The minimum color for this counter (only used if Change Color is enabled)"] = "Bu sayacın asgari rengi (yalnızca Rengi Değiştir etkinse kullanılır)"
L[ [=[The name of this bar (must be unique!).

Remember to press ENTER after filling out this box with the name you want or it will not save.]=] ] = [=[Bu çubuğun adı (benzersiz olmalı!).

Bu kutuyu istediğiniz adla doldurduktan sonra ENTER tuşuna basmayı unutmayın, yoksa kaydedilmez.]=]
L[ [=[The name of this counter (must be unique!). 

Remember to press ENTER after filling out this box with the name you want or it will not save.]=] ] = [=[Bu sayacın adı (benzersiz olmalı!).

Bu kutuyu istediğiniz adla doldurduktan sonra ENTER tuşuna basmayı unutmayın, yoksa kaydedilmez.]=]
L["The point on the PlayerInfo frame that the weapon enchant frame gets connected to"] = "Silah büyüsü çerçevesinin bağlandığı OyuncuBilgisi çerçevesindeki nokta"
L["The point on the TargetInfo frame that the buff frame gets connected to"] = "Güçlendirme çerçevesinin bağlandığı HedefBilgisi çerçevesindeki nokta"
L["The point on the TargetInfo frame that the debuff frame gets connected to"] = "Zayıflatma çerçevesinin bağlandığı HedefBilgisi çerçevesindeki nokta"
L["The type of thing to track the cooldown of"] = "Beklemesi izlenecek şeyin türü"
L[ [=[The upper text to display under this bar (accepts LibDogTag formatting)

See http://www.wowace.com/wiki/LibDogTag-2.0/ or type /dogtag for tag info.

Remember to press ENTER after filling out this box or it will not save.]=] ] = [=[Bu çubuğun altında gösterilecek üst yazı (DogTag biçimini kabul eder)

Etiket bilgisi için /dogtag yazın.

Bu kutuyu doldurduktan sonra Kabul düğmesine basmayı unutmayın, yoksa kaydedilmez.]=]
L[ [=[The upper text to display under this bar.

NOTE: this text block does NOT support DogTags.

Remember to press ENTER/Accept after filling out this box or it will not save.]=] ] = [=[Bu çubuğun altında gösterilecek üst yazı.

NOT: bu yazı bloğu DogTag DESTEKLEMEZ.

Bu kutuyu doldurduktan sonra Kabul düğmesine basmayı unutmayın, yoksa kaydedilmez.]=]
L["Thick outline"] = "Kalın anahat"
L[ [=[This controls how all non-DogTag text on all modules appears.

NOTE: Requires a UI reload to take effect.]=] ] = [=[Bu, tüm modüllerdeki DogTag olmayan tüm yazıların nasıl görüneceğini denetler.

NOT: Etkili olması için arayüz yenilemesi gerekir.]=]
L["This controls what happens to runes that are inactive. Darkened means they are visible but colored black, Hidden means they are not displayed."] = "Bu, etkin olmayan runelere ne olacağını belirler. Karartılmış, görünür ama siyaha boyalı demektir; Gizli, gösterilmedikleri anlamına gelir."
L["This is a per-pixel horizontal adjustment. You should probably use the 'offset' setting above as it is designed to snap bars together. This may be used in the case of a horizontal bar needing to be positioned outside the normal bar locations."] = "Bu, piksel başına yatay bir ayardır. Muhtemelen çubukları birbirine oturtmak için tasarlanmış yukarıdaki 'kayma' ayarını kullanmalısın. Bu, yatay bir çubuğun normal çubuk konumlarının dışına yerleştirilmesi gerektiğinde kullanılabilir."
L["This option requires the UI to be reloaded. Do you wish to reload it now?"] = "Bu seçenek arayüzün yeniden yüklenmesini gerektirir. Şimdi yeniden yüklemek ister misin?"
L["This sets the alignment for the text on line 1"] = "Bu, 1. satırdaki metnin hizalamasını ayarlar"
L["This sets the alignment for the text on line 2"] = "Bu, 2. satırdaki metnin hizalamasını ayarlar"
L["This sets the alignment for the text on line 3"] = "Bu, 3. satırdaki metnin hizalamasını ayarlar"
L["This sets the alignment for the text on line 4"] = "Bu, 4. satırdaki metnin hizalamasını ayarlar"
L["This sets the alignment for the text on this bar"] = "Bu, bu çubuktaki metnin hizalamasını ayarlar"
L[ [=[This specifies at what point along the bar this marker should be displayed. Remember to press ENTER when you are done typing.

Example: if you wanted a marker at 40 energy and you have 100 total energy, then this would be 40. If you want it at 40 energy and you have 120 total energy, then this would be 33.]=] ] = [=[Bu işaretin çubuk üzerinde hangi noktada gösterileceğini belirtir. Yazmayı bitirince ENTER tuşuna basmayı unutmayın.

Örnek: 100 toplam enerjiniz varken 40 enerjide işaret istiyorsanız bu 40 olur. 120 toplam enerjiniz varken 40 enerjide istiyorsanız bu 33 olur.]=]
L[ [=[This will fade the bars or numeric representation from the min color specified to the regular color

(e.g. if the min color is yellow, the color is red, and there are 3 total applications, then the first would be yellow, second orange, and third red)]=] ] = [=[Çubukları veya sayısal gösterimi belirtilen asgari renkten normal renge doğru soldurur

(örn. asgari renk sarı, renk kırmızı ve toplam 3 yığın varsa birincisi sarı, ikincisi turuncu, üçüncüsü kırmızı olur)]=]
L[ [=[This will fade the graphical representation from the min color specified to the regular color

(e.g. if the min color is yellow, the color is red, and there are 3 total applications, then the first would be yellow, second orange, and third red)]=] ] = [=[Grafik gösterimi belirtilen asgari renkten normal renge doğru soldurur

(örn. asgari renk sarı, renk kırmızı ve toplam 3 yığın varsa birincisi sarı, ikincisi turuncu, üçüncüsü kırmızı olur)]=]
L["This will hide the entire mod during pet battles."] = "Bu, evcil hayvan savaşları sırasında tüm modu gizler."
L["This will hide the entire mod when interacting with a barbershop."] = "Bu, berber dükkânıyla etkileşirken tüm modu gizler."
L["This will hide the entire mod when playing the BfA Tortollan shell game world quest."] = "Bu, BfA Tortollan kabuk oyunu dünya görevi oynanırken tüm modu gizler."
L["This will hide the entire mod when using the Dragonflight Cataloging camera."] = "Bu, Dragonflight Kataloglama kamerası kullanılırken tüm modu gizler."
L["This will override the global bar texture setting for this bar with the one specified below."] = "Bu, bu çubuk için genel çubuk dokusu ayarını aşağıda belirtilenle geçersiz kılar."
L["This will override the global bar texture setting for this bar."] = "Bu, bu çubuk için genel çubuk dokusu ayarını geçersiz kılar."
L["This will remove the marker selected in the 'edit marker' box. This action is irreversible."] = "Bu, 'işaretçiyi düzenle' kutusunda seçilen işaretçiyi kaldırır. Bu işlem geri alınamaz."
L[ [=[This will rotate this module by 90 degrees to give a horizontal orientation.

WARNING: This feature is brand new and a bit rough around the edges. You will need to greatly adjust the vertical and horizontal offset of this bar plus move the text around in order for it to look correct.

And I mean greatly.]=] ] = [=[Bu modülü yatay görünüm için 90 derece döndürür.

UYARI: Bu özellik yepyeni ve biraz pürüzlü. Doğru görünmesi için bu çubuğun dikey ve yatay kaymasını büyük ölçüde ayarlamanız ve yazıları da taşımanız gerekecek.

Gerçekten büyük ölçüde.]=]
L["This will update the marker selected in the 'edit marker' box with the values specified."] = "Bu, 'işaretçiyi düzenle' kutusunda seçilen işaretçiyi belirtilen değerlerle günceller."
L["Toggle bar background visibility"] = "Çubuk arka planı görünürlüğünü aç/kapat"
L["Toggle bar visibility"] = "Çubuk görünürlüğünü aç/kapat"
L["Toggle interactive placement mode"] = "Etkileşimli yerleşim modunu aç/kapat"
L["Toggle interactive point placement"] = "Etkileşimli nokta yerleşimini aç/kapat"
L["Toggle lower text visibility"] = "Alt metin görünürlüğünü aç/kapat"
L["Toggle mouseover on/off"] = "Fare üzerine gelmeyi aç/kapat"
L["Toggle mouseover on/off for buffs/debuffs"] = "Güçlendirmeler/zayıflatmalar için fare üzerine gelmeyi aç/kapat"
L["Toggle mouseover on/off for target"] = "Hedef için fare üzerine gelmeyi aç/kapat"
L["Toggle spell cast text visibility"] = "Büyü yapma metni görünürlüğünü aç/kapat"
L["Toggle upper text visibility"] = "Üst metin görünürlüğünü aç/kapat"
L["Toggles contextual background coloring"] = "Bağlamsal arka plan renklendirmesini aç/kapat"
L["Toggles the ability to drag individual points to the desired location."] = "Tekil noktaları istenen konuma sürükleme olanağını aç/kapat."
L["Toggles the ability to drag this module to the desired location instead of adjusting Position sliders."] = "Konum kaydırıcılarını ayarlamak yerine bu modülü istenen konuma sürükleme olanağını aç/kapat."
L["Toggles whether or not buffs are displayed at all"] = "Güçlendirmelerin hiç gösterilip gösterilmeyeceğini aç/kapat"
L["Toggles whether or not debuffs are displayed at all"] = "Zayıflatmaların hiç gösterilip gösterilmeyeceğini aç/kapat"
L["Toggles whether or not temporary weapon enchants are displayed"] = "Geçici silah büyülerinin gösterilip gösterilmeyeceğini aç/kapat"
L["Toggles whether or not to show the CastNonInterruptible color for this bar when a cast is non-interruptible"] = "Bir büyü kesilemezken bu çubuk için CastNonInterruptible renginin gösterilip gösterilmeyeceğini aç/kapat"
L["Toggles whether or not to sort by expiration time (otherwise they're sorted how the game sorts them - by application time)"] = "Bitiş süresine göre sıralanıp sıralanmayacağını aç/kapat (aksi halde oyunun sıraladığı gibi - uygulanma zamanına göre - sıralanırlar)"
L["ToT frame texture"] = "HH çerçevesi dokusu"
L["Totem cooldown mode"] = "Totem bekleme modu"
L["Totem gap"] = "Totem boşluğu"
L["Totem orientation"] = "Totem yönelimi"
L["Transparency Settings"] = "Saydamlık Ayarları"
L["Travel"] = "Seyahat"
L["Type %s to clear focus"] = "Odağı temizlemek için %s yaz"
L["Type %s to set focus"] = "Odaklanmak için %s yaz"
L["Unit to track"] = "İzlenecek birim"
L["Update"] = "Güncelle"
L["Update Period"] = "Güncelleme Aralığı"
L["Upper Text"] = "Üst Metin"
L["Upper Text Color"] = "Üst Metin Rengi"
L["Upper text visible"] = "Üst metin görünür"
L["Use class color as the bar color instead of default color"] = "Varsayılan renk yerine sınıf rengini çubuk rengi olarak kullan"
L["Use class color as the bar color instead of reaction color"] = "Tepki rengi yerine sınıf rengini çubuk rengi olarak kullan"
L[ [=[Use class color as the bar color instead of reaction color

(Note: The 'color bar by health %' setting overrides this)]=] ] = [=[Çubuk rengi olarak tepki rengi yerine sınıf rengini kullan

(Not: 'Çubuğu can yüzdesine göre renklendir' ayarı bunun önüne geçer)]=]
L["Use Dog Tags"] = "Dog Tag'leri Kullan"
L["Use multiple buff colors"] = "Birden çok güçlendirme rengi kullan"
L["Use normal alpha"] = "Normal saydamlığı kullan"
L["Use 'Target' alpha for friendlies"] = "Dostlar için 'Hedef' saydamlığını kullan"
L["Use this for abilities that don't require a target to cast, but you only want to see them when you have a target"] = "Bunu, büyü yapmak için hedef gerektirmeyen ama yalnızca hedefin olduğunda görmek istediğin yetenekler için kullan"
L["Use your Dismiss Pet spell to dismiss a pet"] = "Bir evcil hayvanı azletmek için Evcil Hayvanı Azlet büyünü kullan"
L["Uses the 'color bar by mana %' setting/colors even for classes that don't use Mana"] = "'Mana %'sine göre renklendir' ayarını/renklerini Mana kullanmayan sınıflar için bile kullanır"
L["Usually CD bars will always display if they're set to 'When Ready' or 'Always' mode regardless of your other transparency settings. If you'd rather this bar show/hide as per normal transparency rules, then check this box."] = "Genellikle BK çubukları 'Hazırken' veya 'Her zaman' modundaysa diğer saydamlık ayarlarına bakılmaksızın her zaman gösterilir. Bu çubuğun normal saydamlık kurallarına göre gösterilip gizlenmesini istiyorsan bu kutuyu işaretle."
L["Vertical offset"] = "Dikey kayma"
L["Vertical Position"] = "Dikey Konum"
L["Vertical position"] = "Dikey konum"
L["Visibility Settings"] = "Görünürlük Ayarları"
L["Weapon"] = "Silah"
--[[Translation missing --]]
L["Weapon enchant anchor to"] = ""
--[[Translation missing --]]
L["Weapon enchant grow direction"] = ""
--[[Translation missing --]]
L["Weapon enchant horizontal offset"] = ""
L["Weapon Enchant Settings"] = "Silah Büyüsü Ayarları"
--[[Translation missing --]]
L["Weapon enchant vertical offset"] = ""
L["What alpha value to use for the bar that displays how long your RtB will last if you activate it. (This gets multiplied by the bar's current alpha to stay in line with the bar on top of it)"] = "Etkinleştirirsen RtB'nin ne kadar süreceğini gösteren çubuk için kullanılacak saydamlık değeri. (Üstündeki çubukla uyumlu kalması için çubuğun mevcut saydamlığıyla çarpılır)"
L["What alpha value to use for the bar that displays how long your SnD will last if you activate it. (This gets multiplied by the bar's current alpha to stay in line with the bar on top of it)"] = "Etkinleştirirsen SnD'nin ne kadar süreceğini gösteren çubuk için kullanılacak saydamlık değeri. (Üstündeki çubukla uyumlu kalması için çubuğun mevcut saydamlığıyla çarpılır)"
L["What alpha value to use for the bar that displays how much effective health you have including absorbs (This gets multiplied by the bar's current alpha to stay in line with the bar on top of it)"] = "Emilimler dahil sahip olduğun etkin canı gösteren çubuk için kullanılacak saydamlık değeri (Üstündeki çubukla uyumlu kalması için çubuğun mevcut saydamlığıyla çarpılır)"
L["What alpha value to use for the bar that displays how much health you'll have after an incoming heal (This gets multiplied by the bar's current alpha to stay in line with the bar on top of it)"] = "Gelen şifadan sonra sahip olacağın canı gösteren çubuk için kullanılacak saydamlık değeri (Üstündeki çubukla uyumlu kalması için çubuğun mevcut saydamlığıyla çarpılır)"
L["What graphical representation each rune should have. When setting to anything other than 'graphical', the module will behave more like combo points and simply show how many are active."] = "Her runenin hangi grafik gösterimine sahip olacağı. 'Grafik' dışında bir şeye ayarlandığında modül kombo puanları gibi davranır ve yalnızca kaç tanesinin etkin olduğunu gösterir."
L["What this bar should do whenever the player is the TargetOfTarget"] = "Oyuncu HedefinHedefi olduğunda bu çubuğun ne yapacağı"
L[ [=[What this bar should do whenever the player is the TargetOfTarget

NOTE: When this is set to 'hide', then click-targeting is not available due to Blizzard's restrictions]=] ] = [=[Oyuncu TargetOfTarget olduğunda bu çubuğun ne yapacağı

NOT: Bu 'gizle' olarak ayarlıysa Blizzard kısıtlamaları nedeniyle tıklayarak hedefleme kullanılamaz]=]
L["When checked, if a 'Custom Lag Tolerance' is set in the game's Combat options, the lag indicator will always use that tolerance value. Otherwise, it uses the computed latency."] = "İşaretliyse, oyunun Savaş seçeneklerinde 'Özel Gecikme Toleransı' ayarlıysa, gecikme göstergesi her zaman o tolerans değerini kullanır. Aksi halde hesaplanan gecikmeyi kullanır."
L["When missing"] = "Eksikken"
L["When present"] = "Mevcutken"
L["When tanking, this toggles whether or not the second-highest threat value found in your party or raid is displayed on top of your actual threat value"] = "Tank olarak, partinde veya baskınında bulunan ikinci en yüksek tehdit değerinin gerçek tehdit değerinin üzerinde gösterilip gösterilmeyeceğini aç/kapat"
L["When the bar drops below this amount, it will start flashing (0 means never). For the 'mana' bar this only applies to mana and not rage/energy/focus/runic power."] = "Çubuk bu miktarın altına düştüğünde çakmaya başlar (0 hiçbir zaman demektir). 'Mana' çubuğu için bu yalnızca mana için geçerlidir; öfke/enerji/odak/runik güç için değil."
L["When the player is in one of the chosen shapeshift forms the bar will be shown, otherwise it will be hidden."] = "Oyuncu seçilen şekil değiştirme formlarından birindeyken çubuk gösterilir, aksi halde gizlenir."
L["When to display this bar."] = "Bu çubuğun ne zaman gösterileceği."
L["When to show the bar"] = "Çubuğun ne zaman gösterileceği"
L[ [=[Whether or not the addon should use the DogTag library (this will increase the CPU usage of the mod). DogTag controls all text displayed around bars such as health or mana amounts. Type |cffffff78/dog|r to see all DogTag options.

NOTE: after changing this option, you must reload the UI or else bad things happen]=] ] = [=[Eklentinin DogTag kitaplığını kullanıp kullanmayacağı (bu, eklentinin işlemci kullanımını artırır). DogTag, can veya mana miktarı gibi çubukların çevresinde gösterilen tüm yazıları denetler. Tüm DogTag seçeneklerini görmek için |cffffff78/dog|r yazın.

NOT: bu seçeneği değiştirdikten sonra arayüzü yenilemelisiniz, yoksa sorunlar çıkar]=]
L["Whether or not to allow click casting of Hunger For Blood"] = "Kan Açlığı'nın tıklayarak yapılmasına izin verilip verilmeyeceği"
L["Whether or not to allow click targeting/casting and the player drop-down menu for this bar (Note: does not work properly with HiBar, have to click near the base of the bar)"] = "Bu çubuk için tıklayarak hedeflemeye/büyü yapmaya ve oyuncu açılır menüsüne izin verilip verilmeyeceği (Not: HiBar ile düzgün çalışmaz, çubuğun tabanına yakın tıklamalısın)"
L["Whether or not to allow click targeting/casting and the player drop-down menu for this bar while the player is in combat (Note: does not work properly with HiBar, have to click near the base of the bar)"] = "Oyuncu savaştayken bu çubuk için tıklayarak hedeflemeye/büyü yapmaya ve oyuncu açılır menüsüne izin verilip verilmeyeceği (Not: HiBar ile düzgün çalışmaz, çubuğun tabanına yakın tıklamalısın)"
L["Whether or not to allow click targeting/casting and the target drop-down menu for this bar (Note: does not work properly with HiBar, have to click near the base of the bar)"] = "Bu çubuk için tıklayarak hedeflemeye/büyü yapmaya ve hedef açılır menüsüne izin verilip verilmeyeceği (Not: HiBar ile düzgün çalışmaz, çubuğun tabanına yakın tıklamalısın)"
L["Whether or not to allow click targeting/casting for this bar (Note: does not work properly with HiBar, have to click near the base of the bar)"] = "Bu çubuk için tıklayarak hedeflemeye/büyü yapmaya izin verilip verilmeyeceği (Not: HiBar ile düzgün çalışmaz, çubuğun tabanına yakın tıklamalısın)"
L["Whether or not to allow the mouse to interact with the totems. If this is enabled, then right-clicking a totem will cancel it. Otherwise mouse clicks will not get caught by the totems and no tooltips will be shown."] = "Farenin totemlerle etkileşmesine izin verilip verilmeyeceği. Bu etkinse, bir totemi sağ tıklamak onu iptal eder. Aksi halde fare tıklamaları totemlere ulaşmaz ve ipucu gösterilmez."
L["Whether or not to animate the bar falloffs/gains"] = "Çubuğun azalma/artışlarının canlandırılıp canlandırılmayacağı"
L["Whether or not to color a charged combo point a separate color and append an @ sign to the number. Set the ChargedComboPointBar color to the color you would like it to be."] = "Yüklü bir kombo puanının ayrı bir renge boyanıp boyanmayacağı ve sayının sonuna @ işareti eklenip eklenmeyeceği. ChargedComboPointBar rengini istediğin renge ayarla."
L["Whether or not to color a charged combo point a separate color. Set the ChargedComboPoint color to the color you would like it to be."] = "Yüklü bir kombo puanının ayrı bir renge boyanıp boyanmayacağı. ChargedComboPoint rengini istediğin renge ayarla."
L["Whether or not to color an anima-charged combo point a separate color. Set the KyrianAnimaComboPoint color to the color you would like it to be."] = "Anima yüklü bir kombo puanının ayrı bir renge boyanıp boyanmayacağı. KyrianAnimaComboPoint rengini istediğin renge ayarla."
L["Whether or not to display an icon for the aura that this bar is tracking"] = "Bu çubuğun izlediği aura veya eşya için bir simge gösterilip gösterilmeyeceği"
L["Whether or not to display the first line of text on this module which is the target's name."] = "Bu modülde hedefin adı olan birinci metin satırının gösterilip gösterilmeyeceği."
L["Whether or not to display the second line of text on this module which is the target's details (level, class, PvP status, etc.)."] = "Bu modülde hedefin ayrıntıları (seviye, sınıf, PvP durumu, vb.) olan ikinci metin satırının gösterilip gösterilmeyeceği."
L["Whether or not to display the third line of text on this module which is the target's guild and realm (if they are from another realm)."] = "Bu modülde hedefin loncası ve diyarı (başka bir diyardansa) olan üçüncü metin satırının gösterilip gösterilmeyeceği."
L["Whether or not to display this bar even if the buff/debuff specified is not present."] = "Belirtilen güçlendirme/zayıflatma mevcut olmasa bile bu çubuğun gösterilip gösterilmeyeceği."
L["Whether or not to display when you have no target selected but have combo points available"] = "Hedef seçili olmasa da kombo puanları varsa gösterilip gösterilmeyeceği"
L["Whether or not to reverse the direction of the cast bar when a spell is being channeled. For example, if a normal cast causes this bar to fill up, then checking this option will cause a channeled spell to empty the bar instead."] = "Bir büyü kanalize edilirken büyü çubuğunun yönünün ters çevrilip çevrilmeyeceği. Örneğin normal bir büyü bu çubuğu dolduruyorsa, bu seçeneği işaretlemek kanal büyüsünün çubuğu boşaltmasına yol açar."
L["Whether or not to show absorb amounts as a lighter-colored bar on top of your current health."] = "Emilim miktarlarının mevcut canın üzerinde daha açık renkli bir çubuk olarak gösterilip gösterilmeyeceği."
L["Whether or not to show an IceHUD icon on the minimap."] = "Minimap'te bir IceHUD simgesi gösterilip gösterilmeyeceği."
L["Whether or not to show incoming heals as a lighter-colored bar on top of your current health (requires LibHealComm-4.0 or official patch 4.0)"] = "Gelen şifaların mevcut canın üzerinde daha açık renkli bir çubuk olarak gösterilip gösterilmeyeceği (LibHealComm-4.0 veya resmi 4.0 yaması gerektirir)"
L["Whether or not to show the combat status portion of the status icon (for example, if you only care when you're resting, not when you're in combat)"] = "Durum simgesinin savaş durumu kısmının gösterilip gösterilmeyeceği (örneğin yalnızca dinlenirken ilgileniyorsan, savaşta değil)"
L["Whether or not to show the counter when the value is zero. This will cause a 0 to be displayed at all times for Numeric mode and faded markers for graphical mode."] = "Değer sıfırken sayacın gösterilip gösterilmeyeceği. Bu, Sayısal modda her zaman 0 gösterilmesine, grafik modda ise soluk işaretçiler gösterilmesine yol açar."
L["Whether or not to show the default cast bar."] = "Varsayılan büyü çubuğunun gösterilip gösterilmeyeceği."
L["Whether or not to show the default mirror bar."] = "Varsayılan ayna çubuğunun gösterilip gösterilmeyeceği."
L["Whether or not to show the loot master icon"] = "Ganimet sorumlusu simgesinin gösterilip gösterilmeyeceği"
L["Whether or not to show the party leader icon above this bar"] = "Parti lideri simgesinin bu çubuğun üstünde gösterilip gösterilmeyeceği"
L["Whether or not to show the Party Role icon"] = "Parti Rolü simgesinin gösterilip gösterilmeyeceği"
L["Whether or not to show the PvP icon"] = "PvP simgesinin gösterilip gösterilmeyeceği"
L["Whether or not to show the raid icon above this bar"] = "Baskın simgesinin bu çubuğun üstünde gösterilip gösterilmeyeceği"
L["Whether or not to show the raid icon for this unit."] = "Bu birim için baskın simgesinin gösterilip gösterilmeyeceği."
L["Whether or not to show the rank of a spell being cast."] = "Yapılan büyünün rütbesinin gösterilip gösterilmeyeceği."
L["Whether or not to show the rare/elite icon above this bar"] = "Nadir/elit simgesinin bu çubuğun üstünde gösterilip gösterilmeyeceği"
L["Whether or not to show the remaining cast time of a spell being cast."] = "Yapılan büyünün kalan yapma süresinin gösterilip gösterilmeyeceği."
L["Whether or not to show the resting status portion of the status icon (for example, if you only care when you're in combat, but not when you're resting)"] = "Durum simgesinin dinlenme durumu kısmının gösterilip gösterilmeyeceği (örneğin yalnızca savaştayken ilgileniyorsan, dinlenirken değil)"
L[ [=[Whether or not to show the status icon (resting/combat) above this bar

Note: You can configure resting/combat separately below, but disabling both resting and combat is the same as disabling the icon altogether]=] ] = [=[Bu çubuğun üstünde durum simgesinin (dinlenme/savaş) gösterilip gösterilmeyeceği

Not: Dinlenme/savaşı aşağıda ayrı ayrı ayarlayabilirsiniz, ama ikisini de kapatmak simgeyi tamamen kapatmakla aynıdır]=]
L["Whether the bar's maximum value should be set to the unit's maximum health or not. If set, any absorb above that amount will not be shown."] = "Çubuğun azami değerinin birimin azami canına ayarlanıp ayarlanmayacağı. Ayarlıysa, bu miktarın üzerindeki emilimler gösterilmez."
L["Whether the runes should draw side-by-side or on top of one another"] = "Runelerin yan yana mı yoksa üst üste mi çizileceği"
L["Whether the totems should draw side-by-side or on top of one another"] = "Totemlerin yan yana mı yoksa üst üste mi çizileceği"
L["Whether this bar should hide when the player has 0 combo points or stay visible"] = "Oyuncunun 0 kombo puanı olduğunda bu çubuğun gizlenip gizlenmeyeceği veya görünür kalıp kalmayacağı"
L["Whether to always show this module at 100% alpha or not"] = "Bu modülün her zaman %100 saydamlıkta gösterilip gösterilmeyeceği"
L["Whether to display this bar when you target a unit, even if the buff/debuff specified is not present."] = "Belirtilen güçlendirme/zayıflatma mevcut olmasa bile bir birimi hedeflediğinde bu çubuğun gösterilip gösterilmeyeceği"
L["Whether to draw the elite icon in front of or behind this bar"] = "Elit simgesinin bu çubuğun önünde mi arkasında mı çizileceği"
L["Whether to draw the PvP icon in front of or behind this bar"] = "PvP simgesinin bu çubuğun önünde mi arkasında mı çizileceği"
L["Whether to draw the raid icon in front of or behind this bar"] = "Baskın simgesinin bu çubuğun önünde mi arkasında mı çizileceği"
L["Whether to force buff and debuff frames to hide their cooldown numbers even if enabled in the game settings or not."] = "Oyun ayarlarında etkin olsa bile güçlendirme ve zayıflatma çerçevelerinin bekleme sayılarını gizlemeye zorlayıp zorlamayacağı."
L["Whether to print the seconds left until the next swing under the bar."] = "Bir sonraki vuruşa kalan saniyelerin çubuğun altında yazdırılıp yazdırılmayacağı."
L["Whether to show the Runes module any time the player has fewer than max runes available (regardless of combat/target status)."] = "Oyuncunun kullanılabilir rune sayısı azami sayıdan azsa (savaş/hedef durumundan bağımsız olarak) Rune modülünün gösterilip gösterilmeyeceği."
L["Whether to show this bar when a spellcast longer than the global cooldown is being cast."] = "Küresel beklemeden daha uzun bir büyü yapılırken bu çubuğun gösterilip gösterilmeyeceği."
L["Whether to show threat in scaled values or raw values. Scaled threat means that you will pull aggro when it hits 100%. Raw threat means you will pull aggro at either 110% (melee) or 130% (ranged). Omen uses raw threat which can cause this mod to disagree with Omen if it is in scaled mode."] = "Tehdidin ölçekli değerlerle mi ham değerlerle mi gösterileceği. Ölçekli tehdit, %100'e ulaştığında saldırganlığı çekeceğin anlamına gelir. Ham tehdit, %110 (yakın dövüş) veya %130'da (menzilli) saldırganlığı çekeceğin anlamına gelir. Omen ham tehdit kullanır; bu, ölçekli moddaysa bu modun Omen ile uyuşmamasına yol açabilir."
L["Whether we are tracking a buff or debuff"] = [=[Whether we are tracking a buff, debuff, charges, or stacks.

Some spells, such as Conflagrate, have charges that get consumed and then rebuild. Other spells, such as Focus Fire, have stacks that don't necessarily coincide with a buff/debuff.]=]
L["Which buff/debuff this bar will be tracking. Can use the name or spell id. \\n\\nRemember to press ENTER after filling out this box with the name you want or it will not save."] = "Bu çubuğun takip edeceği güçlendirme/zayıflatma. Adı veya büyü kimliği kullanılabilir. \\n\\nBu kutuyu istediğiniz adla doldurduktan sonra ENTER tuşuna basmayı unutmayın, yoksa kaydedilmez."
L[ [=[Which buff/debuff this bar will be tracking.

Remember to press ENTER after filling out this box with the name you want or it will not save.]=] ] = [=[Bu çubuğun takip edeceği güçlendirme/zayıflatma.

Bu kutuyu istediğiniz adla doldurduktan sonra ENTER tuşuna basmayı unutmayın, yoksa kaydedilmez.]=]
L[ [=[Which buff/debuff this counter will be tracking. 

Remember to press ENTER after filling out this box with the name you want or it will not save.]=] ] = [=[Bu sayacın takip edeceği güçlendirme/zayıflatma. 

Bu kutuyu istediğiniz adla doldurduktan sonra ENTER tuşuna basmayı unutmayın, yoksa kaydedilmez.]=]
L["Which buff/debuff this counter will be tracking. Can use the name or spell id. \\n\\nRemember to press ENTER after filling out this box with the name you want or it will not save."] = "Bu sayacın takip edeceği güçlendirme/zayıflatma. Adı veya büyü kimliği kullanılabilir. \\n\\nBu kutuyu istediğiniz adla doldurduktan sonra ENTER tuşuna basmayı unutmayın, yoksa kaydedilmez."
L["Which direction the buffs should grow from the anchor point"] = "Güçlendirmelerin bağlantı noktasından hangi yöne doğru büyüyeceği"
L["Which direction the debuffs should grow from the anchor point"] = "Zayıflatmaların bağlantı noktasından hangi yöne doğru büyüyeceği"
L["Which direction the weapon enchants should grow from the anchor point"] = "Silah büyülerinin bağlantı noktasından hangi yöne doğru büyüyeceği"
L["Which icon set to use for elite/rare elite/rare textures. This simply changes the look of the classification icon."] = "Elit/nadir elit/nadir dokuları için hangi simge setinin kullanılacağı. Bu yalnızca sınıflandırma simgesinin görünümünü değiştirir."
L["Which item cooldown this bar will be tracking."] = "Bu çubuğun hangi eşya beklemesini izleyeceği."
L[ [=[Which spell cooldown this bar will be tracking.

Remember to press ENTER after filling out this box with the name you want or it will not save.]=] ] = [=[Bu çubuğun takip edeceği büyü bekleme süresi.

Bu kutuyu istediğiniz adla doldurduktan sonra ENTER tuşuna basmayı unutmayın, yoksa kaydedilmez.]=]
L["Which weapon's swing to track"] = "Hangi silahın vuruşunun izleneceği"
L["Width"] = "Genişlik"
L["Will only show buffs that you cast instead of all buffs active"] = "Etkin tüm güçlendirmeler yerine yalnızca senin yaptığın güçlendirmeleri gösterir"
L["Will only show debuffs that you cast instead of all debuffs active"] = "Etkin tüm zayıflatmalar yerine yalnızca senin yaptığın zayıflatmaları gösterir"
L["Will only show this bar if the target uses mana (as opposed to rage, energy, runic power, etc.)"] = "Bu çubuğu yalnızca hedef mana kullanıyorsa gösterir (öfke, enerji, runik güç, vb. yerine)"
L["With this checked, the bar will only activate for your own CC spells and not those of others."] = "Bu işaretliyken çubuk yalnızca senin kendi KK büyülerin için etkinleşir, başkalarınınkiler için değil."
L[ [=[With this enabled, all icons draw so you can configure their placement

Note: the combat and status icons are actually the same texture so you'll only see combat in config mode (unless you're already resting)]=] ] = [=[Bu açıkken tüm simgeler çizilir, böylece yerlerini ayarlayabilirsiniz

Not: savaş ve durum simgeleri aslında aynı doku olduğundan ayar modunda yalnızca savaşı görürsünüz (zaten dinlenmiyorsanız)]=]
L["With this enabled, all icons will be 100% visible regardless of the alpha settings for this bar."] = "Bu etkinken, bu çubuğun saydamlık ayarlarından bağımsız olarak tüm simgeler %100 görünür olur."
L["With this enabled, the raid icon is always 100% alpha, regardless of the bar's alpha. Otherwise, it assumes the bar's alpha level."] = "Bu etkinken, çubuğun saydamlığından bağımsız olarak baskın simgesi her zaman %100 saydamlıktadır. Aksi halde çubuğun saydamlık seviyesini alır."
L["You have changed IceHUD profiles while in combat. This can cause problems due to Blizzard's secure frame policy. You may need to reload your UI to repair IceHUD."] = "IceHUD profillerini savaştayken değiştirdin. Bu, Blizzard'ın güvenli çerçeve politikası nedeniyle sorunlara yol açabilir. IceHUD'u onarmak için arayüzünü yeniden yüklemen gerekebilir."
L["Whether or not the addon should use the DogTag library (this will increase the CPU usage of the mod). DogTag controls all text displayed around bars such as health or mana amounts. Type |cffffff78/dog|r to see all DogTag options.\n\nNOTE: after changing this option, you must reload the UI or else bad things happen"] = "Eklentinin DogTag kitaplığını kullanıp kullanmayacağı (bu, eklentinin işlemci kullanımını artırır). DogTag, can veya mana miktarı gibi çubukların çevresinde gösterilen tüm yazıları denetler. Tüm DogTag seçeneklerini görmek için |cffffff78/dog|r yazın.\n\nNOT: bu seçeneği değiştirdikten sonra arayüzü yenilemelisiniz, yoksa sorunlar çıkar"
