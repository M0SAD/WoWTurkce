if not WoWTurkce.FOREVER then return end -- yalnızca Classic Forever
-- Classic Forever'a özel görevler 1
-- b=başlık, a=açıklama, h=hedef, i=ilerleme, t=tamamlama
-- k = çevrilen İngilizce metnin parmak izi (metin değişirse çeviri gösterilmez, yeniden kaydedilir)
local V = WoWTurkce.Veri

V[5691] = { b="<NYI> <TXT> Karanlıkta Yaratıldı", k={b=2552336783} }
V[5692] = { b="<NYI> Karanlıkta Yaratıldı", h="Undercity'deki Aelthalyste ile konuş.", k={b=1616396367, h=1543403883} }
V[5693] = { b="<NYI> Karanlıkta Yaratıldı", h="Undercity'deki Aelthalyste ile konuş.", k={b=1616396367, h=1543403883} }
V[5704] = { b="<NYI> <TXT> Undead Rahip Cüppesi", k={b=3184914757} }
V[5705] = { b="<NYI> Artık Bir Gölge Değil", h="Undercity'deki Aelthalyste ile konuş.", k={b=4248619520, h=1543403883} }
V[5706] = { b="<NYI> Artık Bir Gölge Değil", h="Undercity'deki Aelthalyste ile konuş.", k={b=4248619520, h=1543403883} }
V[65593] = { b="Âşıkların Kalpleri", h="Avelina Lilly ile Isaac Pearson'ın kalplerini Temple of the Damned'daki Carendin Halgar'a getir.", k={b=3138447965, h=1907887930} }
V[65597] = { b="Bağlama", h="Âşıkların Kalpleri'ni kullanarak bir incubus çağır ve onu boyun eğdir, ardından Âşıkların Kalpleri'ni Undercity'nin Magic Quarter bölgesindeki Carendin Halgar'a geri götür.", k={b=129408481, h=1518403554} }
V[65601] = { b="Aşk Acıtır", h="Orgrimmar'daki Magar ile konuş.", k={b=4122254897, h=3702043172} }
V[65602] = { b="Aşk Nedir?", h="Tahta Heykelcik'i ele geçir ve Stormwind'in Mage Quarter bölgesindeki Karanlık Bağlayıcı Gakin'e götür.", k={b=3435543403, h=545409481} }
V[65603] = { b="Bağlama", h="Tahta Heykelcik'i kullanarak bir incubus çağır ve onu boyun eğdir, ardından Tahta Heykelcik'i Slaughtered Lamb'deki Karanlık Bağlayıcı Gakin'e geri götür.", k={b=129408481, h=2291702552} }
V[65604] = { b="Bağlama", h="Solgun Atkı'yı kullanarak bir incubus çağır ve onu boyun eğdir, ardından Solgun Atkı'yı Orgrimmar'daki Gan'rul Bloodeye'a geri götür.", k={b=129408481, h=3101560346} }
V[65610] = { b="Keşke Burada Olsaydın", h="Ashenvale'deki Fallen Sky Lake'i araştır ve bulduklarını Orgrimmar'daki Gan'rul Bloodeye'a bildir.", k={b=2686763124, h=951616658} }
V[78088] = { b="Tuhaf Bir Eser", h="Althalaxx Küresi'ni Ashenvale'deki Maestra's Post'ta bulunan Arındırıcı Delgren'e götür.", k={b=980648520, h=1218496630} }
V[78089] = { b="Stormwind'den Öğüt", h="Althalaxx Küresi'ni Stormwind'deki Saf Katherine'e götür.", k={b=976730924, h=2341648987} }
V[78090] = { b="İkinci Bir Görüş", h="Stormwind'deki warlock tapınağını bul ve küre hakkında öğüt iste.", k={b=2407264734, h=2395199991} }
V[78091] = { b="Tuzunu Hak Etmek", h="Redridge Mountains'daki Blackrock Çağırıcıları'ndan 14 Çağırıcı Tuzu topla, ardından Stormwind'deki Ursula Deline'a dön.", k={b=1258882956, h=2736020014} }
V[78092] = { b="Yok Edilmeli", h="Ashenvale'deki iblislerden 12 Mannoroth Zerresi topla. Bunları Althalaxx Küresi ile birlikte Demon Fall Canyon'daki Mannoroth'un Mızrağı'na götür.", k={b=2985636869, h=4290257995} }
V[78093] = { b="Delgren'e Dönüş", h="Küre Parçaları'nı Delgren'e geri götür.", k={b=1670112905, h=3319152082} }
V[78148] = { b="Büyücü Kralların Runları", k={b=4267542249} }
V[78676] = { b="Bhossca'nın Gözü", h="Scarlet Monastery'nin içinde Bhossca'nın Gözü'nü bul. Ardından onu Pyrewood Village yakınındaki C'nin gizli bırakma noktasına götür. Bu işi tek başına tamamlamalısın.", k={b=4291237473, h=3936366852} }
V[78699] = { b="Bhossca'nın Gözü", h="Kayıt", k={b=4291237473, h=193498375} }
V[79092] = { b="Başbüyücü Theocritus'un Araştırma Günlüğü", k={b=3213797295} }
V[79095] = { b="Simyacının Metafizik El Kitabı", k={b=3564809084} }
V[79536] = { b="Kütüphanenin Büyük Dostu", k={b=4062613906} }
V[82208] = { b="Kütüphanenin Büyük Dostu", h="Bu görevi tamamlamak için 25 kitap teslim etmen gerekecek, ancak istediğin zaman birer birer teslim edebilirsin.", k={b=4062613906, h=568253940} }
V[90902] = { b="Işığı Yeniden Keşfetmek", h="Holy Light yeteneğinle 5 Yaralı Deathguard'ı iyileştir.", k={b=1016275602, h=293487275} }
V[91208] = { b="Kabullenmek", h="Deathknell'deki Korkmuş Paladin'i bul.", k={b=3519151280, h=3688026483} }
V[91209] = { b="Eğitimine Devam Et", h="Deathknell'den doğuya giden yolu izleyerek Brill kasabasını bul. Eğitimine devam etmek için Shari Stilwell'e rapor ver.", k={b=2632257493, h=2877557516} }
V[91282] = { b="İkinci Bir Yuva", h="Bandarion Keep kalesini bul ve oradaki Breton Samuels'e rapor ver.", k={b=4282113291, h=1740788021} }
V[91285] = { b="Kapıdaki Murloclar", h="8 Vile Fin Attacker ve 8 Vile Fin Seer öldür, iş bitince Breton Samuels'e rapor ver.", k={b=522397396, h=972802103} }
V[91294] = { b="Arazide Bir Tur", h="Bandarion Keep sakinleriyle konuş.", k={b=4129281360, h=3709704118} }
V[91316] = { b="Onarım İşleri", h="Tirisfal Glades'teki Shadowvale'den 12 parça Sağlam Kereste topla.", k={b=2178747634, h=721272437} }
V[91317] = { b="Lekeliler", h="Tirisfal Glades'te 8 Tarnished Drudge ve 6 Tarnished Zealot öldür, Komutan Rudolph Gelhardt'ın kellesini de al.", k={b=3922083336, h=845462949} }
V[91858] = { b="Diplomatik Olay", h="Silverpine Forest'taki The Sepulcher'a git ve kayıp Earthen Ring yolcuları hakkında Trevan Rol ile konuş.", k={b=3894723033, h=1547707058} }
V[91859] = { b="Tuhaf Bir İkili", h="Kısa süre önce The Sepulcher'dan geçen gizemli Earthen Ring yolcuları hakkında Deathguard Baldren ile konuş.", k={b=2428384636, h=2553171798} }
V[91860] = { b="Acı Bir Akıbet", h="Doğudaki Fenris Isle'ı araştır ve Earthen Ring yolcu kafilesinin akıbetini öğren.", k={b=1745536021, h=1737080732} }
V[91861] = { b="Fenris Keep'e Doğru", h="Kuzeydeki Fenris Keep'i araştır ve Earthen Ring kafilesinin kayıp üyesini bulmaya çalış.", k={b=3495861291, h=2453936064} }
V[91862] = { b="Lumina Windsinger", h="Rot Hide Gnoll'larından Fenris Isle Anahtarı'nı al ve onu kullanarak Lumina Windsinger'ı serbest bırak.", k={b=785073733, h=1150544638} }
V[92481] = { b="Arkana Öğrencisi", h="Parıldayan Dönüş Kristali'ni incele, ardından Thendal Grove'daki Dorii Brightwhisper ile konuş.", k={b=913440621, h=1833286699} }
V[92482] = { b="Avcının Yolu", h="Karalanmış Not'u oku ve ardından Thendal Grove'daki Tai'ree Farsight ile konuş.", k={b=2952794755, h=1560611264} }
V[92483] = { b="Gölgelerde Evinde", h="Basit Not'u oku, ardından Thendal Grove'daki gözetleme kulesinde Akeri Duskblade ile konuş.", k={b=3107559540, h=3278061234} }
V[92485] = { b="Doğa Öğrencisi", h="Katlanmış Parşömen'i oku, ardından Thendal Grove'daki Xyton Silverwind ile konuş.", k={b=1007945297, h=2679805428} }
V[93791] = { b="Belann ile Konuş", h="Valanaar'daki Belann Windwood ile konuş.", k={b=1614064421, h=2520825165} }
V[93797] = { b="Rüzgârdaki Dallar", h="Valanaar'daki Belann Windwood'a bir Rüzgârla Dolu Dal getir.", k={b=3905914231, h=4063859464} }
V[94006] = { b="Büyük Ursera Ruhu", h="Valanaar'ın kuzeydoğusundaki şelalelerin yakınında Urs'endris ile konuş.", k={b=1188051302, h=539777920} }
V[94007] = { b="Canavarı Evcilleştirmek", h="Valanaar'daki Quel'ana Quickgale'e rapor ver.", k={b=1677736341, h=423061278} }
V[94013] = { b="Canavarı Evcilleştirmek", h="Gustberry Lowlands'te bir Vuldren Alpha'yı evcilleştirmek için Evcilleştirme Asası'nı kullan. Becerilerini geliştir, ardından Evcilleştirme Asası'nı Valanaar'daki Quel'ana Quickgale'e geri götür.", k={b=1677736341, h=2173541699} }
V[94050] = { b="Canavarı Eğitmek", h="Valanaar'daki Quel'dora Quickgale ile konuş.", k={b=2574330673, h=3540433324} }
V[94427] = { b="Kutsallık Dersi", h="Undercity'deki Tanis Alderwood ile konuş.", k={b=660463681, h=2918944331} }
V[94434] = { b="Kutsallık Dersi", h="Undercity'deki Tanis Alderwood'a 10 Keten Kumaş getir.", k={b=660463681, h=4160073562} }
V[94435] = { b="Kutsallık Dersi", h="Bandarion Keep'teki Danitha Morr'a dön.", k={b=660463681, h=4189600329} }
V[94436] = { b="Kutsallık Dersi", h="Bandarion Keep'teki Deathguard Billmuth ile konuş.$BYaşam Sembolü'nü kaybedersen yenisi için Danitha Morr'a dön.", k={b=660463681, h=591653325} }
V[94438] = { b="Kutsallık Dersi", h="Yaşam Sembolü'nü al ve Venomweb Vale'deki Deathguard Falgan'ı diriltmek için kullan.$BYaşam Sembolü'nü kaybedersen yenisi için Danitha Morr'a dön.", k={b=660463681, h=2575904727} }
V[94440] = { b="Kutsallık Dersi", h="Venomweb Vale'deki Scarlet Crusade askerlerinden Scarlet Crusade Saldırı Planları'nı ele geçir ve Bandarion Keep'teki Deathguard Billmuth'a dön.", k={b=660463681, h=92509022} }
V[94441] = { b="Kutsallık Dersi", h="Bandarion Keep'teki kalede Danitha Morr ile konuş.", k={b=660463681, h=2106506771} }
V[94638] = { b="Güç ve Merhamet", h="Shen'dar Highlands'te Ur'endra'yı bul ve öldür.", k={b=1258407623, h=133632165} }
V[94773] = { b="İlahi Lütuf", k={b=1257876966} }
V[94774] = { b="İlahi Lütuf", h="Stormwind'deki Yüce Rahibe Laurena ile konuş.", k={b=1257876966, h=3267135812} }
V[94775] = { b="İlahi Lütuf", h="Stormwind'deki Yüce Rahibe Laurena ile konuş.", k={b=1257876966, h=3267135812} }
V[94776] = { b="İlahi Lütuf", h="Stormwind'deki Yüce Rahibe Laurena ile konuş.", k={b=1257876966, h=3267135812} }
V[94777] = { b="İlahi Lütuf", h="Stormwind'deki Yüce Rahibe Laurena ile konuş.", k={b=1257876966, h=3267135812} }
V[94778] = { b="İlahi Lütuf", h="Stormwind'deki Yüce Rahibe Laurena ile konuş.", k={b=1257876966, h=3267135812} }
V[94779] = { b="İlahi Lütuf", h="Stormwind'deki Yüce Rahibe Laurena ile konuş.", k={b=1257876966, h=3267135812} }
V[94792] = { b="Canavarı Evcilleştirmek", h="Bir Rockhide Boar'u evcilleştirmek için Evcilleştirme Asası'nı kullan. Becerilerini geliştir, ardından Evcilleştirme Asası'nı Josephine Carson'a geri götür.", k={b=1677736341, h=3686691028} }
V[94793] = { b="Canavarı Eğitmek", h="Goldshire'daki Isaac Chan ile konuş.", k={b=2574330673, h=169142127} }
V[94817] = { b="Şaşırtıcı Işık", k={b=3020916941} }
V[94818] = { b="Yedek Plan", k={b=1050072881} }
V[94819] = { b="Yedek Plan", h="Ironforge'daki Yüce Rahibe Mims ile konuş.", k={b=1050072881, h=3688255350} }
V[94820] = { b="Yedek Plan", h="Ironforge'daki Yüce Rahibe Mims ile konuş.", k={b=1050072881, h=3688255350} }
V[94821] = { b="Şaşırtıcı Işık", h="Ironforge'daki Yüce Rahibe Mims ile konuş.", k={b=3020916941, h=3688255350} }
V[94822] = { b="Şaşırtıcı Işık", h="Ironforge'daki Yüce Rahibe Mims ile konuş.", k={b=3020916941, h=3688255350} }
V[94823] = { b="Şaşırtıcı Işık", h="Ironforge'daki Yüce Rahibe Mims ile konuş.", k={b=3020916941, h=3688255350} }
V[94824] = { b="Şaşırtıcı Işık", h="Ironforge'daki Yüce Rahibe Mims ile konuş.", k={b=3020916941, h=3688255350} }
V[94825] = { b="Şaşırtıcı Işık", h="Ironforge'daki Yüce Rahibe Mims ile konuş.", k={b=3020916941, h=3688255350} }
V[94826] = { b="Şaşırtıcı Işık", h="Ironforge'daki Yüce Rahibe Mims ile konuş.", k={b=3020916941, h=3688255350} }
V[94863] = { b="Canavarı Evcilleştirmek", h="Bir Gray Forest Wolf'u evcilleştirmek için Evcilleştirme Asası'nı kullan. Becerilerini geliştir, ardından Evcilleştirme Asası'nı Josephine Carson'a geri götür.", k={b=1677736341, h=3686691028} }
V[94864] = { b="Canavarı Evcilleştirmek", h="Bir Young Forest Bear'ı evcilleştirmek için Evcilleştirme Asası'nı kullan. Becerilerini geliştir, ardından Evcilleştirme Asası'nı Josephine Carson'a geri götür.", k={b=1677736341, h=3686691028} }
V[94911] = { b="Doğanın Çocuğu", h="Thunder Bluff'taki Turak Runetotem ile konuş.", k={b=228951213, h=14102527} }
V[94912] = { b="Doğanın Çocuğu", h="Stormwind'deki Sheldras Moontree ile konuş.", k={b=228951213, h=1416755282} }
V[94913] = { b="Moonglade", h="\"Teleport: Moonglade\" büyüsünü kullanarak Moonglade'e git. Vardığında Nighthaven köyündeki Dendrite Starblaze ile konuş.", k={b=1681948987, h=74323777} }
V[94914] = { b="Moonglade", h="\"Teleport: Moonglade\" büyüsünü kullanarak Moonglade'e git. Vardığında Nighthaven köyündeki Dendrite Starblaze ile konuş.", k={b=1681948987, h=74323777} }
V[94978] = { b="Canavarı Evcilleştirmek", h="Su kenarlarında bulunan bir Windsong Crawler'ı evcilleştirmek için Evcilleştirme Asası'nı kullan.$BBecerilerini geliştir, ardından Evcilleştirme Asası'nı Valanaar'daki Quel'ana Quickgale'e geri götür.", k={b=1677736341, h=2173541699} }
V[94979] = { b="Canavarı Evcilleştirmek", h="Gustberry Lowlands'te bir Ornery Galestrider'ı evcilleştirmek için Evcilleştirme Asası'nı kullan.$BBecerilerini geliştir, ardından Evcilleştirme Asası'nı Valanaar'daki Quel'ana Quickgale'e geri götür.", k={b=1677736341, h=2173541699} }
V[95034] = { b="Borç", h="The Sepulcher'daki Lumina Windsinger ile konuş.", k={b=3742884293, h=792145816} }
V[95036] = { b="Ayın Öptüğü Kılıç", h="The Sepulcher'daki Trevan Rol ile konuş ve ona ihtiyaç duyduğu malzemeleri getir.", k={b=833591386, h=1286232408} }
V[95042] = { b="Kor Taşı'nın Peşinde", h="Ashenvale'deki Ulric Frostveil'e bir Kor Taşı getir.", k={b=1465754289, h=1592062475} }
V[95111] = { b="Hafife Alınan Bir Yetenek", h="Ott ile konuş ve kılıcını dövmesini iste.", k={b=3199072266, h=697499193} }
V[95125] = { b="Ott'un Başyapıtı", h="Ott kılıcını döverken onu izle.", k={b=2646794110, h=979523316} }
V[95126] = { b="Ay Gümüşü Kılıç", h="Ott'un Başyapıtı'nı Silverpine Forest'taki Trevan Rol'e götür.", k={b=1859622636, h=47451803} }
V[95140] = { b="Yaşlı Ateşgöz", h="Silverpine Forest'taki Old Fire-Eye'ı yok etmek için Ay Gümüşü Kılıç'ı kullan.", k={b=224626989, h=841931577} }
V[95803] = { b="İyi Niyet Nişanesi", h="Rudolph Gelhardt'ın kellesini Undercity'deki Sylvanas Windrunner'a götür.", k={b=2616647825, h=633903255} }
V[95998] = { b="Açık Havada", h="Sohbet penceresine /sit yazarak Sam'in Basit Kamp Ateşi'nin yanına otur ve Güçlendirilmiş Dinlenme etkisini alana kadar bekle.", k={b=1503652632, h=2606633748} }
V[96031] = { b="Kampçılık 101: Dericilik", h="Ironforge'daki Gretta Finespindle ile konuşarak mesleğinde yeterlilik gösterdiğinde mesleğine özgü bir kamp eşyası üretmeyi öğren.", k={b=2619566908, h=404790073} }
V[96044] = { b="Kampçılık 101: Demircilik", h="Kharanos'taki Tognus Flintfire ile konuşarak mesleğinde yeterlilik gösterdiğinde mesleğine özgü bir kamp eşyası üretmeyi öğren.", k={b=3546084662, h=3067718608} }
V[96045] = { b="Kampçılık 101: Simya", h="Ironforge'daki Vosur Brakthel ile konuşarak mesleğinde yeterlilik gösterdiğinde mesleğine özgü bir kamp eşyası üretmeyi öğren.", k={b=2515214777, h=2105846477} }
V[96046] = { b="Kampçılık 101: Madencilik", h="Kharanos'taki Yarr Hammerstone ile konuşarak mesleğinde yeterlilik gösterdiğinde mesleğine özgü bir kamp eşyası üretmeyi öğren.", k={b=2755241176, h=4245124526} }
V[96204] = { b="Rüzgârbiçenin Gazabı", h="Lumina Windsinger'a eşlik et ve Fenris Keep'ten kaçmasına yardım et.", k={b=1459041428, h=2281101912} }
V[96779] = { b="Syndicate Sabotajı", h="Hillsbrad Foothills'teki Durnholde Keep'in içinde Lord Tomas'ı bul ve öldür. Ardından Myrokos Silentform'a dön.", k={b=2301926319, h=7376190} }
V[96781] = { b="Büyük Fikir Ne?", h="Barton'ın Keşif Raporu'nu cebinden çalarak ele geçir. Ardından raporu Ravenholdt Manor'daki Myrokos Silentform'a götür.", k={b=2364256530, h=3076474694} }
V[96782] = { b="Gizli Kurtarma", h="Alterac harabeleri arasında Perenolde Hanedanı Kılıcı'nı ve Perenolde Kraliyet Kalkanı'nı bul. Ardından bunları Myrokos Silentform'a götür.", k={b=2383792409, h=2620106466} }
V[96783] = { b="İçeri Giden Yol", h="Stromgarde Keep'e sızmak için Northfold Manor'dan bir Syndicate üniforması çal.", k={b=4072935214, h=3661177558} }
V[96784] = { b="Kılık Değiştirme Ustası", h="Syndicate üyesi kılığındayken Stromgarde Keep'in içinde gizli anlaşmadan haberi olan birini bul.", k={b=822284067, h=1241423022} }
V[96785] = { b="Kim Bilir", h="Stromgarde Keep'in içinde Anastasia'yı gizli anlaşmanın ayrıntılarını vermeye ikna edecek bir şey bul.", k={b=156149821, h=347499772} }
V[96786] = { b="Syndicate Tuzağı", h="Gizli anlaşmayı boz ve Syndicate'e verilecek nesneyi ele geçir. Ardından Ravenholdt Manor'daki Myrokos Silentform'a dön.", k={b=3020923983, h=2539711901} }
V[97065] = { b="Teraziyi Devir - Keefer'ın Melek Balığı", k={b=2695278788} }
V[97066] = { b="Teraziyi Devir - Brownell'ın Mavi Çizgili Yarışçısı", k={b=3316712246} }
V[97067] = { b="Teraziyi Devir - Dezian Kraliçe Balığı", k={b=1754121873} }
V[97286] = { b="Araştırma İzni", k={b=1315573572} }
V[97583] = { b="KIPIRDA.", h="Besleyici Balçık Çamuru satın al ve dost olduğun heyecanlı balçığına geri dön. Yorgun görünüyorsa dikkatini çekmek için onunla yeniden dans etmeyi dene.", k={b=3718528822, h=1607924860} }
V[98340] = { b="Büyük Kedi Ruhu", h="Moonglade'deki Nighthaven köyünde Dendrite Starblaze ile konuş.", k={b=3316617036, h=4094500223} }
V[98341] = { b="Büyük Rüzgârdoğan Kedi Ruhu", h="Moonglade'in güney kesiminde Saeyleenan'ın Avatarı'nı bul ve rüzgârdoğan kedinin doğası hakkında seninle paylaşacaklarını öğren.", k={b=2393074932, h=1877364734} }
V[98342] = { b="Büyük Kedi Ruhu", h="Stormrage Barrow Den'den Diş Kalıntısı'nı, Pençe Kalıntısı'nı ve Sessiz Gölge Kalıntısı'nı kurtar ve Büyük Kedi Ruhu'na geri götür.", k={b=3316617036, h=3527997230} }
V[98362] = { b="Thunder Bluff'a", h="Thunder Bluff'a dön ve Elder Rise'daki Turak Runetotem ile konuş.", k={b=1266277329, h=3795606683} }
V[98393] = { b="Büyük Kedi Ruhu", h="Moonglade'deki Nighthaven köyünde Dendrite Starblaze ile konuş.", k={b=3316617036, h=4094500223} }
V[98394] = { b="Büyük Kedi Ruhu", h="Moonglade'in güney kesiminde Büyük Kedi Ruhu'nu bul ve kedinin doğası hakkında seninle paylaşacaklarını öğren.", k={b=3316617036, h=4063218914} }
V[98396] = { b="Büyük Kedi Ruhu", h="Stormrage Barrow Den'den Diş Kalıntısı'nı, Pençe Kalıntısı'nı ve Sessiz Gölge Kalıntısı'nı kurtar ve Büyük Kedi Ruhu'na geri götür.", k={b=3316617036, h=3527997230} }
V[98397] = { b="Darnassus'a", h="Darnassus'a dön ve Cenarion Enclave'deki Mathrengyl Bearwalker ile konuş.", k={b=1857124508, h=148448383} }
V[98404] = { b="Büyük Rüzgârdoğan Kedi Ruhu", h="Stormrage Barrow Den'den Diş Kalıntısı'nı, Pençe Kalıntısı'nı ve Sessiz Gölge Kalıntısı'nı kurtar ve Saeyleenan'ın Avatarı'na geri götür.", k={b=2393074932, h=323069121} }
V[98405] = { b="Büyük Kedi Ruhu", h="Moonglade'in güney kesiminde Büyük Kedi Ruhu'nu bul ve kedinin doğası hakkında seninle paylaşacaklarını öğren.", k={b=3316617036, h=4063218914} }
V[98471] = { b="Yüce Magister'den Mesaj", h="Alterac Mountains'da The Uplands'e bakan yamaçlarda Elaadrin Evengale ile buluş.", k={b=2474664188, h=1643852732} }
V[98574] = { b="Kutsal Muhtıra", h="Kutsal Muhtıra'yı oku ve Anvilmar'daki Branstock Khalder ile konuş.", k={b=2049503210, h=1654961540} }
V[98575] = { b="Lekelenmiş Tablet", h="Lekelenmiş Tablet'i oku ve Valley of Trials'taki Den'in içinde Nartok ile konuş.", k={b=2241326506, h=2333807645} }
V[98576] = { b="Gliflerle Dolu Parşömen", h="Gliflerle Dolu Parşömen'i oku ve Valley of Trials'taki Den'in girişine yakın Mai'ah ile konuş.", k={b=462563895, h=1981551890} }
V[98601] = { b="Zorlu Bir Yol", h="Kutsanmış Parşömen'i oku ve Deathknell'deki kilisede Aramis Hammerhand ile konuş.", k={b=2869928813, h=880375168} }
V[98731] = { b="Büyük Kedi Ruhu'nun Kutsamaları", k={b=435817067} }
V[98738] = { b="Büyük Rüzgârdoğan Kedi Ruhu'nun Kutsamaları", k={b=3878673139} }
V[98739] = { b="Büyük Kedi Ruhu'nun Kutsamaları", h="Dendrite ile konuş.", k={b=435817067, h=2145572235} }
V[98977] = { b="Yaşlı Mossheart", k={b=843789480} }
V[98983] = { b="Yaşlı Frostleaf", k={b=1189397688} }
