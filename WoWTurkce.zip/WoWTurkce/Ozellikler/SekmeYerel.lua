-- Yetenek/büyü kitabı penceresindeki başlık sekmeleri (Primary, Secondary...) için Türkçe düzeltme.
local G = WoWTurkce

local METIN = { ["Primary"] = "Birincil", ["Secondary"] = "İkincil" }
local KOKLER = { "PlayerSpellsFrame", "ProfessionsBookFrame", "SpellBookFrame", "SpellBookProfessionFrame" }

local function yazilar(f, d)
	if d > 10 then return end
	if f.IsShown and not f:IsShown() then return end
	if f.GetRegions then
		for _, r in ipairs({ f:GetRegions() }) do
			if r.GetObjectType and r:GetObjectType() == "FontString" and r.GetText then
				local t = r:GetText()
				if type(t) == "string" and not G.gizli(t) and METIN[t] then r:SetText(METIN[t]) end
			end
		end
	end
	if f.GetChildren then
		for _, c in ipairs({ f:GetChildren() }) do yazilar(c, d + 1) end
	end
end

G.basla(function()
	C_Timer.NewTicker(0.5, function()
		if not G.ayar("acik") then return end
		for _, ad in ipairs(KOKLER) do
			local f = _G[ad]
			if f and f.IsShown and f:IsShown() then pcall(yazilar, f, 0) end
		end
	end)
end)

-- "Beceri" penceresi: meslek ve beceri adlarının yanına İngilizcesini ekle (Türkçe (English) stili; ayar: stilBuyu)
local BECERI = {
	["Meslekler"] = "Professions", ["İkincil Beceriler"] = "Secondary Skills", ["Silah Becerisi"] = "Weapon Skills",
	["Zırh Becerisi"] = "Armor Proficiencies", ["Diller"] = "Languages", ["Zırh Eğitimi"] = "Armor Proficiencies",
	["Madencilik"] = "Mining", ["Deri Yüzme"] = "Skinning", ["Aşçılık"] = "Cooking", ["İlk Yardım"] = "First Aid",
	["Balıkçılık"] = "Fishing", ["Simya"] = "Alchemy", ["Demircilik"] = "Blacksmithing", ["Mühendislik"] = "Engineering",
	["Efsunculuk"] = "Enchanting", ["Bitkicilik"] = "Herbalism", ["Dericilik"] = "Leatherworking", ["Terzilik"] = "Tailoring",
	["Çilingirlik"] = "Lockpicking", ["Binicilik"] = "Riding", ["Zehirler"] = "Poisons", ["Arkeoloji"] = "Archaeology",
}
local beceriKok
local function baslikVar(f, d)
	if d > 5 or (f.IsShown and not f:IsShown()) then return false end
	if f.GetRegions then
		for _, r in ipairs({ f:GetRegions() }) do
			if r.GetObjectType and r:GetObjectType() == "FontString" and r.GetText then
				local t = r:GetText()
				if type(t) == "string" and not G.gizli(t) and (t == "Beceri" or t == "Skills") then return true end
			end
		end
	end
	if f.GetChildren then
		for _, c in ipairs({ f:GetChildren() }) do if baslikVar(c, d + 1) then return true end end
	end
	return false
end
local function beceriYaz(f, d)
	if d > 14 or (f.IsShown and not f:IsShown()) then return end
	if f.GetRegions then
		for _, r in ipairs({ f:GetRegions() }) do
			if r.GetObjectType and r:GetObjectType() == "FontString" and r.GetText then
				local t = r:GetText()
				if type(t) == "string" and not G.gizli(t) then
					local en = BECERI[t]
					if en then
						local yeni = G.adStil("stilBuyu", t, en, "|cffaaaaaa")
						if yeni and yeni ~= t then r:SetText(yeni) end
					end
				end
			end
		end
	end
	if f.GetChildren then
		for _, c in ipairs({ f:GetChildren() }) do beceriYaz(c, d + 1) end
	end
end
G.basla(function()
	C_Timer.NewTicker(0.5, function()
		if not G.ayar("acik") then return end
		if not (beceriKok and beceriKok:IsShown()) then
			beceriKok = nil
			for _, c in ipairs({ UIParent:GetChildren() }) do
				if c:IsShown() and not (c.IsForbidden and c:IsForbidden()) and pcall(baslikVar, c, 0) and baslikVar(c, 0) then beceriKok = c; break end
			end
		end
		if beceriKok then pcall(beceriYaz, beceriKok, 0) end
	end)
end)

-- Görev pencerelerinde (başlık, açıklama, hedef, takip listesi) İngilizce kalan "Mining" -> "Madencilik"
local function miningDuzelt(tr)
	if type(tr) ~= "string" or not tr:find("Mining", 1, true) then return tr end
	return (tr:gsub("()%f[%a]Mining%f[%A]", function(pos)
		local once = tr:sub(math.max(1, pos - 12), pos - 1)
		local sonra = tr:sub(pos + 6, pos + 11)
		if once:find("Canyon $") or once:find("Deepmountain $") or once:find("Deep Mountain $") or sonra:find("^ Guild") or sonra:find("^ and ") or sonra:find("^ Co") then return nil end
		return "Madencilik"
	end))
end
local GOREV_KOKLER = { "QuestFrame", "QuestLogFrame", "QuestMapFrame", "QuestLogDetailFrame", "QuestLogPopupDetailFrame", "ObjectiveTrackerFrame", "QuestWatchFrame", "WorldMapFrame", "GossipFrame" }
local function gorevYaz(f, d)
	if d > 14 or (f.IsForbidden and f:IsForbidden()) or (f.IsShown and not f:IsShown()) then return end
	if f.GetRegions then
		for _, r in ipairs({ f:GetRegions() }) do
			if r.GetObjectType and r:GetObjectType() == "FontString" and r.GetText then
				local t = r:GetText()
				if type(t) == "string" and not G.gizli(t) and t:find("Mining", 1, true) then
					local y = miningDuzelt(t)
					if y ~= t then r:SetText(y) end
				end
			end
		end
	end
	if f.GetChildren then
		for _, c in ipairs({ f:GetChildren() }) do gorevYaz(c, d + 1) end
	end
end
G.basla(function()
	C_Timer.NewTicker(0.4, function()
		if not G.ayar("acik") then return end
		for _, ad in ipairs(GOREV_KOKLER) do
			local f = _G[ad]
			if f and f.IsShown and f:IsShown() then pcall(gorevYaz, f, 0) end
		end
	end)
end)
