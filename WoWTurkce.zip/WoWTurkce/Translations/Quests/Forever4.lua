if not WoWTurkce.FOREVER then return end -- yalnızca Classic Forever
-- Classic Forever'a özel görevler 4
-- b=başlık, a=açıklama, h=hedef, i=ilerleme, t=tamamlama
-- k = çevrilen İngilizce metnin parmak izi (metin değişirse çeviri gösterilmez, yeniden kaydedilir)
local V = WoWTurkce.Veri

V[490] = { b="Ödül: Gnarlpine Furbolg'ları", h="Darnassus'un dışındaki yolda bulunan Shayla Nightbreeze, ona 15 Gnarlpine Dişi getirmeni istiyor.", k={b=2114853015, h=3506857499} }
V[79975] = { b="Kartal Yumruğu", h="Su serpintisi havayı nemlendiriyor, manzara inanılmaz.", k={b=1828847788, h=3098146725} }
V[87288] = { b="Yumuşak Pars Postları", h="6 Yumuşak Nightsaber Postu'nu Aldria'ya götür.", k={b=3646019798, h=2601311752} }
V[87760] = { b="Kutsal Dalgıç", h="Bir Stormscale Beastmistress bul, onu öldür ve Derin Hâkimiyet Asası'nı getir.", k={b=1347731387, h=878247503} }
V[91743] = { b="Haylaz Kemirgenler", h="Northshire Valley'deki kobold'lardan 8 Çalıntı Kitap'ı geri al ve Brother Paxton'a götür.", k={b=3052535775, h=2310307382} }
V[91745] = { b="Maden Danışmanı", h="Northshire Valley'deki Echo Ridge Mine'ın dışında Kelsey Fargo ile konuş.", k={b=3770182578, h=2904393291} }
V[91746] = { b="Elmpaw'ın Kafası", h="Elmpaw'ın Kafası'nı Goldshire yakınlarındaki Helene Peltskinner'a teslim et.", k={b=2080272432, h=2023874021} }
V[91751] = { b="Kaba Kurt Postları", h="Elwynn Forest'taki kurtları yüzerek 7 Kaba Kurt Postu elde et, ardından bunları Goldshire yakınlarındaki Helene Peltskinner'a teslim et.", k={b=2332946026, h=2219872545} }
V[91752] = { b="Büyük Resim", h="Shinyfinder Narf'tan bir Çuval \"Resimli\" Kitap'ı al. Çuvalı Northshire Abbey'nin hemen içindeki Marshal McBride'a götür.", k={b=4021877076, h=1382255289} }
V[91753] = { b="Büyülü Bir Ders", h="Tower of Azora'daki Kitta Firewind senden 3 Işıltılı Kalıntı toplamanı istiyor.$BKobold Geomancer'ların düşürdüğü Kaba Mum Heykelcikler'i büyü sökümüne tabi tutarak Işıltılı Kalıntı elde edebilirsin.", k={b=3337535559, h=3493756632} }
V[91758] = { b="Şu Kobold'u Takip Et!", h="Northshire Abbey'nin arkasındaki ahırın yakınında Tordrin Sternblade ile konuş.", k={b=2836682980, h=441786058} }
V[91772] = { b="Şşş! Kobold Avlıyoruz", h="Kobold izlerini takip et ve bulgularınla birlikte Kobold İz Sürme Takımı'nı Goldshire'daki Marshal Dughan'a götür.", k={b=2681626627, h=1930389900} }
V[91775] = { b="Kitap İadesi", h="6 Kayıp Kitap'ı ve \"Elementallerle Eğlence\" kitabını bul ve Marshal Dughan'a geri götür.", k={b=4062346992, h=3377984129} }
V[91777] = { b="Nadir Kitaplar", h="\"Meraklı Genç Büyücüler İçin Yer Büyüsü\" ve \"Arkan Açıklayıcı: Basit Sözlerle Büyülü Şeyler\" kitaplarını kurtar ve Northshire Abbey'nin içindeki Brother Paxton'a geri götür.", k={b=2427240877, h=4275917036} }
V[91920] = { b="Vahşi Gözler", h="3 murloc gözü topla ve Sepulcher'daki Apothecary Renferrel'e götür.", k={b=3827847819, h=2001366055} }
V[91921] = { b="Quinn'e Dönüş (Yine)", h="Quinn'in iksirini Sepulcher'ın kuzeyindeki Ivar Patch'te bulunan Quinn Yorick'e götür.", k={b=47754931, h=2928749073} }
V[92124] = { b="Kitap Sayımı", h="Kütüphanede Brother Paxton'ın yardımcısı Daniel ile konuş.", k={b=1187814110, h=3628788179} }
V[92456] = { b="Yeşil Bir Numune", h="Stormwind City'deki Shylamiir için City of Dalaran'dan bir Fel Aşılı Çiçek topla.", k={b=2882312825, h=3934648694} }
V[92457] = { b="Arkan Açlığı", h="Dalaran'ın dışındaki Başbüyücü Modera için City of Dalaran'ın içinde 8 Seeking Remnant, 8 Saturated Remnant ve 8 Mana Echo yen.", k={b=2621157469, h=2125862010} }
V[92458] = { b="Bozulmanın Kalbi", h="City of Dalaran yakınlarındaki Başbüyücü Modera'nın Sureti için Arkan Zerre'yi topla.", k={b=1647038911, h=4170758019} }
V[92460] = { b="Reşit Olmak", h="Thendal Grove'da Gün Arayıcı Rorian ile konuş.", k={b=3400591268, h=3717162968} }
V[92461] = { b="Dengede Ahenk", h="Thendal Grove'da 8 Vuldren Juvenile öldür.", k={b=3709536000, h=3061803237} }
V[92462] = { b="İstila Soruşturması", h="Thendal Grove'da 8 Pesky Cirrusfly öldür.", k={b=1528211085, h=177228359} }
V[92463] = { b="Cirrusfly Kraliçesi", h="Thendal Grove'daki Cirrusfly Kraliçesi'ni yok et.", k={b=4114310919, h=1559808523} }
V[92464] = { b="Elemental Huzursuzluk", h="Thendal Grove'da Yala Windwatcher ile konuş.", k={b=1702889661, h=3074581661} }
V[92465] = { b="Kışkırtıcılar", h="Thendal Grove'da 6 Roiling Wind ve 7 Al'Aketh Convert öldür.", k={b=3424002771, h=239489151} }
V[92466] = { b="Toprağın Çağrısı", h="Bir Akir Mühür Yüzüğü'nü Rüzgâr Biçimci Boro'ya götür.", k={b=743682218, h=2760062024} }
V[92467] = { b="Toprağın Çağrısı", h="Rise of Spirits'i bul ve Toprak Saptası'nı iç.", k={b=743682218, h=2680517238} }
V[92468] = { b="Toprağın Çağrısı", h="Ham Kuvars'ı Thendal Grove'daki Rüzgâr Biçimci Boros'a götür.", k={b=743682218, h=1627186811} }
V[92469] = { b="Rorian'a Dönüş", h="Al'Aketh hakkındaki haberleri Thendal Grove'daki Gün Arayıcı Rorian'a ilet.", k={b=1001033011, h=3290116137} }
V[92470] = { b="Habis Ana", h="Thendal Grove'da 8 Ursera Scavenger öldür ve in anası Urs'anah'ın kafasını topla.", k={b=4279452118, h=2265438989} }
V[92471] = { b="Fırtınaların Aetheen'i", h="Thendal Grove'da Fırtınaların Aetheen'i ile konuş.", k={b=1515099873, h=454455147} }
V[92472] = { b="Sonraki Adım", h="Shen'dar Village'daki Zabıta Aonda'ya rapor ver.", k={b=4130477409, h=822646178} }
V[92473] = { b="Saldırgan İstila", h="Thendal Grove'daki Scrawny Ursera'lardan 6 Cılız Ursera Pençesi topla.", k={b=3585487308, h=3470275099} }
V[92474] = { b="Zarafetle Düşmek", h="Thendal Grove'daki gözetleme kulesinin tepesinden atla ve düşüşünü yavaşlatmak için Havada Yürüme yeteneğini kullan.", k={b=3747127727, h=2312116988} }
V[92489] = { b="Ezici Güç", h="Stormwind City'deki Yüce Büyücü Andromath için City of Dalaran'daki Mana Elementali'ni öldür.", k={b=3590904393, h=3072751309} }
V[92514] = { b="Shen'dar Village'a Hoş Geldin", h="Shen'dar Village'da Illaya Amberwind ve Coriella Calmbreeze ile konuş.", k={b=3590723549, h=1643419330} }
V[92515] = { b="Prideclaw Sorunu", h="Shen'dar Highlands'deki Prideclaw'lardan 10 Prideclaw Postu topla.", k={b=835851041, h=451808256} }
V[92516] = { b="Hipogrif Tacizi", h="Shen'dar Highlands'de 8 Hippogryph Youth, 6 Hippogryph Protector ve bir Hippogryph Matriarch öldür.", k={b=1072801317, h=1169097993} }
V[92517] = { b="Suç Unsuru", h="Shen'dar Highlands'de 10 Highlands Bandit ve liderleri \"Badwind\" Bennic'i öldür.", k={b=1199762847, h=1161561948} }
V[92528] = { b="İnananların Arasında", h="Shen'dar Highlands'de tarikatın niyetlerini öğrenmek için Falaath Village'ı dolaş.", k={b=2998880523, h=1187897678} }
V[92529] = { b="Falaath Village", h="Falaath Village'ın girişi yakınındaki Misyoner Jasaan'a rapor ver.$BAkir Nişanı'nı kaybedersen, etkisini yeniden kazanmak için Shen'dar Village'daki Sania Silverstream ile konuş.", k={b=2903715418, h=705967166} }
V[92544] = { b="Al'Aketh Haydutları", h="Thendal Grove'da 6 Al'Aketh Brute, 4 Al'Aketh Neophyte ve Malduko Cloudcrush'ı öldür.", k={b=1918696842, h=171352390} }
V[92550] = { b="Highlands'de Kargaşa", h="Falaath Village harabelerine git, 6 Al'Aketh Stormcaller ve 4 Living Lightning öldür ve Komutan Cyclas'ın kafasını al.", k={b=3955155328, h=2710356223} }
V[92551] = { b="Çalınan Erzak", h="Shen'dar Highlands'deki Falaath Village'dan 10 paket Çalıntı Shen'dar Erzakı topla.", k={b=552589743, h=423945658} }
V[92553] = { b="Kilerleri Yeniden Doldurmak", h="Shen'dar Highlands'in dört bir yanındaki yaratıklardan 3 Küçük Yumurta ve 8 Strider Eti topla.", k={b=132204428, h=1579067387} }
V[92753] = { b="Deadmines'ta Yıkım", h="Deadmines'ta gizlenmiş demirhaneyi bul ve Ekstra Yıkıcı Patlayıcılar'ı yakınına yerleştir. Ardından Deadmines çıkışında Alba Fairmoon ile buluş.", k={b=3350360826, h=4046141892} }
V[93739] = { b="Horde'u Keşfetmek", h="Daha fazla talimat almak için Grommash Hold'daki Nazgrel ile konuş. Aldığın talimatları kullanarak Vol'jin'i, Cairne Bloodhoof'u ve Leydi Sylvanas Windrunner'ı bul ve onlarla konuş.", k={b=1499033552, h=1095632103} }
V[93963] = { b="İttifak'ı Keşfetmek", h="Daha fazla talimat almak için Stormwind Keep'teki Randal Emerson ile konuş. Aldığın talimatları kullanarak Kral Magni Bronzebeard'ı, Yüce Tamirci Mekkatorque'u ve Tyrande Whisperwind'i bul ve onlarla konuş.", k={b=1504234423, h=1360095108} }
V[94947] = { b="Azeroth'a Hoş Geldin", h="Skyborne Portalı'nı kullanarak Stormwind'e git ve Stormwind Keep'teki Bolvar Fordragon'a rapor ver.", k={b=2825538001, h=3860806673} }
V[95065] = { b="Balık Vakti", h="1 Parlak Süs ve 3 Gece Solucanı'nı Stormwind limanındaki Gilbert Gray'e götür.", k={b=4246664661, h=1715561170} }
V[95161] = { b="Seni Sevdiğimi Unutma", h="Kana Bulanmış Mektup'u Duskwood'daki Avette Fellwood'a teslim et.", k={b=701676161, h=309128648} }
V[95350] = { b="Azeroth'a Hoş Geldin", h="Orgrimmar'a git ve Valley of Wisdom'daki Thrall ile konuş.", k={b=2825538001, h=3737117085} }
V[95817] = { b="Rotgath Stonebeard", h="Ironforge'daki Great Forge yakınlarında Rotgath Stonebeard ile buluş.", k={b=2036870597, h=470277247} }
V[95883] = { b="İşkence Görmüş Ruh", h="Silverpine Forest'taki Beren's Peril'de bulunan yakındaki ölümsüzlerden bir İşkence Görmüş Ruh topla.", k={b=3273309538, h=257460364} }
V[95884] = { b="Adak Taşı", h="Silverpine Forest'taki Beren's Peril'de Adak Taşı'nı bul.", k={b=1947886719, h=2621509789} }
V[95885] = { b="Kan Adağı", h="İşkence Görmüş Ruh'u kullanarak Beren's Peril'deki Adak Taşı'nda bir kan adağı sun.", k={b=2395485787, h=1235078370} }
V[95981] = { b="Yolları Gözetlemek", h="Sepulcher'daki Shadow Priest Allister için 8 Dalaran Wizard ve 8 Dalaran Watcher öldür.", k={b=1263481492, h=3716539411} }
V[96821] = { b="Bacakları Kırmak", h="Güney Durotar'da 6 Ridgeshade Creeper ve 6 Ridgeshade Lurker öldür, ardından Razor Hill'deki Gar'thok'a rapor ver.", k={b=1026629887, h=535573133} }
V[96822] = { b="Onur İçin", h="Tiragarde Keep'in dış çevresinden Akıncı Savaş Baltası'nı, Akıncı Yayı'nı ve Akıncı Kalkanı'nı topla, ardından bunları Razor Hill'deki Turroc'a geri götür.", k={b=267599922, h=257818154} }
V[96825] = { b="Bu Meyve Isırabilir", h="Razor Hill'deki Aşçı Torka, kasabanın batısındaki Razormane Grounds'tan 8 Dikenli Armut Meyvesi toplamanı istiyor.", k={b=899574451, h=721546753} }
V[96873] = { b="Baş Belası", h="Sen'jin Village'daki Pa'zula senden 3 Işıltılı Kalıntı toplamanı istiyor. Echo Isles'taki trollerin düşürdüğü Lanetli Kolyeler'i büyü sökümüne tabi tutarak Işıltılı Kalıntı elde edebilirsin.", k={b=1539874855, h=1690489046} }
V[96874] = { b="Omurga Baltası", h="Orgrimmar'daki Ug'thok, Thunder Ridge'deki hayvanlardan 5 Yıpranmış Diken ile birlikte 5 Kaba Bileği Taşı toplamanı istiyor.", k={b=28585406, h=79733368} }
V[96875] = { b="Thunder Ridge'in Canavarları", h="Orgrimmar'daki Kamari, Thunder Ridge'deki hayvanlardan 5 Kaba Kertenkele Derisi ile birlikte 2 İşlenmiş Hafif Deri toplamanı istiyor.", k={b=4026631681, h=2652139895} }
V[96876] = { b="Ukor'un Kayıp Çantası", h="Çantayı güney Durotar'daki Ukor'a geri götür.", k={b=1038763418, h=2675871865} }
V[96877] = { b="Halikor'un Toynağı", h="Halikor'un Toynağı'nı Orgrimmar'a teslim et.", k={b=1902988942, h=392611052} }
V[96984] = { b="Bozulmanın Kalbi", h="Tarren Mill'deki Magus Wordeen Voidglare için City of Dalaran'da Arkan Zerre'yi topla.", k={b=1647038911, h=3957929130} }
V[96986] = { b="Mezar Şövalyesi", h="Tarren Mill'deki Melisara için City of Dalaran'da Mezar Şövalyesi Atrexis'i yen.", k={b=1391729664, h=1891697608} }
V[96987] = { b="Fırsatçı Eğitim", h="Kanalizasyon girişinin yakınındaki Rexxie Copperclutch için City of Dalaran'dan \"Dalaran'ın Kuruluşu\" kitabını topla.", k={b=2357211364, h=544068457} }
V[96988] = { b="Gücün Kaynağı", h="Undercity'deki Doktor Martin Felben için City of Dalaran'da 6 Çatlak Nöbetçi Çekirdeği topla.", k={b=2801165496, h=1150569791} }
V[97220] = { b="Philmor'un İyiliği", h="Kapı Evi Sevkiyatı'nı Trade District'teki Trias'ın Peynir dükkânında bulunan depo girişine götür.", k={b=3582832817, h=353573157} }
V[97222] = { b="Kapı Evi Malları", h="Kapı Evi Sevkiyatı'nı Trias'ın dükkânındaki merdivenlerden yukarı taşı ve kapının önüne bırak.", k={b=1777911654, h=2094360595} }
V[97223] = { b="Bloodtalon Anası", h="Bloodtalon Anası'nın Yumurtaları'nı Sen'jin Village'daki Xar'Ti'ye götür.", k={b=1263818446, h=3252349673} }
V[97225] = { b="Unutulmuş Loa Putları", h="Echo Isles'tan 8 Unutulmuş Loa Putu topla. Bunları Sen'jin Village'daki Usta Gadrin'e götür.", k={b=1947049492, h=1106256166} }
V[97234] = { b="Okuma Odası", h="Paketlenmiş okuma malzemesini Stormwind kütüphanesine götür.", k={b=4001259644, h=2000686420} }
V[97236] = { b="Githyiss'in Dişi", h="Githyiss'in Dişi'ni Aldrassil'de örümcek araştırmalarıyla ilgilenen birine teslim et.", k={b=1297916202, h=2555666044} }
V[97237] = { b="Raflar Seçildi", h="Kütüphanenin çeşitli yerlerindeki okuma malzemelerinin her birini bul, ardından Stormwind's Park'taki Roy Lewells'e dön.", k={b=3520246823, h=2450910679} }
V[97242] = { b="Yelmak'ın Karışımı", h="Valley of Honor'daki su akıntılarının çevresinde yetişen Saz ve Mızrak Otları'ndan birkaç dal kes ve Yelmak's Alchemy and Potions'taki Kor'geld'e dön.", k={b=3107563835, h=1143069353} }
V[97246] = { b="Yemek Cazibesi", h="Borstan's Firepit'i ziyaret et ve ona Thatog'un Migi'nin öğle yemeğini bizzat teslim etmeni istediğini söyle.", k={b=3426208983, h=2703548273} }
V[97249] = { b="En Sevdiği Yemek", h="Migi'nin Öğle Yemeği'ni Grommash Hold'un arkasındaki Migi'ye götür.", k={b=2658544685, h=3082586202} }
V[97263] = { b="Paketiniz Geldi", h="Eldrun'ın yanlış yere gitmiş paketini teslim et.", k={b=1573032457, h=2557384299} }
V[97275] = { b="Whuut'un Acelesi Ne", h="Yelmak'ın İksiri'ni Whuut'a ver.", k={b=3331319736, h=1158035807} }
V[97279] = { b="Kayıp Silahlar", h="6 Terk Edilmiş Eğitim Silahı topla, ardından Den'deki Kzan Thornslash'e dön.", k={b=931862721, h=3660736977} }
V[97281] = { b="Kaynayan Bir Fırtına", h="Donuk Fırtınalı Küre'yi Drygulch Ravine yakınlarındaki Rezlak'a götür.", k={b=2917424742, h=2852985491} }
V[97282] = { b="Fırtınalı Potansiyel", h="5 Yüklü Gök Gürültüsü Kertenkelesi Organı'nı Drygulch Ravine yakınlarındaki Rezlak'a götür.", k={b=4016263779, h=3559265661} }
V[97290] = { b="Bitmeyen İşkence", h="Bulgularını Undercity'deki Baş Simyager Faranell'e bildir.", k={b=3499235206, h=4093225620} }
V[97326] = { b="Taşlardan Dinlenceye", h="8 Pürüzsüz Kaya'yı Grommash Hold'un arkasındaki Thra'ya geri götür.", k={b=1182357179, h=1949613656} }
V[97485] = { b="Bluff Gelenekleri", h="Şifacı Nida'dan bir Ot Demeti, büyü malzemecisi Nata'dan bir Sedir Dalı Demeti, deri işçiliği malzemecisi Mahu'dan Sinir İpliği ve aşçılık malzemecisi Naal'dan Tören Çakmaktaşı ve Kavı satın al.$BEşyaları birleştir ve tütsüyü Hunter's Rise'ın tepesinden serp.", k={b=2477295883, h=462854306} }
V[97891] = { b="Hızlı İksir Ulağı", h="Kararsız İksir'i süre dolmadan Apothecarium'daki Doktor Martin Felben'e götür.", k={b=284952570, h=1943238896} }
V[97894] = { b="Auberdine'da İşler", h="Darkshore'daki Auberdine'da Gorbold Steelhand'in durumunu kontrol et.$BBorgus, Stormwind Harbor'ın en güneydeki iskelesinde seni oraya götürebilecek bir gemi olduğundan bahsetti.", k={b=3615321495, h=1610451092} }
V[97914] = { b="Ufukları Genişletmek", h="Thundris'in Mektubu'nu Stormwind'deki Baros Alexston'a götür.$BThundris, Auberdine'da seni oraya götürebilecek bir gemi olduğundan bahsetti.", k={b=4145390911, h=1525560483} }
V[97926] = { b="İdare Etmek", h="Alexston'ın Cevabı'nı Darkshore'daki Auberdine'da bulunan Thundris Windweaver'a götür.", k={b=1070469199, h=2396875764} }
V[97977] = { b="Doğanın Çağrısı", h="4 Gnarlpine Totemi topla ve Tarindrella'ya götür.", k={b=3206230659, h=3283946147} }
V[97985] = { b="Gürleyen Yürekler", h="Thousand Needles'taki Stormheart'ı öldür ve kalbini al.", k={b=2439241156, h=4121182661} }
V[98013] = { b="Kabaran Kuvvetler", h="Grove of the Ancients'taki Arbal için 12 Stormscale Myrmidon, 8 Stormscale Sorceress ve 6 Stormscale Warrior yok et.", k={b=286005836, h=4103869233} }
V[98025] = { b="ARANIYOR: Jai'vhanel", h="Jai'vhanel olarak bilinen baykuşu bul, öldür ve tüylerinden birini al. Kara baykuş en son Ameth'Aran harabelerinin kuzeyinde, dağ eteğinin yakınında görüldü. Jai'vhanel'in ölümünü Auberdine'daki Gözcü Glynda Nal'Shea'ya bildir.", k={b=3681338778, h=1188222575} }
V[98028] = { b="Baron Marinous", h="Bulanık Su Küresi'ni Darkshore'daki Grove of the Ancients'ta bulunan Onu'ya götür.", k={b=1633194981, h=3103460631} }
V[98042] = { b="Her Şey Eğlence ve Oyun, Ta Ki...", h="Darkshore'daki Master's Glaive'de bir Twilight Disciple'dan ya da Thug'dan bir Eşsiz Göz elde et ve Auberdine'da onu almaya razı olacak birini bul.", k={b=610172099, h=1748722860} }
V[98046] = { b="Toprağın Tacı", h="Boşaltılmış Kap'ı Darnassus'taki Temple of the Moon'da bulunan Lariia'ya götür.", k={b=170174008, h=1586153391} }
V[98065] = { b="Toprağın Tacı", h="Ay Kuyusu Kalıntıları'nı Darnassus'taki Temple of the Moon'da bulunan Tyrande Whisperwind'e götür.", k={b=170174008, h=228553844} }
V[98067] = { b="Gözcülerin Gözleri", h="Darnassus'taki Temple of the Moon'da bulunan Gözcü Dalia Sunblade için Cenarion Hold derinliklerinin girişine, Darnassus Bankası'na, Craftsman's Terrace Hanı'na ve Şehir Kapısı'na Gözcü Baykuşları yerleştir.", k={b=3638900358, h=2238885761} }
V[98190] = { b="Ailenin Bir Dostu", h="Menethil Heykelciği'ni Stormwind Keep'teki Yüce Lord Bolvar Fordragon'a götür.", k={b=2690226966, h=3756709200} }
V[98191] = { b="Ailenin Bir Dostu", h="Menethil Heykelciği'ni Cathedral of Light'taki Lord Grayson Shadowbreaker'a götür.", k={b=2690226966, h=3811787959} }
V[98219] = { b="Utanmış Teğmen", h="Hillsbrad Foothills'teki Southshore'da Teğmen Farren Orinelle ile konuş.", k={b=1832304721, h=2497438168} }
V[98251] = { b="Asla Geri Dönmeyecek", h="6 Shadowhorn Stag ve 6 Ashenvale Bear öldür ve Fallen Sky Lake'in kuzeybatısındaki Va'xug Firefure'a dön.", k={b=2954128819, h=3239828047} }
V[98252] = { b="Boşluk Yolu", h="Va'xug'un Eye of Kilrogg'una ana Ashenvale yoluna giden yolu göster.", k={b=1482303045, h=353585556} }
V[98298] = { b="Arugal'ın Ahmaklığı", h="6 Worgen Parçası'nı The Sepulcher'daki Dalar Dawnweaver'a götür.", k={b=289451770, h=1002199119} }
V[98299] = { b="Yayılmayı Durdur", h="The Sepulcher'daki Dalar Dawnweaver için 5 Sickly Refugee ve 5 Haggard Refugee öldür.", k={b=286055979, h=3190335526} }
V[98300] = { b="Ironforge'a Haber", h="Howin'in Mektubu'nu Ironforge'daki Kral Magni Bronzebeard'a teslim et.", k={b=991133327, h=584827504} }
V[98313] = { b="Daha Fazla İnceleme İçin", h="Whelgar Kalıntı Paketi'ni Ironforge'daki Tarihçi Karnik'e götür.", k={b=637218373, h=325063091} }
V[98391] = { b="Elune'un Kız Kardeşliği", h="Darnassus'ta Rahibe Aquinne ile konuş.", k={b=1199141208, h=3648569746} }
V[98392] = { b="Vadideki Karanlık", h="Oracle Glade'deki Gözcü Arynia Cloudsbreak için Hatescreech'in Muskası'nı, Rüzgâr Hanımı Gaedress'in Muskası'nı ve Cadı Ana Arysa'nın Muskası'nı topla.", k={b=1524230869, h=984980842} }
V[98398] = { b="Kâhin Ağacı", h="Mesajını almak için yakınlardaki Kâhin Ağacı Kabuğu'nu bul.", k={b=3515210348, h=2628856489} }
V[98403] = { b="Çarpık Nefret", h="8 Befouled Webwood öldür ve Kötü Xethorr'un Olgun Fel Yosunu'nu Dolanaar'daki Tallonkai Swiftroot'a götür.", k={b=2999114337, h=1281674536} }
V[99046] = { b="Kayıp Ulak", h="Oracle Glade'e giden yolda Gözcü Eralya Leafshadow'u ara.", k={b=810349890, h=1250325807} }
V[99047] = { b="Henüz Ölmedi", h="Gözcü Eralya Leafshadow için Dolaanar'daki Byancie'den yardım iste.", k={b=2255397558, h=1979904296} }
V[99048] = { b="Kayıp Bir Yardımcı", h="Tiragarde Keep'in kuzeyinde Heglan Shadeeye'ı bul.", k={b=1709059291, h=4289047253} }
V[99049] = { b="Derinlerden Gelen Tehdit", h="Heglan Shadeeye'a neyin saldırdığına dair izler bul.", k={b=2980704058, h=3285727979} }
V[99050] = { b="Büyük Ağaç Bahşeder", h="Dolanaar'daki Byancie için 6 Çiyli Kırbaç Yaprağı, bir Boş Şişe ve bir Ferahlatıcı Kaynak Suyu topla.", k={b=410714037, h=2684775841} }
V[99051] = { b="Derinlerden Gelen Tehdit", h="9 Naga Diken Yüzgeci topla.", k={b=2980704058, h=1120706314} }
V[99052] = { b="Derinlerden Gelen Tehdit", h="Durotar'ın kuzey kıyısındaki deniz devini öldür ve başarının kanıtını getir.", k={b=2980704058, h=1965383103} }
V[99053] = { b="Ban'ethil'den Kaçış", h="Gözcü Lynessa Duskblossom'un Ban'ethil Barrow Den'den kaçmasına yardım et ve onun güvende olduğunu Dolanaar'daki Gözcü Kyra Starsong'a bildir.", k={b=1087287030, h=1583251297} }
V[99073] = { b="Acıyı Dindirmek", h="Kırbaç Suyu Merhemi'ni Oracle Tree yolundaki Gözcü Eralya Leafshadow'a götür.", k={b=272997413, h=2749955360} }
V[99123] = { b="Gölgelerde Kaybolmuş", h="Pal'juh'un Kolkar Crag'den kaçmasına yardım et ve başarının haberini Sen'jin Village'daki Usta Vornal'a ilet.", k={b=2452089880, h=1851174438} }
V[99127] = { b="Ağ Felaketi", h="Crystal Lake'teki balık tuzaklarını kontrol et.", k={b=2197103980, h=1051543980} }
V[99128] = { b="Balçıklı Tehdit", h="Crystal Lake'teki murloc'ları öldür.", k={b=1333859676, h=1670315819} }
V[99129] = { b="Bir Murloc Meselesi", h="Jason'ın murloc sorunları hakkında Remy \"Two Times\" ile konuş.", k={b=1209675568, h=976046669} }
V[99130] = { b="Cazip Bir Teklif", h="Murloc yemi için malzeme topla.", k={b=1530058903, h=4168927872} }
V[99131] = { b="Başarıya Yemlenmiş", h="Jason Mathers'a geri dön.", k={b=4108265166, h=2245173335} }
V[99143] = { b="Şişeler ve Süs Eşyaları", h="Yakındaki Murloc kampından 6 parça parlak hurda topla.", k={b=3315962515, h=2274276027} }
