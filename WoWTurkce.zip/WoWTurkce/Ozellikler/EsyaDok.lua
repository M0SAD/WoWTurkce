-- /wtr esyadok: Forever eşya listesini (Veri/Forever/EsyaNo.lua) gizli bir ipucuyla oyundan okur ve
-- İngilizce ipucu metinlerini WoWTurkce_Kayit.esyaDok içine yazar (çevirisiz ham döküm; çeviri kaynağı olarak kullanılır).
-- Eşya bilgisi istemcide yoksa sunucudan istenir (GET_ITEM_INFO_RECEIVED) ve gelince okunur.
-- Arka planda, kare başına en fazla 4 ms çalışır. Bitince /reload gerekir (kayıt diske yazılsın).
local G = WoWTurkce
local tip
local function kur()
	if tip then return tip end
	tip = CreateFrame("GameTooltip", "WTR_DokTip", UIParent, "GameTooltipTemplate")
	tip:SetOwner(UIParent, "ANCHOR_NONE")
	return tip
end
local function oku(id)
	local t = kur()
	t:ClearLines()
	t:SetOwner(UIParent, "ANCHOR_NONE")
	local ok = pcall(t.SetHyperlink, t, "item:" .. id)
	if not ok then return nil end
	local n = t:NumLines() or 0
	if n == 0 then return nil end
	local satirlar = {}
	for i = 1, n do
		local l = _G["WTR_DokTipTextLeft" .. i]; local r = _G["WTR_DokTipTextRight" .. i]
		local a = l and l:IsShown() and l:GetText()
		local b = r and r:IsShown() and r:GetText()
		if type(a) == "string" and a ~= "" and not G.gizli(a) then
			satirlar[#satirlar + 1] = (type(b) == "string" and b ~= "" and not G.gizli(b)) and (a .. "\t" .. b) or a
		end
	end
	if #satirlar == 0 then return nil end
	local m = table.concat(satirlar, "\n")
	-- Henüz sunucudan gelmemiş eşya: "Retrieving item information" / "Eşya bilgisi alınıyor"
	if n <= 2 and (m:find("^Retrieving") or m:find("bilgisi alınıyor")) then return nil end
	return m
end
local function hazir(id)
	if C_Item and C_Item.IsItemDataCachedByID then return C_Item.IsItemDataCachedByID(id) end
	return GetItemInfo(id) ~= nil
end
local function iste(id)
	if C_Item and C_Item.RequestLoadItemDataByID then C_Item.RequestLoadItemDataByID(id) else GetItemInfo(id) end
end
function G.esyaDokBaslat(bas, son)
	local liste = G.EsyaNoListe
	if bas then
		-- /wtr ... BAS SON: numara aralığını tara (listeye bağlı kalmadan, sunucudan var/yok cevabıyla)
		bas, son = tonumber(bas), tonumber(son) or tonumber(bas)
		if not bas or not son or son < bas then G.yaz("Kullanım: BAS SON"); return end
		liste = setmetatable({}, { __index = function(_, i) if i >= 1 and i <= son - bas + 1 then return bas + i - 1 end end, __len = function() return son - bas + 1 end })
		liste.n = son - bas + 1
		G.yaz(("Eşya taraması: %d - %d arası"):format(bas, son))
	end
	if not liste then G.yaz("Eşya listesi yok."); return end
	WoWTurkce_Kayit = WoWTurkce_Kayit or {}
	local D = WoWTurkce_Kayit.esyaDok or {}
	WoWTurkce_Kayit.esyaDok = D
	-- Önceki denemeden kalan boş kayıtları at
	for id, m in pairs(D) do if type(m) ~= "string" or m:find("bilgisi alınıyor") or m:find("^Retrieving") then D[id] = nil end end
	local bekleyen, bekleyenSayi, okunan, basarisiz = {}, 0, 0, 0
	local i, tur, bitti = 0, 1, false
	local f = CreateFrame("Frame")
	local son = GetTime()
	G.yaz(("Eşya dökümü başladı: %d eşya. Bitince bildirilir; sonra /reload yap."):format((liste.n or #liste)))
	local function dene(id)
		if D[id] then return true end
		local m = oku(id)
		if m then D[id] = m; okunan = okunan + 1; return true end
		return false
	end
	local function rapor()
		G.yaz(("Eşya dökümü: %d okundu, %d sunucudan bekleniyor, %d okunamadı"):format(okunan, bekleyenSayi, basarisiz))
	end
	f:RegisterEvent("GET_ITEM_INFO_RECEIVED")
	f:SetScript("OnEvent", function(_, _, id, ok)
		if not id or not bekleyen[id] then return end
		if ok == false then bekleyen[id] = nil; bekleyenSayi = bekleyenSayi - 1; basarisiz = basarisiz + 1; return end
		if dene(id) then bekleyen[id] = nil; bekleyenSayi = bekleyenSayi - 1 end
		son = GetTime()
	end)
	f:SetScript("OnUpdate", function()
		local t0 = debugprofilestop()
		if not bitti then
			if bekleyenSayi >= 40 then
				-- Sunucuyu boğmamak için aynı anda en fazla 40 istek beklet; 5 sn cevap gelmezse bekleyenleri yeniden iste
				if GetTime() - son > 5 then son = GetTime(); for id in pairs(bekleyen) do if dene(id) then bekleyen[id] = nil; bekleyenSayi = bekleyenSayi - 1 else iste(id) end end end
				return
			end
			while debugprofilestop() - t0 < 4 and bekleyenSayi < 40 do
				i = i + 1
				local id = liste[i]
				if not id then bitti = true; rapor(); break end
				if not D[id] then
					if hazir(id) then
						if not dene(id) then bekleyen[id] = true; bekleyenSayi = bekleyenSayi + 1; iste(id) end
					else
						bekleyen[id] = true; bekleyenSayi = bekleyenSayi + 1; iste(id)
					end
				end
				if i % 2000 == 0 then G.yaz(("Eşya dökümü: %d / %d istendi"):format(i, (liste.n or #liste))) end
			end
			return
		end
		-- Liste bitti: sunucudan gelenler olayla okunuyor; 3 sn'de bir bekleyenleri yeniden dene
		if GetTime() - son < 3 then return end
		son = GetTime()
		local kalan = 0
		for id in pairs(bekleyen) do
			if debugprofilestop() - t0 > 4 then break end
			if dene(id) then bekleyen[id] = nil; bekleyenSayi = bekleyenSayi - 1 else iste(id); kalan = kalan + 1 end
		end
		tur = tur + 1
		if tur % 5 == 0 then rapor() end
		if bekleyenSayi <= 0 or tur > 200 then
			f:SetScript("OnUpdate", nil); f:UnregisterAllEvents()
			G.yaz(("Eşya dökümü bitti: %d eşya okundu, %d okunamadı. Şimdi /reload yap ve kayıt dosyasını gönder."):format(okunan, bekleyenSayi + basarisiz))
		end
	end)
end
