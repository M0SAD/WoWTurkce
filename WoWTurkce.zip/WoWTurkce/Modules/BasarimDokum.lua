-- WoWTürkçe - başarım dökümü (/wt basarimdokum)
-- Oyundaki bütün başarım kategorilerini, başarımların adını, açıklamasını, ödül metnini ve alt hedeflerini
-- WoWTurkce_Dokum.basarim tablosuna yazar. Çeviri için kullanılır; /reload sonrası dosyaya kaydedilir.
local _, WT = ...

local function p(f, ...) if type(f) ~= "function" then return nil end local ok, a, b, c, d, e, g, h, i, j, k, l, m = pcall(f, ...); if ok then return a, b, c, d, e, g, h, i, j, k, l, m end end

function WT.BasarimDokumBaslat()
  WoWTurkce_Dokum = WoWTurkce_Dokum or {}
  if not GetCategoryList or not GetAchievementInfo then
    print("|cff33ff99WoWTürkçe:|r Bu istemcide başarım sistemi bulunamadı.")
    return
  end
  local D = { kategori = {}, basarim = {}, surum = (GetBuildInfo()) }
  local listeler = { p(GetCategoryList) or {} }
  if GetGuildCategoryList then listeler[#listeler + 1] = p(GetGuildCategoryList) or {} end
  if GetStatisticsCategoryList then listeler[#listeler + 1] = p(GetStatisticsCategoryList) or {} end
  local gorulen, sayi, kriter = {}, 0, 0
  local function kaydet(id)
    if not id or gorulen[id] then return end
    gorulen[id] = true
    local _, ad, puan, _, _, _, _, aciklama, _, _, odul = p(GetAchievementInfo, id)
    if not ad then return end
    local k = { ad = ad, a = aciklama, o = odul }
    local n = p(GetAchievementNumCriteria, id) or 0
    if n > 0 then
      k.k = {}
      for i = 1, n do
        local metin = p(GetAchievementCriteriaInfo, id, i)
        if type(metin) == "string" and metin ~= "" then k.k[#k.k + 1] = metin; kriter = kriter + 1 end
      end
    end
    D.basarim[id] = k
    sayi = sayi + 1
    -- aynı zincirdeki önceki/sonraki başarımlar
    local onceki = p(GetPreviousAchievement, id); if onceki then kaydet(onceki) end
    local sonraki = p(GetNextAchievement, id); if sonraki then kaydet(sonraki) end
  end
  for _, liste in ipairs(listeler) do
    for _, kat in ipairs(liste) do
      local ad, ust = p(GetCategoryInfo, kat)
      if ad then D.kategori[kat] = { ad = ad, ust = ust } end
      local n = p(GetCategoryNumAchievements, kat, true) or 0
      for i = 1, n do
        local id = p(GetAchievementInfo, kat, i)
        kaydet(id)
      end
    end
  end
  WoWTurkce_Dokum.basarim = D
  print(("|cff33ff99WoWTürkçe:|r Başarım dökümü bitti: %d başarım, %d alt hedef. Şimdi /reload yap ve haber ver."):format(sayi, kriter))
end
