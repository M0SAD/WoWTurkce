local mod	= DBM:NewMod("KaterinatheCleaner", "DBM-Party-Forever", 7)

mod:SetRevision("20261109015934")
mod:EnableGenericTrash()
mod:SetEncounterID(3418)
mod:SetModelID(2317)
mod:SetZone(2994)

mod:RegisterCombat("combat")
