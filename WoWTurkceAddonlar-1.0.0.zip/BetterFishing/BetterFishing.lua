local addonName = ...
local BetterFishing = {}

local internal = {
  -- Defaults
  _frame = CreateFrame("frame"),
  cvarsChanged = false,
  DOUBLECLICK_MIN_SECONDS = 0.04,
  previousClickTime = 0,
  isStandard = false,
  isMists = false,
  isClassic = false,
  isForever = false,
  pending = {},
}

local soundCache = {}
local CVarCacheSounds = {
  "Sound_MasterVolume",
  "Sound_SFXVolume",
  "Sound_EnableAmbience",
  "Sound_MusicVolume",
  "Sound_EnableAllSound",
  "Sound_EnablePetSounds",
  "Sound_EnableSoundWhenGameIsInBG",
  "Sound_EnableSFX",
}

local nameplateCache = {}
local CVarCacheNameplates = {
  "nameplateShowEnemies",
  "nameplateShowFriendlyPlayers",
  "UnitNameNPC",
  "UnitNameNonCombatCreatureName",
  "UnitNameHostleNPC",
  "UnitNameInteractiveNPC",
  "UnitNameFriendlySpecialNPCName"
}

BINDING_NAME_BETTERFISHINGKEY = "At ve Etkileşime Geç"

-- Compat
local GetPlayerAuraBySpellID = C_UnitAuras and C_UnitAuras.GetPlayerAuraBySpellID
local ShouldSpellAuraBeSecret = C_Secrets and C_Secrets.ShouldSpellAuraBeSecret

local FishingIDs = {
  [131474] = true,   -- Live/MoP
  [131490] = true,   -- Cast ID on MoP+ when pole equipped
  [131476] = true,   -- Cast ID on Live, and MoP without pole equipped
  [7620] = true,
  [7731] = true,
  [7732] = true,
  [18248] = true,
  [33095] = true,
  [51294] = true,
  [88868] = true,
  [110410] = true, -- MoP fishing
  [158743] = true, -- WoD Fishing
  [377895] = true, -- Ice Fishing
  [1224771] = true, -- Void Fishing
}

function BetterFishing:RunDeferred()
  for _, task in ipairs(internal.pending) do
    task.obj[task.method](task.obj, unpack(task.args))
  end
  table.wipe(internal.pending)
end

function BetterFishing:Defer(method, ...)
  if not InCombatLockdown() then
    self[method](self, ...)
  else
    table.insert(internal.pending, { obj = self, method = method, args = {...} })
  end
end

function BetterFishing:GetFishingID()
  if internal.isClassic or internal.isForever then
    for fishingID, _ in pairs(FishingIDs) do
      if C_SpellBook.IsSpellKnown(fishingID) then
        return fishingID
      end
    end
  end

  return 131474
end

function BetterFishing:GetFishingName()
  -- technically 7620 exists on every version but still add mainline fallback if for some reason not
  local localizedName = C_Spell.GetSpellName(7620)
  return localizedName or C_Spell.GetSpellName(131474)
end

function BetterFishing:UpdateAttributes()
  if self.secureButton then
    --self.secureButton:SetAttribute("isClassicEra", internal.isClassicEra)
    self.secureButton:SetAttribute("useKeyDowns", GetCVarBool("ActionButtonUseKeyDown"))
  end
end

function BetterFishing:GetSecureButton()
  if not self.secureButton then
    local button = CreateFrame("Button", addonName.."Button", nil, "SecureActionButtonTemplate")
    button:RegisterForClicks("AnyDown", "AnyUp")
    button:SetAttribute("type", "spell")
    button:SetAttribute("spell", self:GetFishingID())
    button:SetScript("PostClick", function(self, mouse_button, down)
      MouselookStart()
      if down then return end
      MouselookStop()
    end)

    SecureHandlerWrapScript(button, "PostClick", button, [[
      local useKeyDowns = self:GetAttribute("useKeyDowns")
      if useKeyDowns then
        if down then
          self:ClearBindings()
        end
      else
        if not down then
          self:ClearBindings()
        end
      end
    ]])
    self.secureButton = button

    self:Defer("UpdateAttributes")
  end
  return self.secureButton
end

function BetterFishing:IsFlying()
    if ShouldSpellAuraBeSecret and ShouldSpellAuraBeSecret(125883) then
        return IsFlying()
    end

    if GetPlayerAuraBySpellID and GetPlayerAuraBySpellID(125883) then
        return false
    end

    return IsFlying()
end

function BetterFishing_Run()
  if InCombatLockdown() or BetterFishing:IsFlying() or GetNumLootItems() ~= 0 or BetterFishing:IsFishing() or (not BetterFishingDB.overrideLunker and BetterFishing:IsLunkerActive()) then return end
  local key1, key2 = GetBindingKey("BETTERFISHINGKEY")
  local localizedName = BetterFishing:GetFishingName()
  if key1 then
    SetOverrideBindingSpell(BetterFishing:GetSecureButton(), true, key1, localizedName)
  end
  if key2 then
    SetOverrideBindingSpell(BetterFishing:GetSecureButton(), true, key2, localizedName)
  end
end

function BetterFishing:IsFishing()
  local spellID = select(8,UnitChannelInfo("player"))
  if FishingIDs[spellID] then
    return true
  end
  return false
end

function BetterFishing:IsLunkerActive()
  local spellID = select(8,UnitChannelInfo("player"))
  if spellID == 392270 then
    return true
  end
  return false
end

function BetterFishing:IsFishingpoleEquipped()
  local itemID = GetInventoryItemID("player", INVSLOT_MAINHAND)
  if itemID then
    local subclassID = select(7, C_Item.GetItemInfoInstant(itemID))
    if subclassID and subclassID == Enum.ItemWeaponSubclass.Fishingpole then
      return true
    end
  end
  return false
end

function BetterFishing:AllowFishing()
  if not C_SpellBook.IsSpellKnown(self:GetFishingID())
  or ((internal.isClassic or internal.isMists or internal.isForever) and not self:IsFishingpoleEquipped())
  or IsPlayerMoving()
  or (IsMounted() and not (BetterFishingDB.doubleClickEnabled and BetterFishingDB.doubleClickForce))
  or BetterFishing:IsFlying()
  or IsFalling()
  or IsStealthed()
  or IsSwimming()
  or IsSubmerged()
  or UnitHasVehicleUI("player")
  or not HasFullControl() then
    return false
  end

  if not BetterFishingDB.overrideLunker and self:IsLunkerActive() then
    return false
  end

  if self:IsFishing() then
    return (BetterFishingDB.recastOnDoubleClick and not IsModifierKeyDown()) or (not BetterFishingDB.recastOnDoubleClick and IsModifierKeyDown())
  end

  return true
end

function BetterFishing:ToggleNamePlates(enable)
  if not BetterFishingDB.hideNamePlates then return end
  if enable then
    for i = 1, #CVarCacheNameplates do
      nameplateCache[CVarCacheNameplates[i]] = GetCVar(CVarCacheNameplates[i])
      if CVarCacheNameplates[i] == "UnitNameHostleNPC" then
        C_CVar.SetCVar(CVarCacheNameplates[i], 1)
      else
        C_CVar.SetCVar(CVarCacheNameplates[i], 0)
      end
    end
  else
    for i = 1, #CVarCacheNameplates do
      if nameplateCache[CVarCacheNameplates[i]] ~= nil then
        C_CVar.SetCVar(CVarCacheNameplates[i], nameplateCache[CVarCacheNameplates[i]])
      end
    end
  end
end

function BetterFishing:OnLootReady(autoLoot)
  if BetterFishingDB.autoLoot then
    if not IsFishingLoot() then return end

    local numLoot = GetNumLootItems()
    if numLoot == 0 then return end

    local bindOnPickup = LE_EXPANSION_LEVEL_CURRENT < LE_EXPANSION_BATTLE_FOR_AZEROTH and not internal.isForever
    for slot = numLoot, 1, -1 do
      LootSlot(slot)
      if bindOnPickup then
        ConfirmLootSlot(slot)
        local dialog = StaticPopup_FindVisible("LOOT_BIND")
        if dialog and dialog.button1 then
          dialog.button1:Click()
        end
      end
    end
  end
end

local InteractCVarTable = {
  "SoftTargetInteract",
  "SoftTargetInteractArc",
  "SoftTargetInteractRange",
  "SoftTargetIconGameObject",
  "SoftTargetIconInteract"
}

local InteractCVars = {}

do
  for _, cvar in ipairs(InteractCVarTable) do
    InteractCVars[string.lower(cvar)] = GetCVar(cvar)
  end
end

hooksecurefunc(C_CVar, "SetCVar", function(cvar, value)
  if internal.cvarsChanged then return end
  local cvar_lower = string.lower(cvar)
  if InteractCVars[cvar_lower] then
    InteractCVars[cvar_lower] = value
  end
end)

function BetterFishing:ResetCVars(logout)
  if not logout then
    internal.cvarsChanged = true
  end
  BetterFishing:EnhanceSounds(false)
  for cvar, value in pairs(InteractCVars) do
    SetCVar(cvar, value)
  end
  C_Timer.After(0.2, function() internal.cvarsChanged = false end)
end

function BetterFishing:SetCVars()
  internal.cvarsChanged = true
  BetterFishing:EnhanceSounds(true)
  SetCVar("SoftTargetInteract", 3);
  SetCVar("SoftTargetInteractArc", 2);
  SetCVar("SoftTargetInteractRange", 60);
  SetCVar("SoftTargetIconGameObject", BetterFishingDB.objectIconDisabled and 0 or 1);
  SetCVar("SoftTargetIconInteract", BetterFishingDB.objectIconDisabled and 0 or 1);
  C_Timer.After(0.2, function() internal.cvarsChanged = false end)
end

function BetterFishing:ClearBinds()
  BetterFishing:ResetCVars()
  ClearOverrideBindings(BetterFishing:GetSecureButton());
end

function BetterFishing:UpdateOverrideBindings()
  if InCombatLockdown() or not self:IsFishing() then return end
  local key1, key2 = GetBindingKey("BETTERFISHINGKEY")
  if key1 then
    SetOverrideBinding(self:GetSecureButton(), true, key1, "INTERACTTARGET")
  end
  if key2 then
    SetOverrideBinding(self:GetSecureButton(), true, key2, "INTERACTTARGET")
  end
end

function BetterFishing:SetGameInfo()
  if WOW_PROJECT_ID == WOW_PROJECT_MAINLINE then
    internal.isStandard = true
  elseif WOW_PROJECT_ID == WOW_PROJECT_CAMELOT then
    internal.isForever = true
  elseif WOW_PROJECT_ID == WOW_PROJECT_MISTS_CLASSIC then
    internal.isMists = true
  elseif WOW_PROJECT_ID == WOW_PROJECT_BURNING_CRUSADE_CLASSIC or WOW_PROJECT_ID == WOW_PROJECT_CLASSIC or WOW_PROJECT_ID == WOW_PROJECT_WRATH_CLASSIC then
    internal.isClassic = true
  end
end

function BetterFishing:OnEvent(event, ...)
  if event == "ADDON_LOADED" and addonName == ... then
    BetterFishingDB = BetterFishingDB or {};
    self:SetGameInfo()
  elseif event == "PLAYER_REGEN_ENABLED" then
    self:RunDeferred()
  elseif event == "LOOT_READY" then
    self:OnLootReady(...)
  elseif event == "GLOBAL_MOUSE_DOWN" then
    if not BetterFishingDB.doubleClickEnabled then return end
    if ... == "RightButton" and not IsMouseButtonDown("LeftButton") and not InCombatLockdown() then
      if GetNumLootItems() == 0 then
        local currentTime = GetTime()
        local lastClick = internal.previousClickTime or 0
        local doubleClickTime = currentTime - lastClick

        -- Debounce
        if ((currentTime - (internal.lastCastTime or 0)) < 0.5) then
          return
        end

        if (doubleClickTime >= internal.DOUBLECLICK_MIN_SECONDS and doubleClickTime <= BetterFishingDB.doubleClickSpeed) then
          if BetterFishing:AllowFishing() then
            SetOverrideBindingClick(BetterFishing:GetSecureButton(), true, "BUTTON2", addonName.."Button")
            internal.lastCastTime = currentTime
          elseif BetterFishing:IsFishing() then
            internal.isInteractBinding = true
            SetOverrideBinding(BetterFishing:GetSecureButton(), true, "BUTTON2", "INTERACTTARGET")
          end
          internal.previousClickTime = nil
        end
      end
      internal.previousClickTime = GetTime()
    end
  elseif event == "GLOBAL_MOUSE_UP" then
    if internal.isInteractBinding and ... == "RightButton" and not IsMouseButtonDown("LeftButton") and not InCombatLockdown() then
      internal.isInteractBinding = false
      ClearOverrideBindings(BetterFishing:GetSecureButton())
    end
  elseif event == "UNIT_SPELLCAST_CHANNEL_START" then
    local unit,_,spellID = ...
    if unit == "player" and (FishingIDs[spellID]) then
      if InCombatLockdown() then return end
      self:ToggleNamePlates(true)
      self:SetCVars()
      self:UpdateOverrideBindings()
    end
  elseif event == "UNIT_SPELLCAST_CHANNEL_STOP" then
    local unit,_,spellID = ...
    if unit == "player" and (FishingIDs[spellID]) then
      self:Defer("ClearBinds")
      self:Defer("ToggleNamePlates", false)
    end
  elseif event == "PLAYER_LOGOUT" then
    self:ResetCVars(true)
  elseif event == "CVAR_UPDATE" then
    if ... == "ActionButtonUseKeyDown" then
      self:Defer("UpdateAttributes")
    end
    if self:IsFishing() then return end
    for i = 1, #CVarCacheSounds do
      if CVarCacheSounds[i] == ... then
        soundCache[CVarCacheSounds[i]] = GetCVar(...);
      end
    end
  end
end

internal._frame:SetScript("OnEvent", function(self, ...) BetterFishing:OnEvent(...) end)
FrameUtil.RegisterFrameForEvents(internal._frame, {
  "ADDON_LOADED",
  "PLAYER_REGEN_ENABLED",
  "CVAR_UPDATE",
  "PLAYER_LOGOUT",
  "GLOBAL_MOUSE_DOWN",
  "GLOBAL_MOUSE_UP",
  "LOOT_READY"
})
internal._frame:RegisterUnitEvent("UNIT_SPELLCAST_CHANNEL_START", "player")
internal._frame:RegisterUnitEvent("UNIT_SPELLCAST_CHANNEL_STOP", "player")

function BetterFishing:EnhanceSounds(enable)
  if not BetterFishingDB.enhanceSounds then return end

  if not enable then
    for i = 1, #CVarCacheSounds do
      if soundCache[CVarCacheSounds[i]] then
        SetCVar(CVarCacheSounds[i], soundCache[CVarCacheSounds[i]])
      end
    end
  else
    for i = 1, #CVarCacheSounds do
      soundCache[CVarCacheSounds[i]] = GetCVar(CVarCacheSounds[i])
      SetCVar(CVarCacheSounds[i], 0)
    end
    SetCVar("Sound_EnableAmbience", 0)
    SetCVar("Sound_MusicVolume", 0)
    SetCVar("Sound_EnablePetSounds", 0)

    SetCVar("Sound_EnableSFX", 1)
    SetCVar("Sound_EnableSoundWhenGameIsInBG", 1)
    SetCVar("Sound_EnableAllSound", 1)
    BetterFishingDB.enhanceSoundsScale = BetterFishingDB.enhanceSoundsScale or 1
    SetCVar("Sound_SFXVolume", BetterFishingDB.enhanceSoundsScale)
    SetCVar("Sound_MasterVolume", BetterFishingDB.enhanceSoundsScale)
  end
end