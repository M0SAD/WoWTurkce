
local _, mod = ...
mod.L = {}
local L = mod.L

L.battleBegins = "Savaş Başlıyor"
L.finalScore = "Son: %d - %d"
L.flagRespawns = "Bayrak yeniden çıkıyor"
L.timeRemaining = "Kalan Süre"

L.takenTheFlagTrigger = "^(.+) has taken the flag!"
L.hasTakenTheTrigger = "has taken the"
L.droppedTrigger = "dropped"
L.capturedTheTrigger = "captured the"

L.hordeGate = "Horde Kapısı"
L.allianceGate = "Alliance Kapısı"
L.gatePosition = "%s (%s)"
L.west = "Batı"
L.front = "Ön"
L.east = "Doğu"
L.hordeBoss = "Horde Bossu"
L.allianceBoss = "Alliance Bossu"
L.galvangar = "Galvangar"
L.balinda = "Balinda"
L.ivus = "Ivus"
L.lokholar = "Lokholar"
L.handIn = "|cFF33FF99Capping|r: Görev eşyaları otomatik teslim ediliyor."
L.anchorTooltip = "Seçenekler için |cffeda55fSağ Tık|r"
L.anchorTooltipNote = "Bu taşıma çapasını gizlemek için seçenekleri açıp çubukları kilitleyin."

--- Alliance IoC Workshop yells:
-- Gnomish Mechanic yells: I'm halfway there! Keep the Horde away from here.  They don't teach fighting in engineering school!
-- Gnomish Mechanic yells: It's broken already?! No worries. It's nothing I can't fix.
--- Horde IoC Workshop yells:
-- Goblin Mechanic yells: I'm about halfway done! Keep the Alliance away - fighting's not in my contract!
-- Goblin Mechanic yells: It's broken again?! I'll fix it... just don't expect the warranty to cover this.
L.halfway = "halfway" -- Needs to match the in game text exactly
L.broken = "broken" -- Needs to match the in game text exactly

-- Wintergrasp
L.damaged = "|cFF33FF99Capping|r: %s Hasar Aldı"
L.destroyed = "|cFF33FF99Capping|r: %s Yıkıldı"
L.northEastKeep = "Kuzeydoğu Kale Kulesi"
L.southEastKeep = "Güneydoğu Kale Kulesi"
L.northWestKeep = "Kuzeybatı Kale Kulesi"
L.southWestKeep = "Güneybatı Kale Kulesi"
L.northWest = "Kuzeybatı Duvarı"
L.southWest = "Güneybatı Duvarı"
L.south = "Güney Duvarı"
L.southEast = "Güneydoğu Duvarı"
L.northEast = "Kuzeydoğu Duvarı"
L.innerWest = "İç Batı Duvarı"
L.innerSouth = "İç Güney Duvarı"
L.innerEast = "İç Doğu Duvarı"
L.southGate = "Güney Kapısı"
L.mainEntrance = "Ana Giriş"
L.westTower = "Batı Kulesi"
L.southTower = "Güney Kulesi"
L.eastTower = "Doğu Kulesi"

-- Ashran
L.hordeGuardian = "Horde Muhafızı"
L.allianceGuardian = "Alliance Muhafızı"
L.kronus = "Kronus"
L.fangraal = "Fangraal"

-- Arena
L.arenaStartTrigger = "The Arena battle has begun!" -- Needs to match the in game text exactly
L.arenaStart60s = "One minute until the Arena battle begins!" -- Needs to match the in game text exactly
L.arenaStart30s = "Thirty seconds until the Arena battle begins!" -- Needs to match the in game text exactly
L.arenaStart15s = "Fifteen seconds until the Arena battle begins!" -- Needs to match the in game text exactly
