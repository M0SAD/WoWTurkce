local _;

local GetTime = GetTime;
local UnitName = UnitName;
local UnitGUID = UnitGUID;
local UnitIsEnemy = UnitIsEnemy;
local GetSpellCooldown = GetSpellCooldown or VUHDO_getSpellCooldown;
local HasFullControl = HasFullControl;
local pairs = pairs;
local InCombatLockdown = InCombatLockdown;
local tonumber = tonumber;
local string = string;
local debugprofilestop = debugprofilestop;
local MeasureCall = C_AddOnProfiler and C_AddOnProfiler.MeasureCall;
local format = string.format;
local tinsert = table.insert;
local tremove = table.remove;
local twipe = table.wipe;
local floor = math.floor;
local issecretvalue = issecretvalue;
local SetCVar = SetCVar;
local GetCVar = GetCVar;
local ShouldAurasBeSecret = C_Secrets and C_Secrets.ShouldAurasBeSecret;
local IsAddOnRestrictionActive = C_RestrictedActions and C_RestrictedActions.IsAddOnRestrictionActive;

VUHDO_INTERNAL_TOGGLES = { };
local VUHDO_INTERNAL_TOGGLES = VUHDO_INTERNAL_TOGGLES;

local VUHDO_INSTANCE = nil;

-- BURST CACHE ---------------------------------------------------

local VUHDO_RAID;
local VUHDO_PANEL_SETUP;
VUHDO_RELOAD_UI_IS_LNF = false;


VUHDO_HANDLER_PROFILING_ENABLED = false;

local VUHDO_HANDLER_PROFILING_SESSION_START_TIME = 0;
local VUHDO_HANDLER_PROFILING_METRICS = { };
local VUHDO_HANDLER_PROFILING_BATCH_SIZE = 10;
local VUHDO_HANDLER_PROFILING_BATCH_COUNT = 0;
local VUHDO_HANDLER_PROFILING_PENDING_UPDATES = { };
local VUHDO_HANDLER_PROFILING_ONUPDATE_INVOCATIONS = 0;

local VUHDO_HANDLER_EVENT_CONFIG = {
	["LIMIT"] = 5,
	["THRESHOLD_US"] = 2000,
	["HISTORY_LIMIT"] = 100,
};

local VUHDO_HANDLER_EVENT_SNAPSHOTS = {
	-- {
	--	["eventName"] = <event name>,
	--	["durationUs"] = <microsecond duration>,
	--	["timestamp"] = <epoch timestamp>,
	--	["args"] = {
	--		<arg1>,
	--		...
	--	},
	-- },
};

local sBossUnitIds = { "boss1", "boss2", "boss3", "boss4", "boss5", "boss6", "boss7", "boss8" };
local sLastBossUnitGuids = { };
local sEmpty = { };

local sAddonRestrictionCvars = {
	"addonChallengeModeRestrictionsForced",
	"addonCombatRestrictionsForced",
	"addonEncounterRestrictionsForced",
	"addonPvPMatchRestrictionsForced",
	"addonMapRestrictionsForced",
	"addonChatRestrictionsForced",
};

local sAddonRestrictionEnableCvars = {
	"addonChallengeModeRestrictionsForced",
	"addonCombatRestrictionsForced",
	"addonEncounterRestrictionsForced",
};

local VUHDO_parseAddonMessage;
local VUHDO_spellcastSent;
local VUHDO_resolveUnitByName;
local VUHDO_updateAllOutRaidTargetButtons;
local VUHDO_updateAllRaidTargetIndices;
local VUHDO_updateDirectionFrame;
local VUHDO_updateHealth;
local VUHDO_updateHealthBarsFor;
local VUHDO_setHealth;
local VUHDO_initAllEventBouquets;
local VUHDO_redisplayAllUnitAuras;
local VUHDO_updateBouquetsForEvent;
local VUHDO_updateManaBars;
local VUHDO_updateAllPowerTypes;
local VUHDO_updateAllHoTs;
local VUHDO_updateAllCyclicBouquets;
local VUHDO_updateAllDebuffIcons;
local VUHDO_updateAllAggro;
local VUHDO_updateAllRange;
local VUHDO_updateUnitRange;
local VUHDO_updateAllVisibilityCharmRange;
local VUHDO_updateAllClusters;
local VUHDO_updateClusterHighlights;
local VUHDO_aoeUpdateAll;
local VUHDO_updateSpellTrace;
local VUHDO_cleanupSpellTraceForUnit;
local VUHDO_clearAllSpellTraces;
local VUHDO_updateAllRaidBars;
local VUHDO_updateCustomDebuffTooltip;
local VUHDO_getUnitZoneName;
local VUHDO_handleScaleChange;
local VUHDO_redrawPanel;
local VUHDO_redrawAllPanels;
local VUHDO_unregisterUnitForEvents;
local VUHDO_isDeferredRefreshActive;
local VUHDO_isDeferredRedrawActive;
local VUHDO_processPendingAuraContainerBuilds;
local VUHDO_processPendingAuraHostUpdates;
local VUHDO_processPendingNativeAuraSounds;
local VUHDO_flushPendingOverlayRebuild;
local VUHDO_flushPendingOverlayAcquires;
local VUHDO_flushPendingAlphaChainRebuild;
local VUHDO_checkAuraDataRestrictedState;
local VUHDO_syncAuraContainersForUnit;
local VUHDO_syncAuraContainersForAllRaidUnits;
local VUHDO_syncOverlaysForUnit;
local VUHDO_syncSwiftmendOverlayGates;
local VUHDO_resetAuraContainersForUnit;
local VUHDO_resetOverlaysForUnit;
local VUHDO_clearOverlaysForUnit;
local VUHDO_syncAllOverlayUnits;
local VUHDO_refreshAllMissingBuffContainers;
local VUHDO_invalidateMissingBuffContainerPlansIfNeeded;

local VUHDO_UIFrameFlash_OnUpdate = function() end;

local sSecretsEnabled = VUHDO_SECRETS_ENABLED;



do
	--
	function VUHDO_setHandlerProfiling(anIsEnabled)

		VUHDO_HANDLER_PROFILING_ENABLED = anIsEnabled;

		if anIsEnabled then
			if VUHDO_HANDLER_PROFILING_SESSION_START_TIME == 0 then
				VUHDO_HANDLER_PROFILING_SESSION_START_TIME = GetTime();
			end

			VUHDO_Msg("Handler profiling is enabled.");
		else
			VUHDO_Msg("Handler profiling is disabled.");
		end

		return;

	end



	--
	local tSnapshots;
	local tNewSnapshot;
	local tIsDuplicate;
	local tCompositionKey;
	local tArgs;
	function VUHDO_addEventSnapshot(aEventName, aDurationUs, ...)

		if not VUHDO_HANDLER_PROFILING_ENABLED or aDurationUs < VUHDO_HANDLER_EVENT_CONFIG["THRESHOLD_US"] then
			return;
		end

		tSnapshots = VUHDO_HANDLER_EVENT_SNAPSHOTS;
		tIsDuplicate = false;

		tArgs = { };

		for tCnt = 1, select("#", ...) do
			tinsert(tArgs, VUHDO_argToString(select(tCnt, ...)));

			-- don't capture more than 5 arguments
			if tCnt >= 5 then
				break;
			end
		end

		tCompositionKey = aEventName .. ":" .. table.concat(tArgs, ",");

		for _, tExistingSnapshot in ipairs(tSnapshots) do
			if not tExistingSnapshot["compositionKey"] then
				-- backward compatibility: create composition key for existing snapshots
				tArgs = { };

				for _, tArg in ipairs(tExistingSnapshot["args"] or { }) do
					tinsert(tArgs, VUHDO_argToString(tArg));
				end

				tExistingSnapshot["compositionKey"] = tExistingSnapshot["eventName"] .. ":" .. table.concat(tArgs, ",");
			end

			if tExistingSnapshot["compositionKey"] == tCompositionKey then
				tExistingSnapshot["dedupedCount"] = (tExistingSnapshot["dedupedCount"] or 1) + 1;

				if aDurationUs > tExistingSnapshot["durationUs"] then
					tExistingSnapshot["durationUs"] = aDurationUs;
					tExistingSnapshot["timestamp"] = time();

					twipe(tExistingSnapshot["args"]);

					for _, tArg in ipairs(tArgs) do
						tinsert(tExistingSnapshot["args"], tArg);
					end
				end

				tIsDuplicate = true;

				break;
			end
		end

		if not tIsDuplicate then
			tNewSnapshot = {
				["eventName"] = aEventName,
				["durationUs"] = aDurationUs,
				["timestamp"] = time(),
				["args"] = { },
				["compositionKey"] = tCompositionKey,
				["dedupedCount"] = 1,
			};

			for _, tArg in ipairs(tArgs) do
				tinsert(tNewSnapshot["args"], tArg);
			end

			tinsert(tSnapshots, tNewSnapshot);
		end

		table.sort(tSnapshots, function(a, b) return a.durationUs > b.durationUs; end);

		while #tSnapshots > VUHDO_HANDLER_EVENT_CONFIG["LIMIT"] do
			tremove(tSnapshots);
		end

		return;

	end



	--
	local tSegmentName;
	local tTracker;
	function VUHDO_updateOnEventProfilingMetrics(anEventName, aDurationUs)

		if not VUHDO_HANDLER_PROFILING_ENABLED or not anEventName then
			return;
		end

		tSegmentName = "OnEvent_" .. anEventName;

		if not VUHDO_HANDLER_PROFILING_METRICS[tSegmentName] then
			VUHDO_HANDLER_PROFILING_METRICS[tSegmentName] = VUHDO_createTailMeanTracker();
		end

		tTracker = VUHDO_HANDLER_PROFILING_METRICS[tSegmentName];
		tTracker:update(aDurationUs);

		return;

	end



	--
	function VUHDO_updateHandlerOnEventMetrics(anEventName, aDurationUs, anArg1, anArg2, anArg3, anArg4, anArg5)

		if not VUHDO_HANDLER_PROFILING_ENABLED or not anEventName then
			return;
		end

		VUHDO_updateOnEventProfilingMetrics(anEventName, aDurationUs);

		VUHDO_addEventSnapshot(anEventName, aDurationUs, anArg1, anArg2, anArg3, anArg4, anArg5);

		return;

	end



	--
	local tOnUpdateSegments = {
		"segment1A",
		"segment1B",
		"segment1Total",
		"segment2Total",
		"segment2A",
		"segment2B",
		"segment2C",
		"segment2D",
		"segment2E",
		"segment2F",
		"segment2G",
		"segment2H",
		"segment2I",
		"segment2J",
		"segment2K",
		"segment2L",
		"segment2M",
		"total",
	};
	function VUHDO_resetHandlerMetrics()

		VUHDO_HANDLER_PROFILING_SESSION_START_TIME = GetTime();
		VUHDO_HANDLER_PROFILING_ONUPDATE_INVOCATIONS = 0;

		twipe(VUHDO_HANDLER_EVENT_SNAPSHOTS);
		twipe(VUHDO_HANDLER_PROFILING_METRICS);

		if VUHDO_HANDLER_PROFILING_ENABLED then
			VUHDO_Msg("Handler profiling metrics reset.");
		end

		return;

	end



	--
	local function VUHDO_sortEventStats(anEntryA, anEntryB)

		return anEntryA["totalTime"] > anEntryB["totalTime"];

	end



	--
	local tTailMeanText;
	function VUHDO_printHandlerMetricSegment(aSegName, aSegData, anInvocationCount, anIndent)

		if not aSegData then
			return;
		end

		tTailMeanText = "";

		for tIndex, tTailMeanKey in ipairs(VUHDO_TAIL_MEAN_KEYS) do
			if tIndex > 1 then
				tTailMeanText = tTailMeanText .. ", ";
			end

			tTailMeanText = tTailMeanText .. tTailMeanKey .. ": " .. VUHDO_formatTime(aSegData[tTailMeanKey] or 0);
		end

		VUHDO_Msg(format("%s|cffB0E0E6%s:|r Total: %s, %s",
			anIndent or "  ", aSegName,
			VUHDO_formatTime(aSegData["Total"] or 0),
			tTailMeanText
		));

		return;

	end



	--
	local tSeg1Segments = {
		["segment1A"] = "Seg 1A (Animations)",
		["segment1B"] = "Seg 1B (Deferred Tasks)",
	};
	local tSeg2Segments = {
		["segment2A"] = "Seg 2A (UI Reloads)",
		["segment2B"] = "Seg 2B (Panel Reset)",
		["segment2C"] = "Seg 2C (Roster & Core)",
		["segment2D"] = "Seg 2D (Combat Chk)",
		["segment2E"] = "Seg 2E (Slow Thres)",
		["segment2F"] = "Seg 2F (Post-Combat)",
		["segment2G"] = "Seg 2G (Get Auto Prof)",
		["segment2H"] = "Seg 2H (Load Profile)",
		["segment2I"] = "Seg 2I (Hide Blizz)",
		["segment2J"] = "Seg 2J (Shield Cleanup)",
		["segment2K"] = "Seg 2K (Zones)",
		["segment2L"] = "Seg 2L (Inspect)",
		["segment2M"] = "Seg 2M (Macros)",
	};
	local tMetrics;
	local tSessionDuration;
	local tInvocationCount;
	local tEventStats;
	local tEventName;
	local tTailMeans;
	local tTailMeanText;
	local tTotal;
	local tCount;
	local tArgString;
	local tDedupedText;
	local tThresholdText;
	local tSortedKeys;
	local tSegmentName;
	function VUHDO_printHandlerMetrics()

		if not VUHDO_HANDLER_PROFILING_ENABLED then
			VUHDO_Msg("Handler profiling is currently disabled.");

			return;
		end

		tMetrics = VUHDO_getHandlerProfilingMetrics();
		tSessionDuration = GetTime() - VUHDO_HANDLER_PROFILING_SESSION_START_TIME;
		tInvocationCount = VUHDO_HANDLER_PROFILING_ONUPDATE_INVOCATIONS;

		VUHDO_Msg("|cffFFD100--- Handler Profiling Metrics (Session: " .. format("%.2f sec", tSessionDuration) .. ") ---|r");

		VUHDO_Msg(format("|cffFFA500** VUHDO_OnUpdate Invocations:|r %d", tInvocationCount));

		if tMetrics["segment1Total"] then
			VUHDO_printHandlerMetricSegment("Segment 1 Total", tMetrics["segment1Total"], tInvocationCount);
		end

		VUHDO_Msg("  |cff98FB98Detailed Segment 1 Breakdown:|r");

		tSortedKeys = VUHDO_sortSegmentKeys(tSeg1Segments);

		for _, tSegmentKey in ipairs(tSortedKeys) do
			tSegmentName = tSeg1Segments[tSegmentKey];

			if tMetrics[tSegmentKey] then
				VUHDO_printHandlerMetricSegment(tSegmentName, tMetrics[tSegmentKey], tInvocationCount, "    - ");
			end
		end

		if tMetrics["segment2Total"] then
			VUHDO_printHandlerMetricSegment("Segment 2 Total", tMetrics["segment2Total"], tInvocationCount);
		end

		VUHDO_Msg("  |cff98FB98Detailed Segment 2 Breakdown:|r");

		tSortedKeys = VUHDO_sortSegmentKeys(tSeg2Segments);

		for _, tSegmentKey in ipairs(tSortedKeys) do
			tSegmentName = tSeg2Segments[tSegmentKey];

			if tMetrics[tSegmentKey] then
				VUHDO_printHandlerMetricSegment(tSegmentName, tMetrics[tSegmentKey], tInvocationCount, "    - ");
			end
		end

		if tMetrics["total"] then
			VUHDO_printHandlerMetricSegment("Sum (Segment 1 + Segment 2)", tMetrics["total"], tInvocationCount);
		end

		VUHDO_Msg("|cffFFA500** VUHDO_OnEvent (time per event type): **|r");

		tEventStats = { };

		for tSegmentName, tTracker in pairs(VUHDO_HANDLER_PROFILING_METRICS) do
			if string.sub(tSegmentName, 1, 8) == "OnEvent_" and tTracker:isInitialized() then
				tEventName = string.sub(tSegmentName, 9);

				tTailMeans = tTracker:getTailMeans();

				tTotal = tTracker:getCumulativeTotal();
				tCount = tTracker["totalCount"];

				tinsert(tEventStats, {
					["name"] = tEventName,
					["totalTime"] = tTotal,
					["count"] = tCount,
					["tailMeans"] = tTailMeans,
				});
			end
		end

		if #tEventStats == 0 then
			VUHDO_Msg("  No OnEvent calls recorded.");
		else
			table.sort(tEventStats, VUHDO_sortEventStats);

			VUHDO_Msg("  |cff98FB98Sorted by Total Time|r (Event: Total, Count, tail means)");

			for _, tStats in ipairs(tEventStats) do
				tTailMeanText = "";

				for tIndex, tTailMeanKey in ipairs(VUHDO_TAIL_MEAN_KEYS) do
					if tIndex > 1 then
						tTailMeanText = tTailMeanText .. ", ";
					end

					tTailMeanText = tTailMeanText .. "|cff98FB98" .. tTailMeanKey .. ":|r " .. VUHDO_formatTime(tStats["tailMeans"][tTailMeanKey] or 0);
				end

				VUHDO_Msg(format("  |cffB0E0E6%s:|r |cff98FB98Total:|r %s, |cff98FB98Count:|r %d, %s",
					tStats["name"],
					VUHDO_formatTime(tStats["totalTime"]),
					tStats["count"],
					tTailMeanText
				));
			end
		end

		if #VUHDO_HANDLER_EVENT_SNAPSHOTS > 0 then
			if VUHDO_HANDLER_EVENT_CONFIG["THRESHOLD_US"] then
				tThresholdText = VUHDO_formatTime(VUHDO_HANDLER_EVENT_CONFIG["THRESHOLD_US"]);
			else
				tThresholdText = "N/A";
			end

			VUHDO_Msg("|cffFFA500** Top " .. #VUHDO_HANDLER_EVENT_SNAPSHOTS .. " Expensive Event Invocations (|cffB0E0E6Threshold:|r " .. tThresholdText .. "): **|r");

			for tCnt, tSnapshot in ipairs(VUHDO_HANDLER_EVENT_SNAPSHOTS) do
				tArgString = table.concat(tSnapshot["args"], ", ");
				tDedupedText = "";

				if (tSnapshot["dedupedCount"] or 0) > 1 then
					tDedupedText = format(" (|cff98FB98deduped|r %d times)", tSnapshot["dedupedCount"]);
				end

				VUHDO_Msg(format("  #%d: |cffB0E0E6%s|r - %s @ |cffB0E0E6%s|r. |cff98FB98Args:|r %s%s",
					tCnt,
					tSnapshot["eventName"],
					VUHDO_formatTime(tSnapshot["durationUs"]),
					date("%m/%d/%y %H:%M:%S", tSnapshot["timestamp"]),
					tArgString,
					tDedupedText
				));
			end
		else
			VUHDO_Msg("|cffFFA500** No expensive event invocations captured. **|r");
		end

		VUHDO_Msg("|cffFFD100--- End of Metrics ---|r")

		return;

	end
end



--
local sIsDirectionArrow = false;
local sHotToggleUpdateSecs = 1;
local sAggroRefreshSecs = 1;
local sRangeRefreshSecs = 1.1;
local sRangeFallbackSecs = 1;
local sClusterRefreshSecs = 1.2;
local sAoeRefreshSecs = 1.3;
local sBuffsRefreshSecs;
local sLastShapeshiftTime = 0;
local sIsKeyboardMacroRebuildPending = false;
local sSpellbookRefreshScheduled = false;
local sSpellbookRefreshNeedsBuffRetry = false;

local VuhDoGcdStatusBar;
local VuhDoDirectionFrame;



--
local function VUHDO_eventHandlerInitFunctionOverrides()

	VUHDO_updateHealth = _G["VUHDO_updateHealth"];
	VUHDO_updateAllRaidBars = _G["VUHDO_updateAllRaidBars"];
	VUHDO_updateAllOutRaidTargetButtons = _G["VUHDO_updateAllOutRaidTargetButtons"];
	VUHDO_parseAddonMessage = _G["VUHDO_parseAddonMessage"];
	VUHDO_spellcastSent = _G["VUHDO_spellcastSent"];
	VUHDO_resolveUnitByName = _G["VUHDO_resolveUnitByName"];
	VUHDO_parseCombatLogEvent = _G["VUHDO_parseCombatLogEvent"];
	VUHDO_updateAllHoTs = _G["VUHDO_updateAllHoTs"];
	VUHDO_updateAllCyclicBouquets = _G["VUHDO_updateAllCyclicBouquets"];
	VUHDO_updateAllDebuffIcons = _G["VUHDO_updateAllDebuffIcons"];
	VUHDO_createDebuffIconAnimation = _G["VUHDO_createDebuffIconAnimation"];
	VUHDO_cleanupDebuffIconAnimation = _G["VUHDO_cleanupDebuffIconAnimation"];
	VUHDO_updateAllRaidTargetIndices = _G["VUHDO_updateAllRaidTargetIndices"];
	VUHDO_updateAllClusters = _G["VUHDO_updateAllClusters"];
	VUHDO_aoeUpdateAll = _G["VUHDO_aoeUpdateAll"];
	VuhDoGcdStatusBar = _G["VuhDoGcdStatusBar"];
	VuhDoDirectionFrame = _G["VuhDoDirectionFrame"];
	VUHDO_updateDirectionFrame = _G["VUHDO_updateDirectionFrame"];
	VUHDO_getUnitZoneName = _G["VUHDO_getUnitZoneName"];
	VUHDO_updateClusterHighlights = _G["VUHDO_updateClusterHighlights"];
	VUHDO_updateCustomDebuffTooltip = _G["VUHDO_updateCustomDebuffTooltip"];
	VUHDO_UIFrameFlash_OnUpdate = _G["VUHDO_UIFrameFlash_OnUpdate"];
	VUHDO_handleScaleChange = _G["VUHDO_handleScaleChange"];
	VUHDO_updateBouquetsForEvent = _G["VUHDO_updateBouquetsForEvent"];
	VUHDO_updateHealthBarsFor = _G["VUHDO_updateHealthBarsFor"];
	VUHDO_updateSpellTrace = _G["VUHDO_updateSpellTrace"];
	VUHDO_setHealth = _G["VUHDO_setHealth"];
	VUHDO_initAllEventBouquets = _G["VUHDO_initAllEventBouquets"];
	VUHDO_updateAllAggro = _G["VUHDO_updateAllAggro"];
	VUHDO_updateAllPowerTypes = _G["VUHDO_updateAllPowerTypes"];
	VUHDO_updateAllRange = _G["VUHDO_updateAllRange"];
	VUHDO_updateUnitRange = _G["VUHDO_updateUnitRange"];
	VUHDO_updateAllVisibilityCharmRange = _G["VUHDO_updateAllVisibilityCharmRange"];
	VUHDO_cleanupSpellTraceForUnit = _G["VUHDO_cleanupSpellTraceForUnit"];
	VUHDO_clearAllSpellTraces = _G["VUHDO_clearAllSpellTraces"];
	VUHDO_unregisterUnitForEvents = _G["VUHDO_unregisterUnitForEvents"];
	VUHDO_isDeferredRefreshActive = _G["VUHDO_isDeferredRefreshActive"];
	VUHDO_isDeferredRedrawActive = _G["VUHDO_isDeferredRedrawActive"];
	VUHDO_processPendingAuraContainerBuilds = _G["VUHDO_processPendingAuraContainerBuilds"];
	VUHDO_processPendingAuraHostUpdates = _G["VUHDO_processPendingAuraHostUpdates"];
	VUHDO_processPendingNativeAuraSounds = _G["VUHDO_processPendingNativeAuraSounds"];
	VUHDO_flushPendingOverlayRebuild = _G["VUHDO_flushPendingOverlayRebuild"];
	VUHDO_flushPendingOverlayAcquires = _G["VUHDO_flushPendingOverlayAcquires"];
	VUHDO_flushPendingAlphaChainRebuild = _G["VUHDO_flushPendingAlphaChainRebuild"];
	VUHDO_checkAuraDataRestrictedState = _G["VUHDO_checkAuraDataRestrictedState"];
	VUHDO_syncAuraContainersForUnit = _G["VUHDO_syncAuraContainersForUnit"];
	VUHDO_syncAuraContainersForAllRaidUnits = _G["VUHDO_syncAuraContainersForAllRaidUnits"];
	VUHDO_syncOverlaysForUnit = _G["VUHDO_syncOverlaysForUnit"];
	VUHDO_syncSwiftmendOverlayGates = _G["VUHDO_syncSwiftmendOverlayGates"];
	VUHDO_resetAuraContainersForUnit = _G["VUHDO_resetAuraContainersForUnit"];
	VUHDO_resetOverlaysForUnit = _G["VUHDO_resetOverlaysForUnit"];
	VUHDO_clearOverlaysForUnit = _G["VUHDO_clearOverlaysForUnit"];
	VUHDO_syncAllOverlayUnits = _G["VUHDO_syncAllOverlayUnits"];
	VUHDO_refreshAllMissingBuffContainers = _G["VUHDO_refreshAllMissingBuffContainers"];
	VUHDO_invalidateMissingBuffContainerPlansIfNeeded = _G["VUHDO_invalidateMissingBuffContainerPlansIfNeeded"];

	return;

end



--
local function VUHDO_eventHandlerInitLocalOverrides()

	VUHDO_RAID = _G["VUHDO_RAID"];
	VUHDO_PANEL_SETUP = _G["VUHDO_PANEL_SETUP"];

	VUHDO_eventHandlerInitFunctionOverrides();

	VUHDO_initTaskSystem();

	VUHDO_syncOverlaysForUnit = _G["VUHDO_deferSyncOverlaysForUnit"];
	VUHDO_syncSwiftmendOverlayGates = _G["VUHDO_deferSyncSwiftmendOverlayGates"];
	VUHDO_flushPendingOverlayRebuild = _G["VUHDO_deferFlushPendingOverlayRebuild"];
	VUHDO_updateHealth = _G["VUHDO_deferUpdateHealth"];
	VUHDO_updateBouquetsForEvent = _G["VUHDO_deferUpdateBouquetsForEvent"];
	VUHDO_updateManaBars = _G["VUHDO_deferUpdateManaBars"];
	VUHDO_updateHealthBarsFor = _G["VUHDO_deferUpdateHealthBarsFor"];
	VUHDO_updateAllHoTs = _G["VUHDO_deferUpdateAllHoTs"];
	VUHDO_updateAllCyclicBouquets = _G["VUHDO_deferUpdateAllCyclicBouquets"];
	VUHDO_updateAllDebuffIcons = _G["VUHDO_deferUpdateAllDebuffIcons"];
	VUHDO_updateAllAggro = _G["VUHDO_deferUpdateAllAggro"];
	VUHDO_updateAllPowerTypes = _G["VUHDO_deferUpdateAllPowerTypes"];
	VUHDO_updateAllRange = _G["VUHDO_deferUpdateAllRange"];
	VUHDO_updateAllVisibilityCharmRange = _G["VUHDO_deferUpdateAllVisibilityCharmRange"];
	VUHDO_updateAllClusters = _G["VUHDO_deferUpdateAllClusters"];
	VUHDO_aoeUpdateAll = _G["VUHDO_deferAoeUpdateAll"];
	VUHDO_updateSpellTrace = _G["VUHDO_deferUpdateSpellTrace"];
	VUHDO_updateAllRaidBars = _G["VUHDO_deferUpdateAllRaidBars"];
	VUHDO_initAllEventBouquets = _G["VUHDO_deferInitAllEventBouquets"];
	VUHDO_redisplayAllUnitAuras = _G["VUHDO_redisplayAllUnitAuras"];
	VUHDO_setHealth = _G["VUHDO_deferSetHealth"];
	VUHDO_updateClusterHighlights = _G["VUHDO_deferUpdateClusterHighlights"];
	VUHDO_handleScaleChange = _G["VUHDO_deferHandleScaleChange"];

	if VUHDO_CONFIG["USE_DEFERRED_REDRAW"] then
		VUHDO_redrawPanel = _G["VUHDO_deferRedrawPanel"];
		VUHDO_redrawAllPanels = _G["VUHDO_deferRedrawAllPanels"];
	else
		VUHDO_redrawPanel = _G["VUHDO_redrawPanel"];
		VUHDO_redrawAllPanels = _G["VUHDO_redrawAllPanels"];
	end

	sIsDirectionArrow = VUHDO_isShowDirectionArrow();

	sHotToggleUpdateSecs = VUHDO_CONFIG["UPDATE_HOTS_MS"] * 0.00033;
	sAggroRefreshSecs = VUHDO_CONFIG["THREAT"]["AGGRO_REFRESH_MS"] * 0.001;
	sRangeRefreshSecs = VUHDO_CONFIG["RANGE_CHECK_DELAY"] * 0.001;
	sRangeFallbackSecs = VUHDO_CONFIG["RANGE_FALLBACK_DELAY"] * 0.001;

	sClusterRefreshSecs = VUHDO_CONFIG["CLUSTER"]["REFRESH"] * 0.001;
	sAoeRefreshSecs = VUHDO_CONFIG["AOE_ADVISOR"]["refresh"] * 0.001;
	sBuffsRefreshSecs = VUHDO_BUFF_SETTINGS["CONFIG"]["REFRESH_SECS"];

	return;

end



--
function VUHDO_getIsDirectionArrow()

	return sIsDirectionArrow;

end



--
function VUHDO_rebuildKeyboardMacros()

	if not InCombatLockdown() then
		VUHDO_initKeyboardMacros();
	else
		sIsKeyboardMacroRebuildPending = true;
	end

	return;

end



----------------------------------------------------

local VUHDO_VARIABLES_LOADED = false;
local VUHDO_IS_RELOAD_BUFFS = false;
local VUHDO_LOST_CONTROL = false;
local VUHDO_RELOAD_AFTER_BATTLE = false;
local VUHDO_OPTIONS_SHOW_AFTER_BATTLE = false;
local VUHDO_GCD_UPDATE = false;

local VUHDO_RELOAD_PANEL_NUM = nil;


VUHDO_TIMERS = {
	["RELOAD_UI"] = 0,
	["REGISTER_BOUQUETS"] = 0,
	["REBUILD_AURA_GROUPS"] = 0,
	["REFRESH_OVERLAYS"] = 0,
	["RELOAD_PANEL"] = 0,
	["CUSTOMIZE"] = 0,
	["CHECK_PROFILES"] = 6.2,
	["RELOAD_ZONES"] = 3.45,
	["UPDATE_CLUSTERS"] = 0,
	["REFRESH_INSPECT"] = 2.1,
	["REFRESH_TOOLTIP"] = 2.3,
	["UPDATE_AGGRO"] = 0,
	["UPDATE_RANGE"] = 1,
	["UPDATE_VISIBILITY_CHARM_RANGE"] = 1,
	["UPDATE_HOTS"] = 0.25,
	["REFRESH_TARGETS"] = 0.51,
	["RELOAD_RAID"] = 0,
	["RELOAD_ROSTER"] = 0,
	["REFRESH_DRAG"] = 0.05,
	["MIRROR_TO_MACRO"] = 8,
	["REFRESH_CUDE_TOOLTIP"] = 1,
	["UPDATE_AOE"] = 3,
	["BUFF_WATCH"] = 1,
	["REFRESH_AURA_CONTAINERS"] = 0,
	["REFRESH_MISSING_BUFF_CONTAINERS"] = -1,
};
local VUHDO_TIMERS = VUHDO_TIMERS;


VUHDO_CONFIG = nil;
VUHDO_PANEL_SETUP = nil;
VUHDO_SPELL_ASSIGNMENTS = nil;
VUHDO_SPELLS_KEYBOARD = nil;
VUHDO_SPELL_CONFIG = nil;

VUHDO_IS_RELOADING = false;
VUHDO_FONTS = { };
VUHDO_STATUS_BARS = { };
VUHDO_SOUNDS = { };
VUHDO_BORDERS = { };


VUHDO_MAINTANK_NAMES = { };
local VUHDO_FIRST_RELOAD_UI = false;



--
function VUHDO_isVariablesLoaded()

	return VUHDO_VARIABLES_LOADED;

end



--
function VUHDO_initBuffs()

	VUHDO_initBuffsFromSpellBook();
	VUHDO_reloadBuffPanel();

	VUHDO_invalidateMissingBuffContainerPlansIfNeeded();

	return;

end



--
function VUHDO_initTooltipTimer()

	VUHDO_TIMERS["REFRESH_TOOLTIP"] = 2.3;

	return;

end



--
function VUHDO_initAllBurstCaches()

	VUHDO_tooltipInitLocalOverrides();
	VUHDO_modelToolsInitLocalOverrides();
	VUHDO_toolboxInitLocalOverrides();
	VUHDO_aurasInitLocalOverrides();
	VUHDO_auraModeInitLocalOverrides();
	VUHDO_auraContainerFiltersInitLocalOverrides();
	VUHDO_auraContainerGlowInitLocalOverrides();
	VUHDO_auraContainerInitLocalOverrides();
	VUHDO_auraContainerStaticInitLocalOverrides();
	VUHDO_auraInferenceInitLocalOverrides();
	VUHDO_auraSoundsInitLocalOverrides();
	VUHDO_guiToolboxInitLocalOverrides();
	VUHDO_vuhdoInitLocalOverrides();
	VUHDO_readyCheckInitLocalOverrides();
	VUHDO_spellEventHandlerInitLocalOverrides();
	VUHDO_macroFactoryInitLocalOverrides();
	VUHDO_keySetupInitLocalOverrides();
	VUHDO_bindingGeneratorInitLocalOverrides();
	VUHDO_combatLogInitLocalOverrides();
	VUHDO_eventHandlerInitLocalOverrides();
	VUHDO_unitEventHandlerInitLocalOverrides();
	VUHDO_customHealthInitLocalOverrides();
	VUHDO_customHealthTextInitLocalOverrides();
	VUHDO_customManaInitLocalOverrides();
	VUHDO_customTargetInitLocalOverrides();
	VUHDO_customClustersInitLocalOverrides();
	VUHDO_panelInitLocalOverrides();
	VUHDO_panelRedrawInitLocalOverrides();
	VUHDO_panelRefreshInitLocalOverrides();
	VUHDO_roleCheckerInitLocalOverrides();
	VUHDO_sizeCalculatorInitLocalOverrides();
	VUHDO_customHotsInitLocalOverrides();
	VUHDO_auraColorsInitLocalOverrides();
	VUHDO_debuffsInitLocalOverrides();
	VUHDO_barCustomizerAurasInitLocalOverrides();
	VUHDO_barCustomizerThreatInitLocalOverrides();
	VUHDO_customDebuffIconsInitLocalOverrides();
	VUHDO_healCommAdapterInitLocalOverrides();
	VUHDO_buffWatchInitLocalOverrides();
	VUHDO_buffWatchContainersInitLocalOverrides();
	VUHDO_clusterBuilderInitLocalOverrides();
	VUHDO_aoeAdvisorInitLocalOverrides();
	VUHDO_bouquetValidatorsSpellTraceInitLocalOverrides();
	VUHDO_bouquetValidatorsStatusInitLocalOverrides();
	VUHDO_bouquetValidatorsInitLocalOverrides();
	VUHDO_bouquetsInitLocalOverrides();
	VUHDO_bouquetLayersInitLocalOverrides();
	VUHDO_textProvidersInitLocalOverrides();
	VUHDO_textProviderHandlersInitLocalOverrides();
	VUHDO_actionEventHandlerInitLocalOverrides();
	VUHDO_directionsInitLocalOverrides();
	VUHDO_dcShieldInitLocalOverrides();
	VUHDO_shieldAbsorbInitLocalOverrides();
	VUHDO_spellTraceInitLocalOverrides();
	VUHDO_playerTargetEventHandlerInitLocalOverrides();

	return;

end



--
local function VUHDO_initOptions()

	if VuhDoNewOptionsTabbedFrame then
		VUHDO_initBouquetComboModel();
		VUHDO_initBouquetSlotsComboModel();
	end

	return;

end



--
local tName;
local tProfile;
function VUHDO_loadCurrentProfile()

	if not VUHDO_CONFIG then
		return;
	end

	tName = VUHDO_CONFIG["CURRENT_PROFILE"];

	if (tName or "") ~= "" then
		_, tProfile = VUHDO_getProfileNamedCompressed(tName);

		if tProfile then
			if tProfile["LOCKED"] then
				VUHDO_Msg("Profil " .. tProfile["NAME"] .. " şu anda kilitli ve YÜKLENMEDİ.");

				return;
			end

			VUHDO_loadProfileNoInit(tName);
		else
			VUHDO_Msg("Hata: Seçili profil \"" .. tName .. "\" mevcut değil.", 1, 0.4, 0.4);
		end
	end

	return;

end



--
local tName;
local function VUHDO_loadCurrentKeyLayout()

	if not VUHDO_CONFIG or not VUHDO_SPEC_LAYOUTS then
		return;
	end

	tName = VUHDO_SPEC_LAYOUTS["selected"];

	if (tName or "") ~= "" then
		if VUHDO_SPELL_LAYOUTS and VUHDO_SPELL_LAYOUTS[tName] then
			VUHDO_activateLayoutNoInit(tName);
		else
			VUHDO_Msg("Hata: Seçili tuş düzeni \"" .. tName .. "\" mevcut değil.", 1, 0.4, 0.4);
		end
	end

	return;

end



--
local tProfile;
local function VUHDO_loadDefaultProfile()

	if not VUHDO_CONFIG then
		return;
	end

	if ((VUHDO_CONFIG["CURRENT_PROFILE"] or "") == "") and ((VUHDO_DEFAULT_PROFILE or "") ~= "") then
		_, tProfile = VUHDO_getProfileNamedCompressed(VUHDO_DEFAULT_PROFILE);

		if tProfile then
			if tProfile["LOCKED"] then
				VUHDO_Msg("Profil " .. tProfile["NAME"] .. " şu anda kilitli ve YÜKLENMEDİ.");

				return;
			end

			VUHDO_loadProfile(VUHDO_DEFAULT_PROFILE);
		else
			VUHDO_Msg("Hata: Varsayılan profil \"" .. VUHDO_DEFAULT_PROFILE .. "\" mevcut değil.", 1, 0.4, 0.4);
		end
	end

	return;

end



--
local function VUHDO_loadDefaultLayout()

	if not VUHDO_SPEC_LAYOUTS then
		return;
	end

	if ((VUHDO_SPEC_LAYOUTS["selected"] or "") == "") and ((VUHDO_DEFAULT_LAYOUT or "") ~= "") then
		if VUHDO_SPELL_LAYOUTS and VUHDO_SPELL_LAYOUTS[VUHDO_DEFAULT_LAYOUT] ~= nil then
			VUHDO_activateLayout(VUHDO_DEFAULT_LAYOUT);
		else
			VUHDO_Msg(VUHDO_I18N_SPELL_LAYOUT_NOT_EXIST_1 .. VUHDO_DEFAULT_LAYOUT .. VUHDO_I18N_SPELL_LAYOUT_NOT_EXIST_2, 1, 0.4, 0.4);
		end
	end

	return;

end



--
local tLevel = 0;
local tHasPerCharacterConfig;
local function VUHDO_init()

	if tLevel == 0 or VUHDO_VARIABLES_LOADED then
		tLevel = 1;

		return;
	end

	--VUHDO_COMBAT_LOG_TRACE = {};

	if not VUHDO_RAID then
		VUHDO_RAID = { };
	end

	tHasPerCharacterConfig = _G["VUHDO_CONFIG"] and true or false;

	VUHDO_loadCurrentProfile(); -- 1. Diese Reihenfolge scheint wichtig zu sein, erzeugt
	VUHDO_loadCurrentKeyLayout();

	VUHDO_loadVariables(); -- 2. umgekehrt undefiniertes Verhalten (VUHDO_CONFIG ist nil etc.)
	VUHDO_initAuraModeSelection();
	VUHDO_initAllBurstCaches();
	VUHDO_verifyFlavorRulesLoaded();
	VUHDO_resolveAllAuraGroupFilters();
	VUHDO_initDefaultProfiles();

	VUHDO_VARIABLES_LOADED = true;

	VUHDO_initPanelModels();
	VUHDO_initFromSpellbook();
	VUHDO_initBuffs();

	if not InCombatLockdown() then
		VUHDO_setIsOutOfCombat(true);
	end

	VUHDO_initDebuffs(); -- Too soon obviously => ReloadUI
	VUHDO_clearUndefinedModelEntries();
	VUHDO_registerAllBouquets(true);
	VUHDO_initSpecialUnitAuraSlots();
	VUHDO_initUnitEventHandler();
	VUHDO_reloadUI(false);
	VUHDO_initAuraMode();
	VUHDO_startAuraPoolPrewarm();
	VUHDO_getAutoProfile();
	VUHDO_initCliqueSupport();

	if VuhDoNewOptionsTabbedFrame then
		VuhDoNewOptionsTabbedFrame:ClearAllPoints();
		VUHDO_PixelUtil.SetPoint(VuhDoNewOptionsTabbedFrame, "CENTER", "UIParent", "CENTER", 0, 0);
	end

	VUHDO_initSharedMedia();
	VUHDO_initFuBar();
	VUHDO_initButtonFacade(VUHDO_INSTANCE);
	VUHDO_initLibSpecialization();
	VUHDO_initHideBlizzFrames();
	VUHDO_initScaleMonitoring();

	if not InCombatLockdown() then
		VUHDO_initKeyboardMacros();
	end

	VUHDO_incrementAuraAnchorConfigVersion();

	VUHDO_timeReloadUI(3);
	VUHDO_aoeUpdateTalents();

	if not tHasPerCharacterConfig then
		VUHDO_loadDefaultProfile();
		VUHDO_loadDefaultLayout();
	end

	return;

end



--
local tSpellbookChanged;
local function VUHDO_processSpellbookRefresh()

	sSpellbookRefreshScheduled = false;

	if not VUHDO_VARIABLES_LOADED then
		return;
	end

	tSpellbookChanged = VUHDO_initFromSpellbook();

	VUHDO_initBuffs();
	VUHDO_initDebuffsIfNeeded();

	if tSpellbookChanged then
		VUHDO_registerAllBouquets(false);

		VUHDO_timeReloadUI(1);
	end

	VUHDO_rebuildKeyboardMacros();

	if sSpellbookRefreshNeedsBuffRetry then
		sSpellbookRefreshNeedsBuffRetry = false;

		C_Timer.After(3, VUHDO_initBuffs);
	end

	return;

end



--
local function VUHDO_scheduleSpellbookRefresh()

	if sSpellbookRefreshScheduled then
		return;
	end

	sSpellbookRefreshScheduled = true;

	C_Timer.After(0.5, VUHDO_processSpellbookRefresh);

	return;

end



--
local tBossUnit;
local tBossGuid;
local function VUHDO_updateBossUnits()

	VUHDO_updateToggledUnitEvents();

	for tBossCnt = 1, 8 do
		tBossUnit = sBossUnitIds[tBossCnt];

		if UnitExists(tBossUnit) then
			tBossGuid = UnitGUID(tBossUnit);

			if tBossGuid and sSecretsEnabled and issecretvalue(tBossGuid) then
				tBossGuid = sEmpty;
			end
		else
			tBossGuid = nil;
		end

		if sLastBossUnitGuids[tBossCnt] ~= tBossGuid then
			sLastBossUnitGuids[tBossCnt] = tBossGuid;

			VUHDO_resetAuraContainersForUnit(tBossUnit);
			VUHDO_resetOverlaysForUnit(tBossUnit);

			if tBossGuid then
				VUHDO_setHealth(tBossUnit, 1); -- VUHDO_UPDATE_ALL
				VUHDO_updateHealthBarsFor(tBossUnit, 1); -- VUHDO_UPDATE_ALL
				VUHDO_initEventBouquetsFor(tBossUnit);

				VUHDO_syncAuraContainersForUnit(tBossUnit);
				VUHDO_syncOverlaysForUnit(tBossUnit);
			else
				VUHDO_clearOverlaysForUnit(tBossUnit);
			end

			if VUHDO_TIMERS["RELOAD_ROSTER"] < 0.15 then
				VUHDO_TIMERS["RELOAD_ROSTER"] = 0.15;
			end
		elseif tBossGuid == sEmpty then
			VUHDO_resetAuraContainersForUnit(tBossUnit);
			VUHDO_resetOverlaysForUnit(tBossUnit);

			VUHDO_syncAuraContainersForUnit(tBossUnit);
			VUHDO_syncOverlaysForUnit(tBossUnit);
		end
	end

	return;

end



--
do
	--
	local tEventTotalStartTime;
	local tEventTotalDuration;
	local tEmptyRaid = { };
	local tSpecNumber;
	local tBestProfileName;
	local tUnit;
	local tSecond;
	function VUHDO_OnEvent(anInstance, anEvent, anArg1, anArg2, anArg3, anArg4, anArg5, anArg6, anArg7, anArg8, anArg9, anArg10, anArg11, anArg12, anArg13, anArg14, anArg15, anArg16, anArg17, anArg18, anArg19)

		if VUHDO_HANDLER_PROFILING_ENABLED and anEvent then
			tEventTotalStartTime = debugprofilestop();
		end

		if "UNIT_SPELLCAST_SENT" == anEvent then
			if VUHDO_VARIABLES_LOADED then
				VUHDO_spellcastSent(anArg1, anArg2, anArg4);
			end

		elseif "UNIT_SPELLCAST_START" == anEvent or "UNIT_SPELLCAST_DELAYED" == anEvent or "UNIT_SPELLCAST_CHANNEL_START" == anEvent or
			"UNIT_SPELLCAST_CHANNEL_UPDATE" == anEvent then
			if VUHDO_VARIABLES_LOADED and VUHDO_INTERNAL_TOGGLES[37] and VUHDO_CONFIG["SHOW_SPELL_TRACE"] and anArg1 and
				((VUHDO_CONFIG["SPELL_TRACE"]["showIncomingEnemy"] and UnitIsEnemy(anArg1, "player")) or
					(VUHDO_CONFIG["SPELL_TRACE"]["showIncomingFriendly"] and UnitIsFriend(anArg1, "player"))) then
				VUHDO_addIncomingSpellTrace(anArg1, anArg2, anArg3);
			end

		elseif "UNIT_SPELLCAST_STOP" == anEvent or "UNIT_SPELLCAST_INTERRUPTED" == anEvent or "UNIT_SPELLCAST_FAILED" == anEvent or
			"UNIT_SPELLCAST_FAILED_QUIET" == anEvent or "UNIT_SPELLCAST_CHANNEL_STOP" == anEvent then
			if VUHDO_VARIABLES_LOADED and VUHDO_INTERNAL_TOGGLES[37] and VUHDO_CONFIG["SHOW_SPELL_TRACE"] and anArg1 and
				((VUHDO_CONFIG["SPELL_TRACE"]["showIncomingEnemy"] and UnitIsEnemy(anArg1, "player")) or
					(VUHDO_CONFIG["SPELL_TRACE"]["showIncomingFriendly"] and UnitIsFriend(anArg1, "player"))) then
				VUHDO_removeIncomingSpellTrace(anArg1, anArg2, anArg3);
			end

		elseif "UNIT_SPELLCAST_SUCCEEDED" == anEvent then
			if VUHDO_VARIABLES_LOADED and VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_AURA_INFERENCE] then
				VUHDO_onSpellcastSucceeded(anArg1, anArg2, anArg3);
			end

		elseif "UNIT_SPELLCAST_EMPOWER_STOP" == anEvent then
			if VUHDO_VARIABLES_LOADED and VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_AURA_INFERENCE]
				and "EVOKER" == VUHDO_PLAYER_CLASS then
				VUHDO_onSpellcastEmpoweredStop(anArg1, anArg2, anArg3, anArg4);
			end

		elseif "NAME_PLATE_UNIT_REMOVED" == anEvent then
			if anArg1 and VUHDO_VARIABLES_LOADED and VUHDO_INTERNAL_TOGGLES[37] and VUHDO_CONFIG["SHOW_SPELL_TRACE"] then
				VUHDO_cleanupSpellTraceForUnit(anArg1);
			end

		elseif "PLAYER_REGEN_ENABLED" == anEvent then
			if VUHDO_VARIABLES_LOADED then
				VUHDO_updateAllAggro();

				VUHDO_updateBouquetsForEvent("target", 13); -- VUHDO_UPDATE_MANA
				VUHDO_updateBouquetsForEvent("focus",  13); -- VUHDO_UPDATE_MANA

				VUHDO_updateManaBars("player", 3);
				VUHDO_updateAllPowerTypes();

				if VUHDO_RELOAD_AFTER_BATTLE and not InCombatLockdown() then
					VUHDO_RELOAD_AFTER_BATTLE = false;

					if VUHDO_TIMERS["RELOAD_RAID"] <= 0 then
						VUHDO_quickRaidReload();

						if VUHDO_IS_RELOAD_BUFFS then
							VUHDO_reloadBuffPanel();

							VUHDO_IS_RELOAD_BUFFS = false;
						end
					end

					VUHDO_TIMERS["REFRESH_AURA_CONTAINERS"] = 0.5;
				end

				VUHDO_updateAuraDataRestrictedState(false);

				VUHDO_processPendingAuraContainerBuilds();

				VUHDO_processPendingManaBarLayouts();

				VUHDO_processPendingAuraHostUpdates();

				VUHDO_processPendingNativeAuraSounds();

				VUHDO_flushPendingOverlayRebuild();

				VUHDO_flushPendingOverlayAcquires();

				VUHDO_flushPendingAlphaChainRebuild();
			end

			if VUHDO_OPTIONS_SHOW_AFTER_BATTLE and VuhDoNewOptionsTabbedFrame and not VuhDoNewOptionsTabbedFrame:IsShown() then
				VuhDoNewOptionsTabbedFrame:SetShown(true);

				VUHDO_OPTIONS_SHOW_AFTER_BATTLE = false;
			end

			if sIsKeyboardMacroRebuildPending then
				VUHDO_initKeyboardMacros();

				sIsKeyboardMacroRebuildPending = false;
			end

			VUHDO_setIsOutOfCombat(true);

		elseif "PLAYER_REGEN_DISABLED" == anEvent then
			if VUHDO_VARIABLES_LOADED then
				VUHDO_stopMovingAllPanels();

				VUHDO_updateAuraDataRestrictedState(false);
			end

			if VuhDoNewOptionsTabbedFrame and VuhDoNewOptionsTabbedFrame:IsShown() then
				VuhDoNewOptionsTabbedFrame:SetShown(false);

				VUHDO_OPTIONS_SHOW_AFTER_BATTLE = true;
			end

			VUHDO_processCombatUnsafeTasksBeforeLockdown();

			VUHDO_setIsOutOfCombat(false);

		elseif "ENCOUNTER_END" == anEvent or "ZONE_CHANGED_NEW_AREA" == anEvent then
			if VUHDO_VARIABLES_LOADED then
				VUHDO_processPendingAuraContainerBuilds();

				VUHDO_TIMERS["REFRESH_AURA_CONTAINERS"] = 0.5;
			end

		elseif "ZONE_CHANGED" == anEvent or "ZONE_CHANGED_INDOORS" == anEvent then
			if VUHDO_VARIABLES_LOADED then
				VUHDO_TIMERS["REFRESH_AURA_CONTAINERS"] = 0.5;
			end

		elseif "RAID_TARGET_UPDATE" == anEvent then
			VUHDO_TIMERS["CUSTOMIZE"] = 0.1;

		elseif "GROUP_ROSTER_UPDATE" == anEvent or "UPDATE_ACTIVE_BATTLEFIELD" == anEvent then
			if VUHDO_FIRST_RELOAD_UI then
				VUHDO_normalRaidReload(true);

				if VUHDO_TIMERS["RELOAD_ROSTER"] < 0.4 then
					VUHDO_TIMERS["RELOAD_ROSTER"] = 0.6;
				end
			end

			if VUHDO_VARIABLES_LOADED then
				if VUHDO_TIMERS["REFRESH_AURA_CONTAINERS"] < 0.9 then
					VUHDO_TIMERS["REFRESH_AURA_CONTAINERS"] = 0.9;
				end
			end

		elseif "INSTANCE_ENCOUNTER_ENGAGE_UNIT" == anEvent then
			if VUHDO_VARIABLES_LOADED then
				VUHDO_updateBossUnits();
			end

		elseif "PLAYER_FOCUS_CHANGED" == anEvent then
			if VUHDO_VARIABLES_LOADED then
				VUHDO_cancelPendingTargetFocusInspect("focus");

				if VUHDO_RAID["focus"] then
					VUHDO_updateUnitRange("focus");

					VUHDO_determineIncHeal("focus");
					VUHDO_updateHealth("focus", 9); -- VUHDO_UPDATE_INC
				end

				VUHDO_clParserSetCurrentFocus();

				if VUHDO_isModelConfigured(VUHDO_ID_FOCUS) or
					(VUHDO_isModelConfigured(VUHDO_ID_PRIVATE_TANKS) and not VUHDO_CONFIG["OMIT_FOCUS"]) then
					if VUHDO_INTERNAL_TOGGLES[37] and VUHDO_CONFIG["SHOW_SPELL_TRACE"] then
						VUHDO_cleanupSpellTraceForUnit("focus");

						VUHDO_cleanupStaleSpellTracesForTargetFocus();
					end

					if UnitExists("focus") then
						VUHDO_fullAuraRefresh("focus");

						VUHDO_setHealth("focus", 1); -- VUHDO_UPDATE_ALL

						if VUHDO_needsRoleInspect("focus") then
							VUHDO_requestTargetFocusInspect("focus");
						end
					else
						VUHDO_clearUnitAuraCache("focus");

						if sSecretsEnabled then
							VUHDO_hideAurasForUnit("focus");
						else
							VUHDO_removeHots("focus");
							VUHDO_removeAllDebuffIcons("focus");
							VUHDO_resetDebuffsFor("focus");
						end

						if VUHDO_RAID["focus"] then
							table.wipe(VUHDO_RAID["focus"]);
						end

						VUHDO_unregisterUnitForEvents("focus");

						VUHDO_RAID["focus"] = nil;
					end

					VUHDO_updateHealthBarsFor("focus", 1); -- VUHDO_UPDATE_ALL
					VUHDO_initEventBouquetsFor("focus");
				end

				VUHDO_updateBouquetsForEvent("player", 23); -- VUHDO_UPDATE_PLAYER_FOCUS
				VUHDO_updateBouquetsForEvent("focus", 23); -- VUHDO_UPDATE_PLAYER_FOCUS

				VUHDO_resetAuraContainersForUnit("focus");
				VUHDO_resetOverlaysForUnit("focus");

				VUHDO_syncAuraContainersForUnit("focus");
				VUHDO_syncOverlaysForUnit("focus");

				VUHDO_updatePanelVisibility();

			end

		elseif "PARTY_MEMBER_ENABLE" == anEvent or "PARTY_MEMBER_DISABLE" == anEvent then
			VUHDO_TIMERS["CUSTOMIZE"] = 0.2;

		elseif "PLAYER_ENTERING_WORLD" == anEvent then
			VUHDO_init();
			VUHDO_initAddonMessages();

			if VUHDO_VARIABLES_LOADED then
				VUHDO_syncAuraContainersForAllRaidUnits();

				VUHDO_timeRefreshMissingBuffContainers(0.3);

				C_Timer.After(2, VUHDO_timeRefreshAuraContainers);
				C_Timer.After(6, VUHDO_timeRefreshAuraContainers);
			end

			if VUHDO_VARIABLES_LOADED and VUHDO_INTERNAL_TOGGLES[37] and VUHDO_CONFIG["SHOW_SPELL_TRACE"] then
				VUHDO_clearAllSpellTraces();
			end

		elseif "CINEMATIC_STOP" == anEvent or "STOP_MOVIE" == anEvent then
			if VUHDO_VARIABLES_LOADED then
				VUHDO_syncAuraContainersForAllRaidUnits();

				VUHDO_TIMERS["REFRESH_AURA_CONTAINERS"] = 0.5;
			end

		elseif "UPDATE_SHAPESHIFT_FORM" == anEvent then
			sLastShapeshiftTime = GetTime();

		elseif "LEARNED_SPELL_IN_SKILL_LINE" == anEvent or "TRAIT_CONFIG_UPDATED" == anEvent or "SPELLS_CHANGED" == anEvent then
			if VUHDO_VARIABLES_LOADED then
				if "SPELLS_CHANGED" == anEvent and (GetTime() - sLastShapeshiftTime) < 0.5 then
					return;
				end

				if "SPELLS_CHANGED" == anEvent then
					sSpellbookRefreshNeedsBuffRetry = true;
				end

				VUHDO_scheduleSpellbookRefresh();
			end

		elseif "SPELL_UPDATE_COOLDOWN" == anEvent or "SPELL_UPDATE_CHARGES" == anEvent then
			if VUHDO_VARIABLES_LOADED and VUHDO_isPlayerKnowsSwiftmend() then
				VUHDO_refreshSwiftmendCooldown();

				VUHDO_syncSwiftmendOverlayGates();
			end

		elseif "VARIABLES_LOADED" == anEvent then
			VUHDO_init();

		elseif "UPDATE_BINDINGS" == anEvent then
			if not InCombatLockdown() and VUHDO_VARIABLES_LOADED then
				VUHDO_initKeyboardMacros();
			end

		elseif "PLAYER_TARGET_CHANGED" == anEvent then
			if VUHDO_VARIABLES_LOADED then
				VUHDO_cancelPendingTargetFocusInspect("target");

				VUHDO_updatePlayerTarget();

				VUHDO_updateHealth("player", 1);
				VUHDO_updateBouquetsForEvent("player", 22); -- VUHDO_UPDATE_UNIT_TARGET

				if UnitExists("target") then
					VUHDO_updateHealth("target", 1);
				end

				VUHDO_updateBouquetsForEvent("target", 22); -- VUHDO_UPDATE_UNIT_TARGET

				if VUHDO_needsRoleInspect("target") then
					VUHDO_requestTargetFocusInspect("target");
				end

				VUHDO_resetAuraContainersForUnit("target");
				VUHDO_resetOverlaysForUnit("target");

				VUHDO_syncAuraContainersForUnit("target");
				VUHDO_syncOverlaysForUnit("target");

				VUHDO_updatePanelVisibility();
			end

		elseif "CHAT_MSG_ADDON" == anEvent then
			if VUHDO_VARIABLES_LOADED then
				VUHDO_parseAddonMessage(anArg1, anArg2, anArg4);
			end

		elseif "READY_CHECK" == anEvent then
			if VUHDO_RAID then
				VUHDO_readyStartCheck(anArg1, anArg2);
			end

		elseif "READY_CHECK_CONFIRM" == anEvent then
			if VUHDO_RAID then
				VUHDO_readyCheckConfirm(anArg1, anArg2);
			end

		elseif "READY_CHECK_FINISHED" == anEvent then
			if VUHDO_RAID then
				VUHDO_readyCheckEnds();
			end

		elseif "CVAR_UPDATE" == anEvent then
			-- Patch 10.0.0 makes setting CVars freeze the game client
			-- FIXME: also there is some issue where this event fires before bouquets have been properly decompressed
			VUHDO_IS_SFX_ENABLED = false; --tonumber(GetCVar("Sound_EnableSFX")) == 1;
			VUHDO_IS_SOUND_ERRORSPEECH_ENABLED = false; --tonumber(GetCVar("Sound_EnableErrorSpeech")) == 1;
			--if VUHDO_VARIABLES_LOADED then VUHDO_reloadUI(false); end

		elseif "INSPECT_READY" == anEvent then
			VUHDO_inspectLockRole();

		elseif "ROLE_CHANGED_INFORM" == anEvent then
			if VUHDO_VARIABLES_LOADED then
				tUnit = VUHDO_resolveUnitByName(anArg1);

				if tUnit then
					VUHDO_resetTalentScan(tUnit);
				end
			end

		elseif "UNIT_NAME_UPDATE" == anEvent then
			if VUHDO_VARIABLES_LOADED and anArg1 then
				if "player" == anArg1 then
					VUHDO_PLAYER_NAME, tSecond = UnitName("player");
					VUHDO_PLAYER_FULL_NAME = VUHDO_buildUnitFullName(VUHDO_PLAYER_NAME, tSecond);
				end

				VUHDO_updateHealth(anArg1, 1);
			end

		elseif "MODIFIER_STATE_CHANGED" == anEvent then
			if VuhDoTooltip:IsShown() then
				VUHDO_updateTooltip();
			end

		elseif "PLAYER_LOGOUT" == anEvent then
			VUHDO_compressAllBouquets();

		elseif "PLAYER_EQUIPMENT_CHANGED" == anEvent then
			VUHDO_aoeUpdateSpellAverages();

		elseif "LFG_PROPOSAL_SHOW" == anEvent then
			VUHDO_buildSafeParty();

		elseif "LFG_PROPOSAL_FAILED" == anEvent then
			VUHDO_quickRaidReload();

		elseif "LFG_PROPOSAL_SUCCEEDED" == anEvent then
			VUHDO_lateRaidReload();

		--elseif("UPDATE_MACROS" == anEvent) then
			--VUHDO_timeReloadUI(0.1); -- @WARNING Ldt wg. shield macro alle 8 sec.

		elseif "PET_BATTLE_OPENING_START" == anEvent then
			VUHDO_setPetBattle(true);

		elseif "PET_BATTLE_CLOSE" == anEvent then
			VUHDO_setPetBattle(false);

		elseif "RUNE_POWER_UPDATE" == anEvent then
			VUHDO_updateBouquetsForEvent("player", 42); -- VUHDO_UPDATE_RUNES

		elseif "PLAYER_SPECIALIZATION_CHANGED" == anEvent or "ACTIVE_TALENT_GROUP_CHANGED" == anEvent then
			if VUHDO_VARIABLES_LOADED and not InCombatLockdown() then
				if "ACTIVE_TALENT_GROUP_CHANGED" == anEvent then
					anArg1 = "player";
				end

				if "player" == anArg1 then
					tSpecNumber = tostring(VUHDO_getActiveSpecSlot()) or "1";
					tBestProfileName = VUHDO_getBestProfileAfterSpecChange();

					-- event sometimes fires multiple times so we must de-dupe
					if (not VUHDO_strempty(VUHDO_SPEC_LAYOUTS[tSpecNumber]) and (VUHDO_SPEC_LAYOUTS["selected"] ~= VUHDO_SPEC_LAYOUTS[tSpecNumber])) or
						(not VUHDO_strempty(tBestProfileName) and (VUHDO_CONFIG["CURRENT_PROFILE"] ~= tBestProfileName)) then
						VUHDO_activateSpecc(tSpecNumber);
					end
				end

				if ((VUHDO_RAID or tEmptyRaid)[anArg1] ~= nil) then
					VUHDO_resetTalentScan(anArg1);
					VUHDO_initDebuffsIfNeeded(); -- Talentabhngige Debuff-Fhigkeiten neu initialisieren.
					VUHDO_timeReloadUI(1);
				end
			end

		elseif "UI_SCALE_CHANGED" == anEvent then
			if VUHDO_VARIABLES_LOADED then
				VUHDO_handleScaleChange();
			end

		elseif "DISPLAY_SIZE_CHANGED" == anEvent then
			if VUHDO_VARIABLES_LOADED then
				VUHDO_handleScaleChange();
			end

		else
			VUHDO_Msg("Hata: Beklenmeyen olay: " .. anEvent);
		end

		if VUHDO_HANDLER_PROFILING_ENABLED and anEvent then
			tEventTotalDuration = (debugprofilestop() - tEventTotalStartTime) * 1000;

			VUHDO_updateHandlerOnEventMetrics(anEvent, tEventTotalDuration, anArg1, anArg2, anArg3, anArg4, anArg5);
		end

		return;

	end
end



--
local function VUHDO_setPanelsVisible(anIsVisible)

	if not InCombatLockdown() then
		VUHDO_CONFIG["SHOW_PANELS"] = anIsVisible;

		VUHDO_Msg(anIsVisible and VUHDO_I18N_PANELS_SHOWN or VUHDO_I18N_PANELS_HIDDEN);

		VUHDO_redrawAllPanels(false);
		VUHDO_saveCurrentProfile();
	else
		VUHDO_Msg("Savaş sırasında mümkün değil!");
	end

	return;

end



--
local function VUHDO_printAbout()

	VUHDO_Msg("VuhDo |cffffe566['vu:du:]|r v" .. VUHDO_VERSION .. " (/vd yazın). Şu an Ivaria@US-Hyjal tarafından, Anny ve iki kızının onuruna sürdürülüyor.");

	return;

end



--
local tTokens;
local tName;
local tKey;
local tAmbiguousNames;
local tAmbiguousMsg;
local function VUHDO_slashCmdPrivateTanks(aArgument)

	if aArgument then
		tTokens = VUHDO_splitString(aArgument, ",");

		if "clear" == tTokens[1] then
			twipe(VUHDO_PLAYER_TARGETS);

			VUHDO_quickRaidReload();

			return;
		end

		for _, tToken in ipairs(tTokens) do
			tName = strtrim(tToken);

			if not InCombatLockdown() then
				tUnit, tAmbiguousNames = VUHDO_getUnitByPrivateTankName(tName);

				if tAmbiguousNames then
					tAmbiguousMsg = format(VUHDO_I18N_PT_NAME_AMBIGUOUS, table.concat(tAmbiguousNames, ", "));

					VUHDO_Msg(tAmbiguousMsg, 1, 0.4, 0.4);
				elseif tUnit then
					tKey = VUHDO_getPrivateTankKey(tUnit);

					if tKey then
						VUHDO_PLAYER_TARGETS[tKey] = true;
					end
				end
			end
		end

		VUHDO_quickRaidReload();

		return;
	end

	tUnit = VUHDO_getPrivateTankUnitFromTarget();
	tKey = tUnit and VUHDO_getPrivateTankKey(tUnit);

	if not InCombatLockdown() and tKey then
		if VUHDO_PLAYER_TARGETS[tKey] then
			VUHDO_PLAYER_TARGETS[tKey] = nil;
		else
			VUHDO_PLAYER_TARGETS[tKey] = true;
		end

		VUHDO_quickRaidReload();
	end

	return;

end



--
do
	--
	local tParsedTexts;
	local tCommandWord;
	local tTokens;
	local tName;
	local tUnit;
	local tSubCommand;
	local tArgument;
	local tPanelNum;
	local tHelpText;
	local tCurrentValue;
	local tCount;
	local tDumpIndicator;
	local tDumpVerbose;
	function VUHDO_slashCmd(aCommand)

		tParsedTexts = VUHDO_textParse(aCommand);
		tCommandWord = strlower(tParsedTexts[1]);

		if strfind(tCommandWord, "opt") then
			if VuhDoNewOptionsTabbedFrame then
				if InCombatLockdown() and not VuhDoNewOptionsTabbedFrame:IsShown() then
					VUHDO_Msg("Seçenekler savaşta kullanılamaz!", 1, 0.4, 0.4);
				else
					VUHDO_CURR_LAYOUT = VUHDO_SPEC_LAYOUTS["selected"];
					VUHDO_CURRENT_PROFILE = VUHDO_CONFIG["CURRENT_PROFILE"];

					VUHDO_toggleMenu(VuhDoNewOptionsTabbedFrame);
				end
			else
				VUHDO_Msg(VUHDO_I18N_OPTIONS_NOT_LOADED, 1, 0.4, 0.4);
			end

		elseif tCommandWord == "pt" then
			VUHDO_slashCmdPrivateTanks(tParsedTexts[2]);

		elseif tCommandWord == "load" and tParsedTexts[2] then
			tTokens = VUHDO_splitString(tParsedTexts[2] .. (tParsedTexts[3] or ""), ",");

			if #tTokens >= 2 and not VUHDO_strempty(tTokens[2]) then
				tName = strtrim(tTokens[2]);

				if (VUHDO_SPELL_LAYOUTS[tName] ~= nil) then
					VUHDO_activateLayout(tName);
				else
					VUHDO_Msg(VUHDO_I18N_SPELL_LAYOUT_NOT_EXIST_1 .. tName .. VUHDO_I18N_SPELL_LAYOUT_NOT_EXIST_2, 1, 0.4, 0.4);
				end
			end

			if #tTokens >= 1 and not VUHDO_strempty(tTokens[1]) then
				VUHDO_loadProfile(strtrim(tTokens[1]));
			end

		elseif tCommandWord == "restrict" then
			tSubCommand = strlower(tParsedTexts[2] or "");

			if tSubCommand == "on" then
				VUHDO_setForcedAddonRestrictions(true);
			elseif tSubCommand == "off" then
				VUHDO_setForcedAddonRestrictions(false);
			elseif tSubCommand == "status" then
				VUHDO_printForcedAddonRestrictionStatus();
			elseif tSubCommand == "" then
				tCurrentValue = GetCVar("addonChallengeModeRestrictionsForced") or "0";
				VUHDO_setForcedAddonRestrictions(tCurrentValue ~= "1");
			else
				VUHDO_Msg("Kullanım: /vd restrict [on|off|status]");
			end

		elseif strfind(tCommandWord, "res") then
			for tPanelNum = 1, VUHDO_MAX_PANELS do
				VUHDO_PANEL_SETUP[tPanelNum]["POSITION"] = nil;
			end

			VUHDO_BUFF_SETTINGS["CONFIG"]["POSITION"] = {
				["x"] = 100, ["y"] = -100, ["point"] = "TOPLEFT", ["relativePoint"] = "TOPLEFT",
			};

			VUHDO_loadDefaultPanelSetup();
			VUHDO_reloadUI(false);

			VUHDO_Msg(VUHDO_I18N_PANELS_RESET);

		elseif tCommandWord == "lock" then
			VUHDO_CONFIG["LOCK_PANELS"] = not VUHDO_CONFIG["LOCK_PANELS"];

			if (VUHDO_CONFIG["LOCK_PANELS"]) then
				VUHDO_Msg(VUHDO_I18N_LOCK_PANELS_PRE .. VUHDO_I18N_LOCK_PANELS_LOCKED);
			else
				VUHDO_Msg(VUHDO_I18N_LOCK_PANELS_PRE .. VUHDO_I18N_LOCK_PANELS_UNLOCKED);
			end

			VUHDO_saveCurrentProfile();

		elseif tCommandWord == "show" then
			VUHDO_setPanelsVisible(true);

		elseif tCommandWord == "hide" then
			VUHDO_setPanelsVisible(false);

		elseif tCommandWord == "toggle" then
			VUHDO_setPanelsVisible(not VUHDO_CONFIG["SHOW_PANELS"]);

		elseif strfind(tCommandWord, "cast") or tCommandWord == "mt" then
			VUHDO_ctraBroadCastMaintanks();

			VUHDO_Msg(VUHDO_I18N_MTS_BROADCASTED);

		elseif (tCommandWord == "pron") then
			SetCVar("scriptProfile", "1");
			ReloadUI();

		elseif tCommandWord == "proff" then
			SetCVar("scriptProfile", "0");
			ReloadUI();

		elseif (strfind(tCommandWord, "chkvars")) then
			table.wipe(VUHDO_DEBUG);

			for tFName, _ in pairs(_G) do
				if(strsub(tFName, 1, 1) == "t" or strsub(tFName, 1, 1) == "s") then
					VUHDO_Msg("Emerging local variable " .. tFName);
				end
			end

		elseif strfind(tCommandWord, "mm") or strfind(tCommandWord, "map") then
			VUHDO_MM_SETTINGS["hide"] = VUHDO_forceBooleanValue(VUHDO_MM_SETTINGS["hide"]);
			VUHDO_MM_SETTINGS["hide"] = not VUHDO_MM_SETTINGS["hide"];

			VUHDO_initShowMinimap();

			VUHDO_Msg(VUHDO_I18N_MM_ICON .. (VUHDO_MM_SETTINGS["hide"] and VUHDO_I18N_CHAT_HIDDEN or VUHDO_I18N_CHAT_SHOWN));

		elseif strfind(tCommandWord, "compart") then
			VUHDO_MM_SETTINGS["addon_compartment_hide"] = VUHDO_forceBooleanValue(VUHDO_MM_SETTINGS["addon_compartment_hide"]);
			VUHDO_MM_SETTINGS["addon_compartment_hide"] = not VUHDO_MM_SETTINGS["addon_compartment_hide"];

			VUHDO_initShowAddOnCompartment();

			VUHDO_Msg(VUHDO_I18N_ADDON_COMPARTMENT_ICON ..
				(VUHDO_MM_SETTINGS["addon_compartment_hide"] and VUHDO_I18N_CHAT_HIDDEN or VUHDO_I18N_CHAT_SHOWN));

		elseif tCommandWord == "ui" then
			VUHDO_reloadUI(false);

		elseif strfind(tCommandWord, "role") then
			VUHDO_Msg("Roller sıfırlandı.");

			table.wipe(VUHDO_MANUAL_ROLES);

			VUHDO_reloadUI(false);

		elseif tCommandWord == "test" then
			table.wipe(VUHDO_DEBUG);

			collectgarbage("collect");

		elseif tCommandWord == "pool" then
			tSubCommand = strlower(tParsedTexts[2] or "");

			if tSubCommand == "on" then
				VUHDO_setPoolProfiling(true);
			elseif tSubCommand == "off" then
				VUHDO_setPoolProfiling(false);
			elseif strfind(tSubCommand, "res") then
				VUHDO_resetPoolMetrics();
			else
				VUHDO_printPoolMetrics();
			end

		elseif tCommandWord == "task" then
			tSubCommand = strlower(tParsedTexts[2] or "");

			if tSubCommand == "on" then
				VUHDO_setDeferredTaskProfiling(true);
			elseif tSubCommand == "off" then
				VUHDO_setDeferredTaskProfiling(false);
			elseif strfind(tSubCommand, "res") then
				VUHDO_resetDeferredTaskMetrics();
			else
				VUHDO_printDeferredTaskMetrics(false);
			end

		elseif tCommandWord == "sync" then
			if VuhDoNewOptionsTabbedFrame then
				VUHDO_syncAuditCatalogCoverage();
			else
				VUHDO_Msg(VUHDO_I18N_OPTIONS_NOT_LOADED, 1, 0.4, 0.4);
			end

		elseif strfind(tCommandWord, "hand") then
			tSubCommand = strlower(tParsedTexts[2] or "");

			if tSubCommand == "on" then
				VUHDO_setHandlerProfiling(true);
			elseif tSubCommand == "off" then
				VUHDO_setHandlerProfiling(false);
			elseif strfind(tSubCommand, "res") then
				VUHDO_resetHandlerMetrics();
			else
				VUHDO_printHandlerMetrics();
			end

		elseif strfind(tCommandWord, "sem") then
			tSubCommand = strlower(tParsedTexts[2] or "");

			if tSubCommand == "on" then
				VUHDO_setSemaphoreProfiling(true);
			elseif tSubCommand == "off" then
				VUHDO_setSemaphoreProfiling(false);
			elseif strfind(tSubCommand, "res") then
				VUHDO_resetSemaphoreMetrics();
			else
				VUHDO_printSemaphoreMetrics();
			end

		elseif tCommandWord == "defer" then
			tSubCommand = strlower(tParsedTexts[2] or "");

			if tSubCommand == "on" then
				VUHDO_setDeferredRedrawEnabled(true);
			elseif tSubCommand == "off" then
				VUHDO_setDeferredRedrawEnabled(false);
			elseif tSubCommand == "state" then
				VUHDO_printDeferredReloadState();
			else
				VUHDO_printDeferredRedrawStatus();
			end

		elseif strfind(tCommandWord, "prof") then
			tSubCommand = strlower(tParsedTexts[2] or "");

			if tSubCommand == "on" then
				VUHDO_setHandlerProfiling(true);
				VUHDO_setDeferredTaskProfiling(true);
				VUHDO_setPoolProfiling(true);
				VUHDO_setSemaphoreProfiling(true);
			elseif tSubCommand == "off" then
				VUHDO_setHandlerProfiling(false);
				VUHDO_setDeferredTaskProfiling(false);
				VUHDO_setPoolProfiling(false);
				VUHDO_setSemaphoreProfiling(false);
			elseif strfind(tSubCommand, "res") then
				VUHDO_resetHandlerMetrics();
				VUHDO_resetDeferredTaskMetrics();
				VUHDO_resetPoolMetrics();
				VUHDO_resetSemaphoreMetrics();
				VUHDO_resetAuraContainerMetrics();

				VUHDO_Msg("All profiling metrics reset.");
			elseif tSubCommand == "test" then
				VUHDO_testProfilingSystem();
			else
				VUHDO_showProfilingMetrics();
			end

		elseif tCommandWord == "pixel" then
			tSubCommand = strlower(tParsedTexts[2] or "");

			if tSubCommand == "test" then
				VUHDO_pixelTest();
			elseif tSubCommand == "spacing" then
				VUHDO_pixelTestSpacing();
			elseif tSubCommand == "hide" then
				VUHDO_pixelHideTestFrame();
			elseif tSubCommand == "scale" then
				VUHDO_pixelShowScale();
			elseif tSubCommand == "cache" then
				VUHDO_pixelPrintCacheStats();
			elseif tSubCommand == "validate" then
				tPanelNum = tonumber(tParsedTexts[3]);

				VUHDO_pixelValidate(tPanelNum);
			else
				VUHDO_pixelHelp();
			end

		elseif tCommandWord == "anim" then
			tSubCommand = strlower(tParsedTexts[2] or "");

			if tSubCommand == "test" then
				tCount = tonumber(tParsedTexts[3]) or 5;
				tCount = max(1, min(40, tCount));

				VUHDO_animTest(tCount);
			elseif tSubCommand == "hide" then
				VUHDO_animHideTestFrames();
			elseif tSubCommand == "on" then
				VUHDO_setAnimationGroupEnabled(true);
			elseif tSubCommand == "off" then
				VUHDO_setAnimationGroupEnabled(false);
			else
				VUHDO_animHelp();
			end

		elseif tCommandWord == "range" then
			tSubCommand = strlower(tParsedTexts[2] or "");
			tUnit = tParsedTexts[3];

			if tSubCommand == "" or strfind(tSubCommand, "help") or strfind(tSubCommand, "%?") then
				VUHDO_rangeHelp();
			else
				if not tUnit or tUnit == "" then
					tUnit = tSubCommand;
				end

				if not tUnit or tUnit == "" then
					_, tUnit = VUHDO_getCurrentMouseOver();
				end

				if not tUnit or tUnit == "" then
					tUnit = "mouseover";
				end

				VUHDO_dumpRangeDiagnostics(tUnit);
			end

		elseif tCommandWord == "aura" then
			tSubCommand = strlower(tParsedTexts[2] or "");

			if strfind(tSubCommand, "mig") then
				VUHDO_resetAndRemigrateAuras();
			elseif strfind(tSubCommand, "dump") then
				tUnit = "player";
				tDumpIndicator = nil;
				tDumpVerbose = false;

				for tDumpIdx = 3, #tParsedTexts do
					tArgument = tParsedTexts[tDumpIdx];

					if tArgument == "-v" then
						tDumpVerbose = true;
					elseif UnitExists(tArgument) or tArgument == "player" or tArgument == "target" or strfind(tArgument, "^raid") or strfind(tArgument, "^party") then
						tUnit = tArgument;
					elseif tArgument and tArgument ~= "" then
						tDumpIndicator = strupper(tArgument);
					end
				end

				VUHDO_dumpAuraDiagnostics(tUnit, tDumpIndicator, tDumpVerbose);
			elseif strfind(tSubCommand, "rebuild") then
				VUHDO_rebuildAuraOverlays();
			elseif strfind(tSubCommand, "restrict") then
				tArgument = strlower(tParsedTexts[3] or "");

				if tArgument == "on" then
					VUHDO_setForceAuraMode(1);

					VUHDO_Msg("Aura modu AÇIK (AuraContainers) - arayüz yeniden yükleniyor...");
					ReloadUI();
				elseif tArgument == "off" then
					VUHDO_setForceAuraMode(0);

					VUHDO_Msg("Aura modu KAPALI (UNIT_AURA) - arayüz yeniden yükleniyor...");
					ReloadUI();
				elseif tArgument == "auto" then
					VUHDO_setForceAuraMode(nil);

					VUHDO_Msg("Aura modu otomatik - arayüz yeniden yükleniyor...");
					ReloadUI();
				else
					VUHDO_Msg("Aura mode: " .. (VUHDO_isAuraModeContainers() and "on" or "off"));
					VUHDO_Msg("Aura data restricted: " .. (VUHDO_isAuraDataRestricted() and "yes" or "no"));
					VUHDO_Msg("Force aura mode: " .. (VUHDO_FORCE_AURA_MODE == nil and "auto" or tostring(VUHDO_FORCE_AURA_MODE)));
				end
			else
				VUHDO_auraHelp();
			end

		elseif tCommandWord == "ab" or tCommandWord == "about" then
			VUHDO_printAbout();

		elseif aCommand == "?" or strfind(tCommandWord, "help") or aCommand == "" then
			tHelpText = (VUHDO_I18N_COMMAND_LIST or ""):gsub("\n", "|n");
			VUHDO_MsgC(tHelpText);

		else
			VUHDO_Msg(VUHDO_I18N_BAD_COMMAND, 1, 0.4, 0.4);
		end

		return;

	end
end



--
local tEvent;
local function VUHDO_UnRegisterEvent(aCondition, ...)

	for tCnt = 1, select("#", ...) do
		tEvent = select(tCnt, ...);

		if aCondition then
			VUHDO_INSTANCE:RegisterEvent(tEvent);
		else
			VUHDO_INSTANCE:UnregisterEvent(tEvent);
		end
	end

	return;

end



--
local tIsShieldInterest;
local tIsHealAbsorbInterest;
function VUHDO_updateGlobalToggles()

	if not VUHDO_INSTANCE then
		return;
	end

	VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_THREAT_LEVEL] = VUHDO_isAnyoneInterestedIn(VUHDO_UPDATE_THREAT_LEVEL);

	VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_THREAT_PERC] = VUHDO_isAnyoneInterestedIn(VUHDO_UPDATE_THREAT_PERC);
	VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_AGGRO] = VUHDO_isAnyoneInterestedIn(VUHDO_UPDATE_AGGRO);

	VUHDO_TIMERS["UPDATE_AGGRO"] =
		 (VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_THREAT_PERC] or VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_AGGRO])
		 and 1 or -1;

	VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_NUM_CLUSTER] = VUHDO_isAnyoneInterestedIn(VUHDO_UPDATE_NUM_CLUSTER);
	VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_MOUSEOVER_CLUSTER] = VUHDO_isAnyoneInterestedIn(VUHDO_UPDATE_MOUSEOVER_CLUSTER);
	VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_AOE_ADVICE] = VUHDO_isAnyoneInterestedIn(VUHDO_UPDATE_AOE_ADVICE);

	if VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_NUM_CLUSTER]
	 or VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_MOUSEOVER_CLUSTER]
	 or VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_AOE_ADVICE]
	 or (VUHDO_isShowDirectionArrow() and VUHDO_CONFIG["DIRECTION"]["isDistanceText"]) then
		VUHDO_TIMERS["UPDATE_CLUSTERS"] = 1;
		VUHDO_TIMERS["UPDATE_AOE"] = VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_AOE_ADVICE] and 1 or -1;
	else
		VUHDO_TIMERS["UPDATE_CLUSTERS"] = -1;
		VUHDO_TIMERS["UPDATE_AOE"] = -1;
	end

	VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_MOUSEOVER] = VUHDO_isAnyoneInterestedIn(VUHDO_UPDATE_MOUSEOVER);
	VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_MOUSEOVER_GROUP] = VUHDO_isAnyoneInterestedIn(VUHDO_UPDATE_MOUSEOVER_GROUP);

	if VUHDO_isAnyoneInterestedIn(VUHDO_UPDATE_UNIT_TARGET) then
		VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_UNIT_TARGET] = true;
		VUHDO_TIMERS["REFRESH_TARGETS"] = 1;
	else
		VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_UNIT_TARGET] = false;
		VUHDO_TIMERS["REFRESH_TARGETS"] = -1;
	end

	VUHDO_TIMERS["REFRESH_INSPECT"] = (VUHDO_CONFIG["IS_SCAN_TALENTS"] and VUHDO_FLAVOR_SPEC_SPECIALIZATIONS == VUHDO_getFlavorSpecModel()) and 1 or -1

	VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_PETS]
		= VUHDO_isModelConfigured(VUHDO_ID_PETS)
		or VUHDO_isModelConfigured(VUHDO_ID_SELF_PET); -- Event nicht deregistrieren => Problem mit manchen Vehikeln

	VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_PLAYER_TARGET]
		= (VUHDO_isModelConfigured(VUHDO_ID_PRIVATE_TANKS) and not VUHDO_CONFIG["OMIT_TARGET"])
		or VUHDO_isModelConfigured(VUHDO_ID_TARGET);

	-- VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_AURA_INFERENCE] = "SHAMAN" == VUHDO_PLAYER_CLASS or "EVOKER" == VUHDO_PLAYER_CLASS or "PRIEST" == VUHDO_PLAYER_CLASS;
	VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_AURA_INFERENCE] = false;

	-- VUHDO_UnRegisterEvent(VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_AURA_INFERENCE],
	-- 	"UNIT_SPELLCAST_SUCCEEDED");

	-- VUHDO_UnRegisterEvent("EVOKER" == VUHDO_PLAYER_CLASS and VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_AURA_INFERENCE],
	-- 	"UNIT_SPELLCAST_EMPOWER_STOP");

	VUHDO_UnRegisterEvent(not VUHDO_CONFIG["IS_READY_CHECK_DISABLED"],
		"READY_CHECK", "READY_CHECK_CONFIRM", "READY_CHECK_FINISHED");

	VUHDO_UnRegisterEvent(VUHDO_isPlayerKnowsSwiftmend(), "SPELL_UPDATE_COOLDOWN", "SPELL_UPDATE_CHARGES");

	tIsShieldInterest =
		VUHDO_PANEL_SETUP["BAR_COLORS"]["HOTS"]["showShieldAbsorb"]
			or VUHDO_CONFIG["SHOW_SHIELD_BAR"]
			or VUHDO_isAnyoneInterestedIn(VUHDO_UPDATE_SHIELD);

	tIsHealAbsorbInterest =
		VUHDO_CONFIG["SHOW_HEAL_ABSORB_BAR"]
			or VUHDO_isAnyoneInterestedIn(VUHDO_UPDATE_SHIELD);

	VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_SHIELD] =
		tIsShieldInterest
			or tIsHealAbsorbInterest;

	VUHDO_INTERNAL_TOGGLES[VUHDO_UPDATE_SPELL_TRACE] = not sSecretsEnabled
		and (VUHDO_CONFIG["SHOW_SPELL_TRACE"]
			or VUHDO_isAnyoneInterestedIn(VUHDO_UPDATE_SPELL_TRACE));

	VUHDO_updateToggledUnitEvents();

	return;

end



--
function VUHDO_loadVariables(anIsProfileSwitch)

	_, VUHDO_PLAYER_CLASS = UnitClass("player");
	VUHDO_PLAYER_NAME, tSecond = UnitName("player");
	VUHDO_PLAYER_FULL_NAME = VUHDO_buildUnitFullName(VUHDO_PLAYER_NAME, tSecond);

	VUHDO_loadDefaultConfig();
	VUHDO_setDeferredRedrawEnabled(VUHDO_CONFIG["USE_DEFERRED_REDRAW"], true);
	VUHDO_loadSpellArray();
	VUHDO_loadDefaultPanelSetup();

	for tLayoutName, tLayout in pairs(VUHDO_SPELL_LAYOUTS) do
		VUHDO_migrateKeyLayoutToAuras(tLayout);
	end

	VUHDO_initBuffSettings();
	VUHDO_loadDefaultBouquets(anIsProfileSwitch);
	VUHDO_panelRedrawInitLocalOverrides();
	VUHDO_initClassColors();
	VUHDO_initTextProviderConfig();

	VUHDO_lnfPatchFont(VuhDoOptionsTooltipText, "Text");

	VUHDO_clearSaneValueCache();

	return;

end



--
function VUHDO_normalRaidReload(anIsReloadBuffs)

	if VUHDO_isConfigPanelShowing() then
		return;
	end

	VUHDO_TIMERS["RELOAD_RAID"] = 2.3;

	if anIsReloadBuffs then
		VUHDO_IS_RELOAD_BUFFS = true;
	end

	return;

end



--
function VUHDO_quickRaidReload()

	VUHDO_TIMERS["RELOAD_RAID"] = 0.3;

	return;

end



--
function VUHDO_lateRaidReload()

	if not VUHDO_isReloadPending() then
		VUHDO_TIMERS["RELOAD_RAID"] = 5;
	end

	return;

end



--
function VUHDO_isReloadPending()

	return VUHDO_TIMERS["RELOAD_RAID"] > 0
		or VUHDO_TIMERS["RELOAD_UI"] > 0
		or VUHDO_IS_RELOADING;

end



--
function VUHDO_timeReloadUI(aNumSecs, anIsLnf)

	VUHDO_TIMERS["RELOAD_UI"] = aNumSecs;
	VUHDO_RELOAD_UI_IS_LNF = anIsLnf;

	return;

end



--
function VUHDO_timeRegisterBouquets(aNumSecs)

	VUHDO_TIMERS["REGISTER_BOUQUETS"] = aNumSecs;

	return;

end



--
function VUHDO_timeRebuildAuraGroups(aNumSecs)

	VUHDO_TIMERS["REBUILD_AURA_GROUPS"] = aNumSecs;

	return;

end



--
function VUHDO_timeRefreshOverlays(aNumSecs)

	VUHDO_TIMERS["REFRESH_OVERLAYS"] = aNumSecs;

	return;

end



--
function VUHDO_timeRefreshAuraContainers(aNumSecs)

	VUHDO_TIMERS["REFRESH_AURA_CONTAINERS"] = aNumSecs or 0.5;

	return;

end



--
function VUHDO_timeRefreshMissingBuffContainers(aNumSecs)

	VUHDO_TIMERS["REFRESH_MISSING_BUFF_CONTAINERS"] = aNumSecs or 0.3;

	return;

end



--
function VUHDO_timeRedrawPanel(aPanelNum, aNumSecs)

	VUHDO_RELOAD_PANEL_NUM = aPanelNum;
	VUHDO_TIMERS["RELOAD_PANEL"] = aNumSecs;

	return;

end






--
local tIsOnGCD;
local tDuration;
function VUHDO_initGcd()

	if not sSecretsEnabled then
		VUHDO_GCD_UPDATE = true;

		return;
	end

	_, _, _, _, tIsOnGCD, tDuration = GetSpellCooldown(VUHDO_SPELL_ID.GLOBAL_COOLDOWN);

	if tIsOnGCD == true and tDuration then
		VuhDoGcdStatusBar:SetTimerDuration(tDuration, Enum.StatusBarInterpolation.Immediate, Enum.StatusBarTimerDirection.RemainingTime);
	end

	return;

end



--
local function VUHDO_doReloadRoster(anIsQuick)

	if not VUHDO_isConfigPanelShowing() then
		if VUHDO_IS_RELOADING or VUHDO_isDeferredRefreshActive() or VUHDO_isDeferredRedrawActive() then
			VUHDO_RELOAD_AFTER_BATTLE = true;

			VUHDO_quickRaidReload();
		else
			VUHDO_rebuildTargets();

			if InCombatLockdown() then
				VUHDO_RELOAD_AFTER_BATTLE = true;
				VUHDO_IS_RELOADING = true;

				VUHDO_refreshRaidMembers();
				VUHDO_updateAllRaidBars();
				VUHDO_initAllEventBouquets();

				VUHDO_updatePanelVisibility();

				VUHDO_IS_RELOADING = false;
			else
				VUHDO_refreshUI();

				VUHDO_TIMERS["RELOAD_RAID"] = 0;

				if VUHDO_IS_RELOAD_BUFFS and not anIsQuick then
					VUHDO_reloadBuffPanel();

					VUHDO_IS_RELOAD_BUFFS = false;
				end

				VUHDO_initHideBlizzRaid(); -- Scheint bei betreten eines Raids von aussen getriggert zu werden.
			end
		end

		VUHDO_initDebuffsIfNeeded(); -- Verzgerung nach Taltentwechsel-Spell?
	end

	return;

end



--
local sTimerDelta;
local function VUHDO_setTimerDelta(aTimeDelta)

	sTimerDelta = aTimeDelta;

	return;

end



--
local function VUHDO_checkResetTimer(aTimerName, aNextTick)

	if VUHDO_TIMERS[aTimerName] > 0 then
		VUHDO_TIMERS[aTimerName] = VUHDO_TIMERS[aTimerName] - sTimerDelta;

		if VUHDO_TIMERS[aTimerName] <= 0 then
			VUHDO_TIMERS[aTimerName] = aNextTick;

			return true;
		end
	end

	return false;

end



--
local function VUHDO_checkTimer(aTimerName)

	if VUHDO_TIMERS[aTimerName] > 0 then
		VUHDO_TIMERS[aTimerName] = VUHDO_TIMERS[aTimerName] - sTimerDelta;

		return VUHDO_TIMERS[aTimerName] <= 0;
	end

	return false;

end



--
do
	--
	local sTimeDelta = 0;
	local sSlowDelta = 0;
	local sHotDebuffToggle = 1;
	local sAutoProfile;
	local sTrigger;



	--
	local function VUHDO_finalizeOnUpdateMetrics(anOverallStart, aSeg2Start, aSegment1Total)

		if VUHDO_HANDLER_PROFILING_ENABLED then
			VUHDO_updateOnUpdateSubSegmentMetrics("segment1Total", aSegment1Total);
			VUHDO_updateOnUpdateSubSegmentMetrics("segment2Total", (debugprofilestop() - aSeg2Start) * 1000);
			VUHDO_updateOnUpdateSubSegmentMetrics("total", (debugprofilestop() - anOverallStart) * 1000);

			VUHDO_HANDLER_PROFILING_ONUPDATE_INVOCATIONS = VUHDO_HANDLER_PROFILING_ONUPDATE_INVOCATIONS + 1;
		end

		return;

	end



	--
	local tGcdStart;
	local tGcdDurationRemaining;
	local function VUHDO_handleSegment1A(aTimeDelta)

		-- Update GCD-Bar
		if VUHDO_GCD_UPDATE then
			tGcdStart, tGcdDurationRemaining = GetSpellCooldown(VUHDO_SPELL_ID.GLOBAL_COOLDOWN);

			if (tGcdDurationRemaining or 0) == 0 then
				VuhDoGcdStatusBar:SetValue(0);
				VUHDO_GCD_UPDATE = false;
			else
				VuhDoGcdStatusBar:SetMinMaxValues(0, 1);
				VuhDoGcdStatusBar:SetValue((tGcdDurationRemaining - (GetTime() - tGcdStart)) / tGcdDurationRemaining);
			end
		end

		-- Direction Arrow
		if sIsDirectionArrow and VuhDoDirectionFrame["shown"] then
			VUHDO_updateDirectionFrame();
		end

		-- Own frame flash routines to avoid taints
		VUHDO_UIFrameFlash_OnUpdate(aTimeDelta);

		return;

	end



	--
	local function VUHDO_handleSegment1B(aTimeDelta)

		VUHDO_resetAuraFilterResultCachePerFrame();

		VUHDO_processDeferredTaskQueue(aTimeDelta);

		return;

	end



	--
	local tIsDeferredActive;
	local function VUHDO_handleSegment2A(aTimeDelta)

		-- reload UI?
		if VUHDO_checkTimer("RELOAD_UI") then
			tIsDeferredActive = VUHDO_CONFIG and VUHDO_CONFIG["USE_DEFERRED_REDRAW"] and VUHDO_isDeferredRedrawActive();

			if VUHDO_IS_RELOADING or InCombatLockdown() or tIsDeferredActive then
				VUHDO_TIMERS["RELOAD_UI"] = 0.3;
			else
				if VUHDO_RELOAD_UI_IS_LNF then
					VUHDO_lnfReloadUI();
				else
					VUHDO_reloadUI(false);
				end

				VUHDO_initOptions();

				VUHDO_FIRST_RELOAD_UI = true;
			end
		end

		return;

	end



	--
	local tIsDeferredActive;
	local function VUHDO_handleSegment2B(aTimeDelta)

		-- reset single panel?
		if VUHDO_checkTimer("RELOAD_PANEL") then
			tIsDeferredActive = VUHDO_CONFIG and VUHDO_CONFIG["USE_DEFERRED_REDRAW"] and VUHDO_isDeferredRedrawActive();

			if VUHDO_IS_RELOADING or InCombatLockdown() or tIsDeferredActive then
				VUHDO_TIMERS["RELOAD_PANEL"] = 0.3;
			else
				VUHDO_PROHIBIT_REPOS = true;

				VUHDO_initAllBurstCaches();
				VUHDO_buildGenericHealthBarBouquet();
				VUHDO_buildGenericTargetHealthBouquet();
				VUHDO_registerAllBouquets(false);
				VUHDO_initAllEventBouquets();
				VUHDO_redrawPanel(VUHDO_RELOAD_PANEL_NUM);

				if not VUHDO_CONFIG["USE_DEFERRED_REDRAW"] then
					VUHDO_updateAllPanelBars(VUHDO_RELOAD_PANEL_NUM);

					VUHDO_redisplayAllUnitAuras();
				end

				VUHDO_PROHIBIT_REPOS = false;
			end
		end

		if VUHDO_checkTimer("REGISTER_BOUQUETS") then
			tIsDeferredActive = VUHDO_CONFIG and VUHDO_CONFIG["USE_DEFERRED_REDRAW"] and VUHDO_isDeferredRedrawActive();

			if VUHDO_IS_RELOADING or InCombatLockdown() or tIsDeferredActive then
				VUHDO_TIMERS["REGISTER_BOUQUETS"] = 0.3;
			else
				VUHDO_registerAllBouquets(false);
				VUHDO_rebuildAuraAnchorsForBouquetListGroups();
				VUHDO_initAllEventBouquets();
			end
		end

		if VUHDO_checkTimer("REBUILD_AURA_GROUPS") then
			if InCombatLockdown() then
				VUHDO_TIMERS["REBUILD_AURA_GROUPS"] = 0.3;
			else
				VUHDO_applyAuraGroupChanges();
			end
		end

		if VUHDO_checkTimer("REFRESH_OVERLAYS") then
			if InCombatLockdown() then
				VUHDO_TIMERS["REFRESH_OVERLAYS"] = 0.3;
			else
				VUHDO_invalidateAllOverlayPlans();
				VUHDO_syncAllOverlayUnits(false);
			end
		end

		return;

	end



	--
	local function VUHDO_loadChangedAutoProfile()

		if InCombatLockdown() or VUHDO_IS_CONFIG then
			return false;
		end

		sAutoProfile, sTrigger = VUHDO_getAutoProfile();

		if not sAutoProfile then
			return false;
		end

		VUHDO_Msg(VUHDO_I18N_AUTO_ARRANG_1 .. sTrigger .. VUHDO_I18N_AUTO_ARRANG_2 .. "|cffffffff" .. sAutoProfile .. "|r\"");

		VUHDO_loadProfile(sAutoProfile);

		sAutoProfile = nil;
		VUHDO_TIMERS["RELOAD_RAID"] = 0;
		VUHDO_IS_RELOAD_BUFFS = false;

		return true;

	end



	--
	local function VUHDO_handleSegment2C(aTimeDelta)

		-- Reload raid roster?
		if VUHDO_checkTimer("RELOAD_RAID") and not VUHDO_loadChangedAutoProfile() then
			VUHDO_doReloadRoster(false);
		end

		-- Quick update after raid roster change?
		if VUHDO_checkTimer("RELOAD_ROSTER") and not VUHDO_loadChangedAutoProfile() then
			VUHDO_doReloadRoster(true);
		end

		-- refresh HoTs, cyclic bouquets and custom debuffs?
		if VUHDO_checkResetTimer("UPDATE_HOTS", sHotToggleUpdateSecs) then
			if VUHDO_RAID then
				if sHotDebuffToggle == 1 then
					if not sSecretsEnabled then
						VUHDO_updateAllHoTs();
					end

					if not sSecretsEnabled and VUHDO_INTERNAL_TOGGLES[18] then -- VUHDO_UPDATE_MOUSEOVER_CLUSTER
						VUHDO_updateClusterHighlights();
					end

					if not sSecretsEnabled and VUHDO_INTERNAL_TOGGLES[37] then -- VUHDO_UPDATE_SPELL_TRACE
						VUHDO_updateSpellTrace();
					end
				elseif sHotDebuffToggle == 2 then
					VUHDO_updateAllCyclicBouquets(false);
				else
					if not sSecretsEnabled then
						VUHDO_updateAllDebuffIcons(false);
					end

					-- Reload after played gained control
					if not HasFullControl() then
						VUHDO_LOST_CONTROL = true;
					else
						if VUHDO_LOST_CONTROL then
							if VUHDO_TIMERS["RELOAD_RAID"] <= 0 then
								VUHDO_TIMERS["CUSTOMIZE"] = 0.3;
							end

							VUHDO_LOST_CONTROL = false;
						end
					end
				end
			end

			if sHotDebuffToggle > 2 then
				sHotDebuffToggle = 1;
			else
				sHotDebuffToggle = sHotDebuffToggle + 1;
			end
		end

		-- track dragged panel coords
		if VUHDO_DRAG_PANEL and VUHDO_checkResetTimer("REFRESH_DRAG", 0.05) then
			VUHDO_refreshDragTarget(VUHDO_DRAG_PANEL);
		end

		-- Set Button colors without repositioning
		if VUHDO_checkTimer("CUSTOMIZE") then
			VUHDO_updateAllRaidTargetIndices();
			VUHDO_updateAllRaidBars();
			VUHDO_initAllEventBouquets();
		end

		if VUHDO_checkTimer("REFRESH_AURA_CONTAINERS") then
			VUHDO_syncAuraContainersForAllRaidUnits();

			VUHDO_syncAllOverlayUnits(false);
		end

		if VUHDO_checkTimer("REFRESH_MISSING_BUFF_CONTAINERS") then
			if VUHDO_refreshAllMissingBuffContainers() then
				VUHDO_TIMERS["REFRESH_MISSING_BUFF_CONTAINERS"] = 0.1;
			else
				VUHDO_TIMERS["REFRESH_MISSING_BUFF_CONTAINERS"] = 0.5;
			end
		end

		-- Refresh Tooltip
		if VUHDO_checkResetTimer("REFRESH_TOOLTIP", 2.3) and VuhDoTooltip:IsShown() then
			VUHDO_updateTooltip();
		end

		-- Refresh custom debuff Tooltip
		if not sSecretsEnabled and VUHDO_checkResetTimer("REFRESH_CUDE_TOOLTIP", 1) then
			VUHDO_updateCustomDebuffTooltip();
		end

		-- Refresh Buff Watch
		if VUHDO_checkResetTimer("BUFF_WATCH", sBuffsRefreshSecs) then
			VUHDO_updateBuffPanel();
		end

		-- Refresh Inspect, check timeout
		if VUHDO_NEXT_INSPECT_UNIT ~= nil and GetTime() > VUHDO_NEXT_INSPECT_TIME_OUT then
			VUHDO_setRoleUndefined(VUHDO_NEXT_INSPECT_UNIT);

			VUHDO_NEXT_INSPECT_UNIT = nil;
		end

		-- Refresh targets not in raid
		if VUHDO_checkResetTimer("REFRESH_TARGETS", 0.51) then
			VUHDO_updateAllOutRaidTargetButtons();
		end

		return;

	end



	--
	local function VUHDO_handleSegment2D(aTimeDelta)

		-- refresh aggro?
		if VUHDO_checkResetTimer("UPDATE_AGGRO", sAggroRefreshSecs) then
			VUHDO_updateAllAggro();
		end

		-- refresh range fallback (slow, range only)
		if VUHDO_checkResetTimer("UPDATE_RANGE", sRangeFallbackSecs) then
			VUHDO_updateAllRange();
		end

		-- refresh visibility / charm / baseRange (fast)
		if VUHDO_checkResetTimer("UPDATE_VISIBILITY_CHARM_RANGE", sRangeRefreshSecs) then
			VUHDO_updateAllVisibilityCharmRange();
		end

		-- Refresh Cluster
		if not sSecretsEnabled and VUHDO_checkResetTimer("UPDATE_CLUSTERS", sClusterRefreshSecs) then
			VUHDO_updateAllClusters();
		end

		-- AoE advice
		if not sSecretsEnabled and VUHDO_checkResetTimer("UPDATE_AOE", sAoeRefreshSecs) then
			VUHDO_aoeUpdateAll();
		end

		return;

	end



	--
	local function VUHDO_handleSegment2F(aTimeDelta)

		-- reload after battle
		if VUHDO_RELOAD_AFTER_BATTLE and not InCombatLockdown() then
			VUHDO_RELOAD_AFTER_BATTLE = false;

			if VUHDO_TIMERS["RELOAD_RAID"] <= 0 then
				VUHDO_quickRaidReload();

				if VUHDO_IS_RELOAD_BUFFS then
					VUHDO_reloadBuffPanel();

					VUHDO_IS_RELOAD_BUFFS = false;
				end
			end
		end

		return;

	end



	--
	local function VUHDO_handleSegment2G(aTimeDelta)

		if not InCombatLockdown() then
			sAutoProfile, sTrigger = VUHDO_getAutoProfile();
		end

		return;

	end



	--
	local function VUHDO_handleSegment2H(aTimeDelta)

		if not InCombatLockdown() and sAutoProfile and not VUHDO_IS_CONFIG then
			VUHDO_Msg(VUHDO_I18N_AUTO_ARRANG_1 .. sTrigger .. VUHDO_I18N_AUTO_ARRANG_2 .. "|cffffffff" .. sAutoProfile .. "|r\"");

			VUHDO_loadProfile(sAutoProfile);
		end

		return;

	end



	--
	local function VUHDO_handleSegment2I(aTimeDelta)

		return;

	end



	--
	local function VUHDO_handleSegment2J(aTimeDelta)

		VUHDO_removeObsoleteShields();

		return;

	end



	--
	local function VUHDO_handleSegment2K(aTimeDelta)

		-- Unit Zones
		if VUHDO_checkResetTimer("RELOAD_ZONES", 3.45) then
			if VUHDO_RAID then
				for tUnit, tUnitInfo in pairs(VUHDO_RAID) do
					tUnitInfo["zone"], tUnitInfo["map"] = VUHDO_getUnitZoneName(tUnit);
				end
			end
		end

		return;

	end



	--
	local function VUHDO_handleSegment2L(aTimeDelta)

		if not VUHDO_NEXT_INSPECT_UNIT and not InCombatLockdown() and VUHDO_checkResetTimer("REFRESH_INSPECT", 2.1) then
			VUHDO_tryInspectNext();
		end

		return;

	end



	--
	local function VUHDO_handleSegment2M(aTimeDelta)

		-- Refresh d/c shield macros?
		if VUHDO_checkTimer("MIRROR_TO_MACRO") then
			if InCombatLockdown() then
				VUHDO_TIMERS["MIRROR_TO_MACRO"] = 2;
			else
				VUHDO_mirrorToMacro();
			end
		end

		return;

	end



	--
	local tStartTime;
	local tProfilerResult;
	local tCallbackResult;
	local tEndTime;
	local tDuration;
	function VUHDO_profileSegment(aSegmentName, aCallback, ...)

		if not VUHDO_HANDLER_PROFILING_ENABLED then
			return aCallback(...), 0;
		end

		if MeasureCall then
			tProfilerResult, tCallbackResult = MeasureCall(aCallback, ...);

			if tProfilerResult and tProfilerResult["elapsedMilliseconds"] then
				tDuration = tProfilerResult["elapsedMilliseconds"] * 1000;
			else
				tDuration = 0;
			end
		else
			tStartTime = debugprofilestop();

			tCallbackResult = aCallback(...);

			tEndTime = debugprofilestop();
			tDuration = (tEndTime - tStartTime) * 1000;
		end

		VUHDO_updateOnUpdateSubSegmentMetrics(aSegmentName, tDuration);

		return tCallbackResult, tDuration;

	end



	--
	local tSegmentCallbacks = {
		["segment1A"] = function(aTimeDelta) VUHDO_handleSegment1A(aTimeDelta); end,
		["segment1B"] = function(aTimeDelta) VUHDO_handleSegment1B(aTimeDelta); end,
		["segment2A"] = function(aTimeDelta) VUHDO_handleSegment2A(aTimeDelta); end,
		["segment2B"] = function(aTimeDelta) VUHDO_handleSegment2B(aTimeDelta); end,
		["segment2C"] = function(aTimeDelta) VUHDO_handleSegment2C(aTimeDelta); end,
		["segment2D"] = function(aTimeDelta) VUHDO_handleSegment2D(aTimeDelta); end,
		["segment2E"] = function(aTimeDelta) VUHDO_handleSegment2E(aTimeDelta); end,
		["segment2F"] = function(aTimeDelta) VUHDO_handleSegment2F(aTimeDelta); end,
		["segment2G"] = function(aTimeDelta) VUHDO_handleSegment2G(aTimeDelta); end,
		["segment2H"] = function(aTimeDelta) VUHDO_handleSegment2H(aTimeDelta); end,
		["segment2I"] = function(aTimeDelta) VUHDO_handleSegment2I(aTimeDelta); end,
		["segment2J"] = function(aTimeDelta) VUHDO_handleSegment2J(aTimeDelta); end,
		["segment2K"] = function(aTimeDelta) VUHDO_handleSegment2K(aTimeDelta); end,
		["segment2L"] = function(aTimeDelta) VUHDO_handleSegment2L(aTimeDelta); end,
		["segment2M"] = function(aTimeDelta) VUHDO_handleSegment2M(aTimeDelta); end,
	};
	local tStartTimes = {
		[1] = -1, -- overall
		[2] = -1, -- segment
		[3] = -1, -- subsegment
	};
	local tSegment1ADuration;
	local tSegment1BDuration;
	local tSegment1Total;
	function VUHDO_OnUpdate(anInstance, aTimeDelta)

		if VUHDO_HANDLER_PROFILING_ENABLED then
			tStartTimes[1] = debugprofilestop();
			tStartTimes[2] = tStartTimes[1];

			tSegment1Total = 0;
		end

		-----------------------------------------------------
		-- Segment 1
		-----------------------------------------------------

		-----------------------------------------------------
		-- These need to update very frequenly to not stutter
		-- --------------------------------------------------

		-- Segment 1A - Animations etc.

		_, tSegment1ADuration = VUHDO_profileSegment("segment1A", tSegmentCallbacks["segment1A"], aTimeDelta);

		if VUHDO_HANDLER_PROFILING_ENABLED then
			tSegment1Total = tSegment1Total + tSegment1ADuration;
		end

		-- Segment 1B - Process deferred tasks
		_, tSegment1BDuration = VUHDO_profileSegment("segment1B", tSegmentCallbacks["segment1B"], aTimeDelta);

		if VUHDO_HANDLER_PROFILING_ENABLED then
			tSegment1Total = tSegment1Total + tSegment1BDuration;

			tStartTimes[2] = debugprofilestop();
		end

		---------------------------------------------------------
		-- Segment 2
		---------------------------------------------------------

		---------------------------------------------------------
		-- From here 0.08 (80 msec) sec tick should be sufficient
		---------------------------------------------------------

		if sTimeDelta < 0.08 then
			sTimeDelta = sTimeDelta + aTimeDelta;
			sSlowDelta = sSlowDelta + aTimeDelta;

			VUHDO_finalizeOnUpdateMetrics(tStartTimes[1], tStartTimes[2], tSegment1Total);

			return;
		else
			VUHDO_setTimerDelta(sTimeDelta);

			sTimeDelta = 0;
		end

		if VUHDO_HANDLER_PROFILING_ENABLED then
			tStartTimes[3] = debugprofilestop();
		end

		-- Segment 2A - UI reloads

		VUHDO_profileSegment("segment2A", tSegmentCallbacks["segment2A"], aTimeDelta);

		---------------------------------------------------
		------------------------- below only if vars loaded
		---------------------------------------------------

		if not VUHDO_VARIABLES_LOADED then
			VUHDO_finalizeOnUpdateMetrics(tStartTimes[1], tStartTimes[2], tSegment1Total);

			return;
		end

		-- Segment 2B: Roster and core updates

		VUHDO_profileSegment("segment2B", tSegmentCallbacks["segment2B"], aTimeDelta);

		-- Segment 2C: Roster and core updates

		VUHDO_profileSegment("segment2C", tSegmentCallbacks["segment2C"], aTimeDelta);

		-- Segment 2D: Combat checks

		if not VUHDO_isConfigDemoUsers() then
			VUHDO_profileSegment("segment2D", tSegmentCallbacks["segment2D"], aTimeDelta);
		end

		if VUHDO_CONFIG_SHOW_RAID then
			VUHDO_finalizeOnUpdateMetrics(tStartTimes[1], tStartTimes[2], tSegment1Total);

			return;
		end

		-- Segment 2E: Slow tasks

		if VUHDO_HANDLER_PROFILING_ENABLED then
			tStartTimes[3] = debugprofilestop();
		end

		if sSlowDelta < 1.2 then
			sSlowDelta = sSlowDelta + sTimerDelta;

			if VUHDO_HANDLER_PROFILING_ENABLED then
				VUHDO_updateOnUpdateSubSegmentMetrics("segment2E", (debugprofilestop() - tStartTimes[3]) * 1000);
			end

			VUHDO_finalizeOnUpdateMetrics(tStartTimes[1], tStartTimes[2], tSegment1Total);

			return;
		else
			VUHDO_setTimerDelta(aTimeDelta + sSlowDelta);

			sSlowDelta = 0;
		end

		if VUHDO_HANDLER_PROFILING_ENABLED then
			VUHDO_updateOnUpdateSubSegmentMetrics("segment2E", (debugprofilestop() - tStartTimes[3]) * 1000);
			tStartTimes[3] = debugprofilestop();
		end

		-- Segment 2F: Post-Combat Reload

		VUHDO_profileSegment("segment2F", tSegmentCallbacks["segment2F"], aTimeDelta);

		-- automatic profiles, shield cleanup, hide generic blizz party
		if VUHDO_checkResetTimer("CHECK_PROFILES", 3.1) then
			if sSecretsEnabled then
				VUHDO_checkAuraDataRestrictedState(false);
			end

			-- Segment 2G: Auto profile detection

			VUHDO_profileSegment("segment2G", tSegmentCallbacks["segment2G"], aTimeDelta);

			-- Segment 2H: Auto profile loading

			VUHDO_profileSegment("segment2H", tSegmentCallbacks["segment2H"], aTimeDelta);

			-- Segment 2I: Hide Blizzard compact party frame

			VUHDO_profileSegment("segment2I", tSegmentCallbacks["segment2I"], aTimeDelta);

			-- Segment 2J: Remove obsolete shields

			VUHDO_profileSegment("segment2J", tSegmentCallbacks["segment2J"], aTimeDelta);
		end

		-- Segment 2K: Zones

		VUHDO_profileSegment("segment2K", tSegmentCallbacks["segment2K"], aTimeDelta);

		-- Segment 2L: Inspect

		VUHDO_profileSegment("segment2L", tSegmentCallbacks["segment2L"], aTimeDelta);

		-- Segment 2M: Macros

		VUHDO_profileSegment("segment2M", tSegmentCallbacks["segment2M"], aTimeDelta);

		VUHDO_finalizeOnUpdateMetrics(tStartTimes[1], tStartTimes[2], tSegment1Total);

		VUHDO_flushProfilingBatch();

		return;

	end
end



--
local VUHDO_ALL_EVENT_NAMES = {
	"VARIABLES_LOADED", "PLAYER_ENTERING_WORLD", "SPELLS_CHANGED",
	"GROUP_ROSTER_UPDATE", "INSTANCE_ENCOUNTER_ENGAGE_UNIT", "UPDATE_ACTIVE_BATTLEFIELD",
	"CHAT_MSG_ADDON",
	"RAID_TARGET_UPDATE",
	"LEARNED_SPELL_IN_SKILL_LINE", "TRAIT_CONFIG_UPDATED",
	"UPDATE_SHAPESHIFT_FORM",
	"PLAYER_LOGOUT",
	"RUNE_POWER_UPDATE",
	"UNIT_SPELLCAST_SENT",
	"UNIT_NAME_UPDATE",
	"PARTY_MEMBER_ENABLE", "PARTY_MEMBER_DISABLE",
	"UPDATE_BINDINGS",
	"PLAYER_TARGET_CHANGED", "PLAYER_FOCUS_CHANGED",
	"PLAYER_EQUIPMENT_CHANGED",
	"READY_CHECK", "READY_CHECK_CONFIRM", "READY_CHECK_FINISHED",
	"ROLE_CHANGED_INFORM",
	"CVAR_UPDATE",
	"INSPECT_READY",
	"MODIFIER_STATE_CHANGED",
	"LFG_PROPOSAL_SHOW", "LFG_PROPOSAL_FAILED", "LFG_PROPOSAL_SUCCEEDED",
	--"UPDATE_MACROS",
	"PET_BATTLE_CLOSE", "PET_BATTLE_OPENING_START",
	"PLAYER_REGEN_ENABLED", "PLAYER_REGEN_DISABLED",
	"ENCOUNTER_END", "ZONE_CHANGED_NEW_AREA",
	"ZONE_CHANGED", "ZONE_CHANGED_INDOORS",
	"PLAYER_SPECIALIZATION_CHANGED", "ACTIVE_TALENT_GROUP_CHANGED",
	"UNIT_SPELLCAST_START", "UNIT_SPELLCAST_DELAYED", "UNIT_SPELLCAST_CHANNEL_START", "UNIT_SPELLCAST_CHANNEL_UPDATE",
	"UNIT_SPELLCAST_STOP", "UNIT_SPELLCAST_INTERRUPTED", "UNIT_SPELLCAST_FAILED", "UNIT_SPELLCAST_FAILED_QUIET", "UNIT_SPELLCAST_CHANNEL_STOP",
	"UNIT_SPELLCAST_SUCCEEDED", "UNIT_SPELLCAST_EMPOWER_STOP",
	"NAME_PLATE_UNIT_REMOVED",
	"UI_SCALE_CHANGED", "DISPLAY_SIZE_CHANGED",
	"CINEMATIC_STOP", "STOP_MOVIE",
};



--
do
	--
	local tTocVersion;
	function VUHDO_OnLoad(anInstance)

		_, _, _, tTocVersion = GetBuildInfo();

		if tonumber(tTocVersion or 999999) < VUHDO_MIN_TOC_VERSION then
			VUHDO_Msg(format(VUHDO_I18N_DISABLE_BY_MIN_VERSION, VUHDO_VERSION, VUHDO_MIN_TOC_VERSION));

			return;
		elseif tonumber(tTocVersion or 0) > VUHDO_MAX_TOC_VERSION then
			VUHDO_Msg(format(VUHDO_I18N_DISABLE_BY_MAX_VERSION, VUHDO_VERSION, VUHDO_MAX_TOC_VERSION));

			return;
		end

		VUHDO_INSTANCE = anInstance;

		for _, tEvent in pairs(VUHDO_ALL_EVENT_NAMES) do
			anInstance:RegisterEvent(tEvent);
		end

		VUHDO_ALL_EVENT_NAMES = nil;

		SLASH_VUHDO1 = "/vuhdo";
		SLASH_VUHDO2 = "/vd";

		SlashCmdList["VUHDO"] = function(aMessage)
			VUHDO_slashCmd(aMessage);
		end

		SLASH_RELOADUI1 = "/rl";

		SlashCmdList["RELOADUI"] = ReloadUI;

		anInstance:SetScript("OnEvent", VUHDO_OnEvent);
		anInstance:SetScript("OnUpdate", VUHDO_OnUpdate);

		VUHDO_refreshPixelScale();

		VUHDO_printAbout();

		return;

	end
end



--
local tCvar;
local tCvarValue;
local tCvarList;
function VUHDO_setForcedAddonRestrictions(anIsEnabled)

	if anIsEnabled then
		tCvarList = sAddonRestrictionEnableCvars;
	else
		tCvarList = sAddonRestrictionCvars;
	end

	for tCnt = 1, #tCvarList do
		tCvar = tCvarList[tCnt];

		SetCVar(tCvar, anIsEnabled and "1" or "0");
	end

	if anIsEnabled then
		VUHDO_Msg("Zorunlu eklenti kısıtlamaları AÇIK - arayüz yeniden yükleniyor.");
	else
		VUHDO_Msg("Zorunlu eklenti kısıtlamaları KAPALI - arayüz yeniden yükleniyor.");
	end

	ReloadUI();

	return;

end



--
function VUHDO_printForcedAddonRestrictionStatus()

	for tCnt = 1, #sAddonRestrictionCvars do
		tCvar = sAddonRestrictionCvars[tCnt];
		tCvarValue = GetCVar(tCvar) or "0";

		VUHDO_Msg(tCvar .. " = " .. tCvarValue);
	end

	VUHDO_Msg("ShouldAurasBeSecret: " .. (ShouldAurasBeSecret() and "yes" or "no"));
	VUHDO_Msg("AddOnRestriction Combat: " .. (IsAddOnRestrictionActive(Enum.AddOnRestrictionType["Combat"]) and "active" or "inactive"));
	VUHDO_Msg("AddOnRestriction Encounter: " .. (IsAddOnRestrictionActive(Enum.AddOnRestrictionType["Encounter"]) and "active" or "inactive"));
	VUHDO_Msg("AddOnRestriction ChallengeMode: " .. (IsAddOnRestrictionActive(Enum.AddOnRestrictionType["ChallengeMode"]) and "active" or "inactive"));

	return;

end



--
function VUHDO_setDeferredRedrawEnabled(anIsEnabled, anIsQuiet)

	VUHDO_CONFIG["USE_DEFERRED_REDRAW"] = anIsEnabled and true or false;

	if VUHDO_CONFIG["USE_DEFERRED_REDRAW"] then
		VUHDO_redrawPanel = _G["VUHDO_deferRedrawPanel"];
		VUHDO_redrawAllPanels = _G["VUHDO_deferRedrawAllPanels"];
	else
		VUHDO_redrawPanel = _G["VUHDO_redrawPanel"];
		VUHDO_redrawAllPanels = _G["VUHDO_redrawAllPanels"];
	end

	if not anIsQuiet then
		if anIsEnabled then
			VUHDO_Msg("Deferred panel redraw is enabled.");
		else
			VUHDO_Msg("Deferred panel redraw is disabled.");
		end
	end

	return;

end



--
function VUHDO_printDeferredRedrawStatus()

	if VUHDO_CONFIG["USE_DEFERRED_REDRAW"] then
		VUHDO_Msg("Deferred panel redraw is currently |cff00ff00ENABLED|r.");
	else
		VUHDO_Msg("Deferred panel redraw is currently |cffff0000DISABLED|r.");
	end

	return;

end



do
	--
	local tWaitingCount;
	local tActiveCount;
	function VUHDO_printDeferredReloadState()

		VUHDO_Msg("|cffFFD100--- Deferred Reload State ---|r");

		VUHDO_Msg("|cffFFA500** Status:|r");
		VUHDO_Msg("  |cffB0E0E6Reloading:|r " .. (VUHDO_IS_RELOADING and "|cff00ff00yes|r" or "|cffff0000no|r"));
		VUHDO_Msg(format("  |cffB0E0E6Reload Raid Timer:|r %.2f", VUHDO_TIMERS["RELOAD_RAID"] or 0));
		VUHDO_Msg("  |cffB0E0E6Deferred Refresh Active:|r " .. (VUHDO_isDeferredRefreshActive() and "|cff00ff00yes|r" or "|cffff0000no|r"));
		VUHDO_Msg("  |cffB0E0E6Deferred Redraw Active:|r " .. (VUHDO_isDeferredRedrawActive() and "|cff00ff00yes|r" or "|cffff0000no|r"));

		VUHDO_Msg("|cffFFA500** Active Semaphores:|r");

		tActiveCount = 0;

		for tSemaphoreName, tSemaphore in pairs(VUHDO_getSemaphores()) do
			tWaitingCount = #tSemaphore["waitingTasks"];

			if tSemaphore["count"] > 0 or tWaitingCount > 0 then
				tActiveCount = tActiveCount + 1;

				VUHDO_Msg(format("  |cffB0E0E6%s:|r |cffB0E0E6Cur=|r%d |cffB0E0E6Wait=|r%d |cffB0E0E6Timeout=|r%dms",
					tSemaphoreName, tSemaphore["count"], tWaitingCount, tSemaphore["timeoutMs"] or 0));
			end
		end

		if tActiveCount == 0 then
			VUHDO_Msg("  None");
		end

		VUHDO_Msg("|cffFFD100--- End of Deferred Reload State ---|r");

		return;

	end
end



--
function VUHDO_setAnimationGroupEnabled(anIsEnabled, anIsQuiet)

	VUHDO_CONFIG["USE_ANIMATION_GROUPS"] = anIsEnabled and true or false;

	if not anIsQuiet then
		if anIsEnabled then
			VUHDO_Msg("Debuff icon AnimationGroup API is now |cff00ff00ENABLED|r.");
			VUHDO_Msg("  |cffB0E0E6Note:|r Type '/reload' for a clean transition.");
		else
			VUHDO_Msg("Debuff icon AnimationGroup API is now |cffff0000DISABLED|r (using OnUpdate).");
			VUHDO_Msg("  |cffB0E0E6Note:|r Type '/reload' for a clean transition.");
		end
	end

	return;

end



--
function VUHDO_printAnimationMethodStatus()

	if VUHDO_CONFIG["USE_ANIMATION_GROUPS"] then
		VUHDO_Msg("Debuff icon animation method: |cff00ff00AnimationGroup API|r");
	else
		VUHDO_Msg("Debuff icon animation method: |cffff0000OnUpdate Script|r");
	end

	return;

end



--
local tSegmentName;
local tDuration;
function VUHDO_updateOnUpdateSubSegmentMetrics(aSegmentName, aDuration)

	if not VUHDO_HANDLER_PROFILING_ENABLED then
		return;
	end

	VUHDO_HANDLER_PROFILING_BATCH_COUNT = VUHDO_HANDLER_PROFILING_BATCH_COUNT + 1;

	tSegmentName = aSegmentName;
	tDuration = aDuration;

	VUHDO_HANDLER_PROFILING_PENDING_UPDATES[VUHDO_HANDLER_PROFILING_BATCH_COUNT] = {
		["segment"] = tSegmentName,
		["duration"] = tDuration
	};

	if VUHDO_HANDLER_PROFILING_BATCH_COUNT >= VUHDO_HANDLER_PROFILING_BATCH_SIZE then
		VUHDO_processProfilingBatch();
	end

	return;

end



--
local tUpdate;
local tSegmentName;
local tDuration;
local tTracker;
function VUHDO_processProfilingBatch()

	if VUHDO_HANDLER_PROFILING_BATCH_COUNT == 0 then
		return;
	end

	for tIndex = 1, VUHDO_HANDLER_PROFILING_BATCH_COUNT do
		tUpdate = VUHDO_HANDLER_PROFILING_PENDING_UPDATES[tIndex];
		tSegmentName = tUpdate["segment"];
		tDuration = tUpdate["duration"];

		if not VUHDO_HANDLER_PROFILING_METRICS[tSegmentName] then
			VUHDO_HANDLER_PROFILING_METRICS[tSegmentName] = VUHDO_createTailMeanTracker();
		end

		tTracker = VUHDO_HANDLER_PROFILING_METRICS[tSegmentName];
		tTracker:update(tDuration);
	end

	VUHDO_HANDLER_PROFILING_BATCH_COUNT = 0;

	return;

end



--
function VUHDO_flushProfilingBatch()

	VUHDO_processProfilingBatch();

	return;

end



do
	--
	local tResult;
	local tTailMeans;
	local tTotal;
	local tCount;
	function VUHDO_getHandlerProfilingMetrics()

		VUHDO_flushProfilingBatch();

		tResult = { };

		for tSegmentName, tTracker in pairs(VUHDO_HANDLER_PROFILING_METRICS) do
			tTailMeans = tTracker:getTailMeans();

			tTotal = tTracker:getCumulativeTotal();
			tCount = tTracker["totalCount"];

			tResult[tSegmentName] = {
				["Total"] = tTotal,
				["Count"] = tCount
			};

			for _, tTailMeanKey in ipairs(VUHDO_TAIL_MEAN_KEYS) do
				tResult[tSegmentName][tTailMeanKey] = tTailMeans[tTailMeanKey] or 0;
			end
		end

		return tResult;

	end
end



--
local tSortedKeys;
function VUHDO_sortSegmentKeys(aSegments)

	tSortedKeys = { };

	for tKey in pairs(aSegments) do
		tinsert(tSortedKeys, tKey);
	end

	table.sort(tSortedKeys);

	return tSortedKeys;

end



do
	--
	local tTestTracker;
	local tExpectedTotal;
	local tBufferTotal;
	local tCumulativeTotal;
	local tBufferCount;
	local tCumulativeCount;
	local tValue;
	local tDataLossPercent;
	local tAccuracyPercent;
	local tTailMeans;
	function VUHDO_testProfilingSystem()

		VUHDO_Msg("=== Testing Profiling System ===");

		tTestTracker = VUHDO_createTailMeanTracker();
		tExpectedTotal = 0;

		VUHDO_Msg("Adding 2000 test measurements...");

		for tCnt = 1, 2000 do
			tValue = 0.1 * tCnt;
			tExpectedTotal = tExpectedTotal + tValue;
			tTestTracker:update(tValue);
		end

		tBufferTotal = 0;

		for tCnt = 1, tTestTracker["bufferSize"] do
			tBufferTotal = tBufferTotal + tTestTracker["buffer"][tCnt];
		end

		tCumulativeTotal = tTestTracker:getCumulativeTotal();
		tBufferCount = tTestTracker["bufferSize"];
		tCumulativeCount = tTestTracker["totalCount"];

		VUHDO_Msg("Expected Total: " .. string.format("%.2f", tExpectedTotal) .. " ms");
		VUHDO_Msg("Buffer Total: " .. string.format("%.2f", tBufferTotal) .. " ms");
		VUHDO_Msg("Cumulative Total: " .. string.format("%.2f", tCumulativeTotal) .. " ms");
		VUHDO_Msg("Buffer Count: " .. tBufferCount);
		VUHDO_Msg("Cumulative Count: " .. tCumulativeCount);

		if tBufferCount > 0 then
			tDataLossPercent = ((tExpectedTotal - tBufferTotal) / tExpectedTotal) * 100;
			tAccuracyPercent = (tCumulativeTotal / tExpectedTotal) * 100;
			VUHDO_Msg("Buffer Data Loss: " .. string.format("%.2f", tDataLossPercent) .. "%");
			VUHDO_Msg("Cumulative Accuracy: " .. string.format("%.2f", tAccuracyPercent) .. "%");
		end

		tTailMeans = tTestTracker:getTailMeans();

		VUHDO_Msg("tm50: " .. string.format("%.2f", tTailMeans["tm50"]) .. " ms, tm80: " .. string.format("%.2f", tTailMeans["tm80"]) .. " ms, tm90: " .. string.format("%.2f", tTailMeans["tm90"]) .. " ms, tm99: " .. string.format("%.2f", tTailMeans["tm99"]) .. " ms, tm100: " .. string.format("%.2f", tTailMeans["tm100"]) .. " ms");

		VUHDO_Msg("=== Test Complete ===");

		return;

	end
end



--
local sProfilingFrame;
local sProfilingScrollFrame;
local sProfilingScrollChildFrame;
local sProfilingEditBox;
local sProfilingCopyButton;



--
local tTitle;
local tProfilingCloseButton;
local tLeft;
local tRight;
local tMiddle;
function VUHDO_ensureProfilingFrames()

	if sProfilingFrame then
		return;
	end

	sProfilingFrame = CreateFrame("Frame", "VuhDoProfilingFrame", UIParent, "BackdropTemplate");

	sProfilingFrame:SetSize(800, 600);
	sProfilingFrame:SetPoint("CENTER");

	sProfilingFrame:SetBackdrop( {
		["bgFile"] = "Interface\\Buttons\\WHITE8x8",
		["edgeFile"] = "Interface\\Tooltips\\UI-Tooltip-Border",
		["tile"] = true,
		["tileSize"] = 8,
		["edgeSize"] = 16,
		["insets"] = {
			["left"] = 4,
			["right"] = 4,
			["top"] = 4,
			["bottom"] = 4,
		},
	} );
	sProfilingFrame:SetBackdropColor(0.1, 0.1, 0.1, 0.9);
	sProfilingFrame:SetBackdropBorderColor(0.6, 0.6, 0.6, 0.8);

	sProfilingFrame:SetMovable(true);
	sProfilingFrame:EnableMouse(true);

	sProfilingFrame:RegisterForDrag("LeftButton");
	sProfilingFrame:SetScript("OnDragStart", sProfilingFrame.StartMoving);
	sProfilingFrame:SetScript("OnDragStop", sProfilingFrame.StopMovingOrSizing);

	tTitle = sProfilingFrame:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge");

	tTitle:SetPoint("TOP", 0, -8);
	tTitle:SetText("VuhDo Profiling Metrics");

	sProfilingScrollFrame = CreateFrame("ScrollFrame", "VuhDoProfilingFrameScrollFrame", sProfilingFrame, "UIPanelScrollFrameTemplate");

	sProfilingScrollFrame:SetPoint("TOPLEFT", 12, -40);
	sProfilingScrollFrame:SetPoint("BOTTOMRIGHT", -32, 50);

	sProfilingScrollChildFrame = CreateFrame("Frame", nil, sProfilingScrollFrame);

	sProfilingScrollChildFrame:SetPoint("TOPLEFT");
	sProfilingScrollChildFrame:SetPoint("TOPRIGHT");
	sProfilingScrollChildFrame:SetSize(756, 400);

	sProfilingEditBox = CreateFrame("EditBox", nil, sProfilingScrollChildFrame, "InputBoxTemplate");

	sProfilingEditBox:SetPoint("TOPLEFT");
	sProfilingEditBox:SetPoint("TOPRIGHT");
	sProfilingEditBox:SetMultiLine(true);
	sProfilingEditBox:SetAutoFocus(false);
	sProfilingEditBox:SetFontObject("GameFontHighlight");

	tLeft = sProfilingEditBox["Left"];
	tRight = sProfilingEditBox["Right"];
	tMiddle = sProfilingEditBox["Middle"];

	if tLeft then
		tLeft:SetVertexColor(1, 1, 1, 0);
	end

	if tRight then
		tRight:SetVertexColor(1, 1, 1, 0);
	end

	if tMiddle then
		tMiddle:SetVertexColor(1, 1, 1, 0);
	end

	sProfilingEditBox:SetScript("OnEscapePressed", function()
		if not InCombatLockdown() then
			sProfilingFrame:Hide();
		end
	end);

	sProfilingScrollFrame:SetScrollChild(sProfilingScrollChildFrame);

	sProfilingCopyButton = CreateFrame("Button", nil, sProfilingFrame, "GameMenuButtonTemplate");

	sProfilingCopyButton:SetSize(100, 25);
	sProfilingCopyButton:SetPoint("BOTTOMLEFT", 12, 12);
	sProfilingCopyButton:SetText("Tümünü Seç");

	sProfilingCopyButton:SetScript("OnClick", function()
		if sProfilingCopyButton:GetText() == "Tümünü Seç" then
			sProfilingEditBox:SetFocus();
			sProfilingEditBox:HighlightText();
			sProfilingCopyButton:SetText("Seçimi Kaldır");
		else
			sProfilingEditBox:HighlightText(0, 0);
			sProfilingCopyButton:SetText("Tümünü Seç");
		end
	end);

	tProfilingCloseButton = CreateFrame("Button", nil, sProfilingFrame, "GameMenuButtonTemplate");

	tProfilingCloseButton:SetSize(100, 25);
	tProfilingCloseButton:SetPoint("BOTTOMRIGHT", -12, 12);
	tProfilingCloseButton:SetText("Kapat");

	tProfilingCloseButton:SetScript("OnClick", function()
		if not InCombatLockdown() then
			sProfilingFrame:Hide();
		end
	end);

	return;

end



--
function VUHDO_showProfilingFrame()

	if InCombatLockdown() then
		VUHDO_Msg("Savaş sırasında profil penceresi gösterilemez.");

		return;
	end

	VUHDO_ensureProfilingFrames();

	sProfilingFrame:Show();

	return;

end



--
local tCapturedOutput;
local tOriginalMsg;
local tOutputText;
function VUHDO_captureProfilingOutput(aCallback)

	if InCombatLockdown() then
		VUHDO_Msg("Savaş sırasında profil çıktısı alınamaz.");

		return;
	end

	VUHDO_ensureProfilingFrames();

	tCapturedOutput = { };
	tOriginalMsg = VUHDO_Msg;

	VUHDO_Msg = function(aMessage, aRed, aGreen, aBlue)
		tinsert(tCapturedOutput, aMessage);

		return;
	end

	aCallback();

	VUHDO_Msg = tOriginalMsg;

	tOutputText = "";

	for _, tLine in ipairs(tCapturedOutput) do
		tOutputText = tOutputText .. tLine .. "\n";
	end

	sProfilingEditBox:SetText(tOutputText);
	sProfilingCopyButton:SetText("Tümünü Seç");
	sProfilingEditBox:HighlightText(0, 0);

	sProfilingScrollFrame:SetVerticalScroll(0);

	return;

end



--
function VUHDO_showProfilingMetrics()

	VUHDO_showProfilingFrame();

	VUHDO_captureProfilingOutput(function()
		VUHDO_printHandlerMetrics();
		VUHDO_printDeferredTaskMetrics(false);
		VUHDO_printPoolMetrics();
		VUHDO_printSemaphoreMetrics();
		VUHDO_printAuraContainerMetrics();
	end);

	return;

end