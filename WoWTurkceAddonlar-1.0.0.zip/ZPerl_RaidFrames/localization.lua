-- X-Perl UnitFrames
-- Author: Resike
-- License: GNU GPL v3, 29 June 2007 (see LICENSE.txt)

XPERL_RAID_GROUP		= "Grup %d"
XPERL_RAID_TOOLTIP_OFFLINE	= "%s süredir çevrimdışı"
XPERL_RAID_TOOLTIP_AFK		= "%s süredir AFK"
XPERL_RAID_TOOLTIP_DND		= "%s süredir DND"
XPERL_RAID_TOOLTIP_DYING	= "%s içinde ölüyor"
XPERL_RAID_TOOLTIP_REBIRTH	= "Rebirth hazır olacak: %s"
XPERL_RAID_TOOLTIP_ANKH		= "Ankh hazır olacak: %s"
XPERL_RAID_TOOLTIP_SOULSTONE	= "Soulstone hazır olacak: %s"

XPERL_RAID_TOOLTIP_REMAINING	= " kaldı"

XPERL_RAID_DROPDOWN_SHOWPET	= "Evcil Hayvanları Göster"
XPERL_RAID_DROPDOWN_SHOWOWNER	= "Sahipleri Göster"

XPERL_RAID_DROPDOWN_MAINTANKS	= "Ana Tanklar"
XPERL_RAID_DROPDOWN_SETMT	= "MT #%d olarak ayarla"
XPERL_RAID_DROPDOWN_REMOVEMT	= "MT #%d kaldır"

XPERL_RAID_RESSING		= " diriltiyor"
XPERL_RAID_AFK			= "AFK"
XPERL_RAID_DND			= "DND"
XPERL_RAID_AUTOPROMOTE		= "Otomatik Yetki Ver"
XPERL_RAID_RESSER_AVAIL		= "Diriltebilecekler: "
