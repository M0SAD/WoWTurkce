-- Oyundan yakalanan görev metinleri ("çevir" ile eklenir). Metin parmak iziyle eşleşir.
local G = WoWTurkce
local gorev = G.yeniGorev
if not gorev then return end

-- Karanlıkta Bir Işık (98389)
gorev(nil, nil, {
	{ "Greetings, priest. Yes, I am a paladin. Not even death can stop the Light.\r\n\r\nThis is something my kind have in common with all Forsaken--we have overcome what the living view as their end. However, some even among our own fear us; they suspect we will smite them as some monstrosity.\r\n\r\nIn truth, our relationship with undeath is complex, but I am not here to hurt our own. Help me show the others this. Venture to Night's Web Hollow to the northwest and free the freshly raised fools trapped by the spiders there.",
	  "Selamlar, rahip. Evet, ben bir paladinim. Ölüm bile Işık'ı durduramaz.\r\n\r\nBu, bizim türümüzün tüm Forsaken'larla ortak noktası--yaşayanların son saydığı şeyin üstesinden geldik. Yine de kendi aramızdan bazıları bile bizden korkuyor; onları bir canavarmışız gibi cezalandıracağımızdan şüpheleniyorlar.\r\n\r\nAslında ölümsüzlükle ilişkimiz karmaşık, ama ben kendi halkımıza zarar vermeye gelmedim. Bunu diğerlerine göstermeme yardım et. Kuzeybatıdaki Night's Web Hollow'a git ve oradaki örümceklerin tuzağına düşmüş, yeni diriltilmiş aptalları kurtar." },
})

-- Karanlıkta Bir Işık (98389) teslim metni
gorev(nil, nil, {
	{ "May this help Executor Arren and so many others see our true nature. Much like in our past lives, we live to serve our people--to protect them with the gifts the Light provides us.\r\n\r\nThey will see in time that we are just as valuable to the Dark Lady's plans as any other.\r\n\r\nLight be with you.",
	  "Bu, Executor Arren'ın ve daha nice kişinin gerçek doğamızı görmesine yardımcı olsun. Geçmiş hayatlarımızda olduğu gibi, halkımıza hizmet etmek için yaşıyoruz--onları Işık'ın bize bahşettiği armağanlarla korumak için.\r\n\r\nZamanla bizim de Kara Leydi'nin planları için diğerleri kadar değerli olduğumuzu görecekler.\r\n\r\nIşık seninle olsun." },
})

-- Gelen: ek görev metinleri
gorev(nil, nil, {
	{ "I can train you if you have the aptitude.",
	  "Yeteneğin varsa seni eğitebilirim." },
	{ "I appreciate your efforts, Someburger.  May Sylvanas recognize your bravery one day. . . .",
	  "Çabalarını takdir ediyorum, Someburger. Umarım Sylvanas bir gün cesaretini tanır. . . ." },
	{ "What beautiful things did you bring me?",
	  "Bana ne güzel şeyler getirdin?" },
})

-- Gelen: 3. batch görev metinleri
gorev(nil, nil, {
	{ "My associate Eleanor Shackleton prides herself on traveling the wilds, surviving against weather and monsters. She is currently camped not far from here, in the hills to the west, and I remember a piece of advice that she once gave me: \"When you think you have enough firewood, gather five times more.\"\r\n\r\nIf you have some spare time, you could collect some wood in this basket and take it to her camp. I'm sure she could give you a few tips about the existence of a traveling adventurer.",
	  "Yol arkadaşım Eleanor Shackleton, vahşi doğada seyahat etmekle, hava koşullarına ve canavarlara karşı hayatta kalmakla övünür. Şu anda buradan çok uzak olmayan, batıdaki tepelerde kamp kurmuş durumda. Bir keresinde bana verdiği bir öğüdü hatırlıyorum: \"Yeterince odunun olduğunu düşündüğünde, beş katını topla.\"\r\n\r\nBoş vaktin varsa bu sepete biraz odun toplayıp onun kampına götürebilirsin. Gezgin bir maceracının yaşamı hakkında sana birkaç ipucu verebileceğinden eminim." },
})

-- Gelen: Deathguard görevi (99134)
gorev(nil, nil, {
	{ "You are not a member of the Deathguard, and therefore have yet to disappoint me.\r\n\r\nAs a reward for your relative lack of incompetence, you shall punish those that have demonstrated such talents in excess.\r\n\r\nSwiftly now--$n, is it?--or I shall add your name to my ledger for someone else's reward.",
	  "Ölüm Muhafızı değilsin, dolayısıyla beni henüz hayal kırıklığına uğratmadın.\r\n\r\nBecerisizlikten görece uzak durmanın ödülü olarak, bu yeteneği haddinden fazla sergileyenleri cezalandıracaksın.\r\n\r\nÇabuk ol şimdi--adın $n, öyle mi?--yoksa adını defterime yazarım, ödül bir başkasına gider." },
})

-- Gelen: Executor görevi (99141)
gorev(nil, nil, {
	{ "Make no mistake, priest--the Dark Lady demands the perfect execution of her will. As an Executor, it is my duty to see that this happens.\r\n\r\nReports from several of my Deathguards are overdue. Needless to say, my patience has run out. Obtain their reports and bring them to me in the Dark Lady's name.\r\n\r\nYou will find Deathguard Dillinger just west of here, by the graveyard. Deathguard Kristof is stationed at the waystation to the east. And check on the abomination Gordo; he wanders west near Stillwater Pond.",
	  "Yanlış anlama, rahip--Kara Leydi iradesinin kusursuz biçimde yerine getirilmesini ister. Bir İnfazcı olarak bunun gerçekleşmesini sağlamak benim görevim.\r\n\r\nBirkaç Ölüm Muhafızımdan gelmesi gereken raporlar gecikti. Söylemeye gerek yok, sabrım tükendi. Raporlarını al ve Kara Leydi adına bana getir.\r\n\r\nDeathguard Dillinger'ı buranın hemen batısında, mezarlığın yanında bulacaksın. Deathguard Kristof doğudaki konaklama noktasında görevli. Ayrıca iğrenç yaratık Gordo'yu da kontrol et; batıda, Stillwater Pond yakınlarında dolaşıyor." },
})

-- Gelen: 99134 ilerleme
gorev(nil, nil, {
	{ "This had better be good.",
	  "Bu işe yarar bir şey olsa iyi olur." },
})

-- Gelen: 99141 ilerleme
gorev(nil, nil, {
	{ "You'd best have those reports in hand, or get out of my face.",
	  "O raporları elinde getirsen iyi olur, yoksa karşımdan defol." },
})
