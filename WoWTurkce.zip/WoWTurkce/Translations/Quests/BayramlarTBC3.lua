-- TBC bayram görevleri 3
-- b=başlık, a=açıklama, h=hedef, i=ilerleme, t=tamamlama
-- k = çevrilen İngilizce metnin parmak izi (metin değişirse çeviri gösterilmez, yeniden kaydedilir)
local V = WoWTurkce.Veri

V[11856] = { b="Ateşi Onurlandır", t="Stonetalon Mountains ateşini onurlandır.", k={b=427467665, t=2596104086} }
V[11857] = { b="Ateşi Onurlandır", t="Swamp of Sorrows ateşini onurlandır.", k={b=427467665, t=1901732717} }
V[11858] = { b="Ateşi Onurlandır", t="Terokkar Forest ateşini onurlandır.", k={b=427467665, t=969648935} }
V[11859] = { b="Ateşi Onurlandır", t="Barrens ateşini onurlandır.", k={b=427467665, t=1537307134} }
V[11860] = { b="Ateşi Onurlandır", t="Hinterlands ateşini onurlandır.", k={b=427467665, t=3902322477} }
V[11861] = { b="Ateşi Onurlandır", t="Thousand Needles ateşini onurlandır.", k={b=427467665, t=2802085655} }
V[11862] = { b="Ateşi Onurlandır", t="Tirisfal Glades ateşini onurlandır.", k={b=427467665, t=232693439} }
V[11863] = { b="Ateşi Onurlandır", t="Zangarmarsh ateşini onurlandır.", k={b=427467665, t=4237014767} }
V[11972] = { b="Ahune'nin Kırıkları", a="Bu kırıklar uğursuz bir şekilde titreşiyor. Ayaz Lordu'nun son özünü mü barındırıyorlar?", h="Buz Kırıkları'nı Luma Skymother'a götür.", k={b=1142126000, a=2343036329, h=1781600934} }
V[11976] = { b="Buz Kırıkları", a="Bu kırıklar uğursuz bir şekilde titreşiyor. Ayaz Lordu'nun son özünü mü barındırıyorlar?", h="Buz Kırıkları'nı Luma Skymother'a götür.", k={b=2301134587, a=2343036329, h=1781600934} }
V[12286] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12331] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12332] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12333] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12334] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12335] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12336] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12337] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12338] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12339] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12340] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12341] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12342] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12343] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12344] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12345] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12346] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12347] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12348] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12349] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12350] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12351] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12352] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12353] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12354] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12355] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12356] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12357] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12358] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12359] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12360] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12361] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12362] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12363] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12364] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12365] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12366] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12367] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12368] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12369] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12370] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12371] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12373] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12374] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12375] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12376] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12377] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12378] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12379] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12380] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12381] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12382] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12383] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12384] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
V[12385] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarların dört bir yanındaki hanlarda bulunur. Hadi... biraz al!", k={b=2899454418, t=555881347} }
