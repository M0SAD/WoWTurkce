local mod	= DBM:NewMod("ManaWraith", "DBM-Party-Forever", 4)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20261019224209")
mod:EnableGenericTrash()
--mod:SetCreatureID(11517)
mod:SetEncounterID(3312)
mod:SetZone(2959)

mod:RegisterCombat("combat")

--mod:AddAuraSoundOption(123456, true, 123456, 1, 1, "targetyou", 2, 0)
