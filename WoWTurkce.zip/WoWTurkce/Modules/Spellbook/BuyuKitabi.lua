-- Büyü kitabı: büyü adlarını, alt başlıkları (Rank 1, Passive) ve sekme adlarını Türkçe gösterir.
-- Sadece yazıyı değiştirir; büyülerin kendisine ve kısayol tuşlarına dokunmaz.
local G = WoWTurkce

local function altCevir(s)
	if not s or s == "" then return nil end
	local tr = G.BuyuAlt[s]
	if tr then return tr end
	local n = s:match("^Rank (%d+)$")
	if n then return "Rütbe " .. n end
end
G.buyuAltCevir = altCevir

local function dugmeCevir(btn)
	if not btn or not btn.GetName or not G.modul("buyuadi") then return end
	local ad = btn:GetName()
	local isim = _G[ad .. "SpellName"] or btn.SpellName
	local alt = _G[ad .. "SubSpellName"] or btn.SubSpellName or btn.SpellSubName
	if isim and isim.GetText then
		local t = isim:GetText()
		local tr = t and G.buyuAdiCevir(t)
		if tr then G.sigdirKoy(isim, tr)
		elseif t and t ~= "" and not G.turkceMi(t) then G.kaydetDiger("buyuadi", t) end
	end
	if alt and alt.GetText then
		local tr = altCevir(alt:GetText())
		if tr then alt:SetText(tr) end
	end
end

local function hepsi()
	if not G.modul("buyuadi") then return end
	for i = 1, 12 do dugmeCevir(_G["SpellButton" .. i]) end
	if SpellBookTitleText and SpellBookTitleText.GetText then
		local t = SpellBookTitleText:GetText()
		if t == "Spellbook" then SpellBookTitleText:SetText("Büyü Kitabı") end
	end
	-- "Page 2" -> "Sayfa 2"
	if SpellBookPageText and SpellBookPageText.GetText then
		local n = (SpellBookPageText:GetText() or ""):match("^Page (%d+)$")
		if n then SpellBookPageText:SetText("Sayfa " .. n) end
	end
	-- "Show all spell ranks" kutusu
	for _, ad in ipairs({ "ShowAllSpellRanksCheckboxText", "ShowAllSpellRanksCheckBoxText" }) do
		local fs = _G[ad]
		if fs and fs.GetText and fs:GetText() == "Show all spell ranks" then fs:SetText("Tüm rütbeleri göster") end
	end
	local kutu = _G.ShowAllSpellRanksCheckbox or _G.ShowAllSpellRanksCheckBox
	if kutu and kutu.Text and kutu.Text.GetText and kutu.Text:GetText() == "Show all spell ranks" then
		kutu.Text:SetText("Tüm rütbeleri göster")
	end
end
G.buyuKitabiYenile = hepsi

G.dinle(function(k)
	-- Savaşta büyü kitabını (güvenli büyü düğmeleri) addon kodundan yenileme
	if (k == "buyuadi" or k == "acik") and SpellBookFrame and SpellBookFrame:IsShown() and SpellBookFrame_Update
		and not (InCombatLockdown and InCombatLockdown()) then
		SpellBookFrame_Update()
	end
end)

G.basla(function()
	if SpellButton_UpdateButton then hooksecurefunc("SpellButton_UpdateButton", dugmeCevir) end
	if SpellBookFrame_Update then hooksecurefunc("SpellBookFrame_Update", hepsi) end
	if SpellBookFrame then SpellBookFrame:HookScript("OnShow", function() C_Timer.After(0, hepsi) end) end
	-- Sekme ipuçları (General, Holy, Shadow...)
	for i = 1, 8 do
		local sekme = _G["SpellBookSkillLineTab" .. i]
		if sekme then
			sekme:HookScript("OnEnter", function(self)
				if not G.modul("buyuadi") then return end
				local fs = GameTooltipTextLeft1
				local t = fs and fs:GetText()
				local tr = t and G.BuyuSekme[t]
				if tr then fs:SetText(tr); GameTooltip:Show() end
			end)
		end
	end
end)

-- Meslek pencereleri (TradeSkillFrame, CraftFrame): tarif adları, malzemeler, açıklama ve gereksinimler
local function tarifCevir(fs)
	if not fs or not fs.GetText or not fs:IsShown() then return end
	local t = fs:GetText()
	if type(t) ~= "string" or t == "" or G.gizli(t) or G.turkceMi(t) then return end
	local bas, ad, son = t:match("^(%s*)(.-)(%s*%[%d+%])$")
	if not ad then bas, ad, son = t:match("^(%s*)(.-)(%s*)$") end
	local tr = ad and ad ~= "" and (G.isimCevir(ad) or (G.esyaAdiGoster and G.esyaAdiGoster(ad)))
	if tr and tr ~= ad then G.sigdirKoy(fs, bas .. tr .. son) end
end
local function metinCevir(fs)
	if not fs or not fs.GetText then return end
	local t = fs:GetText()
	if type(t) ~= "string" or t == "" or G.gizli(t) or G.turkceMi(t) then return end
	local tr = G.cevir(G.Buyu, t) or G.cevir(G.Esya, t) or (G.hedefCevir and G.hedefCevir(t))
	if tr and tr ~= t then G.asilKaydet(fs, tr); fs:SetText(tr) end
end
local function meslekCevir(onek, ad, malzeme, aciklama, gerek)
	if not G.modul("buyuadi") and not G.modul("arayuz") then return end
	for i = 1, 40 do tarifCevir(_G[onek .. i]) end
	tarifCevir(_G[ad])
	for i = 1, 8 do tarifCevir(_G[malzeme .. i .. "Name"]) end
	metinCevir(_G[aciklama]); metinCevir(_G[gerek])
end
local function tsCevir() pcall(meslekCevir, "TradeSkillSkill", "TradeSkillSkillName", "TradeSkillReagent", "TradeSkillDescription", "TradeSkillRequirementText") end
local function crCevir() pcall(meslekCevir, "Craft", "CraftName", "CraftReagent", "CraftDescription", "CraftRequirements") end
local kurulan = {}
local function meslekKur()
	if not kurulan.ts and _G.TradeSkillFrame_Update then
		kurulan.ts = true
		hooksecurefunc("TradeSkillFrame_Update", tsCevir)
		if _G.TradeSkillFrame_SetSelection then hooksecurefunc("TradeSkillFrame_SetSelection", tsCevir) end
	end
	if not kurulan.cr and _G.CraftFrame_Update then
		kurulan.cr = true
		hooksecurefunc("CraftFrame_Update", crCevir)
		if _G.CraftFrame_SetSelection then hooksecurefunc("CraftFrame_SetSelection", crCevir) end
	end
end
local mk = CreateFrame("Frame")
mk:RegisterEvent("ADDON_LOADED")
mk:RegisterEvent("PLAYER_LOGIN")
mk:SetScript("OnEvent", function() meslekKur() end)
G.dinle(function(k)
	if k == "acik" or k == "buyuadi" or k == "arayuz" then
		if TradeSkillFrame and TradeSkillFrame:IsShown() and TradeSkillFrame_Update then TradeSkillFrame_Update() end
		if CraftFrame and CraftFrame:IsShown() and CraftFrame_Update then CraftFrame_Update() end
	end
end)
