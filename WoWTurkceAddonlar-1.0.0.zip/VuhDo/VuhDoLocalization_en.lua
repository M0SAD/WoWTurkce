-- @EXACT = true: Translation has to be the exact(!) match in the clients language,
--                beacause it carries technical semantics
-- @EXACT = false: Translation can be done freely, because text is only descriptive
-- Class Names
-- @EXACT = false
VUHDO_I18N_WARRIORS = "Warrior'lar";
VUHDO_I18N_ROGUES = "Rogue'lar";
VUHDO_I18N_HUNTERS = "Hunter'lar";
VUHDO_I18N_PALADINS = "Paladin'ler";
VUHDO_I18N_MAGES = "Mage'ler";
VUHDO_I18N_WARLOCKS = "Warlock'lar";
VUHDO_I18N_SHAMANS = "Shaman'lar";
VUHDO_I18N_DRUIDS = "Druid'ler";
VUHDO_I18N_PRIESTS = "Priest'ler";
VUHDO_I18N_DEATH_KNIGHT = "Death Knight'lar";
VUHDO_I18N_MONKS = "Monk'lar";
-- Group Model Names
-- @EXACT = false
VUHDO_I18N_GROUP = "Grup";
VUHDO_I18N_OWN_GROUP = "Kendi Grubum";
-- Special Model Names
-- @EXACT = false
VUHDO_I18N_PETS = "Petler";
VUHDO_I18N_MAINTANKS = "Ana Tanklar";
VUHDO_I18N_PRIVATE_TANKS = "Özel Tanklar";
-- General Labels
-- @EXACT = false
VUHDO_I18N_OKAY = "Tamam";
VUHDO_I18N_CLASS = "Sınıf";
VUHDO_I18N_PLAYER = "Oyuncu";
-- VuhDoTooltip.lua
-- @EXACT = false
VUHDO_I18N_TT_POSITION = "|cffffb233Konum:|r";
VUHDO_I18N_TT_GHOST = "<HAYALET>";
VUHDO_I18N_TT_DEAD = "<ÖLÜ>";
VUHDO_I18N_TT_AFK = "<AFK>";
VUHDO_I18N_TT_DND = "<DND>";
VUHDO_I18N_TT_LIFE = "|cffffb233Can:|r ";
VUHDO_I18N_TT_MANA = "|cffffb233Mana:|r ";
VUHDO_I18N_TT_LEVEL = "Seviye ";
-- VuhDoPanel.lua
-- @EXACT = false
VUHDO_I18N_CHOOSE = "Seç";
VUHDO_I18N_DRAG = "Sürükle";
VUHDO_I18N_REMOVE = "Kaldır";
VUHDO_I18N_ME = "ben!";
VUHDO_I18N_TYPE = "Tür";
VUHDO_I18N_VALUE = "Değer";
VUHDO_I18N_SPECIAL = "Özel";
VUHDO_I18N_BUFF_ALL = "Tümü";
VUHDO_I18N_SHOW_BUFF_WATCH = "Buff İzleyiciyi Göster";
-- Chat messages
-- @EXACT = false
VUHDO_I18N_COMMAND_LIST = "\n|cffffe566 - [ VuhDo Komutları ] -|r\n" ..
"|cffffe566opt|r[ions] - VuhDo Options\n" ..
"|cffffe566res|r[et] - Reset Panel Positions\n" ..
"|cffffe566lock|r - Toggle Panel Lock\n" ..
"|cffffe566mm, map, minimap|r - Toggle Minimap Icon\n" ..
"|cffffe566compart|r[ment] - Toggle AddOn Compartment Icon\n" ..
"|cffffe566show, hide, toggle|r - Turn Panels on/off\n" ..
"|cffffe566load|r - [Profile],[Key Layout]\n" ..
"[broad]|cffffe566cast, mt|r[s] - Broadcast maintanks\n" ..
"|cffffe566role|r - Reset player roles\n" ..
"|cffffe566ab|r[out] - About this add-on\n" ..
"|cffffe566help,?|r - This command list\n";
VUHDO_I18N_BAD_COMMAND = "Hatalı komut! Komut listesi için '/vuhdo help' ya da '/vd ?' yaz.";
VUHDO_I18N_CHAT_SHOWN = "|cffffe566gösteriliyor|r.";
VUHDO_I18N_CHAT_HIDDEN = "|cffffe566gizli|r.";
VUHDO_I18N_MM_ICON = "Minimap simgesi artık ";
VUHDO_I18N_MTS_BROADCASTED = "Ana tanklar raide duyuruldu";
VUHDO_I18N_PANELS_SHOWN = "İyileştirme panelleri artık |cffffe566gösteriliyor|r.";
VUHDO_I18N_PANELS_HIDDEN = "İyileştirme panelleri artık |cffffe566gizli|r.";
VUHDO_I18N_LOCK_PANELS_PRE = "Panel konumları artık ";
VUHDO_I18N_LOCK_PANELS_LOCKED = "|cffffe566kilitli|r.";
VUHDO_I18N_LOCK_PANELS_UNLOCKED = "|cffffe566kilitsiz|r.";
VUHDO_I18N_PANELS_RESET = "Panel konumları sıfırlandı.";
-- Config Pop-Up
-- @EXACT = false
VUHDO_I18N_ROLE = "Rol";
VUHDO_I18N_PRIVATE_TANK = "Özel Tank";
VUHDO_I18N_SET_BUFF = "Buff Ata";
-- Minimap
-- @EXACT = false
VUHDO_I18N_VUHDO_OPTIONS = "VuhDo Ayarları";
VUHDO_I18N_PANEL_SETUP = "Seçenekler";
VUHDO_I18N_MM_TOOLTIP = "Sol: Panel Ayarı\nSağ: Menü";
VUHDO_I18N_TOGGLES = "Aç/Kapat";
VUHDO_I18N_LOCK_PANELS = "Panelleri Kilitle";
VUHDO_I18N_SHOW_PANELS = "Panelleri Göster";
VUHDO_I18N_MM_BUTTON = "Minimap Düğmesi";
VUHDO_I18N_CLOSE = "Kapat";
VUHDO_I18N_BROADCAST_MTS = "Ana Tankları Duyur";
-- Buff categories
-- @EXACT = false
-- Priest
-- Shaman
VUHDO_I18N_BUFFC_FIRE_TOTEM = "Fire Totem";
VUHDO_I18N_BUFFC_AIR_TOTEM = "Air Totem";
VUHDO_I18N_BUFFC_EARTH_TOTEM = "Earth Totem";
VUHDO_I18N_BUFFC_WATER_TOTEM = "Water Totem";
VUHDO_I18N_BUFFC_WEAPON_ENCHANT = "Weapon Enchant";
VUHDO_I18N_BUFFC_WEAPON_ENCHANT_2 = "2nd Weapon Enchant";
VUHDO_I18N_BUFFC_SHIELDS = "Shields";
-- Paladin
VUHDO_I18N_BUFFC_BLESSING = "Blessing";
VUHDO_I18N_BUFFC_SEAL = "Seal";
-- Druids
-- Warlock
VUHDO_I18N_BUFFC_SKIN = "Skin";
-- Mage
VUHDO_I18N_BUFFC_ARMOR_MAGE = "Armor";
-- Death Knight
VUHDO_BUFFC_PRESENCE    = "Presence";
-- Warrior
VUHDO_I18N_BUFFC_SHOUT = "Shout";
-- Hunter
VUHDO_I18N_BUFFC_ASPECT = "Aspect";
-- Monk
VUHDO_I18N_BUFFC_STANCE = "Stance";

-- Key Binding Headers/Names
-- @EXACT = false
BINDING_HEADER_VUHDO_TITLE = "VuhDo - Raid Frames";
BINDING_NAME_VUHDO_KEY_ASSIGN_1 = "Mouse over Spell 1";
BINDING_NAME_VUHDO_KEY_ASSIGN_2 = "Mouse over Spell 2";
BINDING_NAME_VUHDO_KEY_ASSIGN_3 = "Mouse over Spell 3";
BINDING_NAME_VUHDO_KEY_ASSIGN_4 = "Mouse over Spell 4";
BINDING_NAME_VUHDO_KEY_ASSIGN_5 = "Mouse over Spell 5";
BINDING_NAME_VUHDO_KEY_ASSIGN_6 = "Mouse over Spell 6";
BINDING_NAME_VUHDO_KEY_ASSIGN_7 = "Mouse over Spell 7";
BINDING_NAME_VUHDO_KEY_ASSIGN_8 = "Mouse over Spell 8";
BINDING_NAME_VUHDO_KEY_ASSIGN_9 = "Mouse over Spell 9";
BINDING_NAME_VUHDO_KEY_ASSIGN_10 = "Mouse over Spell 10";
BINDING_NAME_VUHDO_KEY_ASSIGN_11 = "Mouse over Spell 11";
BINDING_NAME_VUHDO_KEY_ASSIGN_12 = "Mouse over Spell 12";
BINDING_NAME_VUHDO_KEY_ASSIGN_13 = "Mouse over Spell 13";
BINDING_NAME_VUHDO_KEY_ASSIGN_14 = "Mouse over Spell 14";
BINDING_NAME_VUHDO_KEY_ASSIGN_15 = "Mouse over Spell 15";
BINDING_NAME_VUHDO_KEY_ASSIGN_16 = "Mouse over Spell 16";
BINDING_NAME_VUHDO_KEY_ASSIGN_SMART_BUFF = "Smart Buff";
VUHDO_I18N_MOUSE_OVER_BINDING = "Klavye büyüsü";
VUHDO_I18N_UNASSIGNED = "(atanmamış)";
-- #+V1.89
VUHDO_I18N_NO = "Hayır";
VUHDO_I18N_UP = "Up";
VUHDO_I18N_VEHICLES = "Araçlar";
-- #+v1.94
VUHDO_I18N_DEFAULT_RES_ANNOUNCE = "Canlan VuhDo, seni çaylak!";
-- #v+1.151
VUHDO_I18N_MAIN_ASSISTS = "Ana Yardımcılar";
VUHDO_OPTIONS_FONT_NAME = "Interface\\AddOns\\VuhDo\\Fonts\\ariblk.ttf";
-- #v+1.169
-- #+v1.184
VUHDO_I18N_BW_CD = "CD";
VUHDO_I18N_BW_GO = "GO!";
VUHDO_I18N_BW_LOW = "AZ";
VUHDO_I18N_BW_N_A = "|cffff0000Yok|r";
VUHDO_I18N_BW_RNG_RED = "|cffff0000MZL|r";
VUHDO_I18N_BW_OK = "OK";
VUHDO_I18N_BW_RNG_YELLOW = "|cffffff00MZL|r";
VUHDO_I18N_PROMOTE_RAID_LEADER = "Raid Lideri Yap";
VUHDO_I18N_PROMOTE_ASSISTANT = "Yardımcı Yap";
VUHDO_I18N_DEMOTE_ASSISTANT = "Yardımcılıktan Düşür";
VUHDO_I18N_PROMOTE_MASTER_LOOTER = "Ganimet Sorumlusu Yap";
VUHDO_I18N_MT_NUMBER = "AT #";
VUHDO_I18N_ROLE_OVERRIDE = "Rolü Değiştir";
VUHDO_I18N_MELEE_TANK = "Yakın Dövüş Tank";
VUHDO_I18N_MELEE_DPS = "Yakın Dövüş DPS";
VUHDO_I18N_RANGED_DPS = "Menzilli DPS";
VUHDO_I18N_RANGED_HEALERS = "Menzilli Şifacı";
VUHDO_I18N_AUTO_DETECT = "<otomatik algıla>";
VUHDO_I18N_PROMOTE_ASSIST_MSG_1 = "Yükseltildi: |cffffe566";
VUHDO_I18N_PROMOTE_ASSIST_MSG_2 = "|r yardımcı yapıldı.";
VUHDO_I18N_DEMOTE_ASSIST_MSG_1 = "Düşürüldü: |cffffe566";
VUHDO_I18N_DEMOTE_ASSIST_MSG_2 = "|r yardımcılıktan alındı.";
VUHDO_I18N_RESET_ROLES = "Rolleri Sıfırla";
VUHDO_I18N_LOAD_KEY_SETUP = "Tuş Ayarını Yükle";
VUHDO_I18N_BUFF_ASSIGN_1 = "Buff |cffffe566";
VUHDO_I18N_BUFF_ASSIGN_2 = "|r şuna atandı: |cffffe566";
VUHDO_I18N_BUFF_ASSIGN_3 = "|r";
VUHDO_I18N_MACRO_KEY_ERR_1 = "HATA: Klavye fare-üstü makrosu bu büyü için sınırı aşıyor: ";
VUHDO_I18N_MACRO_KEY_ERR_2 = "/256 karakter). Otomatik ateşleme seçeneklerini azaltmayı dene!!!";
VUHDO_I18N_MACRO_NUM_ERR = "Karakter başına makro sınırı aşıldı! Fare-üstü makrosu oluşturulamıyor: ";
VUHDO_I18N_SMARTBUFF_ERR_1 = "VuhDo: Savaşta akıllı buff yapılamaz!";
VUHDO_I18N_SMARTBUFF_ERR_2 = "VuhDo: Buff hedefi yok: ";
VUHDO_I18N_SMARTBUFF_ERR_3 = " oyuncu menzil dışında: ";
VUHDO_I18N_SMARTBUFF_ERR_4 = "VuhDo: Yapılacak buff yok.";
VUHDO_I18N_SMARTBUFF_OKAY_1 = "VuhDo: Buff yapılıyor |cffffffff";
VUHDO_I18N_SMARTBUFF_OKAY_2 = "|r hedef: ";
-- #+v1.189
VUHDO_I18N_UNKNOWN = "bilinmiyor";
VUHDO_I18N_SELF = "Kendim";
VUHDO_I18N_MELEES = "Yakın Dövüşçüler";
VUHDO_I18N_RANGED = "Menzilli";
-- #+1.196
VUHDO_I18N_OPTIONS_NOT_LOADED = ">>> VuhDo Ayarları eklentisi yüklenmedi! <<<";
VUHDO_I18N_SPELL_LAYOUT_NOT_EXIST_1 = "Hata: Büyü düzeni \"";
VUHDO_I18N_SPELL_LAYOUT_NOT_EXIST_2 = "\" mevcut değil.";
VUHDO_I18N_AUTO_ARRANG_1 = "Grup üye sayısı değişti: ";
VUHDO_I18N_AUTO_ARRANG_2 = ". Profil otomatik devreye giriyor: \"";
-- #+1.209
VUHDO_I18N_OWN_GROUP_LONG = "Kendi Grubum";
VUHDO_I18N_TRACK_BUFFS_FOR = "Buff izle: ...";
VUHDO_I18N_NO_FOCUS = "[odak yok]";
VUHDO_I18N_NOT_AVAILABLE = "[ N/A ]";
-- #+1.237
VUHDO_I18N_TT_DISTANCE = "|cffffb233Mesafe:|r";
VUHDO_I18N_TT_OF = " / ";
VUHDO_I18N_YARDS = "yarda";
-- #+1.252
VUHDO_I18N_PANEL = "Panel";
VUHDO_I18N_BOUQUET_AGGRO = "İşaret: Aggro";
VUHDO_I18N_BOUQUET_OUT_OF_RANGE = "İşaret: Menzil dışında";
VUHDO_I18N_BOUQUET_IN_RANGE = "İşaret: Menzil içinde";
VUHDO_I18N_BOUQUET_IN_YARDS = "İşaret: Mesafe < yarda";
VUHDO_I18N_BOUQUET_OTHER_HOTS = "İşaret: Diğer Oyuncuların HoT'ları";
VUHDO_I18N_BOUQUET_DEBUFF_MAGIC = "İşaret: Büyü Debuffı";
VUHDO_I18N_BOUQUET_DEBUFF_DISEASE = "İşaret: Hastalık Debuffı";
VUHDO_I18N_BOUQUET_DEBUFF_POISON = "İşaret: Zehir Debuffı";
VUHDO_I18N_BOUQUET_DEBUFF_CURSE = "İşaret: Lanet Debuffı";
VUHDO_I18N_BOUQUET_CHARMED = "İşaret: Büyülenmiş";
VUHDO_I18N_BOUQUET_DEAD = "İşaret: Ölü";
VUHDO_I18N_BOUQUET_DISCONNECTED = "İşaret: Bağlantı Kopuk";
VUHDO_I18N_BOUQUET_AFK = "İşaret: AFK";
VUHDO_I18N_BOUQUET_PLAYER_TARGET = "İşaret: Oyuncunun Hedefi";
VUHDO_I18N_BOUQUET_MOUSEOVER_TARGET = "İşaret: Fare Üstü Tekil";
VUHDO_I18N_BOUQUET_MOUSEOVER_GROUP = "İşaret: Fare Üstü Grup";
VUHDO_I18N_BOUQUET_HEALTH_BELOW = "İşaret: Can < %";
VUHDO_I18N_BOUQUET_MANA_BELOW = "İşaret: Mana < %";
VUHDO_I18N_BOUQUET_THREAT_ABOVE = "İşaret: Tehdit > %";
VUHDO_I18N_BOUQUET_NUM_IN_CLUSTER = "İşaret: Küme >= oyuncu";
VUHDO_I18N_BOUQUET_CLASS_COLOR = "İşaret: Her Zaman Sınıf Rengi";
VUHDO_I18N_BOUQUET_ALWAYS = "İşaret: Her Zaman Düz";
VUHDO_I18N_SWIFTMEND_POSSIBLE = "İşaret: Swiftmend yapılabilir";
VUHDO_I18N_BOUQUET_MOUSEOVER_CLUSTER = "İşaret: Küme, Fare Üstü";
VUHDO_I18N_THREAT_LEVEL_MEDIUM = "İşaret: Tehdit, Yüksek";
VUHDO_I18N_THREAT_LEVEL_HIGH = "İşaret: Tehdit, Aşırı Hasar";
VUHDO_I18N_BOUQUET_STATUS_HEALTH = "Durum Çubuğu: Can %";
VUHDO_I18N_BOUQUET_STATUS_MANA = "Durum Çubuğu: Mana %";
VUHDO_I18N_BOUQUET_STATUS_OTHER_POWERS = "Durum Çubuğu: Mana Dışı %";
VUHDO_I18N_BOUQUET_STATUS_INCOMING = "Durum Çubuğu: Gelen İyileştirme %";
VUHDO_I18N_BOUQUET_STATUS_THREAT = "Durum Çubuğu: Tehdit %";
VUHDO_I18N_BOUQUET_NEW_ITEM_NAME = "-- (de)buff adını buraya gir --";
VUHDO_I18N_DEF_BOUQUET_TANK_COOLDOWNS = "Tank Cooldowns";
VUHDO_I18N_DEF_BOUQUET_PW_S_WEAKENED_SOUL = "PW:S & Weakened Soul";
VUHDO_I18N_DEF_BOUQUET_MONK_STAGGER = "Monk Stagger";
VUHDO_I18N_DEF_BOUQUET_BORDER_MULTI_AGGRO = "Border: Multi + Aggro";
VUHDO_I18N_DEF_BOUQUET_BORDER_MULTI = "Border: Multi";
VUHDO_I18N_DEF_BOUQUET_BORDER_SIMPLE = "Border: Simple";
VUHDO_I18N_DEF_BOUQUET_SWIFTMENDABLE = "Swiftmendable";
VUHDO_I18N_DEF_BOUQUET_MOUSEOVER_SINGLE = "Mouseover: Single";
VUHDO_I18N_DEF_BOUQUET_MOUSEOVER_MULTI = "Mouseover: Multi";
VUHDO_I18N_DEF_BOUQUET_AGGRO_INDICATOR = "Aggro Indicator";
VUHDO_I18N_DEF_BOUQUET_CLUSTER_MOUSE_HOVER = "Cluster: Mouse Hover";
VUHDO_I18N_DEF_BOUQUET_THREAT_MARKS = "Threat: Marks";
VUHDO_I18N_DEF_BOUQUET_BAR_MANA_ALL = "Manabars: All Powers";
VUHDO_I18N_DEF_BOUQUET_BAR_MANA_ONLY = "Manabars: Mana only";
VUHDO_I18N_DEF_BOUQUET_BAR_THREAT = "Threat: Status Bar";
VUHDO_I18N_CUSTOM_ICON_NONE = "- Yok / Varsayılan -";
VUHDO_I18N_CUSTOM_ICON_GLOSSY = "Parlak";
VUHDO_I18N_CUSTOM_ICON_MOSAIC = "Mozaik";
VUHDO_I18N_CUSTOM_ICON_CLUSTER = "Küme";
VUHDO_I18N_CUSTOM_ICON_FLAT = "Düz";
VUHDO_I18N_CUSTOM_ICON_SPOT = "Nokta";
VUHDO_I18N_CUSTOM_ICON_CIRCLE = "Daire";
VUHDO_I18N_CUSTOM_ICON_SKETCHED = "Karalama";
VUHDO_I18N_CUSTOM_ICON_RHOMB = "Eşkenar Dörtgen";
VUHDO_I18N_ERROR_NO_PROFILE = "Hata: Bu adda profil yok: ";
VUHDO_I18N_PROFILE_LOADED = "Profil başarıyla yüklendi: ";
VUHDO_I18N_PROFILE_SAVED = "Profil başarıyla kaydedildi: ";
VUHDO_I18N_PROFILE_OVERWRITE_1 = "Profil";
VUHDO_I18N_PROFILE_OVERWRITE_2 = "şu anda başka bir\nkarakterin";
VUHDO_I18N_PROFILE_OVERWRITE_3 = "\n- Üzerine Yaz: Mevcut profilin üzerine yazılır.\n- Kopyala: Kopya oluşturup kaydet. Mevcut profili koru.";
VUHDO_I18N_COPY = "Kopyala";
VUHDO_I18N_OVERWRITE = "Üzerine Yaz";
VUHDO_I18N_DISCARD = "Vazgeç";
-- 2.0, alpha #2
VUHDO_I18N_DEF_BAR_BACKGROUND_SOLID = "Background: Solid";
VUHDO_I18N_DEF_BAR_BACKGROUND_CLASS_COLOR = "Background: Class Color";
-- 2.0 alpha #9
VUHDO_I18N_BOUQUET_DEBUFF_BAR_COLOR = "İşaret: Debuff, yapılandırılmış";
-- 2.0 alpha #11
VUHDO_I18N_DEF_BOUQUET_BAR_HEALTH = "Health Bar: (generic, gradient)";
VUHDO_I18N_UPDATE_RAID_TARGET = "İşaret: Raid hedef rengi";
VUHDO_I18N_BOUQUET_OVERHEAL_HIGHLIGHT = "Renk: Fazla İyileştirme Vurgusu";
VUHDO_I18N_BOUQUET_EMERGENCY_COLOR = "Renk: Acil Durum";
VUHDO_I18N_BOUQUET_HEALTH_ABOVE = "İşaret: Can > %";
VUHDO_I18N_BOUQUET_RESURRECTION = "İşaret: Diriltme";
VUHDO_I18N_BOUQUET_STACKS_COLOR = "Renk: #Yığın";
-- 2.1
VUHDO_I18N_DEF_BOUQUET_BAR_HEALTH_SOLID = "Health (generic, solid)";
VUHDO_I18N_DEF_BOUQUET_BAR_HEALTH_CLASS_COLOR = "Health (generic, class col)";
-- 2.9
VUHDO_I18N_NO_TARGET = "[hedef yok]";
VUHDO_I18N_TT_LEFT = " Sol: ";
VUHDO_I18N_TT_RIGHT = " Sağ: ";
VUHDO_I18N_TT_MIDDLE = " Orta: ";
VUHDO_I18N_TT_BTN_4 = " Düğme 4: ";
VUHDO_I18N_TT_BTN_5 = " Düğme 5: ";
VUHDO_I18N_TT_WHEEL_UP = " Tekerlek yukarı: ";
VUHDO_I18N_TT_WHEEL_DOWN = " Tekerlek aşağı: ";
-- 2.13
VUHDO_I18N_BOUQUET_CLASS_ICON = "Simge: Sınıf";
VUHDO_I18N_BOUQUET_RAID_ICON = "Simge: Raid Sembolü";
VUHDO_I18N_BOUQUET_ROLE_ICON = "Simge: Rol";
-- 2.18
VUHDO_I18N_LOAD_PROFILE = "Profili Yükle";
-- 2.20
VUHDO_I18N_DC_SHIELD_NO_MACROS = "Bu karakter için boş makro yuvası yok... bağlantı kopma koruması geçici olarak kapalı.";
VUHDO_I18N_BROKER_TOOLTIP_1 = "Ayarlar menüsü için |cffffff00Sol Tık|r";
VUHDO_I18N_BROKER_TOOLTIP_2 = "Açılır menü için |cffffff00Sağ Tık|r";
-- 2.54
VUHDO_I18N_HOURS = "saat";
VUHDO_I18N_MINS = "dk";
VUHDO_I18N_SECS = "sn";
-- 2.65
VUHDO_I18N_BOUQUET_CUSTOM_DEBUFF = "Simge: Özel Debuff";
-- 2.66
VUHDO_I18N_OFF = "kapalı";
VUHDO_I18N_GHOST = "hayalet";
VUHDO_I18N_RIP = "öldü";
VUHDO_I18N_DC = "d/c";
VUHDO_I18N_FOC = "odak";
VUHDO_I18N_TAR = "hedef";
VUHDO_I18N_VEHICLE = "O-O";
-- 2.67
VUHDO_I18N_BUFF_WATCH = "Buff İzleyici";
VUHDO_I18N_HOTS = "HoT'lar";
VUHDO_I18N_DEBUFFS = "Zayıflatmalar";
VUHDO_I18N_BOUQUET_PLAYER_FOCUS = "İşaret: Oyuncunun Odağı";
-- 2.69
VUHDO_I18N_SIDE_BAR_LEFT = "Sol Kenar";
VUHDO_I18N_SIDE_BAR_RIGHT = "Sağ Kenar";
VUHDO_I18N_OWN_PET = "Kendi Petim";
-- 2.72
VUHDO_I18N_SPELL = "Büyü";
VUHDO_I18N_COMMAND = "Komut";
VUHDO_I18N_MACRO = "Makro";
VUHDO_I18N_ITEM = "Eşya";
-- 2.75
VUHDO_I18N_ERR_NO_BOUQUET = "\"%s\", mevcut olmayan \"%s\" buketine bağlanmaya çalışıyor!";

VUHDO_I18N_BOUQUET_HEALTH_BELOW_ABS = "İşaret: Can < k";
VUHDO_I18N_BOUQUET_HEALTH_ABOVE_ABS = "İşaret: Can > k";
VUHDO_I18N_SPELL_LAYOUT_NOT_EXIST = "Büyü düzeni \"%s\" mevcut değil.";

--VUHDO_I18N_ADDON_WARNING = "WARNING: Addon |cffffffff\"%s\"|r is enabled along with VuhDo, which may be problematic. Reason: %s";
--VUHDO_I18N_MAY_CAUSE_LAGS = "May cause severe lags.";

VUHDO_I18N_DISABLE_BY_MIN_VERSION = "!!! VUHDO KAPALI !!! Bu sürüm (%s) yalnızca %d ve üstü istemci sürümleri içindir !!!"
VUHDO_I18N_DISABLE_BY_MAX_VERSION = "!!! VUHDO KAPALI !!! Bu sürüm (%s) yalnızca %d ve altı istemci sürümleri içindir !!!"

VUHDO_I18N_BOUQUET_STATUS_ALTERNATE_POWERS = "Durum Çubuğu: Alternatif Güç %"
VUHDO_I18N_BOUQUET_ALTERNATE_POWERS_ABOVE = "İşaret: Alternatif Güç > %";
VUHDO_I18N_DEF_ALTERNATE_POWERS = "Alternative Powers";
VUHDO_I18N_DEF_TANK_CDS_EXTENDED = "Tank Cooldowns extd";
VUHDO_I18N_BOUQUET_HOLY_POWER_EQUALS = "İşaret: Kendi Holy Power ==";
VUHDO_I18N_DEF_PLAYER_HOLY_POWER = "Player Holy Power";
VUHDO_I18N_CUSTOM_ICON_ONE_THIRD = "Üçte: Bir";
VUHDO_I18N_CUSTOM_ICON_TWO_THIRDS = "Üçte: İki"
VUHDO_I18N_CUSTOM_ICON_THREE_THIRDS = "Üçte: Üç";
VUHDO_I18N_DEF_ROLE_ICON = "Role Icon";

VUHDO_I18N_DEF_BOUQUET_TARGET_HEALTH = "Health (generic, target)";

VUHDO_I18N_TAPPED_COLOR = "İşaret: Kapılmış";
VUHDO_I18N_ENEMY_STATE_COLOR = "Renk: Dost/Düşman";
VUHDO_I18N_FRIEND_STATUS = "İşaret: Dost";
VUHDO_I18N_FOE_STATUS = "İşaret: Düşman";
VUHDO_I18N_BOUQUET_STATUS_ALWAYS_FULL = "Durum Çubuğu: Her Zaman Dolu";
VUHDO_I18N_BOUQUET_STATUS_FULL_IF_ACTIVE = "Durum Çubuğu: Etkinse Dolu";
VUHDO_I18N_AOE_ADVICE = "Simge: AoE Önerisi";
VUHDO_I18N_DEF_AOE_ADVICE = "AOE Advice";

VUHDO_I18N_BOUQUET_DURATION_ABOVE = "İşaret: Süre > sn";
VUHDO_I18N_BOUQUET_DURATION_BELOW = "İşaret: Süre < sn";
VUHDO_I18N_DEF_WRACK = "Sinestra: Wrack";

VUHDO_I18N_DEF_DIRECTION_ARROW = "Direction Arrow";
VUHDO_I18N_BOUQUET_DIRECTION_ARROW = "Yön Oku";
VUHDO_I18N_DEF_RAID_LEADER = "Icon: Raid leader";
VUHDO_I18N_DEF_RAID_ASSIST = "Icon: Raid assist";
VUHDO_I18N_DEF_MASTER_LOOTER = "Icon: Master looter";
VUHDO_I18N_DEF_PVP_STATUS = "Icon: PvP Status";

VUHDO_I18N_GRID_MOUSEOVER_SINGLE = "Grid: Mouseover Single";
VUHDO_I18N_GRID_BACKGROUND_BAR = "Grid: Background Bar";
VUHDO_I18N_DEF_BIT_O_GRID = "Bit'o'Grid";
VUHDO_I18N_DEF_VUHDO_ESQUE = "Vuhdo'esque";


VUHDO_I18N_DEF_ROLE_COLOR = "Role Color";
VUHDO_I18N_BOUQUET_ROLE_TANK = "İşaret: Rol Tank";
VUHDO_I18N_BOUQUET_ROLE_DAMAGE = "İşaret: Rol Hasar";
VUHDO_I18N_BOUQUET_ROLE_HEALER = "İşaret: Rol Şifacı";

VUHDO_I18N_BOUQUET_STACKS = "İşaret: Yığın >";
VUHDO_I18N_DEF_PLAYER_CHI = "Player Chi";

VUHDO_I18N_BOUQUET_TARGET_RAID_ICON = "Simge: Hedefin Raid Sembolü";
VUHDO_I18N_BOUQUET_OWN_CHI_EQUALS = "İşaret: Kendi Chi ==";
VUHDO_I18N_CUSTOM_ICON_FOUR_THIRDS = "Üçte: Dört";
VUHDO_I18N_CUSTOM_ICON_FIVE_THIRDS = "Üçte: Beş";
VUHDO_I18N_DEF_RAID_CDS = "Raid Cooldowns";
VUHDO_I18N_BOUQUET_STATUS_CLASS_COLOR_IF_ACTIVE = "İşaret: Etkinse Sınıf Rengi";

VUHDO_I18N_LETHAL_POISONS = "Öldürücü Zehirler";
VUHDO_I18N_NON_LETHAL_POISONS = "Öldürücü Olmayan Zehirler";
VUHDO_I18N_DEF_COUNTER_SHIELD_ABSORB = "Counter: All Shield Absorb #k";
VUHDO_I18N_BUFFC_WEAPON_ENCHANT_OFF = "Weapon Enchant (offhand)";

VUHDO_I18N_DEF_PVP_FLAGS="PvP Flag Carriers";
VUHDO_I18N_DEF_STATUS_SHIELD = "Statusbar: Shield";

VUHDO_I18N_TARGET = "Hedef";
VUHDO_I18N_FOCUS = "Odak";
VUHDO_I18N_DEF_STATUS_OVERSHIELDED = "Statusbar: Overshielded";

-- 3.65
VUHDO_I18N_BOUQUET_OUTSIDE_ZONE = "İşaret: Oyuncunun Bölgesi, dışında";
VUHDO_I18N_BOUQUET_INSIDE_ZONE = "İşaret: Oyuncunun Bölgesi, içinde";
VUHDO_I18N_BOUQUET_WARRIOR_TANK = "İşaret: Rol Tank, Warrior";
VUHDO_I18N_BOUQUET_PALADIN_TANK = "İşaret: Rol Tank, Paladin";
VUHDO_I18N_BOUQUET_DK_TANK = "İşaret: Rol Tank, Death Knight";
VUHDO_I18N_BOUQUET_MONK_TANK = "İşaret: Rol Tank, Monk";
VUHDO_I18N_BOUQUET_DRUID_TANK = "İşaret: Rol Tank, Druid";

-- 3.66
VUHDO_I18N_BOUQUET_PALADIN_BEACON = "Paladin İşaret Feneri";
VUHDO_I18N_BOUQUET_STATUS_EXCESS_ABSORB = "Durum Çubuğu: Fazla Emme %";
VUHDO_I18N_BOUQUET_STATUS_TOTAL_ABSORB = "Durum Çubuğu: Toplam Emme %";

-- 3.67
VUHDO_I18N_NO_BOSS = "[NPC yok]";
VUHDO_I18N_BOSSES = "NPC'ler";

-- 3.71
VUHDO_I18N_BOUQUET_CUSTOM_FLAG = "Özel İşaret";
VUHDO_I18N_ERROR_CUSTOM_FLAG_LOAD = "{VuhDo} Hata: Özel işaret doğrulayıcın yüklenmedi:";
VUHDO_I18N_ERROR_CUSTOM_FLAG_EXECUTE = "{VuhDo} Hata: Özel işaret doğrulayıcın çalışmadı:";
VUHDO_I18N_ERROR_CUSTOM_FLAG_BLOCKED = "{VuhDo} Hata: Bu buketin bir özel işareti yasak bir işlevi çağırmaya çalıştı ve engellendi. Yalnızca güvendiğin kaynaklardan içe aktarma yap.";
VUHDO_I18N_ERROR_INVALID_VALIDATOR = "{VuhDo} Hata: Geçersiz doğrulayıcı:";

-- 3.72
VUHDO_I18N_BOUQUET_DEMON_HUNTER_TANK = "İşaret: Rol Tank, Demon Hunter";
VUHDO_I18N_DEMON_HUNTERS = "Demon Hunter'lar";

-- 3.77
VUHDO_I18N_DEF_COUNTER_OVERFLOW_ABSORB = "Counter: Mythic+ Overflow Absorb #k";

-- 3.79
VUHDO_I18N_DEFAULT_RES_ANNOUNCE_MASS = "Toplu diriltme yapılıyor!";

-- 3.81
VUHDO_I18N_BOUQUET_OVERFLOW_COUNTER = "Mythic+ Taşma Eki";

-- 3.82
VUHDO_I18N_SPELL_TRACE = "Simge: Büyü İzi";
VUHDO_I18N_DEF_SPELL_TRACE = "Spell Trace";
VUHDO_I18N_TRAIL_OF_LIGHT = "Simge: Trail of Light";
VUHDO_I18N_DEF_TRAIL_OF_LIGHT = "Trail of Light";

-- 3.83
VUHDO_I18N_BOUQUET_STATUS_MANA_HEALER_ONLY = "Durum Çubuğu: Mana % (Yalnızca Şifacı)";
VUHDO_I18N_DEF_BOUQUET_BAR_MANA_HEALER_ONLY = "Manabars: Mana (Healer Only)";

-- 3.98
VUHDO_I18N_BOUQUET_HAS_SUMMON_ICON = "Simge: Çağrısı Var";
VUHDO_I18N_DEF_BOUQUET_HAS_SUMMON = "Summon Status Icon";
VUHDO_I18N_DEF_BOUQUET_ROLE_AND_SUMMON = "Role & Summon Status Icon";

-- 3.99
VUHDO_I18N_BOUQUET_IS_PHASED = "Simge: Farklı Fazda";
VUHDO_I18N_BOUQUET_IS_WAR_MODE_PHASED = "Simge: War Mode Fazında";
VUHDO_I18N_DEF_BOUQUET_IS_PHASED = "Is Phased Icon";

-- 3.101
VUHDO_I18N_DEF_PLAYER_COMBO_POINTS = "Player Combo Points";
VUHDO_I18N_BOUQUET_OWN_COMBO_POINTS_EQUALS = "İşaret: Kendi Kombo Puanları ==";
VUHDO_I18N_DEF_PLAYER_SOUL_SHARDS = "Player Soul Shards";
VUHDO_I18N_BOUQUET_OWN_SOUL_SHARDS_EQUALS = "İşaret: Kendi Soul Shard'ları ==";
VUHDO_I18N_DEF_PLAYER_RUNES = "Player Runes";
VUHDO_I18N_BOUQUET_OWN_RUNES_EQUALS = "İşaret: Kendi Rünleri ==";
VUHDO_I18N_DEF_PLAYER_ARCANE_CHARGES = "Player Arcane Charges";
VUHDO_I18N_BOUQUET_OWN_ARCANE_CHARGES_EQUALS = "İşaret: Kendi Arcane Charge'ları ==";
VUHDO_I18N_DEBUFF_BLACKLIST_ADDED = "\"[%s] %s\" debuff kara listesine eklendi.";

-- 3.104
VUHDO_I18N_PLAY_SOUND_FILE_ERR = "\"%s\" sesi çalınamadı: %s";
VUHDO_I18N_PLAY_SOUND_FILE_DEBUFF_ERR = "Standart debuff için \"%s\" sesi çalınamadı. Ayarlarını 'VuhDo Ayarları > Debufflar > Standart > Debuff Sesi' altında düzenle.";
VUHDO_I18N_PLAY_SOUND_FILE_CUSTOM_DEBUFF_ERR = "\"%s\" özel debuffı için \"%s\" sesi çalınamadı. Ayarlarını 'VuhDo Ayarları > Debufflar > Özel' altında düzenle.";

-- 3.122
VUHDO_I18N_BOUQUET_STATUS_POWER_TANK_ONLY = "Durum Çubuğu: Güç % (Yalnızca Tank)";
VUHDO_I18N_DEF_BOUQUET_BAR_MANA_TANK_ONLY = "Manabars: Power (Tank Only)";

-- 3.131
VUHDO_I18N_DEF_COUNTER_HEAL_ABSORB = "Counter: All Heal Absorb #k";
VUHDO_I18N_DEF_STATUS_HEAL_ABSORB = "Statusbar: Heal Absorb";

-- 3.135
VUHDO_I18N_TRINKET_1 = "Tılsım 1";
VUHDO_I18N_TRINKET_2 = "Tılsım 2";

-- 3.139
VUHDO_I18N_EVOKERS = "Evoker'lar";

-- 3.143
VUHDO_I18N_BUFFC_EARTH_SHIELD = "Earth Shield (Self)";

-- 3.150
VUHDO_I18N_ADDON_COMPARTMENT_ICON = "Eklenti Bölmesi simgesi artık ";

-- 3.152
VUHDO_I18N_SPELL_TRACE_SINGLE = "Simge: Büyü İzi (Tekil)";

-- 3.154
VUHDO_I18N_SPELL_TRACE_INCOMING = "Simge: Büyü İzi (Gelen)";
VUHDO_I18N_SPELL_TRACE_HEAL = "Simge: Büyü İzi (İyileştirme)";

-- 3.157
VUHDO_I18N_BOUQUET_STATUS_HEALTH_IF_ACTIVE = "Durum Çubuğu: Etkinse Can %";

VUHDO_I18N_DEF_COUNTER_ACTIVE_AURAS = "Counter: Active Bouquet Auras #k";

VUHDO_I18N_BOUQUET_EVOKER_REVERSION = "Evoker Reversion (yankısız)";
VUHDO_I18N_BOUQUET_EVOKER_REVERSION_ECHO = "Evoker Reversion (yankı)";
VUHDO_I18N_BOUQUET_EVOKER_DREAM_BREATH = "Evoker Dream Breath (yankısız)";
VUHDO_I18N_BOUQUET_EVOKER_DREAM_BREATH_ECHO = "Evoker Dream Breath (yankı)";
VUHDO_I18N_BOUQUET_EVOKER_ALL_ECHO = "Evoker Tüm HoT Yankıları";

VUHDO_I18N_TRAIL_OF_LIGHT_NEXT = "İşaret: Trail of Light (Sonraki)";
VUHDO_I18N_DEF_TRAIL_OF_LIGHT_NEXT = "Trail of Light (Next)";
VUHDO_I18N_BOUQUET_DEBUFF_BLEED = "İşaret: Kanama Debuffı";

VUHDO_I18N_DEF_SPELL_TRACE_INCOMING = "Spell Trace (Incoming)";

VUHDO_I18N_BOUQUET_CHI_HARMONY_ICON_MINE = "Simge: Chi Harmony (Benim)";
VUHDO_I18N_DEF_BOUQUET_CHI_HARMONY_ICON_MINE = "Chi Harmony (Mine)";
VUHDO_I18N_BOUQUET_CHI_HARMONY_ICON_OTHERS = "Simge: Chi Harmony (Diğerleri)";
VUHDO_I18N_DEF_BOUQUET_CHI_HARMONY_ICON_OTHERS = "Chi Harmony (Others)";
VUHDO_I18N_BOUQUET_CHI_HARMONY_ICON_BOTH = "Simge: Chi Harmony (İkisi)";
VUHDO_I18N_DEF_BOUQUET_CHI_HARMONY_ICON_BOTH = "Chi Harmony (Both)";

VUHDO_I18N_BOUQUET_DEBUFF_ENRAGE = "İşaret: Öfke Debuffı";

VUHDO_I18N_AURA_GROUP_MY_HOTS = "HoT'larım (Savaş Auraları)";
VUHDO_I18N_AURA_GROUP_OTHERS_HOTS = "Diğerlerinin HoT'ları (Savaş Auraları)";
VUHDO_I18N_AURA_GROUP_ALL_HOTS = "Tüm HoT'lar (Savaş Auraları)";
VUHDO_I18N_AURA_GROUP_DISPELLABLE = "Temizlenebilir Debufflar";
VUHDO_I18N_AURA_GROUP_CC = "Kitle Kontrol Etkileri";
VUHDO_I18N_AURA_GROUP_BIG_DEF = "Büyük Savunmalar";
VUHDO_I18N_AURA_GROUP_EXTERNAL_DEF = "Dış Savunmalar";
VUHDO_I18N_AURA_GROUP_ALL_DEBUFFS = "Tüm Debufflar";
VUHDO_I18N_AURA_GROUP_ALL_BUFFS = "Tüm Bufflar";
VUHDO_I18N_AURA_GROUP_MY_BUFFS = "Sınıfıma Özgü Bufflarım";
VUHDO_I18N_AURA_GROUP_OTHERS_BUFFS = "Diğerlerinin Sınıfa Özgü Buffları";
VUHDO_I18N_AURA_GROUP_ALL_RAID_BUFFS = "Tüm Sınıfa Özgü Bufflar";
VUHDO_I18N_AURA_GROUP_RAID_DEBUFFS = "Raid Debuffları";
VUHDO_I18N_AURA_GROUP_IMPORTANT_BUFFS = "Önemli Bufflar";
VUHDO_I18N_AURA_GROUP_IMPORTANT_DEBUFFS = "Önemli Debufflar";
VUHDO_I18N_AURA_GROUP_CANCELABLE = "İptal Edilebilir Bufflar";
VUHDO_I18N_AURA_GROUP_NOT_CANCELABLE = "İptal Edilemeyen Bufflar";
VUHDO_I18N_AURA_GROUP_TORGHAST_ANIMA = "Torghast Anima Güçleri";
VUHDO_I18N_AURA_GROUP_INFERRED_RIPTIDE = "Riptide (Tahmini)";
VUHDO_I18N_AURA_GROUP_INFERRED_ECHO = "Echo (Tahmini)";
VUHDO_I18N_AURA_GROUP_INFERRED_ATONEMENT = "Atonement (Tahmini)";
VUHDO_I18N_AURA_GROUP_MY_DEBUFFS = "Debufflarım";
VUHDO_I18N_AURA_GROUP_MY_EXTERNAL_DEF = "Dışa Savunmalarım";
VUHDO_I18N_AURA_GROUP_MY_RAID_DEBUFFS = "Raid Debufflarım";
VUHDO_I18N_AURA_GROUP_PRESERVATION_EVOKER_HOTS = "Preservation Evoker HoT'ları";
VUHDO_I18N_AURA_GROUP_AUGMENTATION_EVOKER_BUFFS = "Augmentation Evoker Buffları";
VUHDO_I18N_AURA_GROUP_RESTORATION_DRUID_HOTS = "Restoration Druid HoT'ları";
VUHDO_I18N_AURA_GROUP_DISCIPLINE_PRIEST_HOTS = "Discipline Priest HoT'ları";
VUHDO_I18N_AURA_GROUP_HOLY_PRIEST_HOTS = "Holy Priest HoT'ları";
VUHDO_I18N_AURA_GROUP_MISTWEAVER_MONK_HOTS = "Mistweaver Monk HoT'ları";
VUHDO_I18N_AURA_GROUP_RESTORATION_SHAMAN_HOTS = "Restoration Shaman HoT'ları";
VUHDO_I18N_AURA_GROUP_HOLY_PALADIN_HOTS = "Holy Paladin HoT'ları";
VUHDO_I18N_AURA_GROUP_RAID_BUFFS = "Raid Buffları";
VUHDO_I18N_AURA_GROUP_BLESSING_OF_BRONZE = "Blessing of the Bronze";
VUHDO_I18N_AURA_GROUP_ROGUE_POISONS = "Rogue Zehirleri";
VUHDO_I18N_AURA_GROUP_SHAMAN_WEAPON_IMBUEMENTS = "Shaman Silah Büyüleri";
VUHDO_I18N_AURA_GROUP_PALADIN_WEAPON_IMBUEMENTS = "Paladin Silah Büyüleri";
VUHDO_I18N_AURA_GROUP_ENHANCEMENT_SHAMAN_BUFFS = "Enhancement Shaman Buffları";
VUHDO_I18N_AURA_GROUP_BREWMASTER_MONK_BUFFS = "Brewmaster Monk Buffları";
VUHDO_I18N_AURA_GROUP_WARLOCK_METAMORPHOSIS = "Warlock Metamorphosis";
VUHDO_I18N_AURA_GROUP_MIGRATED_HOTS = "Taşınan HoT'lar";
VUHDO_I18N_AURA_GROUP_MIGRATED_HOT_ICONS = "Taşınan HoT Simgeleri";
VUHDO_I18N_AURA_GROUP_MIGRATED_HOT_BARS = "Taşınan HoT Çubukları";

VUHDO_I18N_BOUQUET_AURA_GROUP_ACTIVE = "İşaret: Aura Grubu Etkin";
VUHDO_I18N_AURA_GROUP_FERAL_DRUID_BUFFS = "Feral Druid Buffları";
VUHDO_I18N_BW_MISS = "|cffff0000YOK|r";
VUHDO_I18N_BW_LOCK = "|cff4488ffKİLİT|r";
VUHDO_I18N_BW_TARGET_MODE = "Hedefleyen";
VUHDO_I18N_BW_TARGET_BY_NAME = "Oyuncu adı";
VUHDO_I18N_BW_TARGET = "Hedef";
VUHDO_I18N_BW_FOCUS = "Odak";

VUHDO_I18N_AURA_GROUP_ALL_DISPELLABLE = "Tüm Temizlenebilir Debufflar";

VUHDO_I18N_TEXT_PROVIDER_SOURCE_MANA = "Mana";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_RAGE = "Öfke";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_FOCUS = "Odak";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_ENERGY = "Enerji";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_RUNIC_POWER = "Runik Güç";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_LUNAR_POWER = "Astral Güç";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_MAELSTROM = "Girdap";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_INSANITY = "Delilik";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_FURY = "Hiddet";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_PAIN = "Acı";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_ESSENCE = "Öz";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_ALL_POWERS = "Tüm Güçler";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_CHI = "Chi";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_HOLY_POWER = "Kutsal Güç";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_COMBO_POINTS = "Kombo Puanları";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_SOUL_SHARDS = "Ruh Parçaları";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_RUNES = "Rünler";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_ARCANE_CHARGES = "Arkan Yükleri";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_THREAT = "Tehdit";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_OVERHEAL = "Fazla İyileştirme";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_INCOMING_HEAL = "Gelen İyileştirme";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_SHIELD_ABSORB = "Kalkan Emmesi";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_HEAL_ABSORB = "İyileştirme Emmesi";
VUHDO_I18N_TEXT_PROVIDER_FORMAT_PERCENT = "<#n>%";
VUHDO_I18N_TEXT_PROVIDER_FORMAT_PERCENT_TENTH = "<#n/10%>";
VUHDO_I18N_TEXT_PROVIDER_FORMAT_UNIT_OF_UNIT = "<#n>/<#n>";
VUHDO_I18N_TEXT_PROVIDER_FORMAT_KILO_OF_KILO = "<#nk>/<#nk>";
VUHDO_I18N_TEXT_PROVIDER_FORMAT_N = "<#n>";
VUHDO_I18N_TEXT_PROVIDER_FORMAT_NK = "<#nk>";
VUHDO_I18N_TEXT_PROVIDER_FORMAT_NK_PLUS = "+<#nk>";
VUHDO_I18N_TEXT_PROVIDER_FORMAT_NK_PERCENT = "<#nk> (<#n>%)";
VUHDO_I18N_TEXT_PROVIDER_FORMAT_KILO_OF_KILO_PERCENT = "<#nk>/<#nk> (<#n>%)";
VUHDO_I18N_TEXT_PROVIDER_SOURCE_LABEL = "Yazı Kaynağı";
VUHDO_I18N_TEXT_PROVIDER_FORMAT_LABEL = "Yazı Biçimi";

VUHDO_I18N_BLIZZ_RESTORE_RELOAD = "Gizlenen Blizzard çerçevelerini geri getirmek için arayüzü yeniden yükle (/reload).";

VUHDO_I18N_AURA_GROUP_MY_NAMEPLATE = "Debufflarım (isim plakası dahil)";
VUHDO_I18N_AURA_GROUP_OTHERS_NAMEPLATE = "Diğerlerinin Debuffları (isim plakası dahil)";
VUHDO_I18N_AURA_GROUP_ALL_NAMEPLATE = "Tüm Debufflar (isim plakası dahil)";
VUHDO_I18N_AURA_GROUP_PURGEABLE_BUFFS = "Silinebilir Bufflar";
VUHDO_I18N_AURA_GROUP_ALL_PURGEABLE_BUFFS = "Tüm Silinebilir Bufflar";
VUHDO_I18N_AURA_GROUP_BOSS_DEBUFFS = "Boss ve Rol Debuffları";
VUHDO_I18N_AURA_GROUP_PRIORITY_DEBUFFS = "Öncelikli Debufflar";
VUHDO_I18N_AURA_GROUP_RELEVANT_BUFFS = "İlgili Bufflar";
VUHDO_I18N_AURA_GROUP_RELEVANT_DEBUFFS = "İlgili Debufflar";
VUHDO_I18N_AURA_GROUP_TIMED_DEBUFFS = "Süreli Debufflar";

VUHDO_I18N_PT_NAME_AMBIGUOUS = "Özel tank adı belirsiz: %s. Tam adı kullan (Ad-Diyar ya da Ad-Soyad).";

VUHDO_I18N_AURA_GROUP_PRIEST_WEAKENED_SOUL = "Priest Weakened Soul";

VUHDO_I18N_BW_MAIN_HAND = "Ana El";
VUHDO_I18N_BW_OFF_HAND = "Yedek El";
VUHDO_I18N_ERROR_NO_LIST_GROUP_BOUQUET = "\"%s\" aura grubu, mevcut olmayan \"%s\" buketini içeriyor!";

VUHDO_I18N_BOUQUET_STATUS_POWER_HEALER_ONLY = "Durum Çubuğu: Güç % (Yalnızca Şifacı)";
VUHDO_I18N_DEF_BOUQUET_BAR_POWER_HEALER_ONLY = "Manabars: Power (Healer Only)";
VUHDO_I18N_DEF_BOUQUET_PW_S_WEAKENED_SOUL_ICONS = "PW:S & Weakened Soul (Icons)";