-- Eğitmen karşılama metinleri, özel görev hedefleri, meslek rütbeleri ve posta penceresi.
local A = WoWTurkce.Arayuz
if A["Accept Redpath's Forgiveness"] == nil then A["Accept Redpath's Forgiveness"] = "Redpath'in affını kabul et" end
if A["Amount to send:"] == nil then A["Amount to send:"] = "Gönderilecek miktar:" end
if A["Apprentice Alchemist"] == nil then A["Apprentice Alchemist"] = "Çırak Simyacı" end
if A["Apprentice Blacksmith"] == nil then A["Apprentice Blacksmith"] = "Çırak Demirci" end
if A["Apprentice Cook"] == nil then A["Apprentice Cook"] = "Çırak Aşçı" end
if A["Apprentice Enchanter"] == nil then A["Apprentice Enchanter"] = "Çırak Efsuncu" end
if A["Apprentice Engineer"] == nil then A["Apprentice Engineer"] = "Çırak Mühendis" end
if A["Apprentice First Aid"] == nil then A["Apprentice First Aid"] = "Çırak İlk Yardım" end
if A["Apprentice Fisherman"] == nil then A["Apprentice Fisherman"] = "Çırak Balıkçı" end
if A["Apprentice Herbalist"] == nil then A["Apprentice Herbalist"] = "Çırak Bitkici" end
if A["Apprentice Leatherworker"] == nil then A["Apprentice Leatherworker"] = "Çırak Derici" end
if A["Apprentice Miner"] == nil then A["Apprentice Miner"] = "Çırak Madenci" end
if A["Apprentice Riding"] == nil then A["Apprentice Riding"] = "Çırak Binicilik" end
if A["Apprentice Skinner"] == nil then A["Apprentice Skinner"] = "Çırak Deri Yüzücü" end
if A["Apprentice Tailor"] == nil then A["Apprentice Tailor"] = "Çırak Terzi" end
if A["Archive Burned"] == nil then A["Archive Burned"] = "Arşiv yakıldı" end
if A["Artisan Alchemist"] == nil then A["Artisan Alchemist"] = "Usta Simyacı" end
if A["Artisan Blacksmith"] == nil then A["Artisan Blacksmith"] = "Usta Demirci" end
if A["Artisan Cook"] == nil then A["Artisan Cook"] = "Usta Aşçı" end
if A["Artisan Enchanter"] == nil then A["Artisan Enchanter"] = "Usta Efsuncu" end
if A["Artisan Engineer"] == nil then A["Artisan Engineer"] = "Usta Mühendis" end
if A["Artisan First Aid"] == nil then A["Artisan First Aid"] = "Usta İlk Yardım" end
if A["Artisan Fisherman"] == nil then A["Artisan Fisherman"] = "Usta Balıkçı" end
if A["Artisan Herbalist"] == nil then A["Artisan Herbalist"] = "Usta Bitkici" end
if A["Artisan Leatherworker"] == nil then A["Artisan Leatherworker"] = "Usta Derici" end
if A["Artisan Miner"] == nil then A["Artisan Miner"] = "Usta Madenci" end
if A["Artisan Riding"] == nil then A["Artisan Riding"] = "Usta Binicilik" end
if A["Artisan Skinner"] == nil then A["Artisan Skinner"] = "Usta Deri Yüzücü" end
if A["Artisan Tailor"] == nil then A["Artisan Tailor"] = "Usta Terzi" end
if A["Atiesh Cleansed"] == nil then A["Atiesh Cleansed"] = "Atiesh arındırıldı" end
if A["Attack Plan: Orgrimmar destroyed"] == nil then A["Attack Plan: Orgrimmar destroyed"] = "Saldırı Planı: Orgrimmar yok edildi" end
if A["Attack Plan: Sen'jin Village destroyed"] == nil then A["Attack Plan: Sen'jin Village destroyed"] = "Saldırı Planı: Sen'jin Village yok edildi" end
if A["Attack Plan: Valley of Trials destroyed"] == nil then A["Attack Plan: Valley of Trials destroyed"] = "Saldırı Planı: Valley of Trials yok edildi" end
if A["Bael Modan Flying Machine destroyed"] == nil then A["Bael Modan Flying Machine destroyed"] = "Bael Modan Uçan Makinesi yok edildi" end
if A["Banner Destroyed"] == nil then A["Banner Destroyed"] = "Sancak yok edildi" end
if A["Blacksmith Assaulted"] == nil then A["Blacksmith Assaulted"] = "Demirhaneye saldırıldı" end
if A["Burn the Highvale Notes"] == nil then A["Burn the Highvale Notes"] = "Highvale Notlarını yak" end
if A["Burn the Highvale Records"] == nil then A["Burn the Highvale Records"] = "Highvale Kayıtlarını yak" end
if A["Burn the Highvale Report"] == nil then A["Burn the Highvale Report"] = "Highvale Raporunu yak" end
if A["C.O.D."] == nil then A["C.O.D."] = "Ödemeli" end
if A["COD Amount:"] == nil then A["COD Amount:"] = "Ödemeli Tutar:" end
if A["Cache of Explosives Destroyed"] == nil then A["Cache of Explosives Destroyed"] = "Patlayıcı zulası yok edildi" end
if A["Can I teach you how to turn the meat you find on beasts into a feast?"] == nil then A["Can I teach you how to turn the meat you find on beasts into a feast?"] = "Hayvanlardan elde ettiğin eti nasıl bir ziyafete dönüştüreceğini sana öğreteyim mi?" end
if A["Capture Crown Guard Tower"] == nil then A["Capture Crown Guard Tower"] = "Crown Guard Tower'ı ele geçir" end
if A["Capture Eastwall Tower"] == nil then A["Capture Eastwall Tower"] = "Eastwall Tower'ı ele geçir" end
if A["Capture Northpass Tower"] == nil then A["Capture Northpass Tower"] = "Northpass Tower'ı ele geçir" end
if A["Capture Plaguewood Tower"] == nil then A["Capture Plaguewood Tower"] = "Plaguewood Tower'ı ele geçir" end
if A["Care to learn how to turn the ore that you find into weapons and metal armor?"] == nil then A["Care to learn how to turn the ore that you find into weapons and metal armor?"] = "Bulduğun cevheri silahlara ve metal zırhlara dönüştürmeyi öğrenmek ister misin?" end
if A["Check First Cage"] == nil then A["Check First Cage"] = "Birinci kafesi kontrol et" end
if A["Check Second Cage"] == nil then A["Check Second Cage"] = "İkinci kafesi kontrol et" end
if A["Check Third Cage"] == nil then A["Check Third Cage"] = "Üçüncü kafesi kontrol et" end
if A["Darrowshire Spirits Freed"] == nil then A["Darrowshire Spirits Freed"] = "Darrowshire ruhları özgürleştirildi" end
if A["Delete"] == nil then A["Delete"] = "Sil" end
if A["Deliver Silithyst"] == nil then A["Deliver Silithyst"] = "Silithyst teslim et" end
if A["Destroy the Demon Seed"] == nil then A["Destroy the Demon Seed"] = "İblis Tohumu'nu yok et" end
if A["Destroy the seal at the ancient flame"] == nil then A["Destroy the seal at the ancient flame"] = "Kadim alevdeki mührü yok et" end
if A["Development Skills"] == nil then A["Development Skills"] = "Gelişim Becerileri" end
if A["Eastern Tower Ablaze"] == nil then A["Eastern Tower Ablaze"] = "Doğu Kulesi alevler içinde" end
if A["Egg of Onyxia destroyed"] == nil then A["Egg of Onyxia destroyed"] = "Onyxia Yumurtası yok edildi" end
if A["Enchanting is the art of improving existing items through magic."] == nil then A["Enchanting is the art of improving existing items through magic."] = "Efsunculuk, var olan eşyaları büyü yoluyla geliştirme sanatıdır." end
if A["Engineering is very simple once you grasp the basics."] == nil then A["Engineering is very simple once you grasp the basics."] = "Temelleri kavradığında mühendislik çok basittir." end
if A["Expert Alchemist"] == nil then A["Expert Alchemist"] = "Uzman Simyacı" end
if A["Expert Blacksmith"] == nil then A["Expert Blacksmith"] = "Uzman Demirci" end
if A["Expert Cook"] == nil then A["Expert Cook"] = "Uzman Aşçı" end
if A["Expert Enchanter"] == nil then A["Expert Enchanter"] = "Uzman Efsuncu" end
if A["Expert Engineer"] == nil then A["Expert Engineer"] = "Uzman Mühendis" end
if A["Expert First Aid"] == nil then A["Expert First Aid"] = "Uzman İlk Yardım" end
if A["Expert Fisherman"] == nil then A["Expert Fisherman"] = "Uzman Balıkçı" end
if A["Expert Herbalist"] == nil then A["Expert Herbalist"] = "Uzman Bitkici" end
if A["Expert Leatherworker"] == nil then A["Expert Leatherworker"] = "Uzman Derici" end
if A["Expert Miner"] == nil then A["Expert Miner"] = "Uzman Madenci" end
if A["Expert Riding"] == nil then A["Expert Riding"] = "Uzman Binicilik" end
if A["Expert Skinner"] == nil then A["Expert Skinner"] = "Uzman Deri Yüzücü" end
if A["Expert Tailor"] == nil then A["Expert Tailor"] = "Uzman Terzi" end
if A["Extinguish the Brazier of Hatred"] == nil then A["Extinguish the Brazier of Hatred"] = "Nefret Mangalı'nı söndür" end
if A["Extinguish the Brazier of Malice"] == nil then A["Extinguish the Brazier of Malice"] = "Kin Mangalı'nı söndür" end
if A["Extinguish the Brazier of Pain"] == nil then A["Extinguish the Brazier of Pain"] = "Acı Mangalı'nı söndür" end
if A["Extinguish the Brazier of Suffering"] == nil then A["Extinguish the Brazier of Suffering"] = "Izdırap Mangalı'nı söndür" end
if A["Farm Assaulted"] == nil then A["Farm Assaulted"] = "Çiftliğe saldırıldı" end
if A["Find Mankrik's Wife"] == nil then A["Find Mankrik's Wife"] = "Mankrik'in karısını bul" end
if A["Find Metzen the Reindeer and rescue him"] == nil then A["Find Metzen the Reindeer and rescue him"] = "Ren geyiği Metzen'i bul ve kurtar" end
if A["Find evidence of the Scythe of Elune"] == nil then A["Find evidence of the Scythe of Elune"] = "Elune'un Tırpanı'na dair kanıt bul" end
if A["Find the hottest area of Fire Plume Ridge"] == nil then A["Find the hottest area of Fire Plume Ridge"] = "Fire Plume Ridge'in en sıcak bölgesini bul" end
if A["Flame of Azel charged"] == nil then A["Flame of Azel charged"] = "Azel Alevi yüklendi" end
if A["Flame of Blackrock Spire"] == nil then A["Flame of Blackrock Spire"] = "Blackrock Spire Alevi" end
if A["Flame of Dire Maul"] == nil then A["Flame of Dire Maul"] = "Dire Maul Alevi" end
if A["Flame of Stratholme"] == nil then A["Flame of Stratholme"] = "Stratholme Alevi" end
if A["Flame of Uzel charged"] == nil then A["Flame of Uzel charged"] = "Uzel Alevi yüklendi" end
if A["Flame of Veraz charged"] == nil then A["Flame of Veraz charged"] = "Veraz Alevi yüklendi" end
if A["Flame of the Scholomance"] == nil then A["Flame of the Scholomance"] = "Scholomance Alevi" end
if A["Frankal Questioned"] == nil then A["Frankal Questioned"] = "Frankal sorgulandı" end
if A["Free the Highborne soul in Night Run"] == nil then A["Free the Highborne soul in Night Run"] = "Night Run'daki Highborne ruhunu özgür bırak" end
if A["Free the Highborne soul in Satyrnaar"] == nil then A["Free the Highborne soul in Satyrnaar"] = "Satyrnaar'daki Highborne ruhunu özgür bırak" end
if A["From:"] == nil then A["From:"] = "Kimden:" end
if A["Gaea seed planted"] == nil then A["Gaea seed planted"] = "Gaea tohumu ekildi" end
if A["Gelkak's First Mate"] == nil then A["Gelkak's First Mate"] = "Gelkak'ın İkinci Kaptanı" end
if A["Gor'tesh Head Planted"] == nil then A["Gor'tesh Head Planted"] = "Gor'tesh'in kafası dikildi" end
if A["Graveyard Assaulted"] == nil then A["Graveyard Assaulted"] = "Mezarlığa saldırıldı" end
if A["Greetings! Can I teach you how to turn beast hides into armor?"] == nil then A["Greetings! Can I teach you how to turn beast hides into armor?"] = "Selamlar! Hayvan postlarını zırha dönüştürmeyi sana öğreteyim mi?" end
if A["Greetings! Can I teach you how to turn found cloth into cloth armor?"] == nil then A["Greetings! Can I teach you how to turn found cloth into cloth armor?"] = "Selamlar! Bulduğun kumaşları kumaş zırha dönüştürmeyi sana öğreteyim mi?" end
if A["Guse's Location Discovered"] == nil then A["Guse's Location Discovered"] = "Guse'un yeri keşfedildi" end
if A["Heal and fortify Deathguard Kel"] == nil then A["Heal and fortify Deathguard Kel"] = "Deathguard Kel'i iyileştir ve güçlendir" end
if A["Heal and fortify Grunt Kor'ja"] == nil then A["Heal and fortify Grunt Kor'ja"] = "Grunt Kor'ja'yı iyileştir ve güçlendir" end
if A["Heal and fortify Guard Roberts"] == nil then A["Heal and fortify Guard Roberts"] = "Guard Roberts'ı iyileştir ve güçlendir" end
if A["Heal and fortify Mountaineer Dolf"] == nil then A["Heal and fortify Mountaineer Dolf"] = "Mountaineer Dolf'u iyileştir ve güçlendir" end
if A["Heal and fortify Sentinel Shaya"] == nil then A["Heal and fortify Sentinel Shaya"] = "Sentinel Shaya'yı iyileştir ve güçlendir" end
if A["Hello! Can I teach you something?"] == nil then A["Hello! Can I teach you something?"] = "Merhaba! Sana bir şey öğreteyim mi?" end
if A["Hello, druid! Ready for some training?"] == nil then A["Hello, druid! Ready for some training?"] = "Merhaba, druid! Eğitime hazır mısın?" end
if A["Hello, hunter! Ready for some training?"] == nil then A["Hello, hunter! Ready for some training?"] = "Merhaba, hunter! Eğitime hazır mısın?" end
if A["Hello, mage! Ready for some training?"] == nil then A["Hello, mage! Ready for some training?"] = "Merhaba, mage! Eğitime hazır mısın?" end
if A["Hello, paladin! Ready for some training?"] == nil then A["Hello, paladin! Ready for some training?"] = "Merhaba, paladin! Eğitime hazır mısın?" end
if A["Hello, priest! Ready for some training?"] == nil then A["Hello, priest! Ready for some training?"] = "Merhaba, priest! Eğitime hazır mısın?" end
if A["Hello, rogue! Ready for some training?"] == nil then A["Hello, rogue! Ready for some training?"] = "Merhaba, rogue! Eğitime hazır mısın?" end
if A["Hello, shaman! Ready for some training?"] == nil then A["Hello, shaman! Ready for some training?"] = "Merhaba, shaman! Eğitime hazır mısın?" end
if A["Hello, warlock! Ready for some training?"] == nil then A["Hello, warlock! Ready for some training?"] = "Merhaba, warlock! Eğitime hazır mısın?" end
if A["Hello, warlock! Ready for some training?"] == nil then A["Hello, warlock! Ready for some training?"] = "Merhaba, warlock! Eğitime hazır mısın?" end
if A["Hello, warrior! Ready for some training?"] == nil then A["Hello, warrior! Ready for some training?"] = "Merhaba, warrior! Eğitime hazır mısın?" end
if A["Here, let me show you how to bind those wounds...."] == nil then A["Here, let me show you how to bind those wounds...."] = "Gel, o yaraları nasıl saracağını sana göstereyim...." end
if A["Hillsbrad Proclamation destroyed"] == nil then A["Hillsbrad Proclamation destroyed"] = "Hillsbrad Bildirisi yok edildi" end
if A["I can teach you how to use a fishing pole to catch fish."] == nil then A["I can teach you how to use a fishing pole to catch fish."] = "Balık tutmak için olta kullanmayı sana öğretebilirim." end
if A["Ichman's Location Discovered"] == nil then A["Ichman's Location Discovered"] = "Ichman'ın yeri keşfedildi" end
if A["Inbox"] == nil then A["Inbox"] = "Gelen Kutusu" end
if A["Information Recovered"] == nil then A["Information Recovered"] = "Bilgiler ele geçirildi" end
if A["It requires a steady hand to remove the leather from a slain beast."] == nil then A["It requires a steady hand to remove the leather from a slain beast."] = "Öldürülmüş bir hayvanın derisini yüzmek sağlam bir el ister." end
if A["Jeztor's Location Discovered"] == nil then A["Jeztor's Location Discovered"] = "Jeztor'un yeri keşfedildi" end
if A["Journeyman Alchemist"] == nil then A["Journeyman Alchemist"] = "Kalfa Simyacı" end
if A["Journeyman Blacksmith"] == nil then A["Journeyman Blacksmith"] = "Kalfa Demirci" end
if A["Journeyman Cook"] == nil then A["Journeyman Cook"] = "Kalfa Aşçı" end
if A["Journeyman Enchanter"] == nil then A["Journeyman Enchanter"] = "Kalfa Efsuncu" end
if A["Journeyman Engineer"] == nil then A["Journeyman Engineer"] = "Kalfa Mühendis" end
if A["Journeyman First Aid"] == nil then A["Journeyman First Aid"] = "Kalfa İlk Yardım" end
if A["Journeyman Fisherman"] == nil then A["Journeyman Fisherman"] = "Kalfa Balıkçı" end
if A["Journeyman Herbalist"] == nil then A["Journeyman Herbalist"] = "Kalfa Bitkici" end
if A["Journeyman Leatherworker"] == nil then A["Journeyman Leatherworker"] = "Kalfa Derici" end
if A["Journeyman Miner"] == nil then A["Journeyman Miner"] = "Kalfa Madenci" end
if A["Journeyman Riding"] == nil then A["Journeyman Riding"] = "Kalfa Binicilik" end
if A["Journeyman Skinner"] == nil then A["Journeyman Skinner"] = "Kalfa Deri Yüzücü" end
if A["Journeyman Tailor"] == nil then A["Journeyman Tailor"] = "Kalfa Terzi" end
if A["Ju-Ju Heaps Destroyed"] == nil then A["Ju-Ju Heaps Destroyed"] = "Ju-Ju yığınları yok edildi" end
if A["Kodos Tamed"] == nil then A["Kodos Tamed"] = "Kodolar evcilleştirildi" end
if A["Lumber Mill Assaulted"] == nil then A["Lumber Mill Assaulted"] = "Kereste Fabrikasına saldırıldı" end
if A["Lunar Fireworks Cluster Fired"] == nil then A["Lunar Fireworks Cluster Fired"] = "Ay Havai Fişek Demeti ateşlendi" end
if A["Lunar Fireworks Fired"] == nil then A["Lunar Fireworks Fired"] = "Ay Havai Fişeği ateşlendi" end
if A["Mine Assaulted"] == nil then A["Mine Assaulted"] = "Madene saldırıldı" end
if A["Mine Captured"] == nil then A["Mine Captured"] = "Maden ele geçirildi" end
if A["Mulverick's Location Discovered"] == nil then A["Mulverick's Location Discovered"] = "Mulverick'in yeri keşfedildi" end
if A["No Postage"] == nil then A["No Postage"] = "Posta Ücreti Yok" end
if A["Northern Tower Ablaze"] == nil then A["Northern Tower Ablaze"] = "Kuzey Kulesi alevler içinde" end
if A["Open Mail"] == nil then A["Open Mail"] = "Mektubu Aç" end
if A["Open Sharpbeak's Cage"] == nil then A["Open Sharpbeak's Cage"] = "Sharpbeak'in kafesini aç" end
if A["Parchment Created"] == nil then A["Parchment Created"] = "Parşömen oluşturuldu" end
if A["Peons Awoken"] == nil then A["Peons Awoken"] = "Peon'lar uyandırıldı" end
if A["Portals Banished"] == nil then A["Portals Banished"] = "Geçitler sürgün edildi" end
if A["Postage"] == nil then A["Postage"] = "Posta Ücreti" end
if A["Postage:"] == nil then A["Postage:"] = "Posta ücreti:" end
if A["Rabid Thistle Bear Captured"] == nil then A["Rabid Thistle Bear Captured"] = "Kuduz Thistle Ayısı yakalandı" end
if A["Rats Captured"] == nil then A["Rats Captured"] = "Sıçanlar yakalandı" end
if A["Read the Fall of Ameth'Aran"] == nil then A["Read the Fall of Ameth'Aran"] = "Ameth'Aran'ın Düşüşü'nü oku" end
if A["Read the Lay of Ameth'Aran"] == nil then A["Read the Lay of Ameth'Aran"] = "Ameth'Aran Destanı'nı oku" end
if A["Remains of Eva Sarkhoff Burned"] == nil then A["Remains of Eva Sarkhoff Burned"] = "Eva Sarkhoff'un kalıntıları yakıldı" end
if A["Remains of Lucien Sarkhoff Burned"] == nil then A["Remains of Lucien Sarkhoff Burned"] = "Lucien Sarkhoff'un kalıntıları yakıldı" end
if A["Reply"] == nil then A["Reply"] = "Yanıtla" end
if A["Rescue Drull"] == nil then A["Rescue Drull"] = "Drull'u kurtar" end
if A["Rescue Tog'thar"] == nil then A["Rescue Tog'thar"] = "Tog'thar'ı kurtar" end
if A["Return"] == nil then A["Return"] = "İade Et" end
if A["Return Silithyst"] == nil then A["Return Silithyst"] = "Silithyst teslim et" end
if A["Rite of Cunning"] == nil then A["Rite of Cunning"] = "Kurnazlık Ayini" end
if A["Rutgar Questioned"] == nil then A["Rutgar Questioned"] = "Rutgar sorgulandı" end
if A["Samuel's Remains Buried"] == nil then A["Samuel's Remains Buried"] = "Samuel'in kalıntıları gömüldü" end
if A["Scare Legacki"] == nil then A["Scare Legacki"] = "Legacki'yi korkut" end
if A["Scare Quixxil"] == nil then A["Scare Quixxil"] = "Quixxil'i korkut" end
if A["Scare Sprinkle"] == nil then A["Scare Sprinkle"] = "Sprinkle'ı korkut" end
if A["Scourge Structures Destroyed"] == nil then A["Scourge Structures Destroyed"] = "Scourge yapıları yok edildi" end
if A["Screecher Spirits Collected"] == nil then A["Screecher Spirits Collected"] = "Screecher ruhları toplandı" end
if A["Searching for herbs requires both knowledge and instinct."] == nil then A["Searching for herbs requires both knowledge and instinct."] = "Bitki aramak hem bilgi hem de sezgi gerektirir." end
if A["Send Mail"] == nil then A["Send Mail"] = "Mektup Gönder" end
if A["Send Money"] == nil then A["Send Money"] = "Para Gönder" end
if A["Servants of Allistarj Freed"] == nil then A["Servants of Allistarj Freed"] = "Allistarj'ın hizmetkârları özgürleştirildi" end
if A["Servants of Grol Freed"] == nil then A["Servants of Grol Freed"] = "Grol'un hizmetkârları özgürleştirildi" end
if A["Servants of Razelikh Freed"] == nil then A["Servants of Razelikh Freed"] = "Razelikh'in hizmetkârları özgürleştirildi" end
if A["Servants of Sevine Freed"] == nil then A["Servants of Sevine Freed"] = "Sevine'in hizmetkârları özgürleştirildi" end
if A["Shut off Fuel Control Valve"] == nil then A["Shut off Fuel Control Valve"] = "Yakıt Kontrol Vanasını kapat" end
if A["Shut off Main Control Valve"] == nil then A["Shut off Main Control Valve"] = "Ana Kontrol Vanasını kapat" end
if A["Shut off Regulator Valve"] == nil then A["Shut off Regulator Valve"] = "Regülatör Vanasını kapat" end
if A["Sickly Deer cured"] == nil then A["Sickly Deer cured"] = "Hasta geyik iyileştirildi" end
if A["Sickly Gazelle cured"] == nil then A["Sickly Gazelle cured"] = "Hasta ceylan iyileştirildi" end
if A["Slidore's Location Discovered"] == nil then A["Slidore's Location Discovered"] = "Slidore'un yeri keşfedildi" end
if A["Souls Freed"] == nil then A["Souls Freed"] = "Ruhlar özgürleştirildi" end
if A["Southern Tower Ablaze"] == nil then A["Southern Tower Ablaze"] = "Güney Kulesi alevler içinde" end
if A["Stable Assaulted"] == nil then A["Stable Assaulted"] = "Ahıra saldırıldı" end
if A["Subject:"] == nil then A["Subject:"] = "Konu:" end
if A["Take Attachment"] == nil then A["Take Attachment"] = "Eki Al" end
if A["Tears Destroyed"] == nil then A["Tears Destroyed"] = "Gözyaşları yok edildi" end
if A["Test the Dried Seeds"] == nil then A["Test the Dried Seeds"] = "Kurutulmuş tohumları dene" end
if A["The Fate of Mistress Natalia Mar'alith"] == nil then A["The Fate of Mistress Natalia Mar'alith"] = "Leydi Natalia Mar'alith'in Akıbeti" end
if A["Theldren's Team Defeated"] == nil then A["Theldren's Team Defeated"] = "Theldren'in takımı yenildi" end
if A["There is no treat finer than Barbecued Buzzard Wing."] == nil then A["There is no treat finer than Barbecued Buzzard Wing."] = "Izgara Akbaba Kanadı'ndan daha güzel bir lezzet yoktur." end
if A["To:"] == nil then A["To:"] = "Kime:" end
if A["Toss Stink Bomb into Southshore"] == nil then A["Toss Stink Bomb into Southshore"] = "Southshore'a Pis Koku Bombası at" end
if A["Tower Captured"] == nil then A["Tower Captured"] = "Kule ele geçirildi" end
if A["Tower Four marked"] == nil then A["Tower Four marked"] = "Dördüncü Kule işaretlendi" end
if A["Tower One marked"] == nil then A["Tower One marked"] = "Birinci Kule işaretlendi" end
if A["Tower Three marked"] == nil then A["Tower Three marked"] = "Üçüncü Kule işaretlendi" end
if A["Tower Two marked"] == nil then A["Tower Two marked"] = "İkinci Kule işaretlendi" end
if A["View the Tome of Mel'Thandris"] == nil then A["View the Tome of Mel'Thandris"] = "Mel'Thandris'in Kitabı'nı incele" end
if A["Vipore's Location Discovered"] == nil then A["Vipore's Location Discovered"] = "Vipore'un yeri keşfedildi" end
if A["Visit Blue Raptor Nest"] == nil then A["Visit Blue Raptor Nest"] = "Mavi Raptor Yuvasını ziyaret et" end
if A["Visit Red Raptor Nest"] == nil then A["Visit Red Raptor Nest"] = "Kırmızı Raptor Yuvasını ziyaret et" end
if A["Visit Yellow Raptor Nest"] == nil then A["Visit Yellow Raptor Nest"] = "Sarı Raptor Yuvasını ziyaret et" end
if A["Vylestem Vines healed"] == nil then A["Vylestem Vines healed"] = "Vylestem sarmaşıkları iyileştirildi" end
if A["Welcome!"] == nil then A["Welcome!"] = "Hoş geldin!" end
if A["Western Tower Ablaze"] == nil then A["Western Tower Ablaze"] = "Batı Kulesi alevler içinde" end
if A["Who Does Number Two Work For?"] == nil then A["Who Does Number Two Work For?"] = "İki Numara kimin için çalışıyor?" end
if A["With alchemy you can turn found herbs into healing and other types of potions."] == nil then A["With alchemy you can turn found herbs into healing and other types of potions."] = "Simya ile bulduğun bitkileri şifa iksirlerine ve diğer türde iksirlere dönüştürebilirsin." end
if A["Writ of Safe Passage Signed"] == nil then A["Writ of Safe Passage Signed"] = "Güvenli Geçiş Belgesi imzalandı" end
if A["You have not lived until you have dug deep into the earth."] == nil then A["You have not lived until you have dug deep into the earth."] = "Toprağın derinliklerine kazmadıysan yaşamış sayılmazsın." end
if A["Ysida Freed"] == nil then A["Ysida Freed"] = "Ysida özgür bırakıldı" end
-- Satıcı ve Savaş Grubu kampı ipuçları
local function ek2(k, v) if A[k] == nil then A[k] = v end end
ek2("<Shift click to buy a different amount>", "<Farklı miktar almak için Shift ile tıkla>")
ek2("<Shift-click to buy a different amount>", "<Farklı miktar almak için Shift ile tıkla>")
ek2("<Shift Click to buy a different amount>", "<Farklı miktar almak için Shift ile tıkla>")
ek2("Unlock", "Açılma Şartı")
ek2("Unlock:", "Açılma Şartı:")
ek2("Warband Campsite", "Warband Kamp Alanı")
ek2("Progress Season 2 Delver's Journey", "Delver'ın Yolculuğu Sezon 2'de ilerle")
WoWTurkce.EtiketTr = WoWTurkce.EtiketTr or {}
WoWTurkce.EtiketTr["Unlock"] = "Açılma Şartı"
