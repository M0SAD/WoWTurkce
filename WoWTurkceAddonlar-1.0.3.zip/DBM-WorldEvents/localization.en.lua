local L

------------
--  Omen  --
------------
L = DBM:GetModLocalization("Omen")

L:SetGeneralLocalization({
	name = "Omen"
})

------------------------------
--  The Crown Chemical Co.  --
------------------------------
L = DBM:GetModLocalization("d288")

L:SetTimerLocalization{
	HummelActive		= "Hummel etkinleşiyor",
	BaxterActive		= "Baxter etkinleşiyor",
	FryeActive			= "Frye etkinleşiyor"
}

L:SetOptionLocalization({
	TrioActiveTimer		= "Apothecary Trio'nun etkinleşme zamanlayıcılarını göster"
})

L:SetMiscLocalization({
	SayCombatStart		= "Did they bother to tell you who I am and why I am doing this?"
})

----------------------------
--  The Frost Lord Ahune  --
----------------------------
L = DBM:GetModLocalization("d286")

L:SetWarningLocalization({
	Emerged			= "Yüzeye çıktı",
	specWarnAttack	= "Ahune savunmasız - Şimdi saldır!"
})

L:SetTimerLocalization{
	SubmergeTimer	= "Dalış",
	EmergeTimer		= "Yüzeye çıkış"
}

L:SetOptionLocalization({
	Emerged			= "Ahune yüzeye çıkınca uyarı göster",
	specWarnAttack	= "Ahune savunmasız kalınca özel uyarı göster",
	SubmergeTimer	= "Dalış için zamanlayıcı göster",
	EmergeTimer		= "Yüzeye çıkış için zamanlayıcı göster"
})

L:SetMiscLocalization({
	Pull			= "The Ice Stone has melted!"
})

----------------------
--  Coren Direbrew  --
----------------------
L = DBM:GetModLocalization("d287")

L:SetWarningLocalization({
	specWarnBrew		= "Sana bir tane daha atmadan biradan kurtul!",
	specWarnBrewStun	= "İPUCU: Kafana yedin, bir dahaki sefere birayı içmeyi unutma!"
})

L:SetOptionLocalization({
	specWarnBrew		= "$spell:47376 için özel uyarı göster",
	specWarnBrewStun	= "$spell:47340 için özel uyarı göster"
})

L:SetMiscLocalization({
	YellBarrel			= "Barrel on me!"
})

----------------
--  Brewfest  --
----------------
L = DBM:GetModLocalization("Brew")

L:SetGeneralLocalization({
	name = "Brewfest"
})

L:SetOptionLocalization({
	NormalizeVolume			= "Brewfest bölgesindeyken DİYALOG ses kanalının seviyesini müzik kanalının seviyesine otomatik eşitle, böylece rahatsız edici derecede yüksek olmaz. (Müzik ses seviyesi ayarlı değilse ses kapatılır.)"
})

-----------------------------
--  The Headless Horseman  --
-----------------------------
L = DBM:GetModLocalization("d285")

L:SetGeneralLocalization({
	name = "The Headless Horseman"
})

L:SetWarningLocalization({
	WarnPhase				= "Aşama %d",
	warnHorsemanSoldiers	= "Pulsing Pumpkin'ler beliriyor",
	warnHorsemanHead		= "Head of the Horseman etkin"
})

L:SetOptionLocalization({
	WarnPhase				= "Her aşama değişiminde uyarı göster",
	warnHorsemanSoldiers	= "Pulsing Pumpkin belirince uyarı göster",
	warnHorsemanHead		= "Head of the Horseman belirince uyarı göster"
})

L:SetMiscLocalization({
	HorsemanSummon			= "Horseman rise...",
	HorsemanSoldiers		= "Soldiers arise, stand and fight! Bring victory at last to this fallen knight!"
})

------------------------------
--  The Abominable Greench  --
------------------------------
L = DBM:GetModLocalization("Greench")

L:SetGeneralLocalization({
	name = "The Abominable Greench"
})

--------------------------
--  Plants Vs. Zombies  --
--------------------------
L = DBM:GetModLocalization("PlantsVsZombies")

L:SetGeneralLocalization({
	name = "Plants Vs. Zombies"
})

L:SetWarningLocalization({
	warnTotalAdds	= "Son büyük dalgadan beri beliren toplam zombi: %d",
	specWarnWave	= "Büyük Dalga!"
})

L:SetTimerLocalization{
	timerWave		= "Sonraki Büyük Dalga"
}

L:SetOptionLocalization({
	warnTotalAdds	= "Her büyük dalga arasında beliren toplam ek yaratık sayısını duyur",
	specWarnWave	= "Büyük Dalga başlayınca özel uyarı göster",
	timerWave		= "Sonraki Büyük Dalga için zamanlayıcı göster"
})

L:SetMiscLocalization({
	MassiveWave		= "A Massive Wave of Zombies is Approaching!"
})

-- Quest
L = DBM:GetModLocalization("EscortQuests")

L:SetGeneralLocalization{
	name = "Eskort Görevleri",
}

L:SetOptionLocalization{
	Timers = "Bazı eskort görevleri için zamanlayıcı göster"
}

--------------------------
--  Demonic Invasions  --
--------------------------
L = DBM:GetModLocalization("DemonInvasions")

L:SetGeneralLocalization({
	name = "İblis İstilaları"
})

--------------------------
--  Memories of Azeroth: Burning Crusade  --
--------------------------
L = DBM:GetModLocalization("BCEvent")

L:SetGeneralLocalization({
	name = "MoA: Burning Crusade"
})

--------------------------
--  Memories of Azeroth: Wrath of the Lich King  --
--------------------------
L = DBM:GetModLocalization("WrathEvent")

L:SetGeneralLocalization({
	name = "MoA: WotLK"
})

L:SetWarningLocalization{
	WarnEmerge				= "Anub'arak yüzeye çıkıyor",
	WarnEmergeSoon			= "10 saniye içinde yüzeye çıkış",
	WarnSubmerge			= "Anub'arak dalıyor",
	WarnSubmergeSoon		= "10 saniye içinde dalış",
	WarningTeleportNow		= "Işınlandı",
	WarningTeleportSoon		= "10 saniye içinde ışınlanma"
}

L:SetTimerLocalization{
	TimerEmerge				= "Yüzeye çıkış",
	TimerSubmerge			= "Dalış",
	TimerTeleport			= "Işınlanma"
}

L:SetMiscLocalization{
	Emerge					= "emerges from the ground!",
	Burrow					= "burrows into the ground!"
}

L:SetOptionLocalization{
	WarnEmerge				= "Yüzeye çıkış için uyarı göster",
	WarnEmergeSoon			= "Yüzeye çıkış için ön uyarı göster",
	WarnSubmerge			= "Dalış için uyarı göster",
	WarnSubmergeSoon		= "Dalış için ön uyarı göster",
	TimerEmerge				= "Yüzeye çıkış için zamanlayıcı göster",
	TimerSubmerge			= "Dalış için zamanlayıcı göster",
	WarningTeleportNow		= "Işınlanma için uyarı göster",
	WarningTeleportSoon		= "Işınlanma için ön uyarı göster",
	TimerTeleport			= "Işınlanma için zamanlayıcı göster"
}

--------------------------
--  Memories of Azeroth: Cataclysm  --
--------------------------
L = DBM:GetModLocalization("CataEvent")

L:SetGeneralLocalization({
	name = "MoA: Cataclysm"
})

L:SetWarningLocalization({
	warnSplittingBlow		= "%s: %s",--Spellname in Location
	warnEngulfingFlame		= "%s: %s"--Spellname in Location
})

L:SetOptionLocalization({
	warnSplittingBlow			= "$spell:98951 için konum uyarılarını göster",
	warnEngulfingFlame			= "$spell:99171 için konum uyarılarını göster"
})

----------------------------------
--  Azeroth Event World Bosses  --
----------------------------------

-- Lord Kazzak (Badlands)
L = DBM:GetModLocalization("KazzakClassic")

L:SetGeneralLocalization{
	name = "Lord Kazzak"
}

L:SetMiscLocalization({
	Pull		= "For the Legion! For Kil'Jaeden!"
})

-- Azuregos (Azshara)
L = DBM:GetModLocalization("Azuregos")

L:SetGeneralLocalization{
	name = "Azuregos"
}

L:SetMiscLocalization({
	Pull		= "This place is under my protection. The mysteries of the arcane shall remain inviolate."
})

-- Taerar (Ashenvale)
L = DBM:GetModLocalization("Taerar")

L:SetGeneralLocalization{
	name = "Taerar"
}

L:SetMiscLocalization({
	Pull		= "Peace is but a fleeting dream! Let the NIGHTMARE reign!"
})

-- Ysondre (Feralas)
L = DBM:GetModLocalization("Ysondre")

L:SetGeneralLocalization{
	name = "Ysondre"
}

L:SetMiscLocalization({
	Pull		= "The strands of LIFE have been severed! The Dreamers must be avenged!"
})

-- Lethon (Hinterlands)
L = DBM:GetModLocalization("Lethon")

L:SetGeneralLocalization{
	name = "Lethon"
}

L:SetMiscLocalization({
--	Pull		= "The strands of LIFE have been severed! The Dreamers must be avenged!"--Does not have one :\
})

-- Emeriss (Duskwood)
L = DBM:GetModLocalization("Emeriss")

L:SetGeneralLocalization{
	name = "Emeriss"
}

L:SetMiscLocalization({
	Pull		= "Hope is a DISEASE of the soul! This land shall wither and die!"
})

-- Doomwalker (Tanaris)
L = DBM:GetModLocalization("DoomwalkerEvent")

L:SetGeneralLocalization{
	name = "Doomwalker (Etkinlik)"
}

-- Archavon (???)
L = DBM:GetModLocalization("ArchavonEvent")

L:SetGeneralLocalization{
	name = "Archavon (Etkinlik)"
}

-- Sha of Anger (???)
L = DBM:GetModLocalization("ShaofAngerEvent")

L:SetGeneralLocalization{
	name = "Sha of Anger (Etkinlik)"
}

--------------------------
--  Blastenheimer 5000  --
--------------------------
L = DBM:GetModLocalization("Cannon")

L:SetGeneralLocalization({
	name = "Blastenheimer 5000"
})

L = DBM:GetModLocalization("CannonClassic")

L:SetGeneralLocalization({
	name = "Blastenheimer 5000"
})

-------------
--  Gnoll  --
-------------
L = DBM:GetModLocalization("Gnoll")

L:SetGeneralLocalization({
	name = "Whack-a-Gnoll"
})

L:SetWarningLocalization({
	warnGameOverQuest	= "Beliren olası puanlardan %d / %d kazanıldı",
	warnGameOverNoQuest	= "Oyun toplam %d olası puanla bitti",
	warnGnoll			= "Gnoll belirdi",
	warnHogger			= "Hogger belirdi",
	specWarnHogger		= "Hogger belirdi!"
})

L:SetOptionLocalization({
	warnGameOver	= "Oyun bitince toplam olası puanı duyur",
	warnGnoll		= "Gnoll belirince duyur",
	warnHogger		= "Hogger belirince duyur",
	specWarnHogger	= "Hogger belirince özel uyarı göster"
})

------------------------
--  Shooting Gallery  --
------------------------
L = DBM:GetModLocalization("Shot")

L:SetGeneralLocalization({
	name = "Shooting Gallery"
})

L:SetOptionLocalization({
	SetBubbles			= "$spell:101871 sırasında sohbet balonlarını otomatik kapat<br/>(oyun bitince geri açar)"
})

----------------------
--  Tonk Challenge  --
----------------------
L = DBM:GetModLocalization("Tonks")

L:SetGeneralLocalization({
	name = "Tonk Challenge"
})

---------------------------
--  Fire Ring Challenge  --
---------------------------
L = DBM:GetModLocalization("Rings")

L:SetGeneralLocalization({
	name = "Fire Ring Challenge"
})

-----------------------
--  Darkmoon Rabbit  --
-----------------------
L = DBM:GetModLocalization("Rabbit")

L:SetGeneralLocalization({
	name = "Darkmoon Rabbit"
})

-------------------------
--  Darkmoon Moonfang  --
-------------------------
L = DBM:GetModLocalization("Moonfang")

L:SetGeneralLocalization({
	name = "Moonfang"
})

L:SetWarningLocalization({
	specWarnCallPack		= "Call the Pack - Moonfang'den 40 metreden fazla uzaklaş!",
	specWarnMoonfangCurse	= "Moonfang's Curse - Moonfang'den 10 metreden fazla uzaklaş!"
})

L:SetOptionLocalization({
	specWarnCallPack		= DBM_CORE_L.AUTO_SPEC_WARN_OPTIONS.run:format(144602),
	specWarnMoonfangCurse	= DBM_CORE_L.AUTO_SPEC_WARN_OPTIONS.run:format(144590)
})
