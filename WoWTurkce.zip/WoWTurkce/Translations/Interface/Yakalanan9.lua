-- Cihaz kaydı (5. batch). Mevcut çevirileri ezmez.
local G = WoWTurkce
local function ekle(t, k, v) if t and t[k] == nil then t[k] = v end end
local A = G.Arayuz
local SZ = G.Soz or {}; G.Soz = SZ
ekle(A, "Kullan:  (# dk Cooldown)", "Kullan: ({1} dk bekleme süresi)")
ekle(A, "   Kullan:  (# dk Cooldown)", "Kullan: ({1} dk bekleme süresi)")
ekle(A, "Yenilenmesi Ruh ile artar", "Yenilenme hızı Ruh ile artar")
ekle(A, "   Yenilenmesi Ruh ile artar", "Yenilenme hızı Ruh ile artar")
ekle(A, "Senin gibi bir priest ile harcayacak vaktim yok.", "Senin gibi bir priest ile harcayacak vaktim yok.")
ekle(A, "   Senin gibi bir priest ile harcayacak vaktim yok.", "Senin gibi bir priest ile harcayacak vaktim yok.")
ekle(A, "Apothecary Johaan of the town of Brill needs # Vile Fin Scales from Murlocs in Tirisfal Glades.", "Brill kasabasındaki Apothecary Johaan, Tirisfal Glades'teki Murloc'lardan {1} Vile Fin Scale istiyor.")
ekle(A, "   Apothecary Johaan of the town of Brill needs # Vile Fin Scales from Murlocs in Tirisfal Glades.", "Brill kasabasındaki Apothecary Johaan, Tirisfal Glades'teki Murloc'lardan {1} Vile Fin Scale istiyor.")
ekle(A, "Nice to see a friendly face. I don't get much chitchat from Apothecary Johaan unless he wants something. He's been out of the grave too long. Someday I'll be like that, I hear. Creepy. Maybe by then I won't care.", "Dost bir yüz görmek ne güzel. Apothecary Johaan benimle bir şey istemedikçe pek sohbet etmez. Mezardan çıkalı çok olmuş. Duyduğuma göre bir gün ben de onun gibi olacağım. Ürpertici. Belki o zamana kadar umurumda olmaz.")
ekle(A, "   Nice to see a friendly face. I don't get much chitchat from Apothecary Johaan unless he wants something. He's been out of the grave too long. Someday I'll be like that, I hear. Creepy. Maybe by then I won't care.", "Dost bir yüz görmek ne güzel. Apothecary Johaan benimle bir şey istemedikçe pek sohbet etmez. Mezardan çıkalı çok olmuş. Duyduğuma göre bir gün ben de onun gibi olacağım. Ürpertici. Belki o zamana kadar umurumda olmaz.")
ekle(A, "Imagine the blow we could deal to the morale of those bloody zealots if we were to kill their leaders in one swift strike.", "Şu kanlı fanatiklerin liderlerini tek hamlede öldürebilsek, moralleri üzerinde nasıl bir darbe vurabileceğimizi bir düşün.")
ekle(A, "   Imagine the blow we could deal to the morale of those bloody zealots if we were to kill their leaders in one swift strike.", "Şu kanlı fanatiklerin liderlerini tek hamlede öldürebilsek, moralleri üzerinde nasıl bir darbe vurabileceğimizi bir düşün.")
ekle(A, "Thursday, November #, # at #:# You Completed the quest Lanetliler", "Perşembe, {1} Kasım {2}, {3}:{4} Tamamlanan görev: Lanetliler")
ekle(A, "   Thursday, November #, # at #:# You Completed the quest Lanetliler", "Perşembe, {1} Kasım {2}, {3}:{4} Tamamlanan görev: Lanetliler")
ekle(A, "#/# Wretched Zombie slain", "{1}/{2} Wretched Zombie öldürüldü")
ekle(A, "   #/# Wretched Zombie slain", "{1}/{2} Wretched Zombie öldürüldü")
ekle(A, "#/# Mindless Zombie slain", "{1}/{2} Mindless Zombie öldürüldü")
ekle(A, "   #/# Mindless Zombie slain", "{1}/{2} Mindless Zombie öldürüldü")
ekle(SZ, 2365600269, "Tam da ihtiyacım olan buydu.")
ekle(SZ, 3775144549, "Çabalarımı ikiye katlayacağım.")
ekle(A, "Campfire Nearby", "Yakındaki Kamp Ateşi |cffaaaaaa(Campfire Nearby)|r")
do
	local B, BA = G.Buyu, G.BuyuAdi
	local d = "Grants various camp benefits after # min spent sitting near the campfire, based on what additional camp objects are placed near the campfire."
	local t = "Kamp ateşinin yanında {1} dk oturduktan sonra, kamp ateşinin yanına başka hangi kamp eşyaları konduğuna bağlı olarak çeşitli kamp avantajları verir."
	ekle(B, d, t); ekle(A, d, t); ekle(G.Esya, d, t)
	local tt = "Yakındaki Kamp Ateşi |cffaaaaaa(Campfire Nearby)|r"
	ekle(BA, "Campfire Nearby", "Yakında Kamp Ateşi Var")
	ekle(BA, "Welcoming Campfire", "Davetkâr Kamp Ateşi")
	ekle(A, "Welcoming Campfire", "Davetkâr Kamp Ateşi |cffaaaaaa(Welcoming Campfire)|r")
end
ekle(G.Konusma, 2005861292, "Scarlet Crusade anayurdumuza saldırıyor. Aptal fanatikler, Kara Leydi'nin sadık hizmetkârlarının onların sonunu getireceğini fark etmiyor.")
ekle(G.Soz, 2005861292, "Scarlet Crusade anayurdumuza saldırıyor. Aptal fanatikler, Kara Leydi'nin sadık hizmetkârlarının onların sonunu getireceğini fark etmiyor.")
ekle(G.Arayuz, "Sende # friend request. var", "Sende {1} arkadaşlık isteği var.")
