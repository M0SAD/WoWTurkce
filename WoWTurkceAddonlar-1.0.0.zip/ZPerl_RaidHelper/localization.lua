XPERL_MSG_PREFIX	= "|c00C05050X-Perl|r "

XPERL_TOOLTIP_ASSISTING	= "Yardım Eden Oyuncular:"
XPERL_TOOLTIP_HEALERS	= "Beni Hedefleyen Şifacılar:"
XPERL_TOOLTIP_ALLONME	= "Beni Hedefleyen Herkes:"
XPERL_TOOLTIP_ENEMYONME	= "Beni Hedefleyen Düşmanlar:"
XPERL_TOOLTIP_HELP	= "Canlı görünümü açmak için tıklayın"
XPERL_TOOLTIP_PET	= "%s adlı oyuncunun evcil hayvanı"

XPERL_LOC_DEAD		= "Ölü"

XPERL_BUTTON_TOGGLE_LABELS	= "Hedef Etiketlerini Göster/Gizle"
XPERL_BUTTON_TOGGLE_MTTARGETS	= "MT hedeflerinin hedefini göster/gizle"
XPERL_BUTTON_TOGGLE_SHOWMT	= "Ana Tankı göster/gizle"
XPERL_BUTTON_HELPER_PIN		= "Pencereyi Sabitle"

XPERL_XS_TARGET			= "%s adlı oyuncunun hedefi"
XPERL_NO_TARGET			= "hedef yok"

XPERL_TITLE_MT_LONG		= "MT Hedefleri"
XPERL_TITLE_MT_SHORT		= "MT"
XPERL_TITLE_WARRIOR_LONG	= "Warrior Hedefleri"
XPERL_TITLE_WARRIOR_SHORT	= "Tanklar"

XPERL_HELPER_NEEDPROMOTE	= "Ana Yardımcıyı belirlemek için yetki verilmiş olmalısınız"
XPERL_HELPER_MASET		= "Ana Yardımcı %s olarak ayarlandı"
XPERL_HELPER_MACLEAR		= "Ana Yardımcı |c00FF0000temizlendi!"
XPERL_HELPER_MAREMOVED		= "Ana Yardımcı %s tank listesinde bulunamadı - kaldırıldı!"
XPERL_HELPER_MAREMOTESET	= "%s, Ana Yardımcı olarak %s oyuncusunu atadı"

XPERL_HELPER_FINDFOUND		= "FIND ile uygun hedef bulundu. (Temizlemek için '|c00007F00/xp find|r')."
XPERL_HELPER_FINDCLEARED	= "Find |c00FF0000temizlendi!|r"
XPERL_HELPER_FINDSET		= "Find %s olarak ayarlandı. (Temizlemek için '|c00007F00/xp find|r')."

XPERL_AGGRO_PLAYER		= "- TEHDİT -"
XPERL_AGGRO_PET			= "- EVCİL HAYVAN TEHDİDİ -"
XPERL_AGGRO_DRAGTIP		= "Tehdit uyarısının konumunu taşı"
