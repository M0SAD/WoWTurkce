local Loc = LibStub("AceLocale-3.0"):NewLocale("Details_Threat", "enUS", true) 

if (not Loc) then
	return 
end 

Loc ["STRING_PLUGIN_NAME"] = "Tiny Threat"

Loc ["STRING_SLASH_ANIMATE"] = "animate"
Loc ["STRING_SLASH_SPEED"] = "speed"
Loc ["STRING_SLASH_AMOUNT"] = "amount"

Loc ["STRING_COMMAND_LIST"] = "Kullanılabilir Komutlar:"
Loc ["STRING_SLASH_SPEED_DESC"] = "Pencerenin güncellenme sıklığını (saniye) değiştirir, 0.1 ile 3.0 arası değerler alır"
Loc ["STRING_SLASH_SPEED_CHANGED"] = "Güncelleme Hızı şuna değişti: "
Loc ["STRING_SLASH_SPEED_CURRENT"] = "Güncelleme Hızının şu anki değeri: "
