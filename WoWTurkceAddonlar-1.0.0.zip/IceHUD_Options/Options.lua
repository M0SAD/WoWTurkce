---@diagnostic disable: undefined-field
local LibDualSpec = LibStub('LibDualSpec-1.0', true)
local L = LibStub("AceLocale-3.0"):GetLocale("IceHUD", false)
local icon = LibStub("LibDBIcon-1.0", true)
local AceGUI = LibStub("AceGUI-3.0")
local AceSerializer = LibStub("AceSerializer-3.0", true)
local lastCustomModule = IceHUD.IsSecretEnv() and "Health" or "Bar"

IceHUD_Options = {}

local options =
{
	type = 'group',
	name = L["IceHUD"],
	desc = L["IceHUD"],
	icon = "Interface\\Icons\\Spell_Frost_Frost",
	args =
	{
		headerGeneral = {
			type = 'header',
			name = L["General Settings"],
			order = 10
		},

		faq = {
			type = 'group',
			name = L["FAQs"],
			desc = L["Answers to questions that are frequently asked."],
			order = 1,
			args = {
				test = {
					type = 'description',
					fontSize = "medium",
					name = [[|cff9999ffIceHUD|r kullandığınız için teşekkürler! Aşağıda en sık sorulan soruların yanıtlarını bulabilirsiniz. Daha fazla tartışma ve güncelleme için eklentinin |cff33ff99GitHub|r ve |cff33ff99curseforge.com|r sayfalarına da göz atmayı unutmayın! İsterseniz doğrudan |cff33ff99icehud@parnic.com|r adresine de e-posta gönderebilirsiniz.

|cff9999ffWoW Midnight Hakkında Bir Not|r
Midnight genişleme paketiyle gelen 12.0 yaması, eklentilerin oyunda çalışma biçiminde büyük ve kapsamlı değişiklikler yaptı. Bu yüzden daha önce mevcut olan birçok özelliğe artık oyun izin vermiyor. IceHUD eskiden yaptığı bir şeyi artık yapmıyorsa, en olası neden yeni yamada bunun mümkün olmaması (veya çok daha zor olması). Bulduğunuz hatalar için GitHub'da bir kayıt açmaktan çekinmeyin; gereken değişikliklerin kapsamı nedeniyle bir süre bazı hatalar olması bekleniyor.

|cff42ffffFractional:Short|r kullanan özel |cff42ffffDogTags|r etiketleriniz varsa Midnight'ta artık çalışmayacak. Düşük Eşik yanıp sönmesi veya savaş içi güçlendirme/zayıflatma takibi gibi düşman canına veya güçlendirmelere bağlı diğer birçok özelliğe de artık oyun izin vermiyor.

|cff9999ff1. Varsayılan Blizzard oyuncu ve hedef birim çerçevelerini nasıl gizlerim?|r
"|cffffdc42Modül Ayarları|r" bölümünü genişletin, "PlayerHealth" veya "TargetHealth" seçin ve "Blizzard Çerçevesini Gizle" kutusunu işaretleyin.

|cff9999ff2. Oyuncu çubuğunda tıklayarak hedeflemeyi ve menüleri nasıl kapatırım?|r
"|cffffdc42Modül Ayarları|r" bölümünü genişletin, "PlayerHealth" seçin ve "Tıklayarak hedeflemeye izin ver" işaretini kaldırın. v1.3'ten beri savaş dışında tıklayarak hedeflemeye izin verip savaşta kapatan bir seçenek de var.

|cff9999ff3. HUD'u savaşa, hedeflemeye vb. göre nasıl gizler veya saydamlığını değiştiririm?|r
"Saydamlık Ayarları" bölümüne bakın. Neredeyse her durum birleşimi ayarlanabilir.

|cff9999ff4. HUD'un geri kalanı saydam olsa bile can yüzdeleri görünüyor. Neden?|r
"|cffffdc42Modül Ayarları|r" bölümünü genişletin, "PlayerHealth" genişletin, "Metin Ayarları"na tıklayın ve alt/üst metin bloklarının saydamlığını kilitlemeyle ilgili seçeneklere bakın. Metnin saydamlığı kilitliyse %100'ün altına düşmez, değilse çubuğunun saydamlık ayarına uyar. PlayerHealth/Mana, TargetHealth/Mana ve evcil hayvan çubuklarında bu seçenekler bulunur.

|cff9999ff5. Rogue ve Druid'ler için kombo puanlarını veya Warrior'lar için sunder uygulamalarını görmenin bir yolu var mı?|r
Evet, ayar panelindeki "ComboPoints" ve "Sunders" modüllerine bakın. (Bu modüller, onları görecek uygun sınıfta değilseniz görünmeyebilir. İlgili sınıflarda bulunurlar.)

|cff9999ff6. Oyuncunun büyü çubuğunun üstündeki bu şey ne? Çubuğun geri kalanından daha koyu.|r
Bu, Büyü Gecikmesi Göstergesidir; mevcut büyüyü yine bitirebilecekken (sunucuya olan gecikmenize göre) yeni bir büyüye ne zaman başlayabileceğinizi gösterir. Player Cast Bar modül ayarlarından kapatabilirsiniz.

|cff9999ff7. Su altında nefesi gösteren bir çubuk var mı, varsa nasıl ayarlarım?|r
Evet, |cffffdc42Modül Ayarları|r içinde adı MirrorBarHandler. Bu adı almasının nedeni büyü çubuğu davranışını taklit etmesi, nefesten fazlasını (örneğin yorgunluk) göstermesi ve Blizzard'ın da ona böyle demesi. Diğer modüller gibi taşınabilir/ayarlanabilir/boyutlandırılabilir.

|cff9999ff8. Bazen her şeyin altında uzun yeşil bir çubuk çıkıyor. Bu ne?|r
Bu TargetOfTarget modülü. Bu modül, tam ToT can/mana çubuklarını istemeyen ama ekranda bir çeşit ToT göstergesi isteyenler içindir.

|cff9999ff9. IceHUD'un X güçlendirmesi/zayıflatması için bir çubuğa veya sayaca ihtiyacı var!|r
İyi haber: v1.5'ten beri istediğiniz güçlendirme veya zayıflatmalar için istediğiniz kadar çubuk ve sayaç oluşturabilirsiniz! Yukarıdaki özel modül türlerinden birini seçip Oluştur düğmesine basın. Bu, özel bir modül oluşturup listede otomatik olarak seçer. İleride karışıklık olmaması için çubuğu en kısa sürede yeniden adlandırmanız şiddetle önerilir.

|cff9999ff10. Oyuncu veya hedefteki dinlenme/savaş/PvP vb. simgelerini nasıl kapatırım?|r
"|cffffdc42Modül Ayarları|r" bölümünü genişletin, PlayerHealth'i (hedefler için TargetHealth) genişletin ve Simge Ayarları'na tıklayın. Konum, görünürlük, çizim sırası vb. dahil simgelerin her yönünü buradan denetleyebilirsiniz.

|cff9999ff11. Oyuncu veya hedef çubuğundaki güçlendirme/zayıflatmaları nasıl kapatırım?|r
"|cffffdc42Modül Ayarları|r" bölümünü genişletin, PlayerInfo'yu (hedefler için TargetInfo) genişletin, Güçlendirme Ayarları veya Zayıflatma Ayarları'nı seçin ve "güçlendirmeleri göster" (veya "zayıflatmaları göster") işaretini kaldırın.

|cff9999ff12. Yeteneklerimden biri tetiklendiğinde yanıp sönen bu kocaman çubukları nasıl kapatırım?|r
Bu |cff9999ffIceHUD|r değil; Blizzard'ın 4.0.1'de eklediği Büyü Uyarıları. Kapatmak için Arayüz seçenekleri => Savaş => "Büyü Uyarısı Saydamlığı" ayarını kullanın veya konumlarını/boyutlarını vb. ayarlayan bir eklenti arayın.

|cff9999ff13. Bazı çubukların yerini beğenmiyorum. Can/manayı sola/sağa nasıl alırım?|r
"|cffffdc42Modül Ayarları|r" bölümünü genişletin, taşımak istediğiniz modülü (örn. PlayerHealth, PlayerMana) genişletin ve "Yan" ile "Kayma" ayarlarını değiştirin. "Yan" solda mı sağda mı olacağını, "Kayma" merkezden ne kadar uzakta olacağını belirler.

|cff9999ff14. Monk Chi gücünü hangi modül gösterir?|r
|cff9999ffIceHUD|r v1.11.2'den önce bu modülün adı |cffdcff42HarmonyPower|r idi. Harmony, 5.0 beta aşamasındayken Chi'nin ilk adıydı; ben de Cataclysm için geliştirirken Blizzard'ın adını kullandım. |cff9999ffIceHUD|r v1.11.2 bu modülün adını |cffdcff42Chi|r olarak değiştirdi.

|cff9999ff15. Can gibi büyük sayılara virgül/nokta nasıl eklerim?|r
|cff42ffffDogTags|r açıksa ilgili modülün Metin Ayarları'nı açıp bölmek istediğiniz etiketin etrafına SeparateDigits() ekleyebilirsiniz. Can/MaksCan'ı virgülle göstermek için: [(SeparateDigits(HP):HPColor "/" SeparateDigits(MaxHP):HPColor):Bracket]. Virgül yerine nokta için: [(SeparateDigits(HP, "."):HPColor "/" SeparateDigits(MaxHP, "."):HPColor):Bracket]. Mana vb. için benzer etiketler oluşturmak üzere /dog yardım menüsünü kullanın.

|cff9999ff16. Güçlendirme ve zayıflatmalardaki geri sayım zamanlayıcıları simgeyi tamamen kapatıyor. Zamanlayıcı yazısını nasıl kapatırım?|r
Bu geri sayım yazısından |cff9999ffIceHUD|r sorumlu değil, ama TargetInfo ayarlarında sayıları zorla kapatan bir seçenek var. 6.0 yaması oyun istemcisine bekleme sürelerinin üstünde sayı gösteren bir seçenek ekledi. Oyunun Arayüz seçeneklerinde Eylem Çubukları menüsüne bakın; yazıyı oradan açıp kapatabilirsiniz. |cff42ffffOmniCC|r veya |cff42ffffCooldownCount|r gibi eklentiler genelde aynı özelliği verir ama yazının ne zaman, nerede ve nasıl görüneceğini denetlemenizi sağlar.

|cff9999ff17. Büyü çubuğu gibi bazı modülleri 90 derece döndürdüğümde çubuk dolarken veya boşalırken yukarı aşağı titriyor gibi görünüyor. Bunu nasıl düzeltirim?|r
Bu, eklentideki her çubuk dokusunun kopyasını vermek zorunda kalmadan döndürmeyi zorlamak için kullandığım animasyon API'sinin bir yan etkisi. Yeterince hızlı hareket eden ve sık güncellenen her çubuk buna yol açar. |cff9999ffIceHUD|r dikey yönlü bir eklenti olarak tasarlandı; döndürme özelliği bu yan etkileri kabul edenler için var. Yatay çubuklar istiyorsanız önerim yatay yönlü çubuk eklentilerinden birini kullanmanız. Örneğin |cff42ffffQuartz|r iyi bir büyü çubuğu alternatifi; onu kullanıp |cff9999ffIceHUD|r'un yerleşik büyü çubuğunu kapatabilirsiniz.

|cff9999ff18. 7.0 yamasında oyuncunun altında çıkan çubuklardan nasıl kurtulurum?|r
Blizzard 7.0 oyun istemcisine "Kişisel Kaynak Göstergesi" özelliği ekledi. Oyun seçenekleri -> |cffffdc42Arayüz|r -> |cffffdc42Adlar|r -> |cffffdc42Kişisel Kaynak Göstergesi|r (10.0+ sürümlerinde Seçenekler -> |cffffdc42Savaş|r -> |cffffdc42Kişisel Kaynak Göstergesi|r) yolundan kapatabilirsiniz.

|cff9999ff19. Classic'te neden hedef büyü çubuğu yok?|r
Classic oyun istemcisi oyuncu dışında kimse için büyü çubuklarını göstermenin güvenilir bir yolunu sunmuyor. Desteği açmak için |cff42ffffLibCasterCasterino|r eklentisini kurabilirsiniz, ama bu yalnızca bir tahmindir ve hiç doğru değildir.

|cff9999ff20. Classic'te güçlendirme/zayıflatma zamanlayıcıları neden çalışmıyor?|r
Classic oyun istemcisi bu bilgiyi eklentilere vermiyor, çünkü oyun ilk çıktığında bu bir özellik değildi. Desteği açmak için |cff42ffffLibClassicDurations|r eklentisini kurabilirsiniz, ama bu yalnızca bir tahmindir ve hiç doğru değildir.]]
				}
			}
		},

		positioningSettings = {
			type = 'group',
			name = L["Positioning Settings"],
			desc = L["Settings related to positioning and alpha"],
			order = 11,
			args = {
				vpos = {
					type = 'range',
					name = L["Vertical position"],
					desc = L["Vertical position"],
					get = function()
						return IceHUD.IceCore:GetVerticalPos()
					end,
					set = function(info, v)
						IceHUD.IceCore:SetVerticalPos(v)
					end,
					min = -700,
					max = 700,
					step = 1,
					order = 11
				},

				hpos = {
					type = 'range',
					name = L["Horizontal position"],
					desc = L["Horizontal position"],
					get = function()
						return IceHUD.IceCore:GetHorizontalPos()
					end,
					set = function(info, v)
						IceHUD.IceCore:SetHorizontalPos(v)
					end,
					min = -2000,
					max = 2000,
					step = 1,
					order = 12
				},

				gap = {
					type = 'range',
					name = L["Gap"],
					desc = L["Distance between the left and right bars"],
					get = function()
						return IceHUD.IceCore:GetGap()
					end,
					set = function(info, v)
						IceHUD.IceCore:SetGap(v)
					end,
					min = 50,
					max = 700,
					step = 5,
					order = 13,
				},

				scale = {
					type = 'range',
					name = L["Scale"],
					desc = L["HUD scale"],
					get = function()
						return IceHUD.IceCore:GetScale()
					end,
					set = function(info, v)
						IceHUD.IceCore:SetScale(v)
					end,
					min = 0.2,
					max = 4.0,
					step = 0.05,
					isPercent = true,
					order = 14,
				},
			}
		},


		alphaSettings = {
			type = 'group',
			name = L["Transparency Settings"],
			desc = L["Settings for bar transparencies"],
			order = 12,
			args = {
				headerAlpha = {
					type = 'header',
					name = L["Bar Alpha"],
					order = 10
				},

				alphaic = {
					type = 'range',
					name = L["Alpha in combat"],
					desc = L["Bar alpha In Combat"],
					get = function()
						return IceHUD.IceCore:GetAlpha("IC")
					end,
					set = function(info, v)
						IceHUD.IceCore:SetAlpha("IC", v)
					end,
					min = 0,
					max = 1,
					step = 0.05,
					isPercent = true,
					order = 11,
				},

				alphaooc = {
					type = 'range',
					name = L["Alpha out of combat"],
					desc = L["Bar alpha Out Of Combat without target"],
					get = function()
						return IceHUD.IceCore:GetAlpha("OOC")
					end,
					set = function(info, v)
						IceHUD.IceCore:SetAlpha("OOC", v)
					end,
					min = 0,
					max = 1,
					step = 0.05,
					isPercent = true,
					order = 12,
				},

				alphaTarget = {
					type = 'range',
					name = L["Alpha OOC and Target"],
					desc = L["Bar alpha Out Of Combat with target accuired (takes precedence over Not Full)"],
					get = function()
						return IceHUD.IceCore:GetAlpha("Target")
					end,
					set = function(info, v)
						IceHUD.IceCore:SetAlpha("Target", v)
					end,
					min = 0,
					max = 1,
					step = 0.05,
					isPercent = true,
					order = 13,
				},

				alphaNotFull = {
					type = 'range',
					name = L["Alpha OOC and not full"],
					desc = L["Bar alpha Out Of Combat with target accuired or bar not full (Target takes precedence over this)"],
					get = function()
						return IceHUD.IceCore:GetAlpha("NotFull")
					end,
					set = function(info, v)
						IceHUD.IceCore:SetAlpha("NotFull", v)
					end,
					min = 0,
					max = 1,
					step = 0.05,
					isPercent = true,
					order = 14,
				},


				headerAlphaBackground = {
					type = 'header',
					name = L["Background Alpha"],
					order = 20
				},

				alphaicbg = {
					type = 'range',
					name = L["BG Alpha in combat"],
					desc = L["Background alpha for bars IC"],
					get = function()
						return IceHUD.IceCore:GetAlphaBG("IC")
					end,
					set = function(info, v)
						IceHUD.IceCore:SetAlphaBG("IC", v)
					end,
					min = 0,
					max = 1,
					step = 0.05,
					isPercent = true,
					order = 21,
				},

				alphaoocbg = {
					type = 'range',
					name = L["BG Alpha out of combat"],
					desc = L["Background alpha for bars OOC without target"],
					get = function()
						return IceHUD.IceCore:GetAlphaBG("OOC")
					end,
					set = function(info, v)
						IceHUD.IceCore:SetAlphaBG("OOC", v)
					end,
					min = 0,
					max = 1,
					step = 0.05,
					isPercent = true,
					order = 22,
				},

				alphaTargetbg = {
					type = 'range',
					name = L["BG Alpha OOC and Target"],
					desc = L["Background alpha for bars OOC and target accuired (takes precedence over Not Full)"],
					get = function()
						return IceHUD.IceCore:GetAlphaBG("Target")
					end,
					set = function(info, v)
						IceHUD.IceCore:SetAlphaBG("Target", v)
					end,
					min = 0,
					max = 1,
					step = 0.05,
					isPercent = true,
					order = 23,
				},

				alphaNotFullbg = {
					type = 'range',
					name = L["BG Alpha OOC and not Full"],
					desc = L["Background alpha for bars OOC and bar not full (Target takes precedence over this)"],
					get = function()
						return IceHUD.IceCore:GetAlphaBG("NotFull")
					end,
					set = function(info, v)
						IceHUD.IceCore:SetAlphaBG("NotFull", v)
					end,
					min = 0,
					max = 1,
					step = 0.05,
					isPercent = true,
					order = 24,
				},


				headerBarAdvanced = {
					type = 'header',
					name = L["Other"],
					order = 30
				},

				backgroundToggle = {
					type = "toggle",
					name = L["Contextual Background"],
					desc = L["Toggles contextual background coloring"],
					get = function()
						return IceHUD.IceCore:GetBackgroundToggle()
					end,
					set = function(info, value)
						IceHUD.IceCore:SetBackgroundToggle(value)
					end,
					order = 31
				},

				backgroundColor = {
					type = 'color',
					name = L["Background Color"],
					desc = L["Background Color"],
					get = function()
						return IceHUD.IceCore:GetBackgroundColor()
					end,
					set = function(info, r, g, b)
						IceHUD.IceCore:SetBackgroundColor(r, g, b)
					end,
					order = 32,
				},

				bTreatFriendlyAsTarget = {
					type = 'toggle',
					name = L["Use 'Target' alpha for friendlies"],
					desc = L["If this is disabled, then targeting a friendly will use the 'Alpha out of combat' setting instead of 'Alpha OOC and Target'."],
					width = 'double',
					get = function()
						return IceHUD.IceCore.settings.bTreatFriendlyAsTarget
					end,
					set = function(info, value)
						IceHUD.IceCore.settings.bTreatFriendlyAsTarget = value
						IceHUD.IceCore:Redraw()
					end,
					order = 33,
				},

				bHideDuringPetBattles = {
					type = 'toggle',
					name = L["Hide during pet battles"],
					desc = L["This will hide the entire mod during pet battles."],
					width = 'double',
					get = function()
						return IceHUD.IceCore.settings.bHideDuringPetBattles
					end,
					set = function(info, value)
						IceHUD.IceCore.settings.bHideDuringPetBattles = value
						if not value then
							IceHUD.IceCore.IceHUDFrame:Show()
						end
					end,
					hidden = not UnitCanPetBattle,
					order = 34,
				},

				bHideInBarberShop = {
					type = 'toggle',
					name = L["Hide in barbershops"],
					desc = L["This will hide the entire mod when interacting with a barbershop."],
					width = 'double',
					get = function()
						return IceHUD.IceCore.settings.bHideInBarberShop
					end,
					set = function(info, value)
						IceHUD.IceCore.settings.bHideInBarberShop = value
						if not value then
							IceHUD.IceCore.IceHUDFrame:Show()
						end
					end,
					hidden = not GetBarberShopStyleInfo,
					order = 35,
				},

				bHideDuringShellGame = {
					type = 'toggle',
					name = L["Hide during shell game"],
					desc = L["This will hide the entire mod when playing the BfA Tortollan shell game world quest."],
					width = 'double',
					get = function()
						return IceHUD.IceCore.settings.bHideDuringShellGame
					end,
					set = function(info, value)
						IceHUD.IceCore.settings.bHideDuringShellGame = value
						if not value then
							IceHUD.IceCore.IceHUDFrame:Show()
						end
					end,
					hidden = not IceHUD.HasShellGame,
					order = 36,
				},

				bHideDuringCataloging = {
					type = 'toggle',
					name = L["Hide during cataloging"],
					desc = L["This will hide the entire mod when using the Dragonflight Cataloging camera."],
					width = 'double',
					get = function()
						return IceHUD.IceCore.settings.bHideDuringCataloging
					end,
					set = function(info, value)
						IceHUD.IceCore.settings.bHideDuringCataloging = value
						if not value then
							IceHUD.IceCore.IceHUDFrame:Show()
						end
					end,
					hidden = not IceHUD.HasCataloging,
					order = 36,
				},
				
				bIncreaseStrata = {
					type = 'range',
					name = L["Added strata"],
					desc = L["Push IceHUD modules to the foreground. Increase if other addons are covering IceHUD. Requires reload."],
					get = function()
						return IceHUD.IceCore:GetAddedStrata()
					end,
					set = function(info, v)
						IceHUD.IceCore:SetAddedStrata(v)
					end,
					min = 0,
					max = 2,
					step = 1,
					order = 37,
				},
			}
		},


		barSettings = {
			type = 'group',
			name = L["Bar Settings"],
			desc = L["Settings related to bars"],
			order = 20,
			args = {
				barPresets = {
					type = 'select',
					name = L["Presets"],
					desc = L["Predefined settings for different bars"],
					get = function(info)
						return IceHUD.IceCore:GetBarPreset()
					end,
					set = function(info, value)
						IceHUD.IceCore:SetBarPreset(value)
					end,
					values = function()
						local keys = {}
						for key, _ in pairs(IceHUD.IceCore.presets) do
							keys[key] = key
						end
						table.sort(keys)
						return keys
					end,
					order = 9
				},


				headerBarAdvanced = {
					type = 'header',
					name = L["Advanced Bar Settings"],
					order = 10
				},

				barTexture = {
					type = 'select',
					name = L["Bar Texture"],
					desc = L["IceHUD Bar Texture"],
					get = function(info)
						return IceHUD:GetSelectValue(info, IceHUD.IceCore:GetBarTexture())
					end,
					set = function(info, value)
						IceHUD.IceCore:SetBarTexture(IceHUD.validBarList[value])
					end,
					values = IceHUD.validBarList,
					order = 11
				},

				barWidth = {
					type = 'range',
					name = L["Bar Width"],
					desc = L["Bar texture width (not the actual bar!)"],
					get = function()
						return IceHUD.IceCore:GetBarWidth()
					end,
					set = function(info, v)
						IceHUD.IceCore:SetBarWidth(v)
					end,
					min = 20,
					max = 200,
					step = 1,
					order = 12
				},

				barHeight = {
					type = 'range',
					name = L["Bar Height"],
					desc = L["Bar texture height (not the actual bar!)"],
					get = function()
						return IceHUD.IceCore:GetBarHeight()
					end,
					set = function(info, v)
						IceHUD.IceCore:SetBarHeight(v)
					end,
					min = 100,
					max = 300,
					step = 1,
					order = 13
				},

				barProportion = {
					type = 'range',
					name = L["Bar Proportion"],
					desc = L["Determines the bar width compared to the whole texture width"],
					get = function()
						return IceHUD.IceCore:GetBarProportion()
					end,
					set = function(info, v)
						IceHUD.IceCore:SetBarProportion(v)
					end,
					min = 0.01,
					max = 0.5,
					step = 0.01,
					isPercent = true,
					order = 14
				},

				barSpace = {
					type = 'range',
					name = L["Bar Space"],
					desc = L["Space between bars on the same side"],
					get = function()
						return IceHUD.IceCore:GetBarSpace()
					end,
					set = function(info, v)
						IceHUD.IceCore:SetBarSpace(v)
					end,
					min = -10,
					max = 30,
					step = 1,
					order = 15
				},

				bgBlendMode = {
					type = 'select',
					name = L["Bar Background Blend Mode"],
					desc = L["IceHUD Bar Background Blend mode"],
					get = function(info)
						return IceHUD.IceCore:GetBarBgBlendMode()
					end,
					set = function(info, value)
						IceHUD.IceCore:SetBarBgBlendMode(value)
					end,
					values = { BLEND = "Karışım", ADD = "Toplamalı" }, --"Disable", "Alphakey", "Mod" },
					order = 16
				},

				barBlendMode = {
					type = 'select',
					name = L["Bar Blend Mode"],
					desc = L["IceHUD Bar Blend mode"],
					get = function(info)
						return IceHUD.IceCore:GetBarBlendMode()
					end,
					set = function(info, value)
						IceHUD.IceCore:SetBarBlendMode(value)
					end,
					values = { BLEND = "Karışım", ADD = "Toplamalı" }, --"Disable", "Alphakey", "Mod" },
					order = 17
				},
			}
		},


		modules = {
			type='group',
			desc = L["Module configuration options"],
			name = L["Module Settings"],
			args = {},
			order = 41
		},

		colors = {
			type='group',
			desc = L["Module color configuration options"],
			name = L["Colors"],
			args = {},
			order = 42
		},

		enabled = {
			type = "toggle",
			name = L["Enabled"],
			desc = L["Enable/disable IceHUD"],
			get = function()
				return IceHUD.IceCore:IsEnabled()
			end,
			set = function(info, value)
				if (value) then
					IceHUD.IceCore:Enable(true)
				else
					IceHUD.IceCore:Disable(true)
				end
			end,
			order = 91
		},

		debug = {
			type = "toggle",
			name = L["Debugging"],
			desc = L["Enable/disable debug messages"],
			get = function()
				return IceHUD.IceCore:GetDebug()
			end,
			set = function(info, value)
				IceHUD.IceCore:SetDebug(value)
			end,
			hidden =
				--@non-debug@
				true
				--@end-non-debug@
				--[==[@debug@
				false
				--@end-debug@]==]
			,
			disabled =
				-- hello, snooper! this feature doesn't actually work yet, so enabling it won't help you much :)
				--@non-debug@
				true
				--@end-non-debug@
				--[==[@debug@
				false
				--@end-debug@]==]
			,
			order = 92
		},

		customModuleSelect = {
			type = "select",
			name = L["Create custom module"],
			desc = L["Select a custom module that you want to create here, then press the 'Create' button."],
			get = function(info)
				return lastCustomModule
			end,
			set = function(info, v)
				lastCustomModule = v
			end,
			values = IceHUD.validCustomModules,
			order = 94.5,
		},

		customModuleCreate = {
			type = "execute",
			name = L["Create"],
			desc = L["Creates the selected custom module"],
			func = function()
				IceHUD:CreateCustomModuleAndNotify(lastCustomModule)
			end,
			disabled = function()
				return not IceHUD.IceCore:IsEnabled()
			end,
			order = 94.6,
		},

		configMode = {
			type = 'toggle',
			name = L["Configuration Mode"],
			desc = L["Makes all modules visible so you can see where they're placed and find any that are overlapping."],
			get = function()
				return IceHUD.IceCore:IsInConfigMode()
			end,
			set = function(info, value)
				IceHUD.IceCore:ConfigModeToggle(value)
			end,
			disabled = function()
				return not IceHUD.IceCore:IsEnabled()
			end,
			order = 95
		},

		useDogTags = {
			type = 'toggle',
			name = L["Use Dog Tags"],
			desc = L["Whether or not the addon should use the DogTag library (this will increase the CPU usage of the mod). DogTag controls all text displayed around bars such as health or mana amounts. Type |cffffff78/dog|r to see all DogTag options.\n\nNOTE: after changing this option, you must reload the UI or else bad things happen"],
			get = function()
				return IceHUD.IceCore:ShouldUseDogTags()
			end,
			set = function(info, v)
				IceHUD.IceCore:SetShouldUseDogTags(v)
				StaticPopup_Show("ICEHUD_CHANGED_DOGTAG")
			end,
			hidden = function()
				return not LibStub("LibDogTag-3.0", true)
			end,
			order = 96
		},

		updatePeriod = {
			type = 'range',
			name = L["Update Period"],
			desc = L["Number of updates per second. The higher this number is, the smoother bars will animate. However, higher settings will also use more CPU, so balance it to your liking. 30 is the recommended setting."],
			get = function()
				return math.ceil(1/IceHUD.IceCore:UpdatePeriod())
			end,
			set = function(info, v)
				IceHUD.IceCore:SetUpdatePeriod(1/v)
			end,
			min = 15,
			max = 60,
			step = 1,
			order = 97
		},

		showMinimap = {
			type = 'toggle',
			name = L["Show Minimap Icon"],
			desc = L["Whether or not to show an IceHUD icon on the minimap."],
			get = function(info)
				return not IceHUD.db.profile.minimap.hide
			end,
			set = function(info, v)
				IceHUD.db.profile.minimap.hide = not v
				if v then
					icon:Show("IceHUD")
				else
					icon:Hide("IceHUD")
				end
			end,
			hidden = function() return not icon end,
			order = 98
		},
	}
}

if AceGUIWidgetLSMlists then
	options.args.textSettings = {
		type = 'select',
		dialogControl = "LSM30_Font",
		name = L["Font"],
		desc = L["IceHUD Font"],
		get = function(info)
			return IceHUD.IceCore:GetFontFamily()
		end,
		set = function(info, value)
			IceHUD.IceCore:SetFontFamily(value)
		end,
		disabled = function()
			return not IceHUD.IceCore:IsEnabled()
		end,
		values = AceGUIWidgetLSMlists.font,
		order = 94.75,
	}
end

IceHUD_Options.options = options

function IceHUD_Options:GenerateModuleOptions(firstLoad)
	self.options.args.modules.args = IceHUD.IceCore:GetModuleOptions()
	if not firstLoad then
		IceHUD:NotifyOptionsChange()
	end
end

function IceHUD_Options:SetupProfileImportButtons()
	if AceSerializer then
		AceSerializer:Embed(self)
		self.options.args.profiles.args.export = {
			type = 'execute',
			name = L["Export profile"],
			desc = L["Exports your active profile to something you can copy and paste to another user or use on another account."],
			func = function()
				local frame = AceGUI:Create("Frame")
				frame:SetTitle("Profil verisi")
				frame:SetStatusText("İçe aktarmak için yukarıdaki metni kopyalayın")
				frame:SetLayout("Flow")
				frame:SetCallback("OnClose", function(widget) AceGUI:Release(widget) end)
				local editbox = AceGUI:Create("MultiLineEditBox")
				editbox:SetLabel("Profil")
				editbox:SetFullWidth(true)
				editbox:SetFullHeight(true)
				local profileTable = IceHUD.deepcopy(IceHUD.db.profile)
				IceHUD:removeDefaults(profileTable, IceHUD.IceCore.defaults.profile)
				editbox:SetText(IceHUD.json.encode(profileTable))
				editbox:DisableButton(true)
				frame:AddChild(editbox)
			end,
			order = 98.1
		}

		self.options.args.profiles.args.import = {
			type = 'execute',
			name = L["Import profile"],
			desc = L["Imports a profile as exported from another user's IceHUD."],
			func = function()
				local frame = AceGUI:Create("Frame")
				frame:SetTitle("Profil verisi")
				frame:SetStatusText("Profili kutuya yapıştırın")
				frame:SetLayout("Flow")
				frame:SetCallback("OnClose", function(widget)
					AceGUI:Release(widget)
				end)
				local editbox = AceGUI:Create("MultiLineEditBox")
				editbox:SetLabel("Profil")
				editbox:SetFullWidth(true)
				editbox:SetFullHeight(true)
				editbox:SetCallback("OnEnterPressed", function()
					local text = strtrim(editbox:GetText())
					if strlen(text) > 0 then
						local newTable, err = IceHUD.json.decode(text)
						if err ~= nil then
							print("IceHUD profili içe aktarılamadı: "..err)
						else
							IceHUD:PreProfileChanged()
							IceHUD:populateDefaults(newTable, IceHUD.IceCore.defaults.profile)
							IceHUD.db.profile = IceHUD.deepcopy(newTable)
							IceHUD.db.profiles[IceHUD.db:GetCurrentProfile()] = IceHUD.db.profile
							IceHUD:PostProfileChanged()
							print("IceHUD profili içe aktarıldı ve uygulandı.")
						end
					end
					frame:Hide()
				end)
				editbox.button:SetText("İçe Aktar")
				editbox.button:SetPoint("RIGHT", editbox.frame, "RIGHT", 0, 0)
				frame:AddChild(editbox)
			end,
			order = 98.2
		}
	end
end

function IceHUD_Options:TryEnhanceOptions()
	if not IceHUD or not IceHUD.dbEnhanced or not IceHUD.db then
		return
	end

	if self.enhanced or not LibDualSpec then
		return
	end

	LibDualSpec:EnhanceOptions(IceHUD_Options.options.args.profiles, IceHUD.db)
	self.enhanced = true
end

function IceHUD_Options:OnLoad()
	if self.loaded then
		-- make sure we're ready and haven't done this already.
		IceHUD_Options:TryEnhanceOptions()
		return
	end

	self:GenerateModuleOptions(true)
	self.options.args.colors.args = IceHUD.IceCore:GetColorOptions()
	self.options.args.profiles = LibStub("AceDBOptions-3.0"):GetOptionsTable(IceHUD.db)
	self:SetupProfileImportButtons()

	-- Add dual-spec support
	IceHUD_Options:TryEnhanceOptions()

	LibStub("AceConfig-3.0"):RegisterOptionsTable("IceHUD", options, "icehudcl")
	self.loaded = true
end

if IceHUD and IceHUD.IceCore then
	IceHUD_Options:OnLoad()
end
