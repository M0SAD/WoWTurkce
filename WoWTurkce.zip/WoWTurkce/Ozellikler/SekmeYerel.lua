-- Yetenek/büyü kitabı penceresindeki başlık sekmeleri (Primary, Secondary...) için Türkçe düzeltme.
local G = WoWTurkce

local METIN = { ["Primary"] = "Birincil", ["Secondary"] = "İkincil" }
local KOKLER = { "PlayerSpellsFrame", "ProfessionsBookFrame", "SpellBookFrame", "SpellBookProfessionFrame" }

local function yazilar(f, d)
	if d > 10 then return end
	if f.IsShown and not f:IsShown() then return end
	if f.GetRegions then
		for _, r in ipairs({ f:GetRegions() }) do
			if r.GetObjectType and r:GetObjectType() == "FontString" and r.GetText then
				local t = r:GetText()
				if type(t) == "string" and not G.gizli(t) and METIN[t] then r:SetText(METIN[t]) end
			end
		end
	end
	if f.GetChildren then
		for _, c in ipairs({ f:GetChildren() }) do yazilar(c, d + 1) end
	end
end

G.basla(function()
	G.olcTicker(1.0, function()
		if not G.ayar("acik") then return end
		for _, ad in ipairs(KOKLER) do
			local f = _G[ad]
			if f and f.IsShown and f:IsShown() then pcall(yazilar, f, 0) end
		end
	end)
end)

-- "Beceri" penceresi: meslek ve beceri adlarının yanına İngilizcesini ekle (Türkçe (English) stili; ayar: stilBuyu)
local BECERI = {
	["Meslekler"] = "Professions", ["İkincil Beceriler"] = "Secondary Skills", ["Silah Becerisi"] = "Weapon Skills",
	["Zırh Becerisi"] = "Armor Proficiencies", ["Diller"] = "Languages", ["Zırh Eğitimi"] = "Armor Proficiencies",
	["Madencilik"] = "Mining", ["Deri Yüzme"] = "Skinning", ["Aşçılık"] = "Cooking", ["İlk Yardım"] = "First Aid",
	["Balıkçılık"] = "Fishing", ["Simya"] = "Alchemy", ["Demircilik"] = "Blacksmithing", ["Mühendislik"] = "Engineering",
	["Efsunculuk"] = "Enchanting", ["Bitkicilik"] = "Herbalism", ["Dericilik"] = "Leatherworking", ["Terzilik"] = "Tailoring",
	["Çilingirlik"] = "Lockpicking", ["Binicilik"] = "Riding", ["Zehirler"] = "Poisons", ["Arkeoloji"] = "Archaeology",
}
local beceriKok
local function baslikVar(f, d)
	if d > 5 or (f.IsShown and not f:IsShown()) then return false end
	if f.GetRegions then
		for _, r in ipairs({ f:GetRegions() }) do
			if r.GetObjectType and r:GetObjectType() == "FontString" and r.GetText then
				local t = r:GetText()
				if type(t) == "string" and not G.gizli(t) and (t == "Beceri" or t == "Skills") then return true end
			end
		end
	end
	if f.GetChildren then
		for _, c in ipairs({ f:GetChildren() }) do if baslikVar(c, d + 1) then return true end end
	end
	return false
end
local function beceriYaz(f, d)
	if d > 14 or (f.IsShown and not f:IsShown()) then return end
	if f.GetRegions then
		for _, r in ipairs({ f:GetRegions() }) do
			if r.GetObjectType and r:GetObjectType() == "FontString" and r.GetText then
				local t = r:GetText()
				if type(t) == "string" and not G.gizli(t) then
					local en = BECERI[t]
					if en then
						local yeni = G.adStil("stilBuyu", t, en, "|cffaaaaaa")
						if yeni and yeni ~= t then r:SetText(yeni) end
					end
				end
			end
		end
	end
	if f.GetChildren then
		for _, c in ipairs({ f:GetChildren() }) do beceriYaz(c, d + 1) end
	end
end
local BECERI_ADAY = { "SkillFrame", "ClassicSkillsFrame", "CharacterFrame", "SkillsFrame" }
G.basla(function()
	G.olcTicker(1.5, function()
		pcall(function()
			if not G.ayar("acik") then return end
			if not (beceriKok and beceriKok:IsShown()) then
				beceriKok = nil
				for _, ad in ipairs(BECERI_ADAY) do
					local c = _G[ad]
					if c and c.IsShown and c:IsShown() and not (c.IsForbidden and c:IsForbidden()) and baslikVar(c, 0) then beceriKok = c; break end
				end
			end
			if beceriKok then beceriYaz(beceriKok, 0) end
		end)
	end)
end)

-- Görev pencerelerinde (başlık, açıklama, hedef, takip listesi) İngilizce kalan "Mining" -> "Madencilik"
local function miningDuzelt(tr)
	if type(tr) ~= "string" or not tr:find("Mining", 1, true) then return tr end
	return (tr:gsub("()%f[%a]Mining%f[%A]", function(pos)
		local once = tr:sub(math.max(1, pos - 12), pos - 1)
		local sonra = tr:sub(pos + 6, pos + 11)
		if once:find("Canyon $") or once:find("Deepmountain $") or once:find("Deep Mountain $") or sonra:find("^ Guild") or sonra:find("^ and ") or sonra:find("^ Co") then return nil end
		return "Madencilik"
	end))
end
local GOREV_KOKLER = { "QuestFrame", "QuestLogFrame", "QuestMapFrame", "QuestLogDetailFrame", "QuestLogPopupDetailFrame", "ObjectiveTrackerFrame", "QuestWatchFrame" }
local function gorevYaz(f, d)
	if d > 14 or (f.IsForbidden and f:IsForbidden()) or (f.IsShown and not f:IsShown()) then return end
	if f.GetRegions then
		for _, r in ipairs({ f:GetRegions() }) do
			if r.GetObjectType and r:GetObjectType() == "FontString" and r.GetText then
				local t = r:GetText()
				if type(t) == "string" and not G.gizli(t) and t:find("Mining", 1, true) then
					local y = miningDuzelt(t)
					if y ~= t then r:SetText(y) end
				end
			end
		end
	end
	if f.GetChildren then
		for _, c in ipairs({ f:GetChildren() }) do gorevYaz(c, d + 1) end
	end
end
G.basla(function()
	G.olcTicker(1.6, function()
		if not G.ayar("acik") then return end
		for _, ad in ipairs(GOREV_KOKLER) do
			local f = _G[ad]
			if f and f.IsShown and f:IsShown() then pcall(gorevYaz, f, 0) end
		end
	end)
end)

-- İngilizce görev adı -> Türkçe (görev verisindeki başlık parmak izinden; yoksa eşya adı)
local baslikIz
local ONEK = { ["Turn in"] = "Teslim et", ["Complete"] = "Tamamla", ["Pick up"] = "Al", ["Accept"] = "Al", ["Objective"] = "Hedef", ["Available"] = "Alınabilir" }
function G.gorevBaslikTr(en)
	if type(en) ~= "string" or en == "" then return nil end
	local tr = G.GorevAdi and G.GorevAdi[en]
	if tr and tr ~= en then return tr end
	if not baslikIz then
		baslikIz = {}
		for _, tablo in ipairs({ G.Veri or {}, G.VeriEk or {} }) do
			for _, v in pairs(tablo) do
				if type(v) == "table" and type(v.b) == "string" and type(v.k) == "table" and v.k.b and not baslikIz[v.k.b] then
					baslikIz[v.k.b] = v.b
				end
			end
		end
	end
	local iz = G.konusmaIz(en, 2)
	tr = iz and baslikIz[iz]
	if tr and tr ~= en then return tr end
	tr = G.Esya and G.Esya[en]
	if type(tr) == "string" and tr ~= en then return tr end
end
function G.gorevSatirTr(s)
	local tr = G.gorevBaslikTr(s)
	if tr then return tr end
	local on, ad = s:match("^([%a ]+): (.+)$")
	if on and ONEK[on] then return ONEK[on] .. ": " .. (G.gorevBaslikTr(ad) or ad) end
end

-- Questie/harita görev ipuçları: "[13] Görev adı" satırından sonra gelen İngilizce görev açıklamasını
-- görev verisindeki Türkçe hedef metniyle değiştir; "(Available)" gibi durumları ve "+100 X" itibar satırını çevir.
local hedefIndeks
local indeksIs = G.arkaPlan(function()
	local d, say = {}, 0
	for _, tablo in ipairs({ G.Veri or {}, G.VeriEk or {} }) do
		for _, v in pairs(tablo) do
			say = say + 1
			if say % 500 == 0 then G.adim() end
			if type(v) == "table" and type(v.b) == "string" and type(v.h) == "string" and v.h ~= "" and not d[v.b] then d[v.b] = v.h end
		end
	end
	hedefIndeks = d
end)
local function indeksKur()
	indeksIs.bitir()
	hedefIndeks = hedefIndeks or {}
end
local DURUM_TR = { ["Available"] = "Alınabilir", ["Completed"] = "Tamamlandı", ["In Progress"] = "Devam ediyor", ["Failed"] = "Başarısız", ["Complete"] = "Tamamlandı" }
local function sade(t) return (t:gsub("|T.-|t", ""):gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", ""):gsub("^%s+", ""):gsub("%s+$", "")) end
local STAT_AD = {}
for _, k in ipairs({ "Ruh", "Zekâ", "Zeka", "Güç", "Çeviklik", "Dayanıklılık", "Zırh", "Büyü Gücü", "Saldırı Gücü", "Spirit", "Intellect", "Strength",
	"Agility", "Stamina", "Armor", "Attack Power", "Spell Power", "Defense", "Savunma" }) do STAT_AD[k] = true end
local FRAKSIYON = {}
for _, k in ipairs({ "Undercity", "Orgrimmar", "Thunder Bluff", "Darkspear Trolls", "Silvermoon City", "Stormwind", "Ironforge", "Darnassus",
	"Gnomeregan", "Gnomeregan Exiles", "Exodar", "Argent Dawn", "Cenarion Circle", "Thorium Brotherhood", "Timbermaw Hold", "Hydraxian Waterlords",
	"Zandalar Tribe", "Brood of Nozdormu", "Bloodsail Buccaneers", "Booty Bay", "Gadgetzan", "Everlook", "Ratchet", "Ravenholdt", "Shen'dralar",
	"Wintersaber Trainers", "Frostwolf Clan", "Stormpike Guard", "Warsong Outriders", "Silverwing Sentinels", "The Defilers", "The League of Arathor",
	"Darkmoon Faire", "Steamwheedle Cartel", "Syndicate", "The Forsaken", "Forsaken" }) do FRAKSIYON[k] = true end
local function ipucuGorevAciklama(tt)
	if not G.ayar("acik") then return end
	local esyaIpucu = (tt.GetItem and select(2, tt:GetItem()) ~= nil) or (tt.GetSpell and select(1, tt:GetSpell()) ~= nil)
	local ad = tt.GetName and tt:GetName()
	if not ad then return end
	local n = tt:NumLines() or 0
	if n < 2 then return end
	local sonBaslik
	for i = 1, math.min(n, 40) do
		local L = _G[ad .. "TextLeft" .. i]
		local R = _G[ad .. "TextRight" .. i]
		local t = L and L:GetText()
		if type(t) == "string" and not G.gizli(t) then
			local s = sade(t)
			local b = s:match("^%[%d+[%a%+%-]*%]%s*(.+)$")
			if b then
				-- Sondaki durum: "Whispering Horror Residue (Complete)"
				local b2, st = b:match("^(.-)%s*%((%a[%a ]*)%)$")
				if b2 and DURUM_TR[st] then b = b2 end
				sonBaslik = b
				local yeni = t
				if st and DURUM_TR[st] then yeni = yeni:gsub("%(" .. st .. "%)", "(" .. DURUM_TR[st] .. ")", 1) end
				if not G.turkceMi(b) then
					local btr = G.gorevBaslikTr(b)
					if btr then
						yeni = yeni:gsub(b:gsub("(%W)", "%%%1"), (btr:gsub("%%", "%%%%")), 1)
						L:SetText(yeni); yeni = nil
						if not hedefIndeks then indeksKur() end
						if hedefIndeks[btr] then sonBaslik = btr end
					end
				end
				if yeni and yeni ~= t then L:SetText(yeni) end
			elseif sonBaslik and #s > 40 and not G.turkceMi(s) and s:find("%a") and not s:find("%d+/%d+") and not s:find("^%-") then
				-- Yalnızca görevin uzun açıklama satırı (harita/alınabilir görev ipucu); "2/6 X" gibi hedef satırlarına dokunma
				if not hedefIndeks then indeksKur() end
				local h = hedefIndeks[sonBaslik]
				if h then local hh = (G.gorevAdCevir and G.gorevAdCevir(h)) or h; L:SetText(G.doldur and G.doldur(hh) or hh); tt:Show() end
				sonBaslik = nil
			else
				local fk, ad2 = s:match("^%+(%d+) (.+)$")
				-- Yalnızca görev ipuçlarındaki fraksiyon itibarı ("+100 Undercity"); eşya statlarına ("+1 Ruh") dokunma
				if fk and not esyaIpucu and not G.turkceMi(s) and L:IsShown() and not ad2:find("itibar", 1, true)
					and not STAT_AD[ad2] and (G.yerAdiMi(ad2) or FRAKSIYON[ad2]) then
					L:SetText("+" .. fk .. " " .. ad2 .. " itibarı")
				end
			end
		end
		local rt = R and R.GetText and R:GetText()
		if type(rt) == "string" and not G.gizli(rt) and rt:find("%(%a[%a ]*%)") then
			local y = rt:gsub("%((%a[%a ]*)%)", function(d) return DURUM_TR[d] and ("(" .. DURUM_TR[d] .. ")") or nil end)
			if y ~= rt then R:SetText(y) end
		end
	end
end
G.ipucuGorevAciklama = function(tt) pcall(ipucuGorevAciklama, tt) end
G.basla(function()
	G.olcTicker(0.8, function()
		pcall(function()
			if not G.ayar("acik") then return end
			for _, ad in ipairs({ "GameTooltip", "ItemRefTooltip", "WorldMapTooltip", "QuestieTooltip" }) do
				local tt = _G[ad]
				if tt and tt.IsShown and tt:IsShown() and tt.NumLines then pcall(ipucuGorevAciklama, tt) end
			end
		end)
	end)
end)

-- TomTom yol noktası ipucu (harita/mini harita): görev adı Türkçe, "From:" -> "Kaynak:"
local function tomtomIpucu(tt)
	local ad = tt.GetName and tt:GetName()
	if not ad then return end
	local var = false
	for i = 2, math.min(tt:NumLines() or 0, 8) do
		local L = _G[ad .. "TextLeft" .. i]
		local t = L and L:GetText()
		if type(t) == "string" and not G.gizli(t) and t:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):find("^From: ") then var = true end
	end
	if not var then return end
	for i = 1, math.min(tt:NumLines() or 0, 8) do
		local L = _G[ad .. "TextLeft" .. i]
		local t = L and L:GetText()
		if type(t) == "string" and not G.gizli(t) then
			local s = t:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", "")
			if i == 1 and not G.turkceMi(s) then
				local tr = G.gorevSatirTr(s) or (G.Arayuz and G.Arayuz[s])
				if tr and tr ~= s then L:SetText(tr) end
			elseif s:find("^From: ") then
				L:SetText((t:gsub("From: ", "Kaynak: ", 1)))
			end
		end
	end
end
G.basla(function()
	G.olcTicker(0.8, function()
		pcall(function()
			if not G.ayar("acik") then return end
			for _, ad in ipairs({ "TomTomTooltip", "GameTooltip" }) do
				local tt = _G[ad]
				if tt and tt.IsShown and tt:IsShown() and tt.NumLines then pcall(tomtomIpucu, tt) end
			end
		end)
	end)
end)


-- Auctionator: Türkçe eşya adıyla arama ("Keten Kumaş" -> "Linen Cloth")
do
	local KUCUK = { ["İ"] = "i", ["I"] = "ı", ["Ç"] = "ç", ["Ğ"] = "ğ", ["Ö"] = "ö", ["Ş"] = "ş", ["Ü"] = "ü", ["Â"] = "â" }
	local function trKucuk(s)
		s = s:gsub("[\195\196\197][\128-\191]", function(c) return KUCUK[c] or c end)
		return (s:gsub("%u", string.lower))
	end
	local dizin, liste
	local function kur()
		local dz, ls, say = {}, {}, 0
		for en, tr in pairs(G.EsyaAdi or {}) do
			say = say + 1
			if say % 300 == 0 then G.adim() end
			if type(en) == "string" and type(tr) == "string" and tr ~= en then
				local k = trKucuk(tr)
				if not dz[k] then dz[k] = en; ls[#ls + 1] = { k, en } end
			end
		end
		dizin, liste = dz, ls
	end
	function G.esyaAramaIngilizce(s)
		if type(s) ~= "string" or s == "" then return s end
		local tirnak = s:match('^"(.*)"$')
		local ham = tirnak or s
		if not G.turkceMi(ham) and not ham:find("[çğıöşüÇĞİÖŞÜ]") then
			-- Türkçe harfsiz de olabilir ("keten kumas" değil, "Keten Kumaş"): yine de sözlükte ara
		end
		if not dizin then kur() end
		local k = trKucuk(ham):gsub("^%s+", ""):gsub("%s+$", "")
		local en = dizin[k]
		if not en and #k >= 3 then
			-- Kısmi arama: Türkçe adı bu metni içeren en kısa eşya
			local enIyi
			for _, p in ipairs(liste) do
				if p[1]:find(k, 1, true) and (not enIyi or #p[1] < #enIyi[1]) then enIyi = p end
			end
			if enIyi then en = enIyi[2] end
		end
		if not en then return s end
		return tirnak and ('"' .. en .. '"') or en
	end
	local function kanca()
		local A = rawget(_G, "Auctionator")
		if not (A and A.Search and A.Search.SplitAdvancedSearch) or A.Search._gtrKanca then return end
		A.Search._gtrKanca = true
		local asil = A.Search.SplitAdvancedSearch
		A.Search.SplitAdvancedSearch = function(str, ...)
			local r = asil(str, ...)
			if type(r) == "table" and type(r.searchString) == "string" and G.ayar("acik") then
				local ok, en = pcall(G.esyaAramaIngilizce, r.searchString)
				if (not ok or not en or en == r.searchString) and G.aramaCevir then ok, en = pcall(G.aramaCevir, r.searchString) end
				if ok and type(en) == "string" and en ~= r.searchString then r.searchString = (en:gsub('^"(.*)"$', "%1")) end
			end
			return r
		end
	end
	local f = CreateFrame("Frame")
	f:RegisterEvent("ADDON_LOADED"); f:RegisterEvent("PLAYER_LOGIN")
	f:SetScript("OnEvent", function() pcall(kanca) end)
end


-- IceHUD büyü çubuğu: yazı ekrana konmadan önce çevir ("0.5s Skinning" -> "0.5 sn Deri Yüzme")
do
	local function kur()
		local B = rawget(_G, "IceBarElement")
		local P = B and B.prototype
		if not P or P._gtrKanca or type(P.SetBottomText1) ~= "function" then return end
		P._gtrKanca = true
		local asil = P.SetBottomText1
		P.SetBottomText1 = function(self, text, ...)
			if type(text) == "string" and G.ayar("acik") then
				local ok, y = pcall(G.buyuSureYazi, text)
				if ok and y then text = y
				elseif not G.gizli(text) and not text:find("%d") then
					-- Süresiz büyü adı ("Skinning", "Interrupted")
					local tr = (G.BuyuAdi and G.BuyuAdi[text]) or G.Arayuz[text]
					if type(tr) == "string" and tr ~= "" then text = (G.renksiz(tr):gsub("%s*%(.-%)%s*$", "")) end
				end
			end
			return asil(self, text, ...)
		end
		local C = rawget(_G, "IceCastBar")
		if C and C.prototype and rawget(C.prototype, "SetBottomText1") and rawget(C.prototype, "SetBottomText1") ~= P.SetBottomText1 then
			local asil2 = C.prototype.SetBottomText1
			C.prototype.SetBottomText1 = function(self, text, ...)
				local ok, y = pcall(G.buyuSureYazi, text)
				return asil2(self, (ok and y) or text, ...)
			end
		end
	end
	local f = CreateFrame("Frame")
	f:RegisterEvent("ADDON_LOADED"); f:RegisterEvent("PLAYER_LOGIN")
	f:SetScript("OnEvent", function() pcall(kur) end)
end

-- IceHUD hatası: kapatılan (devre dışı) modülün çubuğu ekranda kalıyor (Hedefin Hedefi gibi güvenli
-- birim düğmeleri). Kapalı modüllerin çerçevesini savaş dışında gizle.
do
	local function temizle()
		if InCombatLockdown and InCombatLockdown() then return end
		local IH = rawget(_G, "IceHUD")
		local core = IH and IH.IceCore
		local liste = core and core.elements
		if type(liste) ~= "table" then return end
		for _, el in pairs(liste) do
			local ms = type(el) == "table" and el.moduleSettings
			if ms and ms.enabled == false then
				for _, f in ipairs({ el.frame, el.masterFrame }) do
					if f and f.IsShown and f:IsShown() then
						pcall(UnregisterUnitWatch, f)
						pcall(f.Hide, f)
					end
				end
			end
		end
	end
	G.basla(function()
		G.olcTicker(1.5, function() pcall(temizle) end)
	end)
	local f = CreateFrame("Frame")
	f:RegisterEvent("PLAYER_REGEN_ENABLED")
	f:SetScript("OnEvent", function() C_Timer.After(0.2, function() pcall(temizle) end) end)
end

-- RareScanner: dil tablosunu (AceLocale) doğrudan Türkçeleştir. Notlardaki {npc:..}/{map:..} etiketleri çeviride korunur;
-- etiketler adlarla değiştirilmeden önce çevrildiği için harita ipuçlarındaki notlar tam Türkçe olur.
do
	local yapildi = {}
	local function yerelCevir(eklenti)
		if yapildi[eklenti] then return end
		local LS = rawget(_G, "LibStub")
		local AceL = LS and LS("AceLocale-3.0", true)
		local okL, AL = pcall(function() return AceL and AceL:GetLocale(eklenti, true) end)
		if not okL or type(AL) ~= "table" then return end
		yapildi[eklenti] = true
		local n = 0
		for k, v in pairs(AL) do
			if type(v) == "string" and v ~= "" and not G.turkceMi(v) then
				local tr = G.Arayuz[v]
				if not tr and not v:find("%s", 1, true) and v:find("%%[%d%.]*[dfi]") then
					local sayilar = {}
					local k2 = v:gsub("%%[%d%.]*[dfi]", function(s) sayilar[#sayilar + 1] = s; return "#" end):gsub("%%%%", "%%")
					local t2 = G.Arayuz[k2]
					if t2 then tr = (t2:gsub("%%", "%%%%"):gsub("{(%d)}", function(i) return sayilar[tonumber(i)] or "" end)) end
				end
				if type(tr) == "string" and tr ~= v then rawset(AL, k, tr); n = n + 1 end
			end
		end
		G.tani = G.tani or {}; G.tani["yerel_" .. eklenti] = n
	end
	local f = CreateFrame("Frame")
	f:RegisterEvent("PLAYER_LOGIN"); f:RegisterEvent("ADDON_LOADED")
	f:SetScript("OnEvent", function(_, olay, ad)
		if olay == "PLAYER_LOGIN" or ad == "RareScanner" then pcall(yerelCevir, "RareScanner") end
	end)
end

-- Dünya haritası bölge etiketi açıklaması (Leatrix Maps: "Fishing: 130") -> "Balıkçılık: 130"
do
	local function cevir(fs)
		if not fs or not fs.GetText or not G.modul("arayuz") then return end
		local t = fs:GetText()
		if type(t) ~= "string" or t == "" or G.gizli(t) then return end
		local n = t:match("^Fishing: (%d+)$")
		if n then fs:SetText("Balıkçılık: " .. n); return end
		local tr = G.Arayuz[t]
		if type(tr) == "string" and tr ~= t then fs:SetText(tr) end
	end
	local function kur()
		local wm = rawget(_G, "WorldMapFrame")
		if not wm or not wm.dataProviders then return false end
		local bulundu = false
		for dp in pairs(wm.dataProviders) do
			local lb = type(dp) == "table" and dp.Label
			if type(lb) == "table" and lb.Description and lb.EvaluateLabels and not lb._gtrKanca then
				lb._gtrKanca = true; bulundu = true
				hooksecurefunc(lb, "EvaluateLabels", function(self) pcall(cevir, self.Description) end)
			end
		end
		return bulundu
	end
	local f = CreateFrame("Frame")
	f:RegisterEvent("PLAYER_ENTERING_WORLD")
	f:SetScript("OnEvent", function()
		if not pcall(kur) then return end
		if WorldMapFrame and not WorldMapFrame._gtrEtiket then
			WorldMapFrame._gtrEtiket = true
			WorldMapFrame:HookScript("OnShow", function() pcall(kur) end)
		end
	end)
end
