local mod	= DBM:NewMod("RelicGuardian", "DBM-Party-Forever", 3)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20261107034458")
mod:EnableGenericTrash()
--mod:SetCreatureID(11517)
mod:SetEncounterID(3482)
mod:SetModelID(144224)
mod:SetZone(2998)

mod:RegisterCombat("combat")

--mod:AddAuraSoundOption(123456, true, 123456, 1, 1, "targetyou", 2, 0)
