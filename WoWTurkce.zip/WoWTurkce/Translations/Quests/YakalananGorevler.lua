-- Oyundan yakalanan görev metinleri ("çevir" ile eklenir). Metin parmak iziyle eşleşir.
local G = WoWTurkce
local gorev = G.yeniGorev
if not gorev then return end

-- Karanlıkta Bir Işık (98389)
gorev(nil, nil, {
	{ "Greetings, priest. Yes, I am a paladin. Not even death can stop the Light.\r\n\r\nThis is something my kind have in common with all Forsaken--we have overcome what the living view as their end. However, some even among our own fear us; they suspect we will smite them as some monstrosity.\r\n\r\nIn truth, our relationship with undeath is complex, but I am not here to hurt our own. Help me show the others this. Venture to Night's Web Hollow to the northwest and free the freshly raised fools trapped by the spiders there.",
	  "Selamlar, rahip. Evet, ben bir paladinim. Ölüm bile Işık'ı durduramaz.\r\n\r\nBu, bizim türümüzün tüm Forsaken'larla ortak noktası--yaşayanların son saydığı şeyin üstesinden geldik. Yine de kendi aramızdan bazıları bile bizden korkuyor; onları bir canavarmışız gibi cezalandıracağımızdan şüpheleniyorlar.\r\n\r\nAslında ölümsüzlükle ilişkimiz karmaşık, ama ben kendi halkımıza zarar vermeye gelmedim. Bunu diğerlerine göstermeme yardım et. Kuzeybatıdaki Night's Web Hollow'a git ve oradaki örümceklerin tuzağına düşmüş, yeni diriltilmiş aptalları kurtar." },
})

-- Karanlıkta Bir Işık (98389) teslim metni
gorev(nil, nil, {
	{ "May this help Executor Arren and so many others see our true nature. Much like in our past lives, we live to serve our people--to protect them with the gifts the Light provides us.\r\n\r\nThey will see in time that we are just as valuable to the Dark Lady's plans as any other.\r\n\r\nLight be with you.",
	  "Bu, Executor Arren'ın ve daha nice kişinin gerçek doğamızı görmesine yardımcı olsun. Geçmiş hayatlarımızda olduğu gibi, halkımıza hizmet etmek için yaşıyoruz--onları Işık'ın bize bahşettiği armağanlarla korumak için.\r\n\r\nZamanla bizim de Kara Leydi'nin planları için diğerleri kadar değerli olduğumuzu görecekler.\r\n\r\nIşık seninle olsun." },
})

-- Gelen: ek görev metinleri
gorev(nil, nil, {
	{ "I can train you if you have the aptitude.",
	  "Yeteneğin varsa seni eğitebilirim." },
	{ "I appreciate your efforts, Someburger.  May Sylvanas recognize your bravery one day. . . .",
	  "Çabalarını takdir ediyorum, Someburger. Umarım Sylvanas bir gün cesaretini tanır. . . ." },
	{ "What beautiful things did you bring me?",
	  "Bana ne güzel şeyler getirdin?" },
})
