local A = WoWTurkce.BuyuAdi
if A["Walk on Air"] == nil then A["Walk on Air"] = "Havada Yürü" end
for k, v in pairs({["Skysight"]="Gök Görüşü",["Elemental Insight"]="Element Sezgisi",["Armor Proficiency"]="Zırh Ustalığı",["Wind Blessed"]="Rüzgâr Kutsaması"}) do if A[k] == nil then A[k] = v end end
