local _, addonTbl = ...
local L = addonTbl.API:NewLocale("BigWigs: Common", "enUS")

-- Prototype.lua common words
L.you = "%s SENDE"
L.you_icon = "%s |T13700%d:0|tSENDE"
L.underyou = "%s ALTINDA"
L.aboveyou = "%s ÜSTÜNDE"
L.other = "%s: %s"
L.onboss = "%s BOSSTA"
L.buff_boss = "BOSSTA güçlendirme: %s"
L.buff_other = "%s üzerinde güçlendirme: %s"
L.magic_buff_boss = "BOSSTA büyü güçlendirmesi: %s" -- Magic buff on BOSS: SPELL_NAME
L.magic_buff_other = "%s üzerinde büyü güçlendirmesi: %s" -- Magic buff on NPC_NAME: SPELL_NAME
L.on = "%s, %s üzerinde"
L.stack = "%dx %s, %s üzerinde" -- "5x SPELL_NAME on PLAYER_OR_NPC" showing how many stacks of a buff/debuff are on a player or NPC
L.stackyou = "%dx %s SENDE" -- "5x SPELL_NAME on YOU" showing how many stacks of a buff/debuff are on you
L.stackboss = "%dx %s BOSSTA" -- "5x SPELL_NAME on BOSS" showing how many stacks of a buff/debuff are on the boss
L.stack_gained = "%dx kazanıldı" -- "Gained 5x" for situations where we show how many stacks of a buff were gained since last time a message showed
L.cast = "<Büyü: %s>"
L.casting = "%s yapılıyor"
L.soon = "%s yakında"
L.count = "%s (%d)"
L.count_amount = "%s (%d/%d)"
L.count_icon = "%s (%d|T13700%d:0|t)"
L.count_rticon = "%s (%d{rt%d})"
L.rticon = "%s ({rt%d})"
L.near = "%s YAKININDA"
L.on_group = "%s GRUPTA"
L.boss = "BOSS"
L.plus = "%s + %s" -- Spell 1 + Spell 2
L.extra = "%s (%s)" -- SPELL_NAME (short spell name or extra information)

L.phase = "Aşama %d"
L.stage = "Aşama %d"
L.wave = "Dalga %d" -- e.g. "Wave 1" (Waves of adds)
L.wave_count = "Dalga %d / %d" -- Wave 1 of 3 (Usually waves of adds)
L.normal = "Normal mod"
L.heroic = "Heroic mod"
L.mythic = "Mythic mod"
L.hard = "Zor mod"
L.active = "Etkin" -- When a boss becomes active, after speech finishes
L.ready = "Hazır" -- When a player is ready to do something
L.dead = "Ölü" -- When a player is dead
L.general = "Genel" -- General settings, i.e. things that apply to normal, heroic and mythic mode.
L.health = "Can" -- The health of an NPC
L.health_percent = "%%%d Can" -- "10% Health" The health percentage of an NPC
L.energy = "Enerji"
L.energy_percent = "%%%d Enerji" -- "80% Energy" The energy percentage of an NPC
L.door_open = "Kapı açık" -- When a door is open, usually after a speech from an NPC
L.gate_open = "Geçit açık" -- When a gate is open, usually after a speech from an NPC
L.threat = "Tehdit"

L.remaining = "%d kaldı" -- 5 remaining
L.duration = "%s, %s sn boyunca" -- Spell for 10 seconds
L.over = "%s bitti" -- Spell over
L.removed = "%s kaldırıldı" -- Spell removed
L.removed_from = "%s, %s üzerinden kaldırıldı" -- Spell removed from Player
L.removed_by = "%s, %s tarafından kaldırıldı" -- Spell removed by Player
L.removed_after = "%s %.1fs sonra kaldırıldı" -- "Spell removed after 1.1s" (s = seconds)
L.incoming = "%s geliyor" -- Spell incoming
L.interrupted = "%s kesildi" -- Spell interrupted
L.interrupted_by = "%s, %s tarafından kesildi" -- Spell interrupted by Player
L.interruptible = "Kesilebilir" -- when a spell is interruptible
L.no = "%s yok" -- No Spell
L.intermission = "Ara Aşama"
L.intermission_over = "Ara aşama bitti"
L.percent = "%d%% - %s" -- 20% - Spell
L.cancelled = "%s iptal edildi" -- Spell cancelled
L.you_die = "Öleceksin" -- You will die
L.you_die_sec = "%d sn içinde öleceksin" -- "You die in 15 sec" (sec = seconds)
L.next_ability = "Sonraki yetenek" -- We don't know what ability will be next, we only know when it will happen (showing a bar)
L.boss_landing = "%s iniyor" -- "NPC_NAME is landing" Used when a flying NPC/dragon/boss is landing
L.landing = "İniş" -- Used when a flying NPC/dragon/boss is landing
L.flying_available = "Artık uçabilirsin"
L.bosses_too_close = "Bosslar çok yakın" -- When 2 or more bosses are too close to each other, buffing each other with a shield, extra damage, etc.
L.keep_moving = "Hareket etmeye devam et" -- An ability that forces you to keep moving or you will take damage
L.stand_still = "Yerinde dur" -- An ability that forces you to stand still or you will take damage
L.safe_to_stop = "Durmak güvenli" -- When an ability that forces you to keep moving fades from you, allowing you to stop moving
L.safe_to_move = "Hareket etmek güvenli" -- When an ability to forces you to stand still fades from you, allowing you to move again
L.safe = "Güvenli" -- You are safe from a bad ability
L.unsafe = "Güvensiz" -- You are unsafe (in danger) of a bad ability

-- Add related
L.add_spawned = "Ek düşman doğdu" -- singular
L.adds_spawned = "Ek düşmanlar doğdu" -- plural
L.adds_spawned_count = "%d ek düşman doğdu" -- 1 add spawned / 2 adds spawned
L.add_spawning = "Ek düşman doğuyor" -- singular
L.adds_spawning = "Ek düşmanlar doğuyor" -- plural
L.add_incoming = "Ek düşman geliyor" -- singular
L.adds_incoming = "Ek düşmanlar geliyor" -- plural
L.spawned = "%s doğdu"
L.spawning = "%s doğuyor"
L.next_add = "Sonraki Ek Düşman"
L.add_killed = "Ek düşman öldü (%d/%d)"
L.add_remaining = "Ek düşman öldü, %d kaldı"
L.add = "Ek Düşman"
L.adds = "Ek Düşmanlar"
L.big_add = "Büyük Add" -- singular
L.big_adds = "Büyük Add'ler" -- plural
L.small_add = "Küçük Ek Düşman" -- singular
L.small_adds = "Küçük Ek Düşmanlar" -- plural
L.eat_adds = "Ek Düşmanları Ye" -- When a boss is going to eat/consume any adds remaining to empower/heal itself. Usually this is a timer. You have to kill all adds in X seconds or they will be eaten.

-- Mob related
L.killed = "%s öldü"
L.mob_killed = "%s öldü (%d/%d)"
L.mob_remaining = "%s öldü, %d kaldı"

-- NPCs for follower dungeons
L.garrick = "Captain Garrick" -- AI paladin tank (NPC 209057)
L.garrick_short = "*Garrick"
L.meredy = "Meredy Huntswell" -- AI mage dps (NPC 209059)
L.meredy_short = "*Meredy"
L.shuja = "Shuja Grimaxe" -- AI shaman dps (NPC 214390)
L.shuja_short = "*Shuja"
L.crenna = "Crenna Earth-Daughter" -- AI druid healer (NPC 209072)
L.crenna_short = "*Crenna"
L.austin = "Austin Huxworth" -- AI hunter dps (NPC 209065)
L.austin_short = "*Austin"
L.breka = "Warlord Breka Grimaxe" -- AI warrior tank (NPC 215517)
L.breka_short = "*Breka"
L.henry = "Henry Garrick" -- AI priest healer (NPC 215011)
L.henry_short = "*Henry"

-- Localizers note:
-- The default mod:Berserk(600) uses spell ID 26662 to get the Berserk name
L.custom_start = "%s başladı - %s %d dk içinde"
L.custom_start_s = "%s başladı - %s %d sn içinde"
L.custom_end = "%s %s oluyor"
L.custom_min = "%s %d dk içinde"
L.custom_sec = "%s %d sn içinde"

L.focus_only = "|cffff0000Yalnızca odak hedefi uyarıları.|r "
L.trash = "Çöp Düşmanlar"
L.affixes = "Ekler (Affix)" -- Seasonal affixes for raids and mythic+ dungeons

-- GUI boss dropdown for cast counters
-- Cast counters are the numbers you see next to spell names that keep increasing e.g. "Bad Spell (3)" <-- that number
-- This dropdown option will let you choose when that number should reset back to 1
L.counter_reset_name = "%s büyü sayacı" -- SPELL_NAME cast counter
L.counter_reset_desc = "Sayacın ne zaman sıfırlanacağını seçin."
L.reset_casts = "Her %d büyüde sıfırla" -- Reset every 3 casts
L.reset_stages = "Aşama değişince sıfırla"
L.reset_casts_and_stages = "Her %d büyüde ve aşama değişince sıfırla"
L.reset_never = "Asla sıfırlama"

-- Common raid marking locale
L.marker = "%s işareti"
L.marker_player_desc = "'%s' etkisindeki oyuncuları %s ile işaretle; yardımcı veya lider olmak gerekir." -- Mark players affected by 'SPELL_NAME' with SKULL_ICON
L.marker_npc_desc = "%s hedefini %s ile işaretle; yardımcı veya lider olmak gerekir." -- Mark NPC_NAME with SKULL_ICON
L.marker_npc_aura_desc = "'%s' etkisindeki NPC'leri %s ile işaretle; yardımcı veya lider olmak gerekir." -- Mark NPCs affected by 'SPELL_NAME' with SKULL_ICON
L.disabled = "Devre Dışı"
L.none = "Yok"
L.markers = "İşaretler" -- Plural of marker

-- Ability where two players have to move close to each other
L.link = "Bağlantı"
L.link_with = "%s ile bağlandın"
L.link_with_icon = "|T13700%d:0|t%s ile bağlandın"
L.link_with_rticon = "{rt%d}%s ile bağlandın"
L.link_both = "%s + %s bağlandı"
L.link_both_icon = "|T13700%d:0|t%s + |T13700%d:0|t%s bağlandı"
L.link_removed = "Bağ kalktı"
L.link_say_option_name = "Tekrarlanan 'Bağlandı' söyleme mesajları"
L.link_say_option_desc = "Kiminle bağlandığınızı belirten, sohbette tekrarlanan söyleme mesajları."

-- Abbreviated numbers
L.amount_one = "%dB" -- Billions 1,000,000,000
L.amount_two = "%dM" -- Millions 1,000,000
L.amount_three = "%dK" -- Thousands 1,000
L.seconds = "%.1fs" -- 1.1 seconds

-- Directions
L.top = "Üst"
L.top_right = "Sağ Üst"
L.top_left = "Sol Üst"
L.up = "Yukarı"
L.middle = "Orta"
L.down = "Aşağı"
L.bottom = "Alt"
L.bottom_right = "Sağ Alt"
L.bottom_left = "Sol Alt"
L.left = "Sol"
L.right = "Sağ"
L.north = "Kuzey"
L.north_east = "Kuzeydoğu"
L.east = "Doğu" -- I thought you said weast!
L.south_east = "Güneydoğu"
L.south = "Güney"
L.south_west = "Güneybatı"
L.west = "Batı"
L.north_west = "Kuzeybatı"

-- Sizes
L.small = "Küçük"
L.medium = "Orta"
L.large = "Büyük"

-- Schools
L.fire = "Ateş"
L.frost = "Buz"
L.shadow = "Gölge"
L.nature = "Doğa"
L.arcane = "Arkan"

-- Autotalk
L.autotalk = "Otomatik NPC etkileşimi"
L.autotalk_boss_desc = "Boss savaşını başlatan NPC konuşma seçeneklerini otomatik seç."
L.autotalk_generic_desc = "Zindanın sonraki aşamasına geçmenizi sağlayan NPC konuşma seçeneklerini otomatik seç."
L.autotalk_notice = "NPC %s ile otomatik etkileşim kuruluyor."

-- Auto Player Choice
L.autoPlayerChoice = "Otomatik Oyuncu Seçimi"
L.autoPlayerChoice_delve_power_desc = "Delve'de yaratıklardan düşen oyuncu güçlendirmelerini otomatik seç."
L.autoPlayerChoice_notice = "Otomatik seçiliyor: %s"

-- GUI notes
L.intermissionOnly = "Yalnızca Ara Aşama" -- A note to explain that a specific ability only happens during the intermission stage of a boss fight
L.stage1Only = "Yalnızca Aşama 1" -- A note to explain that a specific ability only happens during stage 1 of a boss fight
L.stage2Only = "Yalnızca Aşama 2"
L.stage3Only = "Yalnızca Aşama 3"

-- GUI notes for renames
L.generalNote = "Genel olarak kullanılacak metin budur"
L.timerNote = "Bu metin zamanlayıcılar için kullanılacak"
L.castTimerNote = "Bu metin yalnızca büyü zamanlayıcıları için kullanılacak"
L.messageCastOverNote = "Bu metin büyü bittiğinde mesaj göstermek için kullanılacak"
L.messageCastStartNote = "Bu metin büyü başladığında mesaj göstermek için kullanılacak"
L.messageBeforeCastStartNote = "Bu metin büyü başlamadan önce mesaj göstermek için kullanılacak"
L.messageDuringCastNote = "Bu metin büyü sırasında mesaj göstermek için kullanılacak"
L.messageNote = "Bu metin mesajlar için kullanılacak"
L.messageOnYouNote = "Bu yetenek sendeyken gösterilen mesaj"
L.messageOnOtherNote = "Bu yetenek başkalarındayken gösterilen mesaj"
L.messageTauntNowNote = "Tank olduğunuzda ve kışkırtmanız gerektiğinde gösterilen mesaj"
L.messageSpecificHealth = "Boss yüzde %d candayken gösterilen mesaj"
L.timerOnYouNote = "Bu yetenek sendeyken zamanlayıcıda gösterilen metin"
L.mythicOnlyNote = "Bu metin yalnızca Mythic'te kullanılacak"
L.otherDifficultiesNote = "Bu metin diğer tüm zorluklarda kullanılacak"

-- GUI notes for debuffs
L.debuffFailureNote = "Başarısız olursanız bu zayıflatma size uygulanır"
L.debuffFailureMoveFromExplosionNote = "Patlamadan uzaklaşamazsanız bu zayıflatma size uygulanır"
L.debuffFailureInterruptNote = "|cFFFFFFFF%s|r büyüsünü kesemezseniz bu zayıflatma size uygulanır" -- This debuff will apply to you if you fail to interrupt the cast of SPELL_NAME
L.debuffFailureMoveFromCastNote = "|cFFFFFFFF%s|r büyüsünden çıkamazsanız bu zayıflatma size uygulanır" -- This debuff will apply to you if you fail to move out of the SPELL_NAME cast
L.debuffFailureGroupSoakNote = "Grubunuz |cFFFFFFFF%s|r üstüne giremezse bu zayıflatma size uygulanır" -- This debuff will apply to you if your group fails to soak SPELL_NAME
L.debuffFailureSafeZoneNote = "Güvenli bölgede duramazsanız bu zayıflatma size uygulanır"
L.debuffHitByOtherPlayerNote = "Başka bir oyuncunun |cFFFFFFFF%s|r büyüsü size çarparsa bu zayıflatma size uygulanır" -- This debuff will apply to you if you are hit by another player's SPELL_NAME
L.debuffTargetedNote = "|cFFFFFFFF%s|r için hedef alınırsanız bu zayıflatma size uygulanır" -- This debuff will apply to you if you are being targeted for SPELL_NAME
L.preDebuffNote = "Bu ön zayıflatmadır; asıl zayıflatma size uygulanmadan önce gelir"
L.mainDebuffNote = "Bu size uygulanan asıl zayıflatmadır"
L.postDebuffNote = "|cFFFFFFFF%s|r süresi bitince bu zayıflatma size uygulanır" -- This debuff will apply to you after OTHER_DEBUFF expires
L.debuffUnderYouNote = "Kötü bir yerde durursanız bu zayıflatma size uygulanır" -- Usually when a player is standing in a pool of something bad, a debuff will apply to them
L.debuffDotAfterCastNote = "Bu zayıflatma, |cFFFFFFFF%s|r büyüsünden sonra gelen zamanla hasar etkisidir" -- This debuff is a damage over time effect after the SPELL_NAME cast
L.debuffPossibleAfterCastNote = "|cFFFFFFFF%s|r büyüsünden sonra bu zayıflatma size uygulanabilir" -- This debuff might apply to you after the SPELL_NAME cast
L.debuffTankAfterCastNote = "|cFFFFFFFF%s|r büyüsünden sonra bu zayıflatma tanka uygulanır" -- This debuff will apply to the tank after the SPELL_NAME cast
L.debuffGroupAfterCastNote = "|cFFFFFFFF%s|r büyüsünden sonra bu zayıflatma tüm gruba uygulanır" -- This debuff will apply to the entire group after the SPELL_NAME cast
L.debuffWalkIntoObjectNote = "|cFFFFFFFF%s|r içine bilerek yürürseniz bu zayıflatma size uygulanır" -- This debuff will apply to you if you purposely walk into the OBJECT_NAME (e.g. trap, mine, bomb)
L.debuffHitByCastNote = "|cFFFFFFFF%s|r büyüsü size çarparsa bu zayıflatma size uygulanır" -- This debuff will apply to you if you are hit by the the SPELL_NAME cast
L.debuffAddsCast = "Bu zayıflatma size |cFFFFFFFF%s|r tarafından uygulanır" -- This debuff is applied to you by NPC_NAME
L.debuffPickupNote = "|cFFFFFFFF%s|r öğesini alırsanız bu zayıflatma size uygulanır" -- This debuff will apply to you if you pick up the OBJECT_NAME

-- Common ability name replacements
L.laser = "Lazer" -- Used for abilities that act like a laser. Usually from the boss to a player, or, from the boss to a specific area
L.lasers = "Lazerler" -- Plural of L.lasers
L.beam = "Işın" -- Similar to "Laser" (a beam from boss to player/boss to area) but can be used to better describe certain abilities that don't look like a Laser
L.beams = "Işınlar" -- Plural of L.beam
L.bomb = "Bomba" -- Used for debuffs that make players explode
L.bombs = "Bombalar" -- Plural of L.bomb
L.explosion = "Patlama" -- When the explosion from a bomb-like ability will occur
L.explosions = "Patlamalar" -- Plural of L.explosion
L.knockback = "Geri İtme" -- Used when an ability knocks players away from a certain point, like a "smash" type ability that knocks you back 10 meters
L.knockbacks = "Geri İtmeler" -- Plural of L.knockback
L.pushback = "Geri İtme" -- Used when an ability slowly and continually pushes a player away, like winds gradually pushing you away over time
L.traps = "Tuzaklar" -- Used for abilities that act like traps on the floor e.g. move into it and something bad happens like you die, or are rooted, etc.
L.meteor = "Meteor" -- This one will probably only ever be used for actual meteors
L.teleport = "Işınlanma" -- A boss/add/etc teleported somewhere
L.breath = "Nefes" -- When a boss breathes fire/frost/etc on to a player or the raid e.g. a Dragon breathing fire on everyone
L.roar = "Kükreme" -- When a boss opens their mouth to let out a loud roar, sometimes used to inflict damage on the raid
L.leap = "Sıçrama" -- When a boss leaps through the air from one location to another location, or from a location to a player, etc
L.charge = "Hücum" -- When a boss select a new target and charges at it quickly, in the same way someone playing a warrior can charge at a target
L.full_energy = "Tam Enerji" -- When a boss reaches full/maximum energy, usually the boss will cast something big and powerful when this happens
L.weakened = "Zayıfladı" -- When a boss becomes weakened and sometimes takes extra damage, usually the "hit all your cooldowns" part of the fight
L.immune = "Bağışık" -- When a boss becomes immune to all damage and you can no longer hurt it
L.stunned = "Sersemledi" -- When a boss becomes stunned and cannot cast abilities or move
L.pool = "Havuz" -- A pool or puddle on the ground, usually something bad that you should avoid standing in
L.pools = "Havuzlar" -- Plural of L.pool
L.totem = "Totem" -- A totem, usually summoned by a boss, the same thing that shamans summon
L.totems = "Totemler" -- Plural of L.totem
L.portal = "Geçit" -- A portal somewhere, usually leading to a different location
L.portals = "Portallar" -- Plural of L.portal
L.rift = "Yarık" -- Can be used in a similar way as a portal e.g. "Time Rift" but can also be used as a debuff/pool underneath you that you need to run through to remove/despawn it e.g. "Dread Rift"
L.rifts = "Yarıklar" -- Plural of L.rift
L.orb = "Küre" -- A ball/sphere object usually moving and you need to avoid it
L.orbs = "Küreler" -- Plural for L.orb
L.spirit = "Ruh" -- Sometimes a boss will summon spirits, similar to ghosts, but not exactly, although you might have the same word for both. e.g. "Spirits of X" or "Wild Spirits"
L.spirits = "Ruhlar" -- Plural of L.spirit
L.tornado = "Hortum" -- 'A tornado is a violently rotating column of air that is in contact with both the surface of the Earth and a cloud' - Wikipedia
L.tornadoes = "Hortumlar" -- Plural of L.tornado
L.mark = "İşaret" -- Short name for abilites with "Mark" in the name, for example "Mark of Death" or "Toxic Mark" or "Mark of Frost" etc.
L.marks = "İşaretler" -- Plural of L.marks
L.mind_control = "Zihin Kontrolü" -- Any kind of Mind Control ability, where a player loses control of their character
L.mind_control_short = "ZK" -- Short version of Mind Control, mainly for bars
L.spell_reflection = "Büyü Yansıtma" -- Any ability that reflects spells
L.rooted = "Kökleşti" -- Any ability that roots you in place, preventing you from moving

-- Common ability name replacements A-Z
L.arrow = "Ok" -- Any type of ability that looks like an arrow, or has "arrow" in the name. Like an archer's arrow.
L.arrows = "Oklar" -- Plural of L.arrow
L.ball = "Top" -- A ball, like a football, basketball, etc
L.balls = "Toplar" -- Plural of L.ball
L.blind = "Kör" -- Any ability that blinds or disorientates you. Usually an ability a boss casts and you need to turn away from the boss or it will blind you.
L.blood = "Kan" -- Short for any ability with the name "Blood" in it e.g. "Blood Infusion" (1293969) or "Blood Hunter" (1225274)
L.bouncing_ball = "Seken Top" -- A ball, but it bounces, usually you need to prevent it touching the ground so it bounces to a different location
L.bouncing_balls = "Seken Toplar" -- Plural of L.bouncing_ball
L.chakram = "Çakram" -- Short for any ability with the name "Chakram" in it e.g. "Wind Chakram" (1258152) or "Solar Chakram" (186046)
L.dodge = "Sıyrılma" -- When you need to continually run around to dodge abilities, like missiles landing on the ground under you
L.enrage = "Öfke" -- Any enrage buff that can be removed by players using abilities like Soothe (Druid), Tranquilizing Shot (Hunter) and Shiv (Rogue)
L.fear = "Korku" -- Similar to a warlock or priest ability, when a boss casts a fear on a player or multiple players, that makes them run around out of control
L.fixate = "Odaklanma" -- Used when a boss or add is chasing/fixated on a player
L.fixates = "Odaklanmalar" -- Plural of L.fixate
L.frontal = "Önden Saldırı" -- Usually a bad Area-of-Effect ability cast by the boss in front of them
L.frontal_cone = "Ön Koni" -- Usually a bad Area-of-Effect ability cast by the boss in a cone/triangle/pizza shape in front of them, don't stand in front of the boss!
L.grip = "Çekme" -- When a boss grapples a player towards them. We use "Grip" because of the Death Knight ability "Death Grip" (49576) but you can use "Grapple" if it makes more sense
L.grips = "Çekmeler" -- Plural of L.grip
L.group_damage = "Grup Hasarı" -- Any ability that causes damage to every player in the 5 player group
L.health_drain = "Can Emme" -- Any ability that drains health from the player
L.madness = "Delilik" -- Any ability that contains the word "Madness" in it e.g. "Rift Madness" (1264756) or "Burning Madness" (307013)
L.miasma = "Miasma" -- Any ability that contains the word "Miasma" in it e.g. "Consuming Miasma" (1257087) or "Black Miasma" (1275059)
L.missile = "Füze" -- Short for any ability with the name "Missile" in it e.g. "Fey Missile" (188046) or "Water Missile" (68250)
L.missiles = "Füzeler" -- Plural of L.missile
L.parasite = "Parazit" -- Any ability where a parasite is involved e.g. "Parasitic Infection", "Parasitic Growth", etc
L.parasites = "Parazitler" -- Plural of L.parasite
L.pull_in = "İçeri Çekme" -- An ability that pulls you in towards the boss against your will
L.quills = "Dikenler" -- Short for any ability with the name "Quills" in it e.g. "Searing Quills" (159382) or "Infused Quills" (1242260)
L.raid_damage = "Raid Hasarı" -- Any ability that causes damage to every player in the raid
L.silence = "Susturma" -- Any ability that silences a player, preventing their spells being cast
L.smash = "Ezme" -- Short for any ability with the name "smash" in it e.g. "Darkrift Smash" or "Seismic Smash" or "Arcing Smash"
L.soak = "Soak" -- Abilities you have to stand in on purpose to soak the damage, like a sponge soaks water. Commonly for abilities that split damage between everyone standing in them.
L.soaks = "Soak'lar" -- Plural of L.soak
L.spike = "Diken" -- Short for any ability with the name "spike" in it e.g. "Glacial Spike" or "Fel Spike" or "Volatile Spike"
L.spikes = "Dikenler" -- Plural of L.spike
L.spread = "Dağıl" -- An ability that forces you to spread out away from other players, or you might damage them
L.stomp = "Tepinme" -- Short for any ability with the name "Stomp" in it e.g. "Cryostomp" (1261847) or "Powerful Stomp" (296691)
L.tentacle = "Dokunaç" -- Used for bosses that summon tentacles
L.tentacles = "Dokunaçlar" -- Plural of L.tentacle
L.vines = "Sarmaşıklar" -- Short for any ability with the name "Vines" in it e.g. "Festering Vines" (1222088) or "Choking Vines" (238593)
L.waves = "Dalgalar" -- Multiple waves of a bad ability coming from a boss, like waves in the ocean
L.winds = "Rüzgârlar" -- Short for any ability with the name "Winds" in it e.g. "Winds of Change" (381517)
L.whelp = "Yavru Ejder" -- Short for Whelpling, a baby dragonkin (Dragon Whelp)
L.whelps = "Yavru Ejderler" -- Plural of L.whelp

-- Absorb / Shield related spell renames
L.absorb = "Emme" -- Used for shield-like abilities that absorb damage or healing
L.heal_absorb = "İyileştirme Emilimi" -- Used for shield-like abilities that absorb healing only
L.heal_absorbs = "İyileştirme Emilimleri" -- Plural of L.heal_absorb
L.break_shield = "Kalkanı Kır" -- When you need to do something to break an absorb shield on the boss.
L.break_shields = "Kalkanları Kır" -- Plural of L.break_shield
L.shield = "Kalkan" -- Abilities that absorb damage/healing creating a "shield" around the boss/player e.g. "Shield on boss" or "Shield remaining"

-- Debuff-related spell renames
L.debuff = "Zayıflatma"
L.debuffs = "Zayıflatmalar" -- Plural of L.debuff
L.fire_debuffs = "Ateş Zayıflatmaları"

-- Dispel-related spell renames
L.curse = "Lanet" -- Any curse-type dispellable debuff, or debuffs called "Curse of XYZ", etc.
L.curses = "Lanetler" -- Plural of L.curse
L.disease = "Hastalık" -- Any disease-type dispellable debuff, or debuffs called "Disease of XYZ", etc.
L.dispel = "Arındır" -- General term for any debuff that is dispellable
L.dispels = "Arındırmalar" -- Plural of L.dispel
L.dispel_boss = "Bossu Arındır" -- When the boss gains a buff (magic or enrage) that you need to dispel
L.poison = "Zehir" -- Any poison-type dispellable debuff, or debuffs called "Poison of XYZ", etc.
L.bleed = "Kanama" -- Any bleed-type debuff
L.bleeds = "Kanamalar" -- Plural of L.bleed

-- Clearing-related spell renames (when you get a buff that allows you to clear/cleanse/remove other objects in the world, like pools on the ground, traps, or bombs)
L.clear_bombs = "Bombaları Temizle"
L.clear_pools = "Havuzları Temizle"

-- Interrupt-related spell renames
L.interrupts = "Kesmeler" -- General term used when a player needs to interrupt a spell being cast
L.kick = "Kes" -- General term used when a player needs to interrupt a spell being cast, named after spell "Kick" (1766) from the Rogue class
L.kicks = "Kesmeler" -- Plural of L.kick

-- Tank-related spell renames
L.tank_bomb = "Tank Bombası" -- Similar to L.bomb but only applies to tanks
L.tank_combo = "Tank Kombosu" -- Used for tank swap mechanics where the boss casts a sequence of tank buster attacks
L.tank_debuff = "Tank Debuff'ı" -- Used for debuffs that only apply to tanks, usually an indicator that you need to taunt
L.tank_frontal = "Tank Önü" -- Similar to L.frontal_cone but only applies to tanks
L.tank_hit = "Tank Vuruşu" -- An attack that will only target the tank, usually a spell that does a lot of heavy damage to the tank
L.tank_knockback = "Tank Geri İtme" -- Similar to L.knockback but only applies to tanks"
L.tank_soak = "Tank Soak" -- Similar to L.soak but only applies to tanks
L.tank_grip = "Tank Çekme" -- When a boss grapples the tank towards them. We use "Grip" because of the Death Knight ability "Death Grip" (49576) but you can use "Grapple" if it makes more sense

-- Aura Sections
L.important = "Önemli" -- High priority debuffs
L.achievement = "Başarım: \"%s\"" -- Debuff related to an achievement
L.damage = "Hasar" -- Debuff is just damage
L.failed = "Başarısız" -- Debuff indicates a mechanics failure
