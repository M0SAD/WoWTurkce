local mod	= DBM:NewMod("CaptainDreadrise", "DBM-Party-Forever", 5)

mod:SetRevision("20261109015934")
mod:EnableGenericTrash()
mod:SetEncounterID(3476)
mod:SetModelID(142144)
mod:SetZone(2970)

mod:RegisterCombat("combat")
