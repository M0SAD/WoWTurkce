-- Uçuş süreleri: uçuş haritasında her noktanın ipucuna süre yazar, uçarken kalan süreyi gösterir.
-- Süreler yapılan uçuşlardan öğrenilir (WoWTurkce_Ayar.ucusSure). Bilinmeyen rotalar mesafeden tahmin edilir;
-- tahmin her gerçek uçuşla kıtaya göre kalibre edilir (WoWTurkce_Ayar.ucusOran / ucusOrnek); bölüm süreleri
-- (ucusParca) öğrenildikçe aktarmalı rotalar bilinen bölümlerin toplamından hesaplanır.
local G = WoWTurkce

-- Kıta haritası boyutu (yarda) ve uçuş hızı; kalibrasyon yokken kaba tahmin için
local KITA = { [1414] = { 36799.81, 24533.20 }, [1415] = { 40741.18, 27149.69 }, [1945] = { 17464.08, 11642.72 }, [113] = { 17751.39, 11834.27 } }
local VARSAYILAN_KITA = { 38000, 25000 }
local HIZ = 32 * 0.85 -- yarda/sn, rota kıvrımları için düşürüldü

local function db()
	WoWTurkce_Ayar = WoWTurkce_Ayar or {}
	WoWTurkce_Ayar.ucusSure = WoWTurkce_Ayar.ucusSure or {}
	WoWTurkce_Ayar.ucusOran = WoWTurkce_Ayar.ucusOran or {}
	WoWTurkce_Ayar.ucusParca = WoWTurkce_Ayar.ucusParca or {}  -- tek atlamalı bölüm süreleri: ["A>B"] = sn
	WoWTurkce_Ayar.ucusOrnek = WoWTurkce_Ayar.ucusOrnek or {}  -- [kıta] = { {uzunluk, süre, atlama}, ... } (son 40 uçuş)
	return WoWTurkce_Ayar
end

local function sureYaz(s)
	s = math.floor(s + 0.5)
	local dk, sn = math.floor(s / 60), s % 60
	if dk == 0 then return sn .. " sn" end
	if sn == 0 then return dk .. " dk" end
	return dk .. " dk " .. sn .. " sn"
end

local function kita()
	if not (C_Map and C_Map.GetBestMapForUnit) then return 0 end
	local id = C_Map.GetBestMapForUnit("player")
	local n = 0
	while id and n < 10 do
		local b = C_Map.GetMapInfo(id)
		if not b then break end
		if b.mapType == 2 then return id end -- Enum.UIMapType.Continent
		id = b.parentMapID; n = n + 1
	end
	return 0
end

local function anaNokta()
	for i = 1, NumTaxiNodes() do
		if TaxiNodeGetType(i) == "CURRENT" then return i end
	end
end

-- Rotanın kıta haritasındaki uzunluğu (normal birim) ve yarda karşılığı
local function rotaUzunluk(hedef)
	local hop = GetNumRoutes and GetNumRoutes(hedef) or 0
	if hop <= 0 then return nil end
	local k = KITA[kita()] or VARSAYILAN_KITA
	local top = 0
	for h = 1, hop do
		local sx, sy, dx, dy = TaxiGetSrcX(hedef, h), TaxiGetSrcY(hedef, h), TaxiGetDestX(hedef, h), TaxiGetDestY(hedef, h)
		if not (sx and sy and dx and dy) then return nil end
		local x, y = (dx - sx) * k[1], (dy - sy) * k[2]
		top = top + math.sqrt(x * x + y * y)
	end
	return top
end

local function anahtar(a, b) return a .. ">" .. b end

-- Rotanın atlama noktaları (ad listesi): kaynak, ara duraklar, hedef
local function rotaNoktalari(hedef)
	local hop = GetNumRoutes and GetNumRoutes(hedef) or 0
	if hop <= 0 or not TaxiGetNodeSlot then return nil end
	local liste = {}
	for h = 1, hop do
		local ok1, a = pcall(TaxiGetNodeSlot, hedef, h, true)
		local ok2, b = pcall(TaxiGetNodeSlot, hedef, h, false)
		if not (ok1 and ok2 and a and b) then return nil end
		if h == 1 then liste[1] = TaxiNodeName(a) end
		liste[#liste + 1] = TaxiNodeName(b)
	end
	return liste
end

-- Bölüm süresi (iki yönden biri biliniyorsa)
local function parca(d, a, b)
	return d.ucusParca[anahtar(a, b)] or d.ucusParca[anahtar(b, a)]
		or d.ucusSure[anahtar(a, b)] or d.ucusSure[anahtar(b, a)]
end

-- Kıtadaki gerçek uçuşlardan süre = sabit + eğim × uzunluk (en küçük kareler); az örnekte orana düşer
local function modelTahmin(d, k, uz, hop)
	local ornek = d.ucusOrnek[k]
	if ornek and #ornek >= 4 then
		local n, sx, sy, sxx, sxy = 0, 0, 0, 0, 0
		for _, o in ipairs(ornek) do
			local x, y = o[1], o[2]
			n = n + 1; sx = sx + x; sy = sy + y; sxx = sxx + x * x; sxy = sxy + x * y
		end
		local pay = n * sxx - sx * sx
		if pay > 0 then
			local b = (n * sxy - sx * sy) / pay
			local a = (sy - b * sx) / n
			if b > 0 and a > -30 and a < 90 then return math.max(10, a + b * uz) end
		end
	end
	local oran = d.ucusOran[k] or (1 / HIZ)
	return uz * oran + 8 * (hop or 1) -- kalkış/iniş ve ara dönüşler için küçük pay
end

-- Bilinen ya da tahmini süre: sure, tahminMi
-- Sıra: aynı rotanın gerçek süresi > ters yönü > bilinen bölümlerin toplamı > kıtaya kalibre mesafe modeli
local function sureBul(hedef)
	local ana = anaNokta()
	if not ana or hedef == ana then return nil end
	local d = db()
	local a, b = TaxiNodeName(ana), TaxiNodeName(hedef)
	local s = d.ucusSure[anahtar(a, b)] or d.ucusSure[anahtar(b, a)]
	if s then return s, false end
	local uz = rotaUzunluk(hedef)
	local k = kita()
	local noktalar = rotaNoktalari(hedef)
	if noktalar and #noktalar >= 2 then
		local top, eksik, eksikUz = 0, 0, 0
		for i = 1, #noktalar - 1 do
			local p = parca(d, noktalar[i], noktalar[i + 1])
			if p then top = top + p else eksik = eksik + 1 end
		end
		if eksik == 0 then return top, false end
		-- Bazı bölümler biliniyor: bilinmeyenleri orantılı tahmin et
		if top > 0 and uz and uz > 0 then
			local tumu = modelTahmin(d, k, uz, #noktalar - 1)
			local oranli = tumu * eksik / (#noktalar - 1)
			return top + oranli, true
		end
	end
	if not uz or uz <= 0 then return nil end
	return modelTahmin(d, k, uz, noktalar and (#noktalar - 1) or 1), true
end

-- Harita ipucuna süre satırı
local function ipucuEkle(btn)
	if not G.ayar("ucus") or not btn or not btn.GetID then return end
	local s, tahmin = sureBul(btn:GetID())
	if not s then return end
	if tahmin then
		GameTooltip:AddLine("Tahmini uçuş süresi: ~" .. sureYaz(math.floor(s / 5 + 0.5) * 5), 0.7, 0.7, 0.7)
	else
		GameTooltip:AddLine("Uçuş süresi: " .. sureYaz(s), 0.4, 1, 0.4)
	end
	GameTooltip:Show()
end
local baglandi = {}
local function dugmeleriBagla()
	if TaxiNodeOnButtonEnter then
		if not baglandi.fn then baglandi.fn = true; hooksecurefunc("TaxiNodeOnButtonEnter", ipucuEkle) end
		return
	end
	for i = 1, (NUM_TAXI_BUTTONS or 64) do
		local b = _G["TaxiButton" .. i]
		if b and not baglandi[b] then
			baglandi[b] = true
			b:HookScript("OnEnter", ipucuEkle)
		end
	end
end

-- Uçuş sırasında kalan süre çubuğu
local cubuk = CreateFrame("StatusBar", "WTR_UcusCubugu", UIParent)
cubuk:SetSize(240, 16)
cubuk:SetPoint("TOP", UIParent, "TOP", 0, -120)
cubuk:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
cubuk:SetStatusBarColor(0.2, 0.6, 1)
cubuk:SetMovable(true); cubuk:EnableMouse(true); cubuk:RegisterForDrag("LeftButton")
cubuk:SetClampedToScreen(true)
cubuk:SetScript("OnDragStart", function(self) if IsShiftKeyDown() then self:StartMoving() end end)
cubuk:SetScript("OnDragStop", function(self)
	self:StopMovingOrSizing()
	local _, _, _, x, y = self:GetPoint()
	db().ucusCubukYer = { x, y }
end)
cubuk:SetScript("OnEnter", function(self)
	GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
	GameTooltip:SetText("Uçuş süresi")
	GameTooltip:AddLine("Taşımak için Shift basılıyken sürükle.", 1, 1, 1)
	GameTooltip:Show()
end)
cubuk:SetScript("OnLeave", function() GameTooltip:Hide() end)
local zemin = cubuk:CreateTexture(nil, "BACKGROUND")
zemin:SetAllPoints(); zemin:SetColorTexture(0, 0, 0, 0.6)
local cerceve = CreateFrame("Frame", nil, cubuk, BackdropTemplateMixin and "BackdropTemplate" or nil)
cerceve:SetPoint("TOPLEFT", -3, 3); cerceve:SetPoint("BOTTOMRIGHT", 3, -3)
if cerceve.SetBackdrop then
	cerceve:SetBackdrop({ edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 10 })
	cerceve:SetBackdropBorderColor(0.6, 0.6, 0.6)
end
local yazi = cubuk:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
yazi:SetPoint("CENTER", 0, 1)
cubuk:Hide()

local aktif -- { kaynak, hedef, bas (GetServerTime), sure, tahmin, kita, uz }
local bekle = 0

local function bitir(indi)
	if not aktif then return end
	local d = db()
	if indi then
		local gecen = GetServerTime() - aktif.bas
		if gecen >= 5 then
			d.ucusSure[anahtar(aktif.kaynak, aktif.hedef)] = gecen
			local nk = aktif.noktalar
			if nk and #nk == 2 then
				d.ucusParca[anahtar(nk[1], nk[2])] = gecen
			elseif nk and #nk > 2 then
				-- Tek bilinmeyen bölüm varsa toplamdan çıkar ve öğren
				local top, bos = 0, nil
				for i = 1, #nk - 1 do
					local p = d.ucusParca[anahtar(nk[i], nk[i + 1])] or d.ucusParca[anahtar(nk[i + 1], nk[i])]
					if p then top = top + p elseif bos then bos = false else bos = i end
				end
				if bos and gecen - top >= 5 then d.ucusParca[anahtar(nk[bos], nk[bos + 1])] = gecen - top end
			end
			if aktif.uz and aktif.uz > 0 and aktif.kita then
				local yeni = gecen / aktif.uz
				local eski = d.ucusOran[aktif.kita]
				d.ucusOran[aktif.kita] = eski and (eski * 0.7 + yeni * 0.3) or yeni
				local o = d.ucusOrnek[aktif.kita] or {}
				o[#o + 1] = { aktif.uz, gecen, nk and (#nk - 1) or 1 }
				while #o > 40 do table.remove(o, 1) end
				d.ucusOrnek[aktif.kita] = o
			end
		end
	end
	aktif = nil; d.ucusAktif = nil
	cubuk:Hide()
end

local function cubukGuncelle()
	if not aktif then return end
	local gecen = GetServerTime() - aktif.bas
	if aktif.sure and aktif.sure > 0 then
		local kalan = math.max(0, aktif.sure - gecen)
		cubuk:SetMinMaxValues(0, aktif.sure); cubuk:SetValue(math.min(gecen, aktif.sure))
		yazi:SetText(("%s  —  %s%s"):format(aktif.hedef, aktif.tahmin and "~" or "", kalan > 0 and sureYaz(kalan) or "iniyor"))
	else
		cubuk:SetMinMaxValues(0, 1); cubuk:SetValue(1)
		yazi:SetText(("%s  —  %s"):format(aktif.hedef, sureYaz(gecen)))
	end
end

local izle = CreateFrame("Frame")
local sayac = 0
izle:SetScript("OnUpdate", function(_, e)
	sayac = sayac + e
	if sayac < 0.25 then return end
	sayac = 0
	if not aktif then izle:Hide(); return end
	local ucuyor = UnitOnTaxi("player")
	if not aktif.basladi then
		if ucuyor then
			aktif.basladi = true; aktif.bas = GetServerTime()
			db().ucusAktif = aktif
			if G.ayar("ucus") then cubuk:Show() end
		else
			bekle = bekle + 0.25
			if bekle > 15 then bitir(false) end
			return
		end
	elseif not ucuyor then
		bitir(true); return
	end
	cubukGuncelle()
end)
izle:Hide()

hooksecurefunc("TakeTaxiNode", function(hedef)
	local ana = anaNokta()
	if not ana or not hedef then return end
	local s, tahmin = sureBul(hedef)
	aktif = { kaynak = TaxiNodeName(ana), hedef = TaxiNodeName(hedef), sure = s, tahmin = tahmin, kita = kita(), uz = rotaUzunluk(hedef), noktalar = rotaNoktalari(hedef) }
	bekle = 0
	izle:Show()
end)

local o = CreateFrame("Frame")
o:RegisterEvent("TAXIMAP_OPENED")
o:RegisterEvent("PLAYER_ENTERING_WORLD")
o:SetScript("OnEvent", function(_, olay)
	if olay == "TAXIMAP_OPENED" then dugmeleriBagla(); C_Timer.After(0, dugmeleriBagla); return end
	local d = db()
	if d.ucusCubukYer then
		cubuk:ClearAllPoints(); cubuk:SetPoint("TOP", UIParent, "TOP", d.ucusCubukYer[1], d.ucusCubukYer[2])
	end
	-- /reload ya da yükleme ekranı uçuş sırasında olduysa kaldığı yerden devam et
	if d.ucusAktif and UnitOnTaxi("player") then
		aktif = d.ucusAktif; aktif.basladi = true
		if G.ayar("ucus") then cubuk:Show() end
		izle:Show()
	elseif d.ucusAktif and not aktif then
		d.ucusAktif = nil
	end
end)

G.dinle(function(k)
	if k == "ucus" then
		if G.ayar("ucus") and aktif and aktif.basladi then cubuk:Show() else cubuk:Hide() end
	end
end)
