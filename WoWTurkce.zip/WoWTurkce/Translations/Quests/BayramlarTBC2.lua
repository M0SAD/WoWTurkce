-- TBC bayram görevleri 2
-- b=başlık, a=açıklama, h=hedef, i=ilerleme, t=tamamlama
-- k = çevrilen İngilizce metnin parmak izi (metin değişirse çeviri gösterilmez, yeniden kaydedilir)
local V = WoWTurkce.Veri

V[11780] = { b="Bu Ateşi Kirlet!", t="Horde'un Stonetalon Mountains şenlik ateşini kirlet!", k={b=2141550803, t=3930311205} }
V[11781] = { b="Bu Ateşi Kirlet!", t="Horde'un Swamp of Sorrows şenlik ateşini kirlet!", k={b=2141550803, t=1267564124} }
V[11782] = { b="Bu Ateşi Kirlet!", t="Horde'un Terokkar Forest şenlik ateşini kirlet!", k={b=2141550803, t=4135574678} }
V[11783] = { b="Bu Ateşi Kirlet!", t="Horde'un Barrens şenlik ateşini kirlet!", k={b=2141550803, t=461508621} }
V[11784] = { b="Bu Ateşi Kirlet!", t="Horde'un Hinterlands şenlik ateşini kirlet!", k={b=2141550803, t=519150716} }
V[11785] = { b="Bu Ateşi Kirlet!", t="Horde'un Thousand Needles şenlik ateşini kirlet!", k={b=2141550803, t=2026960486} }
V[11786] = { b="Bu Ateşi Kirlet!", t="Horde'un Tirisfal Glades şenlik ateşini kirlet!", k={b=2141550803, t=454956590} }
V[11787] = { b="Bu Ateşi Kirlet!", t="Horde'un Zangarmarsh şenlik ateşini kirlet!", k={b=2141550803, t=4221801662} }
V[11799] = { b="Bu Ateşi Kirlet!", t="Horde'un Netherstorm şenlik ateşini kirlet!", k={b=2141550803, t=533422811} }
V[11800] = { b="Bu Ateşi Kirlet!", t="Horde'un Silithus şenlik ateşini kirlet!", k={b=2141550803, t=343011733} }
V[11801] = { b="Bu Ateşi Kirlet!", t="Horde'un Stranglethorn Vale şenlik ateşini kirlet!", k={b=2141550803, t=25673939} }
V[11802] = { b="Bu Ateşi Kirlet!", t="Horde'un Tanaris şenlik ateşini kirlet!", k={b=2141550803, t=2502674482} }
V[11803] = { b="Bu Ateşi Kirlet!", t="Horde'un Winterspring şenlik ateşini kirlet!", k={b=2141550803, t=4269707404} }
V[11804] = { b="Alevi Onurlandır", t="Arathi Highlands alevini onurlandır.", k={b=427467665, t=296584124} }
V[11805] = { b="Alevi Onurlandır", t="Ashenvale alevini onurlandır.", k={b=427467665, t=1568827112} }
V[11806] = { b="Alevi Onurlandır", t="Azuremyst Isle alevini onurlandır.", k={b=427467665, t=721132466} }
V[11807] = { b="Alevi Onurlandır", t="Blade's Edge Mountains alevini onurlandır!", k={b=427467665, t=2099557935} }
V[11808] = { b="Alevi Onurlandır", t="Blasted Lands alevini onurlandır.", k={b=427467665, t=1083879714} }
V[11809] = { b="Alevi Onurlandır", t="Bloodmyst Isle alevini onurlandır.", k={b=427467665, t=2731670427} }
V[11810] = { b="Alevi Onurlandır", t="Burning Steppes alevini onurlandır.", k={b=427467665, t=1081861450} }
V[11811] = { b="Alevi Onurlandır", t="Darkshore alevini onurlandır.", k={b=427467665, t=4078962292} }
V[11812] = { b="Alevi Onurlandır", t="Desolace alevini onurlandır.", k={b=427467665, t=155701905} }
V[11813] = { b="Alevi Onurlandır", t="Dun Morogh alevini onurlandır.", k={b=427467665, t=2724838564} }
V[11814] = { b="Alevi Onurlandır", t="Duskwood alevini onurlandır.", k={b=427467665, t=2393609185} }
V[11815] = { b="Alevi Onurlandır", t="Dustwallow Marsh alevini onurlandır.", k={b=427467665, t=878490626} }
V[11816] = { b="Alevi Onurlandır", t="Elwynn Forest alevini onurlandır.", k={b=427467665, t=1256983009} }
V[11817] = { b="Alevi Onurlandır", t="Feralas alevini onurlandır.", k={b=427467665, t=95811535} }
V[11818] = { b="Alevi Onurlandır", t="Hellfire Peninsula alevini onurlandır.", k={b=427467665, t=2619224363} }
V[11819] = { b="Alevi Onurlandır", t="Hillsbrad Foothills alevini onurlandır.", k={b=427467665, t=633807194} }
V[11820] = { b="Alevi Onurlandır", t="Loch Modan alevini onurlandır.", k={b=427467665, t=2662313862} }
V[11821] = { b="Alevi Onurlandır", t="Nagrand alevini onurlandır!", k={b=427467665, t=2794512684} }
V[11822] = { b="Alevi Onurlandır", t="Redridge Mountains alevini onurlandır.", k={b=427467665, t=842924725} }
V[11823] = { b="Alevi Onurlandır", t="Shadowmoon Valley alevini onurlandır.", k={b=427467665, t=2814291997} }
V[11824] = { b="Alevi Onurlandır", t="Teldrassil alevini onurlandır.", k={b=427467665, t=2747590376} }
V[11825] = { b="Alevi Onurlandır", t="Terokkar Forest alevini onurlandır.", k={b=427467665, t=969648935} }
V[11826] = { b="Alevi Onurlandır", t="Hinterlands alevini onurlandır.", k={b=427467665, t=3902322477} }
V[11827] = { b="Alevi Onurlandır", t="Western Plaguelands alevini onurlandır.", k={b=427467665, t=4180991721} }
V[11828] = { b="Alevi Onurlandır", t="Wetlands alevini onurlandır.", k={b=427467665, t=3526619891} }
V[11829] = { b="Alevi Onurlandır", t="Zangarmarsh alevini onurlandır.", k={b=427467665, t=4237014767} }
V[11830] = { b="Alevi Onurlandır", t="Netherstorm alevini onurlandır.", k={b=427467665, t=624908748} }
V[11831] = { b="Alevi Onurlandır", t="Silithus alevini onurlandır.", k={b=427467665, t=1506759590} }
V[11832] = { b="Alevi Onurlandır", t="Stranglethorn Vale alevini onurlandır.", k={b=427467665, t=680018564} }
V[11833] = { b="Alevi Onurlandır", t="Tanaris alevini onurlandır.", k={b=427467665, t=2126830819} }
V[11834] = { b="Alevi Onurlandır", t="Winterspring alevini onurlandır.", k={b=427467665, t=1759607133} }
V[11835] = { b="Alevi Onurlandır", t="Netherstorm alevini onurlandır.", k={b=427467665, t=624908748} }
V[11836] = { b="Alevi Onurlandır", t="Silithus alevini onurlandır.", k={b=427467665, t=1506759590} }
V[11837] = { b="Alevi Onurlandır", t="Stranglethorn Vale alevini onurlandır.", k={b=427467665, t=680018564} }
V[11838] = { b="Alevi Onurlandır", t="Tanaris alevini onurlandır!", k={b=427467665, t=2126830819} }
V[11839] = { b="Alevi Onurlandır", t="Winterspring alevini onurlandır.", k={b=427467665, t=1759607133} }
V[11840] = { b="Alevi Onurlandır", t="Arathi Highlands alevini onurlandır.", k={b=427467665, t=296584124} }
V[11841] = { b="Alevi Onurlandır", t="Ashenvale alevini onurlandır.", k={b=427467665, t=1568827112} }
V[11842] = { b="Alevi Onurlandır", t="Badlands alevini onurlandır.", k={b=427467665, t=902783434} }
V[11843] = { b="Alevi Onurlandır", t="Blade's Edge Mountains alevini onurlandır!", k={b=427467665, t=2099557935} }
V[11844] = { b="Alevi Onurlandır", t="Burning Steppes alevini onurlandır.", k={b=427467665, t=1081861450} }
V[11845] = { b="Alevi Onurlandır", t="Desolace alevini onurlandır.", k={b=427467665, t=155701905} }
V[11846] = { b="Alevi Onurlandır", t="Durotar alevini onurlandır.", k={b=427467665, t=3089251730} }
V[11847] = { b="Alevi Onurlandır", t="Dustwallow Marsh alevini onurlandır.", k={b=427467665, t=878490626} }
V[11848] = { b="Alevi Onurlandır", t="Eversong Woods alevini onurlandır.", k={b=427467665, t=619138662} }
V[11849] = { b="Alevi Onurlandır", t="Feralas alevini onurlandır.", k={b=427467665, t=95811535} }
V[11850] = { b="Alevi Onurlandır", t="Ghostlands alevini onurlandır.", k={b=427467665, t=3487174472} }
V[11851] = { b="Alevi Onurlandır", t="Hellfire Peninsula alevini onurlandır.", k={b=427467665, t=2619224363} }
V[11852] = { b="Alevi Onurlandır", t="Mulgore alevini onurlandır.", k={b=427467665, t=361719660} }
V[11853] = { b="Alevi Onurlandır", t="Hillsbrad Foothills alevini onurlandır.", k={b=427467665, t=633807194} }
V[11854] = { b="Alevi Onurlandır", t="Nagrand alevini onurlandır.", k={b=427467665, t=2794512684} }
V[11855] = { b="Alevi Onurlandır", t="Shadowmoon Valley alevini onurlandır.", k={b=427467665, t=2814291997} }
