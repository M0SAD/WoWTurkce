-- WoWTürkçe - Partide aynı görev
-- Görev günlüğünde ve Questie takip listesinde, görevin yanında partideki kaç kişide olduğunu yazar: "Görev Adı [2/5]".
-- Bilgi iki yoldan gelir:
--   1) Oyunun kendi sorgusu (IsUnitOnQuest / C_QuestLog.IsUnitOnQuest) varsa her üye için doğrudan sorulur.
--   2) WoWTürkçe kullanan parti üyeleri görev listelerini birbirine gizli eklenti mesajıyla gönderir.
local G = WoWTurkce

local ONEK = "WTRPG"
local RENK = "|cff66bbff"
local benim = {}        -- [questID] = true
local uyeler = {}       -- [isim] = { [questID] = true }
local sonGonderilen = ""

local function acik() return G.ayar("acik") and G.ayar("partiGorev") ~= false end
local function grupta() return IsInGroup and IsInGroup() and not (IsInRaid and IsInRaid()) end

---------------------------------------------------------------- kendi görev listem
local function listeTopla()
	local yeni = {}
	local n = (C_QuestLog and C_QuestLog.GetNumQuestLogEntries and C_QuestLog.GetNumQuestLogEntries()) or (GetNumQuestLogEntries and GetNumQuestLogEntries()) or 0
	for i = 1, n do
		local id
		if C_QuestLog and C_QuestLog.GetInfo then
			local ok, info = pcall(C_QuestLog.GetInfo, i)
			if ok and type(info) == "table" and not info.isHeader then id = info.questID end
		end
		if not id and GetQuestLogTitle then
			local ok, _, _, _, baslik, _, _, _, qid = pcall(GetQuestLogTitle, i)
			if ok and not baslik and type(qid) == "number" then id = qid end
		end
		if type(id) == "number" and id > 0 then yeni[id] = true end
	end
	benim = yeni
end

local function listeMetni()
	local t = {}
	for id in pairs(benim) do t[#t + 1] = id end
	table.sort(t)
	return table.concat(t, ",")
end

---------------------------------------------------------------- eklenti mesajları
local gonder = (C_ChatInfo and C_ChatInfo.SendAddonMessage) or SendAddonMessage
local function mesaj(m)
	if gonder and grupta() then pcall(gonder, ONEK, m, "PARTY") end
end

local function listeGonder(zorla)
	if not grupta() then return end
	local metin = listeMetni()
	if not zorla and metin == sonGonderilen then return end
	sonGonderilen = metin
	-- 255 karakter sınırı: parçalara böl ("B" başlangıç, "Q" devam)
	local parca, ilk = {}, true
	local function bosalt()
		mesaj((ilk and "B:" or "Q:") .. table.concat(parca, ","))
		parca, ilk = {}, false
	end
	for id in metin:gmatch("%d+") do
		parca[#parca + 1] = id
		if #table.concat(parca, ",") > 230 then bosalt() end
	end
	if #parca > 0 or ilk then bosalt() end
end

local function kisaAd(ad)
	if type(ad) ~= "string" then return nil end
	return (ad:match("^([^%-]+)")) or ad
end

local function mesajAl(onek, metin, _, gonderen)
	if onek ~= ONEK or type(metin) ~= "string" then return end
	local ad = kisaAd(gonderen)
	if not ad or ad == UnitName("player") then return end
	local tur, govde = metin:match("^(%a):(.*)$")
	if tur == "R" then listeGonder(true); return end
	if tur == "B" then uyeler[ad] = {} end
	if tur == "B" or tur == "Q" then
		local t = uyeler[ad] or {}
		uyeler[ad] = t
		for id in (govde or ""):gmatch("%d+") do t[tonumber(id)] = true end
		G.partiGorevYenile()
	end
end

---------------------------------------------------------------- sayım
local function uyeBirimleri()
	local t = {}
	for i = 1, 4 do
		local u = "party" .. i
		if UnitExists(u) then t[#t + 1] = u end
	end
	return t
end

local function birimdeMi(u, id)
	local ad = kisaAd(UnitName(u))
	if ad and uyeler[ad] then return uyeler[ad][id] == true end
	-- Oyunun sorgusu (eklentisi olmayan üyeler için)
	if C_QuestLog and C_QuestLog.IsUnitOnQuest then
		local ok, v = pcall(C_QuestLog.IsUnitOnQuest, u, id)
		if ok and v ~= nil and not G.gizli(v) then return v == true end
	end
	if IsUnitOnQuest and GetQuestLogIndexByID then
		local idx = GetQuestLogIndexByID(id)
		if idx and idx > 0 then
			local ok, v = pcall(IsUnitOnQuest, idx, u)
			if ok and v ~= nil and not G.gizli(v) then return v == 1 or v == true end
		end
	end
	return nil
end

-- Görev kimliği için (sayı, toplam) döner; bilinmeyen üyeler sayılmaz ama toplama dahildir
function G.partiGorevSay(id)
	if not grupta() or type(id) ~= "number" then return nil end
	local birimler = uyeBirimleri()
	if #birimler == 0 then return nil end
	local n = benim[id] and 1 or 0
	for _, u in ipairs(birimler) do
		if birimdeMi(u, id) then n = n + 1 end
	end
	return n, #birimler + 1
end

---------------------------------------------------------------- yazıya ekleme
local function ekiTemizle(t)
	return (t:gsub("%s*|cff66bbff%[%d+/%d+%]|r", ""))
end

local function ekle(fs, id)
	if not fs or not fs.GetText or not fs.SetText then return end
	local t = fs:GetText()
	if type(t) ~= "string" or t == "" or G.gizli(t) then return end
	local temiz = ekiTemizle(t)
	local yeni = temiz
	if acik() then
		local n, top = G.partiGorevSay(id)
		if n and top and top > 1 then yeni = temiz .. " " .. RENK .. "[" .. n .. "/" .. top .. "]|r" end
	end
	if yeni ~= t then fs:SetText(yeni) end
end

-- Questie takip listesi
local function questieGuncelle()
	local QL = rawget(_G, "QuestieLoader")
	if not QL or not QL.ImportModule then return end
	local ok, LP = pcall(QL.ImportModule, QL, "TrackerLinePool")
	if not ok or type(LP) ~= "table" or not LP.ForEachQuestTitleLine then return end
	pcall(LP.ForEachQuestTitleLine, function(line)
		local q = line.Quest
		local id = q and (q.Id or q.id)
		if line.label and type(id) == "number" and line:IsShown() then pcall(ekle, line.label, id) end
	end)
end

-- Oyunun görev günlüğü (Classic görünümü)
local function gunlukGuncelle()
	if not (QuestLogFrame and QuestLogFrame:IsShown()) then return end
	for i = 1, 40 do
		local b = _G["QuestLogTitle" .. i]
		if not b then break end
		if b:IsShown() and GetQuestLogTitle then
			local idx = b.GetID and b:GetID()
			if idx and idx > 0 then
				local ok, _, _, _, baslik, _, _, _, qid = pcall(GetQuestLogTitle, idx)
				local fs = (b.GetFontString and b:GetFontString()) or _G["QuestLogTitle" .. i .. "NormalText"]
				if ok and not baslik and type(qid) == "number" and fs then pcall(ekle, fs, qid) end
			end
		end
	end
end

function G.partiGorevYenile()
	pcall(questieGuncelle)
	pcall(gunlukGuncelle)
end

---------------------------------------------------------------- olaylar
local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("GROUP_ROSTER_UPDATE")
f:RegisterEvent("QUEST_LOG_UPDATE")
f:RegisterEvent("QUEST_ACCEPTED")
f:RegisterEvent("QUEST_REMOVED")
f:RegisterEvent("QUEST_TURNED_IN")
f:RegisterEvent("CHAT_MSG_ADDON")
local bekleyen
local function sonra(fn, sn)
	if bekleyen then return end
	bekleyen = true
	C_Timer.After(sn or 1, function() bekleyen = nil; pcall(fn) end)
end
f:SetScript("OnEvent", function(_, olay, ...)
	if olay == "CHAT_MSG_ADDON" then return mesajAl(...) end
	if olay == "PLAYER_LOGIN" then
		if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then pcall(C_ChatInfo.RegisterAddonMessagePrefix, ONEK)
		elseif RegisterAddonMessagePrefix then pcall(RegisterAddonMessagePrefix, ONEK) end
	end
	if olay == "GROUP_ROSTER_UPDATE" then
		if not grupta() then uyeler = {}; sonGonderilen = "" else
			-- ayrılan üyelerin listesini sil
			local var = {}
			for _, u in ipairs(uyeBirimleri()) do local a = kisaAd(UnitName(u)); if a then var[a] = true end end
			for a in pairs(uyeler) do if not var[a] then uyeler[a] = nil end end
		end
	end
	sonra(function()
		listeTopla()
		if acik() then
			listeGonder(olay == "GROUP_ROSTER_UPDATE" or olay == "PLAYER_LOGIN")
			if olay == "GROUP_ROSTER_UPDATE" or olay == "PLAYER_LOGIN" then mesaj("R:") end
		end
		G.partiGorevYenile()
	end, olay == "QUEST_LOG_UPDATE" and 1.5 or 0.5)
end)

-- Questie ve günlük yazıyı sık sık yeniden kuruyor: grupta iken düzenli olarak eki yeniden koy
C_Timer.NewTicker(1, function()
	if grupta() or next(uyeler) then G.partiGorevYenile() end
end)
if QuestLog_Update then hooksecurefunc("QuestLog_Update", function() pcall(gunlukGuncelle) end) end
