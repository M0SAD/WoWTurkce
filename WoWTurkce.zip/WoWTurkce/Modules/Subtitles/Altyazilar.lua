-- Sinematik ve film altyazıları: oyunun altyazı çerçevesindeki (SubtitlesFrame) yazıyı Türkçe gösterir.
-- Eşleşme parmak iziyle: G.Altyazi[iz] = "Türkçe". Çevirisi olmayan altyazılar "altyazi" olarak kaydedilir.
-- Not: Altyazıların görünmesi için oyunun Ayarlar > Ses/Erişilebilirlik bölümündeki "Sinematik altyazılar" açık olmalı;
-- bu modül açıkken filmlerde altyazıyı kendisi de açar.
local G = WoWTurkce
G.Altyazi = G.Altyazi or {}

local asilFont
local sonYazilan -- kendi koyduğumuz yazıyı yeniden işlemeyelim

local function uygula()
	if not G.modul("altyazi") or not SubtitlesFrame then return end
	local fs = SubtitlesFrame.Subtitle1
	if not fs or not fs.GetText then return end
	local metin = fs:GetText()
	if G.gizli(metin) then return end
	if not metin or metin == "" or metin == sonYazilan or G.turkceMi(metin) then return end
	-- "[Thrall] Whoever you are," gibi konuşan etiketi
	local etiket, govde = metin:match("^(%b[]%s*)(.+)$")
	if not etiket then
		-- "SYLVANAS: ..." gibi büyük harfli konuşan etiketi
		local e2, g2 = metin:match("^([%u][%u%s'%.%-]+:%s*)(.+)$")
		if e2 and select(2, e2:gsub("%u", "")) >= 2 then etiket, govde = e2, g2 end
	end
	-- Önce tam satır, sonra etiketsiz metin
	local tamIz = G.konusmaIz(metin)
	if tamIz and G.Altyazi[tamIz] then etiket, govde = nil, metin end
	govde = govde or metin
	local tr, iz = G.izBul(G.Altyazi, govde)
	if tr then
		if fs.GetFont and not asilFont then asilFont = { fs:GetFont() } end
		if asilFont and asilFont[1] then if G.fontSerbest(fs) then fs:SetFont(G.FONT_ARAYUZ, asilFont[2] or 20, asilFont[3] or "") end end
		sonYazilan = (etiket or "") .. G.doldur(tr)
		fs:SetText(sonYazilan)
	else
		G.kaydetDiger("altyazi", iz, { metin = metin })
	end
end

G.basla(function()
	if SubtitlesFrame and SubtitlesFrame.HookScript then
		SubtitlesFrame:HookScript("OnEvent", function() pcall(uygula) end)
		if SubtitlesFrame.Subtitle1 and SubtitlesFrame.Subtitle1.SetText then
			hooksecurefunc(SubtitlesFrame.Subtitle1, "SetText", function(fs, t)
				if not G.gizli(t) and t and not G.turkceMi(t) then C_Timer.After(0, function() pcall(uygula) end) end
			end)
		end
	end
	-- Filmlerde (giriş filmi gibi) altyazıyı aç
	if MovieFrame and MovieFrame.HookScript then
		MovieFrame:HookScript("OnShow", function(self)
			if G.modul("altyazi") and self.EnableSubtitles then pcall(self.EnableSubtitles, self, true) end
		end)
	end
end)
