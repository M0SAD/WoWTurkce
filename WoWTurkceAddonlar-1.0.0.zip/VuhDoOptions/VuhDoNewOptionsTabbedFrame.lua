VUHDO_MENU_RETURN_TARGET = nil;
VUHDO_MENU_RETURN_TARGET_MAIN = nil;
VUHDO_MENU_RETURN_TARGET_SAVED = nil;
VUHDO_MENU_RETURN_TARGET_MAIN_SAVED = nil;


local _;
local VUHDO_B_CONFIG = nil;
local VUHDO_B_INDICATOR_CONFIG = nil;
local VUHDO_B_PANEL_SETUP = nil;
local VUHDO_B_SPELL_ASSIGNMENTS = nil;
local VUHDO_B_BUFF_SETTINGS = nil;
local VUHDO_B_SPELL_CONFIG = nil;
local VUHDO_B_SPELLS_KEYBOARD = nil;
local VUHDO_B_BOUQUETS = nil;
VUHDO_OPTIONS_SETTINGS = nil;

VUHDO_IS_CONFIG = false;

--
function VUHDO_tabbedFrameOnMouseDown(aPanel)
	aPanel:StartMoving();
end



--
function VUHDO_tabbedFrameOnMouseUp(aPanel)
	aPanel:StopMovingOrSizing();
end



--
local function VUHDO_countTableDiffs(aTable, anotherTable)
	local tCount = 0;

	if (aTable == nil or anotherTable == nil) then
		return 0;
	end

	aTable = VUHDO_decompressIfCompressed(aTable);
	anotherTable = VUHDO_decompressIfCompressed(anotherTable);

	for tKey, tValue in pairs(aTable) do
		local tType = type(tValue);

		if ("table" == tType) then
			tCount = tCount + VUHDO_countTableDiffs(tValue, anotherTable[tKey]);
		elseif ("number" == tType) then
			if (format("%0.4f", aTable[tKey]) ~= (anotherTable[tKey] and format("%0.4f", anotherTable[tKey]) or nil)) then
				tCount = tCount + 1;
			end
		else
			if (aTable[tKey] ~= anotherTable[tKey]) then
				tCount = tCount + 1;
			end
		end
	end

	for tKey, tValue in pairs(anotherTable) do
		if ("table" == type(tValue)) then
		else
			if (aTable[tKey] == nil and tValue ~= aTable[tKey]) then
				tCount = tCount + 1;
			end
		end
	end

	return tCount;
end



--
function VUHDO_tabbedPanelOkayClicked(aButton)
	if InCombatLockdown() then
		VUHDO_Msg("Seçenekler savaşta kaydedilemez!", 1, 0.4, 0.4);

		return;
	end

	VUHDO_B_CONFIG = nil;
	VUHDO_B_INDICATOR_CONFIG = nil;
	VUHDO_B_PANEL_SETUP = nil;
	VUHDO_B_SPELL_ASSIGNMENTS = nil;
	VUHDO_B_BUFF_SETTINGS = nil;
	VUHDO_B_SPELL_CONFIG = nil;
	VUHDO_B_SPELLS_KEYBOARD = nil;
	VUHDO_B_BOUQUETS = nil;

	VUHDO_initKeyboardMacros();
	VUHDO_fixHotSettings();
	VUHDO_initFromSpellbook();
	VUHDO_registerAllBouquets(false);

	local _, tProfile = VUHDO_getProfileNamedCompressed(VUHDO_CONFIG["CURRENT_PROFILE"]);
	if (VUHDO_CURRENT_PROFILE == "") then
		VUHDO_CONFIG["CURRENT_PROFILE"] = "";
	elseif (tProfile ~= nil and tProfile["LOCKED"]) then
		VUHDO_Msg("Profil kilitli: Ayarlar şuraya KAYDEDİLMEDİ: " .. tProfile["NAME"]);
	else
		local tSkinsPanel = _G["VuhDoNewOptionsToolsSkins"];

		if tSkinsPanel and VUHDO_isAutoProfilesModified() then
			VUHDO_skinsSaveAutoProfileButtonEnablement(tSkinsPanel, VUHDO_CONFIG["CURRENT_PROFILE"]);
			VUHDO_resetAutoProfilesModified();
		end

		VUHDO_saveCurrentProfile();
		VUHDO_CURRENT_PROFILE = VUHDO_CONFIG["CURRENT_PROFILE"];
	end

	VUHDO_invalidateBindingCodeCache();
	VUHDO_initAllBurstCaches();
	VUHDO_trimSpellAssignments(VUHDO_SPELL_ASSIGNMENTS);
	VUHDO_trimSpellAssignments(VUHDO_HOSTILE_SPELL_ASSIGNMENTS);
	VUHDO_reloadUI(true);

	VUHDO_MAY_DEBUFF_ANIM = true;
	VuhDoNewOptionsTabbedFrame:Hide();

	VUHDO_timeReloadUI(3);
end



--
function VUHDO_tabbedPanelCancelClicked()
	if InCombatLockdown() then
		VuhDoNewOptionsTabbedFrame:Hide();
	else
		VUHDO_newOptionsRestoreVars();
		VUHDO_initKeyboardMacros();
	end

	VUHDO_MAY_DEBUFF_ANIM = true;
end



local tAllPanels = {
	{ "VuhDoNewOptionsGeneral", "General" },
	{ "VuhDoNewOptionsSpell", "Spell" },
	{ "VuhDoNewOptionsPanelPanel", "Panels" },
	{ "VuhDoNewOptionsColors", "Colors" },
	{ "VuhDoNewOptionsMove", "Move" },
	{ "VuhDoNewOptionsBuffs", "Buffs" },
	{ "VuhDoNewOptionsAura", "Auras" },
	{ "VuhDoNewOptionsTools", "Tools" },
}


--
function VUHDO_newOptionsTabbedClickedClicked(aTabRadio)

	local tName = aTabRadio:GetName();

	for _, tPanelInfo in pairs(tAllPanels) do
		if strfind(tName, tPanelInfo[2]) then
			_G[tPanelInfo[1]]:SetShown(true);

			_G["VuhDoNewOptionsTabbedFrame"]["selectedTab"] = tPanelInfo[1];
		else
			_G[tPanelInfo[1]]:SetShown(false);
		end
	end

end



--
function VUHDO_newOptionsBufferVars()
	if (VUHDO_B_CONFIG == nil) then
		VUHDO_B_CONFIG = VUHDO_compressTable(VUHDO_CONFIG);
		VUHDO_B_INDICATOR_CONFIG = VUHDO_compressTable(VUHDO_INDICATOR_CONFIG);
		VUHDO_B_PANEL_SETUP = VUHDO_compressTable(VUHDO_PANEL_SETUP);
		VUHDO_B_SPELL_ASSIGNMENTS = VUHDO_compressTable(VUHDO_SPELL_ASSIGNMENTS);
		VUHDO_B_BUFF_SETTINGS = VUHDO_compressTable(VUHDO_BUFF_SETTINGS);
		VUHDO_B_SPELL_CONFIG = VUHDO_compressTable(VUHDO_SPELL_CONFIG);
		VUHDO_B_SPELLS_KEYBOARD = VUHDO_compressTable(VUHDO_SPELLS_KEYBOARD);
		VUHDO_B_BOUQUETS = VUHDO_compressTable(VUHDO_BOUQUETS);
	end
end



--
function VUHDO_yesNoDiscardChangesCallback(aDecision)
	if (VUHDO_YES == aDecision) then

		if (VUHDO_B_CONFIG ~= nil) then
			VUHDO_CONFIG = VUHDO_decompressIfCompressed(VUHDO_B_CONFIG);
		end

		if (VUHDO_B_INDICATOR_CONFIG ~= nil) then
			VUHDO_INDICATOR_CONFIG = VUHDO_decompressIfCompressed(VUHDO_B_INDICATOR_CONFIG);
		end

		if (VUHDO_B_PANEL_SETUP ~= nil) then
			VUHDO_PANEL_SETUP = VUHDO_decompressIfCompressed(VUHDO_B_PANEL_SETUP);
		end

		if (VUHDO_B_SPELL_ASSIGNMENTS ~= nil) then
			VUHDO_SPELL_ASSIGNMENTS = VUHDO_decompressIfCompressed(VUHDO_B_SPELL_ASSIGNMENTS);
		end

		if (VUHDO_B_BUFF_SETTINGS ~= nil) then
			VUHDO_BUFF_SETTINGS = VUHDO_decompressIfCompressed(VUHDO_B_BUFF_SETTINGS);
		end

		if (VUHDO_B_SPELL_CONFIG ~= nil) then
			VUHDO_SPELL_CONFIG = VUHDO_decompressIfCompressed(VUHDO_B_SPELL_CONFIG);
		end

		if (VUHDO_B_SPELLS_KEYBOARD ~= nil) then
			VUHDO_SPELLS_KEYBOARD = VUHDO_decompressIfCompressed(VUHDO_B_SPELLS_KEYBOARD);
		end

		if (VUHDO_B_BOUQUETS ~= nil) then
			VUHDO_BOUQUETS = VUHDO_decompressIfCompressed(VUHDO_B_BOUQUETS);
		end

		VUHDO_initAllBurstCaches();
		VUHDO_initBouquetComboModel();
		VUHDO_newOptionsIndicatorsInvalidate();
		VUHDO_reloadUI(true);
		VUHDO_B_CONFIG = nil;
		VUHDO_B_INDICATOR_CONFIG = nil;
		VUHDO_B_PANEL_SETUP = nil;
		VUHDO_B_SPELL_ASSIGNMENTS = nil;
		VUHDO_B_BUFF_SETTINGS = nil;
		VUHDO_B_SPELL_CONFIG = nil;
		VUHDO_B_SPELLS_KEYBOARD = nil;
		VUHDO_B_BOUQUETS = nil;

		VuhDoNewOptionsTabbedFrame:Hide();
	end
end



--
local tChanges;
function VUHDO_newOptionsRestoreVars()
	tChanges =
		VUHDO_countTableDiffs(VUHDO_CONFIG, VUHDO_B_CONFIG)
		+ VUHDO_countTableDiffs(VUHDO_INDICATOR_CONFIG, VUHDO_B_INDICATOR_CONFIG)
		+ VUHDO_countTableDiffs(VUHDO_PANEL_SETUP, VUHDO_B_PANEL_SETUP)
		+ VUHDO_countTableDiffs(VUHDO_SPELL_ASSIGNMENTS, VUHDO_B_SPELL_ASSIGNMENTS)
		+ VUHDO_countTableDiffs(VUHDO_BUFF_SETTINGS, VUHDO_B_BUFF_SETTINGS)
		+ VUHDO_countTableDiffs(VUHDO_SPELL_CONFIG, VUHDO_B_SPELL_CONFIG)
		+ VUHDO_countTableDiffs(VUHDO_SPELLS_KEYBOARD, VUHDO_B_SPELLS_KEYBOARD);

	if (tChanges > 0) then
		VuhDoYesNoFrameText:SetText(format(VUHDO_I18N_DISCARD_CHANGES_CONFIRM, tChanges));
		VuhDoYesNoFrame:SetAttribute("callback", VUHDO_yesNoDiscardChangesCallback);
		VuhDoYesNoFrame:Show();
	else
		VUHDO_yesNoDiscardChangesCallback(VUHDO_YES);
	end
end



--
function VUHDO_initOptionsSettings()

	if (VUHDO_OPTIONS_SETTINGS == nil) then
		VUHDO_OPTIONS_SETTINGS = {
			["scale"] = 1;
			["SKIN"] = "Classic";
			["SKIN_TINTS"] = { };
		};
	end

	if (VUHDO_OPTIONS_SETTINGS["SKIN"] == nil) then
		VUHDO_OPTIONS_SETTINGS["SKIN"] = "Classic";
	elseif (VUHDO_OPTIONS_SETTINGS["SKIN"] == "Default") then
		VUHDO_OPTIONS_SETTINGS["SKIN"] = "Classic";
	end

	if (VUHDO_OPTIONS_SETTINGS["SKIN_TINTS"] == nil) then
		VUHDO_OPTIONS_SETTINGS["SKIN_TINTS"] = { };
	end

	VUHDO_lnfStartSearchIndexBuild();

end



--
function VUHDO_yesNoSkinPromptCallback(aDecision)

	if (VUHDO_YES == aDecision) then
		VUHDO_lnfSkinSetActive("Classic");
	else
		VUHDO_lnfSkinSetActive("Dark");
	end

	VUHDO_OPTIONS_SETTINGS["SKIN_PROMPT_DONE"] = true;

	return;

end



--
local tSkin;
local tText;
function VUHDO_showOptionsSkinPrompt()

	if not VUHDO_OPTIONS_SETTINGS then
		return;
	end

	if (VUHDO_OPTIONS_SETTINGS["SKIN_PROMPT_DONE"]) then
		return;
	end

	tSkin = VUHDO_OPTIONS_SETTINGS["SKIN"];

	if (tSkin and tSkin ~= "Classic") then
		VUHDO_OPTIONS_SETTINGS["SKIN_PROMPT_DONE"] = true;

		return;
	end

	VuhDoYesNoFrameRootPaneTitleLabelLabel:SetText(VUHDO_I18N_SKIN);
	VuhDoYesNoFrameText:SetText(VUHDO_I18N_SKIN_PROMPT);
	VuhDoYesNoFrameYesButton:SetText(VUHDO_I18N_SKIN_CLASSIC);
	VuhDoYesNoFrameNoButton:SetText(VUHDO_I18N_SKIN_DARK);

	VuhDoYesNoFrameYesButtonIcon:Hide();
	VuhDoYesNoFrameNoButtonIcon:Hide();

	VuhDoYesNoFrame:SetAttribute("callback", VUHDO_yesNoSkinPromptCallback);

	VuhDoYesNoFrame:Show();

	VUHDO_PixelUtil.SetSize(VuhDoYesNoFrameYesButton, 100, 32);
	VUHDO_PixelUtil.SetSize(VuhDoYesNoFrameNoButton, 100, 32);

	tText = VuhDoYesNoFrameYesButton:GetFontString();
	tText:ClearAllPoints();
	tText:SetAllPoints(VuhDoYesNoFrameYesButton);
	tText:SetJustifyH("CENTER");
	tText:SetJustifyV("MIDDLE");

	tText = VuhDoYesNoFrameNoButton:GetFontString();
	tText:ClearAllPoints();
	tText:SetAllPoints(VuhDoYesNoFrameNoButton);
	tText:SetJustifyH("CENTER");
	tText:SetJustifyV("MIDDLE");

	return;

end