-- Ekran ortasındaki kırmızı hata ve sarı bilgi mesajlarının çevirisi.
-- Oyunun hata çerçevesi mesajı bizden alır; olayın kendisi diğer addon'lara değişmeden gider.
local G = WoWTurkce

-- Desenli mesajlar (isim içerenler): { Lua deseni, Türkçe }
G.HataDesen = G.HataDesen or {}

local function normal(s) return (s:gsub("[%.!]+$", "")) end

local function hataCevir(msg)
	if type(msg) ~= "string" or msg == "" then return nil end
	local tr = G.cevir(G.Hata, msg) or G.cevir(G.Hata, normal(msg))
	if tr then return tr end
	for _, d in ipairs(G.HataDesen) do
		if msg:find(d[1]) then return (msg:gsub(d[1], d[2])) end
	end
	-- Görev hedefi ilerlemesi: "Putrid Claw: 4/7" -> "Kokuşmuş Pençe (Putrid Claw): 4/7"; "Rotting Dead slain: 3/8"
	do
		local on, govde, son = "", msg, ""
		if msg:find("^|c%x%x%x%x%x%x%x%x") then
			local a, b, c = msg:match("^(|c%x%x%x%x%x%x%x%x)(.-)(|r)$")
			if a then on, govde, son = a, b, c end
		end
		local ad, n1, n2, ek = govde:match("^(.-): (%d+)/(%d+)(.*)$")
		if ad and ad ~= "" and #ad < 80 then
			local sonuc
			local oncesi = ad:match("^(.-) slain$")
			if oncesi then
				local y = G.Yaratik and G.Yaratik[oncesi]
				if type(y) == "string" and G.adStil then sonuc = G.adStil("stilYaratik", y, oncesi) .. " öldürüldü" end
			else
				local e = G.EsyaAdi and G.EsyaAdi[ad]
				local y = G.Yaratik and G.Yaratik[ad]
				if type(e) == "string" and G.adStil then sonuc = G.adStil("stilEsya", e, ad)
				elseif type(y) == "string" and G.adStil then sonuc = G.adStil("stilYaratik", y, ad) end
			end
			if sonuc then
				local ekTr = ek
				if ek:find("%(Complete%)") then ekTr = ek:gsub("%(Complete%)", "(Tamamlandı)") end
				return on .. sonuc .. ": " .. n1 .. "/" .. n2 .. ekTr .. son
			end
			G.kaydetDiger("hata", (G.sablon(govde)))
		end
	end
	-- Oyunun hazır hata metinleri (GlobalStrings ERR_...)
	tr = G.cevir(G.Arayuz, msg) or (G.globalDesenCevir and G.globalDesenCevir(msg))
	return tr
end
G.hataCevir = hataCevir

G.basla(function()
	-- Retail'de hata çerçevesinin olaylarını yönlendirmek Blizzard kodunu bozabilir; orada dokunmuyoruz
	if G.RETAIL then return end
	local cerceve = UIErrorsFrame
	if not cerceve or not cerceve.GetScript then return end
	local orijinal = cerceve:GetScript("OnEvent")
	if not orijinal then return end
	local olaylar = { "UI_ERROR_MESSAGE", "UI_INFO_MESSAGE" }
	local f = CreateFrame("Frame")
	for _, e in ipairs(olaylar) do
		if cerceve:IsEventRegistered(e) then
			cerceve:UnregisterEvent(e)
			f:RegisterEvent(e)
		end
	end
	f:SetScript("OnEvent", function(_, olay, a, b, ...)
		local ok = pcall(function()
			if G.modul("hata") and not G.gizli(a) and not G.gizli(b) then
				-- Yeni istemcilerde (mesajTürü, mesaj), eskilerde (mesaj, r, g, b)
				if type(a) == "string" then
					local tr = hataCevir(a)
					if tr then a = tr elseif olay == "UI_ERROR_MESSAGE" then G.kaydetDiger("hata", G.sablon(normal(a))) end
				elseif type(b) == "string" then
					local tr = hataCevir(b)
					if tr then b = tr elseif olay == "UI_ERROR_MESSAGE" then G.kaydetDiger("hata", G.sablon(normal(b))) end
				end
			end
		end)
		orijinal(cerceve, olay, a, b, ...)
	end)
end)

-- Doğrudan UIErrorsFrame:AddMessage ile yazılan mesajlar (ör. "Enemy Nameplates Turned On")
G.basla(function()
	if G.RETAIL then return end
	local c = UIErrorsFrame
	if not c or not c.AddMessage or c._gtrHata then return end
	c._gtrHata = true
	local orj = c.AddMessage
	c.AddMessage = function(self, msg, ...)
		if type(msg) == "string" and G.modul("hata") and not G.gizli(msg) then
			local ok, tr = pcall(hataCevir, msg)
			if ok and tr then msg = tr end
		end
		return orj(self, msg, ...)
	end
end)
