-- WoWTürkçe - görev metinleri
-- Görev penceresi (kabul, ilerleme, ödül) ve görev günlüğü ayrıntıları görev kimliğiyle (questID) çevrilir:
-- G.Veri[id] = { b = başlık, h = hedef, a = açıklama, i = ilerleme, t = tamamlama, k = bitiş metni }
-- Kimlikle eşleştiği için oyunda metni biraz değişmiş (Forever) görevler de doğru çevrilir.
-- Çevirisi olmayan görevler "gorevmetin" kaydına yazılır.
local G = WoWTurkce
G.Veri = G.Veri or {}

local function yaz(fs, metin)
	if not fs or not fs.SetText or type(metin) ~= "string" or metin == "" then return end
	local t = G.doldur and G.doldur(metin) or metin
	if fs.GetText and fs:GetText() == t then return end
	fs:SetText(t)
end

local function ilk(...)
	for i = 1, select("#", ...) do
		local ad = select(i, ...)
		local f = type(ad) == "string" and _G[ad] or ad
		if f and f.SetText then return f end
	end
end

local kaydedilen = {}
local function kaydet(id, ad)
	if not id or kaydedilen[id] then return end
	kaydedilen[id] = true
	if G.kaydetDiger then G.kaydetDiger("gorevmetin", tostring(id), { baslik = ad or "", metin = GetQuestText and GetQuestText() or "" }) end
end

-- Görev çevirisi var ama bu alanı (açıklama/ilerleme/tamamlama) yok: oyundaki İngilizce metni kaydet
local function eksikKaydet(id, alan, fs)
	local anahtar = tostring(id) .. alan
	if kaydedilen[anahtar] or not G.kaydetDiger or not fs or not fs.GetText then return end
	local t = fs:GetText()
	if type(t) ~= "string" or not t:find("%a%a") or (G.turkceMi and G.turkceMi(t)) then return end
	kaydedilen[anahtar] = true
	G.kaydetDiger("gorevmetin", anahtar, { metin = t })
end

local function veri(id)
	return id and (G.VeriEk and G.VeriEk[id]) or (id and G.Veri[id])
end

---------------------------------------------------------------- görev penceresi (NPC ile konuşurken)
-- Görev penceresinin sabit etiketleri (XML'de oyun açılışında yazılır, sonradan çevrilmez)
local ETIKET = {
	QuestProgressRequiredItemsText = "Gereken eşyalar:",
	QuestProgressRequiredMoneyText = "Gereken para:",
	QuestInfoObjectivesHeader = "Görev Hedefleri",
	QuestInfoDescriptionHeader = "Açıklama",
	QuestInfoRewardsHeader = "Ödüller",
	QuestInfoItemChooseText = "Şu ödüllerden birini seçebilirsin:",
	QuestInfoItemReceiveText = "Alacakların:",
	QuestInfoSpellLearnText = "Öğreneceğin:",
	QuestInfoXPFrameReceiveText = "Tecrübe:",
}
local function etiketler()
	for ad, tr in pairs(ETIKET) do
		local fs = rawget(_G, ad)
		if fs and fs.GetText and fs.SetText then
			local t = fs:GetText()
			if type(t) == "string" and t ~= tr and not G.gizli(t) and not G.turkceMi(t) then fs:SetText(tr) end
		end
	end
end
local function pencere(tur)
	if not G.modul("gorev") then return end
	pcall(etiketler)
	if C_Timer and C_Timer.After then C_Timer.After(0, function() pcall(etiketler) end) end
	local id = GetQuestID and GetQuestID()
	if not id or id == 0 then return end
	local v = veri(id)
	if not v then kaydet(id, GetTitleText and GetTitleText()); return end
	local baslik = ilk("QuestInfoTitleHeader", "QuestTitleText")
	if tur == "detay" then
		yaz(baslik, v.b)
		yaz(ilk("QuestInfoDescriptionText", "QuestDescription"), v.a)
		yaz(ilk("QuestInfoObjectivesText", "QuestObjectiveText"), v.h)
		if not v.a then eksikKaydet(id, "a", ilk("QuestInfoDescriptionText", "QuestDescription")) end
		if not v.h then eksikKaydet(id, "h", ilk("QuestInfoObjectivesText", "QuestObjectiveText")) end
	elseif tur == "ilerleme" then
		yaz(ilk("QuestProgressTitleText"), v.b)
		yaz(ilk("QuestProgressText"), v.i)
		if not v.i then eksikKaydet(id, "i", ilk("QuestProgressText")) end
	elseif tur == "odul" then
		yaz(ilk("QuestInfoTitleHeader", "QuestRewardTitleText"), v.b)
		yaz(ilk("QuestInfoRewardText", "QuestRewardText"), v.t)
		if not v.t then eksikKaydet(id, "t", ilk("QuestInfoRewardText", "QuestRewardText")) end
	end
end

---------------------------------------------------------------- görev günlüğü ayrıntısı
local function gunlukId()
	-- Yeni görev haritası/günlüğü: seçili görev doğrudan kimlikle
	if C_QuestLog and C_QuestLog.GetSelectedQuest then
		local ok, id = pcall(C_QuestLog.GetSelectedQuest)
		if ok and type(id) == "number" and id > 0 then return id end
	end
	if QuestMapFrame and QuestMapFrame.DetailsFrame and QuestMapFrame.DetailsFrame.questID then
		local id = QuestMapFrame.DetailsFrame.questID
		if type(id) == "number" and id > 0 then return id end
	end
	local sec = GetQuestLogSelection and GetQuestLogSelection()
	if not sec or sec == 0 then return nil end
	if C_QuestLog and C_QuestLog.GetQuestIDForLogIndex then
		local ok, id = pcall(C_QuestLog.GetQuestIDForLogIndex, sec)
		if ok and id and id > 0 then return id end
	end
	if GetQuestLogTitle then
		local id = select(8, GetQuestLogTitle(sec))
		if type(id) == "number" and id > 0 then return id end
	end
end

local function gunluk()
	if not G.modul("gorev") then return end
	local id = gunlukId()
	if not id then return end
	local v = veri(id)
	if not v then return end
	-- Eski günlük ve yeni harita ayrıntısı (QuestInfo) yazılarının hepsine uygula
	for _, ad in ipairs({ "QuestLogQuestTitle", "QuestInfoTitleHeader" }) do yaz(_G[ad], v.b) end
	for _, ad in ipairs({ "QuestLogObjectivesText", "QuestInfoObjectivesText" }) do yaz(_G[ad], v.h) end
	for _, ad in ipairs({ "QuestLogQuestDescription", "QuestInfoDescriptionText" }) do yaz(_G[ad], v.a) end
end

---------------------------------------------------------------- bağlantılar
local function sonra(f, ...)
	local a, b = ...
	if C_Timer and C_Timer.After then C_Timer.After(0, function() pcall(f, a, b) end) else pcall(f, a, b) end
end


---------------------------------------------------------------- görev günlüğü taraması
-- Günlükteki her görevin oyunda görünen İngilizce başlığı ve kısa hedefi okunur, Türkçesi görev
-- kimliğiyle (G.Veri) bulunup sözlüğe eklenir. Böylece Forever'ın değiştirdiği metinler de takip
-- listesinde, Questie'de ve ipuçlarında tam eşleşir. Her görev bir kez okunur.
local taranan = {}
-- Yeni kayıtlardan sonra ekrandaki görev yazılarını yeniden çevir
local function yenile()
	if G.cevirBellekSil then pcall(G.cevirBellekSil) end
	if QuestWatch_Update then pcall(QuestWatch_Update) end
	if QuestLog_Update then pcall(QuestLog_Update) end
	if QuestMapFrame and QuestMapFrame:IsShown() and QuestMapFrame_UpdateAll then pcall(QuestMapFrame_UpdateAll) end
end
local function normal(s) return (s:gsub("%s+", " "):gsub("^ ", ""):gsub(" $", "")) end
local function gunlukTara()
	if not G.modul("gorev") or not GetNumQuestLogEntries or not GetQuestLogTitle then return end
	if InCombatLockdown and InCombatLockdown() then return end
	local n = GetNumQuestLogEntries() or 0
	local okunacak, yeniBaslik
	for i = 1, n do
		local baslik, _, _, baslikMi, _, _, _, id = GetQuestLogTitle(i)
		if not baslikMi and baslik then
			if (not id or id == 0) and C_QuestLog and C_QuestLog.GetQuestIDForLogIndex then id = C_QuestLog.GetQuestIDForLogIndex(i) end
			local v = id and veri(id)
			if v then
				if v.b and G.GorevAdi and G.GorevAdi[baslik] == nil then G.GorevAdi[baslik] = v.b; yeniBaslik = true end
				if v.h and not taranan[id] then okunacak = okunacak or {}; okunacak[#okunacak + 1] = { i, id, v } end
			elseif id and id > 0 and not taranan[id] then
				okunacak = okunacak or {}; okunacak[#okunacak + 1] = { i, id, nil, baslik }
			end
		end
	end
	if not okunacak or not SelectQuestLogEntry or not GetQuestLogQuestText then if yeniBaslik then yenile() end return end
	local sec = GetQuestLogSelection and GetQuestLogSelection()
	for _, x in ipairs(okunacak) do
		taranan[x[2]] = true
		SelectQuestLogEntry(x[1])
		local aciklama, hedef = GetQuestLogQuestText()
		if not x[3] then
			-- Çevirisi olmayan görev: İngilizce metniyle kayda yaz ("çevir" akışında çevrilir)
			if G.kaydetDiger and not kaydedilen[x[2]] then
				kaydedilen[x[2]] = true
				G.kaydetDiger("gorevmetin", tostring(x[2]), { baslik = x[4] or "", hedef = hedef or "", metin = aciklama or "" })
			end
		elseif type(hedef) == "string" and hedef ~= "" then
			local k = normal(hedef)
			if G.Arayuz[k] == nil then G.Arayuz[k] = G.doldur and G.doldur(x[3].h) or x[3].h end
		end
	end
	if sec and sec > 0 then SelectQuestLogEntry(sec) end
	yenile()
end
local taramaBekliyor = false
local function taramaIste()
	if taramaBekliyor then return end
	taramaBekliyor = true
	local function calis() taramaBekliyor = false; pcall(gunlukTara) end
	if C_Timer and C_Timer.After then C_Timer.After(0.5, calis) else calis() end
end

local kisaHedefYukle

---------------------------------------------------------------- takip listesi kısa hedefleri
-- Görev takipçisi (Questie / oyunun kendi listesi) kısa hedefi metinle gösteriyor ("- Speak with X in Y.").
-- İngilizce metin oyunda kodları çözülmüş hâlde gelir: $N ad, $C sınıf, $R ırk, $Gerkek:kadın;
-- Bu yüzden anahtarlardaki kodlar oyuncunun bilgileriyle doldurulup arayüz sözlüğüne eklenir.
local function kodCoz(s)
	if not s:find("$", 1, true) then return s end
	local ad = UnitName and UnitName("player") or ""
	local sinif = UnitClass and UnitClass("player") or ""
	local irk = UnitRace and UnitRace("player") or ""
	local kadin = UnitSex and UnitSex("player") == 3
	s = s:gsub("%$[Gg]%s*([^:;]*):([^;]*);", function(e, k) return kadin and k or e end)
	s = s:gsub("%$[Nn]", function() return ad end):gsub("%$[Cc]", function() return sinif end):gsub("%$[Rr]", function() return irk end)
	s = s:gsub("%$[Bb]", " ")
	return (s:gsub("%s+", " "):gsub("^ ", ""):gsub(" $", ""))
end
kisaHedefYukle = function()
	local K, A = G.GorevHedef, G.Arayuz
	if not K or not A then return end
	for en, tr in pairs(K) do
		local k = kodCoz(en)
		if A[k] == nil then A[k] = (G.doldur and tr:find("$", 1, true)) and G.doldur(tr) or tr end
	end
	if G.cevirBellekSil then pcall(G.cevirBellekSil) end
	if QuestWatch_Update then pcall(QuestWatch_Update) end
end

local olay = CreateFrame("Frame")
for _, e in ipairs({ "QUEST_DETAIL", "QUEST_PROGRESS", "QUEST_COMPLETE", "QUEST_LOG_UPDATE", "PLAYER_LOGIN" }) do
	pcall(olay.RegisterEvent, olay, e)
end
olay:SetScript("OnEvent", function(_, e)
	if e == "QUEST_DETAIL" then pcall(pencere, "detay"); sonra(pencere, "detay")
	elseif e == "QUEST_PROGRESS" then pcall(pencere, "ilerleme"); sonra(pencere, "ilerleme")
	elseif e == "QUEST_COMPLETE" then pcall(pencere, "odul"); sonra(pencere, "odul")
	elseif e == "QUEST_LOG_UPDATE" then sonra(gunluk); taramaIste()
	elseif e == "PLAYER_LOGIN" then
		pcall(kisaHedefYukle)
		taramaIste()
		-- Görev penceresi ve günlük çizimine kancalar (oyun metni yeniden yazdığında tekrar çevir)
		if _G.QuestInfo_Display then
			hooksecurefunc("QuestInfo_Display", function(template)
				local log = type(template) == "table" and template.questLog
				if log or (QuestMapFrame and QuestMapFrame:IsVisible()) then pcall(gunluk)
				elseif QuestFrameDetailPanel and QuestFrameDetailPanel:IsShown() then pcall(pencere, "detay")
				elseif QuestFrameRewardPanel and QuestFrameRewardPanel:IsShown() then pcall(pencere, "odul") end
			end)
		end
		if _G.QuestLog_UpdateQuestDetails then hooksecurefunc("QuestLog_UpdateQuestDetails", function() pcall(gunluk) end) end
		if _G.QuestMapFrame_ShowQuestDetails then hooksecurefunc("QuestMapFrame_ShowQuestDetails", function() pcall(gunluk); sonra(gunluk) end) end
		if QuestMapFrame and QuestMapFrame.DetailsFrame and QuestMapFrame.DetailsFrame.HookScript then
			QuestMapFrame.DetailsFrame:HookScript("OnShow", function() sonra(gunluk) end)
		end
		if _G.QuestFrameProgressItems_Update then hooksecurefunc("QuestFrameProgressItems_Update", function() pcall(pencere, "ilerleme") end) end
		if QuestLogFrame and QuestLogFrame.HookScript then QuestLogFrame:HookScript("OnShow", function() sonra(gunluk) end) end
	end
end)

G.gorevPencereCevir, G.gorevGunlukCevir = pencere, gunluk

-- Görev günlüğü / harita ayrıntısı da aynı QuestInfo başlıklarını kullanıyor
if QuestInfo_Display then
	hooksecurefunc("QuestInfo_Display", function()
		if G.modul("gorev") then pcall(etiketler) end
	end)
end
