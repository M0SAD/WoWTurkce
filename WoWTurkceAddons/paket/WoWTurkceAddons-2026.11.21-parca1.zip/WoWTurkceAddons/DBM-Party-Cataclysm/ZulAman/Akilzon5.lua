local mod	= DBM:NewMod(186, "DBM-Party-Cataclysm", 10, 77)
local L		= mod:GetLocalizedStrings()

mod.statTypes = "heroic,timewalker"

mod:SetRevision("20260523021914")
mod:DisableHardcodedOptions()
mod:SetCreatureID(23574)
mod:SetEncounterID(1189)
mod:SetUsedIcons(1, 8)
mod:SetZone(568)

mod:RegisterCombat("combat")

mod:RegisterEventsInCombat(
	"SPELL_AURA_APPLIED 97318",
	"SPELL_CAST_SUCCESS 43648"
)

local warnStormSoon		= mod:NewSoonAnnounce(43648, 5, 3)
local warnPlucked		= mod:NewTargetNoFilterAnnounce(97318, 3)

local specWarnStorm		= mod:NewSpecialWarningMoveTo(43648, nil, nil, nil, 2, 1, nil, nil, "gather")

local timerStorm		= mod:NewCastTimer(8, 43648, nil, nil, nil, 2)
local timerStormCD		= mod:NewCDTimer(55, 43648, nil, nil, nil, 3)

local berserkTimer		= mod:NewBerserkTimer(600)

mod:AddBoolOption("RangeFrame", true)
mod:AddSetIconOption("StormIcon", 43648, true, 0, {1})
mod:AddSetIconOption("SetIconOnEagle", 97318, true, 5, {8})

function mod:OnCombatStart(delay)
	warnStormSoon:Schedule(43)
	timerStormCD:Start(48)
	berserkTimer:Start(-delay)
end


function mod:SPELL_AURA_APPLIED(args)
	if args.spellId == 97318 then
		if args:IsDestTypePlayer() then
			warnPlucked:Show(args.destName)
		else
			self:ScanForMobs(args.destGUID, 2, 8, 1, nil, 10, "SetIconOnEagle")
		end
	end
end

function mod:SPELL_CAST_SUCCESS(args)
	if args.spellId == 43648 then
		specWarnStorm:Show(args.destName)
		specWarnStorm:Play("gather")
		timerStorm:Start()
		warnStormSoon:Schedule(50)
		timerStormCD:Start()
		if self.Options.StormIcon then
			self:SetIcon(args.destName, 1, 8)
		end
	end
end

