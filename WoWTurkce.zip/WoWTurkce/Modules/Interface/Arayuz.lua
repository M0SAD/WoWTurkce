-- Genel arayüz çevirisi: Ayarlar, karakter penceresi (istatistik, itibar, beceriler, onur),
-- grup/raid yöneticisi, ESC menüsü. Pencere açıkken içindeki yazıları tarar ve sözlükte olanları
-- Türkçe yapar. Sadece yazıyı değiştirir; düğmelerin işlevine dokunmaz.
local OLAY_FIIL = { buried="gömüldü", freed="serbest bırakıldı", rescued="kurtarıldı", destroyed="yok edildi",
	explored="keşfedildi", found="bulundu", placed="yerleştirildi", planted="dikildi", cleansed="arındırıldı",
	captured="ele geçirildi", released="serbest bırakıldı", lit="yakıldı", burned="yakıldı", activated="etkinleştirildi",
	collected="toplandı", delivered="teslim edildi", defeated="yenildi", killed="öldürüldü", saved="kurtarıldı",
	escorted="korundu", marked="işaretlendi", investigated="araştırıldı", examined="incelendi", purified="arındırıldı",
	healed="iyileştirildi", discovered="keşfedildi", repaired="onarıldı", extinguished="söndürüldü", doused="söndürüldü",
	poisoned="zehirlendi", tamed="evcilleştirildi", summoned="çağrıldı", banished="sürgün edildi", slain="öldürüldü",
	captured_="ele geçirildi", visited="ziyaret edildi", searched="arandı", opened="açıldı", sabotaged="sabote edildi",
	infected="enfekte edildi", cured="iyileştirildi", fed="beslendi", returned="geri getirildi", protected="korundu",
	exploded="patlatıldı", detonated="patlatıldı", zapped="çarpıldı", shrunk="küçültüldü", touched="dokunuldu" }
local G = WoWTurkce

-- Kaydedilmemesi gereken yazılar: kişisel bilgi (e-posta, link), oyuncu sohbeti, sohbet satırları,
-- cihaz adları ve bilerek İngilizce kalan özel adlar (NPC, bölge, fraksiyon adları)
function G.cop(s)
	if type(s) ~= "string" then return true end
	if s:find("@") or s:find("https?://") or s:find("www%.") then return true end
	if s:find("^%l") or s:find("^%s*/") then return true end
	if s:find(" says: ") or s:find(" yells: ") or s:find(" whispers: ") or s:find(" der: ") or s:find(" bağırır: ") then return true end
	if s:find("Audio") or s:find("Microphone") or s:find("Mikrofon") or s:find("Hoparl") or s:find("Speakers") or s:find("NVIDIA") or s:find("Realtek") or s:find("Radeon") or s:find("Desktop %-") then return true end
	if s:find("^%u%l+ %- %u") or s:find("^%u%l+ %d+ %- %u") then return true end -- "Furkan - Urfa", "Ege 3 - Manisa"
	if s:find("Changed Channel") or s:find("^%d+%. %a") then return true end
	-- Fısıltılar, sohbet satırları ve oyuncu adı geçen sistem mesajları: kişisel, kaydetme
	if s:find("^To %[") or s:find("^%[.-%]") or s:find("%]: ") or s:find(" creates ") or s:find("davet") or s:find("grupta%.") then return true end
	if s:find("%u%l+%-%u%a+") then return true end -- "Ad-Sunucu"
	local ben = UnitName and UnitName("player")
	if ben and ben ~= "" and s:find(ben, 1, true) then return true end
	-- Tek kelimelik, Türkçe/İngilizce olmayan harfli adlar ("Bekadiscó", "Freyjá")
	if not s:find("%s") and s:find("[\195][\128-\191]") and not s:find("[çğıöşüÇĞİÖŞÜ]") then return true end
	-- Yalnızca büyük harfle başlayan kelimelerden oluşan kısa yazılar (özel adlar): "Deathguard Lundmark", "Tirisfal Glades"
	local n, hepsi = 0, true
	for w in s:gmatch("%S+") do
		n = n + 1
		if not (w:find("^%u[%a'%.]*$") or w == "of" or w == "the" or w == "de") then hepsi = false; break end
	end
	if hepsi and n <= 4 then return true end
	return false
end

local KOKLER = {
	"SettingsPanel", "TutorialFrame", "CharacterFrame", "PaperDollFrame", "ReputationFrame", "SkillFrame", "HonorFrame",
	"CompactRaidFrameManager", "GameMenuFrame", "FriendsFrame", "AddonList", "InterfaceOptionsFrame",
	"VideoOptionsFrame", "KeyBindingFrame", "QuestLogFrame", "MerchantFrame", "ClassTrainerFrame",
	"TalentFrame", "PlayerTalentFrame", "LootFrame", "MailFrame", "WorldMapFrame", "StaticPopup1", "StaticPopup2", "StaticPopup3", "StaticPopup4",
	"PVPFrame", "LFGParentFrame", "RaidFrame", "GuildFrame", "WhoFrame", "GossipFrame", "QuestFrame", "TaxiFrame",
	"BankFrame", "TradeFrame", "TradeSkillFrame", "CraftFrame", "PetStableFrame", "TabardFrame", "GuildRegistrarFrame",
	"InspectFrame", "DressUpFrame", "SpellBookFrame", "DropDownList1", "DropDownList2", "DropDownList3",
	"AuctionFrame", "ItemTextFrame", "BattlefieldFrame", "WorldStateScoreFrame", "ReadyCheckFrame", "LFGFrame", "LFTFrame", "ChannelFrame", "ColorPickerFrame", "GuildBankFrame", "PetPaperDollFrame", "BarberShopFrame", "ArenaFrame", "PetitionFrame", "CalendarFrame", "TokenFrame",
	"ChatMenu", "EmoteMenu", "LanguageMenu", "VoiceMacroMenu", "HelpFrame", "TimeManagerFrame", "ChatConfigFrame", "MacroFrame",
}
local ATLA_AD = { WoWTurkcePaylas = true, QuestLogDetailScrollFrame = true, QuestDetailScrollFrame = true,
	QuestProgressScrollFrame = true, QuestRewardScrollFrame = true, GossipGreetingScrollFrame = true, QuestGreetingScrollFrame = true }

-- Birim ipuçlarındaki kelimeler (ırk adları olduğu gibi kalır)
local KELIME = { Player = "Oyuncu", Elite = "Elit", Rare = "Nadir", ["Rare-Elite"] = "Nadir-Elit", Boss = "Boss",
	Beast = "Hayvan", Humanoid = "İnsansı", Demon = "İblis", Elemental = "Elemental", Dragonkin = "Ejderha",
	Giant = "Dev", Mechanical = "Mekanik", Critter = "Hayvancık", ["Not specified"] = "Belirsiz",
	Skinnable = "Yüzülebilir", Corpse = "Ceset", Tapped = "Alınmış", Pet = "Pet", Minion = "Hizmetkâr",
	Herbalism = "Bitkicilik", Mining = "Madencilik", Skinning = "Deri Yüzme", Totem = "Totem" }
local SINIF = { Warrior = "Savaşçı", Paladin = "Paladin", Hunter = "Avcı", Rogue = "Haydut", Priest = "Rahip",
	Shaman = "Şaman", Mage = "Büyücü", Warlock = "Warlock", Druid = "Druid" }

local TUS = {
	["Page Up"] = "Sayfa Yukarı", ["Page Down"] = "Sayfa Aşağı", ["Print Screen"] = "Ekran Görüntüsü",
	["Up Arrow"] = "Yukarı Ok", ["Down Arrow"] = "Aşağı Ok", ["Left Arrow"] = "Sol Ok", ["Right Arrow"] = "Sağ Ok",
	["Mouse Wheel Up"] = "Fare Tekerleği Yukarı", ["Mouse Wheel Down"] = "Fare Tekerleği Aşağı",
	["Middle Mouse"] = "Orta Fare Tuşu", ["Left Mouse Button"] = "Sol Fare Tuşu", ["Right Mouse Button"] = "Sağ Fare Tuşu",
	["Mouse Button 4"] = "Fare Tuşu 4", ["Mouse Button 5"] = "Fare Tuşu 5",
	["Space"] = "Boşluk", ["Backspace"] = "Geri Sil", ["Delete"] = "Sil", ["Insert"] = "Ekle",
	["Home"] = "Baş", ["End"] = "Son", ["Enter"] = "Enter", ["Escape"] = "Esc", ["Tab"] = "Tab",
	["Caps Lock"] = "Büyük Harf Kilidi", ["Scroll Lock"] = "Kaydırma Kilidi", ["Pause"] = "Duraklat",
}
-- "%s's X" başlıkları: "Mosad's Auctions" -> "Mosad'ın Müzayedeleri"
local IYELIK = {
	Auctions = "Müzayedeleri", Pets = "Evcil Hayvanları", Pet = "Evcil Hayvanı", Minion = "Kölesi", Guardian = "Koruyucusu",
	Totem = "Totemi", Mount = "Bineği", Spirit = "Ruhu", House = "Evi", ["New Balance"] = "Yeni Bakiyesi", Statue = "Heykeli",
	["War Banner"] = "Savaş Sancağı", Squire = "Silahtarı", Champion = "Şampiyonu", Bodyguard = "Koruması", Lightwell = "Işık Kuyusu",
	Gateway = "Geçidi", Assistant = "Yardımcısı", Companion = "Yoldaşı", Bank = "Bankası", Mailbox = "Posta Kutusu",
}
local function iyelikCevir(s)
	local ad, ne = s:match("^(.-)'s (.+)$")
	if not ad or ad == "" or not IYELIK[ne] then return nil end
	return ad .. "'" .. ((G.ekUyumla and G.ekUyumla(ad, "ın")) or "ın") .. " " .. IYELIK[ne]
end
G.iyelikCevir = iyelikCevir
local function desenCevir(s)
	do local tr = iyelikCevir(s); if tr then return tr end end
	-- Yalnızca süreden oluşan yazılar: "59 Mins 51 Secs", "2 Days", "3 Hr"; "... remaining" / "Cooldown remaining: ..."
	if s:find("^%d+[%.,]?%d* %a+") then
		local govde, son = s:match("^(.-)%s+(remaining)$")
		local t = govde or s
		local temiz = t:gsub("%d+[%.,]?%d* (%a+)", function(b) return G.sureCevir("1 " .. b) ~= "1 " .. b and "" or b end):gsub("%s+", "")
		if temiz == "" then return G.sureCevir(t) .. (son and " kaldı" or "") end
	end
	do
		local kalan = s:match("^Cooldown remaining: (.+)$") or s:match("^Kalan bekleme süresi: (.+)$")
		if kalan and kalan:find("%d+ %a") then return "Kalan bekleme süresi: " .. G.sureCevir(kalan) end
	end
	-- "Level 2 Undead Priest" -> "Seviye 2 Undead Rahip"
	-- Birim ipucu: "Level 1 Undead Warlock (Player)", "Level ?? Elite Beast", "Level 5 Humanoid"
	local n, kalan = s:match("^Level (%S+) (.+)$")
	if n and (n:find("^%d+$") or n == "??") then
		kalan = kalan:gsub("%((%a+)%)", function(k) return "(" .. (KELIME[k] or k) .. ")" end)
		kalan = kalan:gsub("(%a+)", function(k) return KELIME[k] or k end) -- ırk ve sınıf adları İngilizce kalır
		return "Seviye " .. n .. " " .. kalan
	end
	-- Otomatik takip durumu: "Following Name" / "Following Name."
	do
		local ad = s:match("^Following (.-)%.?$")
		if ad and ad ~= "" then return ad .. " takip ediliyor" end
		if s == "Following" then return "Takip ediliyor" end
	end
	if KELIME[s] then return KELIME[s] end
	-- Karşılaştırma ipucu: "+16 Armor", "-3 Stamina", "+1.5 Damage Per Second"
	local isaret, ozellik = s:match("^([%+%-][%d%.,]+) (.+)$")
	if isaret then
		local tr = G.Arayuz[ozellik] or KELIME[ozellik]
		if tr then return isaret .. " " .. tr end
	end
	-- Retail görev hedefi: "- 0/1 Bring 400 Ancient Mana to Thalyssra", "0/15 Sovereign Soul"
	do
		local onk, sy, gv = s:match("^(%s*%-?%s*)(%d+/%d+) (.+)$")
		if sy and gv then
			local tr = G.Arayuz[gv] or G.esyaAdiGoster(gv) or (G.modul("yaratik") and G.Yaratik[gv])
			if tr and tr ~= gv then return onk .. sy .. " " .. tr end
		end
	end
	-- Görev hedefleri: " - Mindless Zombie slain: 8/8"
	local on, ad, sayi = s:match("^(%s*%-?%s*)(.-) slain: (%d+/%d+)$")
	if ad then return on .. (G.yaratikCevir(ad) or ad) .. " öldürüldü: " .. sayi end
	-- Questie takipçisi: "   Thurman's Remains: 2/5 (Mosad)  [40%]" -> sondaki oyuncu adı ve yüzdeyi ayır
	do
		local bas, kuyruk = s:match("^(.-: %d+/%d+)(%s+.+)$")
		if bas and (kuyruk:match("^%s*%([^%)]*%)%s*$") or kuyruk:match("^%s*%[%d+%%%]%s*$") or kuyruk:match("^%s*%([^%)]*%)%s*%[%d+%%%]%s*$")) then
			local t = desenCevir(bas)
			if t then return t .. kuyruk:gsub("%[(%d+)%%%]", "[%%%1]") end
		end
	end
	on, ad, sayi = s:match("^(%s*%-?%s*)(.-): (%d+/%d+)$")
	-- Olay hedefleri: "Samuel's Remains Buried: 0/1", "Prisoners Freed: 2/5"
	if ad then
		local kok, fiil = ad:match("^(.-) (%a+)$")
		local ftr = fiil and OLAY_FIIL[fiil:lower()]
		if ftr then
			local ktr = G.Arayuz[kok] or G.esyaAdiGoster(kok) or (G.modul("yaratik") and G.Yaratik[kok]) or kok
			return on .. ktr .. " " .. ftr .. ": " .. sayi
		end
	end
	-- Eşya hedefleri her zaman Türkçe; yaratık adları sadece "Yaratık adları" açıkken
	-- Özel görev hedefleri ("Heal and fortify Deathguard Kel: 0/1")
	if ad and G.Arayuz[ad] then return on .. G.Arayuz[ad] .. ": " .. sayi end
	local gad = ad and G.esyaAdiGoster(ad)
	if gad then return on .. gad .. ": " .. sayi end
	if ad and G.modul("yaratik") and G.Yaratik[ad] then return on .. G.Yaratik[ad] .. ": " .. sayi end
	-- Tuş adları: "CTRL-SHIFT-Page Down", "Num Pad 5", "SHIFT-Mouse Wheel Up"
	local mod, tus = "", s
	while true do
		local m, r = tus:match("^(%u+%-)(.+)$")
		if not m then break end
		mod = mod .. m; tus = r
	end
	if tus ~= "" then
		local ttr = TUS[tus]
		if not ttr then
			local n = tus:match("^Num Pad (.+)$")
			if n then ttr = "Sayı Tuşu " .. n end
		end
		-- Genel kelimelerle karışabilecek tuşlar sadece "CTRL-" gibi önekle çevrilir
		if ttr and mod == "" and (tus == "Home" or tus == "End" or tus == "Delete" or tus == "Insert" or tus == "Space" or tus == "Pause" or tus == "Enter" or tus == "Escape" or tus == "Tab") then ttr = nil end
		if ttr then return mod .. ttr end
	end
	-- İsim içeren arayüz kalıpları (arkadaş notu, davet...)
	local kim = s:match("^Set Notes for (.+)$")
	if kim then return kim .. " için not yaz" end
	-- Tarih: "Sunday, November 01, 2026 at 22:38"
	local gun, ay, gn, yil, saat = s:match("^%s*(%a+), (%a+) (%d+), (%d+) at (%d+:%d+)%s*$")
	if gun then
		local GUN = { Monday = "Pazartesi", Tuesday = "Salı", Wednesday = "Çarşamba", Thursday = "Perşembe", Friday = "Cuma", Saturday = "Cumartesi", Sunday = "Pazar" }
		local AY = { January = "Ocak", February = "Şubat", March = "Mart", April = "Nisan", May = "Mayıs", June = "Haziran", July = "Temmuz", August = "Ağustos", September = "Eylül", October = "Ekim", November = "Kasım", December = "Aralık" }
		if GUN[gun] and AY[ay] then return tonumber(gn) .. " " .. AY[ay] .. " " .. yil .. " " .. GUN[gun] .. ", " .. saat end
	end
	-- Harita koordinatları: "Cursor: 74.8 X, 49.2 Y  |  Player: 58.3 X , 51.5 Y"
	if s:find("^Cursor: ") then
		local r = s:gsub("^Cursor:", "İmleç:"):gsub("Player:", "Oyuncu:")
		return r
	end
	kim = s:match("^Do you want to make (.+) your new home%?$")
	if kim then return kim .. " yeni evin olsun mu?" end
	kim = s:match("^Discovered: (.+)$")
	if kim then return "Keşfedildi: " .. kim end
	local yer, xp = s:match("^Discovered (.+): (%d+) experience gained$")
	if yer then return "Keşfedildi: " .. yer .. " (+" .. xp .. " deneyim)" end
	kim = s:match("^Friends of (.+)$")
	if kim then return "Arkadaşları: " .. kim end
	kim = s:match("^(.-) %(Mutual%)$")
	if kim then return kim .. " (Ortak)" end
	kim = s:match("^Corpse of (.+)$")
	if kim then return "Ceset: " .. kim end
	kim = s:match("^(.+)'s Minion$")
	if kim then return "Uşak (" .. kim .. ")" end
	kim = s:match("^(.+)'s Pet$")
	if kim then return "Evcil Hayvan (" .. kim .. ")" end
	kim = s:match("^Do you want to destroy (.+)%?$")
	if kim then return (G.esyaAdiGoster(kim) or kim) .. " yok edilsin mi?" end
	local bolge, diyar = s:match("^Zone: (.-)|nRealm: (.+)$")
	if bolge then return "Bölge: " .. bolge .. "|nDiyar: " .. diyar end
	kim = s:match("^(.+) has challenged you to a duel%.$")
	if kim then return kim .. " seni düelloya davet etti." end
	kim = s:match("^You have requested to trade with (.+)%.$")
	if kim then return kim .. " ile takas isteği gönderdin." end
	kim = s:match("^(.+) attempts to run away in fear!$")
	if kim then return kim .. " korku içinde kaçmaya çalışıyor!" end
	kim = s:match("^Requires:? (.+)$")
	if kim then
		local tr = G.isimCevir(kim) or G.esyaAdiGoster(kim)
		if tr then return "Gerekli: " .. tr end
	end
	local yeni = s:match("^You have learned a new spell: (.+)%.$")
	if yeni then return "Yeni bir büyü öğrendin: " .. ((G.buyuAdiCevir and G.buyuAdiCevir(yeni)) or yeni) .. "." end
	on, ad = s:match("^(%s*%-?%s*)(.-) %(Complete%)$")
	if ad then return on .. (G.GorevAdi[ad] or ad) .. " (Tamamlandı)" end
	-- Açılır menü: "Loot: Group Loot", "Pass on Loot: No"
	local etiket, deger = s:match("^(.-): (.+)$")
	if etiket and G.Arayuz[etiket .. ":"] then return G.Arayuz[etiket .. ":"] .. " " .. (G.Arayuz[deger] or deger) end
	-- Çıkış geri sayımı: "20 Seconds until logout", "1 Min until exit"
	local sayi, birim, ne = s:match("^(%d+) (%a+%.?) until (%a+)%.?$")
	if sayi then
		local b = birim:lower():sub(1, 3)
		b = (b == "sec" and "saniye") or (b == "min" and "dakika") or (b == "hou" and "saat") or birim
		local hedef = (ne == "logout" and "Oturumun kapanmasına") or (ne == "exit" or ne == "quit") and "Oyundan çıkışa" or nil
		if hedef then return hedef .. " " .. sayi .. " " .. b end
	end
	local bilgi = s:match("^For more information see our (.+)$")
	if bilgi then return "Daha fazla bilgi için: " .. bilgi:gsub("Privacy Policy", "Gizlilik Politikası") end
	-- Açılır uyarılar
	local g = s:match("^Abandon (.+)%?$")
	if g then return (G.GorevAdi[g] or g) .. " görevini bırakmak istiyor musun?" end
	g = s:match("^Do you want to delete (.+)%?$")
	if g then return g .. " silinsin mi?" end
	g = s:match("^(.+) has invited you to join a group%.$")
	if g then return g .. " seni bir gruba davet etti." end
	g = s:match("^(.+) has invited you to join the guild (.+)%.$")
	g = s:match("^Quest accepted: (.+)$")
	if g then return "Görev kabul edildi: " .. (G.GorevAdi[g] or g) end
	g = s:match("^(.+) completed%.$")
	if g and G.GorevAdi[g] then return G.GorevAdi[g] .. " tamamlandı." end
	g = s:match("^You receive item: %[(.+)%]%.?$")
	if g then return "Eşya aldın: [" .. (G.EsyaAdi[g] or g) .. "]." end
	g = s:match("^You receive loot: (.+)$")
	if g then return "Ganimet aldın: " .. g end
	local dil = s:match("^Language: (.+)$")
	if dil then return "Dil: " .. dil end
	local a, b = s:match("^(.-):%s*(.+)$") -- "Etiket: değer"
	if a and G.Arayuz[a .. ":"] and not b:find("%a") then return G.Arayuz[a .. ":"] .. " " .. b end
	-- Oyunun kendi isimli/değişkenli metinleri (GlobalStrings desenleri)
	-- Önce birebir sözlükler (oyun ipuçları, büyü açıklamaları...), en son genel desenler
	local tam = G.cevir(G.Egitim, s) or G.cevir(G.Buyu, s) or G.cevir(G.Secenek, s) or G.cevir(G.Hata, s)
	if tam then return tam end
	if G.globalDesenCevir then return G.globalDesenCevir(s) end
end

local cevirAsil
local function renksiz(s)
	return (s:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|cn[%w_]+:", ""):gsub("|[rR]", ""))
end
G.renksiz = renksiz
-- Simgeyi ayır: baştaki ya da sondaki "|A:..|a" / "|T..|t"
local function simgeAyir(s)
	local bas, kalan = s:match("^(|[AT].-|[at]%s*)(.+)$")
	if bas then return bas, kalan, "" end
	local kalan2, son = s:match("^(.-)(%s*|[AT].-|[at])$")
	if kalan2 and kalan2 ~= "" then return "", kalan2, son end
	return "", s, ""
end
G.simgeAyir = simgeAyir
local function cevir(s)
	if G.gizli(s) or type(s) ~= "string" or s == "" or G.turkceMi(s) then return nil end
	local bas, kalan, son = simgeAyir(s)
	if bas ~= "" or son ~= "" then
		local tr = cevirAsil(kalan)
		return tr and (bas .. tr .. son)
	end
	return cevirAsil(s)
end
local paragrafCevir
cevirAsil = function(s)
	if not s or s == "" or G.turkceMi(s) then return nil end
	if s:find("|n", 1, true) then
		-- "|n" satır sonu: önce bütün, olmazsa satır satır çevir (çevrilemeyen satır olduğu gibi kalır)
		local tam = G.cevir(G.Arayuz, renksiz(s):gsub("|n", " "))
		if tam then return tam end
		local parcalar, biri = {}, false
		for satir in (s .. "|n"):gmatch("(.-)|n") do
			local tr = satir:find("%S") and cevirAsil(satir)
			if tr then biri = true end
			parcalar[#parcalar + 1] = tr or satir
		end
		if biri and #parcalar > 1 then return table.concat(parcalar, "|n") end
	end
	if s:find("\n%s*\n") then
		local tr = paragrafCevir(s)
		if tr then return tr end
	end
	if s:find("\n") and not s:find("\n%s*\n") then
		-- Tek satır sonlarıyla ayrılmış satırlar: her satırı ayrı çevir
		local tam = G.cevir(G.Arayuz, renksiz(s))
		if tam then return tam end
		local parcalar, n = {}, 0
		for satir in (s .. "\n"):gmatch("(.-)\n") do
			n = n + 1
			if satir:find("%S") then
				local tr = cevirAsil(satir)
				if not tr then parcalar = nil; break end
				parcalar[n] = tr
			else parcalar[n] = satir end
		end
		if parcalar and n > 1 then return table.concat(parcalar, "\n") end
	end
	local temiz = renksiz(s)
	-- Tam büyü adı önce ("Power Word: Shield" -> "Güç Sözü: Kalkan"; yarım çeviri olmasın)
	local tr = G.cevir(G.Arayuz, temiz)
	if not tr and G.BuyuAdi then
		-- Eğitmen listelerinde adlar baştaki boşluklarla gelir ("  Power Word: Shield")
		local bas, sade = temiz:match("^(%s*)(.-)%s*$")
		local b = sade and (G.BuyuAdi[sade] or (G.buyuAdiCevir and G.buyuAdiCevir(sade)))
		if b then tr = bas .. b end
	end
	tr = tr or desenCevir(temiz)
	if not tr then
		-- Görev günlüğündeki görev adları ("  The Mindless Ones", "[5] Rude Awakening")
		local bosluk, on, ad = temiz:match("^(%s*)(%[[^%]]+%]%s*)(.-)$")
		if not ad then bosluk, ad = temiz:match("^(%s*)(.-)$"); on = "" end
		if ad and G.GorevAdi[ad] then tr = bosluk .. on .. G.GorevAdi[ad] end
	end
	if not tr then
		-- Büyü ve eşya adları, "Rank 3" alt başlıkları
		tr = G.buyuAdiCevir and G.buyuAdiCevir(temiz) or G.EsyaAdi[temiz]
		if not tr then
			local n = temiz:match("^Rank (%d+)$")
			if n then tr = "Rütbe " .. n end
		end
		if not tr and G.BuyuAlt[temiz] then tr = G.BuyuAlt[temiz] end
		if not tr then tr = G.yaratikCevir(temiz) end
	end
	if not tr then
		-- Diğer sözlükler: oyun ipuçları, büyü açıklamaları, konuşma seçenekleri, hata mesajları
		tr = G.cevir(G.Egitim, temiz) or G.cevir(G.Buyu, temiz) or G.cevir(G.Secenek, temiz) or G.cevir(G.Hata, temiz)
	end
	if not tr and s:find("|c%x%x%x%x%x%x%x%x") then
		-- Renkli parçalı yazılar: "Buyout Price |cff808080(optional)|r" -> her parçayı ayrı çevir
		local parcalar, hepsi, biri = {}, true, false
		local i = 1
		local function parca(metin, onEk, sonEk)
			if metin:find("%a") then
				local b, govde, son = metin:match("^(%s*)(.-)(%s*)$")
				local t = G.cevir(G.Arayuz, govde) or desenCevir(govde)
				if t then biri = true; metin = b .. t .. son else hepsi = false end
			end
			parcalar[#parcalar + 1] = onEk .. metin .. sonEk
		end
		while true do
			local a, b, renk, ic = s:find("(|c%x%x%x%x%x%x%x%x)(.-)|r", i)
			if not a then parca(s:sub(i), "", ""); break end
			if a > i then parca(s:sub(i, a - 1), "", "") end
			parca(ic, renk, "|r")
			i = b + 1
		end
		if hepsi and biri then return table.concat(parcalar) end
	end
	if not tr then
		-- "ETİKET: açıklama" satırları (ayar ipuçları: "CMAA: Conservative ...")
		local etiket, aciklama = temiz:match("^([^:]+):%s+(.+)$")
		if etiket and #etiket <= 40 then
			local atr = G.cevir(G.Arayuz, aciklama) or desenCevir(aciklama)
			if atr then
				local i, j = s:find(aciklama, 1, true)
				local etr = G.cevir(G.Arayuz, etiket)
				if i then
					local yeni = s:sub(1, i - 1) .. atr .. s:sub(j + 1)
					if etr then
						local a, b = yeni:find(etiket, 1, true)
						if a then yeni = yeni:sub(1, a - 1) .. etr .. yeni:sub(b + 1) end
					end
					return yeni
				end
				return (etr or etiket) .. ": " .. atr
			end
		end
	end
	if not tr then
		-- Renkli etiketli kaynak satırı: |cFFFFD200Vendor: |rAd  -> etiket sarı kalır, değer beyaz
		local bas, et, ara, dg = s:match("^(|c%x%x%x%x%x%x%x%x)(%a[%a ]-):(%s*)|r(.+)$")
		local etr = et and G.EtiketTr and G.EtiketTr[et]
		if etr then
			local ds = G.cevir(G.Arayuz, renksiz(dg)) or dg
			for en, trk in pairs(G.DurumTr or {}) do ds = ds:gsub(" %- " .. en .. "$", " - " .. trk) end
			return bas .. etr .. ":" .. ara .. "|r" .. ds
		end
	end
	if not tr then
		-- Kaynak satırları: "Vendor: Ad", "Zone: Ad", "Faction: Ad - Exalted", "Cost: 100" (ad ve değer İngilizce kalır)
		local et, dg = temiz:match("^(%a[%a ]-):%s*(.+)$")
		local etr = et and G.EtiketTr and G.EtiketTr[et]
		if etr then
			local ds = G.cevir(G.Arayuz, dg) or dg
			for en, trk in pairs(G.DurumTr or {}) do ds = ds:gsub(" %- " .. en .. "$", " - " .. trk) end
			tr = etr .. ": " .. ds
		end
	end
	if not tr then
		-- Baştaki boşluklarla girintili adlar ("  Power Word: Fortitude" - eğitmen/makro listeleri)
		local bosluk, govde = temiz:match("^(%s+)(%S.-)$")
		if govde then
			local gtr = G.cevir(G.Arayuz, govde) or (G.buyuAdiCevir and G.buyuAdiCevir(govde)) or G.EsyaAdi[govde]
			if gtr then tr = bosluk .. gtr end
		end
	end
	if not tr then
		-- Oyuncu adı geçen yazılar: "... for you, Mosad?" -> sözlükte "$N"
		local oyuncu = UnitName and UnitName("player")
		if oyuncu and oyuncu ~= "" then
			local kac = oyuncu:gsub("(%W)", "%%%1")
			if temiz:find(kac) then
				local ntr = G.cevir(G.Arayuz, (temiz:gsub(kac, "$N")))
				if ntr then tr = ntr:gsub("%$N", (oyuncu:gsub("%%", "%%%%"))) end
			end
		end
	end
	if tr and temiz ~= s then
		-- renk kodunu koru
		local bas = s:match("^(|c%x%x%x%x%x%x%x%x)")
		if bas then tr = bas .. tr .. "|r" end
	end
	return tr
end
-- Paragraflara bölüp her birini ayrı çevir (hepsi çevrilirse birleştir)
paragrafCevir = function(s)
	local tam = G.cevir(G.Arayuz, (s:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", "")))
	if tam then return tam end
	local parcalar, n, biri = {}, 0, false
	for p in (s .. "\n\n"):gmatch("(.-)\n%s*\n") do
		if p:find("%S") then
			n = n + 1
			local tr = cevirAsil(p)
			if tr then biri = true end
			parcalar[n] = tr or p
		end
	end
	if n < 2 or not biri then return nil end
	return table.concat(parcalar, "\n\n")
end
G.arayuzCevir = cevir

local kaydedilen = 0
local function kaydet(s)
	if kaydedilen > 30000 or not G.ayar("kayit") then return end
	if s:find("WoWTurkce") or s:find("WoWTurkce") or s:find("^Level level") then return end
	local _, ic = simgeAyir(s)
	s = renksiz(ic):gsub("|H.-|h(.-)|h", "%1")
	if s:find("|[TKA]") then return end
	if #s < 3 or #s > 600 or not s:find("%a%a") then return end
	-- Tek kelimelik büyük harfle başlayan yazılar çoğunlukla oyuncu/NPC adıdır: kaydetme
	if not s:find("[ :]") and s:find("^%u[%l']+$") then return end
	if not s:find(" ") and s:find("%-") then return end
	if s:find("^%S+%-%S+,") or s:find("^%u+%d+$") then return end -- oyuncu-sunucu adları
	if s:find("^<") or s:find("^%[") then return end -- guild adları, sohbet kanalları
	if s:find("^%s*/") then return end -- sohbet komutları (/dance, /reload)
	if not s:find("%u") then return end -- tamamı küçük harf: oyuncu sohbeti
	if G.Yaratik[s] then return end -- yaratık adları bilerek İngilizce kalıyor
	local yad = s:match("^(.-) %(.+%)$"); if yad and G.Yaratik[yad] then return end
	if G.cop(s) then return end
	if s:find("%(VB%-Audio") or s:find("Audio") or s:find("Microphone") or s:find("NVIDIA") or s:find("Mikrofon") or s:find("Hoparl") then return end -- cihaz adları
	if s:find("%a%-%u%l") and s:find("%u%l+%-%u%l+") then return end -- "Ad-Sunucu" geçen yazılar
	-- Kendi çıktılarımız: "Türkçe (English)" biçimi
	local ic = s:match("^.+ %((.+)%)$")
	if ic and (G.EsyaAdi[ic] or G.BuyuAdi[ic]) then return end
	-- Kendi çevirilerimizi (Türkçe harfsiz olanlar dahil) tekrar kaydetme
	if not G.cevirDegerleri then
		local d = {}
		for _, tablo in ipairs({ G.Arayuz, G.BuyuAdi, G.EsyaAdi, G.GorevAdi, G.Egitim, G.Hata, G.Secenek, G.Esya, G.BuyuAlt, G.BuyuSekme, G.Yaratik }) do
			for _, v in pairs(tablo) do if type(v) == "string" then d[(v:gsub("{%d}", "#"))] = true end end
		end
		G.cevirDegerleri = d
	end
	local norm = s:gsub("%d+", "#")
	if G.cevirDegerleri[norm] or s:find("^Seviye ") then return end
	local kok = norm:match("^(.-)%s*%(%u+%)$") -- "Sosyal (O)"
	if kok and G.cevirDegerleri[kok] then return end
	kaydedilen = kaydedilen + 1
	G.kaydetDiger("arayuz", (s:gsub("%d+", "#")))
end

local gorulen = setmetatable({}, { __mode = "k" }) -- fontstring -> son yazdığımız metin
-- Sohbet yazma kutusu ("Konuş:" gibi başlıklar) ve diğer yazı kutuları: genişlik İngilizceye göre
-- ayarlandığı için çevirince yazılar iç içe geçiyor; bunlara hiç dokunma.
-- Uzmanlık (specialization) adları İngilizce kalır: Demon Hunter / Havoc gibi
local UZMAN_NET = {}
for ad in ("Havoc|Vengeance|Devourer|Arms|Beast Mastery|Marksmanship|Survival|Assassination|Outlaw|Subtlety|Discipline|Elemental|Enhancement|Restoration|Affliction|Demonology|Destruction|Balance|Feral|Guardian|Brewmaster|Mistweaver|Windwalker|Devastation|Preservation|Augmentation|Unholy|Retribution"):gmatch("[^|]+") do UZMAN_NET[ad] = true end
local UZMAN_BELIRSIZ = { Holy = true, Shadow = true, Frost = true, Fire = true, Arcane = true, Blood = true, Protection = true, Fury = true }
local function uzmanAdi(fs)
	local t = fs.GetText and fs:GetText()
	if type(t) ~= "string" then return false end
	if UZMAN_NET[t] then return true end
	if UZMAN_BELIRSIZ[t] then
		local p, n = fs, 0
		while p and n < 6 do
			local pn = p.GetName and p:GetName()
			if pn and (pn:find("Spec") or pn:find("Talent") or pn:find("PlayerSpells") or pn:find("Inspect")) then return true end
			p = p.GetParent and p:GetParent(); n = n + 1
		end
	end
	return false
end

local function yaziKutusunda(fs)
	if uzmanAdi(fs) then return true end
	local ad = fs.GetName and fs:GetName()
	local u = fs.GetParent and fs:GetParent()
	-- Arama kutusunun silik ipucu yazısı ("Search") çevrilebilir; yalnızca yazılan metin dokunulmaz
	if u and u.Instructions == fs then return false end
	if ad and ad:find("EditBox") then return true end
	if u and u.GetObjectType and u:GetObjectType() == "EditBox" then return true end
	local un = u and u.GetName and u:GetName()
	if un and un:find("EditBox") then return true end
	-- Bölge adları (minimap başlığı, bölge afişi) İngilizce kalır
	local p, n = fs, 0
	while p and n < 4 do
		local pn = p.GetName and p:GetName()
		if pn and (pn:find("ZoneText") or pn:find("MinimapZone")) then return true end
		p = p.GetParent and p:GetParent(); n = n + 1
	end
	return false
end
G.yaziKutusunda = yaziKutusunda

local function yaziIsle(fs)
	if yaziKutusunda(fs) then return end
	local t = fs:GetText()
	-- Kendi eklediğimiz gri Türkçe ad notu varsa bir daha işleme (iç içe "(Acemi Elreth (Acemi Elreth))" olmasın)
	if type(t) == "string" and t:find("|cffaaaaaa(", 1, true) then return end
	if G.gizli(t) then return end
	if not t or t == "" or gorulen[fs] == t then return end
	local tr = cevir(t)
	if tr then
		G.sigdirKoy(fs, tr); gorulen[fs] = tr
		G.tani.cevrilen = G.tani.cevrilen + 1
	else
		gorulen[fs] = t
		if not G.turkceMi(t) then G.sigdirSifirla(fs); kaydet(t) end
	end
end

G.tani = { taranan = 0, cevrilen = 0, hata = nil }
local function guvenliIsle(fs)
	G.tani.taranan = G.tani.taranan + 1
	local ok, e = pcall(yaziIsle, fs)
	if not ok then G.tani.hata = tostring(e) end
end

local function tara(f, derin)
	if derin > 14 or not f or (f.IsForbidden and f:IsForbidden()) then return end
	if f.IsShown and not f:IsShown() then return end
	local ad = f.GetName and f:GetName()
	if ad and ATLA_AD[ad] then return end
	if f.GetObjectType and f:GetObjectType() == "FontString" then guvenliIsle(f); return end
	if f.GetRegions then
		for _, r in ipairs({ f:GetRegions() }) do
			if r.GetObjectType and r:GetObjectType() == "FontString" and r:IsShown() then guvenliIsle(r) end
		end
	end
	-- Düğme yazıları (GetFontString)
	if f.GetFontString then local ok, fs = pcall(f.GetFontString, f); if ok and fs then guvenliIsle(fs) end end
	if f.GetChildren then
		for _, c in ipairs({ f:GetChildren() }) do
			local ok, e = pcall(tara, c, derin + 1)
			if not ok then G.tani.hata = tostring(e) end
		end
	end
end

-- İpucu kutusunu satırlarına sığdır. Savaşta kutu boyutu değiştirilemeyebilir:
-- o zaman taşan satırın yazısını kutuya sığacak kadar küçült.
local ipucuFontAsil = {}
local function ipucuSigdir(tt)
	if not tt or not tt.NumLines or (tt.IsForbidden and tt:IsForbidden()) then return end
	pcall(tt.Show, tt)
	local ad = tt:GetName(); if not ad then return end
	local en = tt:GetWidth() or 0
	for i = 1, tt:NumLines() do
		local fs = _G[ad .. "TextLeft" .. i]
		local sag = _G[ad .. "TextRight" .. i]
		if fs and fs:IsShown() and fs:GetText() then
			if not ipucuFontAsil[fs] then local f, b, st = fs:GetFont(); if f then ipucuFontAsil[fs] = { f, b, st or "" } end end
			local gerek = (fs:GetStringWidth() or 0) + ((sag and sag:IsShown() and sag:GetText()) and (sag:GetStringWidth() + 12) or 0) + 22
			-- Satır kaydırılan (çok satırlı) yazılar kutuyu genişletmez; aksi hâlde ipucu ekran boyu açılıyor
			-- Kaydırılabilen satırlar (açıklamalar) hiç genişletme sebebi sayılmaz: yoksa satır bir tek bir çift satır
			-- olup ipucu her yenilemede genişleyip daralıyor (titreme)
			local cokSatir = (fs.GetNumLines and (fs:GetNumLines() or 1) > 1) or (fs.CanWordWrap and fs:CanWordWrap())
			if cokSatir then gerek = 0 end
			if gerek > 420 then gerek = 420 end
			if gerek > en + 1 then
				local ok = pcall(tt.SetWidth, tt, gerek)
				if not ok or (tt:GetWidth() or 0) + 1 < gerek then
					local a = ipucuFontAsil[fs]
					if a then
						local oran = math.max(0.6, (en - 22 - (gerek - 22 - fs:GetStringWidth())) / fs:GetStringWidth())
						if oran < 1 then if G.fontSerbest(fs) then fs:SetFont(a[1], math.floor(a[2] * oran * 10) / 10, a[3]) end end
					end
				else
					en = tt:GetWidth()
				end
			end
		end
	end
end
local function ipucuFontSifirla(tt)
	local ad = tt and tt.GetName and tt:GetName(); if not ad then return end
	for i = 1, 4 do
		local fs = _G[ad .. "TextLeft" .. i]
		local a = fs and ipucuFontAsil[fs]
		if a then if G.fontSerbest(fs) then fs:SetFont(a[1], a[2], a[3]) end end
	end
end
G.ipucuSigdir = ipucuSigdir
-- Genel ipuçları (düğme, mini harita, menü çubuğu ipuçları). Eşya/büyü/birim ipuçlarına dokunmaz.
local function ipucuTara(tt)
	if not G.modul("arayuz") or not tt or not tt.NumLines then return end
	if tt.GetItem and select(2, tt:GetItem()) then return end
	local birim = tt.GetUnit and tt:GetUnit()
	if G.gizli(birim) then birim = true end -- Retail: gizli birim adı; yine birim ipucu say
	local ad = tt:GetName(); if not ad then return end
	local degisti = false
	-- Oyuncu ipucu: adı ve lonca adı asla çevrilmez
	local oyuncu = false
	if birim and birim ~= true then
		local ok, op = pcall(UnitIsPlayer, birim)
		oyuncu = ok and op and true or false
		if oyuncu then G.oyuncuEkle(birim) end
	end
	if oyuncu then
		for i = 2, tt:NumLines() do
			local fs = _G[ad .. "TextLeft" .. i]
			local t = fs and fs:IsShown() and fs:GetText()
			if t and not G.gizli(t) and not G.turkceMi(t) then
				local tr = desenCevir(G.renksiz(t))
				if tr then fs:SetText(tr); degisti = true end
			end
		end
		if degisti then ipucuSigdir(tt) end
		return
	end
	if birim then
		local fs = _G[ad .. "TextLeft1"]
		local t = fs and fs:GetText()
		if G.gizli(t) then t = nil end
		local temiz = t and G.renksiz(t)
		local ytr = temiz and G.yaratikCevir(temiz)
		if ytr then
			local gos = G.adStil("stilYaratik", ytr, temiz, "|cffaaaaaa")
			fs:SetText((t:gsub(temiz:gsub("(%W)", "%%%1"), (gos:gsub("%%", "%%%%"))))); degisti = true
		elseif temiz and G.modul("arayuz") and not t:find("|cffaaaaaa(", 1, true) and not temiz:find("(", 1, true) and G.adTr(temiz) then
			-- Yaratık/NPC adları kapalı: orijinal ad kalır, yanına Türkçesi gri yazılır
			if G.ayar("stilYaratik") ~= "en" then
				fs:SetText((t:gsub(temiz:gsub("(%W)", "%%%1"), (G.adStil("stilYaratik", G.adTr(temiz), temiz, "|cffaaaaaa"):gsub("%%", "%%%%"))))); degisti = true
			end
		end
	end
	for i = (birim and 2 or 1), tt:NumLines() do
		for _, taraf in ipairs({ "TextLeft", "TextRight" }) do
			local fs = _G[ad .. taraf .. i]
			local t = fs and fs:IsShown() and fs:GetText()
			if G.gizli(t) then t = nil end
			if t and t ~= "" and not G.turkceMi(t) then
				local tr = cevir(t)
				if not tr then
					-- "Character Info (C)" gibi kısayol ekli başlıklar
					local duz = t:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", "")
					local kok, ek = duz:match("^(.-)%s*(%b())$")
					local ktr = kok and cevir(kok)
					if ktr then tr = ktr .. " |cffffd200" .. ek .. "|r" end
				end
				if not tr and birim then
					-- NPC ünvanı: "<Innkeeper>" -> "<Hancı>"
					local u = t:match("^<(.+)>$")
					if u and G.Arayuz[u] then tr = "<" .. G.Arayuz[u] .. ">" end
				end
				if tr then fs:SetText(tr); degisti = true elseif not birim then kaydet(t) end
			end
		end
	end
	if degisti then ipucuSigdir(tt) end
end

-- TAM TARAMA: oyundaki tüm görünür çerçevelerin sabit yazılarını (XML'de baştan yazılmış,
-- sonradan hiç değişmeyen "Display Tips" gibi) bir kez işler. Yeni açılan çerçeveler de yakalanır.
local islenmis = setmetatable({}, { __mode = "k" })
local function tamTarama()
	if not G.modul("arayuz") or not EnumerateFrames then return end
	if G.RETAIL and InCombatLockdown and InCombatLockdown() then return end
	local f = EnumerateFrames()
	local n = 0
	while f do
		if not (f.IsForbidden and f:IsForbidden()) and f:IsVisible() and islenmis[f] ~= "atla" then
			local ad = f:GetName()
			local atla = ad and ad:find("^NamePlate")
			local u, d = f, 0
			while u and d < 8 and not atla do
				local un = u.GetName and u:GetName()
				if un and (ATLA_AD[un] or un:find("^NamePlate") or un:find("ScrollChild")) then atla = true end
				u = u.GetParent and u:GetParent(); d = d + 1
			end
			if atla then islenmis[f] = "atla" else
				for _, r in ipairs({ f:GetRegions() }) do
					if r.GetObjectType and r:GetObjectType() == "FontString" and r:IsShown() then guvenliIsle(r) end
				end
				n = n + 1
			end
		end
		f = EnumerateFrames(f)
	end
	return n
end

local zamanlayici
local function hepsiniTara()
	if not G.modul("arayuz") then return end
	local acikVar = false
	for _, ad in ipairs(KOKLER) do
		local f = _G[ad]
		if type(f) == "table" and f.IsShown and f:IsShown() then
			acikVar = true
			local ok, e = pcall(tara, f, 0)
			if not ok then G.tani.hata = tostring(e) end
		end
	end
	-- Yeni menü sistemi: adı olmayan açılır menüler (portre sağ tık, ganimet ayarları vb.)
	pcall(function()
		for _, c in ipairs({ UIParent:GetChildren() }) do
			if not (c.IsForbidden and c:IsForbidden()) and c:IsShown() and not c:GetName() then
				local strata = c:GetFrameStrata()
				if strata == "FULLSCREEN_DIALOG" or strata == "FULLSCREEN" or strata == "DIALOG" or strata == "TOOLTIP" then
					local ok, e = pcall(tara, c, 0)
					if not ok then G.tani.hata = tostring(e) end
				end
			end
		end
	end)
end

local function baslat()
	if not G.modul("arayuz") then return end
	C_Timer.After(0, hepsiniTara)
	if not zamanlayici then zamanlayici = C_Timer.NewTicker(0.3, hepsiniTara) end
end
G.arayuzTara = baslat

-- GENEL YAKALAYICI: oyundaki her yazı alanına (FontString) yazı konduğu anda bakar.
-- Sözlükte varsa Türkçesini koyar, yoksa (anlamlıysa) kaydeder. Menüler, büyü kitabı,
-- sonradan açılan pencereler dahil her şeyi yakalar.
local hizli = {}      -- ham yazı -> çeviri ya da false (sayısız yazılar için)
local hizliSayi = 0
local sablonYok = {}  -- sayılı yazıların şablonu -> çevirisi yok
local yakalayiciAcik = true
-- "Yaratık adları" ayarı değişince önbelleği boşalt; görev penceresi yeniden çizilsin
G.dinleyiciler[#G.dinleyiciler + 1] = function(k)
	if k ~= "yaratik" and k ~= "arayuz" and k ~= "npc" then return end
	wipe(hizli); wipe(sablonYok); hizliSayi = 0
	pcall(function()
		if QuestLog_UpdateQuestDetails and QuestLogFrame and QuestLogFrame:IsShown() then QuestLog_UpdateQuestDetails() end
		if QuestWatch_Update then QuestWatch_Update() end
	end)
end
local function gorevMetniMi(fs)
	local u, d = fs, 0
	while u and d < 10 do
		local ad = u.GetName and u:GetName()
		if ad and (ATLA_AD[ad] or ad:find("^Quest") or ad:find("^Gossip") or ad:find("ScrollChild") or ad:find("^ChatFrame") or ad:find("^NamePlate")) then return true end
		u = u.GetParent and u:GetParent(); d = d + 1
	end
end
-- İpucu (tooltip) içindeki yazı değişince kutuyu yeni yazıya göre yeniden boyutlandır
local bekleyenIpucu = {}
local function ipucuBul(fs)
	local u = fs.GetParent and fs:GetParent()
	for _ = 1, 2 do
		if not u then return end
		if u.GetObjectType and u:GetObjectType() == "GameTooltip" then return u end
		u = u.GetParent and u:GetParent()
	end
end
local function koyYaz(fs, tr)
	local tt = ipucuBul(fs)
	if not tt then return G.sigdirKoy(fs, tr) end
	fs:SetText(tr) -- ipucunda küçültme yok: kutu büyüsün
	if not bekleyenIpucu[tt] then
		bekleyenIpucu[tt] = true
		C_Timer.After(0, function()
			bekleyenIpucu[tt] = nil
			if tt:IsShown() then pcall(ipucuSigdir, tt) end
		end)
	end
end
local function yakala(fs)
	if not yakalayiciAcik then return end
	local t = fs:GetText()
	if G.gizli(t) or type(t) ~= "string" then return end
	if not t or t == "" or #t > 700 then return end
	if t:find("|cffaaaaaa(", 1, true) then return end
	if G.oyuncuMu(t) then return end
	-- Ad listeleri (arkadaş, lonca, kim, raid/grup çerçeveleri): ad ve lonca alanlarına hiç dokunma
	do
		local ad = fs.GetName and fs:GetName()
		if ad and (ad:find("Name$") or ad:find("Guild$") or ad:find("NameText$")) and
			(ad:find("^GuildFrame") or ad:find("^WhoFrame") or ad:find("^FriendsFrame") or ad:find("^Raid") or ad:find("^Party")
			or ad:find("^Compact") or ad:find("^Target") or ad:find("^Focus") or ad:find("^Player") or ad:find("^Ignore")) then return end
		local ust = fs.GetParent and fs:GetParent()
		-- Sohbet yazma kutusu ("Say:", "/say", kanal başlıkları): genişliği İngilizceye göre hesaplanıyor,
		-- çevirince yazılar iç içe geçiyor. Yazı kutularının içindeki hiçbir yazıya dokunma.
		if ad and ad:find("EditBox") then return end
		if ust and ust.GetObjectType and ust:GetObjectType() == "EditBox" then return end
		local uname = ust and ust.GetName and ust:GetName()
		if uname and uname:find("EditBox") then return end
		if ust and (rawget(ust, "name") == fs or rawget(ust, "Name") == fs) then
			local un = ust.GetName and ust:GetName() or ""
			local uu = ust.GetParent and ust:GetParent()
			local uun = uu and uu.GetName and uu:GetName() or ""
			-- Yeni stil listeler (ScrollBox içindeki arkadaş ve lonca satırları)
			if un:find("Friend") or un:find("Guild") or un:find("Who") or uun:find("Friend") or uun:find("Guild") or uun:find("Who")
				or rawget(ust, "gameAccountInfo") or rawget(ust, "buttonType") then return end
		end
	end
	-- Birim çerçeveleri ve isim plakaları: çerçevenin birimi oyuncuysa adına dokunma
	do
		local u, d = fs, 0
		while u and d < 6 do
			local birim = rawget(u, "unit") or rawget(u, "displayedUnit")
			if type(birim) == "string" then
				local ok, op = pcall(UnitIsPlayer, birim)
				if ok and op then G.oyuncuEkle(birim); return end
				break
			end
			u = u.GetParent and u:GetParent(); d = d + 1
		end
	end
	-- Görev adları: görev takipçisi (Retail ObjectiveTracker), harita görev günlüğü, dünya görevleri
	local gOn, gAd = t:match("^(%[[%d%+%?]+%]%s*)(.+)$")
	if not (gAd and G.GorevAdi[gAd]) then gOn, gAd = "", t end
	if G.modul("gorev") and G.GorevAdi[gAd] and not G.turkceMi(gAd) then
		local u, d = fs, 0
		while u and d < 12 do
			local ad = u.GetName and u:GetName()
			if ad and (ad:find("ObjectiveTracker") or ad:find("QuestScrollFrame") or ad:find("QuestMapFrame") or ad:find("QuestLog") or ad:find("WorldMap") or ad:find("Questie")) then
				yakalayiciAcik = false; pcall(koyYaz, fs, gOn .. G.GorevAdi[gAd]); yakalayiciAcik = true
				return
			end
			u = u.GetParent and u:GetParent(); d = d + 1
		end
	end
	-- Retail meslek penceresi (ProfessionsFrame): tarif, malzeme ve kategori adları
	local pf = rawget(_G, "ProfessionsFrame")
	if pf and pf:IsShown() and not G.turkceMi(t) and (G.modul("buyuadi") or G.modul("arayuz")) then
		local u, d = fs, 0
		while u and d < 12 do
			local ad = u.GetName and u:GetName()
			if ad and (ad:find("^ProfessionsFrame") or ad:find("^ProfessionsCustomerOrders")) then
				local bas, isim, son = t:match("^(%s*)(.-)(%s*%(%d+%))$")
				if not isim then bas, isim, son = "", t, "" end
				local tr = G.isimCevir(isim) or (G.esyaAdiGoster and G.esyaAdiGoster(isim))
				if tr and tr ~= isim then yakalayiciAcik = false; pcall(koyYaz, fs, bas .. tr .. son); yakalayiciAcik = true; return end
				break
			end
			u = u.GetParent and u:GetParent(); d = d + 1
		end
	end
	local onbellek = hizli[t]
	if onbellek == false then return end
	if onbellek then
		yakalayiciAcik = false; pcall(koyYaz, fs, onbellek); yakalayiciAcik = true
		return
	end
	if not t:find("%a%a") or G.turkceMi(t) then return end
	local sayili = t:find("%d")
	if sayili then
		local sab = t:gsub("%d+", "#")
		if sablonYok[sab] then return end
		local tr = cevir(t)
		if tr then
			yakalayiciAcik = false; pcall(koyYaz, fs, tr); yakalayiciAcik = true
		else
			sablonYok[sab] = true
			if not gorevMetniMi(fs) then kaydet(t) end
		end
		return
	end
	local tr = cevir(t)
	if hizliSayi < 20000 then hizli[t] = tr or false; hizliSayi = hizliSayi + 1 end
	if tr then
		yakalayiciAcik = false; pcall(koyYaz, fs, tr); yakalayiciAcik = true
	elseif not gorevMetniMi(fs) then
		kaydet(t)
	end
end
local function yakalayiciKur()
	local ornek = UIParent:CreateFontString()
	local mt = getmetatable(ornek)
	local yontem = mt and mt.__index
	if type(yontem) ~= "table" then return end
	G.tani.yakalayici = true
	local function kanca(fs)
		G.tani.kanca = (G.tani.kanca or 0) + 1
		if not G.modul("arayuz") then return end
		if G.RETAIL and InCombatLockdown and InCombatLockdown() then return end
		local ok, e = pcall(yakala, fs)
		if not ok then G.tani.hata = tostring(e); yakalayiciAcik = true end
	end
	hooksecurefunc(yontem, "SetText", kanca)
	-- Yeni menüler ve ayarlar paneli yazıyı SetTextToFit ile koyuyor
	for _, ad in ipairs({ "SetFormattedText", "SetTextToFit" }) do
		if yontem[ad] then hooksecurefunc(yontem, ad, kanca) end
	end
	-- Düğme yazıları (Button:SetText) FontString:SetText'ten geçmiyor; bu yüzden listelerde
	-- (müzayede kategorileri vb.) önce İngilizce görünüp sonra değişiyordu. Aynı karede çevir.
	local dugme = CreateFrame("Button")
	local dmt = getmetatable(dugme)
	local dyontem = dmt and dmt.__index
	if type(dyontem) == "table" and dyontem.SetText then
		local function dugmeKanca(b)
			if not G.modul("arayuz") then return end
			if G.RETAIL and InCombatLockdown and InCombatLockdown() then return end
			local fs = b.GetFontString and b:GetFontString()
			if fs then local ok, e = pcall(yakala, fs); if not ok then G.tani.hata = tostring(e); yakalayiciAcik = true end end
		end
		hooksecurefunc(dyontem, "SetText", dugmeKanca)
		if dyontem.SetFormattedText then hooksecurefunc(dyontem, "SetFormattedText", dugmeKanca) end
	end
end
G.dinle(function(k) if k == "arayuz" or k == "acik" then wipe(hizli); hizliSayi = 0; wipe(sablonYok) end end)

G.basla(function()
	pcall(yakalayiciKur)
	for _, ad in ipairs(KOKLER) do
		local f = _G[ad]
		if type(f) == "table" and f.HookScript then pcall(f.HookScript, f, "OnShow", baslat) end
	end
	-- Bazı pencereler (TalentFrame vb.) sonradan yüklenir
	local f = CreateFrame("Frame")
	f:RegisterEvent("ADDON_LOADED")
	f:SetScript("OnEvent", function()
		for _, ad in ipairs(KOKLER) do
			local fr = _G[ad]
			if type(fr) == "table" and fr.HookScript and not fr._gtrKanca then fr._gtrKanca = true; pcall(fr.HookScript, fr, "OnShow", baslat) end
		end
	end)
	for _, ad in ipairs(KOKLER) do local fr = _G[ad]; if type(fr) == "table" then fr._gtrKanca = true end end
	-- Girişte zaten açık olan pencereler (ör. grup içindeyken raid yöneticisi) için
	baslat()
	f:RegisterEvent("GROUP_ROSTER_UPDATE")
	f:HookScript("OnEvent", function(_, e) if e == "GROUP_ROSTER_UPDATE" then baslat() end end)
	for _, fn in ipairs({ "CompactRaidFrameManager_Expand", "CompactRaidFrameManager_Toggle", "CompactRaidFrameManager_UpdateShown" }) do
		if _G[fn] then hooksecurefunc(fn, baslat) end
	end
	if _G.QuestWatch_Update then
		hooksecurefunc("QuestWatch_Update", function() pcall(function()
			local f = QuestWatchFrame
			if not f or not G.modul("arayuz") then return end
			for i = 1, 30 do
				local fs = _G["QuestWatchLine" .. i]
				if fs and fs:IsShown() then
					-- Görev başlıkları (Questie "[8] Başlık" biçimi dahil)
					local t = fs:GetText()
					local on, ad = "", t
					if type(t) == "string" and not G.gizli(t) then
						local a, b = t:match("^(%[[^%]]*%]%s*)(.+)$")
						if a then on, ad = a, b end
					end
					local tr = type(ad) == "string" and G.modul("gorev") and G.GorevAdi[ad]
					if tr then G.asilKaydet(fs, on .. tr); fs:SetText(on .. tr)
					else gorulen[fs] = nil; yaziIsle(fs) end
				end
			end
			-- Türkçe yazı daha uzun olabilir: çerçeve genişliğini yeni yazıya göre ayarla (ekran dışına taşmasın)
			local enGenis = 0
			for i = 1, 30 do
				local fs = _G["QuestWatchLine" .. i]
				if fs and fs:IsShown() then enGenis = math.max(enGenis, fs:GetStringWidth() or 0) end
			end
			if enGenis > 0 and f.GetWidth and enGenis + 10 > f:GetWidth() then f:SetWidth(enGenis + 10) end
		end) end)
	end
	if _G.UIDropDownMenu_AddButton then hooksecurefunc("UIDropDownMenu_AddButton", function() C_Timer.After(0, baslat) end) end
	-- Sohbet sekmeleri (General, Combat Log)
	local function sekmeler()
		if not G.modul("arayuz") then return end
		for i = 1, 10 do
			local tab = _G["ChatFrame" .. i .. "Tab"]
			local fs = tab and (tab.Text or (tab.GetFontString and tab:GetFontString()) or _G["ChatFrame" .. i .. "TabText"])
			if fs then gorulen[fs] = nil; guvenliIsle(fs) end
		end
	end
	C_Timer.After(2, sekmeler)
	if _G.FCF_SetWindowName then hooksecurefunc("FCF_SetWindowName", function() C_Timer.After(0, sekmeler) end) end
	-- Sürekli tarama (açık pencere yoksa neredeyse maliyetsiz)
	baslat()
	C_Timer.After(3, function() pcall(tamTarama) end)
	C_Timer.NewTicker(1, function() local ok, e = pcall(tamTarama); if not ok then G.tani.hata = tostring(e) end end)
	local kancali = {}
	local function ipucuKanca()
	for _, ad in ipairs({ "GameTooltip", "SettingsTooltip", "ItemRefTooltip", "ShoppingTooltip1", "ShoppingTooltip2", "ShoppingTooltip3", "ItemRefShoppingTooltip1", "ItemRefShoppingTooltip2", "ItemRefShoppingTooltip3" }) do
		local tt = _G[ad]
		if tt and tt.HookScript and not kancali[tt] then
			kancali[tt] = true
			if tt.HookScript then pcall(tt.HookScript, tt, "OnTooltipCleared", function(self) ipucuFontSifirla(self) end) end
			tt:HookScript("OnShow", function(self) pcall(ipucuTara, self); C_Timer.After(0, function() if self:IsShown() then pcall(ipucuTara, self) end end) end)
			-- Bazı ipuçları açıkken her saniye yeniden yazılıyor (Ana Menü: FPS, gecikme...).
			-- Her yeniden çizimde (Show çağrısı) tekrar çevir.
			local isleniyor = false
			local function yeniden(self)
				if isleniyor then return end
				isleniyor = true
				pcall(ipucuTara, self)
				isleniyor = false
				-- Karşılaştırma satırları Show'dan hemen sonra eklenebiliyor
				C_Timer.After(0, function() if self:IsShown() and not isleniyor then isleniyor = true; pcall(ipucuTara, self); isleniyor = false end end)
			end
			hooksecurefunc(tt, "Show", yeniden)
			-- İpucu açıkken kendini yenileyen yerler (karakter yuvaları, birimler) Show çağırmadan yazar
			for _, yontem in ipairs({ "SetText", "AddLine", "AddDoubleLine" }) do
				if tt[yontem] then hooksecurefunc(tt, yontem, yeniden) end
			end
		end
	end
	end
	ipucuKanca()
	-- Veri tabanlı ipuçları (birim, aura vb.) her yenilendiğinde
	if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and TooltipDataProcessor.AllTypes then
		TooltipDataProcessor.AddTooltipPostCall(TooltipDataProcessor.AllTypes, function(tt) pcall(ipucuTara, tt) end)
	end
	local yk = CreateFrame("Frame")
	yk:RegisterEvent("ADDON_LOADED")
	yk:SetScript("OnEvent", ipucuKanca)
	if SettingsPanel then SettingsPanel:HookScript("OnShow", ipucuKanca) end
	-- Açılır pencereler (yok etme, takas onayı, ruhunu bırak...): yazı ve düğmeler.
	-- Eski ve yeni pencere şablonlarında alan adları farklı; hepsini dene.
	local function popupYazilari(f)
		local t = {}
		local function ekle(x) if x and x.GetText and x.SetText then t[#t + 1] = x end end
		local ad = f:GetName()
		ekle(f.text); ekle(f.Text); ekle(ad and _G[ad .. "Text"])
		for j = 1, 4 do
			local b = f["button" .. j] or (ad and _G[ad .. "Button" .. j]) or (f.ButtonContainer and f.ButtonContainer["Button" .. j])
			if b then ekle(b.GetFontString and b:GetFontString()); ekle(b.Text) end
		end
		return t
	end
	local popupKancali = {}
	local function popupCevir(fs)
		if not G.modul("arayuz") then return end
		local t = fs:GetText()
		if not t or G.gizli(t) or t == "" or G.turkceMi(t) then return end
		local ok, tr = pcall(cevir, t)
		if ok and tr and tr ~= t then
			popupKancali[fs] = "yaziyor"; pcall(fs.SetText, fs, tr); popupKancali[fs] = true
		end
	end
	local function popuplar()
		for i = 1, 4 do
			local f = _G["StaticPopup" .. i]
			if f and f:IsShown() then
				for _, fs in ipairs(popupYazilari(f)) do
					if not popupKancali[fs] then
						popupKancali[fs] = true
						-- Geri sayım gibi her saniye yeniden yazılan metinler için
						hooksecurefunc(fs, "SetText", function(self) if popupKancali[self] ~= "yaziyor" then popupCevir(self) end end)
						if fs.SetFormattedText then hooksecurefunc(fs, "SetFormattedText", function(self) if popupKancali[self] ~= "yaziyor" then popupCevir(self) end end) end
					end
					popupCevir(fs)
				end
			end
		end
	end
	if _G.StaticPopup_Show then
		hooksecurefunc("StaticPopup_Show", function()
			pcall(popuplar)
			C_Timer.After(0, function() pcall(popuplar) end)
			C_Timer.After(0.1, function() pcall(popuplar) end)
		end)
	end
	for i = 1, 4 do
		local f = _G["StaticPopup" .. i]
		if f and f.HookScript then f:HookScript("OnShow", function() C_Timer.After(0, function() pcall(popuplar) end) end) end
	end
	local dugme = _G.CompactRaidFrameManagerToggleButton
	if dugme then dugme:HookScript("OnClick", baslat) end
end)

G.dinle(function(k)
	if k == "arayuz" or k == "acik" then wipe(gorulen) end
end)

-- Oyunun hazır metinleri (BattleNet arkadaş bildirimi, satış fiyatı vb.) doğrudan değiştirilir
local GLOBAL_TR = {
	BN_INLINE_TOAST_FRIEND_ONLINE = "%s çevrimiçi oldu.",
	BN_INLINE_TOAST_FRIEND_OFFLINE = "%s çevrimdışı oldu.",
	BN_INLINE_TOAST_FRIEND_ADDED = "%s arkadaş listene eklendi.",
	BN_INLINE_TOAST_FRIEND_REMOVED = "%s arkadaş listenden çıkarıldı.",
	BN_INLINE_TOAST_FRIEND_REQUEST = "Bir arkadaşlık isteğin var.",
	BN_INLINE_TOAST_FRIEND_PENDING = "%d bekleyen arkadaşlık isteğin var.",
	BN_INLINE_TOAST_BROADCAST = "%s: %s",
	SELL_PRICE = "Satış Fiyatı",
	REPAIR_AN_ITEM = "Bir Eşyayı Onar",
	REPAIR_ALL_ITEMS = "Tüm Eşyaları Onar",
	REPAIR_ITEMS = "Eşyaları Onar",
	TRAINER_FILTER_AVAILABLE = "Mevcut",
	TRAINER_FILTER_UNAVAILABLE = "Mevcut Değil",
	TRAINER_FILTER_USED = "Zaten Bilinen",
	ITEM_SPELL_KNOWN = "Zaten biliniyor",
	NO_ROLE = "Rol Yok",
	MISS = "Iska", DODGE = "Sıyrılma", PARRY = "Savuşturma", BLOCK = "Blok", RESIST = "Direnç",
	IMMUNE = "Bağışık", ABSORB = "Emildi", EVADE = "Kaçındı", DEFLECT = "Saptırıldı", REFLECT = "Yansıtıldı",
	ERR_ZONE_EXPLORED = "Keşfedildi: %s",
	ERR_ZONE_EXPLORED_XP = "Keşfedildi: %s (+%d deneyim)",
	ERR_QUEST_MUST_CHOOSE = "Bir ödül seçmelisin.",
	CONFIRM_BINDER = "%s yeni evin olsun mu?",
	NAMEPLATES_MESSAGE_ENEMY_ON = "Düşman isim levhaları açıldı",
	NAMEPLATES_MESSAGE_ENEMY_OFF = "Düşman isim levhaları kapatıldı",
	NAMEPLATES_MESSAGE_FRIENDLY_ON = "Dost isim levhaları açıldı",
	NAMEPLATES_MESSAGE_FRIENDLY_OFF = "Dost isim levhaları kapatıldı",
	NAMEPLATES_MESSAGE_ALL_ON = "İsim levhaları açıldı",
	NAMEPLATES_MESSAGE_ALL_OFF = "İsim levhaları kapatıldı",
	CHAT_MONSTER_SAY_GET = "%s der: ",
	CHAT_MONSTER_YELL_GET = "%s bağırır: ",
	CHAT_MONSTER_WHISPER_GET = "%s fısıldar: ",
	NEWBIE_TOOLTIP_FREE_FOR_ALL = "Herkes Serbest kuralında herkes her şeyi toplayabilir.",
	NEWBIE_TOOLTIP_ROUND_ROBIN = "Sırayla kuralında ganimet grup üyeleri arasında sırayla dağıtılır.",
	NEWBIE_TOOLTIP_MASTER_LOOTER = "Ganimet Ustası kuralında ganimet eşiğinin üzerindeki eşyaları yalnızca ganimet ustası dağıtabilir; diğer eşyalar sırayla dağıtılır.",
	NEWBIE_TOOLTIP_GROUP_LOOT = "Grup Ganimeti kuralında ganimet sırayla dağıtılır. Ganimet eşiğinin üzerindeki eşyalar için tüm grup zar atabilir.",
	NEWBIE_TOOLTIP_NEED_BEFORE_GREED = "Önce İhtiyaç kuralında ganimet sırayla dağıtılır. Ganimet eşiğinin üzerindeki eşyalar için yalnızca o eşyayı kullanabilen grup üyeleri zar atabilir.",
}
for _, son in ipairs({ "FREE_FOR_ALL", "ROUND_ROBIN", "MASTER_LOOTER", "GROUP_LOOT", "NEED_BEFORE_GREED" }) do
	GLOBAL_TR["NEWBIE_TOOLTIP_UNIT_" .. son] = GLOBAL_TR["NEWBIE_TOOLTIP_" .. son]
	GLOBAL_TR["LOOT_" .. son .. "_DESC"] = GLOBAL_TR["NEWBIE_TOOLTIP_" .. son]
end
local globalAsil = {}
local function globalUygula()
	local acik = G.modul("arayuz")
	for k, v in pairs(GLOBAL_TR) do
		if globalAsil[k] == nil and type(_G[k]) == "string" then globalAsil[k] = _G[k] end
		if globalAsil[k] ~= nil then
			-- Retail: Blizzard global yazılarını değiştirmek onları kirletir (taint) ve güvenli kodu bozabilir;
			-- orada yalnızca sözlüğe ekleriz, yakalayıcı ekrandaki yazıyı yine çevirir.
			-- Classic'te de yalnızca güvenli kodun okumadığı sohbet biçimlerini değiştiriyoruz; ötekiler
			-- (MISS, SELL_PRICE, ERR_... gibi) eylem engellendi uyarısına yol açabiliyordu.
			if not G.RETAIL and (k:find("^CHAT_MONSTER_") or k:find("^BN_INLINE_TOAST_")) then _G[k] = acik and v or globalAsil[k] end
			-- Menüler metni yüklenirken kopyalamış olabilir: İngilizce aslını sözlüğe de ekle
			if G.Arayuz and not v:find("%%") then G.Arayuz[globalAsil[k]] = v end
		end
	end
end
pcall(globalUygula)
local gf = CreateFrame("Frame")
gf:RegisterEvent("PLAYER_LOGIN")
gf:SetScript("OnEvent", function() pcall(globalUygula) end)
G.dinle(function(k) if k == "arayuz" or k == "acik" then pcall(globalUygula) end end)

-- Diğer eklentiler (Questie) için: görev hedefi gibi kısa metinleri çevirir, çeviri yoksa nil döner
function G.hedefCevir(s)
	if type(s) ~= "string" or not G.modul("arayuz") then return nil end
	return G.cevir(G.Arayuz, s) or desenCevir(s)
end

-- "Tümü" (All) daralt/genişlet düğmeleri: sekme alanı "All" için çizilmiş, Türkçe yazı taşıyordu.
-- Yazıyı İngilizcesinin genişliğine yakın olacak şekilde küçült (görev günlüğü, beceriler, eğitmen, meslekler).
local HEPSI = { "QuestLogCollapseAllButton", "SkillFrameCollapseAllButton", "ClassTrainerCollapseAllButton",
	"TradeSkillCollapseAllButton", "CraftCollapseAllButton", "TrainerCollapseAllButton" }
local hepsiKurulu = {}
local function hepsiKucult(b)
	local fs = b and b.GetFontString and b:GetFontString()
	if not fs or not fs.GetFont then return end
	if not b._gtrFont then local d, bo, st = fs:GetFont(); if d then b._gtrFont = { d, bo, st or "" } end end
	local f = b._gtrFont
	if not f then return end
	if G.fontSerbest(fs) then fs:SetFont(f[1], f[2], f[3]) end
	local t = fs:GetText()
	if type(t) == "string" and G.turkceMi(t) then
		local g = fs.GetUnboundedStringWidth and fs:GetUnboundedStringWidth() or fs:GetStringWidth()
		local sinir = 24 -- "All" yazısının genişliği civarı
		local oran = (g and g > sinir) and math.max(0.65, sinir / g) or 1
		if G.fontSerbest(fs) then fs:SetFont(f[1], math.floor(f[2] * math.min(0.82, oran) * 10 + 0.5) / 10, f[3]) end
	end
end
local function hepsiKur()
	for _, ad in ipairs(HEPSI) do
		local b = _G[ad]
		if b and not hepsiKurulu[ad] and b.GetFontString then
			hepsiKurulu[ad] = true
			hooksecurefunc(b, "SetText", function(self)
				pcall(hepsiKucult, self)
				C_Timer.After(0, function() pcall(hepsiKucult, self) end)
			end)
			b:HookScript("OnShow", function(self) C_Timer.After(0, function() pcall(hepsiKucult, self) end) end)
			pcall(hepsiKucult, b)
		end
	end
end
local hk = CreateFrame("Frame")
hk:RegisterEvent("PLAYER_LOGIN")
hk:RegisterEvent("ADDON_LOADED")
hk:SetScript("OnEvent", function() C_Timer.After(0.5, hepsiKur) end)
