if not WoWTurkce.FOREVER then return end
-- Forever yaratık adları (otomatik üretildi: jenerik adlar; kişi adları İngilizce kalır)
local Y = WoWTurkce.Yaratik
if Y["Adventurer's Spirit"] == nil then Y["Adventurer's Spirit"] = "Maceracı Ruhu" end
if Y["Aerie Gryphon Hatchling"] == nil then Y["Aerie Gryphon Hatchling"] = "Aerie Gryphon Yavrusu" end
if Y["Aggressive Manticore"] == nil then Y["Aggressive Manticore"] = "Saldırgan Mantikor" end
if Y["Aku'mai Servant"] == nil then Y["Aku'mai Servant"] = "Aku'mai Hizmetkârı" end
if Y["Al'Aketh Ambusher"] == nil then Y["Al'Aketh Ambusher"] = "Al'Aketh Pusucu" end
if Y["Al'Aketh Assassin"] == nil then Y["Al'Aketh Assassin"] = "Al'Aketh Suikastçı" end
if Y["Al'Aketh Attacker"] == nil then Y["Al'Aketh Attacker"] = "Al'Aketh Saldırgan" end
if Y["Al'Aketh Brawler"] == nil then Y["Al'Aketh Brawler"] = "Al'Aketh Kavgacı" end
if Y["Al'Aketh Convert"] == nil then Y["Al'Aketh Convert"] = "Al'Aketh Mühtedisi" end
if Y["Al'Aketh Guardian"] == nil then Y["Al'Aketh Guardian"] = "Al'Aketh Koruyucu" end
if Y["Al'Aketh Healer"] == nil then Y["Al'Aketh Healer"] = "Al'Aketh Şifacı" end
if Y["Al'Aketh Honor Guard"] == nil then Y["Al'Aketh Honor Guard"] = "Al'Aketh Onur Muhafızı" end
if Y["Al'Aketh Neophyte"] == nil then Y["Al'Aketh Neophyte"] = "Al'Aketh Çömezi" end
if Y["Al'Aketh Stormcaller"] == nil then Y["Al'Aketh Stormcaller"] = "Al'Aketh Fırtınaçağıran" end
if Y["Al'Aketh Stormchaser"] == nil then Y["Al'Aketh Stormchaser"] = "Al'Aketh Fırtına Avcısı" end
if Y["Al'Aketh Warrior"] == nil then Y["Al'Aketh Warrior"] = "Al'Aketh Savaşçı" end
if Y["Alpine Chipmunk"] == nil then Y["Alpine Chipmunk"] = "Alp Sincabı" end
if Y["Ancient Crocolisk"] == nil then Y["Ancient Crocolisk"] = "Kadim Krokolisk" end
if Y["Ancient Fire Elemental"] == nil then Y["Ancient Fire Elemental"] = "Kadim Ateş Elementi" end
if Y["Ancona Chicken"] == nil then Y["Ancona Chicken"] = "Ancona Tavuğu" end
if Y["Animated Hammer"] == nil then Y["Animated Hammer"] = "Canlanmış Çekiç" end
if Y["Apprentice Watcher"] == nil then Y["Apprentice Watcher"] = "Çırak Gözcü" end
if Y["Arbor Tarantula"] == nil then Y["Arbor Tarantula"] = "Ağaç Tarantulası" end
if Y["Arcane Echo"] == nil then Y["Arcane Echo"] = "Büyülü Yankı" end
if Y["Arcane Manaling"] == nil then Y["Arcane Manaling"] = "Arkan Manaling" end
if Y["Arcanite Dragonling"] == nil then Y["Arcanite Dragonling"] = "Arcanite Ejderhacık" end
if Y["Ashen Acolyte"] == nil then Y["Ashen Acolyte"] = "Ashen Çömez" end
if Y["Astral Wraith"] == nil then Y["Astral Wraith"] = "Astral Hayalet" end
if Y["Baby Crocolisk"] == nil then Y["Baby Crocolisk"] = "Yavru Krokolisk" end
if Y["Ban'aethal Refugee"] == nil then Y["Ban'aethal Refugee"] = "Ban'aethal Mülteci" end
if Y["Bandit Henchman"] == nil then Y["Bandit Henchman"] = "Haydut Yardakçısı" end
if Y["Bandit Highwayman"] == nil then Y["Bandit Highwayman"] = "Haydut Yol Kesen" end
if Y["Barkskin Cub"] == nil then Y["Barkskin Cub"] = "Barkskin Yavrusu" end
if Y["Barkskin Matriarch"] == nil then Y["Barkskin Matriarch"] = "Barkskin Matriyarkı" end
if Y["Barkskin Shaman"] == nil then Y["Barkskin Shaman"] = "Barkskin Şaman" end
if Y["Barkskin Warrior"] == nil then Y["Barkskin Warrior"] = "Barkskin Savaşçısı" end
if Y["Bitter Spirit"] == nil then Y["Bitter Spirit"] = "Acı Ruh" end
if Y["Black Guard Executioner"] == nil then Y["Black Guard Executioner"] = "Black Guard Cellâdı" end
if Y["Black Guard Warrior"] == nil then Y["Black Guard Warrior"] = "Black Guard Savaşçı" end
if Y["Black Tabby"] == nil then Y["Black Tabby"] = "Kara Tekir Kedi" end
if Y["Blackbreath Crony"] == nil then Y["Blackbreath Crony"] = "Blackbreath Yandaşı" end
if Y["Blackhand Dreadweaver"] == nil then Y["Blackhand Dreadweaver"] = "Blackhand Dehşet Örücü" end
if Y["Blackmaw Den Watcher"] == nil then Y["Blackmaw Den Watcher"] = "Blackmaw İn Gözcüsü" end
if Y["Blackmaw Totemic"] == nil then Y["Blackmaw Totemic"] = "Blackmaw Totemcisi" end
if Y["Blackthorne Adept"] == nil then Y["Blackthorne Adept"] = "Blackthorne Ustası" end
if Y["Blackthorne Cultist"] == nil then Y["Blackthorne Cultist"] = "Blackthorne Tarikatçı" end
if Y["Blood Flies"] == nil then Y["Blood Flies"] = "Kan Sinekleri" end
if Y["Bloodhound Runt"] == nil then Y["Bloodhound Runt"] = "Kan Tazısı Ufaklığı" end
if Y["Bloodwing Bat"] == nil then Y["Bloodwing Bat"] = "Bloodwing Yarasası" end
if Y["Blue Crystal"] == nil then Y["Blue Crystal"] = "Mavi Kristal" end
if Y["Bone Kodo"] == nil then Y["Bone Kodo"] = "Kemik Kodo" end
if Y["Brackenwall Smasher"] == nil then Y["Brackenwall Smasher"] = "Brackenwall Ezici" end
if Y["Brinescale Priestess"] == nil then Y["Brinescale Priestess"] = "Brinescale Rahibesi" end
if Y["Brinescale Skirmisher"] == nil then Y["Brinescale Skirmisher"] = "Brinescale Akıncısı" end
if Y["Bristleback Bodyguard"] == nil then Y["Bristleback Bodyguard"] = "Bristleback Koruma" end
if Y["Brown Ground Squirrel"] == nil then Y["Brown Ground Squirrel"] = "Kahverengi Yer Sincabı" end
if Y["Burning Bunny"] == nil then Y["Burning Bunny"] = "Yanan Tavşan" end
if Y["Burrow Beetle"] == nil then Y["Burrow Beetle"] = "Oyuk Böceği" end
if Y["Caged Chicken"] == nil then Y["Caged Chicken"] = "Kafesteki Tavuk" end
if Y["Captive Druid"] == nil then Y["Captive Druid"] = "Esir Druid" end
if Y["Captive Fire Elemental"] == nil then Y["Captive Fire Elemental"] = "Esir Ateş Elementi" end
if Y["Captured Bandit"] == nil then Y["Captured Bandit"] = "Yakalanmış Haydut" end
if Y["Carnivorous Weed"] == nil then Y["Carnivorous Weed"] = "Etobur Ot" end
if Y["Cat Familiar"] == nil then Y["Cat Familiar"] = "Kedi Yoldaşı" end
if Y["Cavalry Guard"] == nil then Y["Cavalry Guard"] = "Süvari Muhafızı" end
if Y["Cenarion Warden"] == nil then Y["Cenarion Warden"] = "Cenarion Bekçisi" end
if Y["Charred Ghoul"] == nil then Y["Charred Ghoul"] = "Kömürleşmiş Ghoul" end
if Y["Chromatic Drakonid"] == nil then Y["Chromatic Drakonid"] = "Kromatik Drakonid" end
if Y["Cinderscale Warrior"] == nil then Y["Cinderscale Warrior"] = "Cinderscale Savaşçısı" end
if Y["Cinderscale Whelp"] == nil then Y["Cinderscale Whelp"] = "Cinderscale Ejderha Yavrusu" end
if Y["Cloned Ectoplasm"] == nil then Y["Cloned Ectoplasm"] = "Klonlanmış Ektoplazma" end
if Y["Common Kitten"] == nil then Y["Common Kitten"] = "Sıradan Kedi Yavrusu" end
if Y["Condor Hatchling"] == nil then Y["Condor Hatchling"] = "Kondor Yavrusu" end
if Y["Contemplative Bandit"] == nil then Y["Contemplative Bandit"] = "Düşünceli Haydut" end
if Y["Converted Farmer"] == nil then Y["Converted Farmer"] = "Dönüştürülmüş Çiftçi" end
if Y["Crazed Darkhound"] == nil then Y["Crazed Darkhound"] = "Çılgın Karanlık Av Köpeği" end
if Y["Crimson Battle Mage"] == nil then Y["Crimson Battle Mage"] = "Crimson Savaş Büyücüsü" end
if Y["Crimson Initiate"] == nil then Y["Crimson Initiate"] = "Crimson Çömez" end
if Y["Crimson Priest"] == nil then Y["Crimson Priest"] = "Crimson Rahip" end
if Y["Crimson Sorcerer"] == nil then Y["Crimson Sorcerer"] = "Crimson Sihirbazı" end
if Y["Cut-throat Mugger"] == nil then Y["Cut-throat Mugger"] = "Kalleş Soyguncu" end
if Y["Dalaran Adept"] == nil then Y["Dalaran Adept"] = "Dalaran Ustası" end
if Y["Dalaran Miner"] == nil then Y["Dalaran Miner"] = "Dalaran Madencisi" end
if Y["Dalaran Serpent"] == nil then Y["Dalaran Serpent"] = "Dalaran Yılanı" end
if Y["Dark Iron Engineer"] == nil then Y["Dark Iron Engineer"] = "Dark Iron Mühendis" end
if Y["Dark Iron Looter"] == nil then Y["Dark Iron Looter"] = "Dark Iron Yağmacısı" end
if Y["Dark Iron Summoner"] == nil then Y["Dark Iron Summoner"] = "Dark Iron Çağırıcısı" end
if Y["Darkmoon Faire Carnie"] == nil then Y["Darkmoon Faire Carnie"] = "Darkmoon Faire Panayırcısı" end
if Y["Darkshore Owl"] == nil then Y["Darkshore Owl"] = "Darkshore Baykuşu" end
if Y["Darkspear Elite"] == nil then Y["Darkspear Elite"] = "Darkspear Elit" end
if Y["Darkspear Emissary"] == nil then Y["Darkspear Emissary"] = "Darkspear Elçi" end
if Y["Darkspear Shark"] == nil then Y["Darkspear Shark"] = "Darkspear Köpekbalığı" end
if Y["Darrowshire Poltergeist"] == nil then Y["Darrowshire Poltergeist"] = "Darrowshire Poltergeist'i" end
if Y["Dead Cultist"] == nil then Y["Dead Cultist"] = "Ölü Tarikatçı" end
if Y["Dead Diseased Forest Walker"] == nil then Y["Dead Diseased Forest Walker"] = "Ölü Hastalıklı Orman Yürüyücüsü" end
if Y["Deadwood Den Guardian"] == nil then Y["Deadwood Den Guardian"] = "Deadwood Den Koruyucusu" end
if Y["Deadwood Warden"] == nil then Y["Deadwood Warden"] = "Deadwood Bekçisi" end
if Y["Deathguard Veteran"] == nil then Y["Deathguard Veteran"] = "Deathguard Kıdemlisi" end
if Y["Deathhorn Stag"] == nil then Y["Deathhorn Stag"] = "Deathhorn Geyiği" end
if Y["Deathless Marrow"] == nil then Y["Deathless Marrow"] = "Ölümsüz İlik" end
if Y["Deathpetal Lasher"] == nil then Y["Deathpetal Lasher"] = "Deathpetal Kamçıcısı" end
if Y["Deathsworn Captain"] == nil then Y["Deathsworn Captain"] = "Ölüm Yeminli Yüzbaşı" end
if Y["Decrepit Pylon Protector"] == nil then Y["Decrepit Pylon Protector"] = "Köhne Pylon Koruyucusu" end
if Y["Deepscar Yeti"] == nil then Y["Deepscar Yeti"] = "Deepscar Yetisi" end
if Y["Defias Ambusher"] == nil then Y["Defias Ambusher"] = "Defias Pusucu" end
if Y["Defias Bodyguard"] == nil then Y["Defias Bodyguard"] = "Defias Koruma" end
if Y["Defias Convict"] == nil then Y["Defias Convict"] = "Defias Mahkûmu" end
if Y["Defias Dockmaster"] == nil then Y["Defias Dockmaster"] = "Defias Rıhtım Ustası" end
if Y["Defias Prisoner"] == nil then Y["Defias Prisoner"] = "Defias Mahkûmu" end
if Y["Defias Scout"] == nil then Y["Defias Scout"] = "Defias Gözcüsü" end
if Y["Defias Vintner"] == nil then Y["Defias Vintner"] = "Defias Şarapçı" end
if Y["Deranged Ogre"] == nil then Y["Deranged Ogre"] = "Çıldırmış Ogre" end
if Y["Desolace Bone Worm"] == nil then Y["Desolace Bone Worm"] = "Desolace Kemik Solucanı" end
if Y["Dire Wolf Alpha"] == nil then Y["Dire Wolf Alpha"] = "Dehşet Kurdu Alfa" end
if Y["Diseased Forest Walker"] == nil then Y["Diseased Forest Walker"] = "Hastalıklı Orman Yürüyeni" end
if Y["Diseased Soldier"] == nil then Y["Diseased Soldier"] = "Hastalıklı Asker" end
if Y["Disgusting Oozeling"] == nil then Y["Disgusting Oozeling"] = "İğrenç Çamur Yavrusu" end
if Y["Disturbed Ghoul"] == nil then Y["Disturbed Ghoul"] = "Huzursuz Ghoul" end
if Y["Docile Galestrider"] == nil then Y["Docile Galestrider"] = "Uysal Galestrider" end
if Y["Doomhound Mastiff"] == nil then Y["Doomhound Mastiff"] = "Doomhound Mastifi" end
if Y["Dragon Spawn"] == nil then Y["Dragon Spawn"] = "Ejderha Yavrusu" end
if Y["Dragonmaw Reclaimer"] == nil then Y["Dragonmaw Reclaimer"] = "Dragonmaw Fetihçi" end
if Y["Dragonmaw Saboteur"] == nil then Y["Dragonmaw Saboteur"] = "Dragonmaw Sabotajcı" end
if Y["Dragonmaw Soulbinder"] == nil then Y["Dragonmaw Soulbinder"] = "Dragonmaw Ruhbağlayıcı" end
if Y["Dragonmaw Warder"] == nil then Y["Dragonmaw Warder"] = "Dragonmaw Nöbetçisi" end
if Y["Dreamhunter Hound"] == nil then Y["Dreamhunter Hound"] = "Dreamhunter Av Köpeği" end
if Y["Duskwood Owl"] == nil then Y["Duskwood Owl"] = "Duskwood Baykuşu" end
if Y["Dwarf Hunter"] == nil then Y["Dwarf Hunter"] = "Cüce Avcı" end
if Y["Dwarf Miner"] == nil then Y["Dwarf Miner"] = "Cüce Madenci" end
if Y["Dwarf Warrior"] == nil then Y["Dwarf Warrior"] = "Cüce Savaşçı" end
if Y["Eastsea Buccaneer"] == nil then Y["Eastsea Buccaneer"] = "Eastsea Korsanı" end
if Y["Eastsea Raider"] == nil then Y["Eastsea Raider"] = "Eastsea Akıncı" end
if Y["Echo of a Lost Soul"] == nil then Y["Echo of a Lost Soul"] = "Kayıp Bir Ruhun Yankısı" end
if Y["Elder Crocolisk"] == nil then Y["Elder Crocolisk"] = "Yaşlı Timsah" end
if Y["Elder Snow Leopard"] == nil then Y["Elder Snow Leopard"] = "Yaşlı Kar Leoparı" end
if Y["Elderly War Kodo"] == nil then Y["Elderly War Kodo"] = "Yaşlı Savaş Kodosu" end
if Y["Enormous Crustacean"] == nil then Y["Enormous Crustacean"] = "Devasa Kabuklu" end
if Y["Enraged Ghost"] == nil then Y["Enraged Ghost"] = "Öfkeli Hayalet" end
if Y["Enraged Leywalker"] == nil then Y["Enraged Leywalker"] = "Öfkeli Leywalker" end
if Y["Enraged Shade"] == nil then Y["Enraged Shade"] = "Öfkeli Gölge" end
if Y["Enthusiastic Wisp"] == nil then Y["Enthusiastic Wisp"] = "Hevesli Wisp" end
if Y["Escaped Sheep"] == nil then Y["Escaped Sheep"] = "Kaçak Koyun" end
if Y["Fallen Mage"] == nil then Y["Fallen Mage"] = "Düşmüş Büyücü" end
if Y["Fallen Moonkin"] == nil then Y["Fallen Moonkin"] = "Düşmüş Moonkin" end
if Y["Famished Blackworg"] == nil then Y["Famished Blackworg"] = "Aç Blackworg" end
if Y["Farholde Laborer"] == nil then Y["Farholde Laborer"] = "Farholde İşçi" end
if Y["Farholde Lookout"] == nil then Y["Farholde Lookout"] = "Farholde Gözcü" end
if Y["Farholde Scout"] == nil then Y["Farholde Scout"] = "Farholde Gözcü" end
if Y["Farholde Scout Trainee"] == nil then Y["Farholde Scout Trainee"] = "Farholde Gözcü Çırağı" end
if Y["Farholde Sentry"] == nil then Y["Farholde Sentry"] = "Farholde Nöbetçi" end
if Y["Farholde Steed"] == nil then Y["Farholde Steed"] = "Farholde Atı" end
if Y["Farm Chicken"] == nil then Y["Farm Chicken"] = "Çiftlik Tavuğu" end
if Y["Fel Interloper"] == nil then Y["Fel Interloper"] = "Fel Davetsizi" end
if Y["Fel-Agitated Stag"] == nil then Y["Fel-Agitated Stag"] = "Fel ile Kızışmış Geyik" end
if Y["Firebrand Pyromancer"] == nil then Y["Firebrand Pyromancer"] = "Firebrand Piromansı" end
if Y["Firelands Drudge"] == nil then Y["Firelands Drudge"] = "Firelands İşçisi" end
if Y["Fleshflayer Ravener"] == nil then Y["Fleshflayer Ravener"] = "Fleshflayer Yırtıcısı" end
if Y["Foothills Duskbat"] == nil then Y["Foothills Duskbat"] = "Foothills Alacakarganı" end
if Y["Forest Sprite"] == nil then Y["Forest Sprite"] = "Orman Perisi" end
if Y["Forlorn Ghost"] == nil then Y["Forlorn Ghost"] = "Kimsesiz Hayalet" end
if Y["Forlorn Shade"] == nil then Y["Forlorn Shade"] = "Kimsesiz Gölge" end
if Y["Forsaken Adventurer"] == nil then Y["Forsaken Adventurer"] = "Forsaken Maceracı" end
if Y["Frenzied Whelp"] == nil then Y["Frenzied Whelp"] = "Çılgın Ejderha Yavrusu" end
if Y["Freshwater Crocolisk"] == nil then Y["Freshwater Crocolisk"] = "Tatlı Su Krokolisk" end
if Y["Frog Familiar"] == nil then Y["Frog Familiar"] = "Kurbağa Yoldaşı" end
if Y["Gadgetzan Enforcer"] == nil then Y["Gadgetzan Enforcer"] = "Gadgetzan Muhafızı" end
if Y["Galak Assassin"] == nil then Y["Galak Assassin"] = "Galak Suikastçısı" end
if Y["Galak Flame Guard"] == nil then Y["Galak Flame Guard"] = "Galak Alev Muhafızı" end
if Y["Galak Marauder"] == nil then Y["Galak Marauder"] = "Galak Yağmacı" end
if Y["Galak Messenger"] == nil then Y["Galak Messenger"] = "Galak Haberci" end
if Y["Galak Pack Runner"] == nil then Y["Galak Pack Runner"] = "Galak Sürü Koşucusu" end
if Y["Galak Scout"] == nil then Y["Galak Scout"] = "Galak Gözcüsü" end
if Y["Galestrider Chick"] == nil then Y["Galestrider Chick"] = "Galestrider Civcivi" end
if Y["Gargantuan Plaguebat"] == nil then Y["Gargantuan Plaguebat"] = "Dev Veba Yarasası" end
if Y["Gelkis Guardian"] == nil then Y["Gelkis Guardian"] = "Gelkis Koruyucusu" end
if Y["Ghostly Beast"] == nil then Y["Ghostly Beast"] = "Hayalet Canavar" end
if Y["Gloomrise Hatchling"] == nil then Y["Gloomrise Hatchling"] = "Gloomrise Yavrusu" end
if Y["Gloomrise Soldier"] == nil then Y["Gloomrise Soldier"] = "Gloomrise Askeri" end
if Y["Gloomrise Spinner"] == nil then Y["Gloomrise Spinner"] = "Gloomrise Örümceği" end
if Y["Gnawed Corpse"] == nil then Y["Gnawed Corpse"] = "Kemirilmiş Ceset" end
if Y["Gnome Rogue"] == nil then Y["Gnome Rogue"] = "Gnome Haydut" end
if Y["Gnome Warrior"] == nil then Y["Gnome Warrior"] = "Gnome Savaşçı" end
if Y["Gray Ent Pet"] == nil then Y["Gray Ent Pet"] = "Gri Ent Dostu" end
if Y["Gray Fox"] == nil then Y["Gray Fox"] = "Gri Tilki" end
if Y["Greater Firebird"] == nil then Y["Greater Firebird"] = "Büyük Ateş Kuşu" end
if Y["Groddoc Infant"] == nil then Y["Groddoc Infant"] = "Groddoc Yavrusu" end
if Y["Ground Pounder"] == nil then Y["Ground Pounder"] = "Yer Dövücü" end
if Y["Hay Weevil"] == nil then Y["Hay Weevil"] = "Saman Böceği" end
if Y["Hexed Larva"] == nil then Y["Hexed Larva"] = "Lanetli Larva" end
if Y["High Plains Buzzard"] == nil then Y["High Plains Buzzard"] = "High Plains Akbabası" end
if Y["Highland Creeper"] == nil then Y["Highland Creeper"] = "Highland Sürüngen" end
if Y["Highland Spider"] == nil then Y["Highland Spider"] = "Yayla Örümceği" end
if Y["Highland Tortoise"] == nil then Y["Highland Tortoise"] = "Yayla Kaplumbağası" end
if Y["Highland Wanderer"] == nil then Y["Highland Wanderer"] = "Highland Gezgin" end
if Y["Highlands Bandit"] == nil then Y["Highlands Bandit"] = "Highlands Haydutu" end
if Y["Hippogryph Matriarch"] == nil then Y["Hippogryph Matriarch"] = "Hippogryph Matriyarkı" end
if Y["Hippogryph Youth"] == nil then Y["Hippogryph Youth"] = "Hippogryph Genci" end
if Y["Honey Wasp"] == nil then Y["Honey Wasp"] = "Bal Yabanarısı" end
if Y["Horde Adventurer"] == nil then Y["Horde Adventurer"] = "Horde Maceracısı" end
if Y["Horror of the Deep"] == nil then Y["Horror of the Deep"] = "Derinlerin Dehşeti" end
if Y["Human Mage"] == nil then Y["Human Mage"] = "İnsan Büyücü" end
if Y["Human Paladin"] == nil then Y["Human Paladin"] = "İnsan Paladin" end
if Y["Hungry Bandit"] == nil then Y["Hungry Bandit"] = "Aç Haydut" end
if Y["Hungry Crocolisk"] == nil then Y["Hungry Crocolisk"] = "Aç Krokolisk" end
if Y["Hyacinth Macaw"] == nil then Y["Hyacinth Macaw"] = "Sümbül Papağanı" end
if Y["Hydroling"] == nil then Y["Hydroling"] = "Su Yavrusu" end
if Y["Hyjal Bear"] == nil then Y["Hyjal Bear"] = "Hyjal Ayısı" end
if Y["Illusionary Phantasm"] == nil then Y["Illusionary Phantasm"] = "Yanılsama Hayaleti" end
if Y["Irradiated Burrower"] == nil then Y["Irradiated Burrower"] = "Işınlanmış Kazıcı" end
if Y["Jumbo Crawfish"] == nil then Y["Jumbo Crawfish"] = "Dev Kerevit" end
if Y["Jungle Boa"] == nil then Y["Jungle Boa"] = "Orman Boası" end
if Y["Kirin Tor Enforcer"] == nil then Y["Kirin Tor Enforcer"] = "Kirin Tor Cebir Görevlisi" end
if Y["Kirin Tor Wizard"] == nil then Y["Kirin Tor Wizard"] = "Kirin Tor Büyücüsü" end
if Y["Lake Crawler"] == nil then Y["Lake Crawler"] = "Göl Sürüngeni" end
if Y["Large Loch Crocolisk"] == nil then Y["Large Loch Crocolisk"] = "Büyük Loch Crocolisk" end
if Y["Large Noxious Slime"] == nil then Y["Large Noxious Slime"] = "Büyük Zehirli Balçık" end
if Y["Lesser Stone Golem"] == nil then Y["Lesser Stone Golem"] = "Küçük Taş Golem" end
if Y["Living Lightning"] == nil then Y["Living Lightning"] = "Canlı Yıldırım" end
if Y["Living Storm"] == nil then Y["Living Storm"] = "Yaşayan Fırtına" end
if Y["Lordaeron Guard"] == nil then Y["Lordaeron Guard"] = "Lordaeron Muhafızı" end
if Y["Lost Defender"] == nil then Y["Lost Defender"] = "Kayıp Savunmacı" end
if Y["Lost Horse"] == nil then Y["Lost Horse"] = "Kayıp At" end
if Y["Lost Knight"] == nil then Y["Lost Knight"] = "Kayıp Şövalye" end
if Y["Low Plains Buzzard"] == nil then Y["Low Plains Buzzard"] = "Low Plains Akbabası" end
if Y["Mad Sprite"] == nil then Y["Mad Sprite"] = "Çılgın Peri" end
if Y["Magram Guardian"] == nil then Y["Magram Guardian"] = "Magram Koruyucu" end
if Y["Magram Necromancer"] == nil then Y["Magram Necromancer"] = "Magram Ölü Büyücüsü" end
if Y["Makrinni Burrower"] == nil then Y["Makrinni Burrower"] = "Makrinni Kazıcı" end
if Y["Malevolent Storm"] == nil then Y["Malevolent Storm"] = "Kötücül Fırtına" end
if Y["Mana Phantom"] == nil then Y["Mana Phantom"] = "Mana Hayaleti" end
if Y["Mana Ray"] == nil then Y["Mana Ray"] = "Mana Vatozu" end
if Y["Manticore Hunter"] == nil then Y["Manticore Hunter"] = "Manticore Avcısı" end
if Y["Marsh Owl"] == nil then Y["Marsh Owl"] = "Bataklık Baykuşu" end
if Y["Marsh Skulker"] == nil then Y["Marsh Skulker"] = "Bataklık Sinsisi" end
if Y["Master Tailor"] == nil then Y["Master Tailor"] = "Usta Terzi" end
if Y["Mechanical Chicken"] == nil then Y["Mechanical Chicken"] = "Mekanik Tavuk" end
if Y["Mechanical Dragonling"] == nil then Y["Mechanical Dragonling"] = "Mekanik Ejderhacık" end
if Y["Methuselah Crab"] == nil then Y["Methuselah Crab"] = "Methuselah Yengeci" end
if Y["Might of Kalimdor Archer"] == nil then Y["Might of Kalimdor Archer"] = "Might of Kalimdor Okçu" end
if Y["Might of Kalimdor Archmage"] == nil then Y["Might of Kalimdor Archmage"] = "Might of Kalimdor Başbüyücü" end
if Y["Might of Kalimdor Mage"] == nil then Y["Might of Kalimdor Mage"] = "Might of Kalimdor Büyücü" end
if Y["Might of Kalimdor Shaman"] == nil then Y["Might of Kalimdor Shaman"] = "Might of Kalimdor Şaman" end
if Y["Minor Ice Elemental"] == nil then Y["Minor Ice Elemental"] = "Küçük Buz Elementi" end
if Y["Monstrous Threshadon"] == nil then Y["Monstrous Threshadon"] = "Devasa Threshadon" end
if Y["Mosh'Ogg Butcher"] == nil then Y["Mosh'Ogg Butcher"] = "Mosh'Ogg Kasap" end
if Y["Mosh'Ogg Witch Doctor"] == nil then Y["Mosh'Ogg Witch Doctor"] = "Mosh'Ogg Cadı Doktor" end
if Y["Mounted Reindeer"] == nil then Y["Mounted Reindeer"] = "Binek Ren Geyiği" end
if Y["Mourning's Rest Spirit"] == nil then Y["Mourning's Rest Spirit"] = "Mourning's Rest Ruhu" end
if Y["Mudfin Warrior"] == nil then Y["Mudfin Warrior"] = "Mudfin Savaşçısı" end
if Y["Mudrock Burrower"] == nil then Y["Mudrock Burrower"] = "Mudrock Kazıcısı" end
if Y["Mudrock Tortoise"] == nil then Y["Mudrock Tortoise"] = "Mudrock Kaplumbağası" end
if Y["Murkgill Lord"] == nil then Y["Murkgill Lord"] = "Murkgill Lordu" end
if Y["Nerubian Webspinner"] == nil then Y["Nerubian Webspinner"] = "Nerubian Ağ Örücü" end
if Y["Nightmare Fiend"] == nil then Y["Nightmare Fiend"] = "Kâbus Canavarı" end
if Y["Nightmare Grizzly"] == nil then Y["Nightmare Grizzly"] = "Kâbus Boz Ayısı" end
if Y["Nightmare Hound"] == nil then Y["Nightmare Hound"] = "Kâbus Tazısı" end
if Y["Nightsaber Guardian"] == nil then Y["Nightsaber Guardian"] = "Nightsaber Koruyucu" end
if Y["Obsidian Reaver"] == nil then Y["Obsidian Reaver"] = "Obsidyen Biçici" end
if Y["Off-Duty Pack Mule"] == nil then Y["Off-Duty Pack Mule"] = "Mesai Dışı Yük Katırı" end
if Y["Ogre Miner"] == nil then Y["Ogre Miner"] = "Ogre Madenci" end
if Y["Old Town Thug"] == nil then Y["Old Town Thug"] = "Old Town Külhanbeyi" end
if Y["Orange Tabby"] == nil then Y["Orange Tabby"] = "Turuncu Tekir Kedi" end
if Y["Outcast Centaur"] == nil then Y["Outcast Centaur"] = "Sürgün Centaur" end
if Y["Outcast Cryomancer"] == nil then Y["Outcast Cryomancer"] = "Sürgün Don Büyücüsü" end
if Y["Outcast Marauder"] == nil then Y["Outcast Marauder"] = "Sürgün Yağmacı" end
if Y["Outcast Scout"] == nil then Y["Outcast Scout"] = "Outcast Gözcü" end
if Y["Paladin Trainee"] == nil then Y["Paladin Trainee"] = "Paladin Çırağı" end
if Y["Peacekeeper Scout"] == nil then Y["Peacekeeper Scout"] = "Peacekeeper Gözcü" end
if Y["Plagued Cockroach"] == nil then Y["Plagued Cockroach"] = "Vebalı Hamamböceği" end
if Y["Plagueland Termite"] == nil then Y["Plagueland Termite"] = "Plagueland Termiti" end
if Y["Plains Coyote"] == nil then Y["Plains Coyote"] = "Ova Çakalı" end
if Y["Polymorphed Apprentice"] == nil then Y["Polymorphed Apprentice"] = "Dönüştürülmüş Çırak" end
if Y["Polymorphed Chicken"] == nil then Y["Polymorphed Chicken"] = "Dönüştürülmüş Tavuk" end
if Y["Polymorphed Cow"] == nil then Y["Polymorphed Cow"] = "Dönüştürülmüş İnek" end
if Y["Polymorphed Pig"] == nil then Y["Polymorphed Pig"] = "Dönüştürülmüş Domuz" end
if Y["Powderfuse Bruiser"] == nil then Y["Powderfuse Bruiser"] = "Powderfuse Pehlivan" end
if Y["Prairie Wolf Pup"] == nil then Y["Prairie Wolf Pup"] = "Bozkır Kurdu Yavrusu" end
if Y["Predatory Hyjal Stag"] == nil then Y["Predatory Hyjal Stag"] = "Yırtıcı Hyjal Geyiği" end
if Y["Primeval Elemental"] == nil then Y["Primeval Elemental"] = "İlkel Element" end
if Y["Rabid Forest Wolf"] == nil then Y["Rabid Forest Wolf"] = "Kuduz Orman Kurdu" end
if Y["Ragged Traveler"] == nil then Y["Ragged Traveler"] = "Partal Gezgin" end
if Y["Rallied Defender"] == nil then Y["Rallied Defender"] = "Toparlanmış Savunucu" end
if Y["Rat Familiar"] == nil then Y["Rat Familiar"] = "Sıçan Yoldaşı" end
if Y["Ravenous Shark"] == nil then Y["Ravenous Shark"] = "Aç Köpekbalığı" end
if Y["Razormane Poacher"] == nil then Y["Razormane Poacher"] = "Razormane Kaçak Avcısı" end
if Y["Red Ground Squirrel"] == nil then Y["Red Ground Squirrel"] = "Kırmızı Yer Sincabı" end
if Y["Redridge Scout"] == nil then Y["Redridge Scout"] = "Redridge Gözcü" end
if Y["Redridge Thug"] == nil then Y["Redridge Thug"] = "Redridge Külhanbeyi" end
if Y["Redridge Trapper"] == nil then Y["Redridge Trapper"] = "Redridge Tuzakçı" end
if Y["Relic Guardian"] == nil then Y["Relic Guardian"] = "Kalıntı Koruyucu" end
if Y["Renegade Fire Elemental"] == nil then Y["Renegade Fire Elemental"] = "Hain Ateş Elementi" end
if Y["Revantusk Hunter"] == nil then Y["Revantusk Hunter"] = "Revantusk Avcı" end
if Y["Ridgeshade Creeper"] == nil then Y["Ridgeshade Creeper"] = "Ridgeshade Sürüngen" end
if Y["Riding Horse (Brown)"] == nil then Y["Riding Horse (Brown)"] = "Binek Atı (Kahverengi)" end
if Y["Riding Horse (Pinto)"] == nil then Y["Riding Horse (Pinto)"] = "Binek Atı (Alaca)" end
if Y["Riding Kodo (Green)"] == nil then Y["Riding Kodo (Green)"] = "Binek Kodosu (Yeşil)" end
if Y["Riding Ram (Gray)"] == nil then Y["Riding Ram (Gray)"] = "Binek Koçu (Gri)" end
if Y["Riding Tiger (Orange)"] == nil then Y["Riding Tiger (Orange)"] = "Binek Kaplanı (Turuncu)" end
if Y["Riding Tiger (Yellow)"] == nil then Y["Riding Tiger (Yellow)"] = "Binek Kaplanı (Sarı)" end
if Y["Riding Wolf (Red)"] == nil then Y["Riding Wolf (Red)"] = "Binek Kurdu (Kırmızı)" end
if Y["Risen Charger"] == nil then Y["Risen Charger"] = "Dirilmiş Savaş Atı" end
if Y["Rog'mar Poacher"] == nil then Y["Rog'mar Poacher"] = "Rog'mar Kaçak Avcı" end
if Y["Rog'mar Scout"] == nil then Y["Rog'mar Scout"] = "Rog'mar Gözcüsü" end
if Y["Rog'mar Shaman Initiate"] == nil then Y["Rog'mar Shaman Initiate"] = "Rog'mar Şaman Çırağı" end
if Y["Rolf's corpse"] == nil then Y["Rolf's corpse"] = "Rolf'un Cesedi" end
if Y["Roosting Duskbat"] == nil then Y["Roosting Duskbat"] = "Tüneyen Alacakaranlık Yarasası" end
if Y["Ruined Ballista"] == nil then Y["Ruined Ballista"] = "Harap Balista" end
if Y["Rustleaf Fox"] == nil then Y["Rustleaf Fox"] = "Rustleaf Tilkisi" end
if Y["Rusty Wolf Pup"] == nil then Y["Rusty Wolf Pup"] = "Paslı Kurt Yavrusu" end
if Y["Sadistic Fiend"] == nil then Y["Sadistic Fiend"] = "Sadist İblis" end
if Y["Saltscale Muckdweller"] == nil then Y["Saltscale Muckdweller"] = "Saltscale Çamurcul" end
if Y["Scarlet Bloodhound"] == nil then Y["Scarlet Bloodhound"] = "Scarlet Av Tazısı" end
if Y["Scarshield Infiltrator"] == nil then Y["Scarshield Infiltrator"] = "Scarshield Sızıcı" end
if Y["Scarshield Spellbinder"] == nil then Y["Scarshield Spellbinder"] = "Scarshield Büyücüsü" end
if Y["Sewer Fiend"] == nil then Y["Sewer Fiend"] = "Lağım İblisi" end
if Y["Shadowgale Shriekling"] == nil then Y["Shadowgale Shriekling"] = "Shadowgale Çığlıkçı" end
if Y["Shadowgale Squirrel"] == nil then Y["Shadowgale Squirrel"] = "Shadowgale Sincabı" end
if Y["Shadowsworn Cultist"] == nil then Y["Shadowsworn Cultist"] = "Gölge Yeminli Tarikatçı" end
if Y["Shard Guard"] == nil then Y["Shard Guard"] = "Shard Muhafızı" end
if Y["Shriekling Ancient"] == nil then Y["Shriekling Ancient"] = "Kadim Çığlıkçı" end
if Y["Silithid Invader"] == nil then Y["Silithid Invader"] = "Silithid İstilacı" end
if Y["Silver Tabby"] == nil then Y["Silver Tabby"] = "Gümüş Tekir Kedi" end
if Y["Silverwing Archer"] == nil then Y["Silverwing Archer"] = "Silverwing Okçu" end
if Y["Simmering Elemental"] == nil then Y["Simmering Elemental"] = "Kaynayan Element" end
if Y["Skeletal Black Warhorse"] == nil then Y["Skeletal Black Warhorse"] = "İskelet Kara Savaş Atı" end
if Y["Skeletal Necromancer"] == nil then Y["Skeletal Necromancer"] = "İskelet Ölü Büyücüsü" end
if Y["Skeleton Warrior"] == nil then Y["Skeleton Warrior"] = "İskelet Savaşçı" end
if Y["Skittering Spider"] == nil then Y["Skittering Spider"] = "Koşuşturan Örümcek" end
if Y["Skyborne Hunter"] == nil then Y["Skyborne Hunter"] = "Skyborne Avcı" end
if Y["Skyborne Shaman"] == nil then Y["Skyborne Shaman"] = "Skyborne Şaman" end
if Y["Skyshrike Fury"] == nil then Y["Skyshrike Fury"] = "Skyshrike Furisi" end
if Y["Slack-Jawed Ghoul"] == nil then Y["Slack-Jawed Ghoul"] = "Ağzı Açık Ghoul" end
if Y["Slain Fledgling"] == nil then Y["Slain Fledgling"] = "Öldürülmüş Yavru Kuş" end
if Y["Snow Leopard Prowler"] == nil then Y["Snow Leopard Prowler"] = "Kar Leoparı Gezgini" end
if Y["Snowy Wolf Pup"] == nil then Y["Snowy Wolf Pup"] = "Karlı Kurt Yavrusu" end
if Y["Southshore Crier"] == nil then Y["Southshore Crier"] = "Southshore Tellalı" end
if Y["Southshore Defender"] == nil then Y["Southshore Defender"] = "Southshore Savunucusu" end
if Y["Spectral Bear Cub"] == nil then Y["Spectral Bear Cub"] = "Hayalet Ayı Yavrusu" end
if Y["Spectral Farmer"] == nil then Y["Spectral Farmer"] = "Hayalet Çiftçi" end
if Y["Spider Swarmling"] == nil then Y["Spider Swarmling"] = "Örümcek Sürüsü Yavrusu" end
if Y["Spirit of the Damned"] == nil then Y["Spirit of the Damned"] = "Lanetlilerin Ruhu" end
if Y["Spitelash Scout"] == nil then Y["Spitelash Scout"] = "Spitelash Gözcü" end
if Y["Steamwheedle Enforcer"] == nil then Y["Steamwheedle Enforcer"] = "Steamwheedle Muhafızı" end
if Y["Stone Fury"] == nil then Y["Stone Fury"] = "Taş Gazap" end
if Y["Stonehearth Warmaster"] == nil then Y["Stonehearth Warmaster"] = "Stonehearth Savaş Ustası" end
if Y["Stormwind City Defender"] == nil then Y["Stormwind City Defender"] = "Stormwind Şehir Savunucusu" end
if Y["Stratholme Courier"] == nil then Y["Stratholme Courier"] = "Stratholme Ulağı" end
if Y["Subdued Dragonspawn"] == nil then Y["Subdued Dragonspawn"] = "Boyun Eğdirilmiş Ejderha Yavrusu" end
if Y["Suffused Treant"] == nil then Y["Suffused Treant"] = "Doygun Treant" end
if Y["Summoned Incubus"] == nil then Y["Summoned Incubus"] = "Çağrılmış Incubus" end
if Y["Survivor Village Guard"] == nil then Y["Survivor Village Guard"] = "Hayatta Kalan Köy Muhafızı" end
if Y["Syndicate Smuggler"] == nil then Y["Syndicate Smuggler"] = "Syndicate Kaçakçı" end
if Y["Tainted Hyjal Bear"] == nil then Y["Tainted Hyjal Bear"] = "Lekeli Hyjal Ayısı" end
if Y["Tainted Hyjal Owl"] == nil then Y["Tainted Hyjal Owl"] = "Lekeli Hyjal Baykuşu" end
if Y["Tainted Shrubbery"] == nil then Y["Tainted Shrubbery"] = "Bozulmuş Çalılık" end
if Y["Tallstrider Hatchling"] == nil then Y["Tallstrider Hatchling"] = "Tallstrider Yavrusu" end
if Y["Tarren Mill Elite"] == nil then Y["Tarren Mill Elite"] = "Tarren Mill Elit" end
if Y["Tattered Parachute"] == nil then Y["Tattered Parachute"] = "Yırtık Paraşüt" end
if Y["Tauren Hunter"] == nil then Y["Tauren Hunter"] = "Tauren Avcı" end
if Y["Territorial Fox"] == nil then Y["Territorial Fox"] = "Bölgeci Tilki" end
if Y["Terror Whelp"] == nil then Y["Terror Whelp"] = "Dehşet Ejderha Yavrusu" end
if Y["Theradrim Shardling"] == nil then Y["Theradrim Shardling"] = "Theradrim Kıymık" end
if Y["Theramore Defender"] == nil then Y["Theramore Defender"] = "Theramore Savunucusu" end
if Y["Theramore Elite"] == nil then Y["Theramore Elite"] = "Theramore Elit" end
if Y["Tiny Walking Bomb"] == nil then Y["Tiny Walking Bomb"] = "Minik Yürüyen Bomba" end
if Y["Tower Watchman"] == nil then Y["Tower Watchman"] = "Kule Gözcüsü" end
if Y["Traumatized Spirit"] == nil then Y["Traumatized Spirit"] = "Travmalı Ruh" end
if Y["Treant Avatar"] == nil then Y["Treant Avatar"] = "Treant Avatarı" end
if Y["Troll Rogue"] == nil then Y["Troll Rogue"] = "Troll Hırsız" end
if Y["Turner's Mill Lumberjack"] == nil then Y["Turner's Mill Lumberjack"] = "Turner's Mill Oduncusu" end
if Y["Twilight Instigator"] == nil then Y["Twilight Instigator"] = "Twilight Kışkırtıcısı" end
if Y["Twilight Mauler"] == nil then Y["Twilight Mauler"] = "Twilight Parçalayıcı" end
if Y["Twilight Raider"] == nil then Y["Twilight Raider"] = "Twilight Yağmacı" end
if Y["Twilight Shadowmancer"] == nil then Y["Twilight Shadowmancer"] = "Twilight Gölge Büyücüsü" end
if Y["Unfinished Abomination"] == nil then Y["Unfinished Abomination"] = "Bitmemiş İğrençlik" end
if Y["Unstable Mana Rift"] == nil then Y["Unstable Mana Rift"] = "Dengesiz Mana Yarığı" end
if Y["Unstable Wisp"] == nil then Y["Unstable Wisp"] = "Kararsız Wisp" end
if Y["Ursera Defender"] == nil then Y["Ursera Defender"] = "Ursera Savunucusu" end
if Y["Ursera Scavenger"] == nil then Y["Ursera Scavenger"] = "Ursera Leşçisi" end
if Y["Vengeful Citizen"] == nil then Y["Vengeful Citizen"] = "İntikamcı Vatandaş" end
if Y["Venom Lurker"] == nil then Y["Venom Lurker"] = "Zehir Pusucusu" end
if Y["Venture Co. Agent"] == nil then Y["Venture Co. Agent"] = "Venture Co. Ajanı" end
if Y["Venture Co. Poacher"] == nil then Y["Venture Co. Poacher"] = "Venture Co. Kaçak Avcı" end
if Y["Vile Fin Attacker"] == nil then Y["Vile Fin Attacker"] = "Vile Fin Saldırgan" end
if Y["Vile Fin Seer"] == nil then Y["Vile Fin Seer"] = "Vile Fin Kâhini" end
if Y["Webbed Forsaken"] == nil then Y["Webbed Forsaken"] = "Ağa Sarılmış Forsaken" end
if Y["Wendigo Shaman"] == nil then Y["Wendigo Shaman"] = "Wendigo Şaman" end
if Y["White Baby Murloc"] == nil then Y["White Baby Murloc"] = "Beyaz Yavru Murloc" end
if Y["White Kitten"] == nil then Y["White Kitten"] = "Beyaz Yavru Kedi" end
if Y["White Lion"] == nil then Y["White Lion"] = "Beyaz Aslan" end
if Y["White Tiger Cub"] == nil then Y["White Tiger Cub"] = "Beyaz Kaplan Yavrusu" end
if Y["Wildplains Huntress"] == nil then Y["Wildplains Huntress"] = "Wildplains Avcısı" end
if Y["Wind Sprite"] == nil then Y["Wind Sprite"] = "Rüzgâr Perisi" end
if Y["Windshaper Assassin"] == nil then Y["Windshaper Assassin"] = "Windshaper Suikastçı" end
if Y["Windshaper Guardian"] == nil then Y["Windshaper Guardian"] = "Windshaper Koruyucusu" end
if Y["Windshaper Novice Seer"] == nil then Y["Windshaper Novice Seer"] = "Windshaper Acemi Kâhin" end
if Y["Windshaper Shaman"] == nil then Y["Windshaper Shaman"] = "Windshaper Şaman" end
if Y["Winna's Kitten"] == nil then Y["Winna's Kitten"] = "Winna'nın Kedi Yavrusu" end
if Y["Witherbark Champion"] == nil then Y["Witherbark Champion"] = "Witherbark Şampiyon" end
if Y["Wormwing Fledgling"] == nil then Y["Wormwing Fledgling"] = "Wormwing Yavrusu" end
if Y["Wounded Farholde Scout"] == nil then Y["Wounded Farholde Scout"] = "Yaralı Farholde Gözcü" end
if Y["Wrath Whelp"] == nil then Y["Wrath Whelp"] = "Gazap Ejderha Yavrusu" end
if Y["Wriggling Slime"] == nil then Y["Wriggling Slime"] = "Kıvranan Balçık" end
if Y["Writhing Flame"] == nil then Y["Writhing Flame"] = "Kıvranan Alev" end
if Y["Wyrmkin Terrorwalker"] == nil then Y["Wyrmkin Terrorwalker"] = "Wyrmkin Dehşet Yürüyen" end
