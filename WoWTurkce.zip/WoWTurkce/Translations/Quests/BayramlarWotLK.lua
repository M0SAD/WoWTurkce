-- WotLK bayram görevleri
-- b=başlık, a=açıklama, h=hedef, i=ilerleme, t=tamamlama
-- k = çevrilen İngilizce metnin parmak izi (metin değişirse çeviri gösterilmez, yeniden kaydedilir)
local V = WoWTurkce.Veri

V[12133] = { b="Kabağı Parçala", a="Bu büyük bal kabağı feneri köyün tam ortasında duruyor. Kendisine bakanları süzüyor; içinde karanlık bir tehdit sakladığı belli.$B$BKabağı parçaladığında içinden eski, kavrulmuş kutsal bir sembol çıkıyor.", h="Kavrulmuş Kutsal Sembol'ü Kostümlü Yetimhane Müdiresi'ne ver.", i="Evet, $N?", t="Bunu Headless Horseman'ın bal kabağı fenerinin içinde mi buldun? Bu, Işık'ın eski bir sembolü. Lanetlenip bugünkü canavara dönüşmeden önce Süvari'ye ait olmalı. Teşekkür ederim, $N. Bu sembol paladinlerin yanında olmayı hak ediyor. Onlara ulaşmasını sağlayacağım.$B$BAh, neredeyse unutuyordum! Gizli bir hayranın var...$B$BÇocuklardan biri bunun sende olmasını istedi. Kendisi vermeye utandı.", k={b=2386408742, a=2749338337, h=3851502095, t=1670372783} }
V[12135] = { b="\"Bırakın Ateşler Gelsin!\"", a="Bize yardım etmelisin! Headless Horseman her an köye saldırabilir! Her yer alevler içinde kalacak! Çocuklar güvende değil!$B$BLütfen $n, Headless Horseman'ın ateşlerine göğüs gerer misin? O geldiğinde itfaiye ekibine katılmalısın. Bir kova kap ve ateşin üzerine boşalt ya da alevlere daha yakın olan bir dostuna uzat. Bütün yangınları söndürürsen belki de kurtulabiliriz!", h="Kostümlü Yetimhane Müdiresi, Headless Horseman köyü ateşe verdikten sonra bütün yangınları söndürmene yardım etmeni istiyor. Yangınlar sönünce Kostümlü Yetimhane Müdiresi ile yeniden konuş.", i="$N, çocukları kurtaracağına söz vermiştin!", t="Ah, teşekkür ederim! Işık iyi işlerini kutsasın, nazik $Gefendim:hanımefendi;. Kara Süvari'nin gölgesi hâlâ üzerimizde, ama en azından şimdilik köy onun alevlerinden güvende.", k={b=1388338536, a=1854459420, h=1863150995, t=362590081} }
V[12139] = { b="\"Bırakın Ateşler Gelsin!\"", a="Headless Horseman her an köye saldırabilir! Her yer alevler içinde kalacak!$B$B$n, Headless Horseman'ın ateşlerine göğüs gerer misin? O geldiğinde itfaiye ekibine katılmalısın. Bir kova kap ve ateşin üzerine boşalt ya da alevlere daha yakın olan bir dostuna uzat. Bütün yangınları söndürürsen belki de kurtulabiliriz!", h="Maskeli Yetimhane Müdiresi bütün köy yangınlarını söndürmene yardım etmeni istiyor. Yangınlar sönünce kasabadaki Maskeli Yetimhane Müdiresi ile yeniden konuş.", t="Yangınlar söndü! Sen ve itfaiye ekibin zafer kazandınız! Hah!$B$BHeadless Horseman'ın saldırısı başarısız oldu, ama o ve kafası birlikte yok edilene dek geri dönmeye devam edecek.$B$BYine de o zamana kadar, çocuklarımıza getirdiğin güvenin tadını çıkaralım. Bugünkü cesur çalışmana tanık olmak benim için bir onurdu.", k={b=1388338536, a=1854459420, h=3292988082, t=2129264183} }
V[12155] = { b="Kabağı Parçala", a="Bu büyük bal kabağı feneri köyün tam ortasında duruyor. Kendisine bakanları süzüyor; içinde karanlık bir tehdit sakladığı belli.$B$BKabağı parçaladığında içinden eski, kavrulmuş kutsal bir sembol çıkıyor.", h="Kavrulmuş Kutsal Sembol'ü Maskeli Yetimhane Müdiresi'ne ver.", i="Evet, $N?", t="Bunu Headless Horseman'ın bal kabağı fenerinin içinde mi buldun? Bu, Işık'ın eski bir sembolü. Lanetlenip bugünkü canavara dönüşmeden önce Süvari'ye ait olmalı. Teşekkür ederim, $N. Bu sembol paladinlerin yanında olmayı hak ediyor. Onlara ulaşmasını sağlayacağım.$B$BAh, neredeyse unutuyordum! Gizli bir hayranın var...$B$BÇocuklardan biri bunun sende olmasını istedi. Kendisi vermeye utandı.", k={b=2386408742, a=2749338337, h=1620563392, t=1670372783} }
V[12313] = { b="KULLANILMIYOR Bira Festivali'ni Kurtar!", a="Bira Festivali'ni kurtar! Blackrock Depths'teki Grim Guzzler'da bulunan Bira Festivali casusuyla konuş.", h="Blackrock Depths'teki Grim Guzzler'da bulunan Bira Festivali casusuyla konuş.", k={b=2609174570, a=3851607766, h=3851607766} }
V[12940] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[12941] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[12944] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[12945] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[12946] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[12947] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[12950] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13203] = { b="Bir Kış Örtüsü Hediyesi", k={b=3222383993} }
V[13433] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13434] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13435] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13436] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13437] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13438] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13439] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13440] = { b="Bu Ateşi Kirlet!", t="İttifak'ın Borean Tundra şenlik ateşini kirlet!", k={b=2141550803, t=303430444} }
V[13441] = { b="Bu Ateşi Kirlet!", t="Horde'un Borean Tundra şenlik ateşini kirlet!", k={b=2141550803, t=2384700613} }
V[13442] = { b="Bu Ateşi Kirlet!", t="İttifak'ın Sholazar Basin şenlik ateşini kirlet!", k={b=2141550803, t=2488652664} }
V[13443] = { b="Bu Ateşi Kirlet!", t="İttifak'ın Dragonblight şenlik ateşini kirlet!", k={b=2141550803, t=2751533212} }
V[13444] = { b="Bu Ateşi Kirlet!", t="İttifak'ın Howling Fjord şenlik ateşini kirlet!", k={b=2141550803, t=2060858292} }
V[13445] = { b="Bu Ateşi Kirlet!", t="İttifak'ın Grizzly Hills şenlik ateşini kirlet!", k={b=2141550803, t=444829950} }
V[13446] = { b="Bu Ateşi Kirlet!", t="İttifak'ın Storm Peaks şenlik ateşini kirlet!", k={b=2141550803, t=559428464} }
V[13447] = { b="Bu Ateşi Kirlet!", t="İttifak'ın Crystalsong Forest şenlik ateşini kirlet!", k={b=2141550803, t=2450598771} }
V[13448] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13449] = { b="Bu Ateşi Kirlet!", t="İttifak'ın Zul'Drak şenlik ateşini kirlet!", k={b=2141550803, t=1672024068} }
V[13450] = { b="Bu Ateşi Kirlet!", t="Horde'un Sholazar Basin şenlik ateşini kirlet!", k={b=2141550803, t=2451091505} }
V[13451] = { b="Bu Ateşi Kirlet!", t="Horde'un Dragonblight şenlik ateşini kirlet!", k={b=2141550803, t=537836085} }
V[13452] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13453] = { b="Bu Ateşi Kirlet!", t="Horde'un Howling Fjord şenlik ateşini kirlet!", k={b=2141550803, t=4142128461} }
V[13454] = { b="Bu Ateşi Kirlet!", t="Horde'un Grizzly Hills şenlik ateşini kirlet!", k={b=2141550803, t=2526100119} }
V[13455] = { b="Bu Ateşi Kirlet!", t="Horde'un Storm Peaks şenlik ateşini kirlet!", k={b=2141550803, t=2123145929} }
V[13456] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13457] = { b="Bu Ateşi Kirlet!", t="Horde'un Crystalsong Forest şenlik ateşini kirlet!", k={b=2141550803, t=989183148} }
V[13458] = { b="Bu Ateşi Kirlet!", t="Horde'un Zul'Drak şenlik ateşini kirlet!", k={b=2141550803, t=1414993405} }
V[13459] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13460] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13461] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13462] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13463] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13464] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13465] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13466] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13467] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13468] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13469] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13470] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13471] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13472] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13473] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13474] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13485] = { b="Aleve Saygı Göster", t="Borean Tundra alevine saygı göster.", k={b=427467665, t=160574294} }
V[13486] = { b="Aleve Saygı Göster", t="Sholazar Basin alevine saygı göster.", k={b=427467665, t=3093283298} }
V[13487] = { b="Aleve Saygı Göster", t="Dragonblight alevine saygı göster.", k={b=427467665, t=1842947270} }
V[13488] = { b="Aleve Saygı Göster", t="Howling Fjord alevine saygı göster.", k={b=427467665, t=509256158} }
V[13489] = { b="Aleve Saygı Göster", t="Grizzly Hills alevine saygı göster.", k={b=427467665, t=1738286248} }
V[13490] = { b="Aleve Saygı Göster", t="Storm Peaks alevine saygı göster.", k={b=427467665, t=1700100122} }
V[13491] = { b="Aleve Saygı Göster", t="Crystalsong Forest alevine saygı göster.", k={b=427467665, t=2120447005} }
V[13492] = { b="Aleve Saygı Göster", t="Zul'Drak alevine saygı göster.", k={b=427467665, t=3936107502} }
V[13493] = { b="Aleve Saygı Göster", t="Borean Tundra alevine saygı göster.", k={b=427467665, t=160574294} }
V[13494] = { b="Aleve Saygı Göster", t="Sholazar Basin alevine saygı göster.", k={b=427467665, t=3093283298} }
