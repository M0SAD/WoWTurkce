-- Healium (şifacı çerçeveleri) arayüz çevirisi
local G = WoWTurkce
local A = G.Arayuz
local function e(k, v) if A[k] == nil then A[k] = v end end
local H = "|cFF55AAFFHealium|r"
-- Ayarlar paneli
e("Button Profiles", "Düğme Profilleri")
e("Healium Button Profiles", "Healium Düğme Profilleri")
e("Button profiles are saved copies of your Healium button setup. They can be reused by this character and by other characters of the same class. Button profiles do not include frame positions, visibility, or scale. To update one, select it and click Overwrite Button Profile.", "Düğme profilleri, Healium düğme düzeninin kaydedilmiş kopyalarıdır. Bu karakter ve aynı sınıftaki diğer karakterler tarafından tekrar kullanılabilir. Düğme profilleri çerçeve konumlarını, görünürlüğü veya ölçeği içermez. Birini güncellemek için seçip Düğme Profilinin Üzerine Yaz'a tıkla.")
e("No saved button profiles for this class.", "Bu sınıf için kayıtlı düğme profili yok.")
e("Add New Button Profile...", "Yeni Düğme Profili Ekle...")
e("Overwrite Button Profile", "Düğme Profilinin Üzerine Yaz")
e("Load Button Profile", "Düğme Profilini Yükle")
e("Rename Button Profile", "Düğme Profilini Yeniden Adlandır")
e("Delete Button Profile", "Düğme Profilini Sil")
e("Frame Layouts", "Çerçeve Düzenleri")
e("Healium Frame Layouts", "Healium Çerçeve Düzenleri")
e("Frame layouts save the positions and visibility of all Healium frames plus their overall scale. Saved frame layouts are available for use on any of your characters and do not change your button setup. To update one, select it and click Overwrite Frame Layout. Layouts can only be loaded outside combat.", "Çerçeve düzenleri tüm Healium çerçevelerinin konumlarını, görünürlüğünü ve genel ölçeğini kaydeder. Kayıtlı düzenler tüm karakterlerinde kullanılabilir ve düğme düzenini değiştirmez. Birini güncellemek için seçip Çerçeve Düzeninin Üzerine Yaz'a tıkla. Düzenler yalnızca savaş dışında yüklenebilir.")
e("No saved frame layouts.", "Kayıtlı çerçeve düzeni yok.")
e("Add New Frame Layout...", "Yeni Çerçeve Düzeni Ekle...")
e("Overwrite Frame Layout", "Çerçeve Düzeninin Üzerine Yaz")
e("Load Frame Layout", "Çerçeve Düzenini Yükle")
e("Rename Frame Layout", "Çerçeve Düzenini Yeniden Adlandır")
e("Delete Frame Layout", "Çerçeve Düzenini Sil")
e("Overwrite", "Üzerine Yaz")
e("Name the new button profile:", "Yeni düğme profiline ad ver:")
e("Rename the selected button profile:", "Seçili düğme profilini yeniden adlandır:")
e("Name the new frame layout:", "Yeni çerçeve düzenine ad ver:")
e("Rename the selected frame layout:", "Seçili çerçeve düzenini yeniden adlandır:")
e("Default", "Varsayılan")
e("Tank-Healer-DPS", "Tank-Şifacı-DPS")
e("No Spell", "Büyü Yok")
e("Show Button ToolTips", "Düğme İpuçlarını Göster")
e("Shows spell tooltips when hovering the mouse over the " .. H .. " buttons.", H .. " düğmelerinin üzerine gelince büyü ipuçlarını gösterir.")
e("Shows the unit's mana.", "Birimin manasını gösterir.")
e("Show Mana", "Manayı Göster")
e("Shows the unit's health as a percentage on the right side of the health bar.", "Birimin canını can çubuğunun sağında yüzde olarak gösterir.")
e("Show Health Percentage", "Can Yüzdesini Göster")
e("Colors the healthbar based on the unit's class instead of green/yellow/red based on it's current health.", "Can çubuğunu, mevcut cana göre yeşil/sarı/kırmızı yerine birimin sınıf rengine boyar.")
e("Use Class Colors", "Sınıf Renklerini Kullan")
e("Displays a solid dark background behind the healthbar, making missing health and player names easier to see.", "Can çubuğunun arkasına koyu, düz bir arka plan koyar; eksik can ve oyuncu adları daha kolay görünür.")
e("Opaque Healthbar Background", "Opak Can Çubuğu Arka Planı")
e("Hides the X (close) button on the upper-right of the " .. H .. " caption bar.", H .. " başlık çubuğunun sağ üstündeki X (kapat) düğmesini gizler.")
e("Hide Close Buttons", "Kapat Düğmelerini Gizle")
e("Automatically hides the caption bar of " .. H .. " frames when the mouse leaves the caption.", "Fare başlıktan ayrılınca " .. H .. " çerçevelerinin başlık çubuğunu otomatik gizler.")
e("Hide Captions", "Başlıkları Gizle")
e("Prevents dragging of any " .. H .. " frames.", H .. " çerçevelerinin sürüklenmesini engeller.")
e("Lock Frame Positions", "Çerçeve Konumlarını Kilitle")
e("Allows use of the Clique addon on the healthbar.  Clique will override the ability to LeftClick to target the unit unless you configure Clique to do that, which it can.", "Can çubuğunda Clique eklentisinin kullanılmasını sağlar. Clique'i öyle ayarlamadıkça sol tıkla birimi hedefleme özelliğini Clique devralır (bunu ayarlayabilirsin).")
e("Enable Clique Support", "Clique Desteğini Aç")
e("Shows a threat indicator that displays if the unit has threat on any mob.", "Birimin herhangi bir yaratıkta tehdidi olup olmadığını gösteren bir tehdit göstergesi gösterir.")
e("Show Threat", "Tehdidi Göster")
e("Shows unit's role icon (healer, tank, damage) when in random dungeons.  Will override Health Percentage text when unit is assigned a role.", "Rastgele zindanlarda birimin rol simgesini (şifacı, tank, hasar) gösterir. Birime rol atandığında Can Yüzdesi yazısının yerini alır.")
e("Show Role Icons", "Rol Simgelerini Göster")
e("Shows incoming heals as a dark green bar extending from the unit's current health.", "Gelen iyileştirmeleri, birimin mevcut canından uzanan koyu yeşil bir çubuk olarak gösterir.")
e("Show Incoming Heals", "Gelen İyileştirmeleri Göster")
e("Shows the raid icon assigned to this unit.", "Bu birime atanan raid simgesini gösterir.")
e("Show Raid Icons", "Raid Simgelerini Göster")
e("Shows names in UPPERCASE text.", "Adları BÜYÜK HARFLE gösterir.")
e("UPPERCASE names", "BÜYÜK HARFLİ adlar")
e("Shows the Minimap button", "Minimap düğmesini gösterir")
e("Show Minimap button", "Minimap düğmesini göster")
e("Party Frame Order", "Grup Çerçevesi Sırası")
e("Controls ordering only in the Party frame.", "Yalnızca Grup çerçevesindeki sıralamayı belirler.")
e("Button Configuration", "Düğme Yapılandırması")
e("Dropdown selections use the highest learned rank.|nTo assign a lower rank, drag it from your spellbook onto a Healium button.|nIf lower ranks are hidden, type |cFFFFFFFF/console ShowAllSpellRanks 1|r|nand then reopen your spellbook. Buffs can be dragged too!", "Açılır menü seçimleri öğrenilmiş en yüksek rütbeyi kullanır.|nDaha düşük bir rütbe atamak için büyü kitabından bir Healium düğmesine sürükle.|nDüşük rütbeler gizliyse |cFFFFFFFF/console ShowAllSpellRanks 1|r yaz|nve büyü kitabını yeniden aç. Bufflar da sürüklenebilir!")
e("Click the dropdowns to configure each button.|nYou may now drag and drop directly from the spellbook|nonto buttons to configure them, including buffs!", "Her düğmeyi yapılandırmak için açılır menülere tıkla.|nArtık büyü kitabından doğrudan düğmelere sürükleyip|nbırakarak da (bufflar dahil) yapılandırabilirsin!")
e("How many " .. H .. " buttons to show.", "Kaç " .. H .. " düğmesi gösterileceği.")
e("Small", "Küçük")
e("Large", "Büyük")
e("Sets the scale of all " .. H .. " frames.", "Tüm " .. H .. " çerçevelerinin ölçeğini ayarlar.")
e("Show Frames", "Çerçeveleri Göster")
e("Check each frame to show.", "Gösterilecek her çerçeveyi işaretle.")
e("Party", "Grup")
e("Pets", "Petler")
e("Me", "Ben")
e("Friends", "Arkadaşlar")
e("Target", "Hedef")
e("Focus", "Odak")
e("Damagers", "Hasarcılar")
e("Healers", "Şifacılar")
e("Tanks", "Tanklar")
for i = 1, 8 do e("Group " .. i, "Grup " .. i) end
e("Debuff Warnings", "Debuff Uyarıları")
e("Debuff warnings are visual indicators that|nnotify you when you can cure a debuff on a player.", "Debuff uyarıları, bir oyuncudaki debuffı temizleyebileceğin|nzaman seni haberdar eden görsel göstergelerdir.")
e("Enable Debuff Warnings", "Debuff Uyarılarını Aç")
e("Enables debuff warnings", "Debuff uyarılarını açar")
e("Healthbar Coloring", "Can Çubuğu Renklendirme")
e("Enables coloring of the healthbar of a player that has a debuff which you can cure", "Temizleyebileceğin bir debuffı olan oyuncunun can çubuğunu renklendirir")
e("Healthbar Highlight Warning", "Can Çubuğu Vurgu Uyarısı")
e("Enables highlighting of the healthbar of a player that has a debuff which you can cure", "Temizleyebileceğin bir debuffı olan oyuncunun can çubuğunu vurgular")
e("Button Highlight Warning", "Düğme Vurgu Uyarısı")
e("Enables highlighting of buttons which have been assigned a spell that can cure a debuff on a player", "Bir oyuncudaki debuffı temizleyebilecek büyü atanmış düğmeleri vurgular")
e("Show Debuff Icon", "Debuff Simgesini Göster")
e("Shows a Blizzard-managed debuff icon over each configured cure button that can remove it", "Debuffı kaldırabilecek her temizleme düğmesinin üzerinde Blizzard'ın yönettiği debuff simgesini gösterir")
e("CPU Intensive Settings", "İşlemciyi Yoran Ayarlar")
e("Enabling these settings may cause extra lag.", "Bu ayarları açmak ek gecikmeye yol açabilir.")
e("Enables cooldown animations on the " .. H .. " buttons.", H .. " düğmelerinde bekleme süresi animasyonlarını açar.")
e("Enable Cooldowns", "Bekleme Sürelerini Aç")
e("Enables range checks on the " .. H .. " buttons.", H .. " düğmelerinde menzil kontrolünü açar.")
e("Enable Range Checks", "Menzil Kontrolünü Aç")
e("Slower\n(Less CPU)", "Daha Yavaş\n(Az İşlemci)")
e("Faster\n(More CPU)", "Daha Hızlı\n(Çok İşlemci)")
e("Controls how often to do range checks.  The further to the right, the more often range checks are performed and the more CPU it will use.", "Menzil kontrolünün ne sıklıkla yapılacağını belirler. Sağa doğru gittikçe kontrol daha sık yapılır ve daha çok işlemci kullanılır.")
e("Shows the buffs and HOTs you have personally cast on the player to the left of the healthbar.  It will only show spells that are configured in " .. H .. ".", "Oyuncuya senin yaptığın buff ve HOT'ları can çubuğunun solunda gösterir. Yalnızca " .. H .. " içinde yapılandırılmış büyüleri gösterir.")
e("Show Buffs", "Buffları Göster")
e("About " .. H, H .. " Hakkında")
-- Menü
e("Set button count", "Düğme sayısını ayarla")
e("Configure Buttons", "Düğmeleri Yapılandır")
e("Show / Hide Frames", "Çerçeveleri Göster / Gizle")
e("Reset all frame positions", "Tüm çerçeve konumlarını sıfırla")
e("Close Menu", "Menüyü Kapat")
e("Toggle Frames", "Çerçeveleri Aç/Kapat")
e("Show Party", "Grubu Göster")
e("Show Me", "Beni Göster")
e("Show Pets", "Petleri Göster")
e("Show Friends", "Arkadaşları Göster")
e("Show Damagers", "Hasarcıları Göster")
e("Show Healers", "Şifacıları Göster")
e("Show Tanks", "Tankları Göster")
e("Show Target", "Hedefi Göster")
e("Show Focus", "Odağı Göster")
e("Hide All Raid Groups", "Tüm Raid Gruplarını Gizle")
e("Show Raid Groups 1 and 2 (10 man)", "Raid Grupları 1 ve 2'yi Göster (10 kişilik)")
e("Show Raid Groups 1-5 (25 man)", "Raid Grupları 1-5'i Göster (25 kişilik)")
e("Show Raid Groups 1-8 (40 man)", "Raid Grupları 1-8'i Göster (40 kişilik)")
-- Minimap düğmesi ve düğme ipuçları
e(H .. " |n|cFF55FF55Left Mouse |cFFFFFFFFHealium Menu|n|cFF55FF55Right Mouse |cFFFFFFFFMove Button|n|cFF55FF55Shift & Left Mouse |cFFFFFFFF Toggle Frames", H .. " |n|cFF55FF55Sol Tık |cFFFFFFFFHealium Menüsü|n|cFF55FF55Sağ Tık |cFFFFFFFFDüğmeyi Taşı|n|cFF55FF55Shift + Sol Tık |cFFFFFFFF Çerçeveleri Aç/Kapat")
e("|cFFFFFFFFNo Spell|n|cFF00FF00You may drag-and-drop a spell from your|nspellbook onto this button, or you may go|nto Game Menu, Interface, Addons, Healium and|nselect your spells from the list.", "|cFFFFFFFFBüyü Yok|n|cFF00FF00Büyü kitabından bu düğmeye bir büyü|nsürükleyip bırakabilir ya da|nOyun Menüsü > Arayüz > Eklentiler > Healium'a gidip|nlisteden büyülerini seçebilirsin.")
-- Sohbet mesajları
e("Enter a button profile name.", "Bir düğme profili adı gir.")
e("Button profiles cannot be loaded during combat.", "Düğme profilleri savaş sırasında yüklenemez.")
e("Party Frame Order will be applied when combat ends.", "Grup Çerçevesi Sırası savaş bitince uygulanacak.")
e("Enter a frame layout name.", "Bir çerçeve düzeni adı gir.")
e("Frame layouts cannot be loaded during combat.", "Çerçeve düzenleri savaş sırasında yüklenemez.")
e("Settings cannot be reset during combat.", "Ayarlar savaş sırasında sıfırlanamaz.")
e("All character settings reset to defaults.", "Tüm karakter ayarları varsayılana sıfırlandı.")
e("Character profiles reset to defaults.", "Karakter profilleri varsayılana sıfırlandı.")
e("No unit specified", "Birim belirtilmedi")
e("Friends cleared.", "Arkadaş listesi temizlendi.")
e("Can't configure buttons while in combat!", "Savaştayken düğmeler yapılandırılamaz!")
e("Can't insert more buttons! Max button count already reached!", "Daha fazla düğme eklenemez! En yüksek düğme sayısına ulaşıldı!")
e("Retail aura displays initialized.", "Aura göstergeleri hazırlandı.")
e("Failed to hide heal button", "İyileştirme düğmesi gizlenemedi")
e("Failed to show heal button", "İyileştirme düğmesi gösterilemedi")
e("Can't toggle frames while in combat.", "Savaştayken çerçeveler açılıp kapatılamaz.")
e("Current frames are now hidden.", "Mevcut çerçeveler artık gizli.")
e("Current frames are now shown.", "Mevcut çerçeveler artık görünüyor.")
e("Can't show or hide frames while in combat.", "Savaştayken çerçeveler gösterilip gizlenemez.")
e("Reset frame positions complete.", "Çerçeve konumları sıfırlandı.")
e("Can't update button while in combat", "Savaştayken düğme güncellenemez")
e("Healium Commands", "Healium Komutları")
-- Değişken içerikli yazılar (profil adları, sayılar, Healium adı)
local D = G.GlobalDesen
local function d(k, desen, tr) D[k] = D[k] or {}; table.insert(D[k], { desen, tr }) end
d("shows", "^Shows the (.-) |cFF55AAFFHealium|r frame%.$", "{1} " .. H .. " çerçevesini gösterir.")
d("welcome", "^Welcome to the |cFF55AAFFHealium|r options screen%.|nUse the scrollbar to access more options%.$", H .. " ayar ekranına hoş geldin.|nDaha fazla ayar için kaydırma çubuğunu kullan.")
d("replace", "^Replace '(.-)' with your current Healium button setup%?$", "'{1}' mevcut Healium düğme düzeninle değiştirilsin mi?")
d("load", "^Load '(.-)'%? This will replace your current specialization's Healium button setup%.$", "'{1}' yüklensin mi? Bu, mevcut uzmanlığının Healium düğme düzenini değiştirir.")
d("delete", "^Delete the saved button profile '(.-)'%? This will not change any character's Healium button setup%.$", "Kayıtlı '{1}' düğme profili silinsin mi? Bu, hiçbir karakterin Healium düğme düzenini değiştirmez.")
d("added", "^Added '(.-)' from your current Healium button setup%.$", "'{1}' mevcut Healium düğme düzeninden eklendi.")
d("listing", "^Listing Healium friends:$", "Healium arkadaşları listeleniyor:")
d("debug", "^Healium Debug is ON$", "Healium hata ayıklama AÇIK")
d("debug", "^Healium Debug is OFF$", "Healium hata ayıklama KAPALI")
d("replace", "^Replace '(.-)' with your current frame layout%?$", "'{1}' mevcut çerçeve düzeninle değiştirilsin mi?")
d("load", "^Load the frame layout '(.-)'%? This will change frame positions, visibility, and scale%.$", "'{1}' çerçeve düzeni yüklensin mi? Bu, çerçeve konumlarını, görünürlüğü ve ölçeği değiştirir.")
d("added", "^Added '(.-)' from your current frame layout%.$", "'{1}' mevcut çerçeve düzeninden eklendi.")
d("overwrote", "^Overwrote '(.-)'%.$", "'{1}' üzerine yazıldı.")
d("loaded", "^Loaded '(.-)' into your current specialization%.$", "'{1}' mevcut uzmanlığına yüklendi.")
d("loaded", "^Loaded '(.-)'%.$", "'{1}' yüklendi.")
d("renamed", "^Renamed '(.-)' to '(.-)'%.$", "'{1}' adı '{2}' olarak değiştirildi.")
d("deleted", "^Deleted '(.-)'%.$", "'{1}' silindi.")
d("already", "^A button profile named '(.-)' already exists%.$", "'{1}' adında bir düğme profili zaten var.")
d("already", "^A frame layout named '(.-)' already exists%.$", "'{1}' adında bir çerçeve düzeni zaten var.")
d("range", "^Range Check Frequency: |cFFFFFFFF(.-) Hz$", "Menzil Kontrol Sıklığı: |cFFFFFFFF{1} Hz")
d("buttons", "^Show |cFFFFFFFF(%d+)|r Buttons$", "|cFFFFFFFF{1}|r Düğme Göster")
d("scale", "^Scale: |cFFFFFFFF(.+)$", "Ölçek: |cFFFFFFFF{1}")
d("button", "^Button (%d+)$", "Düğme {1}")
d("target", "^Target: |cFF00FF00(.+)$", "Hedef: |cFF00FF00{1}")
d("macro", "^Macro: (.+)$", "Makro: {1}")
d("friend", "^Friend %((%d+)%) (.+)$", "Arkadaş ({1}) {2}")
d("created", "^|cFF55AAFFHealium|r(.-) |cFFFFFFFFCreated by Engee of Durotan%.|n|n|cFFFFFFFFOriginally based on FB Heal Box, which was created by Dourd of Argent Dawn EU%.$", H .. "{1} |cFFFFFFFFEngee (Durotan) tarafından yapıldı.|n|n|cFFFFFFFFİlk hâli, Dourd (Argent Dawn EU) tarafından yapılan FB Heal Box'a dayanır.")
-- Sohbete yazdığı mesajlar
local function cevir(m)
	if type(m) ~= "string" then return m end
	return A[m] or G.globalDesenCevir(m) or m
end
local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function(self)
	self:UnregisterAllEvents()
	if type(_G.Healium_Print) == "function" then
		_G.Healium_Print = function(msg) DEFAULT_CHAT_FRAME:AddMessage(H .. " " .. tostring(cevir(msg))) end
	end
	if type(_G.Healium_Warn) == "function" then
		_G.Healium_Warn = function(msg) DEFAULT_CHAT_FRAME:AddMessage("|CFFFF0000Uyarı|r: " .. tostring(cevir(msg))) end
	end
end)
e("A healing user-interface addon that provides up to 15 customizable buttons next to each party or raid members name.  Based on FB Healbox.", "Her grup veya raid üyesinin adının yanında 15'e kadar özelleştirilebilir düğme sunan bir iyileştirme arayüzü eklentisi. FB Healbox'a dayanır.")
e("A healing user-interface addon that provides up to 15 customizable buttons next to each party or raid members name. Based on FB Healbox.", "Her grup veya raid üyesinin adının yanında 15'e kadar özelleştirilebilir düğme sunan bir iyileştirme arayüzü eklentisi. FB Healbox'a dayanır.")
-- Healium çerçevelerinde genel çeviriden farklı olanlar
G.EkOzel["^Healium"] = { ["Pets"] = "Petler" }
for k in pairs(G.EkOzel["^Healium"]) do G.EkOzelMetin[k] = true end
table.insert(G.GlobalDesen["shows"], 1, { "^Shows the Pets |cFF55AAFFHealium|r frame%.$", "Petler " .. H .. " çerçevesini gösterir." })
-- Çerçeve başlıkları bir kez, giriş sırasında yazılıyor; genel tarayıcı bazen kaçırıyordu. Doğrudan çevir.
local BASLIK = { Party = "Grup", Pets = "Petler", Me = "Ben", Friends = "Arkadaşlar", Damagers = "Hasarcılar", Healers = "Şifacılar", Tanks = "Tanklar", Target = "Hedef", Focus = "Odak" }
for i = 1, 8 do BASLIK["Group " .. i] = "Grup " .. i end
local CERCEVE = { "Party", "Pet", "Me", "Friends", "Damagers", "Healers", "Tanks", "Target", "Focus" }
for i = 1, 8 do CERCEVE[#CERCEVE + 1] = "Group" .. i end
local function basliklar()
	if not G.modul("arayuz") then return end
	for _, ad in ipairs(CERCEVE) do
		local uf = _G["Healium" .. ad .. "Frame"]
		local fs = uf and uf.CaptionBar and uf.CaptionBar.Caption
		local t = fs and fs:GetText()
		if t and BASLIK[t] then fs:SetText(BASLIK[t]) end
	end
end
local bf = CreateFrame("Frame")
bf:RegisterEvent("PLAYER_ENTERING_WORLD")
bf:RegisterEvent("GROUP_ROSTER_UPDATE")
bf:SetScript("OnEvent", function()
	basliklar(); C_Timer.After(1, basliklar); C_Timer.After(5, basliklar)
end)
-- Buff/debuff simgelerinin ipucu (Blizzard'ın aura kapları doğrudan dolduruyor, olağan kancalar çalışmıyor)
do
	local function healiumda(tt)
		local o = tt.GetOwner and tt:GetOwner()
		local n = 0
		while o and n < 8 do
			local ad = o.GetName and o:GetName()
			if ad and ad:find("^Healium") then return true end
			o = o.GetParent and o:GetParent(); n = n + 1
		end
	end
	local gecen = 0
	local TUR = { Magic = 1, Curse = 1, Poison = 1, Disease = 1, ["Büyü"] = 1, ["Lanet"] = 1, ["Zehir"] = 1, ["Hastalık"] = 1 }
	-- Sahibi bilinmeyen aura ipucu: sağ üstte büyü türü ya da "... remaining" satırı
	local function auraGibi(tt)
		local ad = tt.GetName and tt:GetName()
		if not ad then return false end
		local r = _G[ad .. "TextRight1"]
		local rt = r and r:IsShown() and r:GetText()
		if rt and TUR[rt] then return true end
		local n = tt:NumLines() or 0
		for i = 2, math.min(n, 6) do
			local l = _G[ad .. "TextLeft" .. i]
			local t = l and l:GetText()
			if type(t) == "string" and t:find(" remaining$") then return true end
		end
		return false
	end
	local function cevirIpucu(tt)
		if not G.ipucuCevir then return end
		local o = tt.GetOwner and tt:GetOwner()
		local okH, h = pcall(healiumda, tt)
		local okA, ag = pcall(auraGibi, tt)
		local okO, ob = pcall(function() return o and (o.auraInstanceID or o.auraType or o.unit or o.unitToken) end)
		if not ((okH and h) or (okO and ob) or (okA and ag)) then return end
		G._healiumAuraSon = ("healium=%s owner=%s icerik=%s"):format(tostring(okH and h), tostring(okO and ob ~= nil), tostring(okA and ag))

		if G.auraIpucuIsaretle then G.auraIpucuIsaretle(tt) end
		pcall(G.ipucuCevir, tt)
	end
	GameTooltip:HookScript("OnShow", cevirIpucu)
	GameTooltip:HookScript("OnUpdate", function(tt, e)
		gecen = gecen + e
		if gecen < 0.2 then return end
		gecen = 0
		cevirIpucu(tt)
	end)
end
-- Boş düğme ipucu: oyun |n'leri satır sonuna çevirip satır satır işliyor
do
	local en = "|cFFFFFFFFNo Spell|n|cFF00FF00You may drag-and-drop a spell from your|nspellbook onto this button, or you may go|nto Game Menu, Interface, Addons, Healium and|nselect your spells from the list."
	local tr = A[en]
	e(en:gsub("|n", "\n"), tr:gsub("|n", "\n"))
	local satirlar = {
		{ "You may drag-and-drop a spell from your", "Büyü kitabından bu düğmeye bir büyü" },
		{ "spellbook onto this button, or you may go", "sürükleyip bırakabilir ya da" },
		{ "to Game Menu, Interface, Addons, Healium and", "Oyun Menüsü > Arayüz > Eklentiler > Healium'a gidip" },
		{ "to Oyun Menüsü, Interface, Addons, Healium and", "Oyun Menüsü > Arayüz > Eklentiler > Healium'a gidip" },
		{ "select your spells from the list.", "listeden büyülerini seçebilirsin." },
	}
	for _, s in ipairs(satirlar) do e(s[1], s[2]); e("|cFF00FF00" .. s[1], "|cFF00FF00" .. s[2]) end
	e("|cFFFFFFFFNo Spell", "|cFFFFFFFFBüyü Yok")
end

-- Blizzard aura kaplarının kendi ipucu penceresi: fare bir Healium simgesindeyken açık ipucu pencerelerini bulup çevir
do
	local bilinen, sonTarama, gecen = {}, 0, 0
	local function healiumAlti(f)
		local n = 0
		while f and n < 10 do
			local ad = f.GetName and f:GetName()
			if ad and ad:find("^Healium") then return true end
			f = f.GetParent and f:GetParent(); n = n + 1
		end
	end
	local function fareAlti()
		if GetMouseFoci then local t = GetMouseFoci(); return t and t[1] end
		if GetMouseFocus then return GetMouseFocus() end
	end
	local function metinCevir(t, ilk)
		if type(t) ~= "string" or t == "" or G.turkceMi(t) then return nil end
		if ilk and G.BuyuAdi and G.BuyuAdi[t] then
			local ok, y = pcall(G.adStil, "stilBuyu", G.BuyuAdi[t], t)
			return ok and y or G.BuyuAdi[t]
		end
		local d, s = t:match("^(%d+) (%a+) remaining$")
		if d then
			local B = { minute = "dk", minutes = "dk", second = "sn", seconds = "sn", hour = "sa", hours = "sa", day = "gün", days = "gün", min = "dk", sec = "sn", hr = "sa" }
			if B[s] then return d .. " " .. B[s] .. " kaldı" end
		end
		return (G.Buyu and G.cevir(G.Buyu, t)) or (G.Esya and G.cevir(G.Esya, t)) or G.cevir(G.Arayuz, t)
	end
	local function pencereCevir(tt)
		if tt.GetName and tt:GetName() and G.ipucuCevir then
			if G.auraIpucuIsaretle then G.auraIpucuIsaretle(tt) end
			pcall(G.ipucuCevir, tt)
			return
		end
		local yazilar = {}
		for _, r in ipairs({ tt:GetRegions() }) do
			if r.GetObjectType and r:GetObjectType() == "FontString" and r:IsShown() and r:GetText() then yazilar[#yazilar + 1] = r end
		end
		table.sort(yazilar, function(a, b) return (a:GetTop() or 0) > (b:GetTop() or 0) end)
		for i, r in ipairs(yazilar) do
			local ok, tr = pcall(metinCevir, r:GetText(), i == 1)
			if ok and type(tr) == "string" and tr ~= r:GetText() then r:SetText(tr) end
		end
	end
	local f = CreateFrame("Frame")
	f:SetScript("OnUpdate", function(_, e)
		gecen = gecen + e
		if gecen < 0.15 then return end
		gecen = 0
		if not G.modul("buyu") then return end
		local m = fareAlti()
		-- Geçici tanı: fare altındaki çerçeve ve açık ipucu pencereleri
		if m and WoWTurkce_Ayar and not WoWTurkce_Ayar._auraTani4 and GameTooltip:IsShown() then
			local okT, metin = pcall(function()
				local par = {}
				local x, k = m, 0
				while x and k < 6 do
					local okn, nm = pcall(function() return x.GetDebugName and x:GetDebugName() or x:GetName() end)
					par[#par + 1] = tostring(okn and nm or "?") .. ":" .. tostring(x.GetObjectType and x:GetObjectType())
					x = x.GetParent and x:GetParent(); k = k + 1
				end
				local o = GameTooltip:GetOwner()
				local on = o and (o.GetDebugName and o:GetDebugName() or o:GetName()) or "nil"
				local l1 = GameTooltipTextLeft1:GetText()
				local gz = G.gizli and G.gizli(l1)
				return table.concat(par, " > ") .. " || sahip=" .. tostring(on) .. " satir=" .. tostring(GameTooltip:NumLines()) .. " gizli=" .. tostring(gz) .. " l1=" .. tostring(not gz and l1)
			end)
			local mesaj = okT and metin or ("hata: " .. tostring(metin))
			if mesaj:find("Healium") or mesaj:find("Aura") then WoWTurkce_Ayar._auraTani4 = mesaj end
		end
		if not m or not healiumAlti(m) then return end
		local acik = false
		for tt in pairs(bilinen) do
			if tt:IsShown() then acik = true; pencereCevir(tt) end
		end
		if acik or GetTime() - sonTarama < 2 or not EnumerateFrames then return end
		sonTarama = GetTime()
		local x = EnumerateFrames()
		while x do
			if x ~= GameTooltip and x.GetObjectType and x:GetObjectType() == "GameTooltip" and x:IsShown() and not (x.IsForbidden and x:IsForbidden()) then
				bilinen[x] = true
				WoWTurkce_Ayar = WoWTurkce_Ayar or {}
				WoWTurkce_Ayar._auraTani3 = WoWTurkce_Ayar._auraTani3 or {}
				local n = x.GetDebugName and x:GetDebugName() or tostring(x:GetName())
				if #WoWTurkce_Ayar._auraTani3 < 10 then table.insert(WoWTurkce_Ayar._auraTani3, n) end
				pencereCevir(x)
			end
			x = EnumerateFrames(x)
		end
	end)
end
-- Geçici tanı: "remaining" satırı olan her ipucunun hangi pencereden geldiğini kaydet
do
	local function tani(tt, kaynak)
		if not WoWTurkce_Ayar or not tt or not tt.GetName then return end
		local ad = tt:GetName()
		if not ad then return end
		local n = tt:NumLines() or 0
		local var
		for i = 1, math.min(n, 6) do
			local l = _G[ad .. "TextLeft" .. i]; local t = l and l:GetText()
			if type(t) == "string" and (t:find("remaining") or t:find("kaldı")) then var = true end
		end
		if not var then return end
		local o = tt.GetOwner and tt:GetOwner()
		local on = o and (o.GetDebugName and o:GetDebugName() or (o.GetName and o:GetName())) or "?"
		local l1 = _G[ad .. "TextLeft1"]
		WoWTurkce_Ayar._auraTani2 = WoWTurkce_Ayar._auraTani2 or {}
		local tt2 = WoWTurkce_Ayar._auraTani2
		if #tt2 < 15 then tt2[#tt2 + 1] = kaynak .. " | " .. ad .. " | " .. tostring(on) .. " | " .. tostring(l1 and l1:GetText()) end
	end
	GameTooltip:HookScript("OnShow", function(tt) tani(tt, "show") end)
	if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and TooltipDataProcessor.AllTypes then
		TooltipDataProcessor.AddTooltipPostCall(TooltipDataProcessor.AllTypes, function(tt, d) tani(tt, "veri" .. tostring(d and d.type)) end)
	end
end
-- Menü
e("Healium Config Panel", "Healium Ayar Paneli")
e("|cFF55AAFFHealium|r Menu", "|cFF55AAFFHealium|r Menüsü")
e("Rotate Buttons Left", "Düğmeleri Sola Kaydır")
e("Rotate Buttons Right", "Düğmeleri Sağa Kaydır")
