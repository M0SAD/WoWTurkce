-- Büyü çubuğu (cast bar): büyü adı oyun yazar yazmaz, aynı karede Türkçeye çevrilir.
-- Böylece önce İngilizce adın görünüp sonra değişmesi (titreme) olmaz.
local G = WoWTurkce

local CUBUKLAR = { "CastingBarFrame", "PlayerCastingBarFrame", "PetCastingBarFrame", "TargetFrameSpellBar", "FocusFrameSpellBar", "OverlayPlayerCastingBarFrame", "PlayerCastingBar" }

local function yaziAlani(f)
	local ad = f:GetName()
	return f.Text or f.text or (ad and _G[ad .. "Text"])
end

-- Çubuğun durum yazıları (büyü başarısız olunca ya da kesilince)
local DURUM = { ["Failed"] = "Başarısız", ["Interrupted"] = "Kesildi", ["Canceled"] = "İptal edildi",
	["Cancelled"] = "İptal edildi",
	["Skinning"] = "Deri Yüzme", ["Mining"] = "Madencilik", ["Herb Gathering"] = "Ot Toplama", ["Opening"] = "Açılıyor",
	["Fishing"] = "Balık Tutma", ["Disenchanting"] = "Büyü Bozma", ["Prospecting"] = "Maden Arama", ["Milling"] = "Öğütme",
	["Picking Lock"] = "Kilit Açılıyor", ["Opening - No Text"] = "Açılıyor", ["Gathering"] = "Toplama", ["Channeling"] = "Kanalize ediliyor", ["Failed attempt"] = "Başarısız deneme" }

local function cevirAd(t)
	if not t or t == "" or G.gizli(t) or G.turkceMi(t) then return nil end
	if DURUM[t] then return DURUM[t] end
	local tr = (G.BuyuAdi and G.BuyuAdi[t]) or (G.buyuAdiCevir and G.buyuAdiCevir(t))
	local eg
	if not tr then
		local e = (G.EsyaAdi and G.EsyaAdi[t]) or (G.Esya and G.Esya[t])
		if type(e) == "string" then tr = e; eg = true end
	end
	if not tr or tr == t then return nil end
	-- Çubukta yalnızca Türkçe ad gösterilir
	return tr
end

local kur
local function hepsiniTara()
	for ad, f in pairs(_G) do
		if type(ad) == "string" and type(f) == "table" and (ad:find("CastingBar") or ad:find("SpellBar")) and f.GetObjectType and f.IsForbidden and not f:IsForbidden() then pcall(kur, f) end
	end
end

kur = function(f)
	if not f or f._gtrCubuk then return end
	local fs = yaziAlani(f)
	if not fs or not fs.SetText then return end
	f._gtrCubuk = true
	local yaziyor = false
	local function duzelt()
		if yaziyor or not G.ayar("acik") or not G.modul("buyuadi") then return end
		local tr = cevirAd(fs:GetText())
		if tr then yaziyor = true; fs:SetText(tr); yaziyor = false end
	end
	f._gtrDuzelt = duzelt
	-- Oyun adı SetText ile yazdığı anda (çizimden önce) değiştir
	hooksecurefunc(fs, "SetText", function() pcall(duzelt) end)
	if f.HookScript then f:HookScript("OnEvent", function() pcall(duzelt) end) end
	if f.HookScript then f:HookScript("OnShow", function() pcall(duzelt) end) end
end

G.basla(function()
	for _, ad in ipairs(CUBUKLAR) do pcall(kur, _G[ad]) end
	C_Timer.NewTicker(0.25, function()
		for _, ad in ipairs(CUBUKLAR) do
			local f = _G[ad]
			if f and f.IsShown and f:IsShown() and f._gtrDuzelt then pcall(f._gtrDuzelt) end
		end
	end)
	pcall(hepsiniTara)
	C_Timer.After(3, function() pcall(hepsiniTara) end)
	-- İsim levhası büyü çubukları ve sonradan yüklenen çerçeveler
	local f = CreateFrame("Frame")
	f:RegisterEvent("ADDON_LOADED")
	f:RegisterEvent("NAME_PLATE_UNIT_ADDED")
	f:SetScript("OnEvent", function(_, olay, birim)
		for _, ad in ipairs(CUBUKLAR) do pcall(kur, _G[ad]) end
		if olay == "NAME_PLATE_UNIT_ADDED" and C_NamePlate and C_NamePlate.GetNamePlateForUnit then
			local p = C_NamePlate.GetNamePlateForUnit(birim)
			local uf = p and p.UnitFrame
			local cb = uf and (uf.castBar or uf.CastBar)
			if cb and not (cb.IsForbidden and cb:IsForbidden()) then pcall(kur, cb) end
		end
	end)
end)
