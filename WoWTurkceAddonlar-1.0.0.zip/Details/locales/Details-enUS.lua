local L = LibStub("AceLocale-3.0"):NewLocale ("Details", "enUS", true) 
if not L then return end 

--------------------------------------------------------------------------------------------------------------------------------------------
L = L or {}

L["STRING_OPTIONS_WINDOW_SCALE_DESC"] = [=[Pencerenin ölçeğini ayarla.

|cFFFFFF00İpucu|r: değeri yazmak için sağ tıkla.]=]
L["STRING_OPTIONS_TOTALBAR_ANCHOR"] = "Toplam Çubuğu"
L["STRING_OPTIONS_DESIGNER_WHICH_BUTTONS"] = "Gösterilen düğmeler"
L["STRING_OPTIONS_DESIGNER_NAME_SIZE_OFFSET"] = "Birim Adı Boyut Farkı"
L["STRING_OPTIONS_DESIGNER_SHOW_FACTION_ICON"] = "Fraksiyon Simgesini Göster"
L["STRING_OPTIONS_DESIGNER_SHOW_FACTION_ICON_DESC"] = "Karşı fraksiyondan bir oyuncu gösterilirken fraksiyon simgesini göster."
L["STRING_OPTIONS_DESIGNER_FACTION_ICON_SIZE_OFFSET"] = "Fraksiyon Simgesi Boyut Farkı"
L["STRING_OPTIONS_DESIGNER_NO_SEPARATOR"] = "ayırıcı yok"
L["STRING_OPTIONS_DESIGNER_NO_BRACKET"] = "parantez yok"
L["STRING_OPTIONS_DESIGNER_OBJECT_BARNAMETEXT"] = "Çubuk Birim Adı"
L["STRING_OPTIONS_DESIGNER_OBJECT_BARVALUETEXT"] = "Çubuk Değerleri"
L["STRING_OPTIONS_DESIGNER_TITLEBAR_ENABLED_DESC"] = "Görünüm dosyasındaki yerleşik başlık çubuğu yerine alternatif bir başlık çubuğu kullan.\n\n|cFFFFFF00Önemli|r: Görünüm dosyasındaki başlık çubuğunu kapatmak için 'Pencere'ye git ve 'görünüm rengi'ni tamamen saydam yap."
L["STRING_OPTIONS_DESIGNER_NAME_TEXT_COLOR_DESC"] = [=[Birim adının yazı rengini değiştir.

|cFFFFFFFFsınıfa göre renk|r açıksa yok sayılır.]=]
L["STRING_OPTIONS_DESIGNER_VALUE_TEXT_COLOR_DESC"] = [=[Değer sütunlarının yazı rengini değiştir.

|cFFFFFFFFsınıfa göre renk|r açıksa yok sayılır.]=]
L["STRING_OPTIONS_DESIGNER_NAME_SIZE_OFFSET_DESC"] = "Birim adına, değer sütunları tarafından kesilmeden önce daha fazla ya da daha az yer ver."
L["STRING_OPTIONS_DESIGNER_OVERLAY"] = "Kaplama"
L["STRING_OPTIONS_DESIGNER_OVERLAY_TEXTURE_DESC"] = "Çubuğun üzerinde duran doku"
L["STRING_OPTIONS_DESIGNER_ARENA_TEAM_COLOR"] = "Arena Takım Rengi"
L["STRING_OPTIONS_DESIGNER_SHOW_ARENA_ROLE_ICON"] = "Arena Rol Simgesini Göster"
L["STRING_OPTIONS_DESIGNER_ARENA_ROLE_ICON_SIZE_OFFSET"] = "Arena Rol Simgesi Boyut Farkı"
L["STRING_OPTIONS_DESIGNER_REMOVE_CUSTOM_TEXTURE"] = "Özel Dokuyu Kaldır"
L["STRING_OPTIONS_DESIGNER_ICON_SET"] = "Simge Seti"

L["STRING_OPTIONSMENU_DESIGNER"] = "Tasarımcı"
L["STRING_OPTIONS_DESIGNER_PREVIEW"] = "Önizleme"
L["STRING_OPTIONS_DESIGNER_HINT"] = "Düzenlemek için önizlemenin bir parçasına tıkla. Değişiklikler sağ üstte seçili pencereye uygulanır."
L["STRING_OPTIONS_DESIGNER_PREVIEW_MISSING"] = "Önizleme penceresi oluşturulamadı, burada düzenlenecek bir şey yok."
L["STRING_OPTIONS_DESIGNER_OBJECT_WINDOW"] = "Pencere"
L["STRING_OPTIONS_DESIGNER_OBJECT_TITLETEXT"] = "Başlık Yazısı"
L["STRING_OPTIONS_DESIGNER_OBJECT_BARS"] = "Çubuklar"
L["STRING_OPTIONS_DESIGNER_OBJECT_BARICONS"] = "Çubuk Simgeleri"
L["STRING_OPTIONS_DESIGNER_OBJECT_STATUSBAR"] = "Durum Çubuğu"
L["STRING_OPTIONS_DESIGNER_ROW_AREA_ALPHA"] = "Satır Alanı Opaklığı"
L["STRING_OPTIONS_DESIGNER_ROUNDED_CORNERS"] = "Yuvarlak Köşeler"
L["STRING_OPTIONS_DESIGNER_SHOW_WINDOW_BORDER"] = "Kenarlığı\nGöster"
L["STRING_OPTIONS_DESIGNER_BORDER_COLOR"] = "Kenarlık Rengi"
L["STRING_OPTIONS_DESIGNER_BORDER_THICKNESS"] = "Kenarlık Kalınlığı"
L["STRING_OPTIONS_DESIGNER_TITLEBAR_ENABLED"] = "Özel Başlık Çubuğu"
L["STRING_OPTIONS_DESIGNER_TITLEBAR_HEIGHT"] = "Yükseklik"
L["STRING_OPTIONS_DESIGNER_DESATURATED_MENU"] = "Soluk Düğmeler"
L["STRING_OPTIONS_DESIGNER_MENU_ICON_SIZE"] = "Düğme Boyutu"
L["STRING_OPTIONS_DESIGNER_MENU_ICON_SPACING"] = "Düğme Aralığı"
L["STRING_OPTIONS_DESIGNER_SHOW_ENCOUNTER_TIMER"] = "Karşılaşma Sayacını Göster"
L["STRING_OPTIONS_DESIGNER_BUTTON_MODE"] = "Mod"
L["STRING_OPTIONS_DESIGNER_TITLE_TEXT_ENABLED"] = "Başlık Yazısını Göster"
L["STRING_OPTIONS_DESIGNER_TEXT_X_OFFSET"] = "Yatay Kaydırma"
L["STRING_OPTIONS_DESIGNER_TEXT_Y_OFFSET"] = "Dikey Kaydırma"
L["STRING_OPTIONS_DESIGNER_COLOR_BY_CLASS"] = "Sınıfa Göre Renk"
L["STRING_OPTIONS_DESIGNER_BAR_ALPHA"] = "Opaklık"
L["STRING_OPTIONS_DESIGNER_BACKGROUND_BY_CLASS"] = "Sınıfa Göre Arka Plan"
L["STRING_OPTIONS_DESIGNER_BAR_BORDER"] = "Çubuk Kenarlığını Göster"
L["STRING_OPTIONS_DESIGNER_NAME_OFFSET"] = "Ad Kaydırması"
L["STRING_OPTIONS_DESIGNER_SHOW_RANK_NUMBER"] = "Sıra Numarasını Göster"
L["STRING_OPTIONS_DESIGNER_PERCENT_TYPE"] = "Yüzde Türü"
L["STRING_OPTIONS_DESIGNER_PERCENT_OF_TOTAL"] = "Toplama Göre"
L["STRING_OPTIONS_DESIGNER_PERCENT_OF_TOP"] = "En İyi Oyuncuya Göre"
L["STRING_OPTIONS_DESIGNER_TEXT_OUTLINE"] = "Anahat"
L["STRING_OPTIONS_DESIGNER_SHADOW_OFFSET_X"] = "Gölge Kaydırması X"
L["STRING_OPTIONS_DESIGNER_SHADOW_OFFSET_Y"] = "Gölge Kaydırması Y"
L["STRING_OPTIONS_DESIGNER_ALIGN_COLUMNS"] = "Değer Sütunlarını Hizala"
L["STRING_OPTIONS_DESIGNER_ALIGN_COLUMNS_DESC"] = "Değer sütunlarını tek bir biçimli yazıda birleştirmek yerine sabit sütunlarda çizer. Bu bir pencere ayarı değildir, tüm pencereleri birden değiştirir."
L["STRING_OPTIONS_DESIGNER_SHOW_PERCENT_DESC"] = "Yüzdeyi, hem hizalı sütunlarda hem basit yazı biçiminde toplam ve saniyede miktarlarından sonra ekler."
L["STRING_OPTIONS_DESIGNER_ICON_SIZE_OFFSET"] = "Simge Boyut Farkı"
L["STRING_OPTIONS_DESIGNER_BAR_START_AFTER_ICON"] = "Çubuk Simgeden Sonra Başlar"
L["STRING_OPTIONS_DESIGNER_ICON_GRAYSCALE"] = "Gri Tonlu Simgeler"
L["STRING_OPTIONS_DESIGNER_SHOW_STATUSBAR"] = "Durum Çubuğunu Göster"

L["STRING_OPTIONS_AUTO_COMBATLOG"] = "Combatlog'u Otomatik Başlat"
L["STRING_OPTIONS_AUTO_COMBATLOG_DESC"] = "Bir raide ya da zindana girince combatlog.txt dosyasına savaş kaydını otomatik başlat ve durdur."

L["LE_EXPANSION_CLASSIC"] = "Klasik"
L["LE_EXPANSION_BURNING_CRUSADE"] = "The Burning Crusade"
L["LE_EXPANSION_WRATH_OF_THE_LICH_KING"] = "Wrath of the Lich King"
L["LE_EXPANSION_CATACLYSM"] = "Cataclysm"
L["LE_EXPANSION_MISTS_OF_PANDARIA"] = "Mists of Pandaria"
L["LE_EXPANSION_WARLORDS_OF_DRAENOR"] = "Warlords of Draenor"
L["LE_EXPANSION_LEGION"] = "Legion"
L["LE_EXPANSION_BATTLE_FOR_AZEROTH"] = "Battle for Azeroth"
L["LE_EXPANSION_SHADOWLANDS"] = "Shadowlands"
L["LE_EXPANSION_DRAGONFLIGHT"] = "Dragonflight"
L["LE_EXPANSION_WAR_WITHIN"] = "The War Within"
L["LE_EXPANSION_MIDNIGHT"] = "Midnight"

L["STRING_OPTIONS_SELECT_TEMPLATE"] = "Şablon Seç"
L["STRING_OPTIONS_TEXT_SHADOWCOLOR"] = "Gölge Rengi"
L["STRING_OPTIONS_PLAYERNAME"] = "Oyuncu Adı"
L["STRING_OPTIONS_PLAYERNAME_WIDTH"] = "Uzunluk"
L["STRING_ATTRIBUTE_HEAL_POTIONS"] = "İksirler"
L["STRING_ATTRIBUTE_DAMAGE_MYSPELLS"] = "Hasar Büyüleri"
L["STRING_ATTRIBUTE_HEAL_MYSPELLS"] = "İyileştirme Büyüleri"
L["STRING_SIMPLE_TEXT_FORMAT_TITLE"] = "Midnight Sağ Yazı: Basit ya da Hizalı"
L["STRING_SIMPLE_TEXT_FORMAT"] = "Basit Yazı Biçimi Kullan"
L["STRING_SIMPLE_TEXT_FORMAT_DESC"] = "Aşağıdaki üç kuralın kullanımını açar."
L["STRING_SIMPLE_TEXT_FORMAT_TYPE3"] = "Satırda toplam, saniyede ve yüzde\nbilgisi olduğunda.\n|cFFAAAAAA%s sırası: toplam, saniyede, yüzde."
L["STRING_SIMPLE_TEXT_FORMAT_TYPE2"] = "Satırda toplam ve saniyede\nbilgisi olduğunda.\n|cFFAAAAAA%s sırası: toplam, saniyede."
L["STRING_SIMPLE_TEXT_FORMAT_TYPE1"] = "Satırda toplam ve yüzde\nbilgisi olduğunda.\n|cFFAAAAAA%s sırası: toplam, yüzde."
L["STRING_SIMPLE_TEXT_FORMAT_ASLIGNED_SPACE_BETWEEN"] = "Sütun Aralığı"
L["STRING_SIMPLE_TEXT_FORMAT_TEMPLATE2"] = "Yüzdeyi Gösterme"
L["STRING_SIMPLE_TEXT_FORMAT_TEMPLATE3"] = "Yalnızca Toplamı Göster"
L["STRING_SIMPLE_TEXT_FORMAT_TEMPLATE4"] = "Dikey | Çizgiyle | Ayır"
L["STRING_SIMPLE_TEXT_FORMAT_TEMPLATE5"] = "[Köşeli, Parantezle] Ayır"
L["STRING_SIMPLE_TEXT_FORMAT_TEMPLATE6"] = "Toplam (DPS) Yüzde"

L["ABILITY_ID"] = "yetenek kimliği"
L["STRING_"] = ""
L["STRING_ABSORBED"] = "Emildi"
L["STRING_ACTORFRAME_NOTHING"] = "hay aksi, raporlanacak veri yok :("
L["STRING_ACTORFRAME_REPORTAT"] = "şurada:"
L["STRING_ACTORFRAME_REPORTOF"] = " / "
L["STRING_ACTORFRAME_REPORTTARGETS"] = "şunun hedefleri için rapor:"
L["STRING_ACTORFRAME_REPORTTO"] = "şunun raporu:"
L["STRING_ACTORFRAME_SPELLDETAILS"] = "Büyü ayrıntıları"
L["STRING_ACTORFRAME_SPELLSOF"] = "Büyüleri:"
L["STRING_ACTORFRAME_SPELLUSED"] = "Kullanılan tüm büyüler"
L["STRING_AGAINST"] = "karşı"
L["STRING_ALIVE"] = "Hayatta"
L["STRING_ALPHA"] = "Saydamlık"
L["STRING_ANCHOR_BOTTOM"] = "Alt"
L["STRING_ANCHOR_BOTTOMLEFT"] = "Sol Alt"
L["STRING_ANCHOR_BOTTOMRIGHT"] = "Sağ Alt"
L["STRING_ANCHOR_LEFT"] = "Sol"
L["STRING_ANCHOR_RIGHT"] = "Sağ"
L["STRING_ANCHOR_TOP"] = "Üst"
L["STRING_ANCHOR_TOPLEFT"] = "Sol Üst"
L["STRING_ANCHOR_TOPRIGHT"] = "Sağ Üst"
L["STRING_ASCENDING"] = "Artan"
L["STRING_ATACH_DESC"] = "#%d numaralı pencere, #%d numaralı pencereyle grup oluşturdu."
L["STRING_ATTRIBUTE_CUSTOM"] = "Özel"
L["STRING_ATTRIBUTE_DAMAGE"] = "Hasar"
L["STRING_ATTRIBUTE_DAMAGE_BYSPELL"] = "Büyüye Göre Alınan Hasar"
L["STRING_ATTRIBUTE_DAMAGE_DEBUFFS"] = "Auralar ve Yer Etkileri"
L["STRING_ATTRIBUTE_DAMAGE_DEBUFFS_REPORT"] = "Debuff Hasarı ve Süresi"
L["STRING_ATTRIBUTE_DAMAGE_DONE"] = "Verilen Hasar"
L["STRING_ATTRIBUTE_DAMAGE_DPS"] = "DPS"
L["STRING_ATTRIBUTE_DAMAGE_ENEMIES"] = "Düşmanın Aldığı Hasar"
L["STRING_ATTRIBUTE_DAMAGE_ENEMIES_DONE"] = "Düşmanın Verdiği Hasar"
L["STRING_ATTRIBUTE_DAMAGE_FRAGS"] = "Öldürmeler"
L["STRING_ATTRIBUTE_DAMAGE_FRIENDLYFIRE"] = "Dost Ateşi"
L["STRING_ATTRIBUTE_DAMAGE_TAKEN"] = "Alınan Hasar"
L["STRING_ATTRIBUTE_ENERGY"] = "Kaynaklar"
L["STRING_ATTRIBUTE_ENERGY_ALTERNATEPOWER"] = "Alternatif Güç"
L["STRING_ATTRIBUTE_ENERGY_ENERGY"] = "Üretilen Enerji"
L["STRING_ATTRIBUTE_ENERGY_MANA"] = "Geri Kazanılan Mana"
L["STRING_ATTRIBUTE_ENERGY_RAGE"] = "Üretilen Öfke"
L["STRING_ATTRIBUTE_ENERGY_RESOURCES"] = "Diğer Kaynaklar"
L["STRING_ATTRIBUTE_ENERGY_RUNEPOWER"] = "Üretilen Runic Power"
L["STRING_ATTRIBUTE_HEAL"] = "İyileştirme"
L["STRING_ATTRIBUTE_HEAL_ABSORBED"] = "Emilen İyileştirme"
L["STRING_ATTRIBUTE_HEAL_DONE"] = "Yapılan İyileştirme"
L["STRING_ATTRIBUTE_HEAL_ENEMY"] = "Düşmanın Yaptığı İyileştirme"
L["STRING_ATTRIBUTE_HEAL_HPS"] = "HPS"
L["STRING_ATTRIBUTE_HEAL_OVERHEAL"] = "Fazla İyileştirme"
L["STRING_ATTRIBUTE_HEAL_PREVENT"] = "Önlenen Hasar"
L["STRING_ATTRIBUTE_HEAL_TAKEN"] = "Alınan İyileştirme"
L["STRING_ATTRIBUTE_MISC"] = "Çeşitli"
L["STRING_ATTRIBUTE_MISC_BUFF_UPTIME"] = "Buff Süresi"
L["STRING_ATTRIBUTE_MISC_CCBREAK"] = "CC Bozmaları"
L["STRING_ATTRIBUTE_MISC_DEAD"] = "Ölümler"
L["STRING_ATTRIBUTE_MISC_DEBUFF_UPTIME"] = "Debuff Süresi"
L["STRING_ATTRIBUTE_MISC_DEFENSIVE_COOLDOWNS"] = "Bekleme Süreleri"
L["STRING_ATTRIBUTE_MISC_DISPELL"] = "Dispel'ler"
L["STRING_ATTRIBUTE_MISC_INTERRUPT"] = "Kesmeler"
L["STRING_ATTRIBUTE_MISC_RESS"] = "Diriltme"
L["STRING_AUTO"] = "otomatik"
L["STRING_AUTOSHOT"] = "Auto Shot"
L["STRING_AVERAGE"] = "Ortalama"
L["STRING_BLOCKED"] = "Bloklandı"
L["STRING_BOTTOM"] = "alt"
L["STRING_BOTTOM_TO_TOP"] = "Aşağıdan Yukarı"
L["STRING_CAST"] = "Büyü Yapımları"
L["STRING_CAUGHT"] = "yakalandı"
L["STRING_CCBROKE"] = "Kaldırılan Kitle Kontrolü"
L["STRING_CENTER"] = "orta"
L["STRING_CENTER_UPPER"] = "Orta"
L["STRING_CHANGED_TO_CURRENT"] = "Bölüm Değişti: |cFFFFFF00Şimdiki|r"
L["STRING_CHANNEL_PRINT"] = "Gözlemci"
L["STRING_CHANNEL_RAID"] = "Raid"
L["STRING_CHANNEL_SAY"] = "Söyle"
L["STRING_CHANNEL_WHISPER"] = "Fısılda"
L["STRING_CHANNEL_WHISPER_TARGET_COOLDOWN"] = "Bekleme Süresi Hedefine Fısılda"
L["STRING_CHANNEL_YELL"] = "Bağır"
L["STRING_CLICK_REPORT_LINE1"] = "|cFFFFCC22Tıkla|r: |cFFFFEE00raporla|r"
L["STRING_CLICK_REPORT_LINE2"] = "|cFFFFCC22Shift+Tık|r: |cFFFFEE00pencere modu|r"
L["STRING_CLOSEALL"] = "Tüm pencereler kapalı; yeniden açmak için '/details show' yazabilirsin."
L["STRING_COLOR"] = "Renk"
L["STRING_COMMAND_LIST"] = "komut listesi"
L["STRING_CONTEXT"] = "Bağlam"
L["STRING_COOLTIP_NOOPTIONS"] = "seçenek yok"
L["STRING_CREATEAURA"] = "Aura Oluştur"
L["STRING_CRITICAL_HITS"] = "Kritik Vuruşlar"
L["STRING_CRITICAL_ONLY"] = "kritik"
L["STRING_CURRENT"] = "Güncel"
L["STRING_CURRENTFIGHT"] = "Şimdiki Bölüm"
L["STRING_CUSTOM_ACTIVITY_ALL"] = "Etkinlik Süresi"
L["STRING_CUSTOM_ACTIVITY_ALL_DESC"] = "Raid grubundaki her oyuncunun etkinlik sonuçlarını gösterir."
L["STRING_CUSTOM_ACTIVITY_DPS"] = "Hasar Etkinlik Süresi"
L["STRING_CUSTOM_ACTIVITY_DPS_DESC"] = "Her karakterin hasar vermekle ne kadar zaman geçirdiğini gösterir."
L["STRING_CUSTOM_ACTIVITY_HPS"] = "İyileştirme Etkinlik Süresi"
L["STRING_CUSTOM_ACTIVITY_HPS_DESC"] = "Her karakterin iyileştirme yapmakla ne kadar zaman geçirdiğini gösterir."
L["STRING_CUSTOM_ATTRIBUTE_DAMAGE"] = "Hasar"
L["STRING_CUSTOM_ATTRIBUTE_HEAL"] = "İyileştirme"
L["STRING_CUSTOM_ATTRIBUTE_SCRIPT"] = "Özel Betik"
L["STRING_CUSTOM_AUTHOR"] = "Yazar:"
L["STRING_CUSTOM_AUTHOR_DESC"] = "Bu görünümü oluşturan kişi."
L["STRING_CUSTOM_CANCEL"] = "İptal"
L["STRING_CUSTOM_CC_DONE"] = "Yapılan Kitle Kontrolü"
L["STRING_CUSTOM_CC_RECEIVED"] = "Alınan Kitle Kontrolü"
L["STRING_CUSTOM_CREATE"] = "Oluştur"
L["STRING_CUSTOM_CREATED"] = "Yeni görünüm oluşturuldu."
L["STRING_CUSTOM_DAMAGEONANYMARKEDTARGET"] = "Diğer İşaretli Hedeflere Hasar"
L["STRING_CUSTOM_DAMAGEONANYMARKEDTARGET_DESC"] = "Başka işaretlerle işaretlenmiş hedeflere verilen hasar miktarını göster."
L["STRING_CUSTOM_DAMAGEONSHIELDS"] = "Kalkanlara Hasar"
L["STRING_CUSTOM_DAMAGEONSKULL"] = "Kurukafa İşaretli Hedeflere Hasar"
L["STRING_CUSTOM_DAMAGEONSKULL_DESC"] = "Kurukafa işaretli hedeflere verilen hasar miktarını göster."
L["STRING_CUSTOM_DESCRIPTION"] = "Açıklama:"
L["STRING_CUSTOM_DESCRIPTION_DESC"] = "Bu görünümün ne yaptığına dair açıklama."
L["STRING_CUSTOM_DONE"] = "Bitti"
L["STRING_CUSTOM_DTBS"] = "Büyüye Göre Alınan Hasar"
L["STRING_CUSTOM_DTBS_DESC"] = "Düşman büyülerinin grubuna verdiği hasarı göster."
L["STRING_CUSTOM_DYNAMICOVERAL"] = "Dinamik Genel Hasar"
L["STRING_CUSTOM_EDIT"] = "Düzenle"
L["STRING_CUSTOM_EDIT_SEARCH_CODE"] = "Arama Kodunu Düzenle"
L["STRING_CUSTOM_EDIT_TOOLTIP_CODE"] = "İpucu Kodunu Düzenle"
L["STRING_CUSTOM_EDITCODE_DESC"] = "Bu, kullanıcının kendi görünüm kodunu yazabildiği gelişmiş bir işlevdir."
L["STRING_CUSTOM_EDITTOOLTIP_DESC"] = "Bu, ipucu kodudur; kullanıcı bir çubuğun üzerine gelince çalışır."
L["STRING_CUSTOM_ENEMY_DT"] = " Alınan Hasar"
L["STRING_CUSTOM_EXPORT"] = "Dışa Aktar"
L["STRING_CUSTOM_FUNC_INVALID"] = "Özel betik geçersiz, pencere yenilenemiyor."
L["STRING_CUSTOM_HEALTHSTONE_DEFAULT"] = "Can İksiri ve Taşı"
L["STRING_CUSTOM_HEALTHSTONE_DEFAULT_DESC"] = "Raid grubunda kimin sağlık taşı ya da iyileştirme iksiri kullandığını göster."
L["STRING_CUSTOM_ICON"] = "Simge:"
L["STRING_CUSTOM_IMPORT"] = "İçe Aktar"
L["STRING_CUSTOM_IMPORT_ALERT"] = "Görünüm yüklendi, onaylamak için İçe Aktar'a tıkla."
L["STRING_CUSTOM_IMPORT_BUTTON"] = "İçe Aktar"
L["STRING_CUSTOM_IMPORT_ERROR"] = "İçe aktarma başarısız, geçersiz metin."
L["STRING_CUSTOM_IMPORTED"] = "Görünüm başarıyla içe aktarıldı."
L["STRING_CUSTOM_LONGNAME"] = "Ad çok uzun, en fazla 32 karakter olabilir."
L["STRING_CUSTOM_MYSPELLS"] = "Büyülerim"
L["STRING_CUSTOM_MYSPELLS_DESC"] = "Büyülerini pencerede göster."
L["STRING_CUSTOM_NAME"] = "Ad:"
L["STRING_CUSTOM_NAME_DESC"] = "Yeni özel görünümünün adını gir."
L["STRING_CUSTOM_NEW"] = "Özel Görünümleri Yönet"
L["STRING_CUSTOM_PASTE"] = "Buraya Yapıştır:"
L["STRING_CUSTOM_POT_DEFAULT"] = "Kullanılan İksir"
L["STRING_CUSTOM_POT_DEFAULT_DESC"] = "Raidinde karşılaşma sırasında kimin iksir kullandığını göster."
L["STRING_CUSTOM_REMOVE"] = "Kaldır"
L["STRING_CUSTOM_REPORT"] = "(özel)"
L["STRING_CUSTOM_SAVE"] = "Değişiklikleri Kaydet"
L["STRING_CUSTOM_SAVED"] = "Görünüm kaydedildi."
L["STRING_CUSTOM_SHORTNAME"] = "Ad en az 5 karakter olmalı."
L["STRING_CUSTOM_SKIN_TEXTURE"] = "Özel Görünüm Dosyası"
L["STRING_CUSTOM_SKIN_TEXTURE_DESC"] = [=[.tga dosyasının adı.

Şu klasöre konmalıdır:

|cFFFFFF00WoW/Interface/|r

|cFFFFFF00Önemli:|r dosyayı oluşturmadan önce oyunu kapat. Sonra /reload, doku dosyasında kaydedilen değişiklikleri uygular.]=]
L["STRING_CUSTOM_SOURCE"] = "Kaynak:"
L["STRING_CUSTOM_SOURCE_DESC"] = [=[Etkiyi kimin tetiklediği.

Sağdaki düğme raid karşılaşmalarındaki NPC'lerin listesini gösterir.]=]
L["STRING_CUSTOM_SPELLID"] = "Büyü Kimliği:"
L["STRING_CUSTOM_SPELLID_DESC"] = [=[İsteğe bağlı; kaynağın etkiyi hedefe uygulamak için kullandığı büyü.

Sağdaki düğme raid karşılaşmalarındaki büyülerin listesini gösterir.]=]
L["STRING_CUSTOM_TARGET"] = "Hedef:"
L["STRING_CUSTOM_TARGET_DESC"] = [=[Bu, kaynağın hedefidir.

Sağdaki düğme raid karşılaşmalarındaki NPC'lerin listesini gösterir.]=]
L["STRING_CUSTOM_TEMPORARILY"] = " (|cFFFFC000geçici olarak|r)"
L["STRING_CUSTOM_TEXTURE_GUIDE"] = [=[Simgeler için özel bir dosya kullanmak için:
- Dosya .TGA biçiminde olmalı.
- Dosya 512x512 piksel olmalı.
- Uzmanlık için dosya adında 'spec_' geçmeli.
- Dokuyu /WoW Kurulum Klasörü/_retail_/Interface/ içine koy]=]
L["STRING_DAMAGE"] = "Hasar"
L["STRING_DAMAGE_DPS_IN"] = "şundan alınan DPS:"
L["STRING_DAMAGE_FROM"] = "Şundan hasar aldı:"
L["STRING_DAMAGE_TAKEN_FROM"] = "Şundan Alınan Hasar:"
L["STRING_DAMAGE_TAKEN_FROM2"] = "şununla hasar verdi:"
L["STRING_DEFENSES"] = "Savunmalar"
L["STRING_DESCENDING"] = "Azalan"
L["STRING_DETACH_DESC"] = "Pencere Grubunu Ayır"
L["STRING_DISCARD"] = "Vazgeç"
L["STRING_DISPELLED"] = "Kaldırılan Buff/Debuff'lar"
L["STRING_DODGE"] = "Sıyrılma"
L["STRING_DOT"] = " (DoT)"
L["STRING_DPS"] = "DPS"
L["STRING_EMPTY_SEGMENT"] = "Boş Bölüm"
L["STRING_ENABLE_DO_NOT_DISTURB"] = "Rahatsız Etme'yi Aç"
L["STRING_ENABLED"] = "Etkin"
L["STRING_ENVIRONMENTAL_DROWNING"] = "Ortam (Boğulma)"
L["STRING_ENVIRONMENTAL_FALLING"] = "Ortam (Düşme)"
L["STRING_ENVIRONMENTAL_FATIGUE"] = "Ortam (Yorgunluk)"
L["STRING_ENVIRONMENTAL_FIRE"] = "Ortam (Ateş)"
L["STRING_ENVIRONMENTAL_LAVA"] = "Ortam (Lav)"
L["STRING_ENVIRONMENTAL_SLIME"] = "Ortam (Balçık)"
L["STRING_ERASE"] = "sil"
L["STRING_ERASE_DATA"] = "Tüm Veriyi Sıfırla"
L["STRING_ERASE_DATA_OVERALL"] = "Genel Veriyi Sıfırla"
L["STRING_ERASE_IN_COMBAT"] = "Şimdiki savaştan sonra genel veri silinecek."
L["STRING_EXAMPLE"] = "Örnek"
L["STRING_EXPLOSION"] = "patlama"
L["STRING_FAIL_ATTACKS"] = "Başarısız Saldırılar"
L["STRING_FEEDBACK_CURSE_DESC"] = "Details! sayfasında bir kayıt aç ya da mesaj bırak."
L["STRING_FEEDBACK_MMOC_DESC"] = "mmo-champion forumundaki konumuza yaz."
L["STRING_FEEDBACK_PREFERED_SITE"] = "Tercih ettiğin topluluk sitesini seç:"
L["STRING_FEEDBACK_SEND_FEEDBACK"] = "Geri Bildirim Gönder"
L["STRING_FEEDBACK_WOWI_DESC"] = "Details! proje sayfasına yorum bırak."
L["STRING_FIGHTNUMBER"] = "Dövüş #"
L["STRING_FORGE_BUTTON_ALLSPELLS"] = "Tüm Büyüler"
L["STRING_FORGE_BUTTON_ALLSPELLS_DESC"] = "Oyuncuların ve NPC'lerin tüm büyülerini listele."
L["STRING_FORGE_BUTTON_BWTIMERS"] = "BigWigs Sayaçları"
L["STRING_FORGE_BUTTON_BWTIMERS_DESC"] = "BigWigs sayaçlarını listele"
L["STRING_FORGE_BUTTON_DBMTIMERS"] = "DBM Sayaçları"
L["STRING_FORGE_BUTTON_DBMTIMERS_DESC"] = "Deadly Boss Mods sayaçlarını listele"
L["STRING_FORGE_BUTTON_ENCOUNTERSPELLS"] = "Boss Büyüleri"
L["STRING_FORGE_BUTTON_ENCOUNTERSPELLS_DESC"] = "Yalnızca raid ve zindan karşılaşmalarındaki büyüleri listele."
L["STRING_FORGE_BUTTON_ENEMIES"] = "Düşmanlar"
L["STRING_FORGE_BUTTON_ENEMIES_DESC"] = "Şimdiki savaştaki düşmanları listele."
L["STRING_FORGE_BUTTON_PETS"] = "Petler"
L["STRING_FORGE_BUTTON_PETS_DESC"] = "Şimdiki savaştaki petleri listele."
L["STRING_FORGE_BUTTON_PLAYERS"] = "Oyuncular"
L["STRING_FORGE_BUTTON_PLAYERS_DESC"] = "Şimdiki savaştaki oyuncuları listele."
L["STRING_FORGE_ENABLEPLUGINS"] = "\"Lütfen Raid adlı Details! eklentilerini Escape Menüsü > AddOns'tan aç, ör. Details: Tomb of Sargeras.\""
L["STRING_FORGE_FILTER_BARTEXT"] = "Çubuk Adı"
L["STRING_FORGE_FILTER_CASTERNAME"] = "Büyüyü Yapanın Adı"
L["STRING_FORGE_FILTER_ENCOUNTERNAME"] = "Karşılaşma Adı"
L["STRING_FORGE_FILTER_ENEMYNAME"] = "Düşman Adı"
L["STRING_FORGE_FILTER_OWNERNAME"] = "Sahip Adı"
L["STRING_FORGE_FILTER_PETNAME"] = "Pet Adı"
L["STRING_FORGE_FILTER_PLAYERNAME"] = "Oyuncu Adı"
L["STRING_FORGE_FILTER_SPELLNAME"] = "Büyü Adı"
L["STRING_FORGE_HEADER_BARTEXT"] = "Çubuk Yazısı"
L["STRING_FORGE_HEADER_CASTER"] = "Büyüyü Yapan"
L["STRING_FORGE_HEADER_CLASS"] = "Sınıf"
L["STRING_FORGE_HEADER_CREATEAURA"] = "Aura Oluştur"
L["STRING_FORGE_HEADER_ENCOUNTERID"] = "Karşılaşma Kimliği"
L["STRING_FORGE_HEADER_ENCOUNTERNAME"] = "Karşılaşma Adı"
L["STRING_FORGE_HEADER_EVENT"] = "Etkinlik"
L["STRING_FORGE_HEADER_FLAG"] = "Bayrak"
L["STRING_FORGE_HEADER_GUID"] = "GUID"
L["STRING_FORGE_HEADER_ICON"] = "Simge"
L["STRING_FORGE_HEADER_ID"] = "Kimlik"
L["STRING_FORGE_HEADER_INDEX"] = "Sıra"
L["STRING_FORGE_HEADER_NAME"] = "Ad"
L["STRING_FORGE_HEADER_NPCID"] = "NpcID"
L["STRING_FORGE_HEADER_OWNER"] = "Sahip"
L["STRING_FORGE_HEADER_SCHOOL"] = "Büyü Okulu"
L["STRING_FORGE_HEADER_SPELLID"] = "SpellID"
L["STRING_FORGE_HEADER_TIMER"] = "Sayaç"
L["STRING_FORGE_TUTORIAL_DESC"] = "'|cFFFFFF00Aura Oluştur|r'a tıklayarak aura oluşturmak için büyülere ve boss mod sayaçlarına göz at."
L["STRING_FORGE_TUTORIAL_TITLE"] = "Details! Forge'a Hoş Geldin"
L["STRING_FORGE_TUTORIAL_VIDEO"] = "Boss mod sayaçlarını kullanan bir Aura örneği:"
L["STRING_FREEZE"] = "Bu bölüm şu anda kullanılamıyor"
L["STRING_FROM"] = "Kimden"
L["STRING_GERAL"] = "Genel"
L["STRING_GLANCING"] = "Sıyırma"
L["STRING_GUILDDAMAGERANK_BOSS"] = "Boss"
L["STRING_GUILDDAMAGERANK_DATABASEERROR"] = "'|cFFFFFF00Details! Storage|r' açılamadı, eklenti kapalı olabilir mi?"
L["STRING_GUILDDAMAGERANK_DIFF"] = "Zorluk"
L["STRING_GUILDDAMAGERANK_GUILD"] = "Lonca"
L["STRING_GUILDDAMAGERANK_PLAYERBASE"] = "Oyuncu Tabanı"
L["STRING_GUILDDAMAGERANK_PLAYERBASE_INDIVIDUAL"] = "Bireysel"
L["STRING_GUILDDAMAGERANK_PLAYERBASE_PLAYER"] = "Oyuncu"
L["STRING_GUILDDAMAGERANK_PLAYERBASE_RAID"] = "Tüm Oyuncular"
L["STRING_GUILDDAMAGERANK_RAID"] = "Raid"
L["STRING_GUILDDAMAGERANK_ROLE"] = "Rol"
L["STRING_GUILDDAMAGERANK_SHOWHISTORY"] = "Öldürme Zaman Çizelgesi"
L["STRING_GUILDDAMAGERANK_SHOWRANK"] = "Lonca Rütbesi"
L["STRING_GUILDDAMAGERANK_SYNCBUTTONTEXT"] = "Loncayla Eşitle"
L["STRING_GUILDDAMAGERANK_TUTORIAL_DESC"] = "Details! store the damage and healing done for each boss encounter you run with your guild.\\n\\nBrowse the history by checking the box '|cFFFFFF00Show History|r', results for all fights will be displayed.\\n By selecting '|cFFFFFF00Show Guild Rank|r', the top scores for the selected boss is shown.\\n\\nIf you are using this tool for the first time or if you lost a day of raiding, click on the '|cFFFFFF00Sync With Guild|r' button."
L["STRING_GUILDDAMAGERANK_WINDOWALERT"] = "Boss Yenildi! Sıralamayı Göster"
L["STRING_HEAL"] = "İyileştirme"
L["STRING_HEAL_ABSORBED"] = "Emilen iyileştirme"
L["STRING_HEAL_CRIT"] = "Kritik İyileştirme"
L["STRING_HEALING_FROM"] = "şundan alınan iyileştirme:"
L["STRING_HEALING_HPS_FROM"] = "şundan alınan HPS:"
L["STRING_HITS"] = "Vuruşlar"
L["STRING_HPS"] = "HPS"
L["STRING_IMAGEEDIT_ALPHA"] = "Saydamlık"
L["STRING_IMAGEEDIT_CROPBOTTOM"] = "Alttan Kırp"
L["STRING_IMAGEEDIT_CROPLEFT"] = "Soldan Kırp"
L["STRING_IMAGEEDIT_CROPRIGHT"] = "Sağdan Kırp"
L["STRING_IMAGEEDIT_CROPTOP"] = "Üstten Kırp"
L["STRING_IMAGEEDIT_DONE"] = "BİTTİ"
L["STRING_IMAGEEDIT_FLIPH"] = "Yatay Çevir"
L["STRING_IMAGEEDIT_FLIPV"] = "Dikey Çevir"
L["STRING_INFO_TAB_AVOIDANCE"] = "Kaçınma"
L["STRING_INFO_TAB_COMPARISON"] = "Karşılaştır"
L["STRING_INFO_TAB_SUMMARY"] = "Özet"
L["STRING_INFO_TUTORIAL_COMPARISON1"] = "Aynı sınıftaki oyuncular arasındaki karşılaştırmaları görmek için |cFFFFDD00Karşılaştır|r sekmesine tıkla."
L["STRING_INSTANCE_CHAT"] = "Zindan Sohbeti"
L["STRING_INSTANCE_LIMIT"] = "en fazla pencere sayısına ulaşıldı, bu sınırı ayarlar panelinden değiştirebilirsin. Kapalı pencereleri (#) pencere menüsünden yeniden açabilirsin."
L["STRING_INTERFACE_OPENOPTIONS"] = "Ayarlar Panelini Aç"
L["STRING_INVERT_RULE"] = "Kuralı Ters Çevir"
L["STRING_ISA_PET"] = "Bu Birim Bir Pet"
L["STRING_KEYBIND_BOOKMARK"] = "Yer İmi"
L["STRING_KEYBIND_BOOKMARK_NUMBER"] = "Yer İmi #%s"
L["STRING_KEYBIND_RESET_SEGMENTS"] = "Bölümleri Sıfırla"
L["STRING_KEYBIND_SCROLL_DOWN"] = "Tüm Pencereleri Aşağı Kaydır"
L["STRING_KEYBIND_SCROLL_UP"] = "Tüm Pencereleri Yukarı Kaydır"
L["STRING_KEYBIND_SCROLLING"] = "Kaydırma"
L["STRING_KEYBIND_SEGMENTCONTROL"] = "Bölümler"
L["STRING_KEYBIND_TOGGLE_WINDOW"] = "Pencere #%s Aç/Kapat"
L["STRING_KEYBIND_TOGGLE_WINDOWS"] = "Hepsini Aç/Kapat"
L["STRING_KEYBIND_WINDOW_CONTROL"] = "Pencereler"
L["STRING_KEYBIND_WINDOW_REPORT"] = "#%s numaralı pencerede gösterilen veriyi raporla."
L["STRING_KEYBIND_WINDOW_REPORT_HEADER"] = "Veriyi Raporla"
L["STRING_KEYSTONE_ADD_TO_FRIENDS_TOOLTIP"] = "Karakter olarak arkadaş listesine ekle (battle.net arkadaşlık isteği değil)."
L["STRING_KEYSTONE_CLICK_TO_VIEW_SCOREBOARD"] = "Skor tablosunu görmek için tıkla."
L["STRING_KEYSTONE_DND_TOOLTIP"] = "Anahtarın loncana ya da arkadaşlarına gönderilmez. Gruptayken yine gönderilir."
L["STRING_KEYSTONE_LIFETIME_LIKES_YOU_GAVE"] = [=[|cFFFFFF00Details! Damage Meter Mythic+|r eklentisindeki 'GG' düğmesiyle bu oyuncuya bugüne kadar verdiğin beğeniler.

Bu oyuncuyla yaptığın bir Mythic+ koşusunu seçerek koşu dökümünü görebilirsin.]=]
L["STRING_KEYSTONE_NO_MYTHICPLUS_ADDON"] = "Mythic+ eklentisi bulunamadı."
L["STRING_KEYSTONE_REQUEST_FROM_GUILD"] = "Loncadan İste"
L["STRING_KILLED"] = "Öldürüldü"
L["STRING_LAST_COOLDOWN"] = "son kullanılan bekleme süresi"
L["STRING_LEFT"] = "sol"
L["STRING_LEFT_CLICK_SHARE"] = "Raporlamak için sol tıkla."
L["STRING_LEFT_TO_RIGHT"] = "Soldan Sağa"
L["STRING_LIKES_YOU_GAVE"] = "Verdiğin beğeniler"
L["STRING_LOCK_DESC"] = "Pencereyi kilitle ya da kilidini aç"
L["STRING_LOCK_WINDOW"] = "kilitle"
L["STRING_MASTERY"] = "Mastery"
L["STRING_MAXIMUM"] = "En Çok"
L["STRING_MAXIMUM_SHORT"] = "Azami"
L["STRING_MEDIA"] = "Medya"
L["STRING_MELEE"] = "Yakın Dövüş"
L["STRING_MEMORY_ALERT_BUTTON"] = "Anladım"
L["STRING_MEMORY_ALERT_TEXT1"] = "Details! çok bellek kullanır, ama |cFFFF8800yaygın inanışın aksine|r eklentilerin bellek kullanımı oyun performansını ya da FPS'ini |cFFFF8800etkilemez|r."
L["STRING_MEMORY_ALERT_TEXT2"] = "Yani Details!'in çok bellek kullandığını görürsen panik yapma :D |cFFFF8800Her şey yolunda!|r Bu belleğin bir kısmı eklentiyi hızlandırmak için |cFFFF8800önbellekte|r bile kullanılıyor."
L["STRING_MEMORY_ALERT_TEXT3"] = "Ancak |cFFFF8800hangi eklentilerin 'ağır'|r olduğunu ya da FPS'ini düşürdüğünü öğrenmek istiyorsan '|cFFFFFF00AddOns Cpu Usage|r' eklentisini kur."
L["STRING_MEMORY_ALERT_TITLE"] = "Lütfen Dikkatle Oku!"
L["STRING_MENU_CLOSE_INSTANCE"] = "Bu Pencereyi Kapat"
L["STRING_MENU_CLOSE_INSTANCE_DESC"] = "Kapalı bir pencere etkin değil sayılır ve pencere kontrol menüsüyle her zaman yeniden açılabilir."
L["STRING_MENU_CLOSE_INSTANCE_DESC2"] = "Kalıcı olarak kaldırmak için Ayarlar Paneli > Pencere Gövdesi > Sil'e git."
L["STRING_MENU_INSTANCE_CONTROL"] = "Pencere Kontrolü"
L["STRING_MINIMAP_TOOLTIP1"] = "|cFFCFCFCFsol tık|r: ayarlar panelini aç"
L["STRING_MINIMAP_TOOLTIP11"] = "|cFFCFCFCFsol tık|r: tüm bölümleri temizle"
L["STRING_MINIMAP_TOOLTIP12"] = "|cFFCFCFCFsol tık|r: pencereleri göster/gizle"
L["STRING_MINIMAP_TOOLTIP2"] = "|cFFCFCFCFsağ tık|r: hızlı menü"
L["STRING_MINIMAPMENU_CLOSEALL"] = "Hepsini Kapat"
L["STRING_MINIMAPMENU_HIDEICON"] = "Minimap Simgesini Gizle"
L["STRING_MINIMAPMENU_LOCK"] = "Kilitle"
L["STRING_MINIMAPMENU_NEWWINDOW"] = "Yeni Pencere Oluştur"
L["STRING_MINIMAPMENU_REOPENALL"] = "Hepsini Yeniden Aç"
L["STRING_MINIMAPMENU_UNLOCK"] = "Kilidi Aç"
L["STRING_MINIMUM"] = "En Az"
L["STRING_MINIMUM_SHORT"] = "Asgari"
L["STRING_MINITUTORIAL_BOOKMARK1"] = "Yer imlerini açmak için pencerenin herhangi bir yerine sağ tıkla!"
L["STRING_MINITUTORIAL_BOOKMARK2"] = "Yer imleri sık kullandığın görünümlere hızlı erişim sağlar."
L["STRING_MINITUTORIAL_BOOKMARK3"] = "Yer imi panelini kapatmak için sağ tıkla."
L["STRING_MINITUTORIAL_BOOKMARK4"] = "Bunu bir daha gösterme."
L["STRING_MINITUTORIAL_CLOSECTRL1"] = "|cFFFFFF00Ctrl + Sağ Tık|r pencereyi kapatır!"
L["STRING_MINITUTORIAL_CLOSECTRL2"] = "Yeniden açmak istersen Mod Menüsü -> Pencere Kontrolü ya da Ayarlar Paneline git."
L["STRING_MINITUTORIAL_OPTIONS_PANEL1"] = "Düzenlenmekte olan pencere."
L["STRING_MINITUTORIAL_OPTIONS_PANEL2"] = "İşaretliyse gruptaki tüm pencereler de değişir."
L["STRING_MINITUTORIAL_OPTIONS_PANEL3"] = [=[Bir grup oluşturmak için 2. pencereyi 1. pencerenin yanına sürükle.

Grubu |cFFFFFF00gruptan ayır|r düğmesine tıklayarak bozabilirsin.]=]
L["STRING_MINITUTORIAL_OPTIONS_PANEL4"] = "Deneme çubukları oluşturarak ayarlarını dene."
L["STRING_MINITUTORIAL_OPTIONS_PANEL5"] = "Grubu Düzenleme açıkken gruptaki tüm pencereler değişir."
L["STRING_MINITUTORIAL_OPTIONS_PANEL6"] = "Pencere görünümünü seçmek ve değiştirmek için buradan seç."
L["STRING_MINITUTORIAL_WINDOWS1"] = [=[Bir pencere grubu oluşturdun.

Bozmak için asma kilit simgesine tıkla.]=]
L["STRING_MINITUTORIAL_WINDOWS2"] = [=[Pencere kilitlendi.

Uzatmak için başlık çubuğuna tıkla ve yukarı sürükle.]=]
L["STRING_MIRROR_IMAGE"] = "Ayna Görüntüsü"
L["STRING_MISS"] = "Iska"
L["STRING_MODE_ALL"] = "Her Şey"
L["STRING_MODE_GROUP"] = "Standart"
L["STRING_MODE_OPENFORGE"] = "Büyü Listesi"
L["STRING_MODE_PLUGINS"] = "eklentiler"
L["STRING_MODE_RAID"] = "Eklentiler: Raid"
L["STRING_MODE_SELF"] = "Eklentiler: Tek Başına"
L["STRING_MORE_INFO"] = "Daha fazla bilgi için sağdaki kutuya bak."
L["STRING_MULTISTRIKE"] = "Multistrike"
L["STRING_MULTISTRIKE_HITS"] = "Multistrike Vuruşları"
L["STRING_MUSIC_DETAILS_ROBERTOCARLOS"] = [=[Unutmaya çalışmanın faydası yok
Hayatında uzun süre yaşayacağım
Bizim kadar küçük ayrıntılar]=]
L["STRING_NEWROW"] = "yenileme bekleniyor..."
L["STRING_NEWS_REINSTALL"] = "Bir güncellemeden sonra sorun mu var? '/details reinstall' komutunu dene."
L["STRING_NEWS_TITLE"] = "Bu Sürümdeki Yenilikler"
L["STRING_NO"] = "Hayır"
L["STRING_NO_DATA"] = "veri zaten temizlenmiş"
L["STRING_NO_MYTHIC_PLUS_ADDON"] = "Loot, puan, verilen hasar, yapılan iyileştirme ve kimlerle oynadığın dahil Mythic+ koşularını takip etmek için |cFFfff1c1Wago AddOns|r ya da |cFFfff1c1Curse Forge|r üzerinden |cFFFFAA00Details! Damage Meter Mythic+|r eklentisini kur."
L["STRING_NO_SPELL"] = "hiç büyü kullanılmadı"
L["STRING_NO_TARGET"] = "Hedef bulunamadı."
L["STRING_NO_TARGET_BOX"] = "Uygun Hedef Yok"
L["STRING_NO_TELEPORTER"] = "Bu ışınlayıcıya sahip değilsin"
L["STRING_NOCLOSED_INSTANCES"] = [=[Kapalı pencere yok,
yeni bir tane açmak için tıkla.]=]
L["STRING_NOLAST_COOLDOWN"] = "bekleme süresi kullanılmadı"
L["STRING_NOMORE_INSTANCES"] = [=[En fazla pencere sayısına ulaşıldı.
Sınırı ayarlar panelinden değiştir.]=]
L["STRING_NORMAL_HITS"] = "Normal Vuruşlar"
L["STRING_NUMERALSYSTEM"] = "Sayı Sistemi"
L["STRING_NUMERALSYSTEM_ARABIC_MYRIAD_EASTASIA"] = "Doğu Asya ülkelerinde kullanılır, binler ve onbinler olarak ayırır."
L["STRING_NUMERALSYSTEM_ARABIC_WESTERN"] = "Batı"
L["STRING_NUMERALSYSTEM_ARABIC_WESTERN_DESC"] = "en yaygın yöntem, binler ve milyonlar olarak ayırır."
L["STRING_NUMERALSYSTEM_DESC"] = "Kullanılacak sayı sistemini seç"
L["STRING_NUMERALSYSTEM_MYRIAD_EASTASIA"] = "Doğu Asya"
L["STRING_OFFHAND_HITS"] = "Yedek El"
L["STRING_OPTIONS_3D_LALPHA_DESC"] = [=[Alt modeldeki saydamlık miktarını ayarla.

|cFFFFFF00Önemli|r: bazı modeller saydamlık miktarını yok sayar.]=]
L["STRING_OPTIONS_3D_LANCHOR"] = "Alt 3D Model:"
L["STRING_OPTIONS_3D_LENABLED_DESC"] = "Çubukların arkasında 3D model çerçevesi kullanımını açar ya da kapatır."
L["STRING_OPTIONS_3D_LSELECT_DESC"] = "Alt model çubuğunda hangi modelin kullanılacağını seç."
L["STRING_OPTIONS_3D_SELECT"] = "Model Seç"
L["STRING_OPTIONS_3D_UALPHA_DESC"] = [=[Üst modeldeki saydamlık miktarını ayarla.

|cFFFFFF00Önemli|r: bazı modeller saydamlık miktarını yok sayar.]=]
L["STRING_OPTIONS_3D_UANCHOR"] = "Üst 3D Model:"
L["STRING_OPTIONS_3D_UENABLED_DESC"] = "Çubukların üzerinde 3D model çerçevesi kullanımını açar ya da kapatır."
L["STRING_OPTIONS_3D_USELECT_DESC"] = "Üst model çubuğunda hangi modelin kullanılacağını seç."
L["STRING_OPTIONS_ADVANCED"] = "Gelişmiş"
L["STRING_OPTIONS_ALIGNED_TEXT_COLUMNS"] = "Hizalı Yazı Sütunları"
L["STRING_OPTIONS_ALIGNED_TEXT_COLUMNS_AUTOALIGN"] = "Otomatik Hizalama"
L["STRING_OPTIONS_ALIGNED_TEXT_COLUMNS_AUTOALIGN_DESC"] = "Hizalama, her yazının uzunluğuna göre otomatik yapılır"
L["STRING_OPTIONS_ALIGNED_TEXT_COLUMNS_DESC"] = "Parantezleri ve ayırıcıları kapat, çubuk yazılarını dikey sütunlarda hizala"
L["STRING_OPTIONS_ALIGNED_TEXT_COLUMNS_OFFSET"] = "Yazı %d Kaydırması"
L["STRING_OPTIONS_ALIGNED_TEXT_COLUMNS_OFFSET_DESC"] = "Sağ kenardan uzaklık"
L["STRING_OPTIONS_ALPHAMOD_ANCHOR"] = "Otomatik Gizle:"
L["STRING_OPTIONS_ALWAYS_USE"] = "Tüm Karakterlerde Kullan"
L["STRING_OPTIONS_ALWAYS_USE_DESC"] = "Tüm karakterlerde aynı profil kullanılır. Herhangi bir karakterde başka bir mevcut profili seçerek bunu geçersiz kılabilirsin."
L["STRING_OPTIONS_ALWAYSSHOWPLAYERS"] = "Grupsuz Oyuncuları Göster"
L["STRING_OPTIONS_ALWAYSSHOWPLAYERS_DESC"] = "Varsayılan Standart modu kullanırken, seninle grupta olmasalar bile oyuncu karakterlerini göster."
L["STRING_OPTIONS_ANCHOR"] = "Yan"
L["STRING_OPTIONS_ANIMATEBARS"] = "Çubukları Canlandır"
L["STRING_OPTIONS_ANIMATEBARS_DESC"] = "Tüm çubuklar için animasyonları aç."
L["STRING_OPTIONS_ANIMATESCROLL"] = "Kaydırma Çubuğunu Canlandır"
L["STRING_OPTIONS_ANIMATESCROLL_DESC"] = "Açıksa kaydırma çubuğu görünürken ya da gizlenirken animasyon kullanır."
L["STRING_OPTIONS_APPEARANCE"] = "Görünüm"
L["STRING_OPTIONS_ATTRIBUTE_TEXT"] = "Başlık Yazısı Ayarları"
L["STRING_OPTIONS_ATTRIBUTE_TEXT_DESC"] = "Bu seçenekler pencerenin başlık yazısını denetler."
L["STRING_OPTIONS_AUTO_SWITCH"] = "Tüm Roller |cFFFFAA00(savaşta)|r"
L["STRING_OPTIONS_AUTO_SWITCH_COMBAT"] = "|cFFFFAA00(savaşta)|r"
L["STRING_OPTIONS_AUTO_SWITCH_DAMAGER_DESC"] = "Hasar uzmanlığındayken bu pencere seçili özelliği ya da eklentiyi gösterir."
L["STRING_OPTIONS_AUTO_SWITCH_DESC"] = [=[Savaşa girdiğinde bu pencere seçili özelliği ya da eklentiyi gösterir.

|cFFFFFF00Önemli|r: Her rol için seçilen ayrı özellik, burada seçilen özelliğin yerine geçer.]=]
L["STRING_OPTIONS_AUTO_SWITCH_HEALER_DESC"] = "İyileştirici uzmanlığındayken bu pencere seçili özelliği ya da eklentiyi gösterir."
L["STRING_OPTIONS_AUTO_SWITCH_TANK_DESC"] = "Tank uzmanlığındayken bu pencere seçili özelliği ya da eklentiyi gösterir."
L["STRING_OPTIONS_AUTO_SWITCH_WIPE"] = "Wipe Sonrası"
L["STRING_OPTIONS_AUTO_SWITCH_WIPE_DESC"] = "Bir raid karşılaşmasında başarısız deneme ya da yenilgiden sonra bu pencere otomatik olarak bu özelliği gösterir."
L["STRING_OPTIONS_AVATAR"] = "Avatar Seç"
L["STRING_OPTIONS_AVATAR_ANCHOR"] = "Kimlik:"
L["STRING_OPTIONS_AVATAR_DESC"] = "Avatarlar lonca üyelerine de gönderilir ve ipuçlarının üstünde ve oyuncu ayrıntıları penceresinde gösterilir."
L["STRING_OPTIONS_BAR_BACKDROP_COLOR_DESC"] = "Kenarlık rengini değiştirir."
L["STRING_OPTIONS_BAR_BACKDROP_ENABLED_DESC"] = "Satır kenarlıklarını aç ya da kapat."
L["STRING_OPTIONS_BAR_BACKDROP_SIZE_DESC"] = "Kenarlık boyutunu ayarla."
L["STRING_OPTIONS_BAR_BACKDROP_TEXTURE_DESC"] = "Kenarlığın görünümünü değiştirir."
L["STRING_OPTIONS_BAR_BCOLOR"] = "Arka Plan Rengi"
L["STRING_OPTIONS_BAR_BTEXTURE_DESC"] = "Bu doku üst dokunun altında durur ve boyutu her zaman pencere genişliğiyle aynıdır."
L["STRING_OPTIONS_BAR_COLOR_DESC"] = [=[Bu dokunun rengi ve saydamlığı.

|cFFFFFF00Önemli|r: Sınıf renkleri kullanılırken seçilen renk yok sayılır.]=]
L["STRING_OPTIONS_BAR_COLORBYCLASS"] = "Oyuncu Sınıfına Göre Renk"
L["STRING_OPTIONS_BAR_COLORBYCLASS_DESC"] = "Açıksa bu doku her zaman oyuncunun sınıf rengini kullanır."
L["STRING_OPTIONS_BAR_FOLLOWING"] = "Beni Hep Göster"
L["STRING_OPTIONS_BAR_FOLLOWING_ANCHOR"] = "Oyuncu Çubuğu:"
L["STRING_OPTIONS_BAR_FOLLOWING_DESC"] = "Açıksa en üst sıradaki oyunculardan biri olmasan bile çubuğun her zaman gösterilir."
L["STRING_OPTIONS_BAR_GROW"] = "Çubuk Büyüme Yönü"
L["STRING_OPTIONS_BAR_GROW_DESC"] = "Çubuklar pencerenin üstünden ya da altından büyür."
L["STRING_OPTIONS_BAR_HEIGHT"] = "Çubuk Yüksekliği"
L["STRING_OPTIONS_BAR_HEIGHT_DESC"] = "Çubuk yüksekliğini artır ya da azalt."
L["STRING_OPTIONS_BAR_ICONFILE"] = "Simge Dosyası"
L["STRING_OPTIONS_BAR_ICONFILE_DESC"] = [=[Özel simge dosyasının yolu.

Görsel, alfa kanallı 256x256 piksel bir .tga dosyası olmalı.]=]
L["STRING_OPTIONS_BAR_ICONFILE_DESC2"] = "Kullanılacak simge paketini seç."
L["STRING_OPTIONS_BAR_ICONFILE1"] = "Simge Yok"
L["STRING_OPTIONS_BAR_ICONFILE2"] = "Varsayılan"
L["STRING_OPTIONS_BAR_ICONFILE3"] = "Varsayılan (siyah beyaz)"
L["STRING_OPTIONS_BAR_ICONFILE4"] = "Varsayılan (saydam)"
L["STRING_OPTIONS_BAR_ICONFILE5"] = "Yuvarlak Simgeler"
L["STRING_OPTIONS_BAR_ICONFILE6"] = "Varsayılan (saydam siyah beyaz)"
L["STRING_OPTIONS_BAR_SPACING"] = "Boşluk"
L["STRING_OPTIONS_BAR_SPACING_DESC"] = "Çubuklar arasındaki boşluk."
L["STRING_OPTIONS_BAR_TEXTURE_DESC"] = "Çubuğun üstünde kullanılan doku."
L["STRING_OPTIONS_BARLEFTTEXTCUSTOM"] = "Özel Yazı Açık"
L["STRING_OPTIONS_BARLEFTTEXTCUSTOM_DESC"] = "Özel bir yazı kullan; yazıyı aşağıdaki düğmeye tıklayarak düzenle."
L["STRING_OPTIONS_BARLEFTTEXTCUSTOM2"] = ""
L["STRING_OPTIONS_BARLEFTTEXTCUSTOM2_DESC"] = [=[|cFFFFFF00{data1}|r: genellikle oyuncunun sıra numarasını gösterir.

|cFFFFFF00{data2}|r: her zaman oyuncunun adıdır.

|cFFFFFF00{data3}|r: bazı durumlarda oyuncunun fraksiyon ya da rol simgesini gösterir.

|cFFFFFF00{func}|r: özel bir Lua işlevi çalıştırır ve dönüş değerini yazıya ekler.
Örnek: 
{func return 'hello azeroth'}

|cFFFFFF00Kaçış Dizileri|r: renk değiştirmek ya da doku eklemek için kullan. Daha fazla bilgi için 'UI escape sequences' ara.]=]
L["STRING_OPTIONS_BARORIENTATION"] = "Çubuk Yönü"
L["STRING_OPTIONS_BARORIENTATION_DESC"] = "Çubukların dolma yönü."
L["STRING_OPTIONS_BARRIGHTTEXTCUSTOM"] = "Özel Yazı Açık"
L["STRING_OPTIONS_BARRIGHTTEXTCUSTOM_DESC"] = "Açıksa sağ yazı kutudaki kurallara göre biçimlenir."
L["STRING_OPTIONS_BARRIGHTTEXTCUSTOM2"] = ""
L["STRING_OPTIONS_BARRIGHTTEXTCUSTOM2_DESC"] = [=[|cFFFFFF00{data1}|r: verilen ilk sayıdır, genellikle yapılan toplamı gösterir.

|cFFFFFF00{data2}|r: verilen ikinci sayıdır, çoğu zaman saniyedeki ortalamayı gösterir.

|cFFFFFF00{data3}|r: verilen üçüncü sayıdır, normalde yüzdedir. 

|cFFFFFF00{func}|r: özel bir Lua işlevi çalıştırır ve dönüş değerini yazıya ekler.
Örnek: 
{func return 'hello azeroth'}

|cFFFFFF00Kaçış Dizileri|r: renk değiştirmek ya da doku eklemek için kullan. Daha fazla bilgi için 'UI escape sequences' ara.]=]
L["STRING_OPTIONS_BARS"] = "Genel Çubuk Ayarları"
L["STRING_OPTIONS_BARS_CUSTOM_TEXTURE"] = "Özel Doku Dosyası"
L["STRING_OPTIONS_BARS_DESC"] = "Bu seçenekler çubukların görünümünü denetler."
L["STRING_OPTIONS_BARSORT"] = "Çubuk Sıra Düzeni"
L["STRING_OPTIONS_BARSORT_DESC"] = "Çubukları azalan ya da artan sırada diz."
L["STRING_OPTIONS_BARSTART_DESC"] = [=[Kapalıyken üst doku simgenin sağı yerine solundan başlar

Saydam alanları olan bir simge paketi kullanırken işe yarar.]=]
L["STRING_OPTIONS_BARUR_ANCHOR"] = "Hızlı Güncelleme"
L["STRING_OPTIONS_BARUR_DESC"] = "Açıksa DPS ve HPS değerleri her zamankinden biraz daha hızlı güncellenir."
L["STRING_OPTIONS_BG_ALL_ALLY"] = "Battleground'da Düşmanları Göster"
L["STRING_OPTIONS_BG_ALL_ALLY_DESC"] = [=[Açıksa pencere Grup Modundayken düşman oyuncular da gösterilir.

|cFFFFFF00Önemli|r: değişiklikler bir sonraki savaşa girişten sonra uygulanır.]=]
L["STRING_OPTIONS_BG_ANCHOR"] = "Battleground'lar:"
L["STRING_OPTIONS_BG_UNIQUE_SEGMENT"] = "Tek Bölümlü Battleground"
L["STRING_OPTIONS_BG_UNIQUE_SEGMENT_DESC"] = "Battleground'un başında bir bölüm oluşturulur ve bitene kadar sürer."
L["STRING_OPTIONS_CAURAS"] = "Auraları Topla"
L["STRING_OPTIONS_CAURAS_DESC"] = [=[Şunların toplanmasını aç:

- |cFFFFFF00Buff Süreleri|r
- |cFFFFFF00Debuff Süreleri|r
- |cFFFFFF00Yer Etkileri|r
-|cFFFFFF00 Bekleme Süreleri|r]=]
L["STRING_OPTIONS_CDAMAGE"] = "Hasarı Topla"
L["STRING_OPTIONS_CDAMAGE_DESC"] = [=[Şunların toplanmasını aç:

- |cFFFFFF00Verilen Hasar|r
- |cFFFFFF00Saniyedeki Hasar|r
- |cFFFFFF00Dost Ateşi|r
- |cFFFFFF00Alınan Hasar|r]=]
L["STRING_OPTIONS_CENERGY"] = "Enerjiyi Topla"
L["STRING_OPTIONS_CENERGY_DESC"] = [=[Şunların toplanmasını aç:

- |cFFFFFF00Geri Kazanılan Mana|r
- |cFFFFFF00Üretilen Öfke|r
- |cFFFFFF00Üretilen Enerji|r
- |cFFFFFF00Üretilen Runic Power|r]=]
L["STRING_OPTIONS_CHANGE_CLASSCOLORS"] = "Sınıf Renklerini Değiştir"
L["STRING_OPTIONS_CHANGE_CLASSCOLORS_DESC"] = "Sınıflar için yeni renkler seç."
L["STRING_OPTIONS_CHANGECOLOR"] = "Rengi Değiştir"
L["STRING_OPTIONS_CHANGELOG"] = "Sürüm Notları"
L["STRING_OPTIONS_CHART_ADD"] = "Veri Ekle"
L["STRING_OPTIONS_CHART_ADD2"] = "Ekle"
L["STRING_OPTIONS_CHART_ADDAUTHOR"] = "Yazar: "
L["STRING_OPTIONS_CHART_ADDCODE"] = "Kod: "
L["STRING_OPTIONS_CHART_ADDICON"] = "Simge: "
L["STRING_OPTIONS_CHART_ADDNAME"] = "Ad: "
L["STRING_OPTIONS_CHART_ADDVERSION"] = "Sürüm: "
L["STRING_OPTIONS_CHART_AUTHOR"] = "Yazar"
L["STRING_OPTIONS_CHART_AUTHORERROR"] = "Yazar adı geçersiz."
L["STRING_OPTIONS_CHART_CANCEL"] = "İptal"
L["STRING_OPTIONS_CHART_CLOSE"] = "Kapat"
L["STRING_OPTIONS_CHART_CODELOADED"] = "Kod zaten yüklü ve gösterilemiyor."
L["STRING_OPTIONS_CHART_EDIT"] = "Kodu Düzenle"
L["STRING_OPTIONS_CHART_EXPORT"] = "Dışa Aktar"
L["STRING_OPTIONS_CHART_FUNCERROR"] = "İşlev geçersiz."
L["STRING_OPTIONS_CHART_ICON"] = "Simge"
L["STRING_OPTIONS_CHART_IMPORT"] = "İçe Aktar"
L["STRING_OPTIONS_CHART_IMPORTERROR"] = "İçe aktarma metni geçersiz."
L["STRING_OPTIONS_CHART_NAME"] = "Ad"
L["STRING_OPTIONS_CHART_NAMEERROR"] = "Ad geçersiz."
L["STRING_OPTIONS_CHART_PLUGINWARNING"] = "Özel grafikleri göstermek için Chart Viewer eklentisini kur."
L["STRING_OPTIONS_CHART_REMOVE"] = "Kaldır"
L["STRING_OPTIONS_CHART_SAVE"] = "Kaydet"
L["STRING_OPTIONS_CHART_VERSION"] = "Sürüm"
L["STRING_OPTIONS_CHART_VERSIONERROR"] = "Sürüm geçersiz."
L["STRING_OPTIONS_CHEAL"] = "İyileştirmeyi Topla"
L["STRING_OPTIONS_CHEAL_DESC"] = [=[Şunların toplanmasını aç:

- |cFFFFFF00Yapılan İyileştirme|r
- |cFFFFFF00Emilenler|r
- |cFFFFFF00Saniyedeki İyileştirme|r
- |cFFFFFF00Fazla İyileştirme|r
- |cFFFFFF00Alınan İyileştirme|r
- |cFFFFFF00İyileştirilen Düşman|r
- |cFFFFFF00Önlenen Hasar|r]=]
L["STRING_OPTIONS_CLASSCOLOR_MODIFY"] = "Sınıf Renklerini Değiştir"
L["STRING_OPTIONS_CLASSCOLOR_RESET"] = "Sıfırlamak İçin Sağ Tıkla"
L["STRING_OPTIONS_CLEANUP"] = "Trash Bölümlerini Otomatik Sil"
L["STRING_OPTIONS_CLEANUP_DESC"] = "Açıksa trash temizliği bölümleri, iki bölüm daha geçtikten sonra otomatik silinir."
L["STRING_OPTIONS_CLICK_TO_OPEN_MENUS"] = "Menüleri Açmak İçin Tıkla"
L["STRING_OPTIONS_CLICK_TO_OPEN_MENUS_DESC"] = [=[Başlık çubuğu düğmeleri, üzerlerine gelince menülerini göstermez.

Açmak için tıklaman gerekir.]=]
L["STRING_OPTIONS_CLOUD"] = "Bulut Yakalama"
L["STRING_OPTIONS_CLOUD_DESC"] = "Açıksa kapalı toplayıcıların verileri diğer raid üyelerinden toplanır."
L["STRING_OPTIONS_CMISC"] = "Diğerlerini Topla"
L["STRING_OPTIONS_CMISC_DESC"] = [=[Şunların toplanmasını aç:

- |cFFFFFF00Kitle Kontrolü Bozma|r
- |cFFFFFF00Dispel'ler|r
- |cFFFFFF00Kesmeler|r
- |cFFFFFF00Diriltme|r
- |cFFFFFF00Ölümler|r]=]
L["STRING_OPTIONS_COLORANDALPHA"] = "Renk ve Saydamlık"
L["STRING_OPTIONS_COLORFIXED"] = "Sabit Renk"
L["STRING_OPTIONS_COMBAT_ALPHA"] = "Ne Zaman"
L["STRING_OPTIONS_COMBAT_ALPHA_2"] = "Savaştayken"
L["STRING_OPTIONS_COMBAT_ALPHA_3"] = "Savaş Dışındayken"
L["STRING_OPTIONS_COMBAT_ALPHA_4"] = "Grupta Değilken"
L["STRING_OPTIONS_COMBAT_ALPHA_5"] = "Zindan Dışındayken"
L["STRING_OPTIONS_COMBAT_ALPHA_6"] = "Zindan İçindeyken"
L["STRING_OPTIONS_COMBAT_ALPHA_7"] = "Raid Hata Ayıklama"
L["STRING_OPTIONS_COMBAT_ALPHA_8"] = "Battleground'da"
L["STRING_OPTIONS_COMBAT_ALPHA_9"] = "Mythic+'ta"
L["STRING_OPTIONS_COMBAT_ALPHA_DESC"] = [=[Savaşın pencere saydamlığını nasıl etkileyeceğini seç.

|cFFFFFF00Değişiklik Yok|r: Saydamlığı değiştirmez.

|cFFFFFF00Savaştayken|r: Karakterin savaşa girdiğinde seçilen saydamlık pencereye uygulanır.

|cFFFFFF00Savaş Dışındayken|r: Karakterin savaşta olmadığı her an saydamlık uygulanır.

|cFFFFFF00Grupta Değilken|r: Bir grupta ya da raid grubunda değilken pencere seçilen saydamlığı alır.

|cFFFFFF00Önemli|r: Bu seçenek, Otomatik Saydamlık özelliğinin belirlediği saydamlığın yerine geçer.]=]
L["STRING_OPTIONS_COMBATTWEEKS"] = "Savaş Ayarları"
L["STRING_OPTIONS_COMBATTWEEKS_DESC"] = "Details!'in bazı savaş durumlarını nasıl ele alacağına dair davranış ayarları."
L["STRING_OPTIONS_CONFIRM_ERASE"] = "Veriyi silmek istiyor musun?"
L["STRING_OPTIONS_CUSTOMSPELL_ADD"] = "Büyü Ekle"
L["STRING_OPTIONS_CUSTOMSPELLTITLE"] = "Büyü Ayarlarını Düzenle"
L["STRING_OPTIONS_CUSTOMSPELLTITLE_DESC"] = "Bu panel büyülerin adını ve simgesini değiştirmeni sağlar."
L["STRING_OPTIONS_DATABROKER"] = "Data Broker:"
L["STRING_OPTIONS_DATABROKER_TEXT"] = "Yazı"
L["STRING_OPTIONS_DATABROKER_TEXT_ADD1"] = "Oyuncunun Verdiği Hasar"
L["STRING_OPTIONS_DATABROKER_TEXT_ADD2"] = "Oyuncu Etkin DPS"
L["STRING_OPTIONS_DATABROKER_TEXT_ADD3"] = "Hasar Konumu"
L["STRING_OPTIONS_DATABROKER_TEXT_ADD4"] = "Hasar Farkı"
L["STRING_OPTIONS_DATABROKER_TEXT_ADD5"] = "Oyuncunun Yaptığı İyileştirme"
L["STRING_OPTIONS_DATABROKER_TEXT_ADD6"] = "Oyuncu Etkin HPS"
L["STRING_OPTIONS_DATABROKER_TEXT_ADD7"] = "İyileştirme Konumu"
L["STRING_OPTIONS_DATABROKER_TEXT_ADD8"] = "İyileştirme Farkı"
L["STRING_OPTIONS_DATABROKER_TEXT_ADD9"] = "Geçen Savaş Süresi"
L["STRING_OPTIONS_DATABROKER_TEXT1_DESC"] = [=[|cFFFFFF00{dmg}|r: oyuncunun verdiği hasar.

|cFFFFFF00{dps}|r: oyuncunun etkin saniyedeki hasarı.

|cFFFFFF00{rdps}|r: raidin etkin saniyedeki hasarı.

|cFFFFFF00{dpos}|r: raid ya da grup üyeleri arasındaki hasar sıralaması.

|cFFFFFF00{ddiff}|r: seninle birinci sıradaki arasındaki hasar farkı.

|cFFFFFF00{heal}|r: oyuncunun yaptığı iyileştirme.

|cFFFFFF00{hps}|r: oyuncunun etkin saniyedeki iyileştirmesi.

|cFFFFFF00{rhps}|r: raidin etkin saniyedeki iyileştirmesi.

|cFFFFFF00{hpos}|r: raid ya da grup üyeleri arasındaki iyileştirme sıralaması.

|cFFFFFF00{hdiff}|r: seninle birinci sıradaki arasındaki iyileştirme farkı.

|cFFFFFF00{time}|r: dövüşte geçen süre.]=]
L["STRING_OPTIONS_DATACHARTTITLE"] = "Grafikler İçin Zamanlı Veri Oluştur"
L["STRING_OPTIONS_DATACHARTTITLE_DESC"] = "Bu panel, grafik oluşturmak için özel veri yakalama tanımlamanı sağlar."
L["STRING_OPTIONS_DATACOLLECT_ANCHOR"] = "Veri Türleri:"
L["STRING_OPTIONS_DEATHLIMIT"] = "Ölüm Olayı Sayısı"
L["STRING_OPTIONS_DEATHLIMIT_DESC"] = [=[Ölüm ekranında gösterilecek olay sayısını ayarla.

|cFFFFFF00Önemli|r: yalnızca değişiklikten sonraki yeni ölümlere uygulanır.]=]
L["STRING_OPTIONS_DEATHLOG_MINHEALING"] = "Ölüm Kaydı En Az İyileştirme"
L["STRING_OPTIONS_DEATHLOG_MINHEALING_DESC"] = [=[Ölüm kaydı bu eşiğin altındaki iyileştirmeleri göstermez.

|cFFFFFF00İpucu|r: değeri elle girmek için sağ tıkla.]=]
L["STRING_OPTIONS_DESATURATE_MENU_DESC"] = "Bu seçenek açılınca araç çubuğundaki tüm menü simgeleri siyah beyaz olur."
L["STRING_OPTIONS_DISABLE_ALLDISPLAYSWINDOW"] = "'Tüm Görünümler' Menüsünü Kapat"
L["STRING_OPTIONS_DISABLE_ALLDISPLAYSWINDOW_DESC"] = "Açıksa başlık çubuğuna sağ tıklamak bunun yerine yer imlerini gösterir."
L["STRING_OPTIONS_DISABLE_BARHIGHLIGHT"] = "Çubuk Vurgusunu Kapat"
L["STRING_OPTIONS_DISABLE_BARHIGHLIGHT_DESC"] = "Bir çubuğun üzerine gelmek onu parlatmaz."
L["STRING_OPTIONS_DISABLE_GROUPS"] = "Gruplamayı Kapat"
L["STRING_OPTIONS_DISABLE_GROUPS_DESC"] = "Pencereler birbirine yaklaştırıldığında artık grup oluşturmaz."
L["STRING_OPTIONS_DISABLE_LOCK_RESIZE"] = "Boyutlandırma Düğmelerini Kapat"
L["STRING_OPTIONS_DISABLE_LOCK_RESIZE_DESC"] = "Bir pencerenin üzerine gelince boyutlandır, kilitle/kilidi aç ve grubu ayır düğmeleri görünmez."
L["STRING_OPTIONS_DISABLE_RESET"] = "Sıfırla Düğmesi Tıklamasını Kapat"
L["STRING_OPTIONS_DISABLE_RESET_DESC"] = "Açıksa sıfırla düğmesine tıklamak işe yaramaz; veriyi ipucu menüsünden sıfırlamayı seçmelisin."
L["STRING_OPTIONS_DISABLE_STRETCH_BUTTON"] = "Uzatma Düğmesini Kapat"
L["STRING_OPTIONS_DISABLE_STRETCH_BUTTON_DESC"] = "Bu seçenek açıkken uzatma düğmesi gösterilmez."
L["STRING_OPTIONS_DISABLED_RESET"] = "Bu düğmeyle sıfırlama şu anda kapalı; ipucu menüsünden seç."
L["STRING_OPTIONS_DTAKEN_EVERYTHING"] = "Gelişmiş Alınan Hasar"
L["STRING_OPTIONS_DTAKEN_EVERYTHING_DESC"] = "Alınan hasar '|cFFFFFF00Her Şey|r' modunda her zaman gösterilir."
L["STRING_OPTIONS_ED"] = "Veriyi Sil"
L["STRING_OPTIONS_ED_DESC"] = [=[|cFFFFFF00Elle|r: kullanıcının sıfırla düğmesine tıklaması gerekir.

|cFFFFFF00Sor|r: yeni bir zindana girince sıfırlamayı sor.

|cFFFFFF00Otomatik|r: yeni bir zindana girince veriyi temizle.]=]
L["STRING_OPTIONS_ED1"] = "Elle"
L["STRING_OPTIONS_ED2"] = "Sor"
L["STRING_OPTIONS_ED3"] = "Otomatik"
L["STRING_OPTIONS_EDIT_CUSTOM_TEXT"] = "Özel Yazıyı Düzenle"
L["STRING_OPTIONS_EDITIMAGE"] = "Görseli Düzenle"
L["STRING_OPTIONS_EDITINSTANCE"] = "Düzenlenen Pencere:"
L["STRING_OPTIONS_ERASECHARTDATA"] = "Grafikleri Sil"
L["STRING_OPTIONS_ERASECHARTDATA_DESC"] = "Çıkışta, grafik oluşturmak için toplanan tüm savaş verileri silinir."
L["STRING_OPTIONS_EXPORT_PROFILE"] = "Profili Dışa Aktar"
L["STRING_OPTIONS_EXTERNALS_TITLE"] = "Harici Bileşenler"
L["STRING_OPTIONS_EXTERNALS_TITLE2"] = "Bu seçenekler birçok harici bileşenin davranışını denetler."
L["STRING_OPTIONS_GENERAL"] = "Genel Ayarlar"
L["STRING_OPTIONS_GENERAL_ANCHOR"] = "Genel:"
L["STRING_OPTIONS_GROUPING_HORIZONTAL_GAP"] = "\"Pencereler Arası Boşluk\""
L["STRING_OPTIONS_HIDE_ICON"] = "Simgeyi Gizle"
L["STRING_OPTIONS_HIDE_ICON_DESC"] = [=[Açıksa seçili görünümü temsil eden simge gösterilmez.

|cFFFFFF00Önemli|r: simgeyi açtıktan sonra başlık yazısının yerini ayarlaman önerilir.]=]
L["STRING_OPTIONS_HIDECOMBATALPHA_DESC"] = [=[Karakterin seçilen kurala uyduğunda saydamlığı bu değere değiştirir.

|cFFFFFF00Sıfır|r: tamamen gizli, pencereyle etkileşime girilemez.

|cFFFFFF001 - 100|r: gizli değil, yalnızca saydamlık değişir, pencereyle etkileşime girebilirsin.]=]
L["STRING_OPTIONS_HOTCORNER"] = "Düğmeyi göster"
L["STRING_OPTIONS_HOTCORNER_ACTION"] = "Tıklayınca"
L["STRING_OPTIONS_HOTCORNER_ACTION_DESC"] = "Sıcak köşe çubuğundaki düğmeye farenin sol tuşuyla tıklanınca ne yapılacağını seç."
L["STRING_OPTIONS_HOTCORNER_ANCHOR"] = "Sıcak köşe:"
L["STRING_OPTIONS_HOTCORNER_DESC"] = "Sıcak köşe panelinin üzerindeki düğmeyi göster ya da gizle."
L["STRING_OPTIONS_HOTCORNER_QUICK_CLICK"] = "Hızlı Tıklamayı Aç"
L["STRING_OPTIONS_HOTCORNER_QUICK_CLICK_DESC"] = [=[Sıcak köşeler için Hızlı Tıklama özelliğini açar ya da kapatır.

Hızlı düğme en sol üstteki pikselde bulunur; fareyi oraya kadar götürmek sol üst sıcak köşeyi etkinleştirir, tıklanırsa bir işlem yapılır.]=]
L["STRING_OPTIONS_HOTCORNER_QUICK_CLICK_FUNC"] = "Tıklayınca Hızlı Tıklama"
L["STRING_OPTIONS_HOTCORNER_QUICK_CLICK_FUNC_DESC"] = "Sıcak köşedeki Hızlı Tıklama düğmesine tıklanınca ne yapılacağını seç."
L["STRING_OPTIONS_IGNORENICKNAME"] = "Takma Adları ve Avatarları Yok Say"
L["STRING_OPTIONS_IGNORENICKNAME_DESC"] = "Açıksa diğer lonca üyelerinin belirlediği takma adlar ve avatarlar yok sayılır."
L["STRING_OPTIONS_ILVL_TRACKER"] = "Eşya Seviyesi Takipçisi:"
L["STRING_OPTIONS_ILVL_TRACKER_DESC"] = [=[Açıksa ve savaş dışındaysan eklenti raiddeki oyuncuların eşya seviyesini sorgular ve takip eder.

Kapalıyken de diğer eklentilerin sorgularından ya da başka bir oyuncuyu elle incelediğinde eşya seviyesini okur.]=]
L["STRING_OPTIONS_ILVL_TRACKER_TEXT"] = "Etkin"
L["STRING_OPTIONS_IMPORT_PROFILE"] = "Profil İçe Aktar"
L["STRING_OPTIONS_IMPORT_PROFILE_NAME"] = "Yeni Profil İçin Bir Ad Gir"
L["STRING_OPTIONS_IMPORT_PROFILE_PASTE"] = "Details! Profil İçe Aktar (metni yapıştır)"
L["STRING_OPTIONS_INSTANCE_BACKDROP"] = "Arka Plan Dokusu"
L["STRING_OPTIONS_INSTANCE_BACKDROP_DESC"] = [=[Bu pencerenin kullandığı arka plan dokusunu seç.

|cFFFFFF00Varsayılan|r: Details Arka Planı.]=]
L["STRING_OPTIONS_INSTANCE_CURRENT"] = "Otomatik Olarak Şimdikine Geç"
L["STRING_OPTIONS_INSTANCE_CURRENT_DESC"] = "Bir savaş başladığında bu pencere otomatik olarak şimdiki bölüme geçer."
L["STRING_OPTIONS_INSTANCE_DELETE"] = "Sil"
L["STRING_OPTIONS_INSTANCE_DELETE_DESC"] = [=[Bir pencereyi kalıcı olarak kaldır.
Silme işlemi sırasında oyun ekranın yeniden yüklenebilir.]=]
L["STRING_OPTIONS_INSTANCE_SKIN"] = "Görünüm"
L["STRING_OPTIONS_INSTANCE_SKIN_DESC"] = "Pencere görünümünü bir görünüm temasına göre değiştir."
L["STRING_OPTIONS_INSTANCE_STATUSBAR_ANCHOR"] = "Durum Çubuğu"
L["STRING_OPTIONS_INSTANCE_STATUSBARCOLOR_DESC"] = [=[Durum çubuğunun rengini seç.

|cFFFFFF00Önemli|r: bu seçenek, Pencere Rengi'nde seçilen renk ve saydamlığın yerine geçer.]=]
L["STRING_OPTIONS_INSTANCE_STRATA"] = "Katman Seviyesi"
L["STRING_OPTIONS_INSTANCE_STRATA_DESC"] = [=[Çerçevenin yerleştirileceği katman yüksekliğini seçer.

Düşük katman varsayılandır ve pencerenin diğer arayüz panellerinin çoğunun arkasında kalmasını sağlar.

Yüksek katmanda pencere diğer büyük panellerin önünde kalabilir.

Katman yüksekliğini değiştirirken panellerin üst üste binmesiyle çakışmalar yaşayabilirsin.]=]
L["STRING_OPTIONS_INSTANCES"] = "Pencereler:"
L["STRING_OPTIONS_INTERFACEDIT"] = "Arayüz Düzenleme Modu"
L["STRING_OPTIONS_LOCKSEGMENTS"] = "Bölümler Kilitli"
L["STRING_OPTIONS_LOCKSEGMENTS_DESC"] = "Açıksa bölümü değiştirmek diğer tüm pencereleri de seçili bölüme geçirir."
L["STRING_OPTIONS_MANAGE_BOOKMARKS"] = "Yer İmlerini Yönet"
L["STRING_OPTIONS_MAXINSTANCES"] = "Pencere Sayısı"
L["STRING_OPTIONS_MAXINSTANCES_DESC"] = [=[Oluşturulabilecek pencere sayısını sınırla.

Pencerelerini Pencere Kontrolü menüsünden yönetebilirsin.]=]
L["STRING_OPTIONS_MAXSEGMENTS"] = "Bölüm Sayısı"
L["STRING_OPTIONS_MAXSEGMENTS_DESC"] = "Kaç bölüm saklamak istediğini denetler."
L["STRING_OPTIONS_MENU_ALPHA"] = "Fare Etkileşimi:"
L["STRING_OPTIONS_MENU_ALPHAENABLED_DESC"] = [=[Açıksa fareyle pencerenin üzerine gelip ayrıldığında saydamlık otomatik değişir.

|cFFFFFF00Önemli|r: Bu ayar, Pencere Ayarları bölümündeki Pencere Rengi seçeneğinde seçilen saydamlığın yerine geçer.]=]
L["STRING_OPTIONS_MENU_ALPHAENTER"] = "Üzerine Gelince"
L["STRING_OPTIONS_MENU_ALPHAENTER_DESC"] = "Fare pencerenin üzerindeyken saydamlık bu değere değişir."
L["STRING_OPTIONS_MENU_ALPHALEAVE"] = "Etkileşim Yok"
L["STRING_OPTIONS_MENU_ALPHALEAVE_DESC"] = "Fare pencerenin üzerinde değilken saydamlık bu değere değişir."
L["STRING_OPTIONS_MENU_ALPHAWARNING"] = "Fare Etkileşimi açık, saydamlık etkilenmeyebilir."
L["STRING_OPTIONS_MENU_ANCHOR"] = "Düğmeler Sağa Tuttursun"
L["STRING_OPTIONS_MENU_ANCHOR_DESC"] = "İşaretliyse düğmeler pencerenin sağ tarafına tutturulur."
L["STRING_OPTIONS_MENU_ATTRIBUTE_ANCHORX_DESC"] = "Özellik yazısının X eksenindeki yerini ayarla."
L["STRING_OPTIONS_MENU_ATTRIBUTE_ANCHORY_DESC"] = "Özellik yazısının Y eksenindeki yerini ayarla."
L["STRING_OPTIONS_MENU_ATTRIBUTE_ENABLED_DESC"] = "Etkin, pencerede şu anda gösterilen görünümün adını gösterir."
L["STRING_OPTIONS_MENU_ATTRIBUTE_ENCOUNTERTIMER_DESC"] = "Açıksa yazının sol tarafında bir kronometre gösterilir."
--[[Translation missing --]]
L["STRING_OPTIONS_MENU_ATTRIBUTE_FONT"] = ""
L["STRING_OPTIONS_MENU_ATTRIBUTE_FONT_DESC"] = "Özellik yazısı için yazı tipini seç."
L["STRING_OPTIONS_MENU_ATTRIBUTE_SHADOW_DESC"] = "Yazıdaki gölgeyi açar ya da kapatır."
L["STRING_OPTIONS_MENU_ATTRIBUTE_SIDE"] = "Üst Kenara Tuttur"
L["STRING_OPTIONS_MENU_ATTRIBUTE_SIDE_DESC"] = "Yazının nereye sabitleneceğini seç."
L["STRING_OPTIONS_MENU_ATTRIBUTE_TEXTCOLOR"] = "Yazı Rengi"
L["STRING_OPTIONS_MENU_ATTRIBUTE_TEXTCOLOR_DESC"] = "Özellik yazısının rengini değiştir."
--[[Translation missing --]]
L["STRING_OPTIONS_MENU_ATTRIBUTE_TEXTSIZE"] = ""
L["STRING_OPTIONS_MENU_ATTRIBUTE_TEXTSIZE_DESC"] = "Özellik yazısının boyutunu ayarla."
L["STRING_OPTIONS_MENU_ATTRIBUTESETTINGS_ANCHOR"] = "Ayarlar:"
L["STRING_OPTIONS_MENU_AUTOHIDE_DESC"] = "Fare pencereden çıkınca düğmeleri otomatik gizle, pencereyle yeniden etkileşime geçince göster."
L["STRING_OPTIONS_MENU_AUTOHIDE_LEFT"] = "Düğmeleri Otomatik Gizle"
L["STRING_OPTIONS_MENU_BUTTONSSIZE_DESC"] = "Düğme boyutunu seç. Bu, eklentilerin eklediği düğmeleri de değiştirir."
L["STRING_OPTIONS_MENU_FONT_FACE"] = "Menü Yazı Tipi"
L["STRING_OPTIONS_MENU_FONT_FACE_DESC"] = "Tüm menülerde kullanılan yazı tipini değiştir."
L["STRING_OPTIONS_MENU_FONT_SIZE"] = "Menü Yazı Boyutu"
L["STRING_OPTIONS_MENU_FONT_SIZE_DESC"] = "Tüm menülerdeki yazı boyutunu değiştir."
L["STRING_OPTIONS_MENU_IGNOREBARS"] = "Çubukları Yok Say"
L["STRING_OPTIONS_MENU_IGNOREBARS_DESC"] = "Açıksa bu penceredeki hiçbir satır bu mekanizmadan etkilenmez."
L["STRING_OPTIONS_MENU_SHOWBUTTONS_DESC"] = "Başlık çubuğunda hangi düğmelerin gösterileceğini seç."
L["STRING_OPTIONS_MENU_X"] = "X Konumu"
L["STRING_OPTIONS_MENU_X_DESC"] = "X ekseni konumunu değiştirir."
L["STRING_OPTIONS_MENU_Y"] = "Y Konumu"
L["STRING_OPTIONS_MENU_Y_DESC"] = "Y ekseni konumunu değiştirir"
L["STRING_OPTIONS_MENUS_SHADOW"] = "Gölge"
L["STRING_OPTIONS_MENUS_SHADOW_DESC"] = "Tüm düğmelere ince bir gölge kenarlığı ekler."
L["STRING_OPTIONS_MENUS_SPACEMENT_DESC"] = "Düğmeler arasındaki mesafeyi denetler."
L["STRING_OPTIONS_MICRODISPLAY_ANCHOR"] = "Mikro Görünümler:"
L["STRING_OPTIONS_MICRODISPLAY_LOCK"] = "Mikro Görünümleri Kilitle"
L["STRING_OPTIONS_MICRODISPLAY_LOCK_DESC"] = "Kilitliyken fareyle üzerine gelmeye ve tıklamaya tepki vermezler."
L["STRING_OPTIONS_MICRODISPLAYS_DROPDOWN_TOOLTIP"] = "Bu tarafta gösterilecek mikro görünümü seç."
L["STRING_OPTIONS_MICRODISPLAYS_OPTION_TOOLTIP"] = "Bu mikro görünümün ayarını yap."
L["STRING_OPTIONS_MICRODISPLAYS_SHOWHIDE_TOOLTIP"] = "Bu Mikro Görünümü Göster ya da Gizle"
L["STRING_OPTIONS_MICRODISPLAYS_WARNING"] = [=[|cFFFFFF00Not|r: mikro görünümler gösterilemiyor çünkü
alt kenara sabitlenmişler
ve durum çubuğu kapalı.]=]
L["STRING_OPTIONS_MICRODISPLAYSSIDE"] = "Mikro Görünümler Üstte"
L["STRING_OPTIONS_MICRODISPLAYSSIDE_DESC"] = "Mikro görünümleri pencerenin üstüne ya da altına yerleştir."
L["STRING_OPTIONS_MICRODISPLAYWARNING"] = "Durum çubuğu kapalı olduğu için mikro görünümler gösterilmiyor."
L["STRING_OPTIONS_MINIMAP"] = "Simgeyi Göster"
L["STRING_OPTIONS_MINIMAP_ACTION"] = "Tıklayınca"
L["STRING_OPTIONS_MINIMAP_ACTION_DESC"] = "Minimapteki simgeye farenin sol tuşuyla tıklanınca ne yapılacağını seç."
L["STRING_OPTIONS_MINIMAP_ACTION1"] = "Ayarlar Panelini Aç"
L["STRING_OPTIONS_MINIMAP_ACTION2"] = "Bölümleri Sıfırla"
L["STRING_OPTIONS_MINIMAP_ACTION3"] = "Pencereleri Göster/Gizle"
L["STRING_OPTIONS_MINIMAP_ANCHOR"] = "Minimap:"
L["STRING_OPTIONS_MINIMAP_DESC"] = "Minimap simgesini göster ya da gizle."
L["STRING_OPTIONS_MISCTITLE"] = "Çeşitli Ayarlar"
L["STRING_OPTIONS_MISCTITLE2"] = "Bunlar çeşitli seçenekleri denetler."
L["STRING_OPTIONS_MPLUS_AUTO_CLOSE_TIME"] = "Otomatik Kapanma Süresi"
L["STRING_OPTIONS_MPLUS_AUTO_CLOSE_TIME_DESC"] = "M+ Sonu Panelini otomatik kapatma süresi."
L["STRING_OPTIONS_MPLUS_BOSSNEWCOMBAT"] = "Boss Çekilince Yeni Savaş"
L["STRING_OPTIONS_MPLUS_BOSSNEWCOMBAT_DESC"] = "Savaştayken bir boss çekilirse bu seçenek şimdiki savaşı kapatır ve boss için yenisini başlatır."
L["STRING_OPTIONS_MPLUS_DPS_ANCHOR"] = "Genel Bölüm DPS Hesabı"
L["STRING_OPTIONS_MPLUS_MERGETRASH"] = "Trash'i Birleştir"
L["STRING_OPTIONS_MPLUS_PANELS_ANCHOR"] = "Paneller"
L["STRING_OPTIONS_MPLUS_SHOWENDPANEL"] = "M+ Sonu Panelini Göster"
L["STRING_OPTIONS_MPLUS_TIME_INCOMBAT"] = "Savaşta Geçen Süre"
L["STRING_OPTIONS_MPLUS_TIME_INCOMBAT_DESC"] = "Mythic+ koşusunun genel bölümü DPS'i hesaplamak için 'toplamHasar / toplamSavaşSüresi' kullanır."
L["STRING_OPTIONS_MPLUS_TIME_RUNTIME"] = "Zindan Koşu Süresi"
L["STRING_OPTIONS_MPLUS_TIME_RUNTIME_DESC"] = "Mythic+ koşusunun genel bölümü DPS'i 'toplamHasar / koşuSüresi' ile hesaplar."
L["STRING_OPTIONS_NICKNAME"] = "Takma Ad"
L["STRING_OPTIONS_NICKNAME_DESC"] = [=[Kendin için bir takma ad belirle.

Takma adlar lonca üyelerine gönderilir ve Details! karakter adın yerine onu kullanır.]=]
L["STRING_OPTIONS_OPEN_ROWTEXT_EDITOR"] = "Satır Yazı Düzenleyicisi"
L["STRING_OPTIONS_OPEN_TEXT_EDITOR"] = "Yazı Düzenleyicisini Aç"
L["STRING_OPTIONS_OPENBROKER"] = "Broker Yazı Düzenleyicisini Aç"
L["STRING_OPTIONS_OVERALL_ALL"] = "Tüm Bölümler"
L["STRING_OPTIONS_OVERALL_ALL_DESC"] = "Tüm bölümler genel veriye eklenir."
L["STRING_OPTIONS_OVERALL_ANCHOR"] = "Genel Veri:"
L["STRING_OPTIONS_OVERALL_DUNGEONBOSS"] = "Zindan Boss'ları"
L["STRING_OPTIONS_OVERALL_DUNGEONBOSS_DESC"] = "Zindan boss'larının olduğu bölümler genel veriye eklenir."
L["STRING_OPTIONS_OVERALL_DUNGEONCLEAN"] = "Zindan Trash'i"
L["STRING_OPTIONS_OVERALL_DUNGEONCLEAN_DESC"] = "Zindan trash temizliği bölümleri genel veriye eklenir."
L["STRING_OPTIONS_OVERALL_LOGOFF"] = "Çıkışta Temizle"
L["STRING_OPTIONS_OVERALL_LOGOFF_DESC"] = "Açıksa karakterden çıkış yaptığında genel veri otomatik silinir."
L["STRING_OPTIONS_OVERALL_MYTHICPLUS"] = "Mythic+ Başlarken Temizle"
L["STRING_OPTIONS_OVERALL_MYTHICPLUS_DESC"] = "Açıksa yeni bir mythic+ koşusu başladığında genel veri otomatik silinir."
L["STRING_OPTIONS_OVERALL_NEWBOSS"] = "Yeni Raid Boss'unda Temizle"
L["STRING_OPTIONS_OVERALL_NEWBOSS_DESC"] = "Açıksa farklı bir raid boss'uyla karşılaşınca genel veri otomatik silinir."
L["STRING_OPTIONS_OVERALL_RAIDBOSS"] = "Raid Boss'ları"
L["STRING_OPTIONS_OVERALL_RAIDBOSS_DESC"] = "Raid karşılaşmalarının olduğu bölümler genel veriye eklenir."
L["STRING_OPTIONS_OVERALL_RAIDCLEAN"] = "Raid Trash'i"
L["STRING_OPTIONS_OVERALL_RAIDCLEAN_DESC"] = "Raid trash temizliği bölümleri genel veriye eklenir."
L["STRING_OPTIONS_PANIMODE"] = "Panik Modu"
L["STRING_OPTIONS_PANIMODE_DESC"] = "Açıksa, bir boss karşılaşmasında savaşırken oyundan düşersen (örneğin bağlantı kopunca) tüm bölümler silinir; bu çıkış işlemini hızlandırır."
L["STRING_OPTIONS_PDW_ANCHOR"] = "Paneller:"
L["STRING_OPTIONS_PDW_SKIN_DESC"] = [=[Oyuncu Ayrıntıları Penceresi, Rapor Penceresi ve Ayarlar Panelinde kullanılacak görünüm.
Bazı değişiklikler /reload gerektirir.]=]
L["STRING_OPTIONS_PERCENT_TYPE_DESC"] = [=[Yüzde yöntemini değiştirir:

|cFFFFFF00Toplama Göre|r: yüzde, tüm raid üyelerinin yaptığı toplam miktarın etkin oranını gösterir.

|cFFFFFF00En İyi Oyuncuya Göre|r: yüzde, en iyi oyuncunun puanına göredir.]=]
L["STRING_OPTIONS_PERFORMANCE"] = "Performans"
L["STRING_OPTIONS_PERFORMANCE_ANCHOR"] = "Genel:"
L["STRING_OPTIONS_PERFORMANCE_ARENA"] = "Arena"
L["STRING_OPTIONS_PERFORMANCE_BG15"] = "Battleground 15"
L["STRING_OPTIONS_PERFORMANCE_BG40"] = "Battleground 40"
L["STRING_OPTIONS_PERFORMANCE_DUNGEON"] = "Zindan"
L["STRING_OPTIONS_PERFORMANCE_ENABLE_DESC"] = "Açıksa bu ayar, raidin seçili raid türüyle eşleştiğinde uygulanır."
L["STRING_OPTIONS_PERFORMANCE_ERASEWORLD"] = "Dünya Bölümlerini Otomatik Sil"
L["STRING_OPTIONS_PERFORMANCE_ERASEWORLD_DESC"] = "Dışarıda savaştayken bölümleri otomatik sil."
L["STRING_OPTIONS_PERFORMANCE_MYTHIC"] = "Efsanevi"
L["STRING_OPTIONS_PERFORMANCE_PROFILE_LOAD"] = "Performans Profili Değişti: "
L["STRING_OPTIONS_PERFORMANCE_RAID15"] = "Raid 10-15"
L["STRING_OPTIONS_PERFORMANCE_RAID30"] = "Raid 16-30"
L["STRING_OPTIONS_PERFORMANCE_RF"] = "Raid Bulucu"
L["STRING_OPTIONS_PERFORMANCE_TYPES"] = "Tür"
L["STRING_OPTIONS_PERFORMANCE_TYPES_DESC"] = "Bu, farklı seçeneklerin otomatik olarak değişebileceği raid türüdür."
L["STRING_OPTIONS_PERFORMANCE1"] = "Performans Ayarları"
L["STRING_OPTIONS_PERFORMANCE1_DESC"] = "Bu seçenekler işlemci kullanımından tasarruf etmeye yardımcı olabilir."
L["STRING_OPTIONS_PERFORMANCECAPTURES"] = "Veri Toplayıcı"
L["STRING_OPTIONS_PERFORMANCECAPTURES_DESC"] = "Bu seçenekler savaş verilerinin analizinden ve toplanmasından sorumludur."
L["STRING_OPTIONS_PERFORMANCEPROFILES_ANCHOR"] = "Performans Profilleri:"
L["STRING_OPTIONS_PICONS_DIRECTION"] = "Eklentiler Sağa Tuttursun"
L["STRING_OPTIONS_PICONS_DIRECTION_DESC"] = "İşaretliyse eklenti düğmeleri menü düğmelerinin sağında gösterilir."
L["STRING_OPTIONS_PLUGINS"] = "Eklentiler"
L["STRING_OPTIONS_PLUGINS_AUTHOR"] = "Yazar"
L["STRING_OPTIONS_PLUGINS_NAME"] = "Ad"
L["STRING_OPTIONS_PLUGINS_OPTIONS"] = "Seçenekler"
L["STRING_OPTIONS_PLUGINS_RAID_ANCHOR"] = "Raid Eklentileri"
L["STRING_OPTIONS_PLUGINS_SOLO_ANCHOR"] = "Tek Başına Eklentileri"
L["STRING_OPTIONS_PLUGINS_TOOLBAR_ANCHOR"] = "Başlık Çubuğu Eklentileri"
L["STRING_OPTIONS_PLUGINS_VERSION"] = "Sürüm"
L["STRING_OPTIONS_PRESETNONAME"] = "Ön ayarına bir ad ver."
L["STRING_OPTIONS_PRESETTOOLD"] = "Bu ön ayar çok eski, Details!'in bu sürümüyle yüklenemez."
L["STRING_OPTIONS_PROFILE_COPYOKEY"] = "Profil başarıyla kopyalandı."
L["STRING_OPTIONS_PROFILE_FIELDEMPTY"] = "Ad alanı boş."
L["STRING_OPTIONS_PROFILE_GLOBAL"] = "Tüm karakterlerde kullanılacak profili seç."
L["STRING_OPTIONS_PROFILE_LOADED"] = "Profil yüklendi:"
L["STRING_OPTIONS_PROFILE_NOTCREATED"] = "Profil oluşturulamadı."
L["STRING_OPTIONS_PROFILE_OVERWRITTEN"] = "bu karakter için belirli bir profil seçtin"
L["STRING_OPTIONS_PROFILE_POSSIZE"] = "Boyutu ve Konumu Kaydet"
L["STRING_OPTIONS_PROFILE_POSSIZE_DESC"] = "Pencerenin konumunu ve boyutunu profilde kaydet. Kapalıyken her karakterin kendi değerleri olur."
L["STRING_OPTIONS_PROFILE_REMOVEOKEY"] = "Profil başarıyla kaldırıldı."
L["STRING_OPTIONS_PROFILE_SELECT"] = "bir profil seç."
L["STRING_OPTIONS_PROFILE_SELECTEXISTING"] = "Bu karakter için mevcut bir profil seç ya da yenisini kullanmaya devam et:"
L["STRING_OPTIONS_PROFILE_USENEW"] = "Yeni Profili Kullan"
L["STRING_OPTIONS_PROFILES_ANCHOR"] = "Ayarlar:"
L["STRING_OPTIONS_PROFILES_COPY"] = "Profili Şuradan Kopyala"
L["STRING_OPTIONS_PROFILES_COPY_DESC"] = "Seçili profilin tüm ayarlarını, tüm değerlerin üzerine yazarak geçerli profile kopyala."
L["STRING_OPTIONS_PROFILES_CREATE"] = "Profil Oluştur"
L["STRING_OPTIONS_PROFILES_CREATE_DESC"] = "Yeni bir profil oluştur."
L["STRING_OPTIONS_PROFILES_CURRENT"] = "Geçerli Profil:"
L["STRING_OPTIONS_PROFILES_CURRENT_DESC"] = "Bu, şu anda etkin olan profilin adıdır."
L["STRING_OPTIONS_PROFILES_ERASE"] = "Profili Kaldır"
L["STRING_OPTIONS_PROFILES_ERASE_DESC"] = "Seçili profili kaldır."
L["STRING_OPTIONS_PROFILES_RESET"] = "Geçerli Profili Sıfırla"
L["STRING_OPTIONS_PROFILES_RESET_DESC"] = "Seçili profilin tüm ayarlarını varsayılan değerlere sıfırla."
L["STRING_OPTIONS_PROFILES_SELECT"] = "Profil Seç"
L["STRING_OPTIONS_PROFILES_SELECT_DESC"] = "Mevcut bir profili yükle. Tüm karakterlerde aynı profili kullanıyorsan (Tüm Karakterlerde Kullan seçeneği), bu karakter için bir istisna oluşturulur. "
L["STRING_OPTIONS_PROFILES_TITLE"] = "Profiller"
L["STRING_OPTIONS_PROFILES_TITLE_DESC"] = "Bu seçenekler aynı ayarları farklı karakterler arasında paylaşmanı sağlar."
L["STRING_OPTIONS_PS_ABBREVIATE"] = "Sayı Biçimi"
L["STRING_OPTIONS_PS_ABBREVIATE_COMMA"] = "Virgül"
L["STRING_OPTIONS_PS_ABBREVIATE_DESC"] = [=[Kısaltma yöntemini seç.

|cFFFFFF00ToK I|r:
520600 = 520.6K
19530000 = 19.53M

|cFFFFFF00ToK II|r:
520600 = 520K
19530000 = 19.53M

|cFFFFFF00ToM I|r:
520600 = 520.6K
19530000 = 19M

|cFFFFFF00Virgül|r:
19530000 = 19.530.000

|cFFFFFF00Alt|r ve |cFFFFFF00Üst|r: 'K' ve 'M' harflerinin küçük ya da büyük olduğunu belirtir.]=]
L["STRING_OPTIONS_PS_ABBREVIATE_NONE"] = "Yok"
L["STRING_OPTIONS_PS_ABBREVIATE_TOK"] = "ToK I Üst"
L["STRING_OPTIONS_PS_ABBREVIATE_TOK0"] = "ToM I Üst"
L["STRING_OPTIONS_PS_ABBREVIATE_TOK0MIN"] = "ToM I Alt"
L["STRING_OPTIONS_PS_ABBREVIATE_TOK2"] = "ToK II Üst"
L["STRING_OPTIONS_PS_ABBREVIATE_TOK2MIN"] = "ToK II Alt"
L["STRING_OPTIONS_PS_ABBREVIATE_TOKMIN"] = "ToK I Alt"
L["STRING_OPTIONS_PVPFRAGS"] = "Yalnızca PvP Öldürmeleri"
L["STRING_OPTIONS_PVPFRAGS_DESC"] = "Açıksa |cFFFFFF00hasar > öldürmeler|r görünümünde yalnızca düşman oyunculara karşı öldürmeler sayılır."
L["STRING_OPTIONS_REALMNAME"] = "Realm Adını Kaldır"
L["STRING_OPTIONS_REALMNAME_DESC"] = [=[Açıksa karakterin realm adı gösterilmez.

|cFFFFFF00Kapalı|r: Charles-Netherwing
|cFFFFFF00Açık|r: Charles]=]
L["STRING_OPTIONS_LASTNAME"] = "Soyadı Kaldır"
L["STRING_OPTIONS_LASTNAME_DESC"] = [=[Açıksa karakterin soyadı gösterilmez.

|cFFFFFF00Kapalı|r: Charles Netherwing
|cFFFFFF00Açık|r: Charles]=]
L["STRING_OPTIONS_REPORT_ANCHOR"] = "Rapor:"
L["STRING_OPTIONS_REPORT_HEALLINKS"] = "İyileştirme Büyüsü Bağlantıları"
L["STRING_OPTIONS_REPORT_HEALLINKS_DESC"] = [=[Bu seçenek açıkken rapor gönderilirse |cFF55FF55yardımcı|r büyüler adları yerine büyü bağlantısıyla raporlanır.

|cFFFF5555Zararlı|r büyüler varsayılan olarak bağlantıyla raporlanır.]=]
L["STRING_OPTIONS_REPORT_SCHEMA"] = "Biçim"
L["STRING_OPTIONS_REPORT_SCHEMA_DESC"] = "Sohbet kanalına bağlanan yazının biçimini seç."
L["STRING_OPTIONS_REPORT_SCHEMA1"] = "Toplam / Saniyede / Yüzde"
L["STRING_OPTIONS_REPORT_SCHEMA2"] = "Yüzde / Saniyede / Toplam"
L["STRING_OPTIONS_REPORT_SCHEMA3"] = "Yüzde / Toplam / Saniyede"
L["STRING_OPTIONS_RESET_TO_DEFAULT"] = "Varsayılana Döndür"
L["STRING_OPTIONS_ROWADV_TITLE"] = "Satır Gelişmiş Ayarları"
L["STRING_OPTIONS_ROWADV_TITLE_DESC"] = "Bu seçenekler satırları daha ayrıntılı değiştirmeni sağlar."
L["STRING_OPTIONS_RT_COOLDOWN1"] = "%s, %s üzerinde kullanıldı!"
L["STRING_OPTIONS_RT_COOLDOWN2"] = "%s kullanıldı!"
L["STRING_OPTIONS_RT_COOLDOWNS_ANCHOR"] = "Bekleme Sürelerini Duyur:"
L["STRING_OPTIONS_RT_COOLDOWNS_CHANNEL"] = "Kanal"
L["STRING_OPTIONS_RT_COOLDOWNS_CHANNEL_DESC"] = [=[Uyarı mesajını göndermek için hangi sohbet kanalının kullanılacağı.

|cFFFFFF00Gözlemci|r seçilirse, kişisel bekleme süreleri hariç tüm bekleme süreleri sohbetine yazılır.]=]
L["STRING_OPTIONS_RT_COOLDOWNS_CUSTOM"] = "Özel Yazı"
L["STRING_OPTIONS_RT_COOLDOWNS_CUSTOM_DESC"] = [=[Gönderilecek kendi cümleni yaz.

Bekleme süresi büyüsünün adını eklemek için |cFFFFFF00{spell}|r kullan.

Oyuncunun hedefinin adını eklemek için |cFFFFFF00{target}|r kullan.]=]
L["STRING_OPTIONS_RT_COOLDOWNS_ONOFF_DESC"] = "Bir bekleme süresi kullandığında seçili kanaldan bir mesaj gönderilir."
L["STRING_OPTIONS_RT_COOLDOWNS_SELECT"] = "Yok Sayılan Bekleme Süresi Listesi"
L["STRING_OPTIONS_RT_COOLDOWNS_SELECT_DESC"] = "Hangi bekleme sürelerinin yok sayılacağını seç."
L["STRING_OPTIONS_RT_DEATH_MSG"] = "Details! %s adlı oyuncunun ölümü"
L["STRING_OPTIONS_RT_DEATHS_ANCHOR"] = "Ölümleri Duyur:"
L["STRING_OPTIONS_RT_DEATHS_FIRST"] = "Yalnızca İlki"
L["STRING_OPTIONS_RT_DEATHS_FIRST_DESC"] = "Karşılaşma sırasında yalnızca ilk X ölümü duyurur."
L["STRING_OPTIONS_RT_DEATHS_HITS"] = "Vuruş Sayısı"
L["STRING_OPTIONS_RT_DEATHS_HITS_DESC"] = "Ölümü duyururken kaç vuruş olduğunu göster."
L["STRING_OPTIONS_RT_DEATHS_ONOFF_DESC"] = "Bir raid üyesi öldüğünde, onu neyin öldürdüğünü raid kanalına gönderir."
L["STRING_OPTIONS_RT_DEATHS_WHERE"] = "Zindanlar"
L["STRING_OPTIONS_RT_DEATHS_WHERE_DESC"] = [=[Ölümlerin nerede raporlanabileceğini seç.

|cFFFFFF00Önemli|r: raidlerde /raid kanalı, zindanlarda /p kullanılır.

|cFFFFFF00Gözlemci|r seçilirse ölümler sohbette yalnızca sana gösterilir.]=]
L["STRING_OPTIONS_RT_DEATHS_WHERE1"] = "Raid ve Zindan"
L["STRING_OPTIONS_RT_DEATHS_WHERE2"] = "Yalnızca Raid"
L["STRING_OPTIONS_RT_DEATHS_WHERE3"] = "Yalnızca Zindan"
L["STRING_OPTIONS_RT_FIRST_HIT"] = "İlk Vuruş"
L["STRING_OPTIONS_RT_FIRST_HIT_DESC"] = "İlk vuruşu kimin yaptığını (genellikle dövüşü başlatan kişidir) sohbet paneline (|cFFFFFF00yalnızca sana|r) yazar."
L["STRING_OPTIONS_RT_IGNORE_TITLE"] = "Bekleme Sürelerini Yok Say"
L["STRING_OPTIONS_RT_INFOS"] = "Ek Bilgiler:"
L["STRING_OPTIONS_RT_INFOS_PREPOTION"] = "Savaş Öncesi İksir Kullanımı"
L["STRING_OPTIONS_RT_INFOS_PREPOTION_DESC"] = "Açıksa, bir raid karşılaşmasından sonra çekişten önce kimin iksir kullandığını sohbetine (|cFFFFFF00yalnızca sana|r) yazar."
L["STRING_OPTIONS_RT_INTERRUPT"] = "%s kesildi!"
L["STRING_OPTIONS_RT_INTERRUPT_ANCHOR"] = "Kesmeleri Duyur:"
L["STRING_OPTIONS_RT_INTERRUPT_NEXT"] = "Sonraki: %s"
L["STRING_OPTIONS_RT_INTERRUPTS_CHANNEL"] = "Kanal"
L["STRING_OPTIONS_RT_INTERRUPTS_CHANNEL_DESC"] = [=[Uyarı mesajını göndermek için hangi sohbet kanalının kullanılacağı.

|cFFFFFF00Gözlemci|r seçilirse tüm kesmeler sohbette yalnızca sana yazılır.]=]
L["STRING_OPTIONS_RT_INTERRUPTS_CUSTOM"] = "Özel Yazı"
L["STRING_OPTIONS_RT_INTERRUPTS_CUSTOM_DESC"] = [=[Gönderilecek kendi cümleni yaz.

Kesilen büyünün adını eklemek için |cFFFFFF00{spell}|r kullan.

'Sonraki' kutusuna yazılan sonraki oyuncunun adını eklemek için |cFFFFFF00{next}|r kullan.]=]
L["STRING_OPTIONS_RT_INTERRUPTS_NEXT"] = "Sonraki Oyuncu"
L["STRING_OPTIONS_RT_INTERRUPTS_NEXT_DESC"] = "Bir kesme sırası varsa, sonraki kesmeden sorumlu oyuncunun adını yaz."
L["STRING_OPTIONS_RT_INTERRUPTS_ONOFF_DESC"] = "Bir büyüyü başarıyla kestiğinde bir mesaj gönderilir."
L["STRING_OPTIONS_RT_INTERRUPTS_WHISPER"] = "Şuna Fısılda"
L["STRING_OPTIONS_RT_OTHER_ANCHOR"] = "Genel:"
L["STRING_OPTIONS_RT_TITLE"] = "Raid Oyuncuları İçin Araçlar"
L["STRING_OPTIONS_RT_TITLE_DESC"] = "Bu panelde raidlerde sana yardımcı olacak çeşitli mekanizmaları etkinleştirebilirsin."
L["STRING_OPTIONS_SAVELOAD"] = "Kaydet ve Yükle"
L["STRING_OPTIONS_SAVELOAD_APPLYALL"] = "Geçerli görünüm diğer tüm pencerelere uygulandı."
L["STRING_OPTIONS_SAVELOAD_APPLYALL_DESC"] = "Geçerli görünümü oluşturulan tüm pencerelere uygula."
L["STRING_OPTIONS_SAVELOAD_APPLYTOALL"] = "Tüm Pencerelere Uygula"
L["STRING_OPTIONS_SAVELOAD_CREATE_DESC"] = "Geçerli görünümü ön ayar olarak kaydet; dışa aktarabilir ya da yedek olarak saklayabilirsin."
L["STRING_OPTIONS_SAVELOAD_DESC"] = "Bu seçenekler önceden tanımlı ayarları kaydetmeni ya da yüklemeni sağlar."
L["STRING_OPTIONS_SAVELOAD_ERASE_DESC"] = "Bu seçenek önceden kaydedilmiş bir görünümü siler."
L["STRING_OPTIONS_SAVELOAD_EXPORT"] = "Dışa Aktar"
L["STRING_OPTIONS_SAVELOAD_EXPORT_COPY"] = "CTRL + C'ye bas"
L["STRING_OPTIONS_SAVELOAD_EXPORT_DESC"] = "Görünümü metin biçiminde kaydeder."
L["STRING_OPTIONS_SAVELOAD_IMPORT"] = "Özel Görünüm İçe Aktar"
L["STRING_OPTIONS_SAVELOAD_IMPORT_DESC"] = "Metin biçiminde bir görünüm içe aktar."
L["STRING_OPTIONS_SAVELOAD_IMPORT_OKEY"] = "Görünüm kayıtlı görünümler listene aktarıldı. Artık 'Uygula' açılır listesinden uygulayabilirsin."
L["STRING_OPTIONS_SAVELOAD_LOAD"] = "Uygula"
L["STRING_OPTIONS_SAVELOAD_LOAD_DESC"] = "Seçili pencereye uygulamak için önceden kaydedilmiş görünümlerden birini seç."
L["STRING_OPTIONS_SAVELOAD_MAKEDEFAULT"] = "Standart Yap"
L["STRING_OPTIONS_SAVELOAD_PNAME"] = "Ad"
L["STRING_OPTIONS_SAVELOAD_REMOVE"] = "Sil"
L["STRING_OPTIONS_SAVELOAD_RESET"] = "Varsayılan Görünümü Yükle"
L["STRING_OPTIONS_SAVELOAD_SAVE"] = "kaydet"
L["STRING_OPTIONS_SAVELOAD_SKINCREATED"] = "görünüm kaydedildi."
L["STRING_OPTIONS_SAVELOAD_STD_DESC"] = [=[Geçerli görünümü Standart Görünüm olarak ayarla.

Bu görünüm oluşturulan tüm yeni pencerelere uygulanır.]=]
L["STRING_OPTIONS_SAVELOAD_STDSAVE"] = "Standart Görünüm kaydedildi, yeni pencereler varsayılan olarak bu görünümü kullanacak."
L["STRING_OPTIONS_SCROLLBAR"] = "Kaydırma Çubuğu"
L["STRING_OPTIONS_SCROLLBAR_DESC"] = [=[Kaydırma çubuğunu açar ya da kapatır.

Details! kaydırma çubukları varsayılan olarak pencereyi uzatan bir mekanizmayla değiştirilir.

|cFFFFFF00Uzatma tutamacı|r pencerenin düğme/menü alanının dışında (kapat düğmesinin solunda) bulunur.]=]
L["STRING_OPTIONS_SEGMENTSSAVE"] = "Kaydedilen Bölümler"
L["STRING_OPTIONS_SEGMENTSSAVE_DESC"] = [=[Oyun oturumları arasında kaç bölüm saklamak istediğin.

Yüksek değerler karakterinin çıkış süresini uzatabilir.]=]
L["STRING_OPTIONS_SENDFEEDBACK"] = "Geri Bildirim"
L["STRING_OPTIONS_SHOW_SIDEBARS"] = "Görünüm Kenarlığını Göster"
L["STRING_OPTIONS_SHOW_SIDEBARS_DESC"] = "Görünüm dosyasındaki pencere kenarlığını göster; 'Pencere Rengi' ile aynı rengi kullanır."
L["STRING_OPTIONS_SHOW_STATUSBAR_DESC"] = "Alttaki durum çubuğunu göster ya da gizle."
L["STRING_OPTIONS_SHOW_TOTALBAR_COLOR_DESC"] = "Rengi seç. Saydamlık değeri satır saydamlığını izler."
L["STRING_OPTIONS_SHOW_TOTALBAR_DESC"] = "Toplam çubuğunu göster ya da gizle."
L["STRING_OPTIONS_SHOW_TOTALBAR_ICON"] = "Simge"
L["STRING_OPTIONS_SHOW_TOTALBAR_ICON_DESC"] = "Toplam çubuğunda gösterilen simgeyi seç."
L["STRING_OPTIONS_SHOW_TOTALBAR_INGROUP"] = "Yalnızca Gruptayken"
L["STRING_OPTIONS_SHOW_TOTALBAR_INGROUP_DESC"] = "Grupta değilsen toplam çubuğu gösterilmez."
L["STRING_OPTIONS_SKIN_A"] = "Görünüm Ayarları"
L["STRING_OPTIONS_SKIN_A_DESC"] = "Bu seçenekler görünümü değiştirmeni sağlar."
L["STRING_OPTIONS_SKIN_ELVUI_BUTTON1"] = "Sağ Sohbet İçinde Hizala"
L["STRING_OPTIONS_SKIN_ELVUI_BUTTON1_DESC"] = "|cFFFFFF00#1|r ve |cFFFFFF00#2|r numaralı pencereleri taşı, boyutlandır ve sağ sohbet penceresinin üzerine yerleştir."
L["STRING_OPTIONS_SKIN_ELVUI_BUTTON2"] = "İpucu Kenarlığını Siyah Yap"
L["STRING_OPTIONS_SKIN_ELVUI_BUTTON2_DESC"] = [=[İpucunun şunlarını değiştir:

Kenarlık Rengi: |cFFFFFF00Siyah|r.
Kenarlık Boyutu: |cFFFFFF0016|r.
Doku: |cFFFFFF00Blizzard İpucu|r.]=]
L["STRING_OPTIONS_SKIN_ELVUI_BUTTON3"] = "İpucu Kenarlığını Kaldır"
L["STRING_OPTIONS_SKIN_ELVUI_BUTTON3_DESC"] = [=[İpucunun şunlarını değiştir:

Kenarlık Rengi: |cFFFFFF00Saydam|r.]=]
L["STRING_OPTIONS_SKIN_EXTRA_OPTIONS_ANCHOR"] = "Görünüm Seçenekleri:"
L["STRING_OPTIONS_SKIN_LOADED"] = "görünüm başarıyla yüklendi."
L["STRING_OPTIONS_SKIN_PRESETS_ANCHOR"] = "Görünümü Kaydet:"
L["STRING_OPTIONS_SKIN_PRESETSCONFIG_ANCHOR"] = "Kayıtlı Görünümler:"
L["STRING_OPTIONS_SKIN_REMOVED"] = "görünüm kaldırıldı."
L["STRING_OPTIONS_SKIN_RESET_TOOLTIP"] = "İpucu Kenarlığını Sıfırla"
L["STRING_OPTIONS_SKIN_RESET_TOOLTIP_DESC"] = "İpucunun kenarlık rengini ve dokusunu varsayılana döndür."
L["STRING_OPTIONS_SKIN_SELECT"] = "bir görünüm seç"
L["STRING_OPTIONS_SKIN_SELECT_ANCHOR"] = "Görünüm Seçimi:"
L["STRING_OPTIONS_SOCIAL"] = "Sosyal"
L["STRING_OPTIONS_SOCIAL_DESC"] = "Loncanda nasıl tanınmak istediğini belirt."
L["STRING_OPTIONS_SPELL_ADD"] = "Ekle"
L["STRING_OPTIONS_SPELL_ADDICON"] = "Yeni Simge: "
L["STRING_OPTIONS_SPELL_ADDNAME"] = "Yeni Ad: "
L["STRING_OPTIONS_SPELL_ADDSPELL"] = "Büyü Ekle"
L["STRING_OPTIONS_SPELL_ADDSPELLID"] = "Büyü Kimliği: "
L["STRING_OPTIONS_SPELL_CLOSE"] = "Kapat"
L["STRING_OPTIONS_SPELL_ICON"] = "Simge"
L["STRING_OPTIONS_SPELL_IDERROR"] = "Geçersiz büyü kimliği."
L["STRING_OPTIONS_SPELL_INDEX"] = "Sıra"
L["STRING_OPTIONS_SPELL_NAME"] = "Ad"
L["STRING_OPTIONS_SPELL_NAMEERROR"] = "Geçersiz büyü adı."
L["STRING_OPTIONS_SPELL_NOTFOUND"] = "Büyü bulunamadı."
L["STRING_OPTIONS_SPELL_REMOVE"] = "Kaldır"
L["STRING_OPTIONS_SPELL_RESET"] = "Sıfırla"
L["STRING_OPTIONS_SPELL_SPELLID"] = "Büyü Kimliği"
L["STRING_OPTIONS_STRETCH"] = "Uzatma Düğmesi Üst Kenarda"
L["STRING_OPTIONS_STRETCH_DESC"] = "Uzatma düğmesini pencerenin üstüne yerleştirir."
L["STRING_OPTIONS_STRETCHTOP"] = "Uzatma Düğmesi Hep Üstte"
L["STRING_OPTIONS_STRETCHTOP_DESC"] = [=[Uzatma düğmesi FULLSCREEN katmanına yerleştirilir ve her zaman diğer çerçevelerin üzerinde kalır.

|cFFFFFF00Önemli|r: Tutamacı yüksek katmana taşımak, çantalar gibi diğer çerçevelerin önünde kalmasına yol açabilir; yalnızca gerçekten gerekiyorsa kullan.]=]
L["STRING_OPTIONS_SWITCH_ANCHOR"] = "Geçişler:"
L["STRING_OPTIONS_SWITCHINFO"] = "|cFFF79F81 SOL KAPALI|r  |cFF81BEF7 SAĞ AÇIK|r"
L["STRING_OPTIONS_TABEMB_ANCHOR"] = "Sohbet Sekmesine Göm"
L["STRING_OPTIONS_TABEMB_ENABLED_DESC"] = "Açıksa bir ya da daha fazla pencere bir sohbet sekmesine tutturulur."
L["STRING_OPTIONS_TABEMB_SINGLE"] = "Tek Pencere"
L["STRING_OPTIONS_TABEMB_SINGLE_DESC"] = "Açıksa iki yerine yalnızca bir pencere tutturulur."
L["STRING_OPTIONS_TABEMB_TABNAME"] = "Sekme Adı"
L["STRING_OPTIONS_TABEMB_TABNAME_DESC"] = "Pencerelerin tutturulacağı sekmenin adı."
L["STRING_OPTIONS_TESTBARS"] = "Deneme Çubukları Oluştur"
L["STRING_OPTIONS_TEXT"] = "Çubuk Yazısı Ayarları"
L["STRING_OPTIONS_TEXT_DESC"] = "Bu seçenekler pencere satırı yazılarının görünümünü denetler."
L["STRING_OPTIONS_TEXT_FIXEDCOLOR"] = "Yazı Rengi"
L["STRING_OPTIONS_TEXT_FONT"] = "Yazı Tipi"
L["STRING_OPTIONS_TEXT_FONT_DESC"] = "Sol ve sağ yazıların yazı tipini değiştir."
L["STRING_OPTIONS_TEXT_LCLASSCOLOR_DESC"] = "Açıksa yazı her zaman oyuncunun sınıf rengini kullanır."
L["STRING_OPTIONS_TEXT_LEFT_ANCHOR"] = "Sol Yazı:"
L["STRING_OPTIONS_TEXT_LOUTILINE"] = "Yazı Gölgesi"
L["STRING_OPTIONS_TEXT_LOUTILINE_DESC"] = "Sol yazının dış çizgisini açar ya da kapatır."
L["STRING_OPTIONS_TEXT_LPOSITION_DESC"] = "Oyuncu adının sol tarafında sıra numarasını göster."
L["STRING_OPTIONS_TEXT_LTRANSLIT"] = "Harf Çevirisi"
L["STRING_OPTIONS_TEXT_LTRANSLIT_DESC"] = "Kimsenin anlamadığı Rus harflerinin Batı harfleriyle gösterilmesini sağlar."
L["STRING_OPTIONS_TEXT_OUTLINE"] = "Yazı Dış Çizgisi"
L["STRING_OPTIONS_TEXT_RIGHT_ANCHOR"] = "Sağ Yazı:"
L["STRING_OPTIONS_TEXT_ROUTILINE_DESC"] = "Sağ yazının dış çizgisini açar ya da kapatır."
L["STRING_OPTIONS_TEXT_SHOW_BRACKET"] = "Parantez"
L["STRING_OPTIONS_TEXT_SHOW_BRACKET_DESC"] = "Saniyede ve yüzde bloğunu açıp kapatmak için hangi karakterin kullanılacağını seç."
L["STRING_OPTIONS_TEXT_SHOW_PERCENT"] = "Yüzdeyi Göster"
L["STRING_OPTIONS_TEXT_SHOW_PERCENT_DESC"] = [=[Yüzdeyi göster. 

Yüzdeyi kapatırsan DPS'ten sonra fazladan virgül olmaması için 'Ayırıcı'yı 'yok' yapmak isteyebilirsin.]=]
L["STRING_OPTIONS_TEXT_SHOW_PS"] = "Saniyede Değeri Göster"
L["STRING_OPTIONS_TEXT_SHOW_PS_DESC"] = "Saniyedeki Hasarı ve Saniyedeki İyileştirmeyi göster."
L["STRING_OPTIONS_TEXT_SHOW_SEPARATOR"] = "Ayırıcı"
L["STRING_OPTIONS_TEXT_SHOW_SEPARATOR_DESC"] = "Saniyede miktarını yüzde miktarından ayırmak için hangi karakterin kullanılacağını seç."
L["STRING_OPTIONS_TEXT_SHOW_TOTAL"] = "Toplamı Göster"
L["STRING_OPTIONS_TEXT_SHOW_TOTAL_DESC"] = [=[Birimin yaptığı toplamı göster.

Örneğin: toplam hasar, alınan toplam iyileştirme.]=]
L["STRING_OPTIONS_TEXT_SIZE"] = "Yazı Boyutu"
L["STRING_OPTIONS_TEXT_SIZE_DESC"] = "Sol ve sağ yazıların boyutunu değiştir."
L["STRING_OPTIONS_TEXTEDITOR_CANCEL"] = "İptal"
L["STRING_OPTIONS_TEXTEDITOR_CANCEL_TOOLTIP"] = "Düzenlemeyi bitir ve koddaki değişiklikleri yok say."
L["STRING_OPTIONS_TEXTEDITOR_COLOR_TOOLTIP"] = "Seçili yazının rengini değiştirmek için yazıyı seç, sonra renk düğmesine tıkla."
L["STRING_OPTIONS_TEXTEDITOR_COMMA"] = "Virgül"
L["STRING_OPTIONS_TEXTEDITOR_COMMA_TOOLTIP"] = [=[Sayıları virgülle ayırarak biçimlendiren bir işlev ekle.
Örnek: 1000000 -> 1.000.000.]=]
L["STRING_OPTIONS_TEXTEDITOR_DATA"] = "[Veri %s]"
L["STRING_OPTIONS_TEXTEDITOR_DATA_TOOLTIP"] = [=[Bir veri akışı ekle:

|cFFFFFF00Veri 1|r: normalde birimin yaptığı toplamı ya da sıra numarasını gösterir.

|cFFFFFF00Veri 2|r: çoğu durumda DPS'i, HPS'i ya da oyuncunun adını gösterir.

|cFFFFFF00Veri 3|r: birimin yaptığı yüzdeyi, uzmanlık ya da fraksiyon simgesini gösterir.]=]
L["STRING_OPTIONS_TEXTEDITOR_DONE"] = "Bitti"
L["STRING_OPTIONS_TEXTEDITOR_DONE_TOOLTIP"] = "Düzenlemeyi bitir ve kodu kaydet."
L["STRING_OPTIONS_TEXTEDITOR_FUNC"] = "İşlev"
L["STRING_OPTIONS_TEXTEDITOR_FUNC_TOOLTIP"] = [=[Boş bir işlev ekle.
İşlevler her zaman bir sayı döndürmelidir.]=]
L["STRING_OPTIONS_TEXTEDITOR_RESET"] = "Sıfırla"
L["STRING_OPTIONS_TEXTEDITOR_RESET_TOOLTIP"] = "Tüm kodu sil ve varsayılan kodu ekle."
L["STRING_OPTIONS_TEXTEDITOR_TOK"] = "ToK"
L["STRING_OPTIONS_TEXTEDITOR_TOK_TOOLTIP"] = [=[Sayıları kısaltarak biçimlendiren bir işlev ekle.
Örnek: 1500000 -> 1.5kk.]=]
L["STRING_OPTIONS_TIMEMEASURE"] = "Süre Ölçümü"
L["STRING_OPTIONS_TIMEMEASURE_DESC"] = [=[|cFFFFFF00Etkinlik|r: her raid üyesinin sayacı etkinliği durunca bekletilir, yeniden başlayınca saymaya devam eder; DPS ve HPS ölçmenin yaygın yolu.

|cFFFFFF00Etkin|r: sıralamalarda kullanılır; tüm raid üyelerinin DPS ve HPS'ini ölçmek için geçen savaş süresini kullanır.]=]
L["STRING_OPTIONS_TITLEBAR_MENUBUTTONS_HEADER"] = "Düğme ve Menü Ayarları"
L["STRING_OPTIONS_TOOLBAR_SETTINGS"] = "Başlık Çubuğu Düğme Ayarları"
L["STRING_OPTIONS_TOOLBAR_SETTINGS_DESC"] = "Bu seçenekler pencerenin üstündeki ana menüyü değiştirir."
L["STRING_OPTIONS_TOOLBARSIDE"] = "Başlık Çubuğu Üstte"
L["STRING_OPTIONS_TOOLBARSIDE_DESC"] = [=[Başlık çubuğunu pencerenin üstüne yerleştirir.

|cFFFFFF00Önemli|r: konumu değiştirince başlık yazısı değişmez; daha fazla seçenek için |cFFFFFF00Başlık Çubuğu: Yazı|r bölümüne bak.]=]
L["STRING_OPTIONS_TOOLS_ANCHOR"] = "Araçlar:"
L["STRING_OPTIONS_TOOLTIPS_DISABLE"] = "İpuçlarını Kapat"
L["STRING_OPTIONS_TOOLTIPS_DISABLE_DESC"] = "Seçili pencerede ipuçlarını kapat."
L["STRING_OPTIONS_TOOLTIP_ANCHOR"] = "Ayarlar:"
L["STRING_OPTIONS_TOOLTIP_ANCHORTEXTS"] = "Yazılar:"
L["STRING_OPTIONS_TOOLTIPS_ABBREVIATION"] = "Kısaltma Türü"
L["STRING_OPTIONS_TOOLTIPS_ABBREVIATION_DESC"] = "İpuçlarında gösterilen sayıların nasıl biçimleneceğini seç."
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_ATTACH"] = "İpucu Tarafı"
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_ATTACH_DESC"] = "İpucunun hangi tarafının sabitleme tarafına oturacağı."
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_BORDER"] = "Kenarlık:"
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_POINT"] = "Sabitleme:"
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_RELATIVE"] = "Sabitleme Tarafı"
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_RELATIVE_DESC"] = "İpucunun sabitlemenin hangi tarafına yerleştirileceği."
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_TEXT"] = "İpucu Sabitlemesi"
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_TEXT_DESC"] = "kilitlemek için sağ tıkla."
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_TO"] = "Bağlantı"
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_TO_CHOOSE"] = "Sabitleme Noktasını Taşı"
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_TO_CHOOSE_DESC"] = "Sabitleme |cFFFFFF00Ekrandaki Nokta|r olarak ayarlıyken sabitleme konumunu taşı."
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_TO_DESC"] = "İpuçları üzerine gelinen satıra ya da oyun ekranında seçilen bir noktaya tutturulur."
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_TO1"] = "Pencere Satırı"
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_TO2"] = "Ekrandaki Nokta"
L["STRING_OPTIONS_TOOLTIPS_ANCHORCOLOR"] = "başlık"
L["STRING_OPTIONS_TOOLTIPS_BACKGROUNDCOLOR"] = "Arka Plan Rengi"
L["STRING_OPTIONS_TOOLTIPS_BACKGROUNDCOLOR_DESC"] = "Arka planda kullanılan rengi seç."
L["STRING_OPTIONS_TOOLTIPS_BORDER_COLOR_DESC"] = "Kenarlık rengini değiştir."
L["STRING_OPTIONS_TOOLTIPS_BORDER_SIZE_DESC"] = "Kenarlık boyutunu değiştir."
L["STRING_OPTIONS_TOOLTIPS_BORDER_TEXTURE_DESC"] = "Kenarlık doku dosyasını değiştir."
L["STRING_OPTIONS_TOOLTIPS_FONTCOLOR"] = "Yazı Rengi"
L["STRING_OPTIONS_TOOLTIPS_FONTCOLOR_DESC"] = "İpucu yazılarında kullanılan rengi değiştir."
--[[Translation missing --]]
L["STRING_OPTIONS_TOOLTIPS_FONTFACE"] = ""
L["STRING_OPTIONS_TOOLTIPS_FONTFACE_DESC"] = "İpucu yazılarında kullanılan yazı tipini seç."
L["STRING_OPTIONS_TOOLTIPS_FONTSHADOW_DESC"] = "Yazıda dış çizgi göster."
--[[Translation missing --]]
L["STRING_OPTIONS_TOOLTIPS_FONTSIZE"] = ""
L["STRING_OPTIONS_TOOLTIPS_FONTSIZE_DESC"] = "İpucu yazılarının boyutunu artır ya da azalt"
L["STRING_OPTIONS_TOOLTIPS_IGNORESUBWALLPAPER"] = "Alt Menü Duvar Kâğıdı"
L["STRING_OPTIONS_TOOLTIPS_IGNORESUBWALLPAPER_DESC"] = "Açıksa bazı menüler alt menülerinde kendi duvar kâğıdını kullanabilir."
L["STRING_OPTIONS_TOOLTIPS_MAXIMIZE"] = "Büyütme Yöntemi"
L["STRING_OPTIONS_TOOLTIPS_MAXIMIZE_DESC"] = [=[İpucunda gösterilen bilgiyi genişletmek için kullanılan yöntemi seç.

|cFFFFFF00 Kontrol Tuşlarıyla|r: Shift, Ctrl ya da Alt tuşuna basılınca ipucu kutusu genişler.

|cFFFFFF00 Her Zaman Büyük|r: ipucu her zaman hiçbir sınır olmadan tüm bilgiyi gösterir.

|cFFFFFF00 Yalnızca Shift Bloğu|r: ipucundaki ilk blok varsayılan olarak hep genişletilir.

|cFFFFFF00 Yalnızca Ctrl Bloğu|r: ikinci blok varsayılan olarak hep genişletilir.

|cFFFFFF00 Yalnızca Alt Bloğu|r: üçüncü blok varsayılan olarak hep genişletilir.]=]
L["STRING_OPTIONS_TOOLTIPS_MAXIMIZE1"] = "Shift Ctrl Alt ile"
L["STRING_OPTIONS_TOOLTIPS_MAXIMIZE2"] = "Her Zaman Büyük"
L["STRING_OPTIONS_TOOLTIPS_MAXIMIZE3"] = "Yalnızca Shift Engeli"
L["STRING_OPTIONS_TOOLTIPS_MAXIMIZE4"] = "Yalnızca Ctrl Engeli"
L["STRING_OPTIONS_TOOLTIPS_MAXIMIZE5"] = "Yalnızca Alt Engeli"
L["STRING_OPTIONS_TOOLTIPS_MENU_WALLP"] = "Menü Duvar Kâğıdını Düzenle"
L["STRING_OPTIONS_TOOLTIPS_MENU_WALLP_DESC"] = "Başlık çubuğu menülerinin duvar kâğıdının görünümünü değiştir."
L["STRING_OPTIONS_TOOLTIPS_OFFSETX"] = "X Uzaklığı"
L["STRING_OPTIONS_TOOLTIPS_OFFSETX_DESC"] = "İpucunun sabitlemesinden yatay olarak ne kadar uzağa yerleştirileceği."
L["STRING_OPTIONS_TOOLTIPS_OFFSETY"] = "Y Uzaklığı"
L["STRING_OPTIONS_TOOLTIPS_OFFSETY_DESC"] = "İpucunun sabitlemesinden dikey olarak ne kadar uzağa yerleştirileceği."
L["STRING_OPTIONS_TOOLTIPS_SHOWAMT"] = "Miktarı Göster"
L["STRING_OPTIONS_TOOLTIPS_SHOWAMT_DESC"] = "İpucunda kaç büyü, hedef ve pet olduğunu gösteren bir sayı gösterir."
L["STRING_OPTIONS_TOOLTIPS_TITLE"] = "İpuçları"
L["STRING_OPTIONS_TOOLTIPS_TITLE_DESC"] = "Bu seçenekler ipuçlarının görünümünü denetler."
L["STRING_OPTIONS_TRASH_SUPPRESSION"] = "Trash Bastırma"
L["STRING_OPTIONS_TRASH_SUPPRESSION_DESC"] = "|cFFFFFF00X|r saniye boyunca trash bölümlerini göstermek için otomatik geçişi engelle (|cFFFFFF00yalnızca bir boss karşılaşması yenildikten sonra|r)."
L["STRING_OPTIONS_WALLPAPER_ALPHA"] = "Saydamlık:"
L["STRING_OPTIONS_WALLPAPER_ANCHOR"] = "Duvar Kâğıdı Seçimi:"
L["STRING_OPTIONS_WALLPAPER_BLUE"] = "Mavi:"
L["STRING_OPTIONS_WALLPAPER_CBOTTOM"] = "Kırp (|cFFC0C0C0alt|r):"
L["STRING_OPTIONS_WALLPAPER_CLEFT"] = "Kırp (|cFFC0C0C0sol|r):"
L["STRING_OPTIONS_WALLPAPER_CRIGHT"] = "Kırp (|cFFC0C0C0sağ|r):"
L["STRING_OPTIONS_WALLPAPER_CTOP"] = "Kırp (|cFFC0C0C0üst|r):"
L["STRING_OPTIONS_WALLPAPER_FILE"] = "Dosya:"
L["STRING_OPTIONS_WALLPAPER_GREEN"] = "Yeşil:"
L["STRING_OPTIONS_WALLPAPER_LOAD"] = "Görsel Yükle"
L["STRING_OPTIONS_WALLPAPER_LOAD_DESC"] = "Duvar kâğıdı olarak kullanmak için sabit diskinden bir görsel seç."
L["STRING_OPTIONS_WALLPAPER_LOAD_EXCLAMATION"] = [=[Görsel nasıl yüklenir:

- Genişlik ve yükseklik 128, 256 ya da 512 piksel olmalı (örneğin 512 x 256).
- Görseli WOW/_retail_/Interface/ klasörüne .TGA olarak kaydet.
- Oyunu kapatıp yeniden aç.]=]
L["STRING_OPTIONS_WALLPAPER_LOAD_FILENAME"] = "Dosya Adı:"
L["STRING_OPTIONS_WALLPAPER_LOAD_FILENAME_DESC"] = "Yalnızca dosyanın adını yaz; yolu ve uzantıyı yazma."
L["STRING_OPTIONS_WALLPAPER_LOAD_OKEY"] = "Yükle"
L["STRING_OPTIONS_WALLPAPER_LOAD_TITLE"] = "Özel Duvar Kâğıdın"
L["STRING_OPTIONS_WALLPAPER_LOAD_TROUBLESHOOT"] = "Sorun Giderme"
L["STRING_OPTIONS_WALLPAPER_LOAD_TROUBLESHOOT_TEXT"] = [=[Duvar kâğıdı tamamen yeşil görünüyorsa:

- WoW istemcisini yeniden başlat.
- Görselin 256 genişliğinde ve 256 yüksekliğinde olduğundan emin ol.
- Görselin .TGA biçiminde ve 32 bit/piksel olarak kaydedildiğini kontrol et.
- Interface klasörünün içinde mi, örneğin: C:/Program Files/World of Warcraft/_retail_/Interface/]=]
L["STRING_OPTIONS_WALLPAPER_RED"] = "Kırmızı:"
L["STRING_OPTIONS_WC_ANCHOR"] = "Hızlı Pencere Kontrolü (#%s):"
L["STRING_OPTIONS_WC_BOOKMARK"] = "Yer İmlerini Yönet"
L["STRING_OPTIONS_WC_BOOKMARK_DESC"] = "Yer imleri için ayar panelini aç."
L["STRING_OPTIONS_WC_CLOSE"] = "Kapat"
L["STRING_OPTIONS_WC_CLOSE_DESC"] = [=[Pencereyi kapat.

Kapatılınca pencere etkin değil sayılır ve Pencere Kontrolü menüsüyle her zaman yeniden açılabilir.

|cFFFFFF00Önemli:|r bir pencereyi tamamen kaldırmak için 'Pencere Gövdesi' bölümüne git.]=]
L["STRING_OPTIONS_WC_CREATE"] = "Pencere Oluştur"
L["STRING_OPTIONS_WC_CREATE_DESC"] = "Yeni bir pencere oluştur."
L["STRING_OPTIONS_WC_LOCK"] = "Kilitle"
L["STRING_OPTIONS_WC_LOCK_DESC"] = [=[Pencereyi kilitle ya da kilidini aç.

Kilitliyken pencere taşınamaz.]=]
L["STRING_OPTIONS_WC_REOPEN"] = "Yeniden Aç"
L["STRING_OPTIONS_WC_UNLOCK"] = "Kilidi Aç"
L["STRING_OPTIONS_WC_UNSNAP"] = "Gruptan Ayır"
L["STRING_OPTIONS_WC_UNSNAP_DESC"] = "Bu pencereyi pencere grubundan çıkar."
L["STRING_OPTIONS_WHEEL_SPEED"] = "Tekerlek Hızı"
L["STRING_OPTIONS_WHEEL_SPEED_DESC"] = "Fare tekerleğini bir pencerenin üzerinde çevirince kaydırmanın ne kadar hızlı olacağını değiştirir."
L["STRING_OPTIONS_WINDOW"] = "Ayarlar Paneli"
L["STRING_OPTIONS_WINDOW_ANCHOR_ANCHORS"] = "Sabitlemeler:"
L["STRING_OPTIONS_WINDOW_IGNOREMASSTOGGLE"] = "Toplu Aç/Kapat'ı Yok Say"
L["STRING_OPTIONS_WINDOW_IGNOREMASSTOGGLE_DESC"] = "Açıksa tüm pencereler gizlenirken, gösterilirken ya da açılıp kapatılırken bu pencere etkilenmez."
L["STRING_OPTIONS_WINDOW_ROWAREA_COLOR"] = "\"Satır Alanı Rengi\""
L["STRING_OPTIONS_WINDOW_ROWAREA_COLOR_DESC"] = "Satırlar gösterilirken alanın arka plan rengini ayarla."
L["STRING_OPTIONS_WINDOW_SCALE"] = "Ölçek"
L["STRING_OPTIONS_WINDOW_SKIN_COLOR"] = "Görünüm Rengi"
L["STRING_OPTIONS_WINDOW_SKIN_COLOR_DESC"] = [=[Bu pencereye uygulanan görünümün rengini değiştirir.

|cFFFFFF00Önemli|r: açıksa burada seçilen saydamlığın yerine |cFFFFFF00Otomatik Saydamlık|r değerleri geçer.

|cFFFFFF00Önemli|r: görünüm rengini seçmek durum çubuğuna uygulanan renk özelleştirmesinin yerine geçer.]=]
L["STRING_OPTIONS_WINDOW_TITLE"] = "Genel Pencere Ayarları"
L["STRING_OPTIONS_WINDOW_TITLE_DESC"] = "Bu seçenekler seçili pencerenin görünümünü denetler."
L["STRING_OPTIONS_WINDOWSPEED"] = "Güncelleme Aralığı"
L["STRING_OPTIONS_WINDOWSPEED_DESC"] = [=[Her güncelleme arasındaki süre.

|cFFFFFF000.05|r: gerçek zamanlı güncelleme.

|cFFFFFF000.3|r: saniyede yaklaşık 3 kez güncelle.

|cFFFFFF003.0|r: 3 saniyede bir güncelle.]=]
L["STRING_OPTIONS_WP"] = "Duvar Kâğıdı Ayarları"
L["STRING_OPTIONS_WP_ALIGN"] = "Hizala"
L["STRING_OPTIONS_WP_ALIGN_DESC"] = [=[Duvar kâğıdının pencere içinde nasıl hizalanacağı.

- |cFFFFFF00Doldur|r: otomatik boyutlanır ve tüm köşelere hizalanır.

- |cFFFFFF00Orta|r: boyutlanmaz ve pencerenin ortasına hizalanır.

-|cFFFFFF00Uzat|r: dikey ya da yatay olarak otomatik boyutlanır ve sol-sağ ya da üst-alt kenarlara hizalanır.

-|cFFFFFF00Dört Köşe|r: belirtilen köşeye hizalanır, otomatik boyutlanmaz.]=]
L["STRING_OPTIONS_WP_DESC"] = "Bu seçenekler pencerenin duvar kâğıdını denetler."
L["STRING_OPTIONS_WP_EDIT"] = "Görseli Düzenle"
L["STRING_OPTIONS_WP_EDIT_DESC"] = "Seçili görselin bazı özelliklerini değiştirmek için görsel düzenleyiciyi aç."
L["STRING_OPTIONS_WP_ENABLE_DESC"] = "Duvar kâğıdını göster."
L["STRING_OPTIONS_WP_GROUP"] = "Kategori"
L["STRING_OPTIONS_WP_GROUP_DESC"] = "Görsel grubunu seç."
L["STRING_OPTIONS_WP_GROUP2"] = "Duvar Kâğıdı"
L["STRING_OPTIONS_WP_GROUP2_DESC"] = "Duvar kâğıdı olarak kullanılacak görsel."
L["STRING_OPTIONSMENU_AUTOMATIC"] = "Otomasyon"
L["STRING_OPTIONSMENU_AUTOMATIC_TITLE"] = "Pencere Otomasyon Ayarları"
L["STRING_OPTIONSMENU_AUTOMATIC_TITLE_DESC"] = "Bu ayarlar pencerenin otomatik gizleme ve otomatik geçiş gibi otomatik davranışlarını denetler."
L["STRING_OPTIONSMENU_COMBAT"] = "PvE PvP"
L["STRING_OPTIONSMENU_DATACHART"] = "Grafik Verileri"
L["STRING_OPTIONSMENU_DATACOLLECT"] = "Veri Toplayıcı"
L["STRING_OPTIONSMENU_DATAFEED"] = "Veri Akışı"
L["STRING_OPTIONSMENU_DISPLAY"] = "Görünüm"
L["STRING_OPTIONSMENU_DISPLAY_DESC"] = "Genel temel ayarlar ve hızlı pencere kontrolü."
L["STRING_OPTIONSMENU_LEFTMENU"] = "Başlık Çubuğu"
L["STRING_OPTIONSMENU_MISC"] = "Çeşitli"
L["STRING_OPTIONSMENU_PERFORMANCE"] = "Performans Ayarları"
L["STRING_OPTIONSMENU_PLUGINS"] = "Eklentiler"
L["STRING_OPTIONSMENU_PROFILES"] = "Profiller"
L["STRING_OPTIONSMENU_RAIDTOOLS"] = "Raid Araçları"
L["STRING_OPTIONSMENU_RIGHTMENU"] = "-- x -- x --"
L["STRING_OPTIONSMENU_ROWMODELS"] = "Çubuklar: Gelişmiş"
L["STRING_OPTIONSMENU_ROWSETTINGS"] = "Çubuklar: Genel"
L["STRING_OPTIONSMENU_ROWTEXTS"] = "Çubuklar: Yazılar"
L["STRING_OPTIONSMENU_SKIN"] = "Görünümler"
L["STRING_OPTIONSMENU_SPELLS"] = "Büyüleri Yeniden Adlandır"
L["STRING_OPTIONSMENU_SPELLS_CONSOLIDATE"] = "Aynı Adlı Büyüleri Birleştir"
L["STRING_OPTIONSMENU_TITLEBAR"] = "Başlık Çubuğu"
L["STRING_OPTIONSMENU_TITLETEXT"] = "Başlık Çubuğu: Yazı"
L["STRING_OPTIONSMENU_TOOLTIP"] = "İpuçları"
L["STRING_OPTIONSMENU_WALLPAPER"] = "Duvar Kâğıdı"
L["STRING_OPTIONSMENU_WINDOW"] = "Pencere: Genel"
L["STRING_OPTIONSMENU_WINDOWBODY"] = "Pencere Gövdesi"
L["STRING_OVERALL"] = "Genel"
L["STRING_OVERHEAL"] = "Fazla İyileştirme"
L["STRING_OVERHEALED"] = "Fazla İyileştirildi"
L["STRING_PARRY"] = "Savuşturma"
L["STRING_PERCENTAGE"] = "Yüzde"
L["STRING_PET"] = "Pet"
L["STRING_PETS"] = "Petler"
L["STRING_PLAYER_DETAILS"] = "Oyuncu Details! Dökümü"
L["STRING_PLAYERS"] = "Oyuncular"
L["STRING_PLEASE_WAIT"] = "Lütfen bekle"
L["STRING_PLUGIN_CLEAN"] = "Yok"
L["STRING_PLUGIN_CLOCKNAME"] = "Karşılaşma Süresi"
L["STRING_PLUGIN_CLOCKTYPE"] = "Saat Türü"
L["STRING_PLUGIN_DURABILITY"] = "Dayanıklılık"
L["STRING_PLUGIN_FPS"] = "Kare Hızı"
L["STRING_PLUGIN_GOLD"] = "Altın"
L["STRING_PLUGIN_LATENCY"] = "Gecikme"
L["STRING_PLUGIN_MINSEC"] = "Dakika ve Saniye"
L["STRING_PLUGIN_NAMEALREADYTAKEN"] = "Details! eklentiyi kuramıyor çünkü bu ad zaten alınmış"
L["STRING_PLUGIN_PATTRIBUTENAME"] = "Özellik"
L["STRING_PLUGIN_PDPSNAME"] = "Raid DPS"
L["STRING_PLUGIN_PSEGMENTNAME"] = "Bölüm"
L["STRING_PLUGIN_SECONLY"] = "Yalnızca Saniye"
L["STRING_PLUGIN_SEGMENTTYPE"] = "Bölüm Türü"
L["STRING_PLUGIN_SEGMENTTYPE_1"] = "Dövüş #X"
L["STRING_PLUGIN_SEGMENTTYPE_2"] = "Karşılaşma Adı"
L["STRING_PLUGIN_SEGMENTTYPE_3"] = "Karşılaşma Adı ve Bölüm"
L["STRING_PLUGIN_THREATNAME"] = "Tehdidim"
L["STRING_PLUGIN_TIME"] = "Saat"
L["STRING_PLUGIN_TIMEDIFF"] = "Son Savaş Farkı"
L["STRING_PLUGIN_TOOLTIP_LEFTBUTTON"] = "Geçerli eklentiyi ayarla"
L["STRING_PLUGIN_TOOLTIP_RIGHTBUTTON"] = "Başka bir eklenti seç"
L["STRING_PLUGINOPTIONS_ABBREVIATE"] = "Kısalt"
L["STRING_PLUGINOPTIONS_COMMA"] = "Virgül"
L["STRING_PLUGINOPTIONS_FONTFACE"] = "Yazı Tipi Seç"
L["STRING_PLUGINOPTIONS_NOFORMAT"] = "Yok"
L["STRING_PLUGINOPTIONS_TEXTALIGN"] = "Yazı Hizası"
L["STRING_PLUGINOPTIONS_TEXTALIGN_X"] = "Yazı Hizası X"
L["STRING_PLUGINOPTIONS_TEXTALIGN_Y"] = "Yazı Hizası Y"
L["STRING_PLUGINOPTIONS_TEXTCOLOR"] = "Yazı Rengi"
L["STRING_PLUGINOPTIONS_TEXTSIZE"] = "Yazı Boyutu"
L["STRING_PLUGINOPTIONS_TEXTSTYLE"] = "Yazı Stili"
L["STRING_QUERY_INSPECT"] = "yetenekleri ve eşya seviyesini al."
L["STRING_QUERY_INSPECT_FAIL1"] = "savaştayken sorgulanamaz."
L["STRING_QUERY_INSPECT_REFRESH"] = "yenileme gerekli"
L["STRING_RAID_WIDE"] = "[*] raid geneli bekleme süresi"
L["STRING_RAIDCHECK_PLUGIN_DESC"] = "Raid zindanındayken Details! başlık çubuğunda iksir, yiyecek ve savaş öncesi iksir kullanımını gösteren simge gösterir."
L["STRING_RAIDCHECK_PLUGIN_NAME"] = "Raid Kontrolü"
L["STRING_RECENT_PLAYERS"] = "Son Oyuncular:"
L["STRING_REPORT"] = "için"
L["STRING_REPORT_BUTTON_TOOLTIP"] = "Rapor Penceresini açmak için tıkla"
L["STRING_REPORT_FIGHT"] = "dövüş"
L["STRING_REPORT_FIGHTS"] = "dövüş"
L["STRING_REPORT_INVALIDTARGET"] = "Fısıltı hedefi bulunamadı"
L["STRING_REPORT_LAST"] = "Son"
L["STRING_REPORT_LASTFIGHT"] = "son dövüş"
L["STRING_REPORT_LEFTCLICK"] = "Rapor penceresini açmak için tıkla"
L["STRING_REPORT_PREVIOUSFIGHTS"] = "önceki dövüşler"
L["STRING_REPORT_SINGLE_BUFFUPTIME"] = "buff süresi:"
L["STRING_REPORT_SINGLE_COOLDOWN"] = "şunun kullandığı bekleme süreleri:"
L["STRING_REPORT_SINGLE_DEATH"] = "Ölüm:"
L["STRING_REPORT_SINGLE_DEBUFFUPTIME"] = "debuff süresi:"
L["STRING_REPORT_TEXT"] = "Rapor"
L["STRING_REPORT_TOOLTIP"] = "Sonuçları Raporla"
L["STRING_REPORTFRAME_COPY"] = "Kopyala ve Yapıştır"
L["STRING_REPORTFRAME_CURRENT"] = "Güncel"
L["STRING_REPORTFRAME_CURRENTINFO"] = "Yalnızca şu anda gösterilen verileri göster (destekleniyorsa)."
L["STRING_REPORTFRAME_GUILD"] = "Lonca"
L["STRING_REPORTFRAME_INSERTNAME"] = "oyuncu adını gir"
L["STRING_REPORTFRAME_LINES"] = "Satırlar"
L["STRING_REPORTFRAME_OFFICERS"] = "Subay Kanalı"
L["STRING_REPORTFRAME_PARTY"] = "Grup"
L["STRING_REPORTFRAME_RAID"] = "Raid"
L["STRING_REPORTFRAME_REVERT"] = "Ters"
L["STRING_REPORTFRAME_REVERTED"] = "ters"
L["STRING_REPORTFRAME_REVERTINFO"] = "artan sırada gönder."
L["STRING_REPORTFRAME_SAY"] = "Söyle"
L["STRING_REPORTFRAME_SEND"] = "Gönder"
L["STRING_REPORTFRAME_WHISPER"] = "Fısılda"
L["STRING_REPORTFRAME_WHISPERTARGET"] = "Fısıltı Hedefi"
L["STRING_REPORTFRAME_WINDOW_TITLE"] = "Details! Bağlantısı"
L["STRING_REPORTHISTORY"] = "Son Raporlar"
L["STRING_RESISTED"] = "Direnildi"
L["STRING_RESIZE_ALL"] = "Tüm pencereleri serbestçe boyutlandır"
L["STRING_RESIZE_COMMON"] = [=[Boyutlandır
]=]
L["STRING_RESIZE_HORIZONTAL"] = [=[Gruptaki tüm pencerelerin
 genişliğini boyutlandır]=]
L["STRING_RESIZE_VERTICAL"] = [=[Gruptaki tüm pencerelerin
 yüksekliğini boyutlandır]=]
L["STRING_RIGHT"] = "sağ"
L["STRING_RIGHT_TO_LEFT"] = "Sağdan Sola"
L["STRING_RIGHTCLICK_CLOSE_LARGE"] = "Bu pencereyi kapatmak için farenin sağ tuşuyla tıkla."
L["STRING_RIGHTCLICK_CLOSE_MEDIUM"] = "Bu pencereyi kapatmak için sağ tıkla."
L["STRING_RIGHTCLICK_CLOSE_SHORT"] = "Kapatmak için sağ tıkla."
L["STRING_RIGHTCLICK_TYPEVALUE"] = "değeri yazmak için sağ tıkla"
L["STRING_SCORE_BEST"] = "|cFFFFFF00%s|r puan aldın, bu en iyi puanın, tebrikler!"
L["STRING_SCORE_NOTBEST"] = "|cFFFFFF00%s|r puan aldın, en iyi puanın %s tarihinde %d eşya seviyesiyle aldığın |cFFFFFF00%s|r."
L["STRING_SCRIPTS_TITLE"] = "Betikler"
L["STRING_SEE_BELOW"] = "aşağıya bak"
L["STRING_SEGMENT"] = "Bölüm"
L["STRING_SEGMENT_EMPTY"] = "bu bölüm boş"
L["STRING_SEGMENT_END"] = "Son"
L["STRING_SEGMENT_ENEMY"] = "Düşman"
L["STRING_SEGMENT_LOWER"] = "bölüm"
L["STRING_SEGMENT_OVERALL"] = "Genel Veri"
L["STRING_SEGMENT_START"] = "Başlangıç"
L["STRING_SEGMENT_TRASH"] = "Trash Temizliği"
L["STRING_SEGMENTS"] = "Bölümler"
L["STRING_SEGMENTS_LIST_BOSS"] = "boss dövüşü"
L["STRING_SEGMENTS_LIST_COMBATTIME"] = "Savaş Süresi"
L["STRING_SEGMENTS_LIST_OVERALL"] = "genel"
L["STRING_SEGMENTS_LIST_TIMEINCOMBAT"] = "Savaşta Geçen Süre"
L["STRING_SEGMENTS_LIST_TOTALTIME"] = "Toplam Süre"
L["STRING_SEGMENTS_LIST_TRASH"] = "trash"
L["STRING_SEGMENTS_LIST_WASTED_TIME"] = "Savaşta Değil"
L["STRING_SHIELD_HEAL"] = "Önlendi"
L["STRING_SHIELD_OVERHEAL"] = "Boşa Giden"
L["STRING_SHORTCUT_RIGHTCLICK"] = "kapatmak için sağ tıkla"
L["STRING_SLASH_API_DESC"] = "eklenti, özel görünüm, aura vb. oluşturmak için API panelini aç."
L["STRING_SLASH_CAPTURE_DESC"] = "tüm veri yakalamayı aç ya da kapat."
L["STRING_SLASH_CAPTUREOFF"] = "tüm veri yakalama kapatıldı."
L["STRING_SLASH_CAPTUREON"] = "tüm veri yakalama açıldı."
L["STRING_SLASH_CHANGES"] = "updates"
L["STRING_SLASH_CHANGES_ALIAS1"] = "news"
L["STRING_SLASH_CHANGES_ALIAS2"] = "changes"
L["STRING_SLASH_CHANGES_DESC"] = "Details!'teki yenilikleri ve değişiklikleri gösterir."
L["STRING_SLASH_DISABLE"] = "disable"
L["STRING_SLASH_ENABLE"] = "enable"
L["STRING_SLASH_HIDE"] = "hide"
L["STRING_SLASH_HIDE_ALIAS1"] = "close"
L["STRING_SLASH_HISTORY"] = "history"
L["STRING_SLASH_NEW"] = "new"
L["STRING_SLASH_NEW_DESC"] = "yeni bir pencere oluştur."
L["STRING_SLASH_OPTIONS"] = "options"
L["STRING_SLASH_OPTIONS_DESC"] = "ayarlar panelini aç."
L["STRING_SLASH_RESET"] = "reset"
L["STRING_SLASH_RESET_ALIAS1"] = "clear"
L["STRING_SLASH_RESET_DESC"] = "tüm bölümleri temizle."
L["STRING_SLASH_SHOW"] = "show"
L["STRING_SLASH_SHOW_ALIAS1"] = "open"
L["STRING_SLASH_SHOWHIDETOGGLE_DESC"] = "<pencere numarası> verilmezse tüm pencereler."
L["STRING_SLASH_TOGGLE"] = "toggle"
L["STRING_SLASH_WIPE"] = "wipe"
L["STRING_SLASH_WIPECONFIG"] = "reinstall"
L["STRING_SLASH_WIPECONFIG_CONFIRM"] = "Yeniden Kuruluma Devam Etmek İçin Tıkla"
L["STRING_SLASH_WIPECONFIG_DESC"] = "tüm ayarları varsayılana döndür; Details! düzgün çalışmıyorsa kullan."
L["STRING_SLASH_WORLDBOSS"] = "worldboss"
L["STRING_SLASH_WORLDBOSS_DESC"] = "bu hafta hangi boss'ları öldürdüğünü gösteren bir makro çalıştır."
L["STRING_SPELL_INTERRUPTED"] = "Kesilen büyüler"
L["STRING_SPELLLIST"] = "Büyü Listesi"
L["STRING_SPELLS"] = "Büyüler"
L["STRING_SPIRIT_LINK_TOTEM"] = "Can Değişimi"
L["STRING_SPIRIT_LINK_TOTEM_DESC"] = [=[Totemin çemberi içindeki oyuncular
arasında değiştirilen can miktarı.

Bu iyileştirme oyuncunun yaptığı
toplam iyileştirmeye eklenmez.]=]
L["STRING_STATISTICS"] = "İstatistikler"
L["STRING_STATUSBAR_NOOPTIONS"] = "Bu bileşenin seçeneği yok."
L["STRING_SWITCH_CLICKME"] = "yer imi ekle"
L["STRING_SWITCH_SELECTMSG"] = "Yer İmi #%d için görünümü seç."
L["STRING_SWITCH_TO"] = "Şuna Geç"
L["STRING_SWITCH_WARNING"] = "Rol değişti. Geçiliyor: |cFFFFAA00%s|r  "
L["STRING_TARGET"] = "Hedef"
L["STRING_TARGETS"] = "Hedefler"
L["STRING_TARGETS_OTHER1"] = "Petler ve Diğer Hedefler"
L["STRING_TELEPORT"] = "Işınlanma"
L["STRING_TELEPORTERS"] = "Işınlayıcılar"
L["STRING_TEXTURE"] = "Doku"
L["STRING_TIME_OF_DEATH"] = "Ölüm"
L["STRING_TOOOLD"] = "Details! sürümün çok eski olduğu için kurulamadı."
L["STRING_TOP"] = "üst"
L["STRING_TOP_TO_BOTTOM"] = "Yukarıdan Aşağı"
L["STRING_TOTAL"] = " Toplamı"
L["STRING_TRAINING_DUMMY"] = "Antrenman Kuklası"
L["STRING_TRANSLATE_LANGUAGE"] = "Details! Çevirisine Yardım Et"
L["STRING_TUTORIAL_FULLY_DELETE_WINDOW"] = [=[Bir pencereyi kapattın, onu her zaman yeniden açabilirsin.
Bir pencereyi tamamen silmek için Ayarlar -> Pencere: Genel -> Sil'e git.]=]
L["STRING_TUTORIAL_OVERALL1"] = [=[Genel veri yalnızca savaş bitince güncellenir; düzenli güncelleme istiyorsan başlık çubuğuna sağ tıkla ve 'Dinamik Genel Veri'yi seç.
]=]
L["STRING_UNKNOW"] = "Bilinmiyor"
L["STRING_UNKNOWSPELL"] = "Bilinmeyen Büyü"
L["STRING_UNLOCK"] = [=[Pencereleri bu düğmeden
 gruptan ayır]=]
L["STRING_UNLOCK_WINDOW"] = "kilidi aç"
L["STRING_UPTADING"] = "güncelleniyor"
L["STRING_VERSION_AVAILABLE"] = "yeni bir sürüm çıktı, Curse Forge uygulamasından ya da sitesinden indir."
L["STRING_VERSION_UPDATE"] = "yeni sürüm: neler değişti? buraya tıkla"
L["STRING_VOIDZONE_TOOLTIP"] = "Hasar ve Süre"
L["STRING_WAITPLUGIN"] = [=[  Eklenti Kullanılamıyor, Lütfen Kontrol Et:

- Esc > Eklentiler > orada açık mı.
- Details! ayarlarındaki Eklentiler sayfası.
- Eklenti başka bir pencerede açık.
- Eklenti kapalı bir pencerede kullanılıyor.

]=]
L["STRING_WAVE"] = "dalga"
L["STRING_WELCOME_1"] = [=[|cFFFFFFFFDetails! Hızlı Kurulum Sihirbazına Hoş Geldin|r

Gezinmek için sağ alttaki okları kullan.]=]
L["STRING_WELCOME_11"] = "fikrini değiştirirsen ayarlar panelinden her zaman yeniden değiştirebilirsin"
L["STRING_WELCOME_12"] = "Pencerenin ne kadar hızlı güncelleneceğini seç; Hps ve Dps sayıları için animasyonları ve gerçek zamanlı güncellemeyi de açabilirsin."
--[[Translation missing --]]
L["STRING_WELCOME_13"] = ""
--[[Translation missing --]]
L["STRING_WELCOME_14"] = ""
L["STRING_WELCOME_15"] = "Hoş geldin penceresindeki güncelleme hızı için ipucu."
--[[Translation missing --]]
L["STRING_WELCOME_16"] = ""
--[[Translation missing --]]
L["STRING_WELCOME_17"] = ""
L["STRING_WELCOME_2"] = "fikrini değiştirirsen ayarlar panelinden her zaman yeniden değiştirebilirsin"
L["STRING_WELCOME_26"] = "Arayüzü Kullanma: Uzatma"
L["STRING_WELCOME_27"] = [=[Vurgulanan düğme Uzatıcıdır. |cFFFFFF00Tıkla|r ve |cFFFFFF00yukarı sürükle!|r.


Pencere kilitliyse başlık çubuğunun tamamı uzatma düğmesine dönüşür.]=]
L["STRING_WELCOME_28"] = "Arayüzü Kullanma: Pencere Kontrolü"
L["STRING_WELCOME_29"] = [=[Pencere Kontrolü temelde iki şey yapar:

- bir |cFFFFFF00yeni pencere|r açar.
- her zaman yeniden açılabilecek |cFFFFFF00kapalı pencereleri|r gösteren bir menü açar.]=]
L["STRING_WELCOME_3"] = "Tercih ettiğin DPS ve HPS yöntemini seç:"
L["STRING_WELCOME_30"] = "Arayüzü Kullanma: Yer İmleri"
L["STRING_WELCOME_31"] = [=[Pencerenin herhangi bir yerine |cFFFFFF00sağ tıklamak|r |cFFFFAA00Yer İmi|r panelini gösterir.

|cFFFFFF00Yeniden sağ tıklamak|r paneli kapatır ya da bir simgeye tıklanırsa başka bir görünüm seçer.

'Tüm Görünümler' panelini açmak için başlık çubuğuna |cFFFFFF00sağ tıkla|r.

Pencereyi kapatmak için |TInterface\AddOns\Details\images\key_ctrl:14:30:0:0:64:64:0:64:0:40|t + Sağ Tık.]=]
L["STRING_WELCOME_32"] = "Arayüzü Kullanma: Pencereleri Grupla"
L["STRING_WELCOME_34"] = "Arayüzü Kullanma: İpucunu Genişlet"
L["STRING_WELCOME_36"] = "Arayüzü Kullanma: Eklentiler"
L["STRING_WELCOME_38"] = "Raid'e Hazır!"
L["STRING_WELCOME_39"] = [=[Details!'i seçtiğin için teşekkürler!

Görüşlerini ve hata bildirimlerini bize her zaman gönderebilirsin.


 |cFFFFAA00/details feedback|r]=]
L["STRING_WELCOME_4"] = "Etkinlik Süresi: "
L["STRING_WELCOME_41"] = "Arayüz Eğlence Ayarları:"
L["STRING_WELCOME_42"] = "Hızlı Görünüm Ayarları"
L["STRING_WELCOME_43"] = "Tercih ettiğin görünümü seç:"
--[[Translation missing --]]
L["STRING_WELCOME_44"] = ""
L["STRING_WELCOME_45"] = "Daha fazla özelleştirme için ayarlar paneline bak."
--[[Translation missing --]]
L["STRING_WELCOME_46"] = ""
L["STRING_WELCOME_5"] = "Etkin Süre: "
--[[Translation missing --]]
L["STRING_WELCOME_57"] = ""
L["STRING_WELCOME_58"] = [=[Önceden tanımlı görünüm ayarı setleri.

|cFFFFFF00Önemli|r: tüm ayarlar daha sonra ayarlar panelinden değiştirilebilir.]=]
--[[Translation missing --]]
L["STRING_WELCOME_59"] = ""
L["STRING_WELCOME_6"] = "her raid üyesinin sayacı etkinliği durunca bekletilir, yeniden başlayınca saymaya devam eder."
--[[Translation missing --]]
L["STRING_WELCOME_60"] = ""
--[[Translation missing --]]
L["STRING_WELCOME_61"] = ""
--[[Translation missing --]]
L["STRING_WELCOME_62"] = ""
L["STRING_WELCOME_63"] = "DPS/HPS'yi Gerçek Zamanlı Güncelle"
--[[Translation missing --]]
L["STRING_WELCOME_64"] = ""
L["STRING_WELCOME_65"] = "Sağ Tuşa Bas!"
L["STRING_WELCOME_66"] = [=[Grup oluşturmak için bir pencereyi diğerinin yanına sürükle.

Gruplanmış pencereler birlikte uzar ve boyutlanır.

Çift olarak daha mutlu yaşarlar.]=]
L["STRING_WELCOME_67"] = [=[Oyuncunun ipucunu genişletip kullanılan tüm büyüleri görmek için Shift'e bas.

Hedefler için Ctrl, Petler için Alt.]=]
L["STRING_WELCOME_68"] = [=[Details!'i 'Eklentiler' adlı
bir veba sarmış.

Her yerdeler ve
birçok işte sana yardım ederler.

Örnekler: tehdit ölçer, dps analizi, karşılaşma özeti, grafik oluşturma ve daha fazlası.]=]
L["STRING_WELCOME_69"] = "Atla"
L["STRING_WELCOME_7"] = "sıralamalar için kullanılır; tüm raid üyelerinin DPS ve HPS'ini ölçmek için geçen savaş süresini kullanır."
--[[Translation missing --]]
L["STRING_WELCOME_70"] = ""
--[[Translation missing --]]
L["STRING_WELCOME_71"] = ""
--[[Translation missing --]]
L["STRING_WELCOME_72"] = ""
L["STRING_WELCOME_73"] = "Alfabeyi ya da Bölgeyi Seç:"
L["STRING_WELCOME_74"] = "Latin Alfabesi"
L["STRING_WELCOME_75"] = "Kiril Alfabesi"
L["STRING_WELCOME_76"] = "Çin"
L["STRING_WELCOME_77"] = "Kore"
L["STRING_WELCOME_78"] = "Tayvan"
L["STRING_WELCOME_79"] = "2. Pencereyi Oluştur"
L["STRING_WINDOW_NOTFOUND"] = "Pencere bulunamadı."
L["STRING_WINDOW_NUMBER"] = "pencere numarası"
L["STRING_WINDOW1ATACH_DESC"] = "Bir pencere grubu oluşturmak için 2. pencereyi 1. pencerenin yanına sürükle."
L["STRING_WIPE_ALERT"] = "Raid Lideri Çağrısı: Wipe!"
L["STRING_WIPE_ERROR1"] = "zaten bir wipe çağrısı yapıldı."
L["STRING_WIPE_ERROR2"] = "bir raid karşılaşmasında değiliz."
L["STRING_WIPE_ERROR3"] = "karşılaşma bitirilemedi."
L["STRING_YES"] = "Evet"


L["ABILITY_ID"] = "yetenek kimliği"
L["STRING_"] = ""
L["STRING_ABSORBED"] = "Emildi"
L["STRING_ACTORFRAME_NOTHING"] = "hay aksi, raporlanacak veri yok :("
L["STRING_ACTORFRAME_REPORTAT"] = "şurada:"
L["STRING_ACTORFRAME_REPORTOF"] = " / "
L["STRING_ACTORFRAME_REPORTTARGETS"] = "şunun hedefleri için rapor:"
L["STRING_ACTORFRAME_REPORTTO"] = "şunun raporu:"
L["STRING_ACTORFRAME_SPELLDETAILS"] = "Büyü ayrıntıları"
L["STRING_ACTORFRAME_SPELLSOF"] = "Büyüleri:"
L["STRING_ACTORFRAME_SPELLUSED"] = "Kullanılan tüm büyüler"
L["STRING_AGAINST"] = "karşı"
L["STRING_ALIVE"] = "Hayatta"
L["STRING_ALPHA"] = "Saydamlık"
L["STRING_ANCHOR_BOTTOM"] = "Alt"
L["STRING_ANCHOR_BOTTOMLEFT"] = "Sol Alt"
L["STRING_ANCHOR_BOTTOMRIGHT"] = "Sağ Alt"
L["STRING_ANCHOR_LEFT"] = "Sol"
L["STRING_ANCHOR_RIGHT"] = "Sağ"
L["STRING_ANCHOR_TOP"] = "Üst"
L["STRING_ANCHOR_TOPLEFT"] = "Sol Üst"
L["STRING_ANCHOR_TOPRIGHT"] = "Sağ Üst"
L["STRING_ASCENDING"] = "Artan"
L["STRING_ATACH_DESC"] = "#%d numaralı pencere, #%d numaralı pencereyle grup oluşturdu."
L["STRING_ATTRIBUTE_CUSTOM"] = "Özel"
L["STRING_ATTRIBUTE_DAMAGE"] = "Hasar"
L["STRING_ATTRIBUTE_DAMAGE_BYSPELL"] = "Büyüye Göre Alınan Hasar"
L["STRING_ATTRIBUTE_DAMAGE_DEBUFFS"] = "Auralar ve Yer Etkileri"
L["STRING_ATTRIBUTE_DAMAGE_DEBUFFS_REPORT"] = "Debuff Hasarı ve Süresi"
L["STRING_ATTRIBUTE_DAMAGE_DONE"] = "Verilen Hasar"
L["STRING_ATTRIBUTE_DAMAGE_DPS"] = "DPS"
L["STRING_ATTRIBUTE_DAMAGE_ENEMIES"] = "Düşmanın Aldığı Hasar"
L["STRING_ATTRIBUTE_DAMAGE_ENEMIES_DONE"] = "Düşmanın Verdiği Hasar"
L["STRING_ATTRIBUTE_DAMAGE_FRAGS"] = "Öldürmeler"
L["STRING_ATTRIBUTE_DAMAGE_FRIENDLYFIRE"] = "Dost Ateşi"
L["STRING_ATTRIBUTE_DAMAGE_TAKEN"] = "Alınan Hasar"
L["STRING_ATTRIBUTE_ENERGY"] = "Kaynaklar"
L["STRING_ATTRIBUTE_ENERGY_ALTERNATEPOWER"] = "Alternatif Güç"
L["STRING_ATTRIBUTE_ENERGY_ENERGY"] = "Üretilen Enerji"
L["STRING_ATTRIBUTE_ENERGY_MANA"] = "Geri Kazanılan Mana"
L["STRING_ATTRIBUTE_ENERGY_RAGE"] = "Üretilen Öfke"
L["STRING_ATTRIBUTE_ENERGY_RESOURCES"] = "Diğer Kaynaklar"
L["STRING_ATTRIBUTE_ENERGY_RUNEPOWER"] = "Üretilen Runic Power"
L["STRING_ATTRIBUTE_HEAL"] = "İyileştirme"
L["STRING_ATTRIBUTE_HEAL_ABSORBED"] = "Emilen İyileştirme"
L["STRING_ATTRIBUTE_HEAL_DONE"] = "Yapılan İyileştirme"
L["STRING_ATTRIBUTE_HEAL_ENEMY"] = "Düşmanın Yaptığı İyileştirme"
L["STRING_ATTRIBUTE_HEAL_HPS"] = "HPS"
L["STRING_ATTRIBUTE_HEAL_OVERHEAL"] = "Fazla İyileştirme"
L["STRING_ATTRIBUTE_HEAL_PREVENT"] = "Önlenen Hasar"
L["STRING_ATTRIBUTE_HEAL_TAKEN"] = "Alınan İyileştirme"
L["STRING_ATTRIBUTE_MISC"] = "Çeşitli"
L["STRING_ATTRIBUTE_MISC_BUFF_UPTIME"] = "Buff Süresi"
L["STRING_ATTRIBUTE_MISC_CCBREAK"] = "CC Bozmaları"
L["STRING_ATTRIBUTE_MISC_DEAD"] = "Ölümler"
L["STRING_ATTRIBUTE_MISC_DEBUFF_UPTIME"] = "Debuff Süresi"
L["STRING_ATTRIBUTE_MISC_DEFENSIVE_COOLDOWNS"] = "Bekleme Süreleri"
L["STRING_ATTRIBUTE_MISC_DISPELL"] = "Dispel'ler"
L["STRING_ATTRIBUTE_MISC_INTERRUPT"] = "Kesmeler"
L["STRING_ATTRIBUTE_MISC_RESS"] = "Diriltme"
L["STRING_AUTO"] = "otomatik"
L["STRING_AUTOSHOT"] = "Auto Shot"
L["STRING_AVERAGE"] = "Ortalama"
L["STRING_BLOCKED"] = "Bloklandı"
L["STRING_BOTTOM"] = "alt"
L["STRING_BOTTOM_TO_TOP"] = "Aşağıdan Yukarı"
L["STRING_CAST"] = "Büyü Yapımları"
L["STRING_CAUGHT"] = "yakalandı"
L["STRING_CCBROKE"] = "Kaldırılan Kitle Kontrolü"
L["STRING_CENTER"] = "orta"
L["STRING_CENTER_UPPER"] = "Orta"
L["STRING_CHANGED_TO_CURRENT"] = "Bölüm Değişti: |cFFFFFF00Şimdiki|r"
L["STRING_CHANNEL_PRINT"] = "Gözlemci"
L["STRING_CHANNEL_RAID"] = "Raid"
L["STRING_CHANNEL_SAY"] = "Söyle"
L["STRING_CHANNEL_WHISPER"] = "Fısılda"
L["STRING_CHANNEL_WHISPER_TARGET_COOLDOWN"] = "Bekleme Süresi Hedefine Fısılda"
L["STRING_CHANNEL_YELL"] = "Bağır"
L["STRING_CLICK_REPORT_LINE1"] = "|cFFFFCC22Tıkla|r: |cFFFFEE00raporla|r"
L["STRING_CLICK_REPORT_LINE2"] = "|cFFFFCC22Shift+Tık|r: |cFFFFEE00pencere modu|r"
L["STRING_CLOSEALL"] = "Tüm pencereler kapalı; yeniden açmak için '/details show' yazabilirsin."
L["STRING_COLOR"] = "Renk"
L["STRING_COMMAND_LIST"] = "komut listesi"
L["STRING_CONTEXT"] = "Bağlam"
L["STRING_COOLTIP_NOOPTIONS"] = "seçenek yok"
L["STRING_CREATEAURA"] = "Aura Oluştur"
L["STRING_CRITICAL_HITS"] = "Kritik Vuruşlar"
L["STRING_CRITICAL_ONLY"] = "kritik"
L["STRING_CURRENT"] = "Güncel"
L["STRING_CURRENTFIGHT"] = "Şimdiki Bölüm"
L["STRING_CUSTOM_ACTIVITY_ALL"] = "Etkinlik Süresi"
L["STRING_CUSTOM_ACTIVITY_ALL_DESC"] = "Raid grubundaki her oyuncunun etkinlik sonuçlarını gösterir."
L["STRING_CUSTOM_ACTIVITY_DPS"] = "Hasar Etkinlik Süresi"
L["STRING_CUSTOM_ACTIVITY_DPS_DESC"] = "Her karakterin hasar vermekle ne kadar zaman geçirdiğini gösterir."
L["STRING_CUSTOM_ACTIVITY_HPS"] = "İyileştirme Etkinlik Süresi"
L["STRING_CUSTOM_ACTIVITY_HPS_DESC"] = "Her karakterin iyileştirme yapmakla ne kadar zaman geçirdiğini gösterir."
L["STRING_CUSTOM_ATTRIBUTE_DAMAGE"] = "Hasar"
L["STRING_CUSTOM_ATTRIBUTE_HEAL"] = "İyileştirme"
L["STRING_CUSTOM_ATTRIBUTE_SCRIPT"] = "Özel Betik"
L["STRING_CUSTOM_AUTHOR"] = "Yazar:"
L["STRING_CUSTOM_AUTHOR_DESC"] = "Bu görünümü oluşturan kişi."
L["STRING_CUSTOM_CANCEL"] = "İptal"
L["STRING_CUSTOM_CC_DONE"] = "Yapılan Kitle Kontrolü"
L["STRING_CUSTOM_CC_RECEIVED"] = "Alınan Kitle Kontrolü"
L["STRING_CUSTOM_CREATE"] = "Oluştur"
L["STRING_CUSTOM_CREATED"] = "Yeni görünüm oluşturuldu."
L["STRING_CUSTOM_DAMAGEONANYMARKEDTARGET"] = "Diğer İşaretli Hedeflere Hasar"
L["STRING_CUSTOM_DAMAGEONANYMARKEDTARGET_DESC"] = "Başka işaretlerle işaretlenmiş hedeflere verilen hasar miktarını göster."
L["STRING_CUSTOM_DAMAGEONSHIELDS"] = "Kalkanlara Hasar"
L["STRING_CUSTOM_DAMAGEONSKULL"] = "Kurukafa İşaretli Hedeflere Hasar"
L["STRING_CUSTOM_DAMAGEONSKULL_DESC"] = "Kurukafa işaretli hedeflere verilen hasar miktarını göster."
L["STRING_CUSTOM_DESCRIPTION"] = "Açıklama:"
L["STRING_CUSTOM_DESCRIPTION_DESC"] = "Bu görünümün ne yaptığına dair açıklama."
L["STRING_CUSTOM_DONE"] = "Bitti"
L["STRING_CUSTOM_DTBS"] = "Büyüye Göre Alınan Hasar"
L["STRING_CUSTOM_DTBS_DESC"] = "Düşman büyülerinin grubuna verdiği hasarı göster."
L["STRING_CUSTOM_DYNAMICOVERAL"] = "Dinamik Genel Hasar"
L["STRING_CUSTOM_EDIT"] = "Düzenle"
L["STRING_CUSTOM_EDIT_SEARCH_CODE"] = "Arama Kodunu Düzenle"
L["STRING_CUSTOM_EDIT_TOOLTIP_CODE"] = "İpucu Kodunu Düzenle"
L["STRING_CUSTOM_EDITCODE_DESC"] = "Bu, kullanıcının kendi görünüm kodunu yazabildiği gelişmiş bir işlevdir."
L["STRING_CUSTOM_EDITTOOLTIP_DESC"] = "Bu, ipucu kodudur; kullanıcı bir çubuğun üzerine gelince çalışır."
L["STRING_CUSTOM_ENEMY_DT"] = " Alınan Hasar"
L["STRING_CUSTOM_EXPORT"] = "Dışa Aktar"
L["STRING_CUSTOM_FUNC_INVALID"] = "Özel betik geçersiz, pencere yenilenemiyor."
L["STRING_CUSTOM_HEALTHSTONE_DEFAULT"] = "Can İksiri ve Taşı"
L["STRING_CUSTOM_HEALTHSTONE_DEFAULT_DESC"] = "Raid grubunda kimin sağlık taşı ya da iyileştirme iksiri kullandığını göster."
L["STRING_CUSTOM_ICON"] = "Simge:"
L["STRING_CUSTOM_IMPORT"] = "İçe Aktar"
L["STRING_CUSTOM_IMPORT_ALERT"] = "Görünüm yüklendi, onaylamak için İçe Aktar'a tıkla."
L["STRING_CUSTOM_IMPORT_BUTTON"] = "İçe Aktar"
L["STRING_CUSTOM_IMPORT_ERROR"] = "İçe aktarma başarısız, geçersiz metin."
L["STRING_CUSTOM_IMPORTED"] = "Görünüm başarıyla içe aktarıldı."
L["STRING_CUSTOM_LONGNAME"] = "Ad çok uzun, en fazla 32 karakter olabilir."
L["STRING_CUSTOM_MYSPELLS"] = "Büyülerim"
L["STRING_CUSTOM_MYSPELLS_DESC"] = "Büyülerini pencerede göster."
L["STRING_CUSTOM_NAME"] = "Ad:"
L["STRING_CUSTOM_NAME_DESC"] = "Yeni özel görünümünün adını gir."
L["STRING_CUSTOM_NEW"] = "Özel Görünümleri Yönet"
L["STRING_CUSTOM_PASTE"] = "Buraya Yapıştır:"
L["STRING_CUSTOM_POT_DEFAULT"] = "Kullanılan İksir"
L["STRING_CUSTOM_POT_DEFAULT_DESC"] = "Raidinde karşılaşma sırasında kimin iksir kullandığını göster."
L["STRING_CUSTOM_REMOVE"] = "Kaldır"
L["STRING_CUSTOM_REPORT"] = "(özel)"
L["STRING_CUSTOM_SAVE"] = "Değişiklikleri Kaydet"
L["STRING_CUSTOM_SAVED"] = "Görünüm kaydedildi."
L["STRING_CUSTOM_SHORTNAME"] = "Ad en az 5 karakter olmalı."
L["STRING_CUSTOM_SKIN_TEXTURE"] = "Özel Görünüm Dosyası"
L["STRING_CUSTOM_SKIN_TEXTURE_DESC"] = [=[.tga dosyasının adı.

Şu klasöre konmalıdır:

|cFFFFFF00WoW/Interface/|r

|cFFFFFF00Önemli:|r dosyayı oluşturmadan önce oyunu kapat. Sonra /reload, doku dosyasında kaydedilen değişiklikleri uygular.]=]
L["STRING_CUSTOM_SOURCE"] = "Kaynak:"
L["STRING_CUSTOM_SOURCE_DESC"] = [=[Etkiyi kimin tetiklediği.

Sağdaki düğme raid karşılaşmalarındaki NPC'lerin listesini gösterir.]=]
L["STRING_CUSTOM_SPELLID"] = "Büyü Kimliği:"
L["STRING_CUSTOM_SPELLID_DESC"] = [=[İsteğe bağlı; kaynağın etkiyi hedefe uygulamak için kullandığı büyü.

Sağdaki düğme raid karşılaşmalarındaki büyülerin listesini gösterir.]=]
L["STRING_CUSTOM_TARGET"] = "Hedef:"
L["STRING_CUSTOM_TARGET_DESC"] = [=[Bu, kaynağın hedefidir.

Sağdaki düğme raid karşılaşmalarındaki NPC'lerin listesini gösterir.]=]
L["STRING_CUSTOM_TEMPORARILY"] = " (|cFFFFC000geçici olarak|r)"
L["STRING_CUSTOM_TEXTURE_GUIDE"] = [=[Simgeler için özel bir dosya kullanmak için:
- Dosya .TGA biçiminde olmalı.
- Dosya 512x512 piksel olmalı.
- Uzmanlık için dosya adında 'spec_' geçmeli.
- Dokuyu /WoW Kurulum Klasörü/_retail_/Interface/ içine koy]=]
L["STRING_DAMAGE"] = "Hasar"
L["STRING_DAMAGE_DPS_IN"] = "şundan alınan DPS:"
L["STRING_DAMAGE_FROM"] = "Şundan hasar aldı:"
L["STRING_DAMAGE_TAKEN_FROM"] = "Şundan Alınan Hasar:"
L["STRING_DAMAGE_TAKEN_FROM2"] = "şununla hasar verdi:"
L["STRING_DEFENSES"] = "Savunmalar"
L["STRING_DESCENDING"] = "Azalan"
L["STRING_DETACH_DESC"] = "Pencere Grubunu Ayır"
L["STRING_DISCARD"] = "Vazgeç"
L["STRING_DISPELLED"] = "Kaldırılan Buff/Debuff'lar"
L["STRING_DODGE"] = "Sıyrılma"
L["STRING_DOT"] = " (DoT)"
L["STRING_DPS"] = "DPS"
L["STRING_EMPTY_SEGMENT"] = "Boş Bölüm"
L["STRING_ENABLE_DO_NOT_DISTURB"] = "Rahatsız Etme'yi Aç"
L["STRING_ENABLED"] = "Etkin"
L["STRING_ENVIRONMENTAL_DROWNING"] = "Ortam (Boğulma)"
L["STRING_ENVIRONMENTAL_FALLING"] = "Ortam (Düşme)"
L["STRING_ENVIRONMENTAL_FATIGUE"] = "Ortam (Yorgunluk)"
L["STRING_ENVIRONMENTAL_FIRE"] = "Ortam (Ateş)"
L["STRING_ENVIRONMENTAL_LAVA"] = "Ortam (Lav)"
L["STRING_ENVIRONMENTAL_SLIME"] = "Ortam (Balçık)"
L["STRING_ERASE"] = "sil"
L["STRING_ERASE_DATA"] = "Tüm Veriyi Sıfırla"
L["STRING_ERASE_DATA_OVERALL"] = "Genel Veriyi Sıfırla"
L["STRING_ERASE_IN_COMBAT"] = "Şimdiki savaştan sonra genel veri silinecek."
L["STRING_EXAMPLE"] = "Örnek"
L["STRING_EXPLOSION"] = "patlama"
L["STRING_FAIL_ATTACKS"] = "Başarısız Saldırılar"
L["STRING_FEEDBACK_CURSE_DESC"] = "Details! sayfasında bir kayıt aç ya da mesaj bırak."
L["STRING_FEEDBACK_MMOC_DESC"] = "mmo-champion forumundaki konumuza yaz."
L["STRING_FEEDBACK_PREFERED_SITE"] = "Tercih ettiğin topluluk sitesini seç:"
L["STRING_FEEDBACK_SEND_FEEDBACK"] = "Geri Bildirim Gönder"
L["STRING_FEEDBACK_WOWI_DESC"] = "Details! proje sayfasına yorum bırak."
L["STRING_FIGHTNUMBER"] = "Dövüş #"
L["STRING_FORGE_BUTTON_ALLSPELLS"] = "Tüm Büyüler"
L["STRING_FORGE_BUTTON_ALLSPELLS_DESC"] = "Oyuncuların ve NPC'lerin tüm büyülerini listele."
L["STRING_FORGE_BUTTON_BWTIMERS"] = "BigWigs Sayaçları"
L["STRING_FORGE_BUTTON_BWTIMERS_DESC"] = "BigWigs sayaçlarını listele"
L["STRING_FORGE_BUTTON_DBMTIMERS"] = "DBM Sayaçları"
L["STRING_FORGE_BUTTON_DBMTIMERS_DESC"] = "Deadly Boss Mods sayaçlarını listele"
L["STRING_FORGE_BUTTON_ENCOUNTERSPELLS"] = "Boss Büyüleri"
L["STRING_FORGE_BUTTON_ENCOUNTERSPELLS_DESC"] = "Yalnızca raid ve zindan karşılaşmalarındaki büyüleri listele."
L["STRING_FORGE_BUTTON_ENEMIES"] = "Düşmanlar"
L["STRING_FORGE_BUTTON_ENEMIES_DESC"] = "Şimdiki savaştaki düşmanları listele."
L["STRING_FORGE_BUTTON_PETS"] = "Petler"
L["STRING_FORGE_BUTTON_PETS_DESC"] = "Şimdiki savaştaki petleri listele."
L["STRING_FORGE_BUTTON_PLAYERS"] = "Oyuncular"
L["STRING_FORGE_BUTTON_PLAYERS_DESC"] = "Şimdiki savaştaki oyuncuları listele."
L["STRING_FORGE_ENABLEPLUGINS"] = "\"Lütfen Raid adlı Details! eklentilerini Escape Menüsü > AddOns'tan aç, ör. Details: Tomb of Sargeras.\""
L["STRING_FORGE_FILTER_BARTEXT"] = "Çubuk Adı"
L["STRING_FORGE_FILTER_CASTERNAME"] = "Büyüyü Yapanın Adı"
L["STRING_FORGE_FILTER_ENCOUNTERNAME"] = "Karşılaşma Adı"
L["STRING_FORGE_FILTER_ENEMYNAME"] = "Düşman Adı"
L["STRING_FORGE_FILTER_OWNERNAME"] = "Sahip Adı"
L["STRING_FORGE_FILTER_PETNAME"] = "Pet Adı"
L["STRING_FORGE_FILTER_PLAYERNAME"] = "Oyuncu Adı"
L["STRING_FORGE_FILTER_SPELLNAME"] = "Büyü Adı"
L["STRING_FORGE_HEADER_BARTEXT"] = "Çubuk Yazısı"
L["STRING_FORGE_HEADER_CASTER"] = "Büyüyü Yapan"
L["STRING_FORGE_HEADER_CLASS"] = "Sınıf"
L["STRING_FORGE_HEADER_CREATEAURA"] = "Aura Oluştur"
L["STRING_FORGE_HEADER_ENCOUNTERID"] = "Karşılaşma Kimliği"
L["STRING_FORGE_HEADER_ENCOUNTERNAME"] = "Karşılaşma Adı"
L["STRING_FORGE_HEADER_EVENT"] = "Etkinlik"
L["STRING_FORGE_HEADER_FLAG"] = "Bayrak"
L["STRING_FORGE_HEADER_GUID"] = "GUID"
L["STRING_FORGE_HEADER_ICON"] = "Simge"
L["STRING_FORGE_HEADER_ID"] = "Kimlik"
L["STRING_FORGE_HEADER_INDEX"] = "Sıra"
L["STRING_FORGE_HEADER_NAME"] = "Ad"
L["STRING_FORGE_HEADER_NPCID"] = "NpcID"
L["STRING_FORGE_HEADER_OWNER"] = "Sahip"
L["STRING_FORGE_HEADER_SCHOOL"] = "Büyü Okulu"
L["STRING_FORGE_HEADER_SPELLID"] = "SpellID"
L["STRING_FORGE_HEADER_TIMER"] = "Sayaç"
L["STRING_FORGE_TUTORIAL_DESC"] = "'|cFFFFFF00Aura Oluştur|r'a tıklayarak aura oluşturmak için büyülere ve boss mod sayaçlarına göz at."
L["STRING_FORGE_TUTORIAL_TITLE"] = "Details! Forge'a Hoş Geldin"
L["STRING_FORGE_TUTORIAL_VIDEO"] = "Boss mod sayaçlarını kullanan bir Aura örneği:"
L["STRING_FREEZE"] = "Bu bölüm şu anda kullanılamıyor"
L["STRING_FROM"] = "Kimden"
L["STRING_GERAL"] = "Genel"
L["STRING_GLANCING"] = "Sıyırma"
L["STRING_GUILDDAMAGERANK_BOSS"] = "Boss"
L["STRING_GUILDDAMAGERANK_DATABASEERROR"] = "'|cFFFFFF00Details! Storage|r' açılamadı, eklenti kapalı olabilir mi?"
L["STRING_GUILDDAMAGERANK_DIFF"] = "Zorluk"
L["STRING_GUILDDAMAGERANK_GUILD"] = "Lonca"
L["STRING_GUILDDAMAGERANK_PLAYERBASE"] = "Oyuncu Tabanı"
L["STRING_GUILDDAMAGERANK_PLAYERBASE_INDIVIDUAL"] = "Bireysel"
L["STRING_GUILDDAMAGERANK_PLAYERBASE_PLAYER"] = "Oyuncu"
L["STRING_GUILDDAMAGERANK_PLAYERBASE_RAID"] = "Tüm Oyuncular"
L["STRING_GUILDDAMAGERANK_RAID"] = "Raid"
L["STRING_GUILDDAMAGERANK_ROLE"] = "Rol"
L["STRING_GUILDDAMAGERANK_SHOWHISTORY"] = "Öldürme Zaman Çizelgesi"
L["STRING_GUILDDAMAGERANK_SHOWRANK"] = "Lonca Rütbesi"
L["STRING_GUILDDAMAGERANK_SYNCBUTTONTEXT"] = "Loncayla Eşitle"
L["STRING_GUILDDAMAGERANK_TUTORIAL_DESC"] = "Details! store the damage and healing done for each boss encounter you run with your guild.\\n\\nBrowse the history by checking the box '|cFFFFFF00Show History|r', results for all fights will be displayed.\\n By selecting '|cFFFFFF00Show Guild Rank|r', the top scores for the selected boss is shown.\\n\\nIf you are using this tool for the first time or if you lost a day of raiding, click on the '|cFFFFFF00Sync With Guild|r' button."
L["STRING_GUILDDAMAGERANK_WINDOWALERT"] = "Boss Yenildi! Sıralamayı Göster"
L["STRING_HEAL"] = "İyileştirme"
L["STRING_HEAL_ABSORBED"] = "Emilen iyileştirme"
L["STRING_HEAL_CRIT"] = "Kritik İyileştirme"
L["STRING_HEALING_FROM"] = "şundan alınan iyileştirme:"
L["STRING_HEALING_HPS_FROM"] = "şundan alınan HPS:"
L["STRING_HITS"] = "Vuruşlar"
L["STRING_HPS"] = "HPS"
L["STRING_IMAGEEDIT_ALPHA"] = "Saydamlık"
L["STRING_IMAGEEDIT_CROPBOTTOM"] = "Alttan Kırp"
L["STRING_IMAGEEDIT_CROPLEFT"] = "Soldan Kırp"
L["STRING_IMAGEEDIT_CROPRIGHT"] = "Sağdan Kırp"
L["STRING_IMAGEEDIT_CROPTOP"] = "Üstten Kırp"
L["STRING_IMAGEEDIT_DONE"] = "BİTTİ"
L["STRING_IMAGEEDIT_FLIPH"] = "Yatay Çevir"
L["STRING_IMAGEEDIT_FLIPV"] = "Dikey Çevir"
L["STRING_INFO_TAB_AVOIDANCE"] = "Kaçınma"
L["STRING_INFO_TAB_COMPARISON"] = "Karşılaştır"
L["STRING_INFO_TAB_SUMMARY"] = "Özet"
L["STRING_INFO_TUTORIAL_COMPARISON1"] = "Aynı sınıftaki oyuncular arasındaki karşılaştırmaları görmek için |cFFFFDD00Karşılaştır|r sekmesine tıkla."
L["STRING_INSTANCE_CHAT"] = "Zindan Sohbeti"
L["STRING_INSTANCE_LIMIT"] = "en fazla pencere sayısına ulaşıldı, bu sınırı ayarlar panelinden değiştirebilirsin. Kapalı pencereleri (#) pencere menüsünden yeniden açabilirsin."
L["STRING_INTERFACE_OPENOPTIONS"] = "Ayarlar Panelini Aç"
L["STRING_INVERT_RULE"] = "Kuralı Ters Çevir"
L["STRING_ISA_PET"] = "Bu Birim Bir Pet"
L["STRING_KEYBIND_BOOKMARK"] = "Yer İmi"
L["STRING_KEYBIND_BOOKMARK_NUMBER"] = "Yer İmi #%s"
L["STRING_KEYBIND_RESET_SEGMENTS"] = "Bölümleri Sıfırla"
L["STRING_KEYBIND_SCROLL_DOWN"] = "Tüm Pencereleri Aşağı Kaydır"
L["STRING_KEYBIND_SCROLL_UP"] = "Tüm Pencereleri Yukarı Kaydır"
L["STRING_KEYBIND_SCROLLING"] = "Kaydırma"
L["STRING_KEYBIND_SEGMENTCONTROL"] = "Bölümler"
L["STRING_KEYBIND_TOGGLE_WINDOW"] = "Pencere #%s Aç/Kapat"
L["STRING_KEYBIND_TOGGLE_WINDOWS"] = "Hepsini Aç/Kapat"
L["STRING_KEYBIND_WINDOW_CONTROL"] = "Pencereler"
L["STRING_KEYBIND_WINDOW_REPORT"] = "#%s numaralı pencerede gösterilen veriyi raporla."
L["STRING_KEYBIND_WINDOW_REPORT_HEADER"] = "Veriyi Raporla"
L["STRING_KEYSTONE_ADD_TO_FRIENDS_TOOLTIP"] = "Karakter olarak arkadaş listesine ekle (battle.net arkadaşlık isteği değil)."
L["STRING_KEYSTONE_CLICK_TO_VIEW_SCOREBOARD"] = "Skor tablosunu görmek için tıkla."
L["STRING_KEYSTONE_DND_TOOLTIP"] = "Anahtarın loncana ya da arkadaşlarına gönderilmez. Gruptayken yine gönderilir."
L["STRING_KEYSTONE_LIFETIME_LIKES_YOU_GAVE"] = [=[|cFFFFFF00Details! Damage Meter Mythic+|r eklentisindeki 'GG' düğmesiyle bu oyuncuya bugüne kadar verdiğin beğeniler.

Bu oyuncuyla yaptığın bir Mythic+ koşusunu seçerek koşu dökümünü görebilirsin.]=]
L["STRING_KEYSTONE_NO_MYTHICPLUS_ADDON"] = "Mythic+ eklentisi bulunamadı."
L["STRING_KEYSTONE_REQUEST_FROM_GUILD"] = "Loncadan İste"
L["STRING_KILLED"] = "Öldürüldü"
L["STRING_LAST_COOLDOWN"] = "son kullanılan bekleme süresi"
L["STRING_LEFT"] = "sol"
L["STRING_LEFT_CLICK_SHARE"] = "Raporlamak için sol tıkla."
L["STRING_LEFT_TO_RIGHT"] = "Soldan Sağa"
L["STRING_LIKES_YOU_GAVE"] = "Verdiğin beğeniler"
L["STRING_LOCK_DESC"] = "Pencereyi kilitle ya da kilidini aç"
L["STRING_LOCK_WINDOW"] = "kilitle"
L["STRING_MASTERY"] = "Mastery"
L["STRING_MAXIMUM"] = "En Çok"
L["STRING_MAXIMUM_SHORT"] = "Azami"
L["STRING_MEDIA"] = "Medya"
L["STRING_MELEE"] = "Yakın Dövüş"
L["STRING_MEMORY_ALERT_BUTTON"] = "Anladım"
L["STRING_MEMORY_ALERT_TEXT1"] = "Details! çok bellek kullanır, ama |cFFFF8800yaygın inanışın aksine|r eklentilerin bellek kullanımı oyun performansını ya da FPS'ini |cFFFF8800etkilemez|r."
L["STRING_MEMORY_ALERT_TEXT2"] = "Yani Details!'in çok bellek kullandığını görürsen panik yapma :D |cFFFF8800Her şey yolunda!|r Bu belleğin bir kısmı eklentiyi hızlandırmak için |cFFFF8800önbellekte|r bile kullanılıyor."
L["STRING_MEMORY_ALERT_TEXT3"] = "Ancak |cFFFF8800hangi eklentilerin 'ağır'|r olduğunu ya da FPS'ini düşürdüğünü öğrenmek istiyorsan '|cFFFFFF00AddOns Cpu Usage|r' eklentisini kur."
L["STRING_MEMORY_ALERT_TITLE"] = "Lütfen Dikkatle Oku!"
L["STRING_MENU_CLOSE_INSTANCE"] = "Bu Pencereyi Kapat"
L["STRING_MENU_CLOSE_INSTANCE_DESC"] = "Kapalı bir pencere etkin değil sayılır ve pencere kontrol menüsüyle her zaman yeniden açılabilir."
L["STRING_MENU_CLOSE_INSTANCE_DESC2"] = "Kalıcı olarak kaldırmak için Ayarlar Paneli > Pencere Gövdesi > Sil'e git."
L["STRING_MENU_INSTANCE_CONTROL"] = "Pencere Kontrolü"
L["STRING_MINIMAP_TOOLTIP1"] = "|cFFCFCFCFsol tık|r: ayarlar panelini aç"
L["STRING_MINIMAP_TOOLTIP11"] = "|cFFCFCFCFsol tık|r: tüm bölümleri temizle"
L["STRING_MINIMAP_TOOLTIP12"] = "|cFFCFCFCFsol tık|r: pencereleri göster/gizle"
L["STRING_MINIMAP_TOOLTIP2"] = "|cFFCFCFCFsağ tık|r: hızlı menü"
L["STRING_MINIMAPMENU_CLOSEALL"] = "Hepsini Kapat"
L["STRING_MINIMAPMENU_HIDEICON"] = "Minimap Simgesini Gizle"
L["STRING_MINIMAPMENU_LOCK"] = "Kilitle"
L["STRING_MINIMAPMENU_NEWWINDOW"] = "Yeni Pencere Oluştur"
L["STRING_MINIMAPMENU_REOPENALL"] = "Hepsini Yeniden Aç"
L["STRING_MINIMAPMENU_UNLOCK"] = "Kilidi Aç"
L["STRING_MINIMUM"] = "En Az"
L["STRING_MINIMUM_SHORT"] = "Asgari"
L["STRING_MINITUTORIAL_BOOKMARK1"] = "Yer imlerini açmak için pencerenin herhangi bir yerine sağ tıkla!"
L["STRING_MINITUTORIAL_BOOKMARK2"] = "Yer imleri sık kullandığın görünümlere hızlı erişim sağlar."
L["STRING_MINITUTORIAL_BOOKMARK3"] = "Yer imi panelini kapatmak için sağ tıkla."
L["STRING_MINITUTORIAL_BOOKMARK4"] = "Bunu bir daha gösterme."
L["STRING_MINITUTORIAL_CLOSECTRL1"] = "|cFFFFFF00Ctrl + Sağ Tık|r pencereyi kapatır!"
L["STRING_MINITUTORIAL_CLOSECTRL2"] = "Yeniden açmak istersen Mod Menüsü -> Pencere Kontrolü ya da Ayarlar Paneline git."
L["STRING_MINITUTORIAL_OPTIONS_PANEL1"] = "Düzenlenmekte olan pencere."
L["STRING_MINITUTORIAL_OPTIONS_PANEL2"] = "İşaretliyse gruptaki tüm pencereler de değişir."
L["STRING_MINITUTORIAL_OPTIONS_PANEL3"] = [=[Bir grup oluşturmak için 2. pencereyi 1. pencerenin yanına sürükle.

Grubu |cFFFFFF00gruptan ayır|r düğmesine tıklayarak bozabilirsin.]=]
L["STRING_MINITUTORIAL_OPTIONS_PANEL4"] = "Deneme çubukları oluşturarak ayarlarını dene."
L["STRING_MINITUTORIAL_OPTIONS_PANEL5"] = "Grubu Düzenleme açıkken gruptaki tüm pencereler değişir."
L["STRING_MINITUTORIAL_OPTIONS_PANEL6"] = "Pencere görünümünü seçmek ve değiştirmek için buradan seç."
L["STRING_MINITUTORIAL_WINDOWS1"] = [=[Bir pencere grubu oluşturdun.

Bozmak için asma kilit simgesine tıkla.]=]
L["STRING_MINITUTORIAL_WINDOWS2"] = [=[Pencere kilitlendi.

Uzatmak için başlık çubuğuna tıkla ve yukarı sürükle.]=]
L["STRING_MIRROR_IMAGE"] = "Ayna Görüntüsü"
L["STRING_MISS"] = "Iska"
L["STRING_MODE_ALL"] = "Her Şey"
L["STRING_MODE_GROUP"] = "Standart"
L["STRING_MODE_OPENFORGE"] = "Büyü Listesi"
L["STRING_MODE_PLUGINS"] = "eklentiler"
L["STRING_MODE_RAID"] = "Eklentiler: Raid"
L["STRING_MODE_SELF"] = "Eklentiler: Tek Başına"
L["STRING_MORE_INFO"] = "Daha fazla bilgi için sağdaki kutuya bak."
L["STRING_MULTISTRIKE"] = "Multistrike"
L["STRING_MULTISTRIKE_HITS"] = "Multistrike Vuruşları"
L["STRING_MUSIC_DETAILS_ROBERTOCARLOS"] = [=[Unutmaya çalışmanın faydası yok
Hayatında uzun süre yaşayacağım
Bizim kadar küçük ayrıntılar]=]
L["STRING_NEWROW"] = "yenileme bekleniyor..."
L["STRING_NEWS_REINSTALL"] = "Bir güncellemeden sonra sorun mu var? '/details reinstall' komutunu dene."
L["STRING_NEWS_TITLE"] = "Bu Sürümdeki Yenilikler"
L["STRING_NO"] = "Hayır"
L["STRING_NO_DATA"] = "veri zaten temizlenmiş"
L["STRING_NO_MYTHIC_PLUS_ADDON"] = "Loot, puan, verilen hasar, yapılan iyileştirme ve kimlerle oynadığın dahil Mythic+ koşularını takip etmek için |cFFfff1c1Wago AddOns|r ya da |cFFfff1c1Curse Forge|r üzerinden |cFFFFAA00Details! Damage Meter Mythic+|r eklentisini kur."
L["STRING_NO_SPELL"] = "hiç büyü kullanılmadı"
L["STRING_NO_TARGET"] = "Hedef bulunamadı."
L["STRING_NO_TARGET_BOX"] = "Uygun Hedef Yok"
L["STRING_NO_TELEPORTER"] = "Bu ışınlayıcıya sahip değilsin"
L["STRING_NOCLOSED_INSTANCES"] = [=[Kapalı pencere yok,
yeni bir tane açmak için tıkla.]=]
L["STRING_NOLAST_COOLDOWN"] = "bekleme süresi kullanılmadı"
L["STRING_NOMORE_INSTANCES"] = [=[En fazla pencere sayısına ulaşıldı.
Sınırı ayarlar panelinden değiştir.]=]
L["STRING_NORMAL_HITS"] = "Normal Vuruşlar"
L["STRING_NUMERALSYSTEM"] = "Sayı Sistemi"
L["STRING_NUMERALSYSTEM_ARABIC_MYRIAD_EASTASIA"] = "Doğu Asya ülkelerinde kullanılır, binler ve onbinler olarak ayırır."
L["STRING_NUMERALSYSTEM_ARABIC_WESTERN"] = "Batı"
L["STRING_NUMERALSYSTEM_ARABIC_WESTERN_DESC"] = "en yaygın yöntem, binler ve milyonlar olarak ayırır."
L["STRING_NUMERALSYSTEM_DESC"] = "Kullanılacak sayı sistemini seç"
L["STRING_NUMERALSYSTEM_MYRIAD_EASTASIA"] = "Doğu Asya"
L["STRING_OFFHAND_HITS"] = "Yedek El"
L["STRING_OPTIONS_3D_LALPHA_DESC"] = [=[Alt modeldeki saydamlık miktarını ayarla.

|cFFFFFF00Önemli|r: bazı modeller saydamlık miktarını yok sayar.]=]
L["STRING_OPTIONS_3D_LANCHOR"] = "Alt 3D Model:"
L["STRING_OPTIONS_3D_LENABLED_DESC"] = "Çubukların arkasında 3D model çerçevesi kullanımını açar ya da kapatır."
L["STRING_OPTIONS_3D_LSELECT_DESC"] = "Alt model çubuğunda hangi modelin kullanılacağını seç."
L["STRING_OPTIONS_3D_SELECT"] = "Model Seç"
L["STRING_OPTIONS_3D_UALPHA_DESC"] = [=[Üst modeldeki saydamlık miktarını ayarla.

|cFFFFFF00Önemli|r: bazı modeller saydamlık miktarını yok sayar.]=]
L["STRING_OPTIONS_3D_UANCHOR"] = "Üst 3D Model:"
L["STRING_OPTIONS_3D_UENABLED_DESC"] = "Çubukların üzerinde 3D model çerçevesi kullanımını açar ya da kapatır."
L["STRING_OPTIONS_3D_USELECT_DESC"] = "Üst model çubuğunda hangi modelin kullanılacağını seç."
L["STRING_OPTIONS_ADVANCED"] = "Gelişmiş"
L["STRING_OPTIONS_ALIGNED_TEXT_COLUMNS"] = "Hizalı Yazı Sütunları"
L["STRING_OPTIONS_ALIGNED_TEXT_COLUMNS_AUTOALIGN"] = "Otomatik Hizalama"
L["STRING_OPTIONS_ALIGNED_TEXT_COLUMNS_AUTOALIGN_DESC"] = "Hizalama, her yazının uzunluğuna göre otomatik yapılır"
L["STRING_OPTIONS_ALIGNED_TEXT_COLUMNS_DESC"] = "Parantezleri ve ayırıcıları kapat, çubuk yazılarını dikey sütunlarda hizala"
L["STRING_OPTIONS_ALIGNED_TEXT_COLUMNS_OFFSET"] = "Yazı %d Kaydırması"
L["STRING_OPTIONS_ALIGNED_TEXT_COLUMNS_OFFSET_DESC"] = "Sağ kenardan uzaklık"
L["STRING_OPTIONS_ALIGNED_TEXT_COLUMNS_WARNING"] = "açıksa ayırıcılar ve parantezler kullanılmaz"
L["STRING_OPTIONS_ALPHAMOD_ANCHOR"] = "Otomatik Gizle:"
L["STRING_OPTIONS_ALWAYS_USE"] = "Tüm Karakterlerde Kullan"
L["STRING_OPTIONS_ALWAYS_USE_DESC"] = "Tüm karakterlerde aynı profil kullanılır. Herhangi bir karakterde başka bir mevcut profili seçerek bunu geçersiz kılabilirsin."
L["STRING_OPTIONS_ALWAYSSHOWPLAYERS"] = "Grupsuz Oyuncuları Göster"
L["STRING_OPTIONS_ALWAYSSHOWPLAYERS_DESC"] = "Varsayılan Standart modu kullanırken, seninle grupta olmasalar bile oyuncu karakterlerini göster."
L["STRING_OPTIONS_ANCHOR"] = "Yan"
L["STRING_OPTIONS_ANIMATEBARS"] = "Çubukları Canlandır"
L["STRING_OPTIONS_ANIMATEBARS_DESC"] = "Tüm çubuklar için animasyonları aç."
L["STRING_OPTIONS_ANIMATESCROLL"] = "Kaydırma Çubuğunu Canlandır"
L["STRING_OPTIONS_ANIMATESCROLL_DESC"] = "Açıksa kaydırma çubuğu görünürken ya da gizlenirken animasyon kullanır."
L["STRING_OPTIONS_APPEARANCE"] = "Görünüm"
L["STRING_OPTIONS_ATTRIBUTE_TEXT"] = "Başlık Yazısı Ayarları"
L["STRING_OPTIONS_ATTRIBUTE_TEXT_DESC"] = "Bu seçenekler pencerenin başlık yazısını denetler."
L["STRING_OPTIONS_AUTO_COMBATLOG"] = "Combatlog'u Otomatik Başlat"
L["STRING_OPTIONS_AUTO_COMBATLOG_DESC"] = "Bir raide ya da zindana girince veya çıkınca combatlog.txt dosyasına savaş kaydını otomatik başlat ve durdur."
L["STRING_OPTIONS_AUTO_SWITCH"] = "Tüm Roller |cFFFFAA00(savaşta)|r"
L["STRING_OPTIONS_AUTO_SWITCH_COMBAT"] = "|cFFFFAA00(savaşta)|r"
L["STRING_OPTIONS_AUTO_SWITCH_DAMAGER_DESC"] = "Hasar uzmanlığındayken bu pencere seçili özelliği ya da eklentiyi gösterir."
L["STRING_OPTIONS_AUTO_SWITCH_DESC"] = [=[Savaşa girdiğinde bu pencere seçili özelliği ya da eklentiyi gösterir.

|cFFFFFF00Önemli|r: Her rol için seçilen ayrı özellik, burada seçilen özelliğin yerine geçer.]=]
L["STRING_OPTIONS_AUTO_SWITCH_HEALER_DESC"] = "İyileştirici uzmanlığındayken bu pencere seçili özelliği ya da eklentiyi gösterir."
L["STRING_OPTIONS_AUTO_SWITCH_TANK_DESC"] = "Tank uzmanlığındayken bu pencere seçili özelliği ya da eklentiyi gösterir."
L["STRING_OPTIONS_AUTO_SWITCH_WIPE"] = "Wipe Sonrası"
L["STRING_OPTIONS_AUTO_SWITCH_WIPE_DESC"] = "Bir raid karşılaşmasında başarısız deneme ya da yenilgiden sonra bu pencere otomatik olarak bu özelliği gösterir."
L["STRING_OPTIONS_AVATAR"] = "Avatar Seç"
L["STRING_OPTIONS_AVATAR_ANCHOR"] = "Kimlik:"
L["STRING_OPTIONS_AVATAR_DESC"] = "Avatarlar lonca üyelerine de gönderilir ve ipuçlarının üstünde ve oyuncu ayrıntıları penceresinde gösterilir."
L["STRING_OPTIONS_BAR_BACKDROP_ANCHOR"] = "Kenarlık:"
L["STRING_OPTIONS_BAR_BACKDROP_COLOR_DESC"] = "Kenarlık rengini değiştirir."
L["STRING_OPTIONS_BAR_BACKDROP_ENABLED_DESC"] = "Satır kenarlıklarını aç ya da kapat."
L["STRING_OPTIONS_BAR_BACKDROP_SIZE_DESC"] = "Kenarlık boyutunu ayarla."
L["STRING_OPTIONS_BAR_BACKDROP_TEXTURE_DESC"] = "Kenarlığın görünümünü değiştirir."
L["STRING_OPTIONS_BAR_BCOLOR"] = "Arka Plan Rengi"
L["STRING_OPTIONS_BAR_BTEXTURE_DESC"] = "Bu doku üst dokunun altında durur ve boyutu her zaman pencere genişliğiyle aynıdır."
L["STRING_OPTIONS_BAR_COLOR_DESC"] = [=[Bu dokunun rengi ve saydamlığı.

|cFFFFFF00Önemli|r: Sınıf renkleri kullanılırken seçilen renk yok sayılır.]=]
L["STRING_OPTIONS_BAR_COLORBYCLASS"] = "Oyuncu Sınıfına Göre Renk"
L["STRING_OPTIONS_BAR_COLORBYCLASS_DESC"] = "Açıksa bu doku her zaman oyuncunun sınıf rengini kullanır."
L["STRING_OPTIONS_BAR_FOLLOWING"] = "Beni Hep Göster"
L["STRING_OPTIONS_BAR_FOLLOWING_ANCHOR"] = "Oyuncu Çubuğu:"
L["STRING_OPTIONS_BAR_FOLLOWING_DESC"] = "Açıksa en üst sıradaki oyunculardan biri olmasan bile çubuğun her zaman gösterilir."
L["STRING_OPTIONS_BAR_GROW"] = "Çubuk Büyüme Yönü"
L["STRING_OPTIONS_BAR_GROW_DESC"] = "Çubuklar pencerenin üstünden ya da altından büyür."
L["STRING_OPTIONS_BAR_HEIGHT"] = "Çubuk Yüksekliği"
L["STRING_OPTIONS_BAR_HEIGHT_DESC"] = "Çubuk yüksekliğini artır ya da azalt."
L["STRING_OPTIONS_BAR_ICONFILE"] = "Simge Dosyası"
L["STRING_OPTIONS_BAR_ICONFILE_DESC"] = [=[Özel simge dosyasının yolu.

Görsel, alfa kanallı 256x256 piksel bir .tga dosyası olmalı.]=]
L["STRING_OPTIONS_BAR_ICONFILE_DESC2"] = "Kullanılacak simge paketini seç."
L["STRING_OPTIONS_BAR_ICONFILE1"] = "Simge Yok"
L["STRING_OPTIONS_BAR_ICONFILE2"] = "Varsayılan"
L["STRING_OPTIONS_BAR_ICONFILE3"] = "Varsayılan (siyah beyaz)"
L["STRING_OPTIONS_BAR_ICONFILE4"] = "Varsayılan (saydam)"
L["STRING_OPTIONS_BAR_ICONFILE5"] = "Yuvarlak Simgeler"
L["STRING_OPTIONS_BAR_ICONFILE6"] = "Varsayılan (saydam siyah beyaz)"
L["STRING_OPTIONS_BAR_SPACING"] = "Boşluk"
L["STRING_OPTIONS_BAR_SPACING_DESC"] = "Çubuklar arasındaki boşluk."
L["STRING_OPTIONS_BAR_TEXTURE_DESC"] = "Çubuğun üstünde kullanılan doku."
L["STRING_OPTIONS_BARLEFTTEXTCUSTOM"] = "Özel Yazı Açık"
L["STRING_OPTIONS_BARLEFTTEXTCUSTOM_DESC"] = "Özel bir yazı kullan; yazıyı aşağıdaki düğmeye tıklayarak düzenle."
L["STRING_OPTIONS_BARLEFTTEXTCUSTOM2"] = ""
L["STRING_OPTIONS_BARLEFTTEXTCUSTOM2_DESC"] = [=[|cFFFFFF00{data1}|r: genellikle oyuncunun sıra numarasını gösterir.

|cFFFFFF00{data2}|r: her zaman oyuncunun adıdır.

|cFFFFFF00{data3}|r: bazı durumlarda oyuncunun fraksiyon ya da rol simgesini gösterir.

|cFFFFFF00{func}|r: özel bir Lua işlevi çalıştırır ve dönüş değerini yazıya ekler.
Örnek: 
{func return 'hello azeroth'}

|cFFFFFF00Kaçış Dizileri|r: renk değiştirmek ya da doku eklemek için kullan. Daha fazla bilgi için 'UI escape sequences' ara.]=]
L["STRING_OPTIONS_BARORIENTATION"] = "Çubuk Yönü"
L["STRING_OPTIONS_BARORIENTATION_DESC"] = "Çubukların dolma yönü."
L["STRING_OPTIONS_BARRIGHTTEXTCUSTOM"] = "Özel Yazı Açık"
L["STRING_OPTIONS_BARRIGHTTEXTCUSTOM_DESC"] = "Açıksa sağ yazı kutudaki kurallara göre biçimlenir."
L["STRING_OPTIONS_BARRIGHTTEXTCUSTOM2"] = ""
L["STRING_OPTIONS_BARRIGHTTEXTCUSTOM2_DESC"] = [=[|cFFFFFF00{data1}|r: verilen ilk sayıdır, genellikle yapılan toplamı gösterir.

|cFFFFFF00{data2}|r: verilen ikinci sayıdır, çoğu zaman saniyedeki ortalamayı gösterir.

|cFFFFFF00{data3}|r: verilen üçüncü sayıdır, normalde yüzdedir. 

|cFFFFFF00{func}|r: özel bir Lua işlevi çalıştırır ve dönüş değerini yazıya ekler.
Örnek: 
{func return 'hello azeroth'}

|cFFFFFF00Kaçış Dizileri|r: renk değiştirmek ya da doku eklemek için kullan. Daha fazla bilgi için 'UI escape sequences' ara.]=]
L["STRING_OPTIONS_BARS"] = "Genel Çubuk Ayarları"
L["STRING_OPTIONS_BARS_CUSTOM_TEXTURE"] = "Özel Doku Dosyası"
L["STRING_OPTIONS_BARS_DESC"] = "Bu seçenekler çubukların görünümünü denetler."
L["STRING_OPTIONS_BARSORT"] = "Çubuk Sıra Düzeni"
L["STRING_OPTIONS_BARSORT_DESC"] = "Çubukları azalan ya da artan sırada diz."
L["STRING_OPTIONS_BARSTART"] = "Çubuk Simgeden Sonra Başlasın"
L["STRING_OPTIONS_BARSTART_DESC"] = [=[Kapalıyken üst doku simgenin sağı yerine solundan başlar

Saydam alanları olan bir simge paketi kullanırken işe yarar.]=]
L["STRING_OPTIONS_BARUR_ANCHOR"] = "Hızlı Güncelleme"
L["STRING_OPTIONS_BARUR_DESC"] = "Açıksa DPS ve HPS değerleri her zamankinden biraz daha hızlı güncellenir."
L["STRING_OPTIONS_BG_ALL_ALLY"] = "Battleground'da Düşmanları Göster"
L["STRING_OPTIONS_BG_ALL_ALLY_DESC"] = [=[Açıksa pencere Grup Modundayken düşman oyuncular da gösterilir.

|cFFFFFF00Önemli|r: değişiklikler bir sonraki savaşa girişten sonra uygulanır.]=]
L["STRING_OPTIONS_BG_ANCHOR"] = "Battleground'lar:"
L["STRING_OPTIONS_BG_UNIQUE_SEGMENT"] = "Tek Bölümlü Battleground"
L["STRING_OPTIONS_BG_UNIQUE_SEGMENT_DESC"] = "Battleground'un başında bir bölüm oluşturulur ve bitene kadar sürer."
L["STRING_OPTIONS_CAURAS"] = "Auraları Topla"
L["STRING_OPTIONS_CAURAS_DESC"] = [=[Şunların toplanmasını aç:

- |cFFFFFF00Buff Süreleri|r
- |cFFFFFF00Debuff Süreleri|r
- |cFFFFFF00Yer Etkileri|r
-|cFFFFFF00 Bekleme Süreleri|r]=]
L["STRING_OPTIONS_CDAMAGE"] = "Hasarı Topla"
L["STRING_OPTIONS_CDAMAGE_DESC"] = [=[Şunların toplanmasını aç:

- |cFFFFFF00Verilen Hasar|r
- |cFFFFFF00Saniyedeki Hasar|r
- |cFFFFFF00Dost Ateşi|r
- |cFFFFFF00Alınan Hasar|r]=]
L["STRING_OPTIONS_CENERGY"] = "Enerjiyi Topla"
L["STRING_OPTIONS_CENERGY_DESC"] = [=[Şunların toplanmasını aç:

- |cFFFFFF00Geri Kazanılan Mana|r
- |cFFFFFF00Üretilen Öfke|r
- |cFFFFFF00Üretilen Enerji|r
- |cFFFFFF00Üretilen Runic Power|r]=]
L["STRING_OPTIONS_CHANGE_CLASSCOLORS"] = "Sınıf Renklerini Değiştir"
L["STRING_OPTIONS_CHANGE_CLASSCOLORS_DESC"] = "Sınıflar için yeni renkler seç."
L["STRING_OPTIONS_CHANGECOLOR"] = "Rengi Değiştir"
L["STRING_OPTIONS_CHANGELOG"] = "Sürüm Notları"
L["STRING_OPTIONS_CHART_ADD"] = "Veri Ekle"
L["STRING_OPTIONS_CHART_ADD2"] = "Ekle"
L["STRING_OPTIONS_CHART_ADDAUTHOR"] = "Yazar: "
L["STRING_OPTIONS_CHART_ADDCODE"] = "Kod: "
L["STRING_OPTIONS_CHART_ADDICON"] = "Simge: "
L["STRING_OPTIONS_CHART_ADDNAME"] = "Ad: "
L["STRING_OPTIONS_CHART_ADDVERSION"] = "Sürüm: "
L["STRING_OPTIONS_CHART_AUTHOR"] = "Yazar"
L["STRING_OPTIONS_CHART_AUTHORERROR"] = "Yazar adı geçersiz."
L["STRING_OPTIONS_CHART_CANCEL"] = "İptal"
L["STRING_OPTIONS_CHART_CLOSE"] = "Kapat"
L["STRING_OPTIONS_CHART_CODELOADED"] = "Kod zaten yüklü ve gösterilemiyor."
L["STRING_OPTIONS_CHART_EDIT"] = "Kodu Düzenle"
L["STRING_OPTIONS_CHART_EXPORT"] = "Dışa Aktar"
L["STRING_OPTIONS_CHART_FUNCERROR"] = "İşlev geçersiz."
L["STRING_OPTIONS_CHART_ICON"] = "Simge"
L["STRING_OPTIONS_CHART_IMPORT"] = "İçe Aktar"
L["STRING_OPTIONS_CHART_IMPORTERROR"] = "İçe aktarma metni geçersiz."
L["STRING_OPTIONS_CHART_NAME"] = "Ad"
L["STRING_OPTIONS_CHART_NAMEERROR"] = "Ad geçersiz."
L["STRING_OPTIONS_CHART_PLUGINWARNING"] = "Özel grafikleri göstermek için Chart Viewer eklentisini kur."
L["STRING_OPTIONS_CHART_REMOVE"] = "Kaldır"
L["STRING_OPTIONS_CHART_SAVE"] = "Kaydet"
L["STRING_OPTIONS_CHART_VERSION"] = "Sürüm"
L["STRING_OPTIONS_CHART_VERSIONERROR"] = "Sürüm geçersiz."
L["STRING_OPTIONS_CHEAL"] = "İyileştirmeyi Topla"
L["STRING_OPTIONS_CHEAL_DESC"] = [=[Şunların toplanmasını aç:

- |cFFFFFF00Yapılan İyileştirme|r
- |cFFFFFF00Emilenler|r
- |cFFFFFF00Saniyedeki İyileştirme|r
- |cFFFFFF00Fazla İyileştirme|r
- |cFFFFFF00Alınan İyileştirme|r
- |cFFFFFF00İyileştirilen Düşman|r
- |cFFFFFF00Önlenen Hasar|r]=]
L["STRING_OPTIONS_CLASSCOLOR_MODIFY"] = "Sınıf Renklerini Değiştir"
L["STRING_OPTIONS_CLASSCOLOR_RESET"] = "Sıfırlamak İçin Sağ Tıkla"
L["STRING_OPTIONS_CLEANUP"] = "Trash Bölümlerini Otomatik Sil"
L["STRING_OPTIONS_CLEANUP_DESC"] = "Açıksa trash temizliği bölümleri, iki bölüm daha geçtikten sonra otomatik silinir."
L["STRING_OPTIONS_CLICK_TO_OPEN_MENUS"] = "Menüleri Açmak İçin Tıkla"
L["STRING_OPTIONS_CLICK_TO_OPEN_MENUS_DESC"] = [=[Başlık çubuğu düğmeleri, üzerlerine gelince menülerini göstermez.

Açmak için tıklaman gerekir.]=]
L["STRING_OPTIONS_CLOUD"] = "Bulut Yakalama"
L["STRING_OPTIONS_CLOUD_DESC"] = "Açıksa kapalı toplayıcıların verileri diğer raid üyelerinden toplanır."
L["STRING_OPTIONS_CMISC"] = "Diğerlerini Topla"
L["STRING_OPTIONS_CMISC_DESC"] = [=[Şunların toplanmasını aç:

- |cFFFFFF00Kitle Kontrolü Bozma|r
- |cFFFFFF00Dispel'ler|r
- |cFFFFFF00Kesmeler|r
- |cFFFFFF00Diriltme|r
- |cFFFFFF00Ölümler|r]=]
L["STRING_OPTIONS_COLORANDALPHA"] = "Renk ve Saydamlık"
L["STRING_OPTIONS_COLORFIXED"] = "Sabit Renk"
L["STRING_OPTIONS_COMBAT_ALPHA"] = "Ne Zaman"
L["STRING_OPTIONS_COMBAT_ALPHA_2"] = "Savaştayken"
L["STRING_OPTIONS_COMBAT_ALPHA_3"] = "Savaş Dışındayken"
L["STRING_OPTIONS_COMBAT_ALPHA_4"] = "Grupta Değilken"
L["STRING_OPTIONS_COMBAT_ALPHA_5"] = "Zindan Dışındayken"
L["STRING_OPTIONS_COMBAT_ALPHA_6"] = "Zindan İçindeyken"
L["STRING_OPTIONS_COMBAT_ALPHA_7"] = "Raid Hata Ayıklama"
L["STRING_OPTIONS_COMBAT_ALPHA_8"] = "Battleground'da"
L["STRING_OPTIONS_COMBAT_ALPHA_9"] = "Mythic+'ta"
L["STRING_OPTIONS_COMBAT_ALPHA_DESC"] = [=[Savaşın pencere saydamlığını nasıl etkileyeceğini seç.

|cFFFFFF00Değişiklik Yok|r: Saydamlığı değiştirmez.

|cFFFFFF00Savaştayken|r: Karakterin savaşa girdiğinde seçilen saydamlık pencereye uygulanır.

|cFFFFFF00Savaş Dışındayken|r: Karakterin savaşta olmadığı her an saydamlık uygulanır.

|cFFFFFF00Grupta Değilken|r: Bir grupta ya da raid grubunda değilken pencere seçilen saydamlığı alır.

|cFFFFFF00Önemli|r: Bu seçenek, Otomatik Saydamlık özelliğinin belirlediği saydamlığın yerine geçer.]=]
L["STRING_OPTIONS_COMBATTWEEKS"] = "Savaş Ayarları"
L["STRING_OPTIONS_COMBATTWEEKS_DESC"] = "Details!'in bazı savaş durumlarını nasıl ele alacağına dair davranış ayarları."
L["STRING_OPTIONS_CONFIRM_ERASE"] = "Veriyi silmek istiyor musun?"
L["STRING_OPTIONS_CUSTOMSPELL_ADD"] = "Büyü Ekle"
L["STRING_OPTIONS_CUSTOMSPELLTITLE"] = "Büyü Ayarlarını Düzenle"
L["STRING_OPTIONS_CUSTOMSPELLTITLE_DESC"] = "Bu panel büyülerin adını ve simgesini değiştirmeni sağlar."
L["STRING_OPTIONS_DATABROKER"] = "Data Broker:"
L["STRING_OPTIONS_DATABROKER_TEXT"] = "Yazı"
L["STRING_OPTIONS_DATABROKER_TEXT_ADD1"] = "Oyuncunun Verdiği Hasar"
L["STRING_OPTIONS_DATABROKER_TEXT_ADD2"] = "Oyuncu Etkin DPS"
L["STRING_OPTIONS_DATABROKER_TEXT_ADD3"] = "Hasar Konumu"
L["STRING_OPTIONS_DATABROKER_TEXT_ADD4"] = "Hasar Farkı"
L["STRING_OPTIONS_DATABROKER_TEXT_ADD5"] = "Oyuncunun Yaptığı İyileştirme"
L["STRING_OPTIONS_DATABROKER_TEXT_ADD6"] = "Oyuncu Etkin HPS"
L["STRING_OPTIONS_DATABROKER_TEXT_ADD7"] = "İyileştirme Konumu"
L["STRING_OPTIONS_DATABROKER_TEXT_ADD8"] = "İyileştirme Farkı"
L["STRING_OPTIONS_DATABROKER_TEXT_ADD9"] = "Geçen Savaş Süresi"
L["STRING_OPTIONS_DATABROKER_TEXT1_DESC"] = [=[|cFFFFFF00{dmg}|r: oyuncunun verdiği hasar.

|cFFFFFF00{dps}|r: oyuncunun etkin saniyedeki hasarı.

|cFFFFFF00{rdps}|r: raidin etkin saniyedeki hasarı.

|cFFFFFF00{dpos}|r: raid ya da grup üyeleri arasındaki hasar sıralaması.

|cFFFFFF00{ddiff}|r: seninle birinci sıradaki arasındaki hasar farkı.

|cFFFFFF00{heal}|r: oyuncunun yaptığı iyileştirme.

|cFFFFFF00{hps}|r: oyuncunun etkin saniyedeki iyileştirmesi.

|cFFFFFF00{rhps}|r: raidin etkin saniyedeki iyileştirmesi.

|cFFFFFF00{hpos}|r: raid ya da grup üyeleri arasındaki iyileştirme sıralaması.

|cFFFFFF00{hdiff}|r: seninle birinci sıradaki arasındaki iyileştirme farkı.

|cFFFFFF00{time}|r: dövüşte geçen süre.]=]
L["STRING_OPTIONS_DATACHARTTITLE"] = "Grafikler İçin Zamanlı Veri Oluştur"
L["STRING_OPTIONS_DATACHARTTITLE_DESC"] = "Bu panel, grafik oluşturmak için özel veri yakalama tanımlamanı sağlar."
L["STRING_OPTIONS_DATACOLLECT_ANCHOR"] = "Veri Türleri:"
L["STRING_OPTIONS_DEATHLIMIT"] = "Ölüm Olayı Sayısı"
L["STRING_OPTIONS_DEATHLIMIT_DESC"] = [=[Ölüm ekranında gösterilecek olay sayısını ayarla.

|cFFFFFF00Önemli|r: yalnızca değişiklikten sonraki yeni ölümlere uygulanır.]=]
L["STRING_OPTIONS_DEATHLOG_MINHEALING"] = "Ölüm Kaydı En Az İyileştirme"
L["STRING_OPTIONS_DEATHLOG_MINHEALING_DESC"] = [=[Ölüm kaydı bu eşiğin altındaki iyileştirmeleri göstermez.

|cFFFFFF00İpucu|r: değeri elle girmek için sağ tıkla.]=]
L["STRING_OPTIONS_DESATURATE_MENU"] = "Soluk"
L["STRING_OPTIONS_DESATURATE_MENU_DESC"] = "Bu seçenek açılınca araç çubuğundaki tüm menü simgeleri siyah beyaz olur."
L["STRING_OPTIONS_DESIGNER_ALIGN_COLUMNS"] = "Değer Sütunlarını Hizala"
L["STRING_OPTIONS_DESIGNER_ALIGN_COLUMNS_DESC"] = "Değer sütunlarını tek bir biçimli yazıda birleştirmek yerine sabit sütunlarda çizer. Bu bir pencere ayarı değildir, tüm pencereleri birden değiştirir."
L["STRING_OPTIONS_DESIGNER_ARENA_ROLE_ICON_SIZE_OFFSET"] = "Arena Rol Simgesi Boyut Farkı"
L["STRING_OPTIONS_DESIGNER_ARENA_TEAM_COLOR"] = "Arena Takım Rengi"
L["STRING_OPTIONS_DESIGNER_BACKGROUND_BY_CLASS"] = "Sınıfa Göre Arka Plan"
L["STRING_OPTIONS_DESIGNER_BAR_ALPHA"] = "Opaklık"
L["STRING_OPTIONS_DESIGNER_BAR_BORDER"] = "Çubuk Kenarlığını Göster"
L["STRING_OPTIONS_DESIGNER_BAR_START_AFTER_ICON"] = "Çubuk Simgeden Sonra Başlar"
L["STRING_OPTIONS_DESIGNER_BORDER_COLOR"] = "Kenarlık Rengi"
L["STRING_OPTIONS_DESIGNER_BORDER_THICKNESS"] = "Kenarlık Kalınlığı"
L["STRING_OPTIONS_DESIGNER_BUTTON_MODE"] = "Mod"
L["STRING_OPTIONS_DESIGNER_COLOR_BY_CLASS"] = "Sınıfa Göre Renk"
L["STRING_OPTIONS_DESIGNER_DESATURATED_MENU"] = "Soluk Düğmeler"
L["STRING_OPTIONS_DESIGNER_FACTION_ICON_SIZE_OFFSET"] = "Fraksiyon Simgesi Boyut Farkı"
L["STRING_OPTIONS_DESIGNER_HINT"] = "Düzenlemek için önizlemenin bir parçasına tıkla. Değişiklikler sağ üstte seçili pencereye uygulanır."
L["STRING_OPTIONS_DESIGNER_ICON_GRAYSCALE"] = "Gri Tonlu Simgeler"
L["STRING_OPTIONS_DESIGNER_ICON_SET"] = "Simge Seti"
L["STRING_OPTIONS_DESIGNER_ICON_SIZE_OFFSET"] = "Simge Boyut Farkı"
L["STRING_OPTIONS_DESIGNER_MENU_ICON_SIZE"] = "Düğme Boyutu"
L["STRING_OPTIONS_DESIGNER_MENU_ICON_SPACING"] = "Düğme Aralığı"
L["STRING_OPTIONS_DESIGNER_NAME_OFFSET"] = "Ad Kaydırması"
L["STRING_OPTIONS_DESIGNER_NAME_SIZE_OFFSET"] = "Birim Adı Boyut Farkı"
L["STRING_OPTIONS_DESIGNER_NAME_SIZE_OFFSET_DESC"] = "Birim adına, değer sütunları tarafından kesilmeden önce daha fazla ya da daha az yer ver."
L["STRING_OPTIONS_DESIGNER_NAME_TEXT"] = "Birim Adı"
L["STRING_OPTIONS_DESIGNER_NAME_TEXT_COLOR_DESC"] = [=[Birim adının yazı rengini değiştir.

|cFFFFFFFFsınıfa göre renk|r açıksa yok sayılır.]=]
L["STRING_OPTIONS_DESIGNER_NO_BRACKET"] = "parantez yok"
L["STRING_OPTIONS_DESIGNER_NO_SEPARATOR"] = "ayırıcı yok"
L["STRING_OPTIONS_DESIGNER_OBJECT_BARICONS"] = "Çubuk Simgeleri"
L["STRING_OPTIONS_DESIGNER_OBJECT_BARNAMETEXT"] = "Çubuk Birim Adı"
L["STRING_OPTIONS_DESIGNER_OBJECT_BARS"] = "Çubuklar"
L["STRING_OPTIONS_DESIGNER_OBJECT_BARTEXTS"] = "Çubuk Yazıları"
L["STRING_OPTIONS_DESIGNER_OBJECT_BARVALUETEXT"] = "Çubuk Değerleri"
L["STRING_OPTIONS_DESIGNER_OBJECT_STATUSBAR"] = "Durum Çubuğu"
L["STRING_OPTIONS_DESIGNER_OBJECT_TITLEBUTTONS"] = "Başlık Düğmeleri"
L["STRING_OPTIONS_DESIGNER_OBJECT_TITLETEXT"] = "Başlık Yazısı"
L["STRING_OPTIONS_DESIGNER_OBJECT_WINDOW"] = "Pencere"
L["STRING_OPTIONS_DESIGNER_OVERLAY"] = "Kaplama"
L["STRING_OPTIONS_DESIGNER_OVERLAY_TEXTURE_DESC"] = "Çubuğun üzerinde duran doku"
L["STRING_OPTIONS_DESIGNER_PERCENT_OF_TOP"] = "En İyi Oyuncuya Göre"
L["STRING_OPTIONS_DESIGNER_PERCENT_OF_TOTAL"] = "Toplama Göre"
L["STRING_OPTIONS_DESIGNER_PERCENT_TYPE"] = "Yüzde Türü"
L["STRING_OPTIONS_DESIGNER_PREVIEW"] = "Önizleme"
L["STRING_OPTIONS_DESIGNER_PREVIEW_MISSING"] = "Önizleme penceresi oluşturulamadı, burada düzenlenecek bir şey yok."
L["STRING_OPTIONS_DESIGNER_REMOVE_CUSTOM_TEXTURE"] = "Özel Dokuyu Kaldır"
L["STRING_OPTIONS_DESIGNER_ROUNDED_CORNERS"] = "Yuvarlak Köşeler"
L["STRING_OPTIONS_DESIGNER_ROW_AREA_ALPHA"] = "Satır Alanı Opaklığı"
L["STRING_OPTIONS_DESIGNER_SHADOW_OFFSET_X"] = "Gölge Kaydırması X"
L["STRING_OPTIONS_DESIGNER_SHADOW_OFFSET_Y"] = "Gölge Kaydırması Y"
L["STRING_OPTIONS_DESIGNER_SHOW_ARENA_ROLE_ICON"] = "Arena Rol Simgesini Göster"
L["STRING_OPTIONS_DESIGNER_SHOW_ENCOUNTER_TIMER"] = "Karşılaşma Sayacını Göster"
L["STRING_OPTIONS_DESIGNER_SHOW_FACTION_ICON"] = "Fraksiyon Simgesini Göster"
L["STRING_OPTIONS_DESIGNER_SHOW_FACTION_ICON_DESC"] = "Karşı fraksiyondan bir oyuncu gösterilirken fraksiyon simgesini göster."
L["STRING_OPTIONS_DESIGNER_SHOW_PERCENT_DESC"] = "Yüzde sütununu değer sütunlarının yanında gösterir. Değer sütunları hizalıyken geçerlidir; basit yazı biçiminde sütunlara o biçim karar verir."
L["STRING_OPTIONS_DESIGNER_SHOW_RANK_NUMBER"] = "Sıra Numarasını Göster"
L["STRING_OPTIONS_DESIGNER_SHOW_STATUSBAR"] = "Durum Çubuğunu Göster"
L["STRING_OPTIONS_DESIGNER_SHOW_WINDOW_BORDER"] = "Kenarlığı\nGöster"
L["STRING_OPTIONS_DESIGNER_TEXT_OUTLINE"] = "Anahat"
L["STRING_OPTIONS_DESIGNER_TEXT_X_OFFSET"] = "Yatay Kaydırma"
L["STRING_OPTIONS_DESIGNER_TEXT_Y_OFFSET"] = "Dikey Kaydırma"
L["STRING_OPTIONS_DESIGNER_TITLE_TEXT_ENABLED"] = "Başlık Yazısını Göster"
L["STRING_OPTIONS_DESIGNER_TITLEBAR_ENABLED"] = "Özel Başlık Çubuğu"
L["STRING_OPTIONS_DESIGNER_TITLEBAR_ENABLED_DESC"] = [=[Görünüm dosyasındaki yerleşik başlık çubuğu yerine alternatif bir başlık çubuğu kullan.

|cFFFFFF00Önemli|r: Görünüm dosyasındaki başlık çubuğunu kapatmak için 'Pencere'ye git ve 'görünüm rengi'ni tamamen saydam yap.]=]
L["STRING_OPTIONS_DESIGNER_TITLEBAR_HEIGHT"] = "Yükseklik"
L["STRING_OPTIONS_DESIGNER_VALUE_TEXT"] = "Değer Sütunları"
L["STRING_OPTIONS_DESIGNER_VALUE_TEXT_COLOR_DESC"] = [=[Değer sütunlarının yazı rengini değiştir.

|cFFFFFFFFsınıfa göre renk|r açıksa yok sayılır.]=]
L["STRING_OPTIONS_DESIGNER_WHICH_BUTTONS"] = "Gösterilen düğmeler"
L["STRING_OPTIONS_DISABLE_ALLDISPLAYSWINDOW"] = "'Tüm Görünümler' Menüsünü Kapat"
L["STRING_OPTIONS_DISABLE_ALLDISPLAYSWINDOW_DESC"] = "Açıksa başlık çubuğuna sağ tıklamak bunun yerine yer imlerini gösterir."
L["STRING_OPTIONS_DISABLE_BARHIGHLIGHT"] = "Çubuk Vurgusunu Kapat"
L["STRING_OPTIONS_DISABLE_BARHIGHLIGHT_DESC"] = "Bir çubuğun üzerine gelmek onu parlatmaz."
L["STRING_OPTIONS_DISABLE_GROUPS"] = "Gruplamayı Kapat"
L["STRING_OPTIONS_DISABLE_GROUPS_DESC"] = "Pencereler birbirine yaklaştırıldığında artık grup oluşturmaz."
L["STRING_OPTIONS_DISABLE_LOCK_RESIZE"] = "Boyutlandırma Düğmelerini Kapat"
L["STRING_OPTIONS_DISABLE_LOCK_RESIZE_DESC"] = "Bir pencerenin üzerine gelince boyutlandır, kilitle/kilidi aç ve grubu ayır düğmeleri görünmez."
L["STRING_OPTIONS_DISABLE_RESET"] = "Sıfırla Düğmesi Tıklamasını Kapat"
L["STRING_OPTIONS_DISABLE_RESET_DESC"] = "Açıksa sıfırla düğmesine tıklamak işe yaramaz; veriyi ipucu menüsünden sıfırlamayı seçmelisin."
L["STRING_OPTIONS_DISABLE_STRETCH_BUTTON"] = "Uzatma Düğmesini Kapat"
L["STRING_OPTIONS_DISABLE_STRETCH_BUTTON_DESC"] = "Bu seçenek açıkken uzatma düğmesi gösterilmez."
L["STRING_OPTIONS_DISABLED_RESET"] = "Bu düğmeyle sıfırlama şu anda kapalı; ipucu menüsünden seç."
L["STRING_OPTIONS_DTAKEN_EVERYTHING"] = "Gelişmiş Alınan Hasar"
L["STRING_OPTIONS_DTAKEN_EVERYTHING_DESC"] = "Alınan hasar '|cFFFFFF00Her Şey|r' modunda her zaman gösterilir."
L["STRING_OPTIONS_ED"] = "Veriyi Sil"
L["STRING_OPTIONS_ED_DESC"] = [=[|cFFFFFF00Elle|r: kullanıcının sıfırla düğmesine tıklaması gerekir.

|cFFFFFF00Sor|r: yeni bir zindana girince sıfırlamayı sor.

|cFFFFFF00Otomatik|r: yeni bir zindana girince veriyi temizle.]=]
L["STRING_OPTIONS_ED1"] = "Elle"
L["STRING_OPTIONS_ED2"] = "Sor"
L["STRING_OPTIONS_ED3"] = "Otomatik"
L["STRING_OPTIONS_EDIT_CUSTOM_TEXT"] = "Özel Yazıyı Düzenle"
L["STRING_OPTIONS_EDITIMAGE"] = "Görseli Düzenle"
L["STRING_OPTIONS_EDITINSTANCE"] = "Düzenlenen Pencere:"
L["STRING_OPTIONS_ERASECHARTDATA"] = "Grafikleri Sil"
L["STRING_OPTIONS_ERASECHARTDATA_DESC"] = "Çıkışta, grafik oluşturmak için toplanan tüm savaş verileri silinir."
L["STRING_OPTIONS_EXPORT_PROFILE"] = "Profili Dışa Aktar"
L["STRING_OPTIONS_EXTERNALS_TITLE"] = "Harici Bileşenler"
L["STRING_OPTIONS_EXTERNALS_TITLE2"] = "Bu seçenekler birçok harici bileşenin davranışını denetler."
L["STRING_OPTIONS_GENERAL"] = "Genel Ayarlar"
L["STRING_OPTIONS_GENERAL_ANCHOR"] = "Genel:"
L["STRING_OPTIONS_GROUPING_HORIZONTAL_GAP"] = "\"Pencereler Arası Boşluk\""
L["STRING_OPTIONS_HIDE_ICON"] = "Simgeyi Gizle"
L["STRING_OPTIONS_HIDE_ICON_DESC"] = [=[Açıksa seçili görünümü temsil eden simge gösterilmez.

|cFFFFFF00Önemli|r: simgeyi açtıktan sonra başlık yazısının yerini ayarlaman önerilir.]=]
L["STRING_OPTIONS_HIDECOMBATALPHA_DESC"] = [=[Karakterin seçilen kurala uyduğunda saydamlığı bu değere değiştirir.

|cFFFFFF00Sıfır|r: tamamen gizli, pencereyle etkileşime girilemez.

|cFFFFFF001 - 100|r: gizli değil, yalnızca saydamlık değişir, pencereyle etkileşime girebilirsin.]=]
L["STRING_OPTIONS_HOTCORNER"] = "Düğmeyi göster"
L["STRING_OPTIONS_HOTCORNER_ACTION"] = "Tıklayınca"
L["STRING_OPTIONS_HOTCORNER_ACTION_DESC"] = "Sıcak köşe çubuğundaki düğmeye farenin sol tuşuyla tıklanınca ne yapılacağını seç."
L["STRING_OPTIONS_HOTCORNER_ANCHOR"] = "Sıcak köşe:"
L["STRING_OPTIONS_HOTCORNER_DESC"] = "Sıcak köşe panelinin üzerindeki düğmeyi göster ya da gizle."
L["STRING_OPTIONS_HOTCORNER_QUICK_CLICK"] = "Hızlı Tıklamayı Aç"
L["STRING_OPTIONS_HOTCORNER_QUICK_CLICK_DESC"] = [=[Sıcak köşeler için Hızlı Tıklama özelliğini açar ya da kapatır.

Hızlı düğme en sol üstteki pikselde bulunur; fareyi oraya kadar götürmek sol üst sıcak köşeyi etkinleştirir, tıklanırsa bir işlem yapılır.]=]
L["STRING_OPTIONS_HOTCORNER_QUICK_CLICK_FUNC"] = "Tıklayınca Hızlı Tıklama"
L["STRING_OPTIONS_HOTCORNER_QUICK_CLICK_FUNC_DESC"] = "Sıcak köşedeki Hızlı Tıklama düğmesine tıklanınca ne yapılacağını seç."
L["STRING_OPTIONS_IGNORENICKNAME"] = "Takma Adları ve Avatarları Yok Say"
L["STRING_OPTIONS_IGNORENICKNAME_DESC"] = "Açıksa diğer lonca üyelerinin belirlediği takma adlar ve avatarlar yok sayılır."
L["STRING_OPTIONS_ILVL_TRACKER"] = "Eşya Seviyesi Takipçisi:"
L["STRING_OPTIONS_ILVL_TRACKER_DESC"] = [=[Açıksa ve savaş dışındaysan eklenti raiddeki oyuncuların eşya seviyesini sorgular ve takip eder.

Kapalıyken de diğer eklentilerin sorgularından ya da başka bir oyuncuyu elle incelediğinde eşya seviyesini okur.]=]
L["STRING_OPTIONS_ILVL_TRACKER_TEXT"] = "Etkin"
L["STRING_OPTIONS_IMPORT_PROFILE"] = "Profil İçe Aktar"
L["STRING_OPTIONS_IMPORT_PROFILE_NAME"] = "Yeni Profil İçin Bir Ad Gir"
L["STRING_OPTIONS_IMPORT_PROFILE_PASTE"] = "Details! Profil İçe Aktar (metni yapıştır)"
L["STRING_OPTIONS_INSTANCE_BACKDROP"] = "Arka Plan Dokusu"
L["STRING_OPTIONS_INSTANCE_BACKDROP_DESC"] = [=[Bu pencerenin kullandığı arka plan dokusunu seç.

|cFFFFFF00Varsayılan|r: Details Arka Planı.]=]
L["STRING_OPTIONS_INSTANCE_CURRENT"] = "Otomatik Olarak Şimdikine Geç"
L["STRING_OPTIONS_INSTANCE_CURRENT_DESC"] = "Bir savaş başladığında bu pencere otomatik olarak şimdiki bölüme geçer."
L["STRING_OPTIONS_INSTANCE_DELETE"] = "Sil"
L["STRING_OPTIONS_INSTANCE_DELETE_DESC"] = [=[Bir pencereyi kalıcı olarak kaldır.
Silme işlemi sırasında oyun ekranın yeniden yüklenebilir.]=]
L["STRING_OPTIONS_INSTANCE_SKIN"] = "Görünüm"
L["STRING_OPTIONS_INSTANCE_SKIN_DESC"] = "Pencere görünümünü bir görünüm temasına göre değiştir."
L["STRING_OPTIONS_INSTANCE_STATUSBAR_ANCHOR"] = "Durum Çubuğu"
L["STRING_OPTIONS_INSTANCE_STATUSBARCOLOR"] = "Renk ve Saydamlık"
L["STRING_OPTIONS_INSTANCE_STATUSBARCOLOR_DESC"] = [=[Durum çubuğunun rengini seç.

|cFFFFFF00Önemli|r: bu seçenek, Pencere Rengi'nde seçilen renk ve saydamlığın yerine geçer.]=]
L["STRING_OPTIONS_INSTANCE_STRATA"] = "Katman Seviyesi"
L["STRING_OPTIONS_INSTANCE_STRATA_DESC"] = [=[Çerçevenin yerleştirileceği katman yüksekliğini seçer.

Düşük katman varsayılandır ve pencerenin diğer arayüz panellerinin çoğunun arkasında kalmasını sağlar.

Yüksek katmanda pencere diğer büyük panellerin önünde kalabilir.

Katman yüksekliğini değiştirirken panellerin üst üste binmesiyle çakışmalar yaşayabilirsin.]=]
L["STRING_OPTIONS_INSTANCES"] = "Pencereler:"
L["STRING_OPTIONS_INTERFACEDIT"] = "Arayüz Düzenleme Modu"
L["STRING_OPTIONS_LOCKSEGMENTS"] = "Bölümler Kilitli"
L["STRING_OPTIONS_LOCKSEGMENTS_DESC"] = "Açıksa bölümü değiştirmek diğer tüm pencereleri de seçili bölüme geçirir."
L["STRING_OPTIONS_MANAGE_BOOKMARKS"] = "Yer İmlerini Yönet"
L["STRING_OPTIONS_MAXINSTANCES"] = "Pencere Sayısı"
L["STRING_OPTIONS_MAXINSTANCES_DESC"] = [=[Oluşturulabilecek pencere sayısını sınırla.

Pencerelerini Pencere Kontrolü menüsünden yönetebilirsin.]=]
L["STRING_OPTIONS_MAXSEGMENTS"] = "Bölüm Sayısı"
L["STRING_OPTIONS_MAXSEGMENTS_DESC"] = "Kaç bölüm saklamak istediğini denetler."
L["STRING_OPTIONS_MENU_ALPHA"] = "Fare Etkileşimi:"
L["STRING_OPTIONS_MENU_ALPHAENABLED_DESC"] = [=[Açıksa fareyle pencerenin üzerine gelip ayrıldığında saydamlık otomatik değişir.

|cFFFFFF00Önemli|r: Bu ayar, Pencere Ayarları bölümündeki Pencere Rengi seçeneğinde seçilen saydamlığın yerine geçer.]=]
L["STRING_OPTIONS_MENU_ALPHAENTER"] = "Üzerine Gelince"
L["STRING_OPTIONS_MENU_ALPHAENTER_DESC"] = "Fare pencerenin üzerindeyken saydamlık bu değere değişir."
L["STRING_OPTIONS_MENU_ALPHALEAVE"] = "Etkileşim Yok"
L["STRING_OPTIONS_MENU_ALPHALEAVE_DESC"] = "Fare pencerenin üzerinde değilken saydamlık bu değere değişir."
L["STRING_OPTIONS_MENU_ALPHAWARNING"] = "Fare Etkileşimi açık, saydamlık etkilenmeyebilir."
L["STRING_OPTIONS_MENU_ANCHOR"] = "Düğmeler Sağa Tuttursun"
L["STRING_OPTIONS_MENU_ANCHOR_DESC"] = "İşaretliyse düğmeler pencerenin sağ tarafına tutturulur."
L["STRING_OPTIONS_MENU_ATTRIBUTE_ANCHORX"] = "X Konumu"
L["STRING_OPTIONS_MENU_ATTRIBUTE_ANCHORX_DESC"] = "Özellik yazısının X eksenindeki yerini ayarla."
L["STRING_OPTIONS_MENU_ATTRIBUTE_ANCHORY"] = "Y Konumu"
L["STRING_OPTIONS_MENU_ATTRIBUTE_ANCHORY_DESC"] = "Özellik yazısının Y eksenindeki yerini ayarla."
L["STRING_OPTIONS_MENU_ATTRIBUTE_ENABLED_DESC"] = "Etkin, pencerede şu anda gösterilen görünümün adını gösterir."
L["STRING_OPTIONS_MENU_ATTRIBUTE_ENCOUNTERTIMER"] = "Karşılaşma Sayacı"
L["STRING_OPTIONS_MENU_ATTRIBUTE_ENCOUNTERTIMER_DESC"] = "Açıksa yazının sol tarafında bir kronometre gösterilir."
--[[Translation missing --]]
L["STRING_OPTIONS_MENU_ATTRIBUTE_FONT"] = ""
L["STRING_OPTIONS_MENU_ATTRIBUTE_FONT_DESC"] = "Özellik yazısı için yazı tipini seç."
L["STRING_OPTIONS_MENU_ATTRIBUTE_SHADOW_DESC"] = "Yazıdaki gölgeyi açar ya da kapatır."
L["STRING_OPTIONS_MENU_ATTRIBUTE_SIDE"] = "Üst Kenara Tuttur"
L["STRING_OPTIONS_MENU_ATTRIBUTE_SIDE_DESC"] = "Yazının nereye sabitleneceğini seç."
L["STRING_OPTIONS_MENU_ATTRIBUTE_TEXTCOLOR"] = "Yazı Rengi"
L["STRING_OPTIONS_MENU_ATTRIBUTE_TEXTCOLOR_DESC"] = "Özellik yazısının rengini değiştir."
--[[Translation missing --]]
L["STRING_OPTIONS_MENU_ATTRIBUTE_TEXTSIZE"] = ""
L["STRING_OPTIONS_MENU_ATTRIBUTE_TEXTSIZE_DESC"] = "Özellik yazısının boyutunu ayarla."
L["STRING_OPTIONS_MENU_ATTRIBUTESETTINGS_ANCHOR"] = "Ayarlar:"
L["STRING_OPTIONS_MENU_AUTOHIDE_DESC"] = "Fare pencereden çıkınca düğmeleri otomatik gizle, pencereyle yeniden etkileşime geçince göster."
L["STRING_OPTIONS_MENU_AUTOHIDE_LEFT"] = "Düğmeleri Otomatik Gizle"
L["STRING_OPTIONS_MENU_BUTTONSSIZE_DESC"] = "Düğme boyutunu seç. Bu, eklentilerin eklediği düğmeleri de değiştirir."
L["STRING_OPTIONS_MENU_FONT_FACE"] = "Menü Yazı Tipi"
L["STRING_OPTIONS_MENU_FONT_FACE_DESC"] = "Tüm menülerde kullanılan yazı tipini değiştir."
L["STRING_OPTIONS_MENU_FONT_SIZE"] = "Menü Yazı Boyutu"
L["STRING_OPTIONS_MENU_FONT_SIZE_DESC"] = "Tüm menülerdeki yazı boyutunu değiştir."
L["STRING_OPTIONS_MENU_IGNOREBARS"] = "Çubukları Yok Say"
L["STRING_OPTIONS_MENU_IGNOREBARS_DESC"] = "Açıksa bu penceredeki hiçbir satır bu mekanizmadan etkilenmez."
L["STRING_OPTIONS_MENU_SHOWBUTTONS"] = "Düğmeleri Göster"
L["STRING_OPTIONS_MENU_SHOWBUTTONS_DESC"] = "Başlık çubuğunda hangi düğmelerin gösterileceğini seç."
L["STRING_OPTIONS_MENU_X"] = "X Konumu"
L["STRING_OPTIONS_MENU_X_DESC"] = "X ekseni konumunu değiştirir."
L["STRING_OPTIONS_MENU_Y"] = "Y Konumu"
L["STRING_OPTIONS_MENU_Y_DESC"] = "Y ekseni konumunu değiştirir"
L["STRING_OPTIONS_MENUS_SHADOW"] = "Gölge"
L["STRING_OPTIONS_MENUS_SHADOW_DESC"] = "Tüm düğmelere ince bir gölge kenarlığı ekler."
L["STRING_OPTIONS_MENUS_SPACEMENT"] = "Boşluk"
L["STRING_OPTIONS_MENUS_SPACEMENT_DESC"] = "Düğmeler arasındaki mesafeyi denetler."
L["STRING_OPTIONS_MICRODISPLAY_ANCHOR"] = "Mikro Görünümler:"
L["STRING_OPTIONS_MICRODISPLAY_LOCK"] = "Mikro Görünümleri Kilitle"
L["STRING_OPTIONS_MICRODISPLAY_LOCK_DESC"] = "Kilitliyken fareyle üzerine gelmeye ve tıklamaya tepki vermezler."
L["STRING_OPTIONS_MICRODISPLAYS_DROPDOWN_TOOLTIP"] = "Bu tarafta gösterilecek mikro görünümü seç."
L["STRING_OPTIONS_MICRODISPLAYS_OPTION_TOOLTIP"] = "Bu mikro görünümün ayarını yap."
L["STRING_OPTIONS_MICRODISPLAYS_SHOWHIDE_TOOLTIP"] = "Bu Mikro Görünümü Göster ya da Gizle"
L["STRING_OPTIONS_MICRODISPLAYS_WARNING"] = [=[|cFFFFFF00Not|r: mikro görünümler gösterilemiyor çünkü
alt kenara sabitlenmişler
ve durum çubuğu kapalı.]=]
L["STRING_OPTIONS_MICRODISPLAYSSIDE"] = "Mikro Görünümler Üstte"
L["STRING_OPTIONS_MICRODISPLAYSSIDE_DESC"] = "Mikro görünümleri pencerenin üstüne ya da altına yerleştir."
L["STRING_OPTIONS_MICRODISPLAYWARNING"] = "Durum çubuğu kapalı olduğu için mikro görünümler gösterilmiyor."
L["STRING_OPTIONS_MINIMAP"] = "Simgeyi Göster"
L["STRING_OPTIONS_MINIMAP_ACTION"] = "Tıklayınca"
L["STRING_OPTIONS_MINIMAP_ACTION_DESC"] = "Minimapteki simgeye farenin sol tuşuyla tıklanınca ne yapılacağını seç."
L["STRING_OPTIONS_MINIMAP_ACTION1"] = "Ayarlar Panelini Aç"
L["STRING_OPTIONS_MINIMAP_ACTION2"] = "Bölümleri Sıfırla"
L["STRING_OPTIONS_MINIMAP_ACTION3"] = "Pencereleri Göster/Gizle"
L["STRING_OPTIONS_MINIMAP_ANCHOR"] = "Minimap:"
L["STRING_OPTIONS_MINIMAP_DESC"] = "Minimap simgesini göster ya da gizle."
L["STRING_OPTIONS_MISCTITLE"] = "Çeşitli Ayarlar"
L["STRING_OPTIONS_MISCTITLE2"] = "Bunlar çeşitli seçenekleri denetler."
L["STRING_OPTIONS_MPLUS_AUTO_CLOSE_TIME"] = "Otomatik Kapanma Süresi"
L["STRING_OPTIONS_MPLUS_AUTO_CLOSE_TIME_DESC"] = "M+ Sonu Panelini otomatik kapatma süresi."
L["STRING_OPTIONS_MPLUS_BOSSNEWCOMBAT"] = "Boss Çekilince Yeni Savaş"
L["STRING_OPTIONS_MPLUS_BOSSNEWCOMBAT_DESC"] = "Savaştayken bir boss çekilirse bu seçenek şimdiki savaşı kapatır ve boss için yenisini başlatır."
L["STRING_OPTIONS_MPLUS_DPS_ANCHOR"] = "Genel Bölüm DPS Hesabı"
L["STRING_OPTIONS_MPLUS_MERGETRASH"] = "Trash'i Birleştir"
L["STRING_OPTIONS_MPLUS_PANELS_ANCHOR"] = "Paneller"
L["STRING_OPTIONS_MPLUS_SHOWENDPANEL"] = "M+ Sonu Panelini Göster"
L["STRING_OPTIONS_MPLUS_TIME_INCOMBAT"] = "Savaşta Geçen Süre"
L["STRING_OPTIONS_MPLUS_TIME_INCOMBAT_DESC"] = "Mythic+ koşusunun genel bölümü DPS'i hesaplamak için 'toplamHasar / toplamSavaşSüresi' kullanır."
L["STRING_OPTIONS_MPLUS_TIME_RUNTIME"] = "Zindan Koşu Süresi"
L["STRING_OPTIONS_MPLUS_TIME_RUNTIME_DESC"] = "Mythic+ koşusunun genel bölümü DPS'i 'toplamHasar / koşuSüresi' ile hesaplar."
L["STRING_OPTIONS_NICKNAME"] = "Takma Ad"
L["STRING_OPTIONS_NICKNAME_DESC"] = [=[Kendin için bir takma ad belirle.

Takma adlar lonca üyelerine gönderilir ve Details! karakter adın yerine onu kullanır.]=]
L["STRING_OPTIONS_OPEN_ROWTEXT_EDITOR"] = "Satır Yazı Düzenleyicisi"
L["STRING_OPTIONS_OPEN_TEXT_EDITOR"] = "Yazı Düzenleyicisini Aç"
L["STRING_OPTIONS_OPENBROKER"] = "Broker Yazı Düzenleyicisini Aç"
L["STRING_OPTIONS_OVERALL_ALL"] = "Tüm Bölümler"
L["STRING_OPTIONS_OVERALL_ALL_DESC"] = "Tüm bölümler genel veriye eklenir."
L["STRING_OPTIONS_OVERALL_ANCHOR"] = "Genel Veri:"
L["STRING_OPTIONS_OVERALL_DUNGEONBOSS"] = "Zindan Boss'ları"
L["STRING_OPTIONS_OVERALL_DUNGEONBOSS_DESC"] = "Zindan boss'larının olduğu bölümler genel veriye eklenir."
L["STRING_OPTIONS_OVERALL_DUNGEONCLEAN"] = "Zindan Trash'i"
L["STRING_OPTIONS_OVERALL_DUNGEONCLEAN_DESC"] = "Zindan trash temizliği bölümleri genel veriye eklenir."
L["STRING_OPTIONS_OVERALL_LOGOFF"] = "Çıkışta Temizle"
L["STRING_OPTIONS_OVERALL_LOGOFF_DESC"] = "Açıksa karakterden çıkış yaptığında genel veri otomatik silinir."
L["STRING_OPTIONS_OVERALL_MYTHICPLUS"] = "Mythic+ Başlarken Temizle"
L["STRING_OPTIONS_OVERALL_MYTHICPLUS_DESC"] = "Açıksa yeni bir mythic+ koşusu başladığında genel veri otomatik silinir."
L["STRING_OPTIONS_OVERALL_NEWBOSS"] = "Yeni Raid Boss'unda Temizle"
L["STRING_OPTIONS_OVERALL_NEWBOSS_DESC"] = "Açıksa farklı bir raid boss'uyla karşılaşınca genel veri otomatik silinir."
L["STRING_OPTIONS_OVERALL_RAIDBOSS"] = "Raid Boss'ları"
L["STRING_OPTIONS_OVERALL_RAIDBOSS_DESC"] = "Raid karşılaşmalarının olduğu bölümler genel veriye eklenir."
L["STRING_OPTIONS_OVERALL_RAIDCLEAN"] = "Raid Trash'i"
L["STRING_OPTIONS_OVERALL_RAIDCLEAN_DESC"] = "Raid trash temizliği bölümleri genel veriye eklenir."
L["STRING_OPTIONS_PANIMODE"] = "Panik Modu"
L["STRING_OPTIONS_PANIMODE_DESC"] = "Açıksa, bir boss karşılaşmasında savaşırken oyundan düşersen (örneğin bağlantı kopunca) tüm bölümler silinir; bu çıkış işlemini hızlandırır."
L["STRING_OPTIONS_PDW_ANCHOR"] = "Paneller:"
L["STRING_OPTIONS_PDW_SKIN_DESC"] = [=[Oyuncu Ayrıntıları Penceresi, Rapor Penceresi ve Ayarlar Panelinde kullanılacak görünüm.
Bazı değişiklikler /reload gerektirir.]=]
L["STRING_OPTIONS_PERCENT_TYPE"] = "Yüzde Türü"
L["STRING_OPTIONS_PERCENT_TYPE_DESC"] = [=[Yüzde yöntemini değiştirir:

|cFFFFFF00Toplama Göre|r: yüzde, tüm raid üyelerinin yaptığı toplam miktarın etkin oranını gösterir.

|cFFFFFF00En İyi Oyuncuya Göre|r: yüzde, en iyi oyuncunun puanına göredir.]=]
L["STRING_OPTIONS_PERFORMANCE"] = "Performans"
L["STRING_OPTIONS_PERFORMANCE_ANCHOR"] = "Genel:"
L["STRING_OPTIONS_PERFORMANCE_ARENA"] = "Arena"
L["STRING_OPTIONS_PERFORMANCE_BG15"] = "Battleground 15"
L["STRING_OPTIONS_PERFORMANCE_BG40"] = "Battleground 40"
L["STRING_OPTIONS_PERFORMANCE_DUNGEON"] = "Zindan"
L["STRING_OPTIONS_PERFORMANCE_ENABLE_DESC"] = "Açıksa bu ayar, raidin seçili raid türüyle eşleştiğinde uygulanır."
L["STRING_OPTIONS_PERFORMANCE_ERASEWORLD"] = "Dünya Bölümlerini Otomatik Sil"
L["STRING_OPTIONS_PERFORMANCE_ERASEWORLD_DESC"] = "Dışarıda savaştayken bölümleri otomatik sil."
L["STRING_OPTIONS_PERFORMANCE_MYTHIC"] = "Efsanevi"
L["STRING_OPTIONS_PERFORMANCE_PROFILE_LOAD"] = "Performans Profili Değişti: "
L["STRING_OPTIONS_PERFORMANCE_RAID15"] = "Raid 10-15"
L["STRING_OPTIONS_PERFORMANCE_RAID30"] = "Raid 16-30"
L["STRING_OPTIONS_PERFORMANCE_RF"] = "Raid Bulucu"
L["STRING_OPTIONS_PERFORMANCE_TYPES"] = "Tür"
L["STRING_OPTIONS_PERFORMANCE_TYPES_DESC"] = "Bu, farklı seçeneklerin otomatik olarak değişebileceği raid türüdür."
L["STRING_OPTIONS_PERFORMANCE1"] = "Performans Ayarları"
L["STRING_OPTIONS_PERFORMANCE1_DESC"] = "Bu seçenekler işlemci kullanımından tasarruf etmeye yardımcı olabilir."
L["STRING_OPTIONS_PERFORMANCECAPTURES"] = "Veri Toplayıcı"
L["STRING_OPTIONS_PERFORMANCECAPTURES_DESC"] = "Bu seçenekler savaş verilerinin analizinden ve toplanmasından sorumludur."
L["STRING_OPTIONS_PERFORMANCEPROFILES_ANCHOR"] = "Performans Profilleri:"
L["STRING_OPTIONS_PICONS_DIRECTION"] = "Eklentiler Sağa Tuttursun"
L["STRING_OPTIONS_PICONS_DIRECTION_DESC"] = "İşaretliyse eklenti düğmeleri menü düğmelerinin sağında gösterilir."
L["STRING_OPTIONS_PLAYERNAME"] = "Oyuncu Adı"
L["STRING_OPTIONS_PLAYERNAME_AUTO_ALIGNMENT"] = "Otomatik Hizalama"
L["STRING_OPTIONS_PLAYERNAME_AUTO_ALIGNMENT_DESC"] = "Bunu yalnızca oyuncu adı hizalama sorunu yaşıyorsan kapat."
L["STRING_OPTIONS_PLAYERNAME_AUTO_WIDTH"] = "Otomatik Uzunluk"
L["STRING_OPTIONS_PLAYERNAME_WIDTH"] = "Uzunluk"
L["STRING_OPTIONS_PLUGINS"] = "Eklentiler"
L["STRING_OPTIONS_PLUGINS_AUTHOR"] = "Yazar"
L["STRING_OPTIONS_PLUGINS_NAME"] = "Ad"
L["STRING_OPTIONS_PLUGINS_OPTIONS"] = "Seçenekler"
L["STRING_OPTIONS_PLUGINS_RAID_ANCHOR"] = "Raid Eklentileri"
L["STRING_OPTIONS_PLUGINS_SOLO_ANCHOR"] = "Tek Başına Eklentileri"
L["STRING_OPTIONS_PLUGINS_TOOLBAR_ANCHOR"] = "Başlık Çubuğu Eklentileri"
L["STRING_OPTIONS_PLUGINS_VERSION"] = "Sürüm"
L["STRING_OPTIONS_PRESETNONAME"] = "Ön ayarına bir ad ver."
L["STRING_OPTIONS_PRESETTOOLD"] = "Bu ön ayar çok eski, Details!'in bu sürümüyle yüklenemez."
L["STRING_OPTIONS_PROFILE_COPYOKEY"] = "Profil başarıyla kopyalandı."
L["STRING_OPTIONS_PROFILE_FIELDEMPTY"] = "Ad alanı boş."
L["STRING_OPTIONS_PROFILE_GLOBAL"] = "Tüm karakterlerde kullanılacak profili seç."
L["STRING_OPTIONS_PROFILE_LOADED"] = "Profil yüklendi:"
L["STRING_OPTIONS_PROFILE_NOTCREATED"] = "Profil oluşturulamadı."
L["STRING_OPTIONS_PROFILE_OVERWRITTEN"] = "bu karakter için belirli bir profil seçtin"
L["STRING_OPTIONS_PROFILE_POSSIZE"] = "Boyutu ve Konumu Kaydet"
L["STRING_OPTIONS_PROFILE_POSSIZE_DESC"] = "Pencerenin konumunu ve boyutunu profilde kaydet. Kapalıyken her karakterin kendi değerleri olur."
L["STRING_OPTIONS_PROFILE_REMOVEOKEY"] = "Profil başarıyla kaldırıldı."
L["STRING_OPTIONS_PROFILE_SELECT"] = "bir profil seç."
L["STRING_OPTIONS_PROFILE_SELECTEXISTING"] = "Bu karakter için mevcut bir profil seç ya da yenisini kullanmaya devam et:"
L["STRING_OPTIONS_PROFILE_USENEW"] = "Yeni Profili Kullan"
L["STRING_OPTIONS_PROFILES_ANCHOR"] = "Ayarlar:"
L["STRING_OPTIONS_PROFILES_COPY"] = "Profili Şuradan Kopyala"
L["STRING_OPTIONS_PROFILES_COPY_DESC"] = "Seçili profilin tüm ayarlarını, tüm değerlerin üzerine yazarak geçerli profile kopyala."
L["STRING_OPTIONS_PROFILES_CREATE"] = "Profil Oluştur"
L["STRING_OPTIONS_PROFILES_CREATE_DESC"] = "Yeni bir profil oluştur."
L["STRING_OPTIONS_PROFILES_CURRENT"] = "Geçerli Profil:"
L["STRING_OPTIONS_PROFILES_CURRENT_DESC"] = "Bu, şu anda etkin olan profilin adıdır."
L["STRING_OPTIONS_PROFILES_ERASE"] = "Profili Kaldır"
L["STRING_OPTIONS_PROFILES_ERASE_DESC"] = "Seçili profili kaldır."
L["STRING_OPTIONS_PROFILES_RESET"] = "Geçerli Profili Sıfırla"
L["STRING_OPTIONS_PROFILES_RESET_DESC"] = "Seçili profilin tüm ayarlarını varsayılan değerlere sıfırla."
L["STRING_OPTIONS_PROFILES_SELECT"] = "Profil Seç"
L["STRING_OPTIONS_PROFILES_SELECT_DESC"] = "Mevcut bir profili yükle. Tüm karakterlerde aynı profili kullanıyorsan (Tüm Karakterlerde Kullan seçeneği), bu karakter için bir istisna oluşturulur. "
L["STRING_OPTIONS_PROFILES_TITLE"] = "Profiller"
L["STRING_OPTIONS_PROFILES_TITLE_DESC"] = "Bu seçenekler aynı ayarları farklı karakterler arasında paylaşmanı sağlar."
L["STRING_OPTIONS_PS_ABBREVIATE"] = "Sayı Biçimi"
L["STRING_OPTIONS_PS_ABBREVIATE_COMMA"] = "Virgül"
L["STRING_OPTIONS_PS_ABBREVIATE_DESC"] = [=[Kısaltma yöntemini seç.

|cFFFFFF00ToK I|r:
520600 = 520.6K
19530000 = 19.53M

|cFFFFFF00ToK II|r:
520600 = 520K
19530000 = 19.53M

|cFFFFFF00ToM I|r:
520600 = 520.6K
19530000 = 19M

|cFFFFFF00Virgül|r:
19530000 = 19.530.000

|cFFFFFF00Alt|r ve |cFFFFFF00Üst|r: 'K' ve 'M' harflerinin küçük ya da büyük olduğunu belirtir.]=]
L["STRING_OPTIONS_PS_ABBREVIATE_NONE"] = "Yok"
L["STRING_OPTIONS_PS_ABBREVIATE_TOK"] = "ToK I Üst"
L["STRING_OPTIONS_PS_ABBREVIATE_TOK0"] = "ToM I Üst"
L["STRING_OPTIONS_PS_ABBREVIATE_TOK0MIN"] = "ToM I Alt"
L["STRING_OPTIONS_PS_ABBREVIATE_TOK2"] = "ToK II Üst"
L["STRING_OPTIONS_PS_ABBREVIATE_TOK2MIN"] = "ToK II Alt"
L["STRING_OPTIONS_PS_ABBREVIATE_TOKMIN"] = "ToK I Alt"
L["STRING_OPTIONS_PVPFRAGS"] = "Yalnızca PvP Öldürmeleri"
L["STRING_OPTIONS_PVPFRAGS_DESC"] = "Açıksa |cFFFFFF00hasar > öldürmeler|r görünümünde yalnızca düşman oyunculara karşı öldürmeler sayılır."
L["STRING_OPTIONS_REALMNAME"] = "Realm Adını Kaldır"
L["STRING_OPTIONS_REALMNAME_DESC"] = [=[Açıksa karakterin realm adı gösterilmez.

|cFFFFFF00Kapalı|r: Charles-Netherwing
|cFFFFFF00Açık|r: Charles]=]
L["STRING_OPTIONS_REPORT_ANCHOR"] = "Rapor:"
L["STRING_OPTIONS_REPORT_HEALLINKS"] = "İyileştirme Büyüsü Bağlantıları"
L["STRING_OPTIONS_REPORT_HEALLINKS_DESC"] = [=[Bu seçenek açıkken rapor gönderilirse |cFF55FF55yardımcı|r büyüler adları yerine büyü bağlantısıyla raporlanır.

|cFFFF5555Zararlı|r büyüler varsayılan olarak bağlantıyla raporlanır.]=]
L["STRING_OPTIONS_REPORT_SCHEMA"] = "Biçim"
L["STRING_OPTIONS_REPORT_SCHEMA_DESC"] = "Sohbet kanalına bağlanan yazının biçimini seç."
L["STRING_OPTIONS_REPORT_SCHEMA1"] = "Toplam / Saniyede / Yüzde"
L["STRING_OPTIONS_REPORT_SCHEMA2"] = "Yüzde / Saniyede / Toplam"
L["STRING_OPTIONS_REPORT_SCHEMA3"] = "Yüzde / Toplam / Saniyede"
L["STRING_OPTIONS_RESET_TO_DEFAULT"] = "Varsayılana Döndür"
L["STRING_OPTIONS_ROWADV_TITLE"] = "Satır Gelişmiş Ayarları"
L["STRING_OPTIONS_ROWADV_TITLE_DESC"] = "Bu seçenekler satırları daha ayrıntılı değiştirmeni sağlar."
L["STRING_OPTIONS_RT_COOLDOWN1"] = "%s, %s üzerinde kullanıldı!"
L["STRING_OPTIONS_RT_COOLDOWN2"] = "%s kullanıldı!"
L["STRING_OPTIONS_RT_COOLDOWNS_ANCHOR"] = "Bekleme Sürelerini Duyur:"
L["STRING_OPTIONS_RT_COOLDOWNS_CHANNEL"] = "Kanal"
L["STRING_OPTIONS_RT_COOLDOWNS_CHANNEL_DESC"] = [=[Uyarı mesajını göndermek için hangi sohbet kanalının kullanılacağı.

|cFFFFFF00Gözlemci|r seçilirse, kişisel bekleme süreleri hariç tüm bekleme süreleri sohbetine yazılır.]=]
L["STRING_OPTIONS_RT_COOLDOWNS_CUSTOM"] = "Özel Yazı"
L["STRING_OPTIONS_RT_COOLDOWNS_CUSTOM_DESC"] = [=[Gönderilecek kendi cümleni yaz.

Bekleme süresi büyüsünün adını eklemek için |cFFFFFF00{spell}|r kullan.

Oyuncunun hedefinin adını eklemek için |cFFFFFF00{target}|r kullan.]=]
L["STRING_OPTIONS_RT_COOLDOWNS_ONOFF_DESC"] = "Bir bekleme süresi kullandığında seçili kanaldan bir mesaj gönderilir."
L["STRING_OPTIONS_RT_COOLDOWNS_SELECT"] = "Yok Sayılan Bekleme Süresi Listesi"
L["STRING_OPTIONS_RT_COOLDOWNS_SELECT_DESC"] = "Hangi bekleme sürelerinin yok sayılacağını seç."
L["STRING_OPTIONS_RT_DEATH_MSG"] = "Details! %s adlı oyuncunun ölümü"
L["STRING_OPTIONS_RT_DEATHS_ANCHOR"] = "Ölümleri Duyur:"
L["STRING_OPTIONS_RT_DEATHS_FIRST"] = "Yalnızca İlki"
L["STRING_OPTIONS_RT_DEATHS_FIRST_DESC"] = "Karşılaşma sırasında yalnızca ilk X ölümü duyurur."
L["STRING_OPTIONS_RT_DEATHS_HITS"] = "Vuruş Sayısı"
L["STRING_OPTIONS_RT_DEATHS_HITS_DESC"] = "Ölümü duyururken kaç vuruş olduğunu göster."
L["STRING_OPTIONS_RT_DEATHS_ONOFF_DESC"] = "Bir raid üyesi öldüğünde, onu neyin öldürdüğünü raid kanalına gönderir."
L["STRING_OPTIONS_RT_DEATHS_WHERE"] = "Zindanlar"
L["STRING_OPTIONS_RT_DEATHS_WHERE_DESC"] = [=[Ölümlerin nerede raporlanabileceğini seç.

|cFFFFFF00Önemli|r: raidlerde /raid kanalı, zindanlarda /p kullanılır.

|cFFFFFF00Gözlemci|r seçilirse ölümler sohbette yalnızca sana gösterilir.]=]
L["STRING_OPTIONS_RT_DEATHS_WHERE1"] = "Raid ve Zindan"
L["STRING_OPTIONS_RT_DEATHS_WHERE2"] = "Yalnızca Raid"
L["STRING_OPTIONS_RT_DEATHS_WHERE3"] = "Yalnızca Zindan"
L["STRING_OPTIONS_RT_FIRST_HIT"] = "İlk Vuruş"
L["STRING_OPTIONS_RT_FIRST_HIT_DESC"] = "İlk vuruşu kimin yaptığını (genellikle dövüşü başlatan kişidir) sohbet paneline (|cFFFFFF00yalnızca sana|r) yazar."
L["STRING_OPTIONS_RT_IGNORE_TITLE"] = "Bekleme Sürelerini Yok Say"
L["STRING_OPTIONS_RT_INFOS"] = "Ek Bilgiler:"
L["STRING_OPTIONS_RT_INFOS_PREPOTION"] = "Savaş Öncesi İksir Kullanımı"
L["STRING_OPTIONS_RT_INFOS_PREPOTION_DESC"] = "Açıksa, bir raid karşılaşmasından sonra çekişten önce kimin iksir kullandığını sohbetine (|cFFFFFF00yalnızca sana|r) yazar."
L["STRING_OPTIONS_RT_INTERRUPT"] = "%s kesildi!"
L["STRING_OPTIONS_RT_INTERRUPT_ANCHOR"] = "Kesmeleri Duyur:"
L["STRING_OPTIONS_RT_INTERRUPT_NEXT"] = "Sonraki: %s"
L["STRING_OPTIONS_RT_INTERRUPTS_CHANNEL"] = "Kanal"
L["STRING_OPTIONS_RT_INTERRUPTS_CHANNEL_DESC"] = [=[Uyarı mesajını göndermek için hangi sohbet kanalının kullanılacağı.

|cFFFFFF00Gözlemci|r seçilirse tüm kesmeler sohbette yalnızca sana yazılır.]=]
L["STRING_OPTIONS_RT_INTERRUPTS_CUSTOM"] = "Özel Yazı"
L["STRING_OPTIONS_RT_INTERRUPTS_CUSTOM_DESC"] = [=[Gönderilecek kendi cümleni yaz.

Kesilen büyünün adını eklemek için |cFFFFFF00{spell}|r kullan.

'Sonraki' kutusuna yazılan sonraki oyuncunun adını eklemek için |cFFFFFF00{next}|r kullan.]=]
L["STRING_OPTIONS_RT_INTERRUPTS_NEXT"] = "Sonraki Oyuncu"
L["STRING_OPTIONS_RT_INTERRUPTS_NEXT_DESC"] = "Bir kesme sırası varsa, sonraki kesmeden sorumlu oyuncunun adını yaz."
L["STRING_OPTIONS_RT_INTERRUPTS_ONOFF_DESC"] = "Bir büyüyü başarıyla kestiğinde bir mesaj gönderilir."
L["STRING_OPTIONS_RT_INTERRUPTS_WHISPER"] = "Şuna Fısılda"
L["STRING_OPTIONS_RT_OTHER_ANCHOR"] = "Genel:"
L["STRING_OPTIONS_RT_TITLE"] = "Raid Oyuncuları İçin Araçlar"
L["STRING_OPTIONS_RT_TITLE_DESC"] = "Bu panelde raidlerde sana yardımcı olacak çeşitli mekanizmaları etkinleştirebilirsin."
L["STRING_OPTIONS_SAVELOAD"] = "Kaydet ve Yükle"
L["STRING_OPTIONS_SAVELOAD_APPLYALL"] = "Geçerli görünüm diğer tüm pencerelere uygulandı."
L["STRING_OPTIONS_SAVELOAD_APPLYALL_DESC"] = "Geçerli görünümü oluşturulan tüm pencerelere uygula."
L["STRING_OPTIONS_SAVELOAD_APPLYTOALL"] = "Tüm Pencerelere Uygula"
L["STRING_OPTIONS_SAVELOAD_CREATE_DESC"] = "Geçerli görünümü ön ayar olarak kaydet; dışa aktarabilir ya da yedek olarak saklayabilirsin."
L["STRING_OPTIONS_SAVELOAD_DESC"] = "Bu seçenekler önceden tanımlı ayarları kaydetmeni ya da yüklemeni sağlar."
L["STRING_OPTIONS_SAVELOAD_ERASE_DESC"] = "Bu seçenek önceden kaydedilmiş bir görünümü siler."
L["STRING_OPTIONS_SAVELOAD_EXPORT"] = "Dışa Aktar"
L["STRING_OPTIONS_SAVELOAD_EXPORT_COPY"] = "CTRL + C'ye bas"
L["STRING_OPTIONS_SAVELOAD_EXPORT_DESC"] = "Görünümü metin biçiminde kaydeder."
L["STRING_OPTIONS_SAVELOAD_IMPORT"] = "Özel Görünüm İçe Aktar"
L["STRING_OPTIONS_SAVELOAD_IMPORT_DESC"] = "Metin biçiminde bir görünüm içe aktar."
L["STRING_OPTIONS_SAVELOAD_IMPORT_OKEY"] = "Görünüm kayıtlı görünümler listene aktarıldı. Artık 'Uygula' açılır listesinden uygulayabilirsin."
L["STRING_OPTIONS_SAVELOAD_LOAD"] = "Uygula"
L["STRING_OPTIONS_SAVELOAD_LOAD_DESC"] = "Seçili pencereye uygulamak için önceden kaydedilmiş görünümlerden birini seç."
L["STRING_OPTIONS_SAVELOAD_MAKEDEFAULT"] = "Standart Yap"
L["STRING_OPTIONS_SAVELOAD_PNAME"] = "Ad"
L["STRING_OPTIONS_SAVELOAD_REMOVE"] = "Sil"
L["STRING_OPTIONS_SAVELOAD_RESET"] = "Varsayılan Görünümü Yükle"
L["STRING_OPTIONS_SAVELOAD_SAVE"] = "kaydet"
L["STRING_OPTIONS_SAVELOAD_SKINCREATED"] = "görünüm kaydedildi."
L["STRING_OPTIONS_SAVELOAD_STD_DESC"] = [=[Geçerli görünümü Standart Görünüm olarak ayarla.

Bu görünüm oluşturulan tüm yeni pencerelere uygulanır.]=]
L["STRING_OPTIONS_SAVELOAD_STDSAVE"] = "Standart Görünüm kaydedildi, yeni pencereler varsayılan olarak bu görünümü kullanacak."
L["STRING_OPTIONS_SCROLLBAR"] = "Kaydırma Çubuğu"
L["STRING_OPTIONS_SCROLLBAR_DESC"] = [=[Kaydırma çubuğunu açar ya da kapatır.

Details! kaydırma çubukları varsayılan olarak pencereyi uzatan bir mekanizmayla değiştirilir.

|cFFFFFF00Uzatma tutamacı|r pencerenin düğme/menü alanının dışında (kapat düğmesinin solunda) bulunur.]=]
L["STRING_OPTIONS_SEGMENTSSAVE"] = "Kaydedilen Bölümler"
L["STRING_OPTIONS_SEGMENTSSAVE_DESC"] = [=[Oyun oturumları arasında kaç bölüm saklamak istediğin.

Yüksek değerler karakterinin çıkış süresini uzatabilir.]=]
L["STRING_OPTIONS_SELECT_TEMPLATE"] = "Şablon Seç"
L["STRING_OPTIONS_SENDFEEDBACK"] = "Geri Bildirim"
L["STRING_OPTIONS_SHOW_SIDEBARS"] = "Görünüm Kenarlığını Göster"
L["STRING_OPTIONS_SHOW_SIDEBARS_DESC"] = "Görünüm dosyasındaki pencere kenarlığını göster; 'Pencere Rengi' ile aynı rengi kullanır."
L["STRING_OPTIONS_SHOW_STATUSBAR"] = "Durum Çubuğunu Göster"
L["STRING_OPTIONS_SHOW_STATUSBAR_DESC"] = "Alttaki durum çubuğunu göster ya da gizle."
L["STRING_OPTIONS_SHOW_TOTALBAR_COLOR_DESC"] = "Rengi seç. Saydamlık değeri satır saydamlığını izler."
L["STRING_OPTIONS_SHOW_TOTALBAR_DESC"] = "Toplam çubuğunu göster ya da gizle."
L["STRING_OPTIONS_SHOW_TOTALBAR_ICON"] = "Simge"
L["STRING_OPTIONS_SHOW_TOTALBAR_ICON_DESC"] = "Toplam çubuğunda gösterilen simgeyi seç."
L["STRING_OPTIONS_SHOW_TOTALBAR_INGROUP"] = "Yalnızca Gruptayken"
L["STRING_OPTIONS_SHOW_TOTALBAR_INGROUP_DESC"] = "Grupta değilsen toplam çubuğu gösterilmez."
L["STRING_OPTIONS_SIZE"] = "Boyut"
L["STRING_OPTIONS_SKIN_A"] = "Görünüm Ayarları"
L["STRING_OPTIONS_SKIN_A_DESC"] = "Bu seçenekler görünümü değiştirmeni sağlar."
L["STRING_OPTIONS_SKIN_ELVUI_BUTTON1"] = "Sağ Sohbet İçinde Hizala"
L["STRING_OPTIONS_SKIN_ELVUI_BUTTON1_DESC"] = "|cFFFFFF00#1|r ve |cFFFFFF00#2|r numaralı pencereleri taşı, boyutlandır ve sağ sohbet penceresinin üzerine yerleştir."
L["STRING_OPTIONS_SKIN_ELVUI_BUTTON2"] = "İpucu Kenarlığını Siyah Yap"
L["STRING_OPTIONS_SKIN_ELVUI_BUTTON2_DESC"] = [=[İpucunun şunlarını değiştir:

Kenarlık Rengi: |cFFFFFF00Siyah|r.
Kenarlık Boyutu: |cFFFFFF0016|r.
Doku: |cFFFFFF00Blizzard İpucu|r.]=]
L["STRING_OPTIONS_SKIN_ELVUI_BUTTON3"] = "İpucu Kenarlığını Kaldır"
L["STRING_OPTIONS_SKIN_ELVUI_BUTTON3_DESC"] = [=[İpucunun şunlarını değiştir:

Kenarlık Rengi: |cFFFFFF00Saydam|r.]=]
L["STRING_OPTIONS_SKIN_EXTRA_OPTIONS_ANCHOR"] = "Görünüm Seçenekleri:"
L["STRING_OPTIONS_SKIN_LOADED"] = "görünüm başarıyla yüklendi."
L["STRING_OPTIONS_SKIN_PRESETS_ANCHOR"] = "Görünümü Kaydet:"
L["STRING_OPTIONS_SKIN_PRESETSCONFIG_ANCHOR"] = "Kayıtlı Görünümler:"
L["STRING_OPTIONS_SKIN_REMOVED"] = "görünüm kaldırıldı."
L["STRING_OPTIONS_SKIN_RESET_TOOLTIP"] = "İpucu Kenarlığını Sıfırla"
L["STRING_OPTIONS_SKIN_RESET_TOOLTIP_DESC"] = "İpucunun kenarlık rengini ve dokusunu varsayılana döndür."
L["STRING_OPTIONS_SKIN_SELECT"] = "bir görünüm seç"
L["STRING_OPTIONS_SKIN_SELECT_ANCHOR"] = "Görünüm Seçimi:"
L["STRING_OPTIONS_SOCIAL"] = "Sosyal"
L["STRING_OPTIONS_SOCIAL_DESC"] = "Loncanda nasıl tanınmak istediğini belirt."
L["STRING_OPTIONS_SPELL_ADD"] = "Ekle"
L["STRING_OPTIONS_SPELL_ADDICON"] = "Yeni Simge: "
L["STRING_OPTIONS_SPELL_ADDNAME"] = "Yeni Ad: "
L["STRING_OPTIONS_SPELL_ADDSPELL"] = "Büyü Ekle"
L["STRING_OPTIONS_SPELL_ADDSPELLID"] = "Büyü Kimliği: "
L["STRING_OPTIONS_SPELL_CLOSE"] = "Kapat"
L["STRING_OPTIONS_SPELL_ICON"] = "Simge"
L["STRING_OPTIONS_SPELL_IDERROR"] = "Geçersiz büyü kimliği."
L["STRING_OPTIONS_SPELL_INDEX"] = "Sıra"
L["STRING_OPTIONS_SPELL_NAME"] = "Ad"
L["STRING_OPTIONS_SPELL_NAMEERROR"] = "Geçersiz büyü adı."
L["STRING_OPTIONS_SPELL_NOTFOUND"] = "Büyü bulunamadı."
L["STRING_OPTIONS_SPELL_REMOVE"] = "Kaldır"
L["STRING_OPTIONS_SPELL_RESET"] = "Sıfırla"
L["STRING_OPTIONS_SPELL_SPELLID"] = "Büyü Kimliği"
L["STRING_OPTIONS_STRETCH"] = "Uzatma Düğmesi Üst Kenarda"
L["STRING_OPTIONS_STRETCH_DESC"] = "Uzatma düğmesini pencerenin üstüne yerleştirir."
L["STRING_OPTIONS_STRETCHTOP"] = "Uzatma Düğmesi Hep Üstte"
L["STRING_OPTIONS_STRETCHTOP_DESC"] = [=[Uzatma düğmesi FULLSCREEN katmanına yerleştirilir ve her zaman diğer çerçevelerin üzerinde kalır.

|cFFFFFF00Önemli|r: Tutamacı yüksek katmana taşımak, çantalar gibi diğer çerçevelerin önünde kalmasına yol açabilir; yalnızca gerçekten gerekiyorsa kullan.]=]
L["STRING_OPTIONS_SWITCH_ANCHOR"] = "Geçişler:"
L["STRING_OPTIONS_SWITCHINFO"] = "|cFFF79F81 SOL KAPALI|r  |cFF81BEF7 SAĞ AÇIK|r"
L["STRING_OPTIONS_TABEMB_ANCHOR"] = "Sohbet Sekmesine Göm"
L["STRING_OPTIONS_TABEMB_ENABLED_DESC"] = "Açıksa bir ya da daha fazla pencere bir sohbet sekmesine tutturulur."
L["STRING_OPTIONS_TABEMB_SINGLE"] = "Tek Pencere"
L["STRING_OPTIONS_TABEMB_SINGLE_DESC"] = "Açıksa iki yerine yalnızca bir pencere tutturulur."
L["STRING_OPTIONS_TABEMB_TABNAME"] = "Sekme Adı"
L["STRING_OPTIONS_TABEMB_TABNAME_DESC"] = "Pencerelerin tutturulacağı sekmenin adı."
L["STRING_OPTIONS_TESTBARS"] = "Deneme Çubukları Oluştur"
L["STRING_OPTIONS_TEXT"] = "Çubuk Yazısı Ayarları"
L["STRING_OPTIONS_TEXT_DESC"] = "Bu seçenekler pencere satırı yazılarının görünümünü denetler."
L["STRING_OPTIONS_TEXT_FIXEDCOLOR"] = "Yazı Rengi"
L["STRING_OPTIONS_TEXT_FIXEDCOLOR_DESC"] = [=[Sol ve sağ yazıların rengini değiştir.

|cFFFFFFFFsınıfa göre renk|r açıksa yok sayılır.]=]
L["STRING_OPTIONS_TEXT_FONT"] = "Yazı Tipi"
L["STRING_OPTIONS_TEXT_FONT_DESC"] = "Sol ve sağ yazıların yazı tipini değiştir."
L["STRING_OPTIONS_TEXT_LCLASSCOLOR_DESC"] = "Açıksa yazı her zaman oyuncunun sınıf rengini kullanır."
L["STRING_OPTIONS_TEXT_LEFT_ANCHOR"] = "Sol Yazı:"
L["STRING_OPTIONS_TEXT_LOUTILINE"] = "Yazı Gölgesi"
L["STRING_OPTIONS_TEXT_LOUTILINE_DESC"] = "Sol yazının dış çizgisini açar ya da kapatır."
L["STRING_OPTIONS_TEXT_LPOSITION"] = "Sayıyı Göster"
L["STRING_OPTIONS_TEXT_LPOSITION_DESC"] = "Oyuncu adının sol tarafında sıra numarasını göster."
L["STRING_OPTIONS_TEXT_LTRANSLIT"] = "Harf Çevirisi"
L["STRING_OPTIONS_TEXT_LTRANSLIT_DESC"] = "Kimsenin anlamadığı Rus harflerinin Batı harfleriyle gösterilmesini sağlar."
L["STRING_OPTIONS_TEXT_OUTLINE"] = "Yazı Dış Çizgisi"
L["STRING_OPTIONS_TEXT_RIGHT_ANCHOR"] = "Sağ Yazı:"
L["STRING_OPTIONS_TEXT_ROUTILINE_DESC"] = "Sağ yazının dış çizgisini açar ya da kapatır."
L["STRING_OPTIONS_TEXT_ROWICONS_ANCHOR"] = "Simgeler:"
L["STRING_OPTIONS_TEXT_SHADOWCOLOR"] = "Gölge Rengi"
L["STRING_OPTIONS_TEXT_SHADOWOFFSET"] = "Gölge Kaydırması %s"
L["STRING_OPTIONS_TEXT_SHOW_BRACKET"] = "Parantez"
L["STRING_OPTIONS_TEXT_SHOW_BRACKET_DESC"] = "Saniyede ve yüzde bloğunu açıp kapatmak için hangi karakterin kullanılacağını seç."
L["STRING_OPTIONS_TEXT_SHOW_PERCENT"] = "Yüzdeyi Göster"
L["STRING_OPTIONS_TEXT_SHOW_PERCENT_DESC"] = [=[Yüzdeyi göster. 

Yüzdeyi kapatırsan DPS'ten sonra fazladan virgül olmaması için 'Ayırıcı'yı 'yok' yapmak isteyebilirsin.]=]
L["STRING_OPTIONS_TEXT_SHOW_PS"] = "Saniyede Değeri Göster"
L["STRING_OPTIONS_TEXT_SHOW_PS_DESC"] = "Saniyedeki Hasarı ve Saniyedeki İyileştirmeyi göster."
L["STRING_OPTIONS_TEXT_SHOW_SEPARATOR"] = "Ayırıcı"
L["STRING_OPTIONS_TEXT_SHOW_SEPARATOR_DESC"] = "Saniyede miktarını yüzde miktarından ayırmak için hangi karakterin kullanılacağını seç."
L["STRING_OPTIONS_TEXT_SHOW_TOTAL"] = "Toplamı Göster"
L["STRING_OPTIONS_TEXT_SHOW_TOTAL_DESC"] = [=[Birimin yaptığı toplamı göster.

Örneğin: toplam hasar, alınan toplam iyileştirme.]=]
L["STRING_OPTIONS_TEXT_SIZE"] = "Yazı Boyutu"
L["STRING_OPTIONS_TEXT_SIZE_DESC"] = "Sol ve sağ yazıların boyutunu değiştir."
L["STRING_OPTIONS_TEXT_TEXTUREL_ANCHOR"] = "Arka Plan:"
L["STRING_OPTIONS_TEXT_TEXTUREU_ANCHOR"] = "Görünüm:"
L["STRING_OPTIONS_TEXTEDITOR_CANCEL"] = "İptal"
L["STRING_OPTIONS_TEXTEDITOR_CANCEL_TOOLTIP"] = "Düzenlemeyi bitir ve koddaki değişiklikleri yok say."
L["STRING_OPTIONS_TEXTEDITOR_COLOR_TOOLTIP"] = "Seçili yazının rengini değiştirmek için yazıyı seç, sonra renk düğmesine tıkla."
L["STRING_OPTIONS_TEXTEDITOR_COMMA"] = "Virgül"
L["STRING_OPTIONS_TEXTEDITOR_COMMA_TOOLTIP"] = [=[Sayıları virgülle ayırarak biçimlendiren bir işlev ekle.
Örnek: 1000000 -> 1.000.000.]=]
L["STRING_OPTIONS_TEXTEDITOR_DATA"] = "[Veri %s]"
L["STRING_OPTIONS_TEXTEDITOR_DATA_TOOLTIP"] = [=[Bir veri akışı ekle:

|cFFFFFF00Veri 1|r: normalde birimin yaptığı toplamı ya da sıra numarasını gösterir.

|cFFFFFF00Veri 2|r: çoğu durumda DPS'i, HPS'i ya da oyuncunun adını gösterir.

|cFFFFFF00Veri 3|r: birimin yaptığı yüzdeyi, uzmanlık ya da fraksiyon simgesini gösterir.]=]
L["STRING_OPTIONS_TEXTEDITOR_DONE"] = "Bitti"
L["STRING_OPTIONS_TEXTEDITOR_DONE_TOOLTIP"] = "Düzenlemeyi bitir ve kodu kaydet."
L["STRING_OPTIONS_TEXTEDITOR_FUNC"] = "İşlev"
L["STRING_OPTIONS_TEXTEDITOR_FUNC_TOOLTIP"] = [=[Boş bir işlev ekle.
İşlevler her zaman bir sayı döndürmelidir.]=]
L["STRING_OPTIONS_TEXTEDITOR_RESET"] = "Sıfırla"
L["STRING_OPTIONS_TEXTEDITOR_RESET_TOOLTIP"] = "Tüm kodu sil ve varsayılan kodu ekle."
L["STRING_OPTIONS_TEXTEDITOR_TOK"] = "ToK"
L["STRING_OPTIONS_TEXTEDITOR_TOK_TOOLTIP"] = [=[Sayıları kısaltarak biçimlendiren bir işlev ekle.
Örnek: 1500000 -> 1.5kk.]=]
L["STRING_OPTIONS_TIMEMEASURE"] = "Süre Ölçümü"
L["STRING_OPTIONS_TIMEMEASURE_DESC"] = [=[|cFFFFFF00Etkinlik|r: her raid üyesinin sayacı etkinliği durunca bekletilir, yeniden başlayınca saymaya devam eder; DPS ve HPS ölçmenin yaygın yolu.

|cFFFFFF00Etkin|r: sıralamalarda kullanılır; tüm raid üyelerinin DPS ve HPS'ini ölçmek için geçen savaş süresini kullanır.]=]
L["STRING_OPTIONS_TITLEBAR_MENUBUTTONS_HEADER"] = "Düğme ve Menü Ayarları"
L["STRING_OPTIONS_TOOLBAR_SETTINGS"] = "Başlık Çubuğu Düğme Ayarları"
L["STRING_OPTIONS_TOOLBAR_SETTINGS_DESC"] = "Bu seçenekler pencerenin üstündeki ana menüyü değiştirir."
L["STRING_OPTIONS_TOOLBARSIDE"] = "Başlık Çubuğu Üstte"
L["STRING_OPTIONS_TOOLBARSIDE_DESC"] = [=[Başlık çubuğunu pencerenin üstüne yerleştirir.

|cFFFFFF00Önemli|r: konumu değiştirince başlık yazısı değişmez; daha fazla seçenek için |cFFFFFF00Başlık Çubuğu: Yazı|r bölümüne bak.]=]
L["STRING_OPTIONS_TOOLS_ANCHOR"] = "Araçlar:"
L["STRING_OPTIONS_TOOLTIP_ANCHOR"] = "Ayarlar:"
L["STRING_OPTIONS_TOOLTIP_ANCHORTEXTS"] = "Yazılar:"
L["STRING_OPTIONS_TOOLTIPS_ABBREVIATION"] = "Kısaltma Türü"
L["STRING_OPTIONS_TOOLTIPS_ABBREVIATION_DESC"] = "İpuçlarında gösterilen sayıların nasıl biçimleneceğini seç."
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_ATTACH"] = "İpucu Tarafı"
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_ATTACH_DESC"] = "İpucunun hangi tarafının sabitleme tarafına oturacağı."
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_BORDER"] = "Kenarlık:"
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_POINT"] = "Sabitleme:"
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_RELATIVE"] = "Sabitleme Tarafı"
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_RELATIVE_DESC"] = "İpucunun sabitlemenin hangi tarafına yerleştirileceği."
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_TEXT"] = "İpucu Sabitlemesi"
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_TEXT_DESC"] = "kilitlemek için sağ tıkla."
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_TO"] = "Bağlantı"
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_TO_CHOOSE"] = "Sabitleme Noktasını Taşı"
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_TO_CHOOSE_DESC"] = "Sabitleme |cFFFFFF00Ekrandaki Nokta|r olarak ayarlıyken sabitleme konumunu taşı."
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_TO_DESC"] = "İpuçları üzerine gelinen satıra ya da oyun ekranında seçilen bir noktaya tutturulur."
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_TO1"] = "Pencere Satırı"
L["STRING_OPTIONS_TOOLTIPS_ANCHOR_TO2"] = "Ekrandaki Nokta"
L["STRING_OPTIONS_TOOLTIPS_ANCHORCOLOR"] = "başlık"
L["STRING_OPTIONS_TOOLTIPS_BACKGROUNDCOLOR"] = "Arka Plan Rengi"
L["STRING_OPTIONS_TOOLTIPS_BACKGROUNDCOLOR_DESC"] = "Arka planda kullanılan rengi seç."
L["STRING_OPTIONS_TOOLTIPS_BORDER_COLOR_DESC"] = "Kenarlık rengini değiştir."
L["STRING_OPTIONS_TOOLTIPS_BORDER_SIZE_DESC"] = "Kenarlık boyutunu değiştir."
L["STRING_OPTIONS_TOOLTIPS_BORDER_TEXTURE_DESC"] = "Kenarlık doku dosyasını değiştir."
L["STRING_OPTIONS_TOOLTIPS_DISABLE"] = "İpuçlarını Kapat"
L["STRING_OPTIONS_TOOLTIPS_DISABLE_DESC"] = "Seçili pencerede ipuçlarını kapat."
L["STRING_OPTIONS_TOOLTIPS_FONTCOLOR"] = "Yazı Rengi"
L["STRING_OPTIONS_TOOLTIPS_FONTCOLOR_DESC"] = "İpucu yazılarında kullanılan rengi değiştir."
--[[Translation missing --]]
L["STRING_OPTIONS_TOOLTIPS_FONTFACE"] = ""
L["STRING_OPTIONS_TOOLTIPS_FONTFACE_DESC"] = "İpucu yazılarında kullanılan yazı tipini seç."
L["STRING_OPTIONS_TOOLTIPS_FONTSHADOW_DESC"] = "Yazıda dış çizgi göster."
--[[Translation missing --]]
L["STRING_OPTIONS_TOOLTIPS_FONTSIZE"] = ""
L["STRING_OPTIONS_TOOLTIPS_FONTSIZE_DESC"] = "İpucu yazılarının boyutunu artır ya da azalt"
L["STRING_OPTIONS_TOOLTIPS_IGNORESUBWALLPAPER"] = "Alt Menü Duvar Kâğıdı"
L["STRING_OPTIONS_TOOLTIPS_IGNORESUBWALLPAPER_DESC"] = "Açıksa bazı menüler alt menülerinde kendi duvar kâğıdını kullanabilir."
L["STRING_OPTIONS_TOOLTIPS_MAXIMIZE"] = "Büyütme Yöntemi"
L["STRING_OPTIONS_TOOLTIPS_MAXIMIZE_DESC"] = [=[İpucunda gösterilen bilgiyi genişletmek için kullanılan yöntemi seç.

|cFFFFFF00 Kontrol Tuşlarıyla|r: Shift, Ctrl ya da Alt tuşuna basılınca ipucu kutusu genişler.

|cFFFFFF00 Her Zaman Büyük|r: ipucu her zaman hiçbir sınır olmadan tüm bilgiyi gösterir.

|cFFFFFF00 Yalnızca Shift Bloğu|r: ipucundaki ilk blok varsayılan olarak hep genişletilir.

|cFFFFFF00 Yalnızca Ctrl Bloğu|r: ikinci blok varsayılan olarak hep genişletilir.

|cFFFFFF00 Yalnızca Alt Bloğu|r: üçüncü blok varsayılan olarak hep genişletilir.]=]
L["STRING_OPTIONS_TOOLTIPS_MAXIMIZE1"] = "Shift Ctrl Alt ile"
L["STRING_OPTIONS_TOOLTIPS_MAXIMIZE2"] = "Her Zaman Büyük"
L["STRING_OPTIONS_TOOLTIPS_MAXIMIZE3"] = "Yalnızca Shift Engeli"
L["STRING_OPTIONS_TOOLTIPS_MAXIMIZE4"] = "Yalnızca Ctrl Engeli"
L["STRING_OPTIONS_TOOLTIPS_MAXIMIZE5"] = "Yalnızca Alt Engeli"
L["STRING_OPTIONS_TOOLTIPS_MENU_WALLP"] = "Menü Duvar Kâğıdını Düzenle"
L["STRING_OPTIONS_TOOLTIPS_MENU_WALLP_DESC"] = "Başlık çubuğu menülerinin duvar kâğıdının görünümünü değiştir."
L["STRING_OPTIONS_TOOLTIPS_OFFSETX"] = "X Uzaklığı"
L["STRING_OPTIONS_TOOLTIPS_OFFSETX_DESC"] = "İpucunun sabitlemesinden yatay olarak ne kadar uzağa yerleştirileceği."
L["STRING_OPTIONS_TOOLTIPS_OFFSETY"] = "Y Uzaklığı"
L["STRING_OPTIONS_TOOLTIPS_OFFSETY_DESC"] = "İpucunun sabitlemesinden dikey olarak ne kadar uzağa yerleştirileceği."
L["STRING_OPTIONS_TOOLTIPS_SHOWAMT"] = "Miktarı Göster"
L["STRING_OPTIONS_TOOLTIPS_SHOWAMT_DESC"] = "İpucunda kaç büyü, hedef ve pet olduğunu gösteren bir sayı gösterir."
L["STRING_OPTIONS_TOOLTIPS_TITLE"] = "İpuçları"
L["STRING_OPTIONS_TOOLTIPS_TITLE_DESC"] = "Bu seçenekler ipuçlarının görünümünü denetler."
L["STRING_OPTIONS_TOTALBAR_ANCHOR"] = "Toplam Çubuğu"
L["STRING_OPTIONS_TRASH_SUPPRESSION"] = "Trash Bastırma"
L["STRING_OPTIONS_TRASH_SUPPRESSION_DESC"] = "|cFFFFFF00X|r saniye boyunca trash bölümlerini göstermek için otomatik geçişi engelle (|cFFFFFF00yalnızca bir boss karşılaşması yenildikten sonra|r)."
L["STRING_OPTIONS_WALLPAPER_ALPHA"] = "Saydamlık:"
L["STRING_OPTIONS_WALLPAPER_ANCHOR"] = "Duvar Kâğıdı Seçimi:"
L["STRING_OPTIONS_WALLPAPER_BLUE"] = "Mavi:"
L["STRING_OPTIONS_WALLPAPER_CBOTTOM"] = "Kırp (|cFFC0C0C0alt|r):"
L["STRING_OPTIONS_WALLPAPER_CLEFT"] = "Kırp (|cFFC0C0C0sol|r):"
L["STRING_OPTIONS_WALLPAPER_CRIGHT"] = "Kırp (|cFFC0C0C0sağ|r):"
L["STRING_OPTIONS_WALLPAPER_CTOP"] = "Kırp (|cFFC0C0C0üst|r):"
L["STRING_OPTIONS_WALLPAPER_FILE"] = "Dosya:"
L["STRING_OPTIONS_WALLPAPER_GREEN"] = "Yeşil:"
L["STRING_OPTIONS_WALLPAPER_LOAD"] = "Görsel Yükle"
L["STRING_OPTIONS_WALLPAPER_LOAD_DESC"] = "Duvar kâğıdı olarak kullanmak için sabit diskinden bir görsel seç."
L["STRING_OPTIONS_WALLPAPER_LOAD_EXCLAMATION"] = [=[Görsel nasıl yüklenir:

- Genişlik ve yükseklik 128, 256 ya da 512 piksel olmalı (örneğin 512 x 256).
- Görseli WOW/_retail_/Interface/ klasörüne .TGA olarak kaydet.
- Oyunu kapatıp yeniden aç.]=]
L["STRING_OPTIONS_WALLPAPER_LOAD_FILENAME"] = "Dosya Adı:"
L["STRING_OPTIONS_WALLPAPER_LOAD_FILENAME_DESC"] = "Yalnızca dosyanın adını yaz; yolu ve uzantıyı yazma."
L["STRING_OPTIONS_WALLPAPER_LOAD_OKEY"] = "Yükle"
L["STRING_OPTIONS_WALLPAPER_LOAD_TITLE"] = "Özel Duvar Kâğıdın"
L["STRING_OPTIONS_WALLPAPER_LOAD_TROUBLESHOOT"] = "Sorun Giderme"
L["STRING_OPTIONS_WALLPAPER_LOAD_TROUBLESHOOT_TEXT"] = [=[Duvar kâğıdı tamamen yeşil görünüyorsa:

- WoW istemcisini yeniden başlat.
- Görselin 256 genişliğinde ve 256 yüksekliğinde olduğundan emin ol.
- Görselin .TGA biçiminde ve 32 bit/piksel olarak kaydedildiğini kontrol et.
- Interface klasörünün içinde mi, örneğin: C:/Program Files/World of Warcraft/_retail_/Interface/]=]
L["STRING_OPTIONS_WALLPAPER_RED"] = "Kırmızı:"
L["STRING_OPTIONS_WC_ANCHOR"] = "Hızlı Pencere Kontrolü (#%s):"
L["STRING_OPTIONS_WC_BOOKMARK"] = "Yer İmlerini Yönet"
L["STRING_OPTIONS_WC_BOOKMARK_DESC"] = "Yer imleri için ayar panelini aç."
L["STRING_OPTIONS_WC_CLOSE"] = "Kapat"
L["STRING_OPTIONS_WC_CLOSE_DESC"] = [=[Pencereyi kapat.

Kapatılınca pencere etkin değil sayılır ve Pencere Kontrolü menüsüyle her zaman yeniden açılabilir.

|cFFFFFF00Önemli:|r bir pencereyi tamamen kaldırmak için 'Pencere Gövdesi' bölümüne git.]=]
L["STRING_OPTIONS_WC_CREATE"] = "Pencere Oluştur"
L["STRING_OPTIONS_WC_CREATE_DESC"] = "Yeni bir pencere oluştur."
L["STRING_OPTIONS_WC_LOCK"] = "Kilitle"
L["STRING_OPTIONS_WC_LOCK_DESC"] = [=[Pencereyi kilitle ya da kilidini aç.

Kilitliyken pencere taşınamaz.]=]
L["STRING_OPTIONS_WC_REOPEN"] = "Yeniden Aç"
L["STRING_OPTIONS_WC_UNLOCK"] = "Kilidi Aç"
L["STRING_OPTIONS_WC_UNSNAP"] = "Gruptan Ayır"
L["STRING_OPTIONS_WC_UNSNAP_DESC"] = "Bu pencereyi pencere grubundan çıkar."
L["STRING_OPTIONS_WHEEL_SPEED"] = "Tekerlek Hızı"
L["STRING_OPTIONS_WHEEL_SPEED_DESC"] = "Fare tekerleğini bir pencerenin üzerinde çevirince kaydırmanın ne kadar hızlı olacağını değiştirir."
L["STRING_OPTIONS_WINDOW"] = "Ayarlar Paneli"
L["STRING_OPTIONS_WINDOW_ANCHOR_ANCHORS"] = "Sabitlemeler:"
L["STRING_OPTIONS_WINDOW_IGNOREMASSTOGGLE"] = "Toplu Aç/Kapat'ı Yok Say"
L["STRING_OPTIONS_WINDOW_IGNOREMASSTOGGLE_DESC"] = "Açıksa tüm pencereler gizlenirken, gösterilirken ya da açılıp kapatılırken bu pencere etkilenmez."
L["STRING_OPTIONS_WINDOW_ROWAREA_COLOR"] = "\"Satır Alanı Rengi\""
L["STRING_OPTIONS_WINDOW_ROWAREA_COLOR_DESC"] = "Satırlar gösterilirken alanın arka plan rengini ayarla."
L["STRING_OPTIONS_WINDOW_SCALE"] = "Ölçek"
L["STRING_OPTIONS_WINDOW_SCALE_DESC"] = [=[Pencerenin ölçeğini ayarla.

|cFFFFFF00İpucu|r: değeri yazmak için sağ tıkla.]=]
L["STRING_OPTIONS_WINDOW_SKIN_COLOR"] = "Görünüm Rengi"
L["STRING_OPTIONS_WINDOW_SKIN_COLOR_DESC"] = [=[Bu pencereye uygulanan görünümün rengini değiştirir.

|cFFFFFF00Önemli|r: açıksa burada seçilen saydamlığın yerine |cFFFFFF00Otomatik Saydamlık|r değerleri geçer.

|cFFFFFF00Önemli|r: görünüm rengini seçmek durum çubuğuna uygulanan renk özelleştirmesinin yerine geçer.]=]
L["STRING_OPTIONS_WINDOW_TITLE"] = "Genel Pencere Ayarları"
L["STRING_OPTIONS_WINDOW_TITLE_DESC"] = "Bu seçenekler seçili pencerenin görünümünü denetler."
L["STRING_OPTIONS_WINDOWSPEED"] = "Güncelleme Aralığı"
L["STRING_OPTIONS_WINDOWSPEED_DESC"] = [=[Her güncelleme arasındaki süre.

|cFFFFFF000.05|r: gerçek zamanlı güncelleme.

|cFFFFFF000.3|r: saniyede yaklaşık 3 kez güncelle.

|cFFFFFF003.0|r: 3 saniyede bir güncelle.]=]
L["STRING_OPTIONS_WP"] = "Duvar Kâğıdı Ayarları"
L["STRING_OPTIONS_WP_ALIGN"] = "Hizala"
L["STRING_OPTIONS_WP_ALIGN_DESC"] = [=[Duvar kâğıdının pencere içinde nasıl hizalanacağı.

- |cFFFFFF00Doldur|r: otomatik boyutlanır ve tüm köşelere hizalanır.

- |cFFFFFF00Orta|r: boyutlanmaz ve pencerenin ortasına hizalanır.

-|cFFFFFF00Uzat|r: dikey ya da yatay olarak otomatik boyutlanır ve sol-sağ ya da üst-alt kenarlara hizalanır.

-|cFFFFFF00Dört Köşe|r: belirtilen köşeye hizalanır, otomatik boyutlanmaz.]=]
L["STRING_OPTIONS_WP_DESC"] = "Bu seçenekler pencerenin duvar kâğıdını denetler."
L["STRING_OPTIONS_WP_EDIT"] = "Görseli Düzenle"
L["STRING_OPTIONS_WP_EDIT_DESC"] = "Seçili görselin bazı özelliklerini değiştirmek için görsel düzenleyiciyi aç."
L["STRING_OPTIONS_WP_ENABLE_DESC"] = "Duvar kâğıdını göster."
L["STRING_OPTIONS_WP_GROUP"] = "Kategori"
L["STRING_OPTIONS_WP_GROUP_DESC"] = "Görsel grubunu seç."
L["STRING_OPTIONS_WP_GROUP2"] = "Duvar Kâğıdı"
L["STRING_OPTIONS_WP_GROUP2_DESC"] = "Duvar kâğıdı olarak kullanılacak görsel."
L["STRING_OPTIONSMENU_AUTOMATIC"] = "Otomasyon"
L["STRING_OPTIONSMENU_AUTOMATIC_TITLE"] = "Pencere Otomasyon Ayarları"
L["STRING_OPTIONSMENU_AUTOMATIC_TITLE_DESC"] = "Bu ayarlar pencerenin otomatik gizleme ve otomatik geçiş gibi otomatik davranışlarını denetler."
L["STRING_OPTIONSMENU_COMBAT"] = "PvE PvP"
L["STRING_OPTIONSMENU_DATACHART"] = "Grafik Verileri"
L["STRING_OPTIONSMENU_DATACOLLECT"] = "Veri Toplayıcı"
L["STRING_OPTIONSMENU_DATAFEED"] = "Veri Akışı"
L["STRING_OPTIONSMENU_DESIGNER"] = "Tasarımcı"
L["STRING_OPTIONSMENU_DISPLAY"] = "Görünüm"
L["STRING_OPTIONSMENU_DISPLAY_DESC"] = "Genel temel ayarlar ve hızlı pencere kontrolü."
L["STRING_OPTIONSMENU_LEFTMENU"] = "Başlık Çubuğu"
L["STRING_OPTIONSMENU_MISC"] = "Çeşitli"
L["STRING_OPTIONSMENU_PERFORMANCE"] = "Performans Ayarları"
L["STRING_OPTIONSMENU_PLUGINS"] = "Eklentiler"
L["STRING_OPTIONSMENU_PROFILES"] = "Profiller"
L["STRING_OPTIONSMENU_RAIDTOOLS"] = "Raid Araçları"
L["STRING_OPTIONSMENU_RIGHTMENU"] = "-- x -- x --"
L["STRING_OPTIONSMENU_ROWMODELS"] = "Çubuklar: Gelişmiş"
L["STRING_OPTIONSMENU_ROWSETTINGS"] = "Çubuklar: Genel"
L["STRING_OPTIONSMENU_ROWTEXTS"] = "Çubuklar: Yazılar"
L["STRING_OPTIONSMENU_SKIN"] = "Görünümler"
L["STRING_OPTIONSMENU_SPELLS"] = "Büyüleri Yeniden Adlandır"
L["STRING_OPTIONSMENU_SPELLS_CONSOLIDATE"] = "Aynı Adlı Büyüleri Birleştir"
L["STRING_OPTIONSMENU_TITLEBAR"] = "Başlık Çubuğu"
L["STRING_OPTIONSMENU_TITLETEXT"] = "Başlık Çubuğu: Yazı"
L["STRING_OPTIONSMENU_TOOLTIP"] = "İpuçları"
L["STRING_OPTIONSMENU_WALLPAPER"] = "Duvar Kâğıdı"
L["STRING_OPTIONSMENU_WINDOW"] = "Pencere: Genel"
L["STRING_OPTIONSMENU_WINDOWBODY"] = "Pencere Gövdesi"
L["STRING_OR"] = "Ya da"
L["STRING_OVERALL"] = "Genel"
L["STRING_OVERHEAL"] = "Fazla İyileştirme"
L["STRING_OVERHEALED"] = "Fazla İyileştirildi"
L["STRING_PARRY"] = "Savuşturma"
L["STRING_PERCENTAGE"] = "Yüzde"
L["STRING_PET"] = "Pet"
L["STRING_PETS"] = "Petler"
L["STRING_PLAYER_DETAILS"] = "Oyuncu Details! Dökümü"
L["STRING_PLAYERS"] = "Oyuncular"
L["STRING_PLEASE_WAIT"] = "Lütfen bekle"
L["STRING_PLUGIN_CLEAN"] = "Yok"
L["STRING_PLUGIN_CLOCKNAME"] = "Karşılaşma Süresi"
L["STRING_PLUGIN_CLOCKTYPE"] = "Saat Türü"
L["STRING_PLUGIN_DURABILITY"] = "Dayanıklılık"
L["STRING_PLUGIN_FPS"] = "Kare Hızı"
L["STRING_PLUGIN_GOLD"] = "Altın"
L["STRING_PLUGIN_LATENCY"] = "Gecikme"
L["STRING_PLUGIN_MINSEC"] = "Dakika ve Saniye"
L["STRING_PLUGIN_NAMEALREADYTAKEN"] = "Details! eklentiyi kuramıyor çünkü bu ad zaten alınmış"
L["STRING_PLUGIN_PATTRIBUTENAME"] = "Özellik"
L["STRING_PLUGIN_PDPSNAME"] = "Raid DPS"
L["STRING_PLUGIN_PSEGMENTNAME"] = "Bölüm"
L["STRING_PLUGIN_SECONLY"] = "Yalnızca Saniye"
L["STRING_PLUGIN_SEGMENTTYPE"] = "Bölüm Türü"
L["STRING_PLUGIN_SEGMENTTYPE_1"] = "Dövüş #X"
L["STRING_PLUGIN_SEGMENTTYPE_2"] = "Karşılaşma Adı"
L["STRING_PLUGIN_SEGMENTTYPE_3"] = "Karşılaşma Adı ve Bölüm"
L["STRING_PLUGIN_THREATNAME"] = "Tehdidim"
L["STRING_PLUGIN_TIME"] = "Saat"
L["STRING_PLUGIN_TIMEDIFF"] = "Son Savaş Farkı"
L["STRING_PLUGIN_TOOLTIP_LEFTBUTTON"] = "Geçerli eklentiyi ayarla"
L["STRING_PLUGIN_TOOLTIP_RIGHTBUTTON"] = "Başka bir eklenti seç"
L["STRING_PLUGINOPTIONS_ABBREVIATE"] = "Kısalt"
L["STRING_PLUGINOPTIONS_COMMA"] = "Virgül"
L["STRING_PLUGINOPTIONS_FONTFACE"] = "Yazı Tipi Seç"
L["STRING_PLUGINOPTIONS_NOFORMAT"] = "Yok"
L["STRING_PLUGINOPTIONS_TEXTALIGN"] = "Yazı Hizası"
L["STRING_PLUGINOPTIONS_TEXTALIGN_X"] = "Yazı Hizası X"
L["STRING_PLUGINOPTIONS_TEXTALIGN_Y"] = "Yazı Hizası Y"
L["STRING_PLUGINOPTIONS_TEXTCOLOR"] = "Yazı Rengi"
L["STRING_PLUGINOPTIONS_TEXTSIZE"] = "Yazı Boyutu"
L["STRING_PLUGINOPTIONS_TEXTSTYLE"] = "Yazı Stili"
L["STRING_QUERY_INSPECT"] = "yetenekleri ve eşya seviyesini al."
L["STRING_QUERY_INSPECT_FAIL1"] = "savaştayken sorgulanamaz."
L["STRING_QUERY_INSPECT_REFRESH"] = "yenileme gerekli"
L["STRING_RAID_WIDE"] = "[*] raid geneli bekleme süresi"
L["STRING_RAIDCHECK_PLUGIN_DESC"] = "Raid zindanındayken Details! başlık çubuğunda iksir, yiyecek ve savaş öncesi iksir kullanımını gösteren simge gösterir."
L["STRING_RAIDCHECK_PLUGIN_NAME"] = "Raid Kontrolü"
L["STRING_RECENT_PLAYERS"] = "Son Oyuncular:"
L["STRING_REPORT"] = "için"
L["STRING_REPORT_BUTTON_TOOLTIP"] = "Rapor Penceresini açmak için tıkla"
L["STRING_REPORT_FIGHT"] = "dövüş"
L["STRING_REPORT_FIGHTS"] = "dövüş"
L["STRING_REPORT_INVALIDTARGET"] = "Fısıltı hedefi bulunamadı"
L["STRING_REPORT_LAST"] = "Son"
L["STRING_REPORT_LASTFIGHT"] = "son dövüş"
L["STRING_REPORT_LEFTCLICK"] = "Rapor penceresini açmak için tıkla"
L["STRING_REPORT_PREVIOUSFIGHTS"] = "önceki dövüşler"
L["STRING_REPORT_SINGLE_BUFFUPTIME"] = "buff süresi:"
L["STRING_REPORT_SINGLE_COOLDOWN"] = "şunun kullandığı bekleme süreleri:"
L["STRING_REPORT_SINGLE_DEATH"] = "Ölüm:"
L["STRING_REPORT_SINGLE_DEBUFFUPTIME"] = "debuff süresi:"
L["STRING_REPORT_TEXT"] = "Rapor"
L["STRING_REPORT_TOOLTIP"] = "Sonuçları Raporla"
L["STRING_REPORTFRAME_COPY"] = "Kopyala ve Yapıştır"
L["STRING_REPORTFRAME_CURRENT"] = "Güncel"
L["STRING_REPORTFRAME_CURRENTINFO"] = "Yalnızca şu anda gösterilen verileri göster (destekleniyorsa)."
L["STRING_REPORTFRAME_GUILD"] = "Lonca"
L["STRING_REPORTFRAME_INSERTNAME"] = "oyuncu adını gir"
L["STRING_REPORTFRAME_LINES"] = "Satırlar"
L["STRING_REPORTFRAME_OFFICERS"] = "Subay Kanalı"
L["STRING_REPORTFRAME_PARTY"] = "Grup"
L["STRING_REPORTFRAME_RAID"] = "Raid"
L["STRING_REPORTFRAME_REVERT"] = "Ters"
L["STRING_REPORTFRAME_REVERTED"] = "ters"
L["STRING_REPORTFRAME_REVERTINFO"] = "artan sırada gönder."
L["STRING_REPORTFRAME_SAY"] = "Söyle"
L["STRING_REPORTFRAME_SEND"] = "Gönder"
L["STRING_REPORTFRAME_WHISPER"] = "Fısılda"
L["STRING_REPORTFRAME_WHISPERTARGET"] = "Fısıltı Hedefi"
L["STRING_REPORTFRAME_WINDOW_TITLE"] = "Details! Bağlantısı"
L["STRING_REPORTHISTORY"] = "Son Raporlar"
L["STRING_RESISTED"] = "Direnildi"
L["STRING_RESIZE_ALL"] = "Tüm pencereleri serbestçe boyutlandır"
L["STRING_RESIZE_COMMON"] = [=[Boyutlandır
]=]
L["STRING_RESIZE_HORIZONTAL"] = [=[Gruptaki tüm pencerelerin
 genişliğini boyutlandır]=]
L["STRING_RESIZE_VERTICAL"] = [=[Gruptaki tüm pencerelerin
 yüksekliğini boyutlandır]=]
L["STRING_RIGHT"] = "sağ"
L["STRING_RIGHT_TO_LEFT"] = "Sağdan Sola"
L["STRING_RIGHTCLICK_CLOSE_LARGE"] = "Bu pencereyi kapatmak için farenin sağ tuşuyla tıkla."
L["STRING_RIGHTCLICK_CLOSE_MEDIUM"] = "Bu pencereyi kapatmak için sağ tıkla."
L["STRING_RIGHTCLICK_CLOSE_SHORT"] = "Kapatmak için sağ tıkla."
L["STRING_RIGHTCLICK_TYPEVALUE"] = "değeri yazmak için sağ tıkla"
L["STRING_SCORE_BEST"] = "|cFFFFFF00%s|r puan aldın, bu en iyi puanın, tebrikler!"
L["STRING_SCORE_NOTBEST"] = "|cFFFFFF00%s|r puan aldın, en iyi puanın %s tarihinde %d eşya seviyesiyle aldığın |cFFFFFF00%s|r."
L["STRING_SCRIPTS_TITLE"] = "Betikler"
L["STRING_SEE_BELOW"] = "aşağıya bak"
L["STRING_SEGMENT"] = "Bölüm"
L["STRING_SEGMENT_EMPTY"] = "bu bölüm boş"
L["STRING_SEGMENT_END"] = "Son"
L["STRING_SEGMENT_ENEMY"] = "Düşman"
L["STRING_SEGMENT_LOWER"] = "bölüm"
L["STRING_SEGMENT_OVERALL"] = "Genel Veri"
L["STRING_SEGMENT_START"] = "Başlangıç"
L["STRING_SEGMENT_TRASH"] = "Trash Temizliği"
L["STRING_SEGMENTS"] = "Bölümler"
L["STRING_SEGMENTS_LIST_BOSS"] = "boss dövüşü"
L["STRING_SEGMENTS_LIST_COMBATTIME"] = "Savaş Süresi"
L["STRING_SEGMENTS_LIST_OVERALL"] = "genel"
L["STRING_SEGMENTS_LIST_TIMEINCOMBAT"] = "Savaşta Geçen Süre"
L["STRING_SEGMENTS_LIST_TOTALTIME"] = "Toplam Süre"
L["STRING_SEGMENTS_LIST_TRASH"] = "trash"
L["STRING_SEGMENTS_LIST_WASTED_TIME"] = "Savaşta Değil"
L["STRING_SHIELD_HEAL"] = "Önlendi"
L["STRING_SHIELD_OVERHEAL"] = "Boşa Giden"
L["STRING_SHORTCUT_RIGHTCLICK"] = "kapatmak için sağ tıkla"
L["STRING_SIMPLE_TEXT_FORMAT"] = "Basit Yazı Biçimi Kullan"
--[[Translation missing --]]
L["STRING_SIMPLE_TEXT_FORMAT_ASLIGNED"] = ""
--[[Translation missing --]]
L["STRING_SIMPLE_TEXT_FORMAT_ASLIGNED_DESC"] = ""
L["STRING_SIMPLE_TEXT_FORMAT_ASLIGNED_SPACE_BETWEEN"] = "Sütun Aralığı"
L["STRING_SIMPLE_TEXT_FORMAT_DESC"] = "Aşağıdaki üç kuralın kullanımını açar."
--[[Translation missing --]]
L["STRING_SIMPLE_TEXT_FORMAT_TEMPLATE2"] = ""
--[[Translation missing --]]
L["STRING_SIMPLE_TEXT_FORMAT_TEMPLATE3"] = ""
--[[Translation missing --]]
L["STRING_SIMPLE_TEXT_FORMAT_TEMPLATE4"] = ""
--[[Translation missing --]]
L["STRING_SIMPLE_TEXT_FORMAT_TEMPLATE5"] = ""
--[[Translation missing --]]
L["STRING_SIMPLE_TEXT_FORMAT_TEMPLATE6"] = ""
L["STRING_SIMPLE_TEXT_FORMAT_TITLE"] = "Midnight Sağ Yazı: Basit ya da Hizalı"
L["STRING_SIMPLE_TEXT_FORMAT_TYPE1"] = [=[Satırda toplam ve yüzde
bilgisi olduğunda.
|cFFAAAAAA%s sırası: toplam, yüzde.]=]
L["STRING_SIMPLE_TEXT_FORMAT_TYPE2"] = [=[Satırda toplam ve saniyede
bilgisi olduğunda.
|cFFAAAAAA%s sırası: toplam, saniyede.]=]
L["STRING_SIMPLE_TEXT_FORMAT_TYPE3"] = [=[Satırda toplam, saniyede ve yüzde
bilgisi olduğunda.
|cFFAAAAAA%s sırası: toplam, saniyede, yüzde.]=]
L["STRING_SLASH_API_DESC"] = "eklenti, özel görünüm, aura vb. oluşturmak için API panelini aç."
L["STRING_SLASH_CAPTURE_DESC"] = "tüm veri yakalamayı aç ya da kapat."
L["STRING_SLASH_CAPTUREOFF"] = "tüm veri yakalama kapatıldı."
L["STRING_SLASH_CAPTUREON"] = "tüm veri yakalama açıldı."
L["STRING_SLASH_CHANGES"] = "updates"
L["STRING_SLASH_CHANGES_ALIAS1"] = "news"
L["STRING_SLASH_CHANGES_ALIAS2"] = "changes"
L["STRING_SLASH_CHANGES_DESC"] = "Details!'teki yenilikleri ve değişiklikleri gösterir."
L["STRING_SLASH_DISABLE"] = "disable"
L["STRING_SLASH_ENABLE"] = "enable"
L["STRING_SLASH_HIDE"] = "hide"
L["STRING_SLASH_HIDE_ALIAS1"] = "close"
L["STRING_SLASH_HISTORY"] = "history"
L["STRING_SLASH_NEW"] = "new"
L["STRING_SLASH_NEW_DESC"] = "yeni bir pencere oluştur."
L["STRING_SLASH_OPTIONS"] = "options"
L["STRING_SLASH_OPTIONS_DESC"] = "ayarlar panelini aç."
L["STRING_SLASH_RESET"] = "reset"
L["STRING_SLASH_RESET_ALIAS1"] = "clear"
L["STRING_SLASH_RESET_DESC"] = "tüm bölümleri temizle."
L["STRING_SLASH_SHOW"] = "show"
L["STRING_SLASH_SHOW_ALIAS1"] = "open"
L["STRING_SLASH_SHOWHIDETOGGLE_DESC"] = "<pencere numarası> verilmezse tüm pencereler."
L["STRING_SLASH_TOGGLE"] = "toggle"
L["STRING_SLASH_WIPE"] = "wipe"
L["STRING_SLASH_WIPECONFIG"] = "reinstall"
L["STRING_SLASH_WIPECONFIG_CONFIRM"] = "Yeniden Kuruluma Devam Etmek İçin Tıkla"
L["STRING_SLASH_WIPECONFIG_DESC"] = "tüm ayarları varsayılana döndür; Details! düzgün çalışmıyorsa kullan."
L["STRING_SLASH_WORLDBOSS"] = "worldboss"
L["STRING_SLASH_WORLDBOSS_DESC"] = "bu hafta hangi boss'ları öldürdüğünü gösteren bir makro çalıştır."
L["STRING_SPELL_INTERRUPTED"] = "Kesilen büyüler"
L["STRING_SPELLLIST"] = "Büyü Listesi"
L["STRING_SPELLS"] = "Büyüler"
L["STRING_SPIRIT_LINK_TOTEM"] = "Can Değişimi"
L["STRING_SPIRIT_LINK_TOTEM_DESC"] = [=[Totemin çemberi içindeki oyuncular
arasında değiştirilen can miktarı.

Bu iyileştirme oyuncunun yaptığı
toplam iyileştirmeye eklenmez.]=]
L["STRING_STATISTICS"] = "İstatistikler"
L["STRING_STATUSBAR_NOOPTIONS"] = "Bu bileşenin seçeneği yok."
L["STRING_SWITCH_CLICKME"] = "yer imi ekle"
L["STRING_SWITCH_SELECTMSG"] = "Yer İmi #%d için görünümü seç."
L["STRING_SWITCH_TO"] = "Şuna Geç"
L["STRING_SWITCH_WARNING"] = "Rol değişti. Geçiliyor: |cFFFFAA00%s|r  "
L["STRING_TARGET"] = "Hedef"
L["STRING_TARGETS"] = "Hedefler"
L["STRING_TARGETS_OTHER1"] = "Petler ve Diğer Hedefler"
L["STRING_TELEPORT"] = "Işınlanma"
L["STRING_TELEPORTERS"] = "Işınlayıcılar"
L["STRING_TEXTURE"] = "Doku"
L["STRING_TIME_OF_DEATH"] = "Ölüm"
L["STRING_TOOOLD"] = "Details! sürümün çok eski olduğu için kurulamadı."
L["STRING_TOP"] = "üst"
L["STRING_TOP_TO_BOTTOM"] = "Yukarıdan Aşağı"
L["STRING_TOTAL"] = " Toplamı"
L["STRING_TRAINING_DUMMY"] = "Antrenman Kuklası"
L["STRING_TRANSLATE_LANGUAGE"] = "Details! Çevirisine Yardım Et"
L["STRING_TUTORIAL_FULLY_DELETE_WINDOW"] = [=[Bir pencereyi kapattın, onu her zaman yeniden açabilirsin.
Bir pencereyi tamamen silmek için Ayarlar -> Pencere: Genel -> Sil'e git.]=]
L["STRING_TUTORIAL_OVERALL1"] = [=[Genel veri yalnızca savaş bitince güncellenir; düzenli güncelleme istiyorsan başlık çubuğuna sağ tıkla ve 'Dinamik Genel Veri'yi seç.
]=]
L["STRING_UNKNOW"] = "Bilinmiyor"
L["STRING_UNKNOWSPELL"] = "Bilinmeyen Büyü"
L["STRING_UNLOCK"] = [=[Pencereleri bu düğmeden
 gruptan ayır]=]
L["STRING_UNLOCK_WINDOW"] = "kilidi aç"
L["STRING_UPTADING"] = "güncelleniyor"
L["STRING_VERSION_AVAILABLE"] = "yeni bir sürüm çıktı, Curse Forge uygulamasından ya da sitesinden indir."
L["STRING_VERSION_UPDATE"] = "yeni sürüm: neler değişti? buraya tıkla"
L["STRING_VOIDZONE_TOOLTIP"] = "Hasar ve Süre"
L["STRING_WAITPLUGIN"] = [=[  Eklenti Kullanılamıyor, Lütfen Kontrol Et:

- Esc > Eklentiler > orada açık mı.
- Details! ayarlarındaki Eklentiler sayfası.
- Eklenti başka bir pencerede açık.
- Eklenti kapalı bir pencerede kullanılıyor.

]=]
L["STRING_WAVE"] = "dalga"
L["STRING_WELCOME_1"] = [=[|cFFFFFFFFDetails! Hızlı Kurulum Sihirbazına Hoş Geldin|r

Gezinmek için sağ alttaki okları kullan.]=]
L["STRING_WELCOME_11"] = "fikrini değiştirirsen ayarlar panelinden her zaman yeniden değiştirebilirsin"
L["STRING_WELCOME_12"] = "Pencerenin ne kadar hızlı güncelleneceğini seç; Hps ve Dps sayıları için animasyonları ve gerçek zamanlı güncellemeyi de açabilirsin."
--[[Translation missing --]]
L["STRING_WELCOME_13"] = ""
--[[Translation missing --]]
L["STRING_WELCOME_14"] = ""
L["STRING_WELCOME_15"] = "Hoş geldin penceresindeki güncelleme hızı için ipucu."
--[[Translation missing --]]
L["STRING_WELCOME_16"] = ""
--[[Translation missing --]]
L["STRING_WELCOME_17"] = ""
L["STRING_WELCOME_2"] = "fikrini değiştirirsen ayarlar panelinden her zaman yeniden değiştirebilirsin"
L["STRING_WELCOME_26"] = "Arayüzü Kullanma: Uzatma"
L["STRING_WELCOME_27"] = [=[Vurgulanan düğme Uzatıcıdır. |cFFFFFF00Tıkla|r ve |cFFFFFF00yukarı sürükle!|r.


Pencere kilitliyse başlık çubuğunun tamamı uzatma düğmesine dönüşür.]=]
L["STRING_WELCOME_28"] = "Arayüzü Kullanma: Pencere Kontrolü"
L["STRING_WELCOME_29"] = [=[Pencere Kontrolü temelde iki şey yapar:

- bir |cFFFFFF00yeni pencere|r açar.
- her zaman yeniden açılabilecek |cFFFFFF00kapalı pencereleri|r gösteren bir menü açar.]=]
L["STRING_WELCOME_3"] = "Tercih ettiğin DPS ve HPS yöntemini seç:"
L["STRING_WELCOME_30"] = "Arayüzü Kullanma: Yer İmleri"
L["STRING_WELCOME_31"] = [=[Pencerenin herhangi bir yerine |cFFFFFF00sağ tıklamak|r |cFFFFAA00Yer İmi|r panelini gösterir.

|cFFFFFF00Yeniden sağ tıklamak|r paneli kapatır ya da bir simgeye tıklanırsa başka bir görünüm seçer.

'Tüm Görünümler' panelini açmak için başlık çubuğuna |cFFFFFF00sağ tıkla|r.

Pencereyi kapatmak için |TInterface\AddOns\Details\images\key_ctrl:14:30:0:0:64:64:0:64:0:40|t + Sağ Tık.]=]
L["STRING_WELCOME_32"] = "Arayüzü Kullanma: Pencereleri Grupla"
L["STRING_WELCOME_34"] = "Arayüzü Kullanma: İpucunu Genişlet"
L["STRING_WELCOME_36"] = "Arayüzü Kullanma: Eklentiler"
L["STRING_WELCOME_38"] = "Raid'e Hazır!"
L["STRING_WELCOME_39"] = [=[Details!'i seçtiğin için teşekkürler!

Görüşlerini ve hata bildirimlerini bize her zaman gönderebilirsin.


 |cFFFFAA00/details feedback|r]=]
L["STRING_WELCOME_4"] = "Etkinlik Süresi: "
L["STRING_WELCOME_41"] = "Arayüz Eğlence Ayarları:"
L["STRING_WELCOME_42"] = "Hızlı Görünüm Ayarları"
L["STRING_WELCOME_43"] = "Tercih ettiğin görünümü seç:"
--[[Translation missing --]]
L["STRING_WELCOME_44"] = ""
L["STRING_WELCOME_45"] = "Daha fazla özelleştirme için ayarlar paneline bak."
--[[Translation missing --]]
L["STRING_WELCOME_46"] = ""
L["STRING_WELCOME_5"] = "Etkin Süre: "
--[[Translation missing --]]
L["STRING_WELCOME_57"] = ""
L["STRING_WELCOME_58"] = [=[Önceden tanımlı görünüm ayarı setleri.

|cFFFFFF00Önemli|r: tüm ayarlar daha sonra ayarlar panelinden değiştirilebilir.]=]
--[[Translation missing --]]
L["STRING_WELCOME_59"] = ""
L["STRING_WELCOME_6"] = "her raid üyesinin sayacı etkinliği durunca bekletilir, yeniden başlayınca saymaya devam eder."
--[[Translation missing --]]
L["STRING_WELCOME_60"] = ""
--[[Translation missing --]]
L["STRING_WELCOME_61"] = ""
--[[Translation missing --]]
L["STRING_WELCOME_62"] = ""
L["STRING_WELCOME_63"] = "DPS/HPS'yi Gerçek Zamanlı Güncelle"
--[[Translation missing --]]
L["STRING_WELCOME_64"] = ""
L["STRING_WELCOME_65"] = "Sağ Tuşa Bas!"
L["STRING_WELCOME_66"] = [=[Grup oluşturmak için bir pencereyi diğerinin yanına sürükle.

Gruplanmış pencereler birlikte uzar ve boyutlanır.

Çift olarak daha mutlu yaşarlar.]=]
L["STRING_WELCOME_67"] = [=[Oyuncunun ipucunu genişletip kullanılan tüm büyüleri görmek için Shift'e bas.

Hedefler için Ctrl, Petler için Alt.]=]
L["STRING_WELCOME_68"] = [=[Details!'i 'Eklentiler' adlı
bir veba sarmış.

Her yerdeler ve
birçok işte sana yardım ederler.

Örnekler: tehdit ölçer, dps analizi, karşılaşma özeti, grafik oluşturma ve daha fazlası.]=]
L["STRING_WELCOME_69"] = "Atla"
L["STRING_WELCOME_7"] = "sıralamalar için kullanılır; tüm raid üyelerinin DPS ve HPS'ini ölçmek için geçen savaş süresini kullanır."
--[[Translation missing --]]
L["STRING_WELCOME_70"] = ""
--[[Translation missing --]]
L["STRING_WELCOME_71"] = ""
--[[Translation missing --]]
L["STRING_WELCOME_72"] = ""
L["STRING_WELCOME_73"] = "Alfabeyi ya da Bölgeyi Seç:"
L["STRING_WELCOME_74"] = "Latin Alfabesi"
L["STRING_WELCOME_75"] = "Kiril Alfabesi"
L["STRING_WELCOME_76"] = "Çin"
L["STRING_WELCOME_77"] = "Kore"
L["STRING_WELCOME_78"] = "Tayvan"
L["STRING_WELCOME_79"] = "2. Pencereyi Oluştur"
L["STRING_WINDOW_NOTFOUND"] = "Pencere bulunamadı."
L["STRING_WINDOW_NUMBER"] = "pencere numarası"
L["STRING_WINDOW1ATACH_DESC"] = "Bir pencere grubu oluşturmak için 2. pencereyi 1. pencerenin yanına sürükle."
L["STRING_WIPE_ALERT"] = "Raid Lideri Çağrısı: Wipe!"
L["STRING_WIPE_ERROR1"] = "zaten bir wipe çağrısı yapıldı."
L["STRING_WIPE_ERROR2"] = "bir raid karşılaşmasında değiliz."
L["STRING_WIPE_ERROR3"] = "karşılaşma bitirilemedi."
L["STRING_YES"] = "Evet"
