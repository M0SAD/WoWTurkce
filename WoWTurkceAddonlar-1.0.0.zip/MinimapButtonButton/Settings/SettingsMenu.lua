local addonName, addon = ...;

local Settings = _G.Settings;
local SliderLabels = _G.MinimalSliderWithSteppersMixin.Label;
local CreateSettingsButtonInitializer = _G.CreateSettingsButtonInitializer;

local category, layout = Settings.RegisterVerticalLayoutCategory(addonName);

local Main = addon.import('Logic/Main');
local Options = addon.import('Logic/Options');
local Enhancements = addon.import('Features/Enhancements');
local Layout = addon.import('Layouts/Main');

local addonOptions = Options.getAll();

local function registerDropdown (key, defaultValue, optionsGetter, options)
  options = options or {};

  local name = options.name or key;
  local variable = addonName .. '_' .. key;
  local setValue = options.setValue;
  local setting = Settings.RegisterAddOnSetting(category, variable, key, addonOptions, type(defaultValue), name, defaultValue);

  if (setValue ~= nil) then
    setting:SetValueChangedCallback(function (_, value)
      setValue(value);
    end);
  end

  Settings.CreateDropdown(category, setting, optionsGetter, options.tooltip);
end

local function registerSlider(key, defaultValue, options)
  options = options or {};

  local name = options.name or key;
  local variable = addonName .. '_' .. key;
  local sliderOptions = Settings.CreateSliderOptions(options.min or 1,
      options.max or 100, options.step or 1);
  local setValue = options.setValue;
  local setting = Settings.RegisterAddOnSetting(category, variable, key, addonOptions, type(defaultValue), name, defaultValue);

  if (setValue ~= nil) then
    setting:SetValueChangedCallback(function (_, value)
      setValue(value);
    end);
  end

  if (options.labels ~= nil) then
    for label, formatter in pairs(options.labels) do
      sliderOptions:SetLabelFormatter(label, formatter);
    end
  else
    sliderOptions:SetLabelFormatter(options.label or SliderLabels.Right);
  end

  Settings.CreateSlider(category, setting, sliderOptions, options.tooltip)
end

local function registerCheckbox (key, defaultValue, options)
  options = options or {};

  local name = options.name or key;
  local variable = addonName .. '_' .. key;
  local setValue = options.setValue;
  local setting = Settings.RegisterAddOnSetting(category, variable, key, addonOptions, type(defaultValue), name, defaultValue);

  if (setValue ~= nil) then
    setting:SetValueChangedCallback(function (_, value)
      setValue(value);
    end);
  end

  Settings.CreateCheckbox(category, setting, options.tooltip);
end

local function registerButton (name, onclick, options)
  options = options or {};

  local buttonInitializer = CreateSettingsButtonInitializer(name, name, onclick, options.tooltip, false);

  layout:AddInitializer(buttonInitializer);
end


local function registerSettingsMenu()
  local function getOptions ()
    local container = Settings.CreateControlTextContainer();

    container:Add("leftdown", "Sol > Aşağı");
    container:Add("leftup", "Sol > Yukarı");
    container:Add("downleft", "Aşağı > Sol");
    container:Add("downright", "Aşağı > Sağ");
    container:Add("rightdown", "Sağ > Aşağı");
    container:Add("rightup", "Sağ > Yukarı");
    container:Add("upleft", "Yukarı > Sol");
    container:Add("upright", "Yukarı > Sağ");

    return container:GetData();
  end

  registerDropdown("direction", "leftdown", getOptions, {
    name = "Büyüme düzeni",
    setValue = Layout.applyLayout,
  });

  registerSlider("buttonsPerRow", 5, {
    name = "Satır başına düğme",
    min = 1,
    max = 50,
    setValue = Layout.updateLayout,
  });

  registerSlider("scale", 10, {
    name = "Ana düğmenin ölçeği",
    min = 1,
    max = 50,
    setValue = Main.applyScale,
    labels = {
      [SliderLabels.Right] = function (value)
        return value / 10;
      end,
    },
  });

  registerSlider("buttonScale", 10, {
    name = "Toplanan düğmelerin ölçeği",
    min = 1,
    max = 50,
    setValue = Main.applyButtonScale,
    labels = {
      [SliderLabels.Right] = function (value)
        return value / 10;
      end,
    },
  });

  registerCheckbox("autoClose", false, {
    name = "Düğme kabını otomatik kapat",
    tooltip = "Fare üzerinden çekildiğinde düğme kabını otomatik kapatır.",
    setValue = function (value)
      if (value) then
        Main.hideButtons();
      end
    end
  });

  if (Enhancements.compartment ~= nil) then
    registerCheckbox("hidecompartment", false, {
      name = "Eklenti bölmesi çerçevesini gizle",
      setValue = function (value)
        if (value == true) then
          Enhancements.hideCompartmentFrame();
        else
          Enhancements.showCompartmentFrame();
        end
      end
    });
  end

  registerButton("Konumu sıfırla", Main.resetPosition);

  Settings.RegisterAddOnCategory(category);
end

registerSettingsMenu();
