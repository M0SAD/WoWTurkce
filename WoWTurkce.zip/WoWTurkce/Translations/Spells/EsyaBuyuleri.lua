-- Eşya kullanma ve görev büyüleri (büyü çubuğunda görünen adlar): "Bury Samuel's Remains" -> "Samuel'in Kalıntılarını Göm"
local B = WoWTurkce.BuyuAdi
if B[" Attack Power - Feral (+305)"] == nil then B[" Attack Power - Feral (+305)"] = "Saldırı Gücü - Vahşi (+305)" end
if B["10% speed bonus"] == nil then B["10% speed bonus"] = "%10 Hız Bonusu" end
if B["13% speed bonus"] == nil then B["13% speed bonus"] = "%13 Hız Bonusu" end
if B["15% speed bonus"] == nil then B["15% speed bonus"] = "%15 Hız Bonusu" end
if B["5% speed bonus"] == nil then B["5% speed bonus"] = "%5 Hız Bonusu" end
if B["8% speed bonus"] == nil then B["8% speed bonus"] = "%8 Hız Bonusu" end
if B["Abolish Magic"] == nil then B["Abolish Magic"] = "Büyüyü Kaldır" end
if B["Absorb Blow"] == nil then B["Absorb Blow"] = "Darbe Emme" end
if B["Accurate Scope"] == nil then B["Accurate Scope"] = "Hassas Dürbün" end
if B["Acid Blast"] == nil then B["Acid Blast"] = "Asit Patlaması" end
if B["Activating Defenses"] == nil then B["Activating Defenses"] = "Savunmalar Etkinleştiriliyor" end
if B["Add Fire Dam - Weap 02"] == nil then B["Add Fire Dam - Weap 02"] = "Ateş Hasarı Ekle - Silah 02" end
if B["Add Fire Dam - Weap 04"] == nil then B["Add Fire Dam - Weap 04"] = "Ateş Hasarı Ekle - Silah 04" end
if B["Add Lightning Dam - Weap 03"] == nil then B["Add Lightning Dam - Weap 03"] = "Yıldırım Hasarı Ekle - Silah 03" end
if B["Admiral's Hat"] == nil then B["Admiral's Hat"] = "Amiralin Şapkası" end
if B["Aegis of Preservation"] == nil then B["Aegis of Preservation"] = "Koruma Siperi" end
if B["Agility"] == nil then B["Agility"] = "Çeviklik" end
if B["Alchemists Stone"] == nil then B["Alchemists Stone"] = "Simyacı Taşı" end
if B["Alex's Audacity"] == nil then B["Alex's Audacity"] = "Alex'in Cüreti" end
if B["Alterac Manna Biscuit"] == nil then B["Alterac Manna Biscuit"] = "Alterac Manna Bisküvisi" end
if B["Alterac Spring Water"] == nil then B["Alterac Spring Water"] = "Alterac Kaynak Suyu" end
if B["Ancestor's Vengeance"] == nil then B["Ancestor's Vengeance"] = "Atanın İntikamı" end
if B["Animist's Caress"] == nil then B["Animist's Caress"] = "Animistin Okşayışı" end
if B["Anti-Venom"] == nil then B["Anti-Venom"] = "Panzehir" end
if B["Apply Salve"] == nil then B["Apply Salve"] = "Merhem Sür" end
if B["Apply Seduction Gland"] == nil then B["Apply Seduction Gland"] = "Baştan Çıkarma Bezini Sür" end
if B["Applying the Lure"] == nil then B["Applying the Lure"] = "Yem Takılıyor" end
if B["Aquadynamic Fish Attractor"] == nil then B["Aquadynamic Fish Attractor"] = "Akuadinamik Balık Çekici" end
if B["Aquadynamic Fish Lens"] == nil then B["Aquadynamic Fish Lens"] = "Akuadinamik Balık Merceği" end
if B["Aqual Quintessence - Dowse Molten Core Rune"] == nil then B["Aqual Quintessence - Dowse Molten Core Rune"] = "Aqual Özü - Molten Core Rününü Söndür" end
if B["Arathi Basin Enriched Ration"] == nil then B["Arathi Basin Enriched Ration"] = "Arathi Havzası Zenginleştirilmiş Erzak" end
if B["Arathi Basin Field Ration"] == nil then B["Arathi Basin Field Ration"] = "Arathi Havzası Sahra Erzakı" end
if B["Arathi Basin Iron Ration"] == nil then B["Arathi Basin Iron Ration"] = "Arathi Havzası Kuru Erzak" end
if B["Arcane Blast"] == nil then B["Arcane Blast"] = "Arkan Patlama" end
if B["Arcane Bomb"] == nil then B["Arcane Bomb"] = "Arkan Bomba" end
if B["Arcane Brilliance"] == nil then B["Arcane Brilliance"] = "Arkan Parlaklık" end
if B["Arcane Elixir"] == nil then B["Arcane Elixir"] = "Arkan Eliksiri" end
if B["Arcane Infused"] == nil then B["Arcane Infused"] = "Arkanla Aşılanmış" end
if B["Arcane Mantle of the Dawn"] == nil then B["Arcane Mantle of the Dawn"] = "Şafağın Arkan Omuzluğu" end
if B["Arcane Potency"] == nil then B["Arcane Potency"] = "Arkan Kudret" end
if B["Arcane Protection"] == nil then B["Arcane Protection"] = "Arkan Koruma" end
if B["Arcane Shot Mana Reduction"] == nil then B["Arcane Shot Mana Reduction"] = "Arkan Atış Mana İndirimi" end
if B["Arcane Shroud"] == nil then B["Arcane Shroud"] = "Arkan Örtü" end
if B["Arcanite Dragonling"] == nil then B["Arcanite Dragonling"] = "Arcanite Ejder Yavrusu" end
if B["Arcanite Skeleton Key"] == nil then B["Arcanite Skeleton Key"] = "Arcanite Maymuncuk" end
if B["Arcanum of Focus"] == nil then B["Arcanum of Focus"] = "Odak Arcanumu" end
if B["Arcanum of Protection"] == nil then B["Arcanum of Protection"] = "Koruma Arcanumu" end
if B["Arcanum of Rapidity"] == nil then B["Arcanum of Rapidity"] = "Sürat Arcanumu" end
if B["Arctic Wolf"] == nil then B["Arctic Wolf"] = "Kutup Kurdu" end
if B["Argent Avenger"] == nil then B["Argent Avenger"] = "Argent İntikamcısı" end
if B["Argent Dawn Commission"] == nil then B["Argent Dawn Commission"] = "Argent Dawn Görev Belgesi" end
if B["Armor"] == nil then B["Armor"] = "Zırh" end
if B["Armor +16"] == nil then B["Armor +16"] = "Zırh +16" end
if B["Armor +24"] == nil then B["Armor +24"] = "Zırh +24" end
if B["Armor +32"] == nil then B["Armor +32"] = "Zırh +32" end
if B["Armor +40"] == nil then B["Armor +40"] = "Zırh +40" end
if B["Armor +8"] == nil then B["Armor +8"] = "Zırh +8" end
if B["Armor Shatter"] == nil then B["Armor Shatter"] = "Zırh Parçalama" end
if B["Artisan Cook"] == nil then B["Artisan Cook"] = "Zanaatkâr Aşçı" end
if B["Artisan First Aid"] == nil then B["Artisan First Aid"] = "Zanaatkâr İlk Yardım" end
if B["Artisan Fishing"] == nil then B["Artisan Fishing"] = "Zanaatkâr Balıkçılık" end
if B["Ascendance"] == nil then B["Ascendance"] = "Yükseliş" end
if B["Aspect of Neptulon"] == nil then B["Aspect of Neptulon"] = "Neptulon'un Sureti" end
if B["Atiesh Priest Damage/Healing"] == nil then B["Atiesh Priest Damage/Healing"] = "Atiesh Rahip Hasarı/İyileştirmesi" end
if B["Attach Medallion to Shaft"] == nil then B["Attach Medallion to Shaft"] = "Madalyonu Sapa Tak" end
if B["Attach Shaft to Medallion"] == nil then B["Attach Shaft to Medallion"] = "Sapı Madalyona Tak" end
if B["Attack Power - Feral (+140)"] == nil then B["Attack Power - Feral (+140)"] = "Saldırı Gücü - Vahşi (+140)" end
if B["Attack Power - Feral (+154)"] == nil then B["Attack Power - Feral (+154)"] = "Saldırı Gücü - Vahşi (+154)" end
if B["Attack Power - Feral (+280)"] == nil then B["Attack Power - Feral (+280)"] = "Saldırı Gücü - Vahşi (+280)" end
if B["Attack Power - Feral (+420)"] == nil then B["Attack Power - Feral (+420)"] = "Saldırı Gücü - Vahşi (+420)" end
if B["Attack Power - Feral (+574)"] == nil then B["Attack Power - Feral (+574)"] = "Saldırı Gücü - Vahşi (+574)" end
if B["Attack Power 06"] == nil then B["Attack Power 06"] = "Saldırı Gücü 06" end
if B["Attack Power 08"] == nil then B["Attack Power 08"] = "Saldırı Gücü 08" end
if B["Attack Power 10"] == nil then B["Attack Power 10"] = "Saldırı Gücü 10" end
if B["Attack Power 12"] == nil then B["Attack Power 12"] = "Saldırı Gücü 12" end
if B["Attack Power 14"] == nil then B["Attack Power 14"] = "Saldırı Gücü 14" end
if B["Attack Power 15"] == nil then B["Attack Power 15"] = "Saldırı Gücü 15" end
if B["Attack Power 16"] == nil then B["Attack Power 16"] = "Saldırı Gücü 16" end
if B["Attack Power 18"] == nil then B["Attack Power 18"] = "Saldırı Gücü 18" end
if B["Attack Power 20"] == nil then B["Attack Power 20"] = "Saldırı Gücü 20" end
if B["Attack Power 200"] == nil then B["Attack Power 200"] = "Saldırı Gücü 200" end
if B["Attack Power 22"] == nil then B["Attack Power 22"] = "Saldırı Gücü 22" end
if B["Attack Power 24"] == nil then B["Attack Power 24"] = "Saldırı Gücü 24" end
if B["Attack Power 26"] == nil then B["Attack Power 26"] = "Saldırı Gücü 26" end
if B["Attack Power 28"] == nil then B["Attack Power 28"] = "Saldırı Gücü 28" end
if B["Attack Power 30"] == nil then B["Attack Power 30"] = "Saldırı Gücü 30" end
if B["Attack Power 32"] == nil then B["Attack Power 32"] = "Saldırı Gücü 32" end
if B["Attack Power 34"] == nil then B["Attack Power 34"] = "Saldırı Gücü 34" end
if B["Attack Power 36"] == nil then B["Attack Power 36"] = "Saldırı Gücü 36" end
if B["Attack Power 38"] == nil then B["Attack Power 38"] = "Saldırı Gücü 38" end
if B["Attack Power 40"] == nil then B["Attack Power 40"] = "Saldırı Gücü 40" end
if B["Attack Power 42"] == nil then B["Attack Power 42"] = "Saldırı Gücü 42" end
if B["Attack Power 44"] == nil then B["Attack Power 44"] = "Saldırı Gücü 44" end
if B["Attack Power 46"] == nil then B["Attack Power 46"] = "Saldırı Gücü 46" end
if B["Attack Power 48"] == nil then B["Attack Power 48"] = "Saldırı Gücü 48" end
if B["Attack Power 50"] == nil then B["Attack Power 50"] = "Saldırı Gücü 50" end
if B["Attack Power 52"] == nil then B["Attack Power 52"] = "Saldırı Gücü 52" end
if B["Attack Power 54"] == nil then B["Attack Power 54"] = "Saldırı Gücü 54" end
if B["Attack Power 56"] == nil then B["Attack Power 56"] = "Saldırı Gücü 56" end
if B["Attack Power 58"] == nil then B["Attack Power 58"] = "Saldırı Gücü 58" end
if B["Attack Power 60"] == nil then B["Attack Power 60"] = "Saldırı Gücü 60" end
if B["Attack Power 62"] == nil then B["Attack Power 62"] = "Saldırı Gücü 62" end
if B["Attack Power 64"] == nil then B["Attack Power 64"] = "Saldırı Gücü 64" end
if B["Attack Power 66"] == nil then B["Attack Power 66"] = "Saldırı Gücü 66" end
if B["Attack Power 72"] == nil then B["Attack Power 72"] = "Saldırı Gücü 72" end
if B["Attack Power 76"] == nil then B["Attack Power 76"] = "Saldırı Gücü 76" end
if B["Attack Power 80"] == nil then B["Attack Power 80"] = "Saldırı Gücü 80" end
if B["Attack Power 86"] == nil then B["Attack Power 86"] = "Saldırı Gücü 86" end
if B["Attack Power 98"] == nil then B["Attack Power 98"] = "Saldırı Gücü 98" end
if B["Attack Power Ranged 10"] == nil then B["Attack Power Ranged 10"] = "Menzilli Saldırı Gücü 10" end
if B["Attack Power Ranged 14"] == nil then B["Attack Power Ranged 14"] = "Menzilli Saldırı Gücü 14" end
if B["Attack Power Ranged 17"] == nil then B["Attack Power Ranged 17"] = "Menzilli Saldırı Gücü 17" end
if B["Attack Power Ranged 19"] == nil then B["Attack Power Ranged 19"] = "Menzilli Saldırı Gücü 19" end
if B["Attack Power Ranged 22"] == nil then B["Attack Power Ranged 22"] = "Menzilli Saldırı Gücü 22" end
if B["Attack Power Ranged 31"] == nil then B["Attack Power Ranged 31"] = "Menzilli Saldırı Gücü 31" end
if B["Attack Power Ranged 34"] == nil then B["Attack Power Ranged 34"] = "Menzilli Saldırı Gücü 34" end
if B["Attack Power Ranged 36"] == nil then B["Attack Power Ranged 36"] = "Menzilli Saldırı Gücü 36" end
if B["Attack Power Ranged 41"] == nil then B["Attack Power Ranged 41"] = "Menzilli Saldırı Gücü 41" end
if B["Attack Power Ranged 48"] == nil then B["Attack Power Ranged 48"] = "Menzilli Saldırı Gücü 48" end
if B["Attuned Dampener"] == nil then B["Attuned Dampener"] = "Ayarlı Sönümleyici" end
if B["Aura of Protection"] == nil then B["Aura of Protection"] = "Koruma Aurası" end
if B["Aura of the Blue Dragon"] == nil then B["Aura of the Blue Dragon"] = "Mavi Ejderhanın Aurası" end
if B["Awaken Kerlonian"] == nil then B["Awaken Kerlonian"] = "Kerlonian'ı Uyandır" end
if B["Awaken Peon"] == nil then B["Awaken Peon"] = "Peon'u Uyandır" end
if B["Awaken the Soulflayer"] == nil then B["Awaken the Soulflayer"] = "Soulflayer'ı Uyandır" end
if B["Azure Silk Gloves"] == nil then B["Azure Silk Gloves"] = "Lacivert İpek Eldivenler" end
if B["Badge of the Swarmguard"] == nil then B["Badge of the Swarmguard"] = "Sürü Muhafızı Nişanı" end
if B["Bael'Gar's Fiery Essence"] == nil then B["Bael'Gar's Fiery Essence"] = "Bael'Gar'ın Alevli Özü" end
if B["Balance of Light and Shadow"] == nil then B["Balance of Light and Shadow"] = "Işık ve Gölge Dengesi" end
if B["Banish Burning Exile"] == nil then B["Banish Burning Exile"] = "Yanan Sürgünü Kov" end
if B["Banish Cresting Exile"] == nil then B["Banish Cresting Exile"] = "Kabaran Sürgünü Kov" end
if B["Banish Thundering Exile"] == nil then B["Banish Thundering Exile"] = "Gürleyen Sürgünü Kov" end
if B["Basilisk Sample"] == nil then B["Basilisk Sample"] = "Basilisk Numunesi" end
if B["Basilisk Skin"] == nil then B["Basilisk Skin"] = "Basilisk Derisi" end
if B["Bat Costume"] == nil then B["Bat Costume"] = "Yarasa Kostümü" end
if B["Battle Standard"] == nil then B["Battle Standard"] = "Savaş Sancağı" end
if B["Beast Slaying 18"] == nil then B["Beast Slaying 18"] = "Canavar Avcılığı 18" end
if B["Beast Slaying 24"] == nil then B["Beast Slaying 24"] = "Canavar Avcılığı 24" end
if B["Beast Slaying 30"] == nil then B["Beast Slaying 30"] = "Canavar Avcılığı 30" end
if B["Beast Slaying 33"] == nil then B["Beast Slaying 33"] = "Canavar Avcılığı 33" end
if B["Beast Slaying 45"] == nil then B["Beast Slaying 45"] = "Canavar Avcılığı 45" end
if B["Beast Slaying 48"] == nil then B["Beast Slaying 48"] = "Canavar Avcılığı 48" end
if B["Beast Slaying 60"] == nil then B["Beast Slaying 60"] = "Canavar Avcılığı 60" end
if B["Beast Slaying 72"] == nil then B["Beast Slaying 72"] = "Canavar Avcılığı 72" end
if B["Beasts Deck"] == nil then B["Beasts Deck"] = "Canavarlar Destesi" end
if B["Bending Shinbone"] == nil then B["Bending Shinbone"] = "Bükülen Kaval Kemiği" end
if B["Benediction"] == nil then B["Benediction"] = "Kutsama" end
if B["Bethor's Potion"] == nil then B["Bethor's Potion"] = "Bethor'un İksiri" end
if B["Big Bronze Bomb"] == nil then B["Big Bronze Bomb"] = "Büyük Bronz Bomba" end
if B["Big Iron Bomb"] == nil then B["Big Iron Bomb"] = "Büyük Demir Bomba" end
if B["Bind Chapter 1"] == nil then B["Bind Chapter 1"] = "1. Bölümü Ciltle" end
if B["Bind Chapter 2"] == nil then B["Bind Chapter 2"] = "2. Bölümü Ciltle" end
if B["Bind Chapter 3"] == nil then B["Bind Chapter 3"] = "3. Bölümü Ciltle" end
if B["Bind Draconic For Dummies"] == nil then B["Bind Draconic For Dummies"] = "Yeni Başlayanlar İçin Ejderce'yi Ciltle" end
if B["Binding Volume I"] == nil then B["Binding Volume I"] = "Cilt I Ciltleniyor" end
if B["Binding Volume II"] == nil then B["Binding Volume II"] = "Cilt II Ciltleniyor" end
if B["Binding Volume III"] == nil then B["Binding Volume III"] = "Cilt III Ciltleniyor" end
if B["Biznicks 247x128 Accurascope"] == nil then B["Biznicks 247x128 Accurascope"] = "Biznicks 247x128 Hassas Dürbün" end
if B["Black Battlestrider"] == nil then B["Black Battlestrider"] = "Kara Savaş Yürüteci" end
if B["Black Ram"] == nil then B["Black Ram"] = "Kara Koç" end
if B["Black Stallion"] == nil then B["Black Stallion"] = "Kara Aygır" end
if B["Black War Kodo"] == nil then B["Black War Kodo"] = "Kara Savaş Kodosu" end
if B["Black War Ram"] == nil then B["Black War Ram"] = "Kara Savaş Koçu" end
if B["Black War Raptor"] == nil then B["Black War Raptor"] = "Kara Savaş Raptoru" end
if B["Black War Steed"] == nil then B["Black War Steed"] = "Kara Savaş Atı" end
if B["Black War Tiger"] == nil then B["Black War Tiger"] = "Kara Savaş Kaplanı" end
if B["Black War Wolf"] == nil then B["Black War Wolf"] = "Kara Savaş Kurdu" end
if B["Black Whelp Cloak"] == nil then B["Black Whelp Cloak"] = "Kara Ejder Yavrusu Pelerini" end
if B["Black Wolf"] == nil then B["Black Wolf"] = "Kara Kurt" end
if B["Bladestorm"] == nil then B["Bladestorm"] = "Kılıç Fırtınası" end
if B["Blaze"] == nil then B["Blaze"] = "Alev" end
if B["Blazerunner Dispel"] == nil then B["Blazerunner Dispel"] = "Blazerunner Dağıtma" end
if B["Blazing Emblem"] == nil then B["Blazing Emblem"] = "Alevli Amblem" end
if B["Bleakwood Curse"] == nil then B["Bleakwood Curse"] = "Bleakwood Laneti" end
if B["Blessed Sunfruit"] == nil then B["Blessed Sunfruit"] = "Kutsanmış Güneş Meyvesi" end
if B["Blessed Sunfruit Juice"] == nil then B["Blessed Sunfruit Juice"] = "Kutsanmış Güneş Meyvesi Suyu" end
if B["Blessed Wizard Oil"] == nil then B["Blessed Wizard Oil"] = "Kutsanmış Büyücü Yağı" end
if B["Blessing of the Black Book"] == nil then B["Blessing of the Black Book"] = "Kara Kitabın Lütfu" end
if B["Blessing of the Holy Spring"] == nil then B["Blessing of the Holy Spring"] = "Kutsal Pınarın Lütfu" end
if B["Blight"] == nil then B["Blight"] = "Afet" end
if B["Blinding Light"] == nil then B["Blinding Light"] = "Kör Eden Işık" end
if B["Block Value 10"] == nil then B["Block Value 10"] = "Blok Değeri 10" end
if B["Block Value 12"] == nil then B["Block Value 12"] = "Blok Değeri 12" end
if B["Block Value 14"] == nil then B["Block Value 14"] = "Blok Değeri 14" end
if B["Block Value 15"] == nil then B["Block Value 15"] = "Blok Değeri 15" end
if B["Block Value 18"] == nil then B["Block Value 18"] = "Blok Değeri 18" end
if B["Block Value 19"] == nil then B["Block Value 19"] = "Blok Değeri 19" end
if B["Block Value 21"] == nil then B["Block Value 21"] = "Blok Değeri 21" end
if B["Block Value 23"] == nil then B["Block Value 23"] = "Blok Değeri 23" end
if B["Block Value 24"] == nil then B["Block Value 24"] = "Blok Değeri 24" end
if B["Block Value 27"] == nil then B["Block Value 27"] = "Blok Değeri 27" end
if B["Block Value 30"] == nil then B["Block Value 30"] = "Blok Değeri 30" end
if B["Block Value 32"] == nil then B["Block Value 32"] = "Blok Değeri 32" end
if B["Blood Boil"] == nil then B["Blood Boil"] = "Kan Kaynaması" end
if B["Blood Pact"] == nil then B["Blood Pact"] = "Kan Antlaşması" end
if B["Bloodpetal Zapper"] == nil then B["Bloodpetal Zapper"] = "Kan Yaprağı Çarpıcısı" end
if B["Blow Maraudine Horn"] == nil then B["Blow Maraudine Horn"] = "Maraudine Borusunu Öttür" end
if B["Blue Firework"] == nil then B["Blue Firework"] = "Mavi Havai Fişek" end
if B["Blue Firework Cluster"] == nil then B["Blue Firework Cluster"] = "Mavi Havai Fişek Demeti" end
if B["Blue Mechanostrider"] == nil then B["Blue Mechanostrider"] = "Mavi Mechanostrider" end
if B["Blue Ram"] == nil then B["Blue Ram"] = "Mavi Koç" end
if B["Blue Skeletal Horse"] == nil then B["Blue Skeletal Horse"] = "Mavi İskelet At" end
if B["Bone Armor"] == nil then B["Bone Armor"] = "Kemik Zırh" end
if B["Bonereaver's Edge"] == nil then B["Bonereaver's Edge"] = "Bonereaver'ın Kılıcı" end
if B["Bonespike"] == nil then B["Bonespike"] = "Kemik Diken" end
if B["Boon of Life"] == nil then B["Boon of Life"] = "Yaşam Lütfu" end
if B["Bounty of the Harvest"] == nil then B["Bounty of the Harvest"] = "Hasat Bereketi" end
if B["Brain Damage"] == nil then B["Brain Damage"] = "Beyin Hasarı" end
if B["Brain Food"] == nil then B["Brain Food"] = "Beyin Gıdası" end
if B["Brain Hacker"] == nil then B["Brain Hacker"] = "Beyin Yaran" end
if B["Break Tool"] == nil then B["Break Tool"] = "Aleti Kır" end
if B["Breath of Fire"] == nil then B["Breath of Fire"] = "Ateş Nefesi" end
if B["Bright Baubles"] == nil then B["Bright Baubles"] = "Parlak Süs Boncukları" end
if B["Brilliant Light"] == nil then B["Brilliant Light"] = "Parlak Işık" end
if B["Brilliant Mana Oil"] == nil then B["Brilliant Mana Oil"] = "Parlak Mana Yağı" end
if B["Brilliant Wizard Oil"] == nil then B["Brilliant Wizard Oil"] = "Parlak Büyücü Yağı" end
if B["Brittle Armor"] == nil then B["Brittle Armor"] = "Kırılgan Zırh" end
if B["Brown Horse"] == nil then B["Brown Horse"] = "Kahverengi At" end
if B["Brown Kodo"] == nil then B["Brown Kodo"] = "Kahverengi Kodo" end
if B["Brown Ram"] == nil then B["Brown Ram"] = "Kahverengi Koç" end
if B["Brown Skeletal Horse"] == nil then B["Brown Skeletal Horse"] = "Kahverengi İskelet At" end
if B["Brown Wolf"] == nil then B["Brown Wolf"] = "Kahverengi Kurt" end
if B["Bubbly Refreshment"] == nil then B["Bubbly Refreshment"] = "Köpüklü Ferahlık" end
if B["Burning Spirit"] == nil then B["Burning Spirit"] = "Yanan Ruh" end
if B["Burst of Energy"] == nil then B["Burst of Energy"] = "Enerji Patlaması" end
if B["Burst of Knowledge"] == nil then B["Burst of Knowledge"] = "Bilgi Patlaması" end
if B["Bury Samuel's Remains"] == nil then B["Bury Samuel's Remains"] = "Samuel'in Kalıntılarını Göm" end
if B["Buttermilk Delight"] == nil then B["Buttermilk Delight"] = "Ayranlı Lokum" end
if B["CHU's QUEST SPELL"] == nil then B["CHU's QUEST SPELL"] = "CHU'nun Görev Büyüsü" end
if B["Call Anathema"] == nil then B["Call Anathema"] = "Aforoz'u Çağır" end
if B["Call Benediction"] == nil then B["Call Benediction"] = "Kutsama'yı Çağır" end
if B["Call Spirit"] == nil then B["Call Spirit"] = "Ruhu Çağır" end
if B["Call of Sul'thraze"] == nil then B["Call of Sul'thraze"] = "Sul'thraze'in Çağrısı" end
if B["Call of the Ashbringer"] == nil then B["Call of the Ashbringer"] = "Ashbringer'ın Çağrısı" end
if B["Cantation of Manifestation"] == nil then B["Cantation of Manifestation"] = "Tezahür İlahisi" end
if B["Capture Faerie Dragon"] == nil then B["Capture Faerie Dragon"] = "Peri Ejderhasını Yakala" end
if B["Capture Felhound Spirit"] == nil then B["Capture Felhound Spirit"] = "Felhound Ruhunu Yakala" end
if B["Capture Grark"] == nil then B["Capture Grark"] = "Grark'ı Yakala" end
if B["Capture Hippogryph"] == nil then B["Capture Hippogryph"] = "Hipogrifi Yakala" end
if B["Capture Infernal Spirit"] == nil then B["Capture Infernal Spirit"] = "Infernal Ruhunu Yakala" end
if B["Capture Mountain Giant"] == nil then B["Capture Mountain Giant"] = "Dağ Devini Yakala" end
if B["Capture Spirit"] == nil then B["Capture Spirit"] = "Ruhu Yakala" end
if B["Capture Treant"] == nil then B["Capture Treant"] = "Treant'i Yakala" end
if B["Capture Wildkin"] == nil then B["Capture Wildkin"] = "Wildkin'i Yakala" end
if B["Capture Worg Pup"] == nil then B["Capture Worg Pup"] = "Worg Yavrusunu Yakala" end
if B["Capturing Termites"] == nil then B["Capturing Termites"] = "Termitler Yakalanıyor" end
if B["Cascade of Roses"] == nil then B["Cascade of Roses"] = "Gül Yağmuru" end
if B["Chains of Ice"] == nil then B["Chains of Ice"] = "Buz Zincirleri" end
if B["Champion of the Dawn"] == nil then B["Champion of the Dawn"] = "Şafağın Şampiyonu" end
if B["Chaos Fire"] == nil then B["Chaos Fire"] = "Kaos Ateşi" end
if B["Charge Stave of Equinex"] == nil then B["Charge Stave of Equinex"] = "Equinex Asasını Doldur" end
if B["Charging"] == nil then B["Charging"] = "Dolduruluyor" end
if B["Chestnut Mare"] == nil then B["Chestnut Mare"] = "Kestane Kısrak" end
if B["Chilled"] == nil then B["Chilled"] = "Üşümüş" end
if B["Chitinous Spikes"] == nil then B["Chitinous Spikes"] = "Kitin Dikenler" end
if B["Chromatic Infusion"] == nil then B["Chromatic Infusion"] = "Kromatik Aşılama" end
if B["Chromatic Mantle of the Dawn"] == nil then B["Chromatic Mantle of the Dawn"] = "Şafağın Kromatik Omuzluğu" end
if B["Chromatic Mount"] == nil then B["Chromatic Mount"] = "Kromatik Binek" end
if B["Chromatic Resistance"] == nil then B["Chromatic Resistance"] = "Kromatik Direnç" end
if B["Circle of Flame"] == nil then B["Circle of Flame"] = "Alev Halkası" end
if B["Clean Up Stink Bomb"] == nil then B["Clean Up Stink Bomb"] = "Pis Koku Bombasını Temizle" end
if B["Cleanse Cost Reduced"] == nil then B["Cleanse Cost Reduced"] = "Arındırma Maliyeti Azaltıldı" end
if B["Cleanse Thunderhorn Well"] == nil then B["Cleanse Thunderhorn Well"] = "Thunderhorn Kuyusunu Arındır" end
if B["Cleanse Wildmane Well"] == nil then B["Cleanse Wildmane Well"] = "Wildmane Kuyusunu Arındır" end
if B["Cleanse Winterhoof Well"] == nil then B["Cleanse Winterhoof Well"] = "Winterhoof Kuyusunu Arındır" end
if B["Cleave Armor"] == nil then B["Cleave Armor"] = "Zırh Yarma" end
if B["Cloak of Fire"] == nil then B["Cloak of Fire"] = "Ateş Pelerini" end
if B["Cloaking"] == nil then B["Cloaking"] = "Gizlenme" end
if B["Coarse Dynamite"] == nil then B["Coarse Dynamite"] = "Kaba Dinamit" end
if B["Cold Eye"] == nil then B["Cold Eye"] = "Soğuk Göz" end
if B["Collect Blessed Water"] == nil then B["Collect Blessed Water"] = "Kutsanmış Su Topla" end
if B["Collect Corrupted Water"] == nil then B["Collect Corrupted Water"] = "Bozulmuş Su Topla" end
if B["Collect Dire Water"] == nil then B["Collect Dire Water"] = "Uğursuz Su Topla" end
if B["Collect Orange Crystal Liquid"] == nil then B["Collect Orange Crystal Liquid"] = "Turuncu Kristal Sıvısı Topla" end
if B["Collect Rookery Egg"] == nil then B["Collect Rookery Egg"] = "Kuluçka Yumurtası Topla" end
if B["Collecting Fallout"] == nil then B["Collecting Fallout"] = "Serpinti Toplanıyor" end
if B["Cologne"] == nil then B["Cologne"] = "Kolonya" end
if B["Combine Pendants"] == nil then B["Combine Pendants"] = "Kolyeleri Birleştir" end
if B["Combining Charms"] == nil then B["Combining Charms"] = "Tılsımlar Birleştiriliyor" end
if B["Compact Harvest Reaper"] == nil then B["Compact Harvest Reaper"] = "Kompakt Hasat Biçici" end
if B["Conjure Lily Root"] == nil then B["Conjure Lily Root"] = "Zambak Kökü Yarat" end
if B["Conjure Mana Gem"] == nil then B["Conjure Mana Gem"] = "Mana Taşı Yarat" end
if B["Consecrated Weapon"] == nil then B["Consecrated Weapon"] = "Kutsanmış Silah" end
if B["Consume Shadows"] == nil then B["Consume Shadows"] = "Gölgeleri Tüket" end
if B["Cooked Deviate Fish"] == nil then B["Cooked Deviate Fish"] = "Pişmiş Sapkın Balık" end
if B["Copy of Improved Mana/Health Totems"] == nil then B["Copy of Improved Mana/Health Totems"] = "Gelişmiş Mana/Sağlık Totemleri Kopyası" end
if B["Copy of Pattern: Stormcloth Shoulders"] == nil then B["Copy of Pattern: Stormcloth Shoulders"] = "Desen Kopyası: Fırtına Kumaşı Omuzluklar" end
if B["Corrosive Poison"] == nil then B["Corrosive Poison"] = "Aşındırıcı Zehir" end
if B["Cowardly Flight"] == nil then B["Cowardly Flight"] = "Korkakça Kaçış" end
if B["Create Alliance Gift Collection"] == nil then B["Create Alliance Gift Collection"] = "Alliance Hediye Koleksiyonu Yarat" end
if B["Create Amulet of Union"] == nil then B["Create Amulet of Union"] = "Birlik Muskası Yarat" end
if B["Create Cluster Rocket Launcher"] == nil then B["Create Cluster Rocket Launcher"] = "Salkım Roket Atar Yarat" end
if B["Create Coagulated Rot"] == nil then B["Create Coagulated Rot"] = "Pıhtılaşmış Çürüme Yarat" end
if B["Create Containment Coffer"] == nil then B["Create Containment Coffer"] = "Muhafaza Sandığı Yarat" end
if B["Create Crest of Beckoning: Air"] == nil then B["Create Crest of Beckoning: Air"] = "Çağrı Arması Yarat: Hava" end
if B["Create Crest of Beckoning: Earth"] == nil then B["Create Crest of Beckoning: Earth"] = "Çağrı Arması Yarat: Toprak" end
if B["Create Crest of Beckoning: Fire"] == nil then B["Create Crest of Beckoning: Fire"] = "Çağrı Arması Yarat: Ateş" end
if B["Create Crest of Beckoning: Water"] == nil then B["Create Crest of Beckoning: Water"] = "Çağrı Arması Yarat: Su" end
if B["Create Darnassus Box of Woodcrafts"] == nil then B["Create Darnassus Box of Woodcrafts"] = "Darnassus Ahşap İşleri Kutusu Yarat" end
if B["Create Darnassus Pledges of Loyalty"] == nil then B["Create Darnassus Pledges of Loyalty"] = "Darnassus Sadakat Yeminleri Yarat" end
if B["Create Darnassus Stack of Cards"] == nil then B["Create Darnassus Stack of Cards"] = "Darnassus Kart Destesi Yarat" end
if B["Create Elune Stone"] == nil then B["Create Elune Stone"] = "Elune Taşı Yarat" end
if B["Create Fervor Potion (New)"] == nil then B["Create Fervor Potion (New)"] = "Şevk İksiri Yarat (Yeni)" end
if B["Create Firework Rocket Launcher"] == nil then B["Create Firework Rocket Launcher"] = "Havai Fişek Roket Atar Yarat" end
if B["Create Greater Healthstone"] == nil then B["Create Greater Healthstone"] = "Büyük Sağlık Taşı Yarat" end
if B["Create Heart Candy"] == nil then B["Create Heart Candy"] = "Kalp Şekeri Yarat" end
if B["Create Horde Gift Collection"] == nil then B["Create Horde Gift Collection"] = "Horde Hediye Koleksiyonu Yarat" end
if B["Create Ironforge Case of Homebrew"] == nil then B["Create Ironforge Case of Homebrew"] = "Ironforge Ev Yapımı Bira Kasası Yarat" end
if B["Create Ironforge Parcel of Cards"] == nil then B["Create Ironforge Parcel of Cards"] = "Ironforge Kart Kolisi Yarat" end
if B["Create Ironforge Pledges of Loyalty"] == nil then B["Create Ironforge Pledges of Loyalty"] = "Ironforge Sadakat Yeminleri Yarat" end
if B["Create Knucklebone Pouch"] == nil then B["Create Knucklebone Pouch"] = "Aşık Kemiği Kesesi Yarat" end
if B["Create Lesser Healthstone"] == nil then B["Create Lesser Healthstone"] = "Küçük Sağlık Taşı Yarat" end
if B["Create Mallet of Zul'Farrak"] == nil then B["Create Mallet of Zul'Farrak"] = "Zul'Farrak Tokmağı Yarat" end
if B["Create Nimboya's Laden Pike"] == nil then B["Create Nimboya's Laden Pike"] = "Nimboya'nın Yüklü Mızrağı Yarat" end
if B["Create Orgrimmar Box of Fresh Pies"] == nil then B["Create Orgrimmar Box of Fresh Pies"] = "Orgrimmar Taze Turta Kutusu Yarat" end
if B["Create Orgrimmar Package of Cards"] == nil then B["Create Orgrimmar Package of Cards"] = "Orgrimmar Kart Paketi Yarat" end
if B["Create Orgrimmar Pledges of Loyalty"] == nil then B["Create Orgrimmar Pledges of Loyalty"] = "Orgrimmar Sadakat Yeminleri Yarat" end
if B["Create PX83-Enigmatron"] == nil then B["Create PX83-Enigmatron"] = "PX83-Enigmatron Yarat" end
if B["Create Pamela's Doll"] == nil then B["Create Pamela's Doll"] = "Pamela'nın Bebeği Yarat" end
if B["Create Relic Bundle"] == nil then B["Create Relic Bundle"] = "Kalıntı Demeti Yarat" end
if B["Create Samophlange Manual"] == nil then B["Create Samophlange Manual"] = "Samophlange Kılavuzu Yarat" end
if B["Create Scepter of Beckoning: Air"] == nil then B["Create Scepter of Beckoning: Air"] = "Çağrı Asası Yarat: Hava" end
if B["Create Scepter of Beckoning: Earth"] == nil then B["Create Scepter of Beckoning: Earth"] = "Çağrı Asası Yarat: Toprak" end
if B["Create Scepter of Beckoning: Fire"] == nil then B["Create Scepter of Beckoning: Fire"] = "Çağrı Asası Yarat: Ateş" end
if B["Create Scepter of Beckoning: Water"] == nil then B["Create Scepter of Beckoning: Water"] = "Çağrı Asası Yarat: Su" end
if B["Create Scrying Bowl"] == nil then B["Create Scrying Bowl"] = "Kehanet Kâsesi Yarat" end
if B["Create Shredder"] == nil then B["Create Shredder"] = "Shredder Yarat" end
if B["Create Signet of Beckoning: Air"] == nil then B["Create Signet of Beckoning: Air"] = "Çağrı Mührü Yarat: Hava" end
if B["Create Signet of Beckoning: Earth"] == nil then B["Create Signet of Beckoning: Earth"] = "Çağrı Mührü Yarat: Toprak" end
if B["Create Signet of Beckoning: Fire"] == nil then B["Create Signet of Beckoning: Fire"] = "Çağrı Mührü Yarat: Ateş" end
if B["Create Signet of Beckoning: Water"] == nil then B["Create Signet of Beckoning: Water"] = "Çağrı Mührü Yarat: Su" end
if B["Create Stormwind Bundle of Cards"] == nil then B["Create Stormwind Bundle of Cards"] = "Stormwind Kart Destesi Yarat" end
if B["Create Stormwind Pledges of Loyalty"] == nil then B["Create Stormwind Pledges of Loyalty"] = "Stormwind Sadakat Yeminleri Yarat" end
if B["Create Stormwind Sack of Homemade Bread"] == nil then B["Create Stormwind Sack of Homemade Bread"] = "Stormwind Ev Yapımı Ekmek Torbası Yarat" end
if B["Create Thunder Bluff Basket of Flowers"] == nil then B["Create Thunder Bluff Basket of Flowers"] = "Thunder Bluff Çiçek Sepeti Yarat" end
if B["Create Thunder Bluff Pledges of Loyalty"] == nil then B["Create Thunder Bluff Pledges of Loyalty"] = "Thunder Bluff Sadakat Yeminleri Yarat" end
if B["Create Thunder Bluff Satchel of Cards"] == nil then B["Create Thunder Bluff Satchel of Cards"] = "Thunder Bluff Kart Heybesi Yarat" end
if B["Create Undercity Book of Romantic Poetry"] == nil then B["Create Undercity Book of Romantic Poetry"] = "Undercity Romantik Şiir Kitabı Yarat" end
if B["Create Undercity Pledges of Loyalty"] == nil then B["Create Undercity Pledges of Loyalty"] = "Undercity Sadakat Yeminleri Yarat" end
if B["Create Undercity Sheaf of Cards"] == nil then B["Create Undercity Sheaf of Cards"] = "Undercity Kart Destesi Yarat" end
if B["Create Weegli's Barrel"] == nil then B["Create Weegli's Barrel"] = "Weegli'nin Fıçısı Yarat" end
if B["Create Witherbark Totem Bundle"] == nil then B["Create Witherbark Totem Bundle"] = "Witherbark Totem Demeti Yarat" end
if B["Creeping Mold"] == nil then B["Creeping Mold"] = "Sürünen Küf" end
if B["Crest of Retribution"] == nil then B["Crest of Retribution"] = "İntikam Arması" end
if B["Cripple"] == nil then B["Cripple"] = "Sakatla" end
if B["Crude Scope"] == nil then B["Crude Scope"] = "Kaba Dürbün" end
if B["Crystal Charge"] == nil then B["Crystal Charge"] = "Kristal Yükü" end
if B["Crystal Force"] == nil then B["Crystal Force"] = "Kristal Gücü" end
if B["Crystal Infused Bandage"] == nil then B["Crystal Infused Bandage"] = "Kristal Aşılı Sargı" end
if B["Crystal Prison"] == nil then B["Crystal Prison"] = "Kristal Hapishane" end
if B["Crystal Protection"] == nil then B["Crystal Protection"] = "Kristal Koruma" end
if B["Crystal Restore"] == nil then B["Crystal Restore"] = "Kristal Onarımı" end
if B["Crystal Spire"] == nil then B["Crystal Spire"] = "Kristal Kule" end
if B["Crystal Throat Lozenge"] == nil then B["Crystal Throat Lozenge"] = "Kristal Boğaz Pastili" end
if B["Crystal Ward"] == nil then B["Crystal Ward"] = "Kristal Siper" end
if B["Crystal Yield"] == nil then B["Crystal Yield"] = "Kristal Verimi" end
if B["Crystal of Zin-Malor"] == nil then B["Crystal of Zin-Malor"] = "Zin-Malor Kristali" end
if B["Cultivate Packet of Seeds"] == nil then B["Cultivate Packet of Seeds"] = "Tohum Paketini Yetiştir" end
if B["Cure Ailments"] == nil then B["Cure Ailments"] = "Hastalıkları İyileştir" end
if B["Curse of Archimonde"] == nil then B["Curse of Archimonde"] = "Archimonde'un Laneti" end
if B["Curse of Stalvan"] == nil then B["Curse of Stalvan"] = "Stalvan'ın Laneti" end
if B["Curse of Timmy"] == nil then B["Curse of Timmy"] = "Timmy'nin Laneti" end
if B["DEBUG Create Samophlange Manual"] == nil then B["DEBUG Create Samophlange Manual"] = "DEBUG Samophlange Kılavuzu Yarat" end
if B["Dalaran Wizard Disguise"] == nil then B["Dalaran Wizard Disguise"] = "Dalaran Büyücüsü Kılığı" end
if B["Damage Absorb"] == nil then B["Damage Absorb"] = "Hasar Emme" end
if B["Dark Desire"] == nil then B["Dark Desire"] = "Karanlık Arzu" end
if B["Dark Iron Bomb"] == nil then B["Dark Iron Bomb"] = "Kara Demir Bombası" end
if B["Dark Iron Dwarf Disguise"] == nil then B["Dark Iron Dwarf Disguise"] = "Dark Iron Cücesi Kılığı" end
if B["Dark Rune"] == nil then B["Dark Rune"] = "Karanlık Rün" end
if B["Darnassus Gift of Friendship"] == nil then B["Darnassus Gift of Friendship"] = "Darnassus Dostluk Armağanı" end
if B["Dawn's Gambit"] == nil then B["Dawn's Gambit"] = "Şafağın Hamlesi" end
if B["Dazed"] == nil then B["Dazed"] = "Sersemlemiş" end
if B["Deadly Poison II"] == nil then B["Deadly Poison II"] = "Ölümcül Zehir II" end
if B["Deadly Poison III"] == nil then B["Deadly Poison III"] = "Ölümcül Zehir III" end
if B["Deadly Poison IV"] == nil then B["Deadly Poison IV"] = "Ölümcül Zehir IV" end
if B["Deadly Poison V"] == nil then B["Deadly Poison V"] = "Ölümcül Zehir V" end
if B["Deadly Scope"] == nil then B["Deadly Scope"] = "Ölümcül Dürbün" end
if B["Death Touch"] == nil then B["Death Touch"] = "Ölüm Dokunuşu" end
if B["Death by Peasant"] == nil then B["Death by Peasant"] = "Köylü Eliyle Ölüm" end
if B["Death's Embrace"] == nil then B["Death's Embrace"] = "Ölümün Kucaklaması" end
if B["Deathcharger"] == nil then B["Deathcharger"] = "Ölüm Atı" end
if B["Decapitate"] == nil then B["Decapitate"] = "Kafa Kes" end
if B["Decayed Strength"] == nil then B["Decayed Strength"] = "Çürümüş Güç" end
if B["Decreased Parry 1"] == nil then B["Decreased Parry 1"] = "Azaltılmış Savuşturma 1" end
if B["Defender of the Timbermaw"] == nil then B["Defender of the Timbermaw"] = "Timbermaw Savunucusu" end
if B["Defense +3"] == nil then B["Defense +3"] = "Savunma +3" end
if B["Defias Disguise"] == nil then B["Defias Disguise"] = "Defias Kılığı" end
if B["Defibrillate"] == nil then B["Defibrillate"] = "Şok Ver" end
if B["Demon Breath"] == nil then B["Demon Breath"] = "İblis Nefesi" end
if B["Demon Forged Breastplate"] == nil then B["Demon Forged Breastplate"] = "İblis Dövmesi Göğüs Zırhı" end
if B["Demon Pick"] == nil then B["Demon Pick"] = "İblis Kazması" end
if B["Demon Slaying 117"] == nil then B["Demon Slaying 117"] = "İblis Avcılığı 117" end
if B["Demon Slaying 33"] == nil then B["Demon Slaying 33"] = "İblis Avcılığı 33" end
if B["Demon Slaying 45"] == nil then B["Demon Slaying 45"] = "İblis Avcılığı 45" end
if B["Demon Slaying 78"] == nil then B["Demon Slaying 78"] = "İblis Avcılığı 78" end
if B["Demon Slaying 99"] == nil then B["Demon Slaying 99"] = "İblis Avcılığı 99" end
if B["Demon Summoning Torch"] == nil then B["Demon Summoning Torch"] = "İblis Çağırma Meşalesi" end
if B["Demonfork"] == nil then B["Demonfork"] = "İblis Çatalı" end
if B["Demonic Rune"] == nil then B["Demonic Rune"] = "İblisî Rün" end
if B["Dense Dynamite"] == nil then B["Dense Dynamite"] = "Yoğun Dinamit" end
if B["Deputize Agent of Nozdormu"] == nil then B["Deputize Agent of Nozdormu"] = "Nozdormu Ajanı Ata" end
if B["Destiny"] == nil then B["Destiny"] = "Kader" end
if B["Destroy Bijou"] == nil then B["Destroy Bijou"] = "Bijou'yu Yok Et" end
if B["Destroy Tent"] == nil then B["Destroy Tent"] = "Çadırı Yok Et" end
if B["Detect Demon"] == nil then B["Detect Demon"] = "İblis Algıla" end
if B["Detect Elven Gems"] == nil then B["Detect Elven Gems"] = "Elf Mücevherlerini Algıla" end
if B["Detect Gahz'ridian"] == nil then B["Detect Gahz'ridian"] = "Gahz'ridian Algıla" end
if B["Detect Undead"] == nil then B["Detect Undead"] = "Ölümsüz Algıla" end
if B["Detonate"] == nil then B["Detonate"] = "Patlat" end
if B["Deviate Fish"] == nil then B["Deviate Fish"] = "Sapkın Balık" end
if B["Devilsaur Barb"] == nil then B["Devilsaur Barb"] = "Devilsaur Dikeni" end
if B["Devilsaur Fury"] == nil then B["Devilsaur Fury"] = "Devilsaur Öfkesi" end
if B["Devotion Armor Increased"] == nil then B["Devotion Armor Increased"] = "Bağlılık Zırhı Artırıldı" end
if B["Devour Magic"] == nil then B["Devour Magic"] = "Büyüyü Yut" end
if B["Diamond Flask"] == nil then B["Diamond Flask"] = "Elmas Şişe" end
if B["Digging for Cobalt"] == nil then B["Digging for Cobalt"] = "Kobalt İçin Kazılıyor" end
if B["Dimensional Siphon"] == nil then B["Dimensional Siphon"] = "Boyutsal Sifon" end
if B["Dire Wolf"] == nil then B["Dire Wolf"] = "Vahşi Kurt" end
if B["Discombobulate"] == nil then B["Discombobulate"] = "Sersemlet" end
if B["Dispel Poison"] == nil then B["Dispel Poison"] = "Zehri Dağıt" end
if B["Displacing Temporal Rift"] == nil then B["Displacing Temporal Rift"] = "Zamansal Yarık Yerinden Oynatılıyor" end
if B["Disruption"] == nil then B["Disruption"] = "Bozulma" end
if B["Distilled Wisdom"] == nil then B["Distilled Wisdom"] = "Damıtılmış Bilgelik" end
if B["Divine Escape"] == nil then B["Divine Escape"] = "İlahi Kaçış" end
if B["Divining Scroll Spell"] == nil then B["Divining Scroll Spell"] = "Kehanet Parşömeni Büyüsü" end
if B["Dominion of Soul"] == nil then B["Dominion of Soul"] = "Ruh Hâkimiyeti" end
if B["Dousing"] == nil then B["Dousing"] = "Söndürülüyor" end
if B["Dowse Eternal Flame"] == nil then B["Dowse Eternal Flame"] = "Ebedi Alevi Söndür" end
if B["Dowsing"] == nil then B["Dowsing"] = "Söndürülüyor" end
if B["Dragon Slaying 117"] == nil then B["Dragon Slaying 117"] = "Ejderha Avcılığı 117" end
if B["Dragon Slaying 48"] == nil then B["Dragon Slaying 48"] = "Ejderha Avcılığı 48" end
if B["Dragon's Call"] == nil then B["Dragon's Call"] = "Ejderin Çağrısı" end
if B["Dragonbreath Chili"] == nil then B["Dragonbreath Chili"] = "Ejder Nefesi Chili" end
if B["Draw Ancient Glyphs"] == nil then B["Draw Ancient Glyphs"] = "Kadim Sembolleri Çiz" end
if B["Draw Water Sample"] == nil then B["Draw Water Sample"] = "Su Numunesi Al" end
if B["Drawing Kit"] == nil then B["Drawing Kit"] = "Çizim Takımı" end
if B["Dream Vision"] == nil then B["Dream Vision"] = "Rüya Görüsü" end
if B["Dreamless Sleep"] == nil then B["Dreamless Sleep"] = "Rüyasız Uyku" end
if B["Drink"] == nil then B["Drink"] = "İç" end
if B["Drive Nimboya's Laden Pike"] == nil then B["Drive Nimboya's Laden Pike"] = "Nimboya'nın Yüklü Mızrağını Sapla" end
if B["Earthen Sigil"] == nil then B["Earthen Sigil"] = "Toprak Mührü" end
if B["Earthshaker"] == nil then B["Earthshaker"] = "Yer Sarsan" end
if B["Earthstrike"] == nil then B["Earthstrike"] = "Toprak Darbesi" end
if B["Echo of Archimonde"] == nil then B["Echo of Archimonde"] = "Archimonde'un Yankısı" end
if B["Ectoplasmic Distiller"] == nil then B["Ectoplasmic Distiller"] = "Ektoplazmik Damıtıcı" end
if B["Egan's Blaster"] == nil then B["Egan's Blaster"] = "Egan'ın Patlatıcısı" end
if B["Egg Nog"] == nil then B["Egg Nog"] = "Yumurta Likörü" end
if B["Elderberry Pie"] == nil then B["Elderberry Pie"] = "Mürver Turtası" end
if B["Electric Discharge"] == nil then B["Electric Discharge"] = "Elektrik Boşalması" end
if B["Electromagnetic Gigaflux Reactivator"] == nil then B["Electromagnetic Gigaflux Reactivator"] = "Elektromanyetik Gigaflux Yeniden Etkinleştirici" end
if B["Electrostatic Charge"] == nil then B["Electrostatic Charge"] = "Elektrostatik Yük" end
if B["Elemental Protection"] == nil then B["Elemental Protection"] = "Elemental Koruma" end
if B["Elemental Slaying 36"] == nil then B["Elemental Slaying 36"] = "Elemental Avcılığı 36" end
if B["Elementals Deck"] == nil then B["Elementals Deck"] = "Elementaller Destesi" end
if B["Elixir of Brute Force"] == nil then B["Elixir of Brute Force"] = "Kaba Kuvvet Eliksiri" end
if B["Elixir of Demonslaying"] == nil then B["Elixir of Demonslaying"] = "İblis Avcılığı Eliksiri" end
if B["Elixir of Dodging"] == nil then B["Elixir of Dodging"] = "Kaçınma Eliksiri" end
if B["Elixir of Resistance"] == nil then B["Elixir of Resistance"] = "Direnç Eliksiri" end
if B["Elixir of the Giants"] == nil then B["Elixir of the Giants"] = "Devler Eliksiri" end
if B["Elixir of the Mongoose"] == nil then B["Elixir of the Mongoose"] = "Firavunfaresi Eliksiri" end
if B["Elixir of the Sages"] == nil then B["Elixir of the Sages"] = "Bilgeler Eliksiri" end
if B["Elune's Candle"] == nil then B["Elune's Candle"] = "Elune'un Mumu" end
if B["Emerald Raptor"] == nil then B["Emerald Raptor"] = "Zümrüt Raptor" end
if B["Empty Charm Pouch"] == nil then B["Empty Charm Pouch"] = "Tılsım Kesesini Boşalt" end
if B["Empty Festive Mug"] == nil then B["Empty Festive Mug"] = "Boş Bayram Kupası" end
if B["Empty Phial"] == nil then B["Empty Phial"] = "Şişeyi Boşalt" end
if B["Enchant: Fiery Blaze"] == nil then B["Enchant: Fiery Blaze"] = "Efsun: Alevli Ateş" end
if B["Enchanted Gaea Seed"] == nil then B["Enchanted Gaea Seed"] = "Efsunlu Gaea Tohumu" end
if B["Enchanted Resonite Crystal"] == nil then B["Enchanted Resonite Crystal"] = "Efsunlu Resonite Kristali" end
if B["Energized Shield"] == nil then B["Energized Shield"] = "Enerji Yüklü Kalkan" end
if B["Engulfing Shadows"] == nil then B["Engulfing Shadows"] = "Saran Gölgeler" end
if B["Enhance Blunt Weapon"] == nil then B["Enhance Blunt Weapon"] = "Kör Silahı Güçlendir" end
if B["Enhance Blunt Weapon II"] == nil then B["Enhance Blunt Weapon II"] = "Kör Silahı Güçlendir II" end
if B["Enhance Blunt Weapon III"] == nil then B["Enhance Blunt Weapon III"] = "Kör Silahı Güçlendir III" end
if B["Enhance Blunt Weapon IV"] == nil then B["Enhance Blunt Weapon IV"] = "Kör Silahı Güçlendir IV" end
if B["Enhance Blunt Weapon V"] == nil then B["Enhance Blunt Weapon V"] = "Kör Silahı Güçlendir V" end
if B["Enlarge"] == nil then B["Enlarge"] = "Büyüt" end
if B["Enriched Manna Biscuit"] == nil then B["Enriched Manna Biscuit"] = "Zenginleştirilmiş Manna Bisküvisi" end
if B["Ephemeral Power"] == nil then B["Ephemeral Power"] = "Geçici Güç" end
if B["Eskhandar's Rage"] == nil then B["Eskhandar's Rage"] = "Eskhandar'ın Öfkesi" end
if B["Eskhandar's Rake"] == nil then B["Eskhandar's Rake"] = "Eskhandar'ın Pençesi" end
if B["Essence Mango"] == nil then B["Essence Mango"] = "Öz Mangosu" end
if B["Essence of Sapphiron"] == nil then B["Essence of Sapphiron"] = "Sapphiron'un Özü" end
if B["Eternium Fishing Line"] == nil then B["Eternium Fishing Line"] = "Eternium Olta İpi" end
if B["Ethereal Form"] == nil then B["Ethereal Form"] = "Eterik Biçim" end
if B["Everlook Transporter"] == nil then B["Everlook Transporter"] = "Everlook Taşıyıcısı" end
if B["Exorcise Atiesh"] == nil then B["Exorcise Atiesh"] = "Atiesh'i Arındır" end
if B["Exorcise Spirits"] == nil then B["Exorcise Spirits"] = "Ruhları Kov" end
if B["Expert Cook"] == nil then B["Expert Cook"] = "Uzman Aşçı" end
if B["Expert First Aid"] == nil then B["Expert First Aid"] = "Uzman İlk Yardım" end
if B["Expert Fishing"] == nil then B["Expert Fishing"] = "Uzman Balıkçılık" end
if B["Explosive Sheep"] == nil then B["Explosive Sheep"] = "Patlayıcı Koyun" end
if B["Extinguish"] == nil then B["Extinguish"] = "Söndür" end
if B["Extra-Dimensional Ghost Revealer"] == nil then B["Extra-Dimensional Ghost Revealer"] = "Boyutlar Ötesi Hayalet Gösterici" end
if B["Eye of Divinity"] == nil then B["Eye of Divinity"] = "İlahiyat Gözü" end
if B["Eye of Sulfuras"] == nil then B["Eye of Sulfuras"] = "Sulfuras'ın Gözü" end
if B["Ez-Thro Dynamite"] == nil then B["Ez-Thro Dynamite"] = "Kolay Atış Dinamiti" end
if B["Falcon's Call"] == nil then B["Falcon's Call"] = "Şahinin Çağrısı" end
if B["Fang of the Crystal Spider"] == nil then B["Fang of the Crystal Spider"] = "Kristal Örümceğin Dişi" end
if B["Faster Healing Touch Cast"] == nil then B["Faster Healing Touch Cast"] = "Daha Hızlı Healing Touch Kullanımı" end
if B["Fatal Wound"] == nil then B["Fatal Wound"] = "Ölümcül Yara" end
if B["Fear Resistance 4"] == nil then B["Fear Resistance 4"] = "Korku Direnci 4" end
if B["Fearless"] == nil then B["Fearless"] = "Korkusuz" end
if B["Feather Fall"] == nil then B["Feather Fall"] = "Tüy Düşüşü" end
if B["Fel Curse"] == nil then B["Fel Curse"] = "Fel Laneti" end
if B["Fervor"] == nil then B["Fervor"] = "Şevk" end
if B["Field Repair Bot 74A"] == nil then B["Field Repair Bot 74A"] = "Saha Tamir Robotu 74A" end
if B["Fiery Aura"] == nil then B["Fiery Aura"] = "Alevli Aura" end
if B["Fill Amethyst Phial"] == nil then B["Fill Amethyst Phial"] = "Ametist Şişeyi Doldur" end
if B["Fill Deino's Flask"] == nil then B["Fill Deino's Flask"] = "Deino'nun Matarasını Doldur" end
if B["Fill Jennea's Flask"] == nil then B["Fill Jennea's Flask"] = "Jennea'nın Matarasını Doldur" end
if B["Fill Nagmara's Vial"] == nil then B["Fill Nagmara's Vial"] = "Nagmara'nın Şişesini Doldur" end
if B["Fill the Egg of Hakkar"] == nil then B["Fill the Egg of Hakkar"] = "Hakkar Yumurtasını Doldur" end
if B["Filling"] == nil then B["Filling"] = "Dolduruluyor" end
if B["Filling Empty Jar"] == nil then B["Filling Empty Jar"] = "Boş Kavanoz Dolduruluyor" end
if B["Find Relic Fragment"] == nil then B["Find Relic Fragment"] = "Kalıntı Parçası Bul" end
if B["Finkle's Skinner"] == nil then B["Finkle's Skinner"] = "Finkle'ın Yüzme Bıçağı" end
if B["Fire Cannon"] == nil then B["Fire Cannon"] = "Ateş Topu" end
if B["Fire Power"] == nil then B["Fire Power"] = "Ateş Gücü" end
if B["Fire Protection"] == nil then B["Fire Protection"] = "Ateş Koruması" end
if B["Fire Reflector"] == nil then B["Fire Reflector"] = "Ateş Yansıtıcı" end
if B["Fire Shield"] == nil then B["Fire Shield"] = "Ateş Kalkanı" end
if B["Fire's Glow"] == nil then B["Fire's Glow"] = "Ateşin Işıltısı" end
if B["Fire-toasted Bun"] == nil then B["Fire-toasted Bun"] = "Ateşte Kızarmış Çörek" end
if B["Firebolt"] == nil then B["Firebolt"] = "Ateş Oku" end
if B["Firecrackers"] == nil then B["Firecrackers"] = "Kestane Fişekleri" end
if B["Firestone Passive"] == nil then B["Firestone Passive"] = "Ateş Taşı Pasif" end
if B["Firework"] == nil then B["Firework"] = "Havai Fişek" end
if B["Fishing Skill +15"] == nil then B["Fishing Skill +15"] = "Balıkçılık Becerisi +15" end
if B["Fishing Skill +20"] == nil then B["Fishing Skill +20"] = "Balıkçılık Becerisi +20" end
if B["Fishing Skill +25"] == nil then B["Fishing Skill +25"] = "Balıkçılık Becerisi +25" end
if B["Fishing Skill +3"] == nil then B["Fishing Skill +3"] = "Balıkçılık Becerisi +3" end
if B["Fishing Skill +35"] == nil then B["Fishing Skill +35"] = "Balıkçılık Becerisi +35" end
if B["Fishing Skill +5"] == nil then B["Fishing Skill +5"] = "Balıkçılık Becerisi +5" end
if B["Fishliver Oil"] == nil then B["Fishliver Oil"] = "Balık Karaciğeri Yağı" end
if B["Fist of Stone"] == nil then B["Fist of Stone"] = "Taş Yumruk" end
if B["Fix Ritual Node"] == nil then B["Fix Ritual Node"] = "Ritüel Düğümünü Onar" end
if B["Flame Lash"] == nil then B["Flame Lash"] = "Alev Kırbacı" end
if B["Flame Mantle of the Dawn"] == nil then B["Flame Mantle of the Dawn"] = "Şafağın Alev Omuzluğu" end
if B["Flame Wrath"] == nil then B["Flame Wrath"] = "Alev Gazabı" end
if B["Flames of Retribution"] == nil then B["Flames of Retribution"] = "İntikam Alevleri" end
if B["Flaming Cannonball"] == nil then B["Flaming Cannonball"] = "Alevli Top Güllesi" end
if B["Flaming Shell"] == nil then B["Flaming Shell"] = "Alevli Kabuk" end
if B["Flash Bomb"] == nil then B["Flash Bomb"] = "Flaş Bombası" end
if B["Flask of the Titans"] == nil then B["Flask of the Titans"] = "Titanlar Şişesi" end
if B["Flee"] == nil then B["Flee"] = "Kaç" end
if B["Flesh Eating Worm"] == nil then B["Flesh Eating Worm"] = "Et Yiyen Solucan" end
if B["Fluorescent Green Mechanostrider"] == nil then B["Fluorescent Green Mechanostrider"] = "Floresan Yeşil Mechanostrider" end
if B["Flurry Axe"] == nil then B["Flurry Axe"] = "Sağanak Baltası" end
if B["Focus"] == nil then B["Focus"] = "Odak" end
if B["Focusing"] == nil then B["Focusing"] = "Odaklanılıyor" end
if B["Food"] == nil then B["Food"] = "Yiyecek" end
if B["Force Reactive Disk"] == nil then B["Force Reactive Disk"] = "Kuvvet Tepkili Disk" end
if B["Force of Will"] == nil then B["Force of Will"] = "İrade Gücü" end
if B["Forging"] == nil then B["Forging"] = "Dövülüyor" end
if B["Form of the Moonstalker"] == nil then B["Form of the Moonstalker"] = "Moonstalker Biçimi" end
if B["Forming Frame of Atiesh"] == nil then B["Forming Frame of Atiesh"] = "Atiesh'in Çerçevesi Şekilleniyor" end
if B["Forming Rhok'delar"] == nil then B["Forming Rhok'delar"] = "Rhok'delar Şekilleniyor" end
if B["Formula: Brilliant Mana Oil"] == nil then B["Formula: Brilliant Mana Oil"] = "Formül: Parlak Mana Yağı" end
if B["Formula: Brilliant Wizard Oil"] == nil then B["Formula: Brilliant Wizard Oil"] = "Formül: Parlak Büyücü Yağı" end
if B["Formula: Enchant 2H Weapon - Agility"] == nil then B["Formula: Enchant 2H Weapon - Agility"] = "Formül: İki El Silahı Efsunu - Çeviklik" end
if B["Formula: Enchant 2H Weapon - Intellect"] == nil then B["Formula: Enchant 2H Weapon - Intellect"] = "Formül: İki El Silahı Efsunu - Zekâ" end
if B["Formula: Enchant 2H Weapon - Major Intellect"] == nil then B["Formula: Enchant 2H Weapon - Major Intellect"] = "Formül: İki El Silahı Efsunu - Muazzam Zekâ" end
if B["Formula: Enchant 2H Weapon - Major Spirit"] == nil then B["Formula: Enchant 2H Weapon - Major Spirit"] = "Formül: İki El Silahı Efsunu - Muazzam Ruh" end
if B["Formula: Enchant 2H Weapon - Spirit"] == nil then B["Formula: Enchant 2H Weapon - Spirit"] = "Formül: İki El Silahı Efsunu - Ruh" end
if B["Formula: Enchant Boots - Greater Agility"] == nil then B["Formula: Enchant Boots - Greater Agility"] = "Formül: Çizme Efsunu - Büyük Çeviklik" end
if B["Formula: Enchant Boots - Greater Stamina"] == nil then B["Formula: Enchant Boots - Greater Stamina"] = "Formül: Çizme Efsunu - Büyük Dayanıklılık" end
if B["Formula: Enchant Boots - Lesser Spirit"] == nil then B["Formula: Enchant Boots - Lesser Spirit"] = "Formül: Çizme Efsunu - Küçük Ruh" end
if B["Formula: Enchant Boots - Minor Agility"] == nil then B["Formula: Enchant Boots - Minor Agility"] = "Formül: Çizme Efsunu - Ufak Çeviklik" end
if B["Formula: Enchant Boots - Minor Stamina"] == nil then B["Formula: Enchant Boots - Minor Stamina"] = "Formül: Çizme Efsunu - Ufak Dayanıklılık" end
if B["Formula: Enchant Boots - Spirit"] == nil then B["Formula: Enchant Boots - Spirit"] = "Formül: Çizme Efsunu - Ruh" end
if B["Formula: Enchant Bracer - Deflection"] == nil then B["Formula: Enchant Bracer - Deflection"] = "Formül: Bileklik Efsunu - Saptırma" end
if B["Formula: Enchant Bracer - Greater Intellect"] == nil then B["Formula: Enchant Bracer - Greater Intellect"] = "Formül: Bileklik Efsunu - Büyük Zekâ" end
if B["Formula: Enchant Bracer - Greater Spirit"] == nil then B["Formula: Enchant Bracer - Greater Spirit"] = "Formül: Bileklik Efsunu - Büyük Ruh" end
if B["Formula: Enchant Bracer - Greater Stamina"] == nil then B["Formula: Enchant Bracer - Greater Stamina"] = "Formül: Bileklik Efsunu - Büyük Dayanıklılık" end
if B["Formula: Enchant Bracer - Healing"] == nil then B["Formula: Enchant Bracer - Healing"] = "Formül: Bileklik Efsunu - İyileştirme" end
if B["Formula: Enchant Bracer - Lesser Deflection"] == nil then B["Formula: Enchant Bracer - Lesser Deflection"] = "Formül: Bileklik Efsunu - Küçük Saptırma" end
if B["Formula: Enchant Bracer - Lesser Spirit"] == nil then B["Formula: Enchant Bracer - Lesser Spirit"] = "Formül: Bileklik Efsunu - Küçük Ruh" end
if B["Formula: Enchant Bracer - Lesser Strength"] == nil then B["Formula: Enchant Bracer - Lesser Strength"] = "Formül: Bileklik Efsunu - Küçük Güç" end
if B["Formula: Enchant Bracer - Mana Regeneration"] == nil then B["Formula: Enchant Bracer - Mana Regeneration"] = "Formül: Bileklik Efsunu - Mana Yenilenmesi" end
if B["Formula: Enchant Bracer - Minor Spirit"] == nil then B["Formula: Enchant Bracer - Minor Spirit"] = "Formül: Bileklik Efsunu - Ufak Ruh" end
if B["Formula: Enchant Bracer - Minor Strength"] == nil then B["Formula: Enchant Bracer - Minor Strength"] = "Formül: Bileklik Efsunu - Ufak Güç" end
if B["Formula: Enchant Bracer - Superior Spirit"] == nil then B["Formula: Enchant Bracer - Superior Spirit"] = "Formül: Bileklik Efsunu - Üstün Ruh" end
if B["Formula: Enchant Bracer - Superior Stamina"] == nil then B["Formula: Enchant Bracer - Superior Stamina"] = "Formül: Bileklik Efsunu - Üstün Dayanıklılık" end
if B["Formula: Enchant Bracer - Superior Strength"] == nil then B["Formula: Enchant Bracer - Superior Strength"] = "Formül: Bileklik Efsunu - Üstün Güç" end
if B["Formula: Enchant Chest - Greater Stats"] == nil then B["Formula: Enchant Chest - Greater Stats"] = "Formül: Göğüs Efsunu - Büyük Nitelikler" end
if B["Formula: Enchant Chest - Lesser Mana"] == nil then B["Formula: Enchant Chest - Lesser Mana"] = "Formül: Göğüs Efsunu - Küçük Mana" end
if B["Formula: Enchant Chest - Major Health"] == nil then B["Formula: Enchant Chest - Major Health"] = "Formül: Göğüs Efsunu - Muazzam Sağlık" end
if B["Formula: Enchant Chest - Major Mana"] == nil then B["Formula: Enchant Chest - Major Mana"] = "Formül: Göğüs Efsunu - Muazzam Mana" end
if B["Formula: Enchant Chest - Minor Mana"] == nil then B["Formula: Enchant Chest - Minor Mana"] = "Formül: Göğüs Efsunu - Ufak Mana" end
if B["Formula: Enchant Cloak - Dodge"] == nil then B["Formula: Enchant Cloak - Dodge"] = "Formül: Pelerin Efsunu - Kaçınma" end
if B["Formula: Enchant Cloak - Greater Fire Resistance"] == nil then B["Formula: Enchant Cloak - Greater Fire Resistance"] = "Formül: Pelerin Efsunu - Büyük Ateş Direnci" end
if B["Formula: Enchant Cloak - Greater Nature Resistance"] == nil then B["Formula: Enchant Cloak - Greater Nature Resistance"] = "Formül: Pelerin Efsunu - Büyük Doğa Direnci" end
if B["Formula: Enchant Cloak - Greater Resistance"] == nil then B["Formula: Enchant Cloak - Greater Resistance"] = "Formül: Pelerin Efsunu - Büyük Direnç" end
if B["Formula: Enchant Cloak - Lesser Agility"] == nil then B["Formula: Enchant Cloak - Lesser Agility"] = "Formül: Pelerin Efsunu - Küçük Çeviklik" end
if B["Formula: Enchant Cloak - Lesser Shadow Resistance"] == nil then B["Formula: Enchant Cloak - Lesser Shadow Resistance"] = "Formül: Pelerin Efsunu - Küçük Gölge Direnci" end
if B["Formula: Enchant Cloak - Minor Agility"] == nil then B["Formula: Enchant Cloak - Minor Agility"] = "Formül: Pelerin Efsunu - Ufak Çeviklik" end
if B["Formula: Enchant Cloak - Minor Protection"] == nil then B["Formula: Enchant Cloak - Minor Protection"] = "Formül: Pelerin Efsunu - Ufak Koruma" end
if B["Formula: Enchant Cloak - Stealth"] == nil then B["Formula: Enchant Cloak - Stealth"] = "Formül: Pelerin Efsunu - Gizlilik" end
if B["Formula: Enchant Cloak - Subtlety"] == nil then B["Formula: Enchant Cloak - Subtlety"] = "Formül: Pelerin Efsunu - İncelik" end
if B["Formula: Enchant Cloak - Superior Defense"] == nil then B["Formula: Enchant Cloak - Superior Defense"] = "Formül: Pelerin Efsunu - Üstün Savunma" end
if B["Formula: Enchant Gloves - Advanced Herbalism"] == nil then B["Formula: Enchant Gloves - Advanced Herbalism"] = "Formül: Eldiven Efsunu - İleri Bitkicilik" end
if B["Formula: Enchant Gloves - Advanced Mining"] == nil then B["Formula: Enchant Gloves - Advanced Mining"] = "Formül: Eldiven Efsunu - İleri Madencilik" end
if B["Formula: Enchant Gloves - Fire Power"] == nil then B["Formula: Enchant Gloves - Fire Power"] = "Formül: Eldiven Efsunu - Ateş Gücü" end
if B["Formula: Enchant Gloves - Fishing"] == nil then B["Formula: Enchant Gloves - Fishing"] = "Formül: Eldiven Efsunu - Balıkçılık" end
if B["Formula: Enchant Gloves - Frost Power"] == nil then B["Formula: Enchant Gloves - Frost Power"] = "Formül: Eldiven Efsunu - Buz Gücü" end
if B["Formula: Enchant Gloves - Greater Agility"] == nil then B["Formula: Enchant Gloves - Greater Agility"] = "Formül: Eldiven Efsunu - Büyük Çeviklik" end
if B["Formula: Enchant Gloves - Greater Strength"] == nil then B["Formula: Enchant Gloves - Greater Strength"] = "Formül: Eldiven Efsunu - Büyük Güç" end
if B["Formula: Enchant Gloves - Healing Power"] == nil then B["Formula: Enchant Gloves - Healing Power"] = "Formül: Eldiven Efsunu - İyileştirme Gücü" end
if B["Formula: Enchant Gloves - Herbalism"] == nil then B["Formula: Enchant Gloves - Herbalism"] = "Formül: Eldiven Efsunu - Bitkicilik" end
if B["Formula: Enchant Gloves - Mining"] == nil then B["Formula: Enchant Gloves - Mining"] = "Formül: Eldiven Efsunu - Madencilik" end
if B["Formula: Enchant Gloves - Minor Riding"] == nil then B["Formula: Enchant Gloves - Minor Riding"] = "Formül: Eldiven Efsunu - Ufak Binicilik" end
if B["Formula: Enchant Gloves - Shadow Power"] == nil then B["Formula: Enchant Gloves - Shadow Power"] = "Formül: Eldiven Efsunu - Gölge Gücü" end
if B["Formula: Enchant Gloves - Skinning"] == nil then B["Formula: Enchant Gloves - Skinning"] = "Formül: Eldiven Efsunu - Deri Yüzme" end
if B["Formula: Enchant Gloves - Superior Agility"] == nil then B["Formula: Enchant Gloves - Superior Agility"] = "Formül: Eldiven Efsunu - Üstün Çeviklik" end
if B["Formula: Enchant Gloves - Threat"] == nil then B["Formula: Enchant Gloves - Threat"] = "Formül: Eldiven Efsunu - Tehdit" end
if B["Formula: Enchant Shield - Frost Resistance"] == nil then B["Formula: Enchant Shield - Frost Resistance"] = "Formül: Kalkan Efsunu - Buz Direnci" end
if B["Formula: Enchant Shield - Greater Stamina"] == nil then B["Formula: Enchant Shield - Greater Stamina"] = "Formül: Kalkan Efsunu - Büyük Dayanıklılık" end
if B["Formula: Enchant Shield - Lesser Blocking"] == nil then B["Formula: Enchant Shield - Lesser Blocking"] = "Formül: Kalkan Efsunu - Küçük Bloklama" end
if B["Formula: Enchant Shield - Lesser Protection"] == nil then B["Formula: Enchant Shield - Lesser Protection"] = "Formül: Kalkan Efsunu - Küçük Koruma" end
if B["Formula: Enchant Shield - Stamina"] == nil then B["Formula: Enchant Shield - Stamina"] = "Formül: Kalkan Efsunu - Dayanıklılık" end
if B["Formula: Enchant Shield - Superior Spirit"] == nil then B["Formula: Enchant Shield - Superior Spirit"] = "Formül: Kalkan Efsunu - Üstün Ruh" end
if B["Formula: Enchant Weapon - Agility"] == nil then B["Formula: Enchant Weapon - Agility"] = "Formül: Silah Efsunu - Çeviklik" end
if B["Formula: Enchant Weapon - Beastslayer"] == nil then B["Formula: Enchant Weapon - Beastslayer"] = "Formül: Silah Efsunu - Canavar Avcısı" end
if B["Formula: Enchant Weapon - Crusader"] == nil then B["Formula: Enchant Weapon - Crusader"] = "Formül: Silah Efsunu - Haçlı" end
if B["Formula: Enchant Weapon - Demonslaying"] == nil then B["Formula: Enchant Weapon - Demonslaying"] = "Formül: Silah Efsunu - İblis Avcılığı" end
if B["Formula: Enchant Weapon - Fiery Weapon"] == nil then B["Formula: Enchant Weapon - Fiery Weapon"] = "Formül: Silah Efsunu - Alevli Silah" end
if B["Formula: Enchant Weapon - Healing Power"] == nil then B["Formula: Enchant Weapon - Healing Power"] = "Formül: Silah Efsunu - İyileştirme Gücü" end
if B["Formula: Enchant Weapon - Icy Chill"] == nil then B["Formula: Enchant Weapon - Icy Chill"] = "Formül: Silah Efsunu - Buzlu Ürperti" end
if B["Formula: Enchant Weapon - Lesser Beastslayer"] == nil then B["Formula: Enchant Weapon - Lesser Beastslayer"] = "Formül: Silah Efsunu - Küçük Canavar Avcısı" end
if B["Formula: Enchant Weapon - Lesser Elemental Slayer"] == nil then B["Formula: Enchant Weapon - Lesser Elemental Slayer"] = "Formül: Silah Efsunu - Küçük Elemental Avcısı" end
if B["Formula: Enchant Weapon - Lifestealer"] == nil then B["Formula: Enchant Weapon - Lifestealer"] = "Formül: Silah Efsunu - Can Çalan" end
if B["Formula: Enchant Weapon - Mighty Intellect"] == nil then B["Formula: Enchant Weapon - Mighty Intellect"] = "Formül: Silah Efsunu - Kudretli Zekâ" end
if B["Formula: Enchant Weapon - Mighty Spirit"] == nil then B["Formula: Enchant Weapon - Mighty Spirit"] = "Formül: Silah Efsunu - Kudretli Ruh" end
if B["Formula: Enchant Weapon - Spell Power"] == nil then B["Formula: Enchant Weapon - Spell Power"] = "Formül: Silah Efsunu - Büyü Gücü" end
if B["Formula: Enchant Weapon - Strength"] == nil then B["Formula: Enchant Weapon - Strength"] = "Formül: Silah Efsunu - Güç" end
if B["Formula: Enchant Weapon - Superior Impact"] == nil then B["Formula: Enchant Weapon - Superior Impact"] = "Formül: Silah Efsunu - Üstün Darbe" end
if B["Formula: Enchant Weapon - Superior Striking"] == nil then B["Formula: Enchant Weapon - Superior Striking"] = "Formül: Silah Efsunu - Üstün Vuruş" end
if B["Formula: Enchant Weapon - Unholy"] == nil then B["Formula: Enchant Weapon - Unholy"] = "Formül: Silah Efsunu - Kutsal Olmayan" end
if B["Formula: Enchant Weapon - Winter's Might"] == nil then B["Formula: Enchant Weapon - Winter's Might"] = "Formül: Silah Efsunu - Kışın Kudreti" end
if B["Formula: Imbue Chest - Minor Spirit"] == nil then B["Formula: Imbue Chest - Minor Spirit"] = "Formül: Göğüs Aşılaması - Ufak Ruh" end
if B["Formula: Lesser Mana Oil"] == nil then B["Formula: Lesser Mana Oil"] = "Formül: Küçük Mana Yağı" end
if B["Formula: Lesser Wizard Oil"] == nil then B["Formula: Lesser Wizard Oil"] = "Formül: Küçük Büyücü Yağı" end
if B["Formula: Minor Mana Oil"] == nil then B["Formula: Minor Mana Oil"] = "Formül: Ufak Mana Yağı" end
if B["Formula: Minor Wizard Oil"] == nil then B["Formula: Minor Wizard Oil"] = "Formül: Ufak Büyücü Yağı" end
if B["Formula: Powerful Anti-Venom"] == nil then B["Formula: Powerful Anti-Venom"] = "Formül: Güçlü Panzehir" end
if B["Formula: Runed Arcanite Rod"] == nil then B["Formula: Runed Arcanite Rod"] = "Formül: Rünlü Arcanite Çubuk" end
if B["Formula: Smoking Heart of the Mountain"] == nil then B["Formula: Smoking Heart of the Mountain"] = "Formül: Dağın Tüten Kalbi" end
if B["Formula: Strong Anti-Venom"] == nil then B["Formula: Strong Anti-Venom"] = "Formül: Güçlü Panzehir" end
if B["Formula: Wizard Oil"] == nil then B["Formula: Wizard Oil"] = "Formül: Büyücü Yağı" end
if B["Fortitude of the Scourge"] == nil then B["Fortitude of the Scourge"] = "Scourge'un Metaneti" end
if B["Free Action"] == nil then B["Free Action"] = "Serbest Hareket" end
if B["Freeze"] == nil then B["Freeze"] = "Dondur" end
if B["Freeze Rookery Egg"] == nil then B["Freeze Rookery Egg"] = "Kuluçka Yumurtasını Dondur" end
if B["Freeze Rookery Egg - Prototype"] == nil then B["Freeze Rookery Egg - Prototype"] = "Kuluçka Yumurtasını Dondur - Prototip" end
if B["Frightalon"] == nil then B["Frightalon"] = "Dehşet Pençe" end
if B["Frost Arrow"] == nil then B["Frost Arrow"] = "Buz Oku" end
if B["Frost Blast"] == nil then B["Frost Blast"] = "Buz Patlaması" end
if B["Frost Mantle of the Dawn"] == nil then B["Frost Mantle of the Dawn"] = "Şafağın Buz Omuzluğu" end
if B["Frost Oil"] == nil then B["Frost Oil"] = "Ayaz Yağı" end
if B["Frost Power"] == nil then B["Frost Power"] = "Buz Gücü" end
if B["Frost Protection"] == nil then B["Frost Protection"] = "Buz Koruması" end
if B["Frost Ram"] == nil then B["Frost Ram"] = "Buz Koçu" end
if B["Frost Reflector"] == nil then B["Frost Reflector"] = "Buz Yansıtıcı" end
if B["Frost Shield"] == nil then B["Frost Shield"] = "Buz Kalkanı" end
if B["Frostwolf Howler"] == nil then B["Frostwolf Howler"] = "Frostwolf Uluyanı" end
if B["Frosty Zap"] == nil then B["Frosty Zap"] = "Buzlu Çarpma" end
if B["Fumble"] == nil then B["Fumble"] = "Beceriksizlik" end
if B["Fungal Regrowth"] == nil then B["Fungal Regrowth"] = "Mantar Yeniden Büyümesi" end
if B["Furbolg Form"] == nil then B["Furbolg Form"] = "Furbolg Biçimi" end
if B["Furbolg Medicine Pouch"] == nil then B["Furbolg Medicine Pouch"] = "Furbolg İlaç Kesesi" end
if B["Fury of Forgewright"] == nil then B["Fury of Forgewright"] = "Forgewright'ın Öfkesi" end
if B["Fury of the Bogling"] == nil then B["Fury of the Bogling"] = "Bogling'in Öfkesi" end
if B["Gammerita Turtle Camera"] == nil then B["Gammerita Turtle Camera"] = "Gammerita Kaplumbağa Kamerası" end
if B["Gem of the Serpent"] == nil then B["Gem of the Serpent"] = "Yılanın Mücevheri" end
if B["Getting Tide Pool Sample #1"] == nil then B["Getting Tide Pool Sample #1"] = "Gelgit Havuzu Numunesi Alınıyor #1" end
if B["Getting Tide Pool Sample #2"] == nil then B["Getting Tide Pool Sample #2"] = "Gelgit Havuzu Numunesi Alınıyor #2" end
if B["Getting Tide Pool Sample #3"] == nil then B["Getting Tide Pool Sample #3"] = "Gelgit Havuzu Numunesi Alınıyor #3" end
if B["Getting Tide Pool Sample #4"] == nil then B["Getting Tide Pool Sample #4"] = "Gelgit Havuzu Numunesi Alınıyor #4" end
if B["Ghost Costume"] == nil then B["Ghost Costume"] = "Hayalet Kostümü" end
if B["Ghost Wolf Speed"] == nil then B["Ghost Wolf Speed"] = "Hayalet Kurt Hızı" end
if B["Gift of Arthas"] == nil then B["Gift of Arthas"] = "Arthas'ın Armağanı" end
if B["Gift of Life"] == nil then B["Gift of Life"] = "Yaşam Armağanı" end
if B["Gift of Stone"] == nil then B["Gift of Stone"] = "Taşın Armağanı" end
if B["Gift of the Wild"] == nil then B["Gift of the Wild"] = "Vahşiliğin Armağanı" end
if B["Give Friendship Bracelet"] == nil then B["Give Friendship Bracelet"] = "Dostluk Bilekliği Ver" end
if B["Glimpse of Madness"] == nil then B["Glimpse of Madness"] = "Deliliğin Görüntüsü" end
if B["Glyph of Deflection"] == nil then B["Glyph of Deflection"] = "Saptırma Sembolü" end
if B["Gnome Camera Connection"] == nil then B["Gnome Camera Connection"] = "Gnome Kamera Bağlantısı" end
if B["Gnomish Battle Chicken"] == nil then B["Gnomish Battle Chicken"] = "Gnome Savaş Tavuğu" end
if B["Gnomish Death Ray"] == nil then B["Gnomish Death Ray"] = "Gnome Ölüm Işını" end
if B["Gnomish Mind Control Cap"] == nil then B["Gnomish Mind Control Cap"] = "Gnome Zihin Kontrol Başlığı" end
if B["Gnomish Rocket Boots"] == nil then B["Gnomish Rocket Boots"] = "Gnome Roket Çizmeleri" end
if B["Gnomish Transporter"] == nil then B["Gnomish Transporter"] = "Gnome Taşıyıcısı" end
if B["Goblin Bomb"] == nil then B["Goblin Bomb"] = "Goblin Bombası" end
if B["Goblin Camera Connection"] == nil then B["Goblin Camera Connection"] = "Goblin Kamera Bağlantısı" end
if B["Goblin Dragon Gun"] == nil then B["Goblin Dragon Gun"] = "Goblin Ejderha Tüfeği" end
if B["Goblin Land Mine"] == nil then B["Goblin Land Mine"] = "Goblin Kara Mayını" end
if B["Goblin Mortar"] == nil then B["Goblin Mortar"] = "Goblin Havan Topu" end
if B["Goblin Rocket Boots"] == nil then B["Goblin Rocket Boots"] = "Goblin Roket Çizmeleri" end
if B["Goblin Sapper Charge"] == nil then B["Goblin Sapper Charge"] = "Goblin Lağımcı Patlayıcısı" end
if B["Golden Sabercat"] == nil then B["Golden Sabercat"] = "Altın Sabercat" end
if B["Golden Skeleton Key"] == nil then B["Golden Skeleton Key"] = "Altın Maymuncuk" end
if B["Gong Zul'Farrak Gong"] == nil then B["Gong Zul'Farrak Gong"] = "Zul'Farrak Gongunu Çal" end
if B["Gordok Green Grog"] == nil then B["Gordok Green Grog"] = "Gordok Yeşil Grogu" end
if B["Gordok Ogre Suit"] == nil then B["Gordok Ogre Suit"] = "Gordok Ogre Kostümü" end
if B["Graccu's Mince Meat Fruitcake"] == nil then B["Graccu's Mince Meat Fruitcake"] = "Graccu'nun Kıymalı Meyveli Keki" end
if B["Grace of Earth"] == nil then B["Grace of Earth"] = "Toprağın Lütfu" end
if B["Gray Kodo"] == nil then B["Gray Kodo"] = "Gri Kodo" end
if B["Gray Ram"] == nil then B["Gray Ram"] = "Gri Koç" end
if B["Gray Wolf"] == nil then B["Gray Wolf"] = "Gri Kurt" end
if B["Great Brown Kodo"] == nil then B["Great Brown Kodo"] = "Büyük Kahverengi Kodo" end
if B["Great Gray Kodo"] == nil then B["Great Gray Kodo"] = "Büyük Gri Kodo" end
if B["Great Rage"] == nil then B["Great Rage"] = "Büyük Öfke" end
if B["Great White Kodo"] == nil then B["Great White Kodo"] = "Büyük Beyaz Kodo" end
if B["Greater Agility"] == nil then B["Greater Agility"] = "Büyük Çeviklik" end
if B["Greater Arcane Amalgamation"] == nil then B["Greater Arcane Amalgamation"] = "Büyük Arkan Karışımı" end
if B["Greater Arcane Elixir"] == nil then B["Greater Arcane Elixir"] = "Büyük Arkan Eliksiri" end
if B["Greater Armor"] == nil then B["Greater Armor"] = "Büyük Zırh" end
if B["Greater Astral Essence"] == nil then B["Greater Astral Essence"] = "Büyük Astral Öz" end
if B["Greater Dreamless Sleep"] == nil then B["Greater Dreamless Sleep"] = "Büyük Rüyasız Uyku" end
if B["Greater Eternal Essence"] == nil then B["Greater Eternal Essence"] = "Büyük Ebedi Öz" end
if B["Greater Firepower"] == nil then B["Greater Firepower"] = "Büyük Ateş Gücü" end
if B["Greater Healing Wave"] == nil then B["Greater Healing Wave"] = "Büyük İyileştirme Dalgası" end
if B["Greater Healthstone"] == nil then B["Greater Healthstone"] = "Büyük Sağlık Taşı" end
if B["Greater Intellect"] == nil then B["Greater Intellect"] = "Büyük Zekâ" end
if B["Greater Magic Essence"] == nil then B["Greater Magic Essence"] = "Büyük Büyü Özü" end
if B["Greater Mark of the Dawn"] == nil then B["Greater Mark of the Dawn"] = "Şafağın Büyük Nişanı" end
if B["Greater Mystic Essence"] == nil then B["Greater Mystic Essence"] = "Büyük Mistik Öz" end
if B["Greater Nether Essence"] == nil then B["Greater Nether Essence"] = "Büyük Nether Özü" end
if B["Greater Spellstone"] == nil then B["Greater Spellstone"] = "Büyük Büyü Taşı" end
if B["Greater Stoneshield"] == nil then B["Greater Stoneshield"] = "Büyük Taş Kalkan" end
if B["Greater Water Breathing"] == nil then B["Greater Water Breathing"] = "Büyük Su Altında Nefes" end
if B["Green Firework"] == nil then B["Green Firework"] = "Yeşil Havai Fişek" end
if B["Green Firework Cluster"] == nil then B["Green Firework Cluster"] = "Yeşil Havai Fişek Demeti" end
if B["Green Kodo"] == nil then B["Green Kodo"] = "Yeşil Kodo" end
if B["Green Mechanostrider"] == nil then B["Green Mechanostrider"] = "Yeşil Mechanostrider" end
if B["Green Skeletal Warhorse"] == nil then B["Green Skeletal Warhorse"] = "Yeşil İskelet Savaş Atı" end
if B["Green Tea"] == nil then B["Green Tea"] = "Yeşil Çay" end
if B["Grom's Tribute"] == nil then B["Grom's Tribute"] = "Grom'un Haracı" end
if B["Group Astral Recall"] == nil then B["Group Astral Recall"] = "Grup Astral Geri Dönüş" end
if B["Guardian"] == nil then B["Guardian"] = "Muhafız" end
if B["Guile of the Raptor"] == nil then B["Guile of the Raptor"] = "Raptorun Kurnazlığı" end
if B["Gutgore Ripper"] == nil then B["Gutgore Ripper"] = "Gutgore Deşicisi" end
if B["Hallow's End Candy"] == nil then B["Hallow's End Candy"] = "Hallow's End Şekeri" end
if B["Hamstring Rage Reduction"] == nil then B["Hamstring Rage Reduction"] = "Hamstring Öfke İndirimi" end
if B["Hand of Iruxos"] == nil then B["Hand of Iruxos"] = "Iruxos'un Eli" end
if B["Hand of Justice"] == nil then B["Hand of Justice"] = "Adaletin Eli" end
if B["Harm Prevention Belt"] == nil then B["Harm Prevention Belt"] = "Zarar Önleme Kemeri" end
if B["Harvest Silithid Egg"] == nil then B["Harvest Silithid Egg"] = "Silithid Yumurtası Topla" end
if B["Haste"] == nil then B["Haste"] = "Hız" end
if B["Hatch Egg"] == nil then B["Hatch Egg"] = "Yumurtayı Çatlat" end
if B["Headmaster's Charge"] == nil then B["Headmaster's Charge"] = "Müdürün Emaneti" end
if B["Heal Pet"] == nil then B["Heal Pet"] = "Hayvanı İyileştir" end
if B["Heal Self"] == nil then B["Heal Self"] = "Kendini İyileştir" end
if B["Heal Vylestem Vine"] == nil then B["Heal Vylestem Vine"] = "Vylestem Sarmaşığını İyileştir" end
if B["Healing Draught"] == nil then B["Healing Draught"] = "Şifa Şerbeti" end
if B["Healing Potion"] == nil then B["Healing Potion"] = "Şifa İksiri" end
if B["Healing Touch Refund"] == nil then B["Healing Touch Refund"] = "Healing Touch İadesi" end
if B["Healing of the Ages"] == nil then B["Healing of the Ages"] = "Çağların Şifası" end
if B["Health"] == nil then B["Health"] = "Sağlık" end
if B["Health II"] == nil then B["Health II"] = "Sağlık II" end
if B["Healthstone"] == nil then B["Healthstone"] = "Sağlık Taşı" end
if B["Heart of the Scale"] == nil then B["Heart of the Scale"] = "Pulun Kalbi" end
if B["Hearthstone"] == nil then B["Hearthstone"] = "Yuva Taşı" end
if B["Heaven's Blessing"] == nil then B["Heaven's Blessing"] = "Cennetin Lütfu" end
if B["Heavy Dynamite"] == nil then B["Heavy Dynamite"] = "Ağır Dinamit" end
if B["Heavy Leather Ball"] == nil then B["Heavy Leather Ball"] = "Ağır Deri Top" end
if B["Heavy Silk Bandage"] == nil then B["Heavy Silk Bandage"] = "Ağır İpek Sargı" end
if B["Heightened Senses"] == nil then B["Heightened Senses"] = "Keskinleşmiş Duyular" end
if B["Heroism"] == nil then B["Heroism"] = "Kahramanlık" end
if B["Hi-Explosive Bomb"] == nil then B["Hi-Explosive Bomb"] = "Yüksek Patlayıcılı Bomba" end
if B["Holiday Cheer"] == nil then B["Holiday Cheer"] = "Bayram Neşesi" end
if B["Holy Mightstone"] == nil then B["Holy Mightstone"] = "Kutsal Kudret Taşı" end
if B["Holy Protection"] == nil then B["Holy Protection"] = "Kutsal Koruma" end
if B["Holy Protection "] == nil then B["Holy Protection "] = "Kutsal Koruma" end
if B["Holy Smite"] == nil then B["Holy Smite"] = "Kutsal Çarpma" end
if B["Holy Sunder"] == nil then B["Holy Sunder"] = "Kutsal Yarma" end
if B["Holy Ward"] == nil then B["Holy Ward"] = "Kutsal Siper" end
if B["Holy Word: Fortitude"] == nil then B["Holy Word: Fortitude"] = "Kutsal Söz: Metanet" end
if B["Holy Word: Shield"] == nil then B["Holy Word: Shield"] = "Kutsal Söz: Kalkan" end
if B["Hoodoo Hex"] == nil then B["Hoodoo Hex"] = "Hoodoo Laneti" end
if B["Hourglass Sand"] == nil then B["Hourglass Sand"] = "Kum Saati Kumu" end
if B["Howling Blade"] == nil then B["Howling Blade"] = "Uluyan Kılıç" end
if B["Hyena Sample"] == nil then B["Hyena Sample"] = "Sırtlan Numunesi" end
if B["Ice Guard"] == nil then B["Ice Guard"] = "Buz Siperi" end
if B["Icy Blue Mechanostrider"] == nil then B["Icy Blue Mechanostrider"] = "Buz Mavisi Mechanostrider" end
if B["Igniting Kroshius"] == nil then B["Igniting Kroshius"] = "Kroshius Ateşleniyor" end
if B["Illidan's Fury"] == nil then B["Illidan's Fury"] = "Illidan'ın Öfkesi" end
if B["Illusion: Black Dragonkin"] == nil then B["Illusion: Black Dragonkin"] = "İllüzyon: Kara Dragonkin" end
if B["Immature Venom Sac"] == nil then B["Immature Venom Sac"] = "Olgunlaşmamış Zehir Kesesi" end
if B["Immolation"] == nil then B["Immolation"] = "Yakma" end
if B["Immune Charm/Fear/Polymorph"] == nil then B["Immune Charm/Fear/Polymorph"] = "Büyülenme/Korku/Polymorph Bağışıklığı" end
if B["Immune Charm/Fear/Stun"] == nil then B["Immune Charm/Fear/Stun"] = "Büyülenme/Korku/Sersemletme Bağışıklığı" end
if B["Immune Fear/Polymorph/Snare"] == nil then B["Immune Fear/Polymorph/Snare"] = "Korku/Polymorph/Yavaşlatma Bağışıklığı" end
if B["Immune Fear/Polymorph/Stun"] == nil then B["Immune Fear/Polymorph/Stun"] = "Korku/Polymorph/Sersemletme Bağışıklığı" end
if B["Immune Root"] == nil then B["Immune Root"] = "Kök Salma Bağışıklığı" end
if B["Immune Root/Snare/Stun"] == nil then B["Immune Root/Snare/Stun"] = "Kök Salma/Yavaşlatma/Sersemletme Bağışıklığı" end
if B["Immune to Disarm"] == nil then B["Immune to Disarm"] = "Silahsızlandırma Bağışıklığı" end
if B["Improved Counterspell"] == nil then B["Improved Counterspell"] = "Gelişmiş Counterspell" end
if B["Improved Feign Death"] == nil then B["Improved Feign Death"] = "Gelişmiş Feign Death" end
if B["Improved Hammer of Justice"] == nil then B["Improved Hammer of Justice"] = "Gelişmiş Hammer of Justice" end
if B["Improved Hamstring"] == nil then B["Improved Hamstring"] = "Gelişmiş Hamstring" end
if B["Improved Kick"] == nil then B["Improved Kick"] = "Gelişmiş Kick" end
if B["Improved Moonfire"] == nil then B["Improved Moonfire"] = "Gelişmiş Moonfire" end
if B["Improved Rain of Fire/Hellfire"] == nil then B["Improved Rain of Fire/Hellfire"] = "Gelişmiş Rain of Fire/Hellfire" end
if B["Improved Seal of the Crusader"] == nil then B["Improved Seal of the Crusader"] = "Gelişmiş Seal of the Crusader" end
if B["Improved Skinning"] == nil then B["Improved Skinning"] = "Gelişmiş Deri Yüzme" end
if B["Improved Wrath/Starfire"] == nil then B["Improved Wrath/Starfire"] = "Gelişmiş Wrath/Starfire" end
if B["Incendia Powder"] == nil then B["Incendia Powder"] = "Incendia Tozu" end
if B["Incineration"] == nil then B["Incineration"] = "Yakıp Kül Etme" end
if B["Increase Arcane Dam 11"] == nil then B["Increase Arcane Dam 11"] = "Arkan Hasarı Artışı 11" end
if B["Increase Arcane Dam 13"] == nil then B["Increase Arcane Dam 13"] = "Arkan Hasarı Artışı 13" end
if B["Increase Arcane Dam 14"] == nil then B["Increase Arcane Dam 14"] = "Arkan Hasarı Artışı 14" end
if B["Increase Arcane Dam 16"] == nil then B["Increase Arcane Dam 16"] = "Arkan Hasarı Artışı 16" end
if B["Increase Arcane Dam 34"] == nil then B["Increase Arcane Dam 34"] = "Arkan Hasarı Artışı 34" end
if B["Increase Arcane Dam 36"] == nil then B["Increase Arcane Dam 36"] = "Arkan Hasarı Artışı 36" end
if B["Increase Arcane Dam 9"] == nil then B["Increase Arcane Dam 9"] = "Arkan Hasarı Artışı 9" end
if B["Increase Fire Dam 10"] == nil then B["Increase Fire Dam 10"] = "Ateş Hasarı Artışı 10" end
if B["Increase Fire Dam 13"] == nil then B["Increase Fire Dam 13"] = "Ateş Hasarı Artışı 13" end
if B["Increase Fire Dam 14"] == nil then B["Increase Fire Dam 14"] = "Ateş Hasarı Artışı 14" end
if B["Increase Fire Dam 16"] == nil then B["Increase Fire Dam 16"] = "Ateş Hasarı Artışı 16" end
if B["Increase Fire Dam 17"] == nil then B["Increase Fire Dam 17"] = "Ateş Hasarı Artışı 17" end
if B["Increase Fire Dam 19"] == nil then B["Increase Fire Dam 19"] = "Ateş Hasarı Artışı 19" end
if B["Increase Fire Dam 21"] == nil then B["Increase Fire Dam 21"] = "Ateş Hasarı Artışı 21" end
if B["Increase Fire Dam 23"] == nil then B["Increase Fire Dam 23"] = "Ateş Hasarı Artışı 23" end
if B["Increase Fire Dam 24"] == nil then B["Increase Fire Dam 24"] = "Ateş Hasarı Artışı 24" end
if B["Increase Fire Dam 26"] == nil then B["Increase Fire Dam 26"] = "Ateş Hasarı Artışı 26" end
if B["Increase Fire Dam 27"] == nil then B["Increase Fire Dam 27"] = "Ateş Hasarı Artışı 27" end
if B["Increase Fire Dam 29"] == nil then B["Increase Fire Dam 29"] = "Ateş Hasarı Artışı 29" end
if B["Increase Fire Dam 33"] == nil then B["Increase Fire Dam 33"] = "Ateş Hasarı Artışı 33" end
if B["Increase Fire Dam 34"] == nil then B["Increase Fire Dam 34"] = "Ateş Hasarı Artışı 34" end
if B["Increase Fire Dam 36"] == nil then B["Increase Fire Dam 36"] = "Ateş Hasarı Artışı 36" end
if B["Increase Fire Dam 4"] == nil then B["Increase Fire Dam 4"] = "Ateş Hasarı Artışı 4" end
if B["Increase Fire Dam 40"] == nil then B["Increase Fire Dam 40"] = "Ateş Hasarı Artışı 40" end
if B["Increase Fire Dam 43"] == nil then B["Increase Fire Dam 43"] = "Ateş Hasarı Artışı 43" end
if B["Increase Fire Dam 57"] == nil then B["Increase Fire Dam 57"] = "Ateş Hasarı Artışı 57" end
if B["Increase Fire Dam 6"] == nil then B["Increase Fire Dam 6"] = "Ateş Hasarı Artışı 6" end
if B["Increase Fire Dam 7"] == nil then B["Increase Fire Dam 7"] = "Ateş Hasarı Artışı 7" end
if B["Increase Fire Dam 9"] == nil then B["Increase Fire Dam 9"] = "Ateş Hasarı Artışı 9" end
if B["Increase Frost Dam 10"] == nil then B["Increase Frost Dam 10"] = "Buz Hasarı Artışı 10" end
if B["Increase Frost Dam 11"] == nil then B["Increase Frost Dam 11"] = "Buz Hasarı Artışı 11" end
if B["Increase Frost Dam 13"] == nil then B["Increase Frost Dam 13"] = "Buz Hasarı Artışı 13" end
if B["Increase Frost Dam 132"] == nil then B["Increase Frost Dam 132"] = "Buz Hasarı Artışı 132" end
if B["Increase Frost Dam 14"] == nil then B["Increase Frost Dam 14"] = "Ayaz Hasarını Artır 14" end
if B["Increase Frost Dam 16"] == nil then B["Increase Frost Dam 16"] = "Ayaz Hasarını Artır 16" end
if B["Increase Frost Dam 17"] == nil then B["Increase Frost Dam 17"] = "Ayaz Hasarını Artır 17" end
if B["Increase Frost Dam 19"] == nil then B["Increase Frost Dam 19"] = "Ayaz Hasarını Artır 19" end
if B["Increase Frost Dam 20"] == nil then B["Increase Frost Dam 20"] = "Ayaz Hasarını Artır 20" end
if B["Increase Frost Dam 21"] == nil then B["Increase Frost Dam 21"] = "Ayaz Hasarını Artır 21" end
if B["Increase Frost Dam 24"] == nil then B["Increase Frost Dam 24"] = "Ayaz Hasarını Artır 24" end
if B["Increase Frost Dam 26"] == nil then B["Increase Frost Dam 26"] = "Ayaz Hasarını Artır 26" end
if B["Increase Frost Dam 29"] == nil then B["Increase Frost Dam 29"] = "Ayaz Hasarını Artır 29" end
if B["Increase Frost Dam 34"] == nil then B["Increase Frost Dam 34"] = "Ayaz Hasarını Artır 34" end
if B["Increase Frost Dam 36"] == nil then B["Increase Frost Dam 36"] = "Ayaz Hasarını Artır 36" end
if B["Increase Frost Dam 37"] == nil then B["Increase Frost Dam 37"] = "Ayaz Hasarını Artır 37" end
if B["Increase Frost Dam 39"] == nil then B["Increase Frost Dam 39"] = "Ayaz Hasarını Artır 39" end
if B["Increase Frost Dam 40"] == nil then B["Increase Frost Dam 40"] = "Ayaz Hasarını Artır 40" end
if B["Increase Frost Dam 41"] == nil then B["Increase Frost Dam 41"] = "Ayaz Hasarını Artır 41" end
if B["Increase Frost Dam 43"] == nil then B["Increase Frost Dam 43"] = "Ayaz Hasarını Artır 43" end
if B["Increase Frost Dam 6"] == nil then B["Increase Frost Dam 6"] = "Ayaz Hasarını Artır 6" end
if B["Increase Frost Dam 7"] == nil then B["Increase Frost Dam 7"] = "Ayaz Hasarını Artır 7" end
if B["Increase Frost Dam 72"] == nil then B["Increase Frost Dam 72"] = "Ayaz Hasarını Artır 72" end
if B["Increase Frost Dam 9"] == nil then B["Increase Frost Dam 9"] = "Ayaz Hasarını Artır 9" end
if B["Increase Healing 106"] == nil then B["Increase Healing 106"] = "İyileştirmeyi Artır 106" end
if B["Increase Healing 11"] == nil then B["Increase Healing 11"] = "İyileştirmeyi Artır 11" end
if B["Increase Healing 121"] == nil then B["Increase Healing 121"] = "İyileştirmeyi Artır 121" end
if B["Increase Healing 13"] == nil then B["Increase Healing 13"] = "İyileştirmeyi Artır 13" end
if B["Increase Healing 134"] == nil then B["Increase Healing 134"] = "İyileştirmeyi Artır 134" end
if B["Increase Healing 143"] == nil then B["Increase Healing 143"] = "İyileştirmeyi Artır 143" end
if B["Increase Healing 15"] == nil then B["Increase Healing 15"] = "İyileştirmeyi Artır 15" end
if B["Increase Healing 161"] == nil then B["Increase Healing 161"] = "İyileştirmeyi Artır 161" end
if B["Increase Healing 178"] == nil then B["Increase Healing 178"] = "İyileştirmeyi Artır 178" end
if B["Increase Healing 18"] == nil then B["Increase Healing 18"] = "İyileştirmeyi Artır 18" end
if B["Increase Healing 187"] == nil then B["Increase Healing 187"] = "İyileştirmeyi Artır 187" end
if B["Increase Healing 20"] == nil then B["Increase Healing 20"] = "İyileştirmeyi Artır 20" end
if B["Increase Healing 22"] == nil then B["Increase Healing 22"] = "İyileştirmeyi Artır 22" end
if B["Increase Healing 238"] == nil then B["Increase Healing 238"] = "İyileştirmeyi Artır 238" end
if B["Increase Healing 24"] == nil then B["Increase Healing 24"] = "İyileştirmeyi Artır 24" end
if B["Increase Healing 26"] == nil then B["Increase Healing 26"] = "İyileştirmeyi Artır 26" end
if B["Increase Healing 29"] == nil then B["Increase Healing 29"] = "İyileştirmeyi Artır 29" end
if B["Increase Healing 300"] == nil then B["Increase Healing 300"] = "İyileştirmeyi Artır 300" end
if B["Increase Healing 31"] == nil then B["Increase Healing 31"] = "İyileştirmeyi Artır 31" end
if B["Increase Healing 33"] == nil then B["Increase Healing 33"] = "İyileştirmeyi Artır 33" end
if B["Increase Healing 35"] == nil then B["Increase Healing 35"] = "İyileştirmeyi Artır 35" end
if B["Increase Healing 37"] == nil then B["Increase Healing 37"] = "İyileştirmeyi Artır 37" end
if B["Increase Healing 40"] == nil then B["Increase Healing 40"] = "İyileştirmeyi Artır 40" end
if B["Increase Healing 42"] == nil then B["Increase Healing 42"] = "İyileştirmeyi Artır 42" end
if B["Increase Healing 44"] == nil then B["Increase Healing 44"] = "İyileştirmeyi Artır 44" end
if B["Increase Healing 46"] == nil then B["Increase Healing 46"] = "İyileştirmeyi Artır 46" end
if B["Increase Healing 48"] == nil then B["Increase Healing 48"] = "İyileştirmeyi Artır 48" end
if B["Increase Healing 51"] == nil then B["Increase Healing 51"] = "İyileştirmeyi Artır 51" end
if B["Increase Healing 53"] == nil then B["Increase Healing 53"] = "İyileştirmeyi Artır 53" end
if B["Increase Healing 55"] == nil then B["Increase Healing 55"] = "İyileştirmeyi Artır 55" end
if B["Increase Healing 57"] == nil then B["Increase Healing 57"] = "İyileştirmeyi Artır 57" end
if B["Increase Healing 59"] == nil then B["Increase Healing 59"] = "İyileştirmeyi Artır 59" end
if B["Increase Healing 62"] == nil then B["Increase Healing 62"] = "İyileştirmeyi Artır 62" end
if B["Increase Healing 64"] == nil then B["Increase Healing 64"] = "İyileştirmeyi Artır 64" end
if B["Increase Healing 66"] == nil then B["Increase Healing 66"] = "İyileştirmeyi Artır 66" end
if B["Increase Healing 68"] == nil then B["Increase Healing 68"] = "İyileştirmeyi Artır 68" end
if B["Increase Healing 70"] == nil then B["Increase Healing 70"] = "İyileştirmeyi Artır 70" end
if B["Increase Healing 73"] == nil then B["Increase Healing 73"] = "İyileştirmeyi Artır 73" end
if B["Increase Healing 75"] == nil then B["Increase Healing 75"] = "İyileştirmeyi Artır 75" end
if B["Increase Healing 77"] == nil then B["Increase Healing 77"] = "İyileştirmeyi Artır 77" end
if B["Increase Healing 84"] == nil then B["Increase Healing 84"] = "İyileştirmeyi Artır 84" end
if B["Increase Healing 9"] == nil then B["Increase Healing 9"] = "İyileştirmeyi Artır 9" end
if B["Increase Healing 90"] == nil then B["Increase Healing 90"] = "İyileştirmeyi Artır 90" end
if B["Increase Healing 92"] == nil then B["Increase Healing 92"] = "İyileştirmeyi Artır 92" end
if B["Increase Holy Dam 16"] == nil then B["Increase Holy Dam 16"] = "Kutsal Hasarını Artır 16" end
if B["Increase Holy Dam 29"] == nil then B["Increase Holy Dam 29"] = "Kutsal Hasarını Artır 29" end
if B["Increase Nature Dam 10"] == nil then B["Increase Nature Dam 10"] = "Doğa Hasarını Artır 10" end
if B["Increase Nature Dam 14"] == nil then B["Increase Nature Dam 14"] = "Doğa Hasarını Artır 14" end
if B["Increase Nature Dam 16"] == nil then B["Increase Nature Dam 16"] = "Doğa Hasarını Artır 16" end
if B["Increase Nature Dam 17"] == nil then B["Increase Nature Dam 17"] = "Doğa Hasarını Artır 17" end
if B["Increase Nature Dam 19"] == nil then B["Increase Nature Dam 19"] = "Doğa Hasarını Artır 19" end
if B["Increase Nature Dam 21"] == nil then B["Increase Nature Dam 21"] = "Doğa Hasarını Artır 21" end
if B["Increase Nature Dam 24"] == nil then B["Increase Nature Dam 24"] = "Doğa Hasarını Artır 24" end
if B["Increase Nature Dam 29"] == nil then B["Increase Nature Dam 29"] = "Doğa Hasarını Artır 29" end
if B["Increase Nature Dam 33"] == nil then B["Increase Nature Dam 33"] = "Doğa Hasarını Artır 33" end
if B["Increase Nature Dam 34"] == nil then B["Increase Nature Dam 34"] = "Doğa Hasarını Artır 34" end
if B["Increase Nature Dam 40"] == nil then B["Increase Nature Dam 40"] = "Doğa Hasarını Artır 40" end
if B["Increase Reputation"] == nil then B["Increase Reputation"] = "İtibarı Artır" end
if B["Increase Shadow Dam 10"] == nil then B["Increase Shadow Dam 10"] = "Gölge Hasarını Artır 10" end
if B["Increase Shadow Dam 11"] == nil then B["Increase Shadow Dam 11"] = "Gölge Hasarını Artır 11" end
if B["Increase Shadow Dam 13"] == nil then B["Increase Shadow Dam 13"] = "Gölge Hasarını Artır 13" end
if B["Increase Shadow Dam 14"] == nil then B["Increase Shadow Dam 14"] = "Gölge Hasarını Artır 14" end
if B["Increase Shadow Dam 17"] == nil then B["Increase Shadow Dam 17"] = "Gölge Hasarını Artır 17" end
if B["Increase Shadow Dam 19"] == nil then B["Increase Shadow Dam 19"] = "Gölge Hasarını Artır 19" end
if B["Increase Shadow Dam 20"] == nil then B["Increase Shadow Dam 20"] = "Gölge Hasarını Artır 20" end
if B["Increase Shadow Dam 21"] == nil then B["Increase Shadow Dam 21"] = "Gölge Hasarını Artır 21" end
if B["Increase Shadow Dam 23"] == nil then B["Increase Shadow Dam 23"] = "Gölge Hasarını Artır 23" end
if B["Increase Shadow Dam 24"] == nil then B["Increase Shadow Dam 24"] = "Gölge Hasarını Artır 24" end
if B["Increase Shadow Dam 26"] == nil then B["Increase Shadow Dam 26"] = "Gölge Hasarını Artır 26" end
if B["Increase Shadow Dam 27"] == nil then B["Increase Shadow Dam 27"] = "Gölge Hasarını Artır 27" end
if B["Increase Shadow Dam 30"] == nil then B["Increase Shadow Dam 30"] = "Gölge Hasarını Artır 30" end
if B["Increase Shadow Dam 33"] == nil then B["Increase Shadow Dam 33"] = "Gölge Hasarını Artır 33" end
if B["Increase Shadow Dam 34"] == nil then B["Increase Shadow Dam 34"] = "Gölge Hasarını Artır 34" end
if B["Increase Shadow Dam 36"] == nil then B["Increase Shadow Dam 36"] = "Gölge Hasarını Artır 36" end
if B["Increase Shadow Dam 4"] == nil then B["Increase Shadow Dam 4"] = "Gölge Hasarını Artır 4" end
if B["Increase Shadow Dam 40"] == nil then B["Increase Shadow Dam 40"] = "Gölge Hasarını Artır 40" end
if B["Increase Shadow Dam 43"] == nil then B["Increase Shadow Dam 43"] = "Gölge Hasarını Artır 43" end
if B["Increase Shadow Dam 6"] == nil then B["Increase Shadow Dam 6"] = "Gölge Hasarını Artır 6" end
if B["Increase Shadow Dam 64"] == nil then B["Increase Shadow Dam 64"] = "Gölge Hasarını Artır 64" end
if B["Increase Shadow Dam 69"] == nil then B["Increase Shadow Dam 69"] = "Gölge Hasarını Artır 69" end
if B["Increase Shadow Dam 7"] == nil then B["Increase Shadow Dam 7"] = "Gölge Hasarını Artır 7" end
if B["Increase Shadow Dam 9"] == nil then B["Increase Shadow Dam 9"] = "Gölge Hasarını Artır 9" end
if B["Increase Spell Dam 11"] == nil then B["Increase Spell Dam 11"] = "Büyü Hasarını Artır 11" end
if B["Increase Spell Dam 113"] == nil then B["Increase Spell Dam 113"] = "Büyü Hasarını Artır 113" end
if B["Increase Spell Dam 12"] == nil then B["Increase Spell Dam 12"] = "Büyü Hasarını Artır 12" end
if B["Increase Spell Dam 126"] == nil then B["Increase Spell Dam 126"] = "Büyü Hasarını Artır 126" end
if B["Increase Spell Dam 13"] == nil then B["Increase Spell Dam 13"] = "Büyü Hasarını Artır 13" end
if B["Increase Spell Dam 14"] == nil then B["Increase Spell Dam 14"] = "Büyü Hasarını Artır 14" end
if B["Increase Spell Dam 15"] == nil then B["Increase Spell Dam 15"] = "Büyü Hasarını Artır 15" end
if B["Increase Spell Dam 150"] == nil then B["Increase Spell Dam 150"] = "Büyü Hasarını Artır 150" end
if B["Increase Spell Dam 16"] == nil then B["Increase Spell Dam 16"] = "Büyü Hasarını Artır 16" end
if B["Increase Spell Dam 18"] == nil then B["Increase Spell Dam 18"] = "Büyü Hasarını Artır 18" end
if B["Increase Spell Dam 19"] == nil then B["Increase Spell Dam 19"] = "Büyü Hasarını Artır 19" end
if B["Increase Spell Dam 20"] == nil then B["Increase Spell Dam 20"] = "Büyü Hasarını Artır 20" end
if B["Increase Spell Dam 21"] == nil then B["Increase Spell Dam 21"] = "Büyü Hasarını Artır 21" end
if B["Increase Spell Dam 22"] == nil then B["Increase Spell Dam 22"] = "Büyü Hasarını Artır 22" end
if B["Increase Spell Dam 23"] == nil then B["Increase Spell Dam 23"] = "Büyü Hasarını Artır 23" end
if B["Increase Spell Dam 24"] == nil then B["Increase Spell Dam 24"] = "Büyü Hasarını Artır 24" end
if B["Increase Spell Dam 25"] == nil then B["Increase Spell Dam 25"] = "Büyü Hasarını Artır 25" end
if B["Increase Spell Dam 26"] == nil then B["Increase Spell Dam 26"] = "Büyü Hasarını Artır 26" end
if B["Increase Spell Dam 27"] == nil then B["Increase Spell Dam 27"] = "Büyü Hasarını Artır 27" end
if B["Increase Spell Dam 28"] == nil then B["Increase Spell Dam 28"] = "Büyü Hasarını Artır 28" end
if B["Increase Spell Dam 29"] == nil then B["Increase Spell Dam 29"] = "Büyü Hasarını Artır 29" end
if B["Increase Spell Dam 30"] == nil then B["Increase Spell Dam 30"] = "Büyü Hasarını Artır 30" end
if B["Increase Spell Dam 32"] == nil then B["Increase Spell Dam 32"] = "Büyü Hasarını Artır 32" end
if B["Increase Spell Dam 33"] == nil then B["Increase Spell Dam 33"] = "Büyü Hasarını Artır 33" end
if B["Increase Spell Dam 34"] == nil then B["Increase Spell Dam 34"] = "Büyü Hasarını Artır 34" end
if B["Increase Spell Dam 35"] == nil then B["Increase Spell Dam 35"] = "Büyü Hasarını Artır 35" end
if B["Increase Spell Dam 36"] == nil then B["Increase Spell Dam 36"] = "Büyü Hasarını Artır 36" end
if B["Increase Spell Dam 37"] == nil then B["Increase Spell Dam 37"] = "Büyü Hasarını Artır 37" end
if B["Increase Spell Dam 39"] == nil then B["Increase Spell Dam 39"] = "Büyü Hasarını Artır 39" end
if B["Increase Spell Dam 40"] == nil then B["Increase Spell Dam 40"] = "Büyü Hasarını Artır 40" end
if B["Increase Spell Dam 41"] == nil then B["Increase Spell Dam 41"] = "Büyü Hasarını Artır 41" end
if B["Increase Spell Dam 43"] == nil then B["Increase Spell Dam 43"] = "Büyü Hasarını Artır 43" end
if B["Increase Spell Dam 44"] == nil then B["Increase Spell Dam 44"] = "Büyü Hasarını Artır 44" end
if B["Increase Spell Dam 46"] == nil then B["Increase Spell Dam 46"] = "Büyü Hasarını Artır 46" end
if B["Increase Spell Dam 47"] == nil then B["Increase Spell Dam 47"] = "Büyü Hasarını Artır 47" end
if B["Increase Spell Dam 5"] == nil then B["Increase Spell Dam 5"] = "Büyü Hasarını Artır 5" end
if B["Increase Spell Dam 51"] == nil then B["Increase Spell Dam 51"] = "Büyü Hasarını Artır 51" end
if B["Increase Spell Dam 53"] == nil then B["Increase Spell Dam 53"] = "Büyü Hasarını Artır 53" end
if B["Increase Spell Dam 56"] == nil then B["Increase Spell Dam 56"] = "Büyü Hasarını Artır 56" end
if B["Increase Spell Dam 57"] == nil then B["Increase Spell Dam 57"] = "Büyü Hasarını Artır 57" end
if B["Increase Spell Dam 59"] == nil then B["Increase Spell Dam 59"] = "Büyü Hasarını Artır 59" end
if B["Increase Spell Dam 6"] == nil then B["Increase Spell Dam 6"] = "Büyü Hasarını Artır 6" end
if B["Increase Spell Dam 60"] == nil then B["Increase Spell Dam 60"] = "Büyü Hasarını Artır 60" end
if B["Increase Spell Dam 64"] == nil then B["Increase Spell Dam 64"] = "Büyü Hasarını Artır 64" end
if B["Increase Spell Dam 7"] == nil then B["Increase Spell Dam 7"] = "Büyü Hasarını Artır 7" end
if B["Increase Spell Dam 71"] == nil then B["Increase Spell Dam 71"] = "Büyü Hasarını Artır 71" end
if B["Increase Spell Dam 72"] == nil then B["Increase Spell Dam 72"] = "Büyü Hasarını Artır 72" end
if B["Increase Spell Dam 76"] == nil then B["Increase Spell Dam 76"] = "Büyü Hasarını Artır 76" end
if B["Increase Spell Dam 8"] == nil then B["Increase Spell Dam 8"] = "Büyü Hasarını Artır 8" end
if B["Increase Spell Dam 84"] == nil then B["Increase Spell Dam 84"] = "Büyü Hasarını Artır 84" end
if B["Increase Spell Dam 840"] == nil then B["Increase Spell Dam 840"] = "Büyü Hasarını Artır 840" end
if B["Increase Spell Dam 85"] == nil then B["Increase Spell Dam 85"] = "Büyü Hasarını Artır 85" end
if B["Increase Spell Dam 9"] == nil then B["Increase Spell Dam 9"] = "Büyü Hasarını Artır 9" end
if B["Increase Spell Dam 95"] == nil then B["Increase Spell Dam 95"] = "Büyü Hasarını Artır 95" end
if B["Increase Spell Dam Undead 26"] == nil then B["Increase Spell Dam Undead 26"] = "Ölümsüzlere Karşı Büyü Hasarını Artır 26" end
if B["Increase Spell Dam Undead 35"] == nil then B["Increase Spell Dam Undead 35"] = "Ölümsüzlere Karşı Büyü Hasarını Artır 35" end
if B["Increase Spell Dam Undead 48"] == nil then B["Increase Spell Dam Undead 48"] = "Ölümsüzlere Karşı Büyü Hasarını Artır 48" end
if B["Increased 1H Axe"] == nil then B["Increased 1H Axe"] = "Tek Elli Balta Becerisi Artışı" end
if B["Increased 1H Fist Weapons"] == nil then B["Increased 1H Fist Weapons"] = "Yumruk Silahları Becerisi Artışı" end
if B["Increased 1H Mace"] == nil then B["Increased 1H Mace"] = "Tek Elli Gürz Becerisi Artışı" end
if B["Increased 1H Sword"] == nil then B["Increased 1H Sword"] = "Tek Elli Kılıç Becerisi Artışı" end
if B["Increased 2H Axe"] == nil then B["Increased 2H Axe"] = "Çift Elli Balta Becerisi Artışı" end
if B["Increased 2H Mace"] == nil then B["Increased 2H Mace"] = "Çift Elli Gürz Becerisi Artışı" end
if B["Increased 2H Sword"] == nil then B["Increased 2H Sword"] = "Çift Elli Kılıç Becerisi Artışı" end
if B["Increased All Resist 05"] == nil then B["Increased All Resist 05"] = "Tüm Direnç Artışı 05" end
if B["Increased Arcane Resist 08"] == nil then B["Increased Arcane Resist 08"] = "Arkan Direnci Artışı 08" end
if B["Increased Arcane Resist 10"] == nil then B["Increased Arcane Resist 10"] = "Arkan Direnci Artışı 10" end
if B["Increased Arcane Resist 12"] == nil then B["Increased Arcane Resist 12"] = "Arkan Direnci Artışı 12" end
if B["Increased Arcane Resist 14"] == nil then B["Increased Arcane Resist 14"] = "Arkan Direnci Artışı 14" end
if B["Increased Armor 1000"] == nil then B["Increased Armor 1000"] = "Zırh Artışı 1000" end
if B["Increased Armor 150"] == nil then B["Increased Armor 150"] = "Zırh Artışı 150" end
if B["Increased Armor 200"] == nil then B["Increased Armor 200"] = "Zırh Artışı 200" end
if B["Increased Armor 250"] == nil then B["Increased Armor 250"] = "Zırh Artışı 250" end
if B["Increased Block 1"] == nil then B["Increased Block 1"] = "Engelleme Artışı 1" end
if B["Increased Block 2"] == nil then B["Increased Block 2"] = "Engelleme Artışı 2" end
if B["Increased Block 20"] == nil then B["Increased Block 20"] = "Engelleme Artışı 20" end
if B["Increased Block 3"] == nil then B["Increased Block 3"] = "Engelleme Artışı 3" end
if B["Increased Block 5"] == nil then B["Increased Block 5"] = "Engelleme Artışı 5" end
if B["Increased Bow"] == nil then B["Increased Bow"] = "Yay Becerisi Artışı" end
if B["Increased Critical 1"] == nil then B["Increased Critical 1"] = "Kritik Vuruş Artışı 1" end
if B["Increased Critical 10"] == nil then B["Increased Critical 10"] = "Kritik Vuruş Artışı 10" end
if B["Increased Critical 2"] == nil then B["Increased Critical 2"] = "Kritik Vuruş Artışı 2" end
if B["Increased Critical 5"] == nil then B["Increased Critical 5"] = "Kritik Vuruş Artışı 5" end
if B["Increased Critical Holy Spells"] == nil then B["Increased Critical Holy Spells"] = "Kutsal Büyü Kritiği Artışı" end
if B["Increased Critical Spell"] == nil then B["Increased Critical Spell"] = "Büyü Kritiği Artışı" end
if B["Increased Critical Spell Shadow"] == nil then B["Increased Critical Spell Shadow"] = "Gölge Büyüsü Kritiği Artışı" end
if B["Increased Crossbow"] == nil then B["Increased Crossbow"] = "Arbalet Becerisi Artışı" end
if B["Increased Dagger"] == nil then B["Increased Dagger"] = "Hançer Becerisi Artışı" end
if B["Increased Defense"] == nil then B["Increased Defense"] = "Savunma Artışı" end
if B["Increased Dodge 1"] == nil then B["Increased Dodge 1"] = "Kaçınma Artışı 1" end
if B["Increased Dodge 2"] == nil then B["Increased Dodge 2"] = "Kaçınma Artışı 2" end
if B["Increased Dodge 8"] == nil then B["Increased Dodge 8"] = "Kaçınma Artışı 8" end
if B["Increased Fire Resist 08"] == nil then B["Increased Fire Resist 08"] = "Ateş Direnci Artışı 08" end
if B["Increased Fire Resist 10"] == nil then B["Increased Fire Resist 10"] = "Ateş Direnci Artışı 10" end
if B["Increased Flash of Light Healing"] == nil then B["Increased Flash of Light Healing"] = "Işık Parlaması İyileştirme Artışı" end
if B["Increased Frost Resist 08"] == nil then B["Increased Frost Resist 08"] = "Ayaz Direnci Artışı 08" end
if B["Increased Frost Resist 10"] == nil then B["Increased Frost Resist 10"] = "Ayaz Direnci Artışı 10" end
if B["Increased Frost Resist 12"] == nil then B["Increased Frost Resist 12"] = "Ayaz Direnci Artışı 12" end
if B["Increased Frost Resist 14"] == nil then B["Increased Frost Resist 14"] = "Ayaz Direnci Artışı 14" end
if B["Increased Gun"] == nil then B["Increased Gun"] = "Tüfek Becerisi Artışı" end
if B["Increased Hit Chance 1"] == nil then B["Increased Hit Chance 1"] = "İsabet Şansı Artışı 1" end
if B["Increased Hit Chance 10"] == nil then B["Increased Hit Chance 10"] = "İsabet Şansı Artışı 10" end
if B["Increased Hit Chance 2"] == nil then B["Increased Hit Chance 2"] = "İsabet Şansı Artışı 2" end
if B["Increased Hit Chance 3"] == nil then B["Increased Hit Chance 3"] = "İsabet Şansı Artışı 3" end
if B["Increased Holy Criticals"] == nil then B["Increased Holy Criticals"] = "Kutsal Kritik Artışı" end
if B["Increased Hunter Pet Damage"] == nil then B["Increased Hunter Pet Damage"] = "Avcı Hayvanı Hasar Artışı" end
if B["Increased Imp Firebolt Damage"] == nil then B["Increased Imp Firebolt Damage"] = "Imp Ateş Oku Hasar Artışı" end
if B["Increased Lesser Healing Wave"] == nil then B["Increased Lesser Healing Wave"] = "Küçük İyileştirme Dalgası Artışı" end
if B["Increased Lightning Damage"] == nil then B["Increased Lightning Damage"] = "Yıldırım Hasarı Artışı" end
if B["Increased Mana Regen"] == nil then B["Increased Mana Regen"] = "Mana Yenilenmesi Artışı" end
if B["Increased Nature Criticals"] == nil then B["Increased Nature Criticals"] = "Doğa Kritiği Artışı" end
if B["Increased Nature Resist 08"] == nil then B["Increased Nature Resist 08"] = "Doğa Direnci Artışı 08" end
if B["Increased Nature Resist 10"] == nil then B["Increased Nature Resist 10"] = "Doğa Direnci Artışı 10" end
if B["Increased Nature Resist 12"] == nil then B["Increased Nature Resist 12"] = "Doğa Direnci Artışı 12" end
if B["Increased Nature Resist 14"] == nil then B["Increased Nature Resist 14"] = "Doğa Direnci Artışı 14" end
if B["Increased Parry 1"] == nil then B["Increased Parry 1"] = "Savuşturma Artışı 1" end
if B["Increased Parry 2"] == nil then B["Increased Parry 2"] = "Savuşturma Artışı 2" end
if B["Increased Parry 5"] == nil then B["Increased Parry 5"] = "Savuşturma Artışı 5" end
if B["Increased Pet Armor +10%"] == nil then B["Increased Pet Armor +10%"] = "Evcil Hayvan Zırhı Artışı +%10" end
if B["Increased Pet Crit +2%"] == nil then B["Increased Pet Crit +2%"] = "Evcil Hayvan Kritiği Artışı +%2" end
if B["Increased Pet Damage +3%"] == nil then B["Increased Pet Damage +3%"] = "Evcil Hayvan Hasarı Artışı +%3" end
if B["Increased Pet Health +3%"] == nil then B["Increased Pet Health +3%"] = "Evcil Hayvan Sağlığı Artışı +%3" end
if B["Increased Rejuvenation Healing"] == nil then B["Increased Rejuvenation Healing"] = "Yenilenme İyileştirme Artışı" end
if B["Increased Shadow Resist 10"] == nil then B["Increased Shadow Resist 10"] = "Gölge Direnci Artışı 10" end
if B["Increased Shadow Resist 12"] == nil then B["Increased Shadow Resist 12"] = "Gölge Direnci Artışı 12" end
if B["Increased Shadow Resist 14"] == nil then B["Increased Shadow Resist 14"] = "Gölge Direnci Artışı 14" end
if B["Increased Shock Damage"] == nil then B["Increased Shock Damage"] = "Şok Hasarı Artışı" end
if B["Increased Spell Hit Chance 1"] == nil then B["Increased Spell Hit Chance 1"] = "Büyü İsabet Şansı Artışı 1" end
if B["Increased Spell Hit Chance 2"] == nil then B["Increased Spell Hit Chance 2"] = "Büyü İsabet Şansı Artışı 2" end
if B["Increased Spell Penetration 10"] == nil then B["Increased Spell Penetration 10"] = "Büyü Delme Artışı 10" end
if B["Increased Spell Penetration 20"] == nil then B["Increased Spell Penetration 20"] = "Büyü Delme Artışı 20" end
if B["Increased Spell Penetration 25"] == nil then B["Increased Spell Penetration 25"] = "Büyü Delme Artışı 25" end
if B["Inducing Vision"] == nil then B["Inducing Vision"] = "Vizyon Uyandır" end
if B["Infallible Mind"] == nil then B["Infallible Mind"] = "Yanılmaz Zihin" end
if B["Inferno"] == nil then B["Inferno"] = "Cehennem Ateşi" end
if B["Insight"] == nil then B["Insight"] = "Sezgi" end
if B["Instant Poison III"] == nil then B["Instant Poison III"] = "Ani Zehir III" end
if B["Instant Poison IV"] == nil then B["Instant Poison IV"] = "Ani Zehir IV" end
if B["Instant Poison V"] == nil then B["Instant Poison V"] = "Ani Zehir V" end
if B["Instant Poison VI"] == nil then B["Instant Poison VI"] = "Ani Zehir VI" end
if B["Instant Toxin"] == nil then B["Instant Toxin"] = "Ani Toksin" end
if B["Intellect"] == nil then B["Intellect"] = "Zekâ" end
if B["Invisibility"] == nil then B["Invisibility"] = "Görünmezlik" end
if B["Invulnerability"] == nil then B["Invulnerability"] = "Dokunulmazlık" end
if B["Iron Grenade"] == nil then B["Iron Grenade"] = "Demir El Bombası" end
if B["Iron Shield Spike"] == nil then B["Iron Shield Spike"] = "Demir Kalkan Çivisi" end
if B["Ironforge Breastplate"] == nil then B["Ironforge Breastplate"] = "Ironforge Göğüs Zırhı" end
if B["Ironforge Chain"] == nil then B["Ironforge Chain"] = "Ironforge Zinciri" end
if B["Ironforge Gauntlets"] == nil then B["Ironforge Gauntlets"] = "Ironforge Demir Eldiveni" end
if B["Ironforge Gift of Friendship"] == nil then B["Ironforge Gift of Friendship"] = "Ironforge Dostluk Hediyesi" end
if B["Item - Minor Run Speed"] == nil then B["Item - Minor Run Speed"] = "Eşya - Küçük Koşu Hızı" end
if B["Item - Purify"] == nil then B["Item - Purify"] = "Eşya - Arındır" end
if B["Ivory Raptor"] == nil then B["Ivory Raptor"] = "Fildişi Raptor" end
if B["Jeklik's Crushing Blow"] == nil then B["Jeklik's Crushing Blow"] = "Jeklik'in Ezici Darbesi" end
if B["Join Map Fragments"] == nil then B["Join Map Fragments"] = "Harita Parçalarını Birleştir" end
if B["Jubling Cooldown"] == nil then B["Jubling Cooldown"] = "Jubling Bekleme Süresi" end
if B["Juju Chill"] == nil then B["Juju Chill"] = "Juju Ayazı" end
if B["Juju Ember"] == nil then B["Juju Ember"] = "Juju Közü" end
if B["Juju Escape"] == nil then B["Juju Escape"] = "Juju Kaçışı" end
if B["Juju Flurry"] == nil then B["Juju Flurry"] = "Juju Sağanağı" end
if B["Juju Guile"] == nil then B["Juju Guile"] = "Juju Kurnazlığı" end
if B["Juju Might"] == nil then B["Juju Might"] = "Juju Kudreti" end
if B["Juju Power"] == nil then B["Juju Power"] = "Juju Gücü" end
if B["Julie's Blessing"] == nil then B["Julie's Blessing"] = "Julie'nin Kutsaması" end
if B["Kadrak's Flag"] == nil then B["Kadrak's Flag"] = "Kadrak'ın Bayrağı" end
if B["Keeper's Sting"] == nil then B["Keeper's Sting"] = "Bekçinin Iğnesi" end
if B["Khadgar's Unlocking"] == nil then B["Khadgar's Unlocking"] = "Khadgar'ın Kilit Açması" end
if B["Kiss of the Spider"] == nil then B["Kiss of the Spider"] = "Örümceğin Öpücüğü" end
if B["Kodo Kombobulator"] == nil then B["Kodo Kombobulator"] = "Kodo Kombobulatörü" end
if B["Kreeg's Stout Beatdown"] == nil then B["Kreeg's Stout Beatdown"] = "Kreeg'in Sert Dayak Birası" end
if B["Lacerations"] == nil then B["Lacerations"] = "Yırtıklar" end
if B["Large Blue Firework Cluster"] == nil then B["Large Blue Firework Cluster"] = "Büyük Mavi Havai Fişek Demeti" end
if B["Large Blue Rocket"] == nil then B["Large Blue Rocket"] = "Büyük Mavi Roket" end
if B["Large Copper Bomb"] == nil then B["Large Copper Bomb"] = "Büyük Bakır Bomba" end
if B["Large Green Firework Cluster"] == nil then B["Large Green Firework Cluster"] = "Büyük Yeşil Havai Fişek Demeti" end
if B["Large Green Rocket"] == nil then B["Large Green Rocket"] = "Büyük Yeşil Roket" end
if B["Large Purple Firework Cluster"] == nil then B["Large Purple Firework Cluster"] = "Büyük Mor Havai Fişek Demeti" end
if B["Large Purple Rocket"] == nil then B["Large Purple Rocket"] = "Büyük Mor Roket" end
if B["Large Red Firework Cluster"] == nil then B["Large Red Firework Cluster"] = "Büyük Kırmızı Havai Fişek Demeti" end
if B["Large Red Rocket"] == nil then B["Large Red Rocket"] = "Büyük Kırmızı Roket" end
if B["Large Seaforium Charge"] == nil then B["Large Seaforium Charge"] = "Büyük Seaforium Patlayıcısı" end
if B["Large Timber Wolf"] == nil then B["Large Timber Wolf"] = "Büyük Orman Kurdu" end
if B["Large White Firework Cluster"] == nil then B["Large White Firework Cluster"] = "Büyük Beyaz Havai Fişek Demeti" end
if B["Large White Rocket"] == nil then B["Large White Rocket"] = "Büyük Beyaz Roket" end
if B["Large Yellow Firework Cluster"] == nil then B["Large Yellow Firework Cluster"] = "Büyük Sarı Havai Fişek Demeti" end
if B["Large Yellow Rocket"] == nil then B["Large Yellow Rocket"] = "Büyük Sarı Roket" end
if B["Lash of Pain"] == nil then B["Lash of Pain"] = "Acı Kırbacı" end
if B["Learn Ferocious Bite"] == nil then B["Learn Ferocious Bite"] = "Vahşi Isırık Öğren" end
if B["Left Piece of Lord Valthalak's Amulet"] == nil then B["Left Piece of Lord Valthalak's Amulet"] = "Lord Valthalak'ın Muskasının Sol Parçası" end
if B["Legendary Arcane Amalgamation"] == nil then B["Legendary Arcane Amalgamation"] = "Efsanevi Arkan Birleşimi" end
if B["Leopard"] == nil then B["Leopard"] = "Leopar" end
if B["Leper Gnome Costume"] == nil then B["Leper Gnome Costume"] = "Cüzamlı Gnome Kostümü" end
if B["Lesser Agility"] == nil then B["Lesser Agility"] = "Küçük Çeviklik" end
if B["Lesser Arcane Amalgamation"] == nil then B["Lesser Arcane Amalgamation"] = "Küçük Arkan Birleşimi" end
if B["Lesser Armor"] == nil then B["Lesser Armor"] = "Küçük Zırh" end
if B["Lesser Astral Essence"] == nil then B["Lesser Astral Essence"] = "Küçük Astral Öz" end
if B["Lesser Eternal Essence"] == nil then B["Lesser Eternal Essence"] = "Küçük Ebedi Öz" end
if B["Lesser Healthstone"] == nil then B["Lesser Healthstone"] = "Küçük Sağlık Taşı" end
if B["Lesser Intellect"] == nil then B["Lesser Intellect"] = "Küçük Zekâ" end
if B["Lesser Invisibility"] == nil then B["Lesser Invisibility"] = "Küçük Görünmezlik" end
if B["Lesser Magic Essence"] == nil then B["Lesser Magic Essence"] = "Küçük Büyü Özü" end
if B["Lesser Mana Oil"] == nil then B["Lesser Mana Oil"] = "Küçük Mana Yağı" end
if B["Lesser Mark of the Dawn"] == nil then B["Lesser Mark of the Dawn"] = "Şafağın Küçük Nişanı" end
if B["Lesser Mystic Essence"] == nil then B["Lesser Mystic Essence"] = "Küçük Mistik Öz" end
if B["Lesser Nether Essence"] == nil then B["Lesser Nether Essence"] = "Küçük Nether Özü" end
if B["Lesser Strength"] == nil then B["Lesser Strength"] = "Küçük Güç" end
if B["Lesser Wizard Oil"] == nil then B["Lesser Wizard Oil"] = "Küçük Büyücü Yağı" end
if B["Lifestone Healing"] == nil then B["Lifestone Healing"] = "Yaşam Taşı İyileştirmesi" end
if B["Lifestone Regeneration"] == nil then B["Lifestone Regeneration"] = "Yaşam Taşı Yenilenmesi" end
if B["Lift Seal"] == nil then B["Lift Seal"] = "Mührü Kaldır" end
if B["Light Torch"] == nil then B["Light Torch"] = "Meşale Yak" end
if B["Light of Elune"] == nil then B["Light of Elune"] = "Elune'un Işığı" end
if B["Lightheaded"] == nil then B["Lightheaded"] = "Sersemlik" end
if B["Lightning Storm"] == nil then B["Lightning Storm"] = "Yıldırım Fırtınası" end
if B["Lightning Strike"] == nil then B["Lightning Strike"] = "Yıldırım Çarpması" end
if B["Lily Root"] == nil then B["Lily Root"] = "Zambak Kökü" end
if B["Linken's Boomerang"] == nil then B["Linken's Boomerang"] = "Linken'in Bumerangı" end
if B["Living Free Action"] == nil then B["Living Free Action"] = "Canlı Serbest Hareket" end
if B["Loatheb's Reflection"] == nil then B["Loatheb's Reflection"] = "Loatheb'in Yansıması" end
if B["Lockpicking 5"] == nil then B["Lockpicking 5"] = "Kilit Açma 5" end
if B["Longsight"] == nil then B["Longsight"] = "Uzak Görüş" end
if B["Lord General's Sword"] == nil then B["Lord General's Sword"] = "Lord General'in Kılıcı" end
if B["Love Fool"] == nil then B["Love Fool"] = "Aşk Budalası" end
if B["Lucky Lunar Rocket"] == nil then B["Lucky Lunar Rocket"] = "Şanslı Ay Roketi" end
if B["Luffa"] == nil then B["Luffa"] = "Lif Kabağı" end
if B["Lunar Invititation"] == nil then B["Lunar Invititation"] = "Ay Daveti" end
if B["M73 Frag Grenade"] == nil then B["M73 Frag Grenade"] = "M73 Parça Tesirli El Bombası" end
if B["Mageweave Bandage"] == nil then B["Mageweave Bandage"] = "Büyü Kumaşı Sargı" end
if B["Major Healthstone"] == nil then B["Major Healthstone"] = "Büyük Sağlık Taşı" end
if B["Major Spellstone"] == nil then B["Major Spellstone"] = "Büyük Büyü Taşı" end
if B["Malown's Slam"] == nil then B["Malown's Slam"] = "Malown'un Darbesi" end
if B["Mana Drain Trigger"] == nil then B["Mana Drain Trigger"] = "Mana Emme Tetikleyicisi" end
if B["Mana Funnel"] == nil then B["Mana Funnel"] = "Mana Hunisi" end
if B["Mana Infusion"] == nil then B["Mana Infusion"] = "Mana Aşılama" end
if B["Mana Regeneration"] == nil then B["Mana Regeneration"] = "Mana Yenilenmesi" end
if B["Mana Rejuvenation"] == nil then B["Mana Rejuvenation"] = "Mana Tazelenmesi" end
if B["Mana Shield Absorb Increase"] == nil then B["Mana Shield Absorb Increase"] = "Mana Kalkanı Emme Artışı" end
if B["Manifest Spirit"] == nil then B["Manifest Spirit"] = "Ruhu Görünür Kıl" end
if B["Mar'li's Brain Boost"] == nil then B["Mar'li's Brain Boost"] = "Mar'li'nin Beyin Takviyesi" end
if B["Maraudon Portal"] == nil then B["Maraudon Portal"] = "Maraudon Geçidi" end
if B["Mark of the Chosen"] == nil then B["Mark of the Chosen"] = "Seçilmişin Nişanı" end
if B["Mark of the Dawn"] == nil then B["Mark of the Dawn"] = "Şafağın Nişanı" end
if B["Mark of the Dragon Lord"] == nil then B["Mark of the Dragon Lord"] = "Ejderha Lordunun Nişanı" end
if B["Massive Destruction"] == nil then B["Massive Destruction"] = "Büyük Yıkım" end
if B["Master Angler"] == nil then B["Master Angler"] = "Usta Balıkçı" end
if B["Mechanical Dragonling"] == nil then B["Mechanical Dragonling"] = "Mekanik Ejderha Yavrusu" end
if B["Mechanical Patch Kit"] == nil then B["Mechanical Patch Kit"] = "Mekanik Yama Takımı" end
if B["Mechanical Squirrel"] == nil then B["Mechanical Squirrel"] = "Mekanik Sincap" end
if B["Melodious Rapture"] == nil then B["Melodious Rapture"] = "Ahenkli Coşku" end
if B["Mercurial Shield"] == nil then B["Mercurial Shield"] = "Cıva Kalkanı" end
if B["Metamorphosis Rune"] == nil then B["Metamorphosis Rune"] = "Başkalaşım Rünü" end
if B["Miblon's Bait"] == nil then B["Miblon's Bait"] = "Miblon'un Yemi" end
if B["Midsummer Sausage"] == nil then B["Midsummer Sausage"] = "Yaz Ortası Sucuğu" end
if B["Might of the Scourge"] == nil then B["Might of the Scourge"] = "Scourge'un Kudreti" end
if B["Mighty Rage"] == nil then B["Mighty Rage"] = "Kudretli Öfke" end
if B["Mind Blast Cast Pushback Reduction"] == nil then B["Mind Blast Cast Pushback Reduction"] = "Zihin Patlaması Kesinti Azaltma" end
if B["Mind Bomb"] == nil then B["Mind Bomb"] = "Zihin Bombası" end
if B["Mind Quickening"] == nil then B["Mind Quickening"] = "Zihin Hızlanması" end
if B["Mind Rot"] == nil then B["Mind Rot"] = "Zihin Çürümesi" end
if B["Mind-numbing Poison II"] == nil then B["Mind-numbing Poison II"] = "Zihin Uyuşturan Zehir II" end
if B["Mind-numbing Poison III"] == nil then B["Mind-numbing Poison III"] = "Zihin Uyuşturan Zehir III" end
if B["Minor Healthstone"] == nil then B["Minor Healthstone"] = "Ufak Sağlık Taşı" end
if B["Minor Mana Oil"] == nil then B["Minor Mana Oil"] = "Ufak Mana Yağı" end
if B["Minor Wizard Oil"] == nil then B["Minor Wizard Oil"] = "Ufak Büyücü Yağı" end
if B["Mistletoe"] == nil then B["Mistletoe"] = "Ökseotu" end
if B["Mithril Frag Bomb"] == nil then B["Mithril Frag Bomb"] = "Mithril Parça Bombası" end
if B["Mithril Mechanical Dragonling"] == nil then B["Mithril Mechanical Dragonling"] = "Mithril Mekanik Ejderha Yavrusu" end
if B["Mithril Shield Spike"] == nil then B["Mithril Shield Spike"] = "Mithril Kalkan Dikeni" end
if B["Mithril Spurs"] == nil then B["Mithril Spurs"] = "Mithril Mahmuzlar" end
if B["Moist Towelette"] == nil then B["Moist Towelette"] = "Islak Mendil" end
if B["Molten Blast"] == nil then B["Molten Blast"] = "Erimiş Patlama" end
if B["Moonglow Alcohol"] == nil then B["Moonglow Alcohol"] = "Ay Işıltısı Alkolü" end
if B["Mottled Red Raptor"] == nil then B["Mottled Red Raptor"] = "Benekli Kırmızı Raptor" end
if B["Mount Speed"] == nil then B["Mount Speed"] = "Binek Hızı" end
if B["Multi-Shot Damage Increase"] == nil then B["Multi-Shot Damage Increase"] = "Çoklu Atış Hasar Artışı" end
if B["Mystical Disjunction"] == nil then B["Mystical Disjunction"] = "Mistik Ayrılma" end
if B["Nature Aligned"] == nil then B["Nature Aligned"] = "Doğayla Uyumlu" end
if B["Nature Mantle of the Dawn"] == nil then B["Nature Mantle of the Dawn"] = "Şafağın Doğa Pelerini" end
if B["Nature Protection "] == nil then B["Nature Protection "] = "Doğa Koruması" end
if B["Net-o-Matic"] == nil then B["Net-o-Matic"] = "Ağ-o-Matik" end
if B["Night Dragon's Breath"] == nil then B["Night Dragon's Breath"] = "Gece Ejderhası Nefesi" end
if B["Nightcrawlers"] == nil then B["Nightcrawlers"] = "Gece Solucanları" end
if B["Nimble Healing Touch"] == nil then B["Nimble Healing Touch"] = "Çevik İyileştiren Dokunuş" end
if B["Ninja Costume"] == nil then B["Ninja Costume"] = "Ninja Kostümü" end
if B["Noggenfogger Elixir"] == nil then B["Noggenfogger Elixir"] = "Noggenfogger Eliksiri" end
if B["Nullify Disease"] == nil then B["Nullify Disease"] = "Hastalığı Etkisiz Kıl" end
if B["Nullify Poison"] == nil then B["Nullify Poison"] = "Zehri Etkisiz Kıl" end
if B["Numbing Pain"] == nil then B["Numbing Pain"] = "Uyuşturan Acı" end
if B["Obsidian Armor"] == nil then B["Obsidian Armor"] = "Obsidyen Zırh" end
if B["Obsidian Insight"] == nil then B["Obsidian Insight"] = "Obsidyen Sezgisi" end
if B["Obsidian Raptor"] == nil then B["Obsidian Raptor"] = "Obsidyen Raptor" end
if B["Onyxia Scale Cloak"] == nil then B["Onyxia Scale Cloak"] = "Onyxia Pulu Pelerin" end
if B["Opening"] == nil then B["Opening"] = "Açılıyor" end
if B["Opening Bar Door"] == nil then B["Opening Bar Door"] = "Parmaklıklı Kapı Açılıyor" end
if B["Opening Benedict's Chest"] == nil then B["Opening Benedict's Chest"] = "Benedict'in Sandığı Açılıyor" end
if B["Opening Booty Chest"] == nil then B["Opening Booty Chest"] = "Ganimet Sandığı Açılıyor" end
if B["Opening Cage"] == nil then B["Opening Cage"] = "Kafes Açılıyor" end
if B["Opening Chest"] == nil then B["Opening Chest"] = "Sandık Açılıyor" end
if B["Opening Dark Coffer"] == nil then B["Opening Dark Coffer"] = "Karanlık Kasa Açılıyor" end
if B["Opening Greater Scarab Coffer"] == nil then B["Opening Greater Scarab Coffer"] = "Büyük Skarabe Sandığı Açılıyor" end
if B["Opening Relic Coffer"] == nil then B["Opening Relic Coffer"] = "Kalıntı Sandığı Açılıyor" end
if B["Opening Safe"] == nil then B["Opening Safe"] = "Kasa Açılıyor" end
if B["Opening Scarab Coffer"] == nil then B["Opening Scarab Coffer"] = "Skarabe Sandığı Açılıyor" end
if B["Opening Secret Safe"] == nil then B["Opening Secret Safe"] = "Gizli Kasa Açılıyor" end
if B["Opening Stratholme Postbox"] == nil then B["Opening Stratholme Postbox"] = "Stratholme Posta Kutusu Açılıyor" end
if B["Opening Strongbox"] == nil then B["Opening Strongbox"] = "Sağlam Kasa Açılıyor" end
if B["Opening Termite Barrel"] == nil then B["Opening Termite Barrel"] = "Termit Varili Açılıyor" end
if B["Orb of Deception"] == nil then B["Orb of Deception"] = "Aldatma Küresi" end
if B["Orb of Fire"] == nil then B["Orb of Fire"] = "Ateş Küresi" end
if B["Orgrimmar Gift of Friendship"] == nil then B["Orgrimmar Gift of Friendship"] = "Orgrimmar Dostluk Hediyesi" end
if B["Pagle's Broken Reel"] == nil then B["Pagle's Broken Reel"] = "Pagle'ın Kırık Makarası" end
if B["Pagle's Point Cast - Create Mudskunk Lure"] == nil then B["Pagle's Point Cast - Create Mudskunk Lure"] = "Pagle's Point Atışı - Mudskunk Yemi Yarat" end
if B["Palamino Stallion"] == nil then B["Palamino Stallion"] = "Palomino Aygırı" end
if B["Palomino Stallion"] == nil then B["Palomino Stallion"] = "Palomino Aygırı" end
if B["Panther"] == nil then B["Panther"] = "Panter" end
if B["Panther Cage Key"] == nil then B["Panther Cage Key"] = "Panter Kafesi Anahtarı" end
if B["Paranoia"] == nil then B["Paranoia"] = "Paranoya" end
if B["Party Fever"] == nil then B["Party Fever"] = "Parti Ateşi" end
if B["Path of Defense"] == nil then B["Path of Defense"] = "Savunma Yolu" end
if B["Path of the Berserker"] == nil then B["Path of the Berserker"] = "Çılgın Savaşçının Yolu" end
if B["Pattern: Admiral's Hat"] == nil then B["Pattern: Admiral's Hat"] = "Desen: Amiral Şapkası" end
if B["Pattern: Argent Boots"] == nil then B["Pattern: Argent Boots"] = "Desen: Argent Çizmeleri" end
if B["Pattern: Argent Shoulders"] == nil then B["Pattern: Argent Shoulders"] = "Desen: Argent Omuzlukları" end
if B["Pattern: Azure Shoulders"] == nil then B["Pattern: Azure Shoulders"] = "Desen: Gök Mavisi Omuzluklar" end
if B["Pattern: Azure Silk Cloak"] == nil then B["Pattern: Azure Silk Cloak"] = "Desen: Gök Mavisi İpek Pelerin" end
if B["Pattern: Barbaric Belt"] == nil then B["Pattern: Barbaric Belt"] = "Desen: Barbar Kemeri" end
if B["Pattern: Barbaric Bracers"] == nil then B["Pattern: Barbaric Bracers"] = "Desen: Barbar Bileklikleri" end
if B["Pattern: Barbaric Gloves"] == nil then B["Pattern: Barbaric Gloves"] = "Desen: Barbar Eldivenleri" end
if B["Pattern: Barbaric Leggings"] == nil then B["Pattern: Barbaric Leggings"] = "Desen: Barbar Tozluğu" end
if B["Pattern: Belt of the Archmage"] == nil then B["Pattern: Belt of the Archmage"] = "Desen: Başbüyücünün Kemeri" end
if B["Pattern: Big Bag of Enchantment"] == nil then B["Pattern: Big Bag of Enchantment"] = "Desen: Büyük Efsun Çantası" end
if B["Pattern: Big Voodoo Cloak"] == nil then B["Pattern: Big Voodoo Cloak"] = "Desen: Büyük Vudu Pelerini" end
if B["Pattern: Big Voodoo Mask"] == nil then B["Pattern: Big Voodoo Mask"] = "Desen: Büyük Vudu Maskesi" end
if B["Pattern: Big Voodoo Pants"] == nil then B["Pattern: Big Voodoo Pants"] = "Desen: Büyük Vudu Pantolonu" end
if B["Pattern: Big Voodoo Robe"] == nil then B["Pattern: Big Voodoo Robe"] = "Desen: Büyük Vudu Cüppesi" end
if B["Pattern: Black Dragonscale Boots"] == nil then B["Pattern: Black Dragonscale Boots"] = "Desen: Kara Ejderha Pulu Çizmeler" end
if B["Pattern: Black Dragonscale Breastplate"] == nil then B["Pattern: Black Dragonscale Breastplate"] = "Desen: Kara Ejderha Pulu Göğüs Zırhı" end
if B["Pattern: Black Dragonscale Leggings"] == nil then B["Pattern: Black Dragonscale Leggings"] = "Desen: Kara Ejderha Pulu Tozluk" end
if B["Pattern: Black Dragonscale Shoulders"] == nil then B["Pattern: Black Dragonscale Shoulders"] = "Desen: Kara Ejderha Pulu Omuzluklar" end
if B["Pattern: Black Silk Pack"] == nil then B["Pattern: Black Silk Pack"] = "Desen: Siyah İpek Sırt Çantası" end
if B["Pattern: Black Swashbucklers Shirt"] == nil then B["Pattern: Black Swashbucklers Shirt"] = "Desen: Siyah Korsan Gömleği" end
if B["Pattern: Black Whelp Tunic"] == nil then B["Pattern: Black Whelp Tunic"] = "Desen: Kara Yavru Ejderha Tuniği" end
if B["Pattern: Blood Tiger Breastplate"] == nil then B["Pattern: Blood Tiger Breastplate"] = "Desen: Kan Kaplanı Göğüs Zırhı" end
if B["Pattern: Blood Tiger Shoulders"] == nil then B["Pattern: Blood Tiger Shoulders"] = "Desen: Kan Kaplanı Omuzlukları" end
if B["Pattern: Bloodvine Boots"] == nil then B["Pattern: Bloodvine Boots"] = "Desen: Kan Sarmaşığı Çizmeleri" end
if B["Pattern: Bloodvine Leggings"] == nil then B["Pattern: Bloodvine Leggings"] = "Desen: Kan Sarmaşığı Tozluğu" end
if B["Pattern: Bloodvine Vest"] == nil then B["Pattern: Bloodvine Vest"] = "Desen: Kan Sarmaşığı Yeleği" end
if B["Pattern: Blue Dragonscale Breastplate"] == nil then B["Pattern: Blue Dragonscale Breastplate"] = "Desen: Mavi Ejderha Pulu Göğüs Zırhı" end
if B["Pattern: Blue Dragonscale Shoulders"] == nil then B["Pattern: Blue Dragonscale Shoulders"] = "Desen: Mavi Ejderha Pulu Omuzluklar" end
if B["Pattern: Blue Linen Robe"] == nil then B["Pattern: Blue Linen Robe"] = "Desen: Mavi Keten Cüppe" end
if B["Pattern: Blue Linen Vest"] == nil then B["Pattern: Blue Linen Vest"] = "Desen: Mavi Keten Yelek" end
if B["Pattern: Blue Overalls"] == nil then B["Pattern: Blue Overalls"] = "Desen: Mavi Tulum" end
if B["Pattern: Boots of Darkness"] == nil then B["Pattern: Boots of Darkness"] = "Desen: Karanlık Çizmeleri" end
if B["Pattern: Boots of the Enchanter"] == nil then B["Pattern: Boots of the Enchanter"] = "Desen: Efsuncunun Çizmeleri" end
if B["Pattern: Bottomless Bag"] == nil then B["Pattern: Bottomless Bag"] = "Desen: Dipsiz Çanta" end
if B["Pattern: Bramblewood Belt"] == nil then B["Pattern: Bramblewood Belt"] = "Desen: Böğürtlen Ağacı Kemeri" end
if B["Pattern: Bramblewood Boots"] == nil then B["Pattern: Bramblewood Boots"] = "Desen: Böğürtlen Ağacı Çizmeleri" end
if B["Pattern: Bramblewood Helm"] == nil then B["Pattern: Bramblewood Helm"] = "Desen: Böğürtlen Ağacı Miğferi" end
if B["Pattern: Bright Yellow Shirt"] == nil then B["Pattern: Bright Yellow Shirt"] = "Desen: Parlak Sarı Gömlek" end
if B["Pattern: Brightcloth Cloak"] == nil then B["Pattern: Brightcloth Cloak"] = "Desen: Parlak Kumaş Pelerin" end
if B["Pattern: Brightcloth Gloves"] == nil then B["Pattern: Brightcloth Gloves"] = "Desen: Parlak Kumaş Eldivenler" end
if B["Pattern: Brightcloth Pants"] == nil then B["Pattern: Brightcloth Pants"] = "Desen: Parlak Kumaş Pantolon" end
if B["Pattern: Brightcloth Robe"] == nil then B["Pattern: Brightcloth Robe"] = "Desen: Parlak Kumaş Cüppe" end
if B["Pattern: Cenarion Herb Bag"] == nil then B["Pattern: Cenarion Herb Bag"] = "Desen: Cenarion Ot Çantası" end
if B["Pattern: Chimeric Boots"] == nil then B["Pattern: Chimeric Boots"] = "Desen: Kimerik Çizmeler" end
if B["Pattern: Chimeric Gloves"] == nil then B["Pattern: Chimeric Gloves"] = "Desen: Kimerik Eldivenler" end
if B["Pattern: Chimeric Leggings"] == nil then B["Pattern: Chimeric Leggings"] = "Desen: Kimerik Tozluk" end
if B["Pattern: Chimeric Vest"] == nil then B["Pattern: Chimeric Vest"] = "Desen: Kimerik Yelek" end
if B["Pattern: Chromatic Cloak"] == nil then B["Pattern: Chromatic Cloak"] = "Desen: Kromatik Pelerin" end
if B["Pattern: Chromatic Gauntlets"] == nil then B["Pattern: Chromatic Gauntlets"] = "Desen: Kromatik Demir Eldivenler" end
if B["Pattern: Cindercloth Cloak"] == nil then B["Pattern: Cindercloth Cloak"] = "Desen: Kor Kumaşı Pelerin" end
if B["Pattern: Cindercloth Gloves"] == nil then B["Pattern: Cindercloth Gloves"] = "Desen: Kor Kumaşı Eldivenler" end
if B["Pattern: Cindercloth Pants"] == nil then B["Pattern: Cindercloth Pants"] = "Desen: Kor Kumaşı Pantolon" end
if B["Pattern: Cindercloth Vest"] == nil then B["Pattern: Cindercloth Vest"] = "Desen: Kor Kumaşı Yelek" end
if B["Pattern: Cloak of Fire"] == nil then B["Pattern: Cloak of Fire"] = "Desen: Ateş Pelerini" end
if B["Pattern: Cloak of Warding"] == nil then B["Pattern: Cloak of Warding"] = "Desen: Koruma Pelerini" end
if B["Pattern: Colorful Kilt"] == nil then B["Pattern: Colorful Kilt"] = "Desen: Renkli Etek" end
if B["Pattern: Comfortable Leather Hat"] == nil then B["Pattern: Comfortable Leather Hat"] = "Desen: Rahat Deri Şapka" end
if B["Pattern: Core Armor Kit"] == nil then B["Pattern: Core Armor Kit"] = "Desen: Çekirdek Zırh Takımı" end
if B["Pattern: Core Felcloth Bag"] == nil then B["Pattern: Core Felcloth Bag"] = "Desen: Çekirdek Fel Kumaşı Çanta" end
if B["Pattern: Corehound Belt"] == nil then B["Pattern: Corehound Belt"] = "Desen: Çekirdek Tazısı Kemeri" end
if B["Pattern: Corehound Boots"] == nil then B["Pattern: Corehound Boots"] = "Desen: Çekirdek Tazısı Çizmeleri" end
if B["Pattern: Crimson Silk Cloak"] == nil then B["Pattern: Crimson Silk Cloak"] = "Desen: Kızıl İpek Pelerin" end
if B["Pattern: Crimson Silk Robe"] == nil then B["Pattern: Crimson Silk Robe"] = "Desen: Kızıl İpek Cüppe" end
if B["Pattern: Crimson Silk Shoulders"] == nil then B["Pattern: Crimson Silk Shoulders"] = "Desen: Kızıl İpek Omuzluklar" end
if B["Pattern: Dark Leather Gloves"] == nil then B["Pattern: Dark Leather Gloves"] = "Desen: Koyu Deri Eldivenler" end
if B["Pattern: Dark Leather Shoulders"] == nil then B["Pattern: Dark Leather Shoulders"] = "Desen: Koyu Deri Omuzluklar" end
if B["Pattern: Dark Leather Tunic"] == nil then B["Pattern: Dark Leather Tunic"] = "Desen: Koyu Deri Tunik" end
if B["Pattern: Dark Silk Shirt"] == nil then B["Pattern: Dark Silk Shirt"] = "Desen: Koyu İpek Gömlek" end
if B["Pattern: Dawn Treaders"] == nil then B["Pattern: Dawn Treaders"] = "Desen: Şafak Yürüyüşçüleri" end
if B["Pattern: Deviate Scale Belt"] == nil then B["Pattern: Deviate Scale Belt"] = "Desen: Sapkın Pul Kemer" end
if B["Pattern: Deviate Scale Cloak"] == nil then B["Pattern: Deviate Scale Cloak"] = "Desen: Sapkın Pul Pelerin" end
if B["Pattern: Deviate Scale Gloves"] == nil then B["Pattern: Deviate Scale Gloves"] = "Desen: Sapkın Pul Eldivenler" end
if B["Pattern: Devilsaur Gauntlets"] == nil then B["Pattern: Devilsaur Gauntlets"] = "Desen: Devilsaur Demir Eldivenleri" end
if B["Pattern: Devilsaur Leggings"] == nil then B["Pattern: Devilsaur Leggings"] = "Desen: Devilsaur Tozluğu" end
if B["Pattern: Dreamscale Breastplate"] == nil then B["Pattern: Dreamscale Breastplate"] = "Desen: Rüya Pulu Göğüs Zırhı" end
if B["Pattern: Dusky Boots"] == nil then B["Pattern: Dusky Boots"] = "Desen: Alacakaranlık Çizmeleri" end
if B["Pattern: Dusky Leather Leggings"] == nil then B["Pattern: Dusky Leather Leggings"] = "Desen: Alacakaranlık Deri Tozluğu" end
if B["Pattern: Earthen Leather Shoulders"] == nil then B["Pattern: Earthen Leather Shoulders"] = "Desen: Topraksı Deri Omuzluklar" end
if B["Pattern: Earthen Silk Belt"] == nil then B["Pattern: Earthen Silk Belt"] = "Desen: Topraksı İpek Kemer" end
if B["Pattern: Enchanted Mageweave Pouch"] == nil then B["Pattern: Enchanted Mageweave Pouch"] = "Desen: Efsunlu Büyü Kumaşı Kese" end
if B["Pattern: Enchanted Runecloth Bag"] == nil then B["Pattern: Enchanted Runecloth Bag"] = "Desen: Efsunlu Rün Kumaşı Çanta" end
if B["Pattern: Enchanter's Cowl"] == nil then B["Pattern: Enchanter's Cowl"] = "Desen: Efsuncu Kukuletası" end
if B["Pattern: Felcloth Bag"] == nil then B["Pattern: Felcloth Bag"] = "Desen: Fel Kumaşı Çanta" end
if B["Pattern: Felcloth Boots"] == nil then B["Pattern: Felcloth Boots"] = "Desen: Fel Kumaşı Çizmeler" end
if B["Pattern: Felcloth Gloves"] == nil then B["Pattern: Felcloth Gloves"] = "Desen: Fel Kumaşı Eldivenler" end
if B["Pattern: Felcloth Hood"] == nil then B["Pattern: Felcloth Hood"] = "Desen: Fel Kumaşı Kukuleta" end
if B["Pattern: Felcloth Pants"] == nil then B["Pattern: Felcloth Pants"] = "Desen: Fel Kumaşı Pantolon" end
if B["Pattern: Felcloth Robe"] == nil then B["Pattern: Felcloth Robe"] = "Desen: Fel Kumaşı Cüppe" end
if B["Pattern: Felcloth Shoulders"] == nil then B["Pattern: Felcloth Shoulders"] = "Desen: Fel Kumaşı Omuzluklar" end
if B["Pattern: Festival Suit"] == nil then B["Pattern: Festival Suit"] = "Desen: Festival Takımı" end
if B["Pattern: Festive Red Dress"] == nil then B["Pattern: Festive Red Dress"] = "Desen: Şenlikli Kırmızı Elbise" end
if B["Pattern: Fine Leather Boots"] == nil then B["Pattern: Fine Leather Boots"] = "Desen: İnce Deri Çizmeler" end
if B["Pattern: Fine Leather Gloves"] == nil then B["Pattern: Fine Leather Gloves"] = "Desen: İnce Deri Eldivenler" end
if B["Pattern: Fine Leather Pants"] == nil then B["Pattern: Fine Leather Pants"] = "Desen: İnce Deri Pantolon" end
if B["Pattern: Flarecore Gloves"] == nil then B["Pattern: Flarecore Gloves"] = "Desen: Alev Çekirdeği Eldivenleri" end
if B["Pattern: Flarecore Leggings"] == nil then B["Pattern: Flarecore Leggings"] = "Desen: Alev Çekirdeği Tozluğu" end
if B["Pattern: Flarecore Mantle"] == nil then B["Pattern: Flarecore Mantle"] = "Desen: Alev Çekirdeği Omuzluğu" end
if B["Pattern: Flarecore Robe"] == nil then B["Pattern: Flarecore Robe"] = "Desen: Alev Çekirdeği Cüppesi" end
if B["Pattern: Flarecore Wraps"] == nil then B["Pattern: Flarecore Wraps"] = "Desen: Alev Çekirdeği Sargıları" end
if B["Pattern: Frostsaber Boots"] == nil then B["Pattern: Frostsaber Boots"] = "Desen: Frostsaber Çizmeleri" end
if B["Pattern: Frostsaber Gloves"] == nil then B["Pattern: Frostsaber Gloves"] = "Desen: Frostsaber Eldivenleri" end
if B["Pattern: Frostsaber Leggings"] == nil then B["Pattern: Frostsaber Leggings"] = "Desen: Frostsaber Tozluğu" end
if B["Pattern: Frostsaber Tunic"] == nil then B["Pattern: Frostsaber Tunic"] = "Desen: Frostsaber Tuniği" end
if B["Pattern: Frostweave Gloves"] == nil then B["Pattern: Frostweave Gloves"] = "Desen: Ayaz Dokuma Eldivenler" end
if B["Pattern: Frostweave Pants"] == nil then B["Pattern: Frostweave Pants"] = "Desen: Ayaz Dokuma Pantolon" end
if B["Pattern: Frostweave Robe"] == nil then B["Pattern: Frostweave Robe"] = "Desen: Ayaz Dokuma Cüppe" end
if B["Pattern: Frostweave Tunic"] == nil then B["Pattern: Frostweave Tunic"] = "Desen: Ayaz Dokuma Tunik" end
if B["Pattern: Gaea's Embrace"] == nil then B["Pattern: Gaea's Embrace"] = "Desen: Gaea'nın Kucağı" end
if B["Pattern: Gem-studded Leather Belt"] == nil then B["Pattern: Gem-studded Leather Belt"] = "Desen: Mücevher İşlemeli Deri Kemer" end
if B["Pattern: Ghostweave Belt"] == nil then B["Pattern: Ghostweave Belt"] = "Desen: Hayalet Dokuma Kemer" end
if B["Pattern: Ghostweave Gloves"] == nil then B["Pattern: Ghostweave Gloves"] = "Desen: Hayalet Dokuma Eldivenler" end
if B["Pattern: Ghostweave Pants"] == nil then B["Pattern: Ghostweave Pants"] = "Desen: Hayalet Dokuma Pantolon" end
if B["Pattern: Ghostweave Vest"] == nil then B["Pattern: Ghostweave Vest"] = "Desen: Hayalet Dokuma Yelek" end
if B["Pattern: Girdle of Insight"] == nil then B["Pattern: Girdle of Insight"] = "Desen: Sezgi Kuşağı" end
if B["Pattern: Glacial Cloak"] == nil then B["Pattern: Glacial Cloak"] = "Desen: Buzul Pelerini" end
if B["Pattern: Glacial Gloves"] == nil then B["Pattern: Glacial Gloves"] = "Desen: Buzul Eldivenleri" end
if B["Pattern: Glacial Wrists"] == nil then B["Pattern: Glacial Wrists"] = "Desen: Buzul Bileklikleri" end
if B["Pattern: Gloves of Spell Mastery"] == nil then B["Pattern: Gloves of Spell Mastery"] = "Desen: Büyü Ustalığı Eldivenleri" end
if B["Pattern: Gloves of the Greatfather"] == nil then B["Pattern: Gloves of the Greatfather"] = "Desen: Ulu Baba'nın Eldivenleri" end
if B["Pattern: Golden Mantle of the Dawn"] == nil then B["Pattern: Golden Mantle of the Dawn"] = "Desen: Şafağın Altın Omuzluğu" end
if B["Pattern: Gray Woolen Robe"] == nil then B["Pattern: Gray Woolen Robe"] = "Desen: Gri Yün Cüppe" end
if B["Pattern: Greater Adept's Robe"] == nil then B["Pattern: Greater Adept's Robe"] = "Desen: Kıdemli Ehil Cüppesi" end
if B["Pattern: Green Dragonscale Breastplate"] == nil then B["Pattern: Green Dragonscale Breastplate"] = "Desen: Yeşil Ejderha Pulu Göğüs Zırhı" end
if B["Pattern: Green Dragonscale Leggings"] == nil then B["Pattern: Green Dragonscale Leggings"] = "Desen: Yeşil Ejderha Pulu Tozluk" end
if B["Pattern: Green Holiday Shirt"] == nil then B["Pattern: Green Holiday Shirt"] = "Desen: Yeşil Bayram Gömleği" end
if B["Pattern: Green Leather Armor"] == nil then B["Pattern: Green Leather Armor"] = "Desen: Yeşil Deri Zırh" end
if B["Pattern: Green Silk Armor"] == nil then B["Pattern: Green Silk Armor"] = "Desen: Yeşil İpek Zırh" end
if B["Pattern: Green Silk Pack"] == nil then B["Pattern: Green Silk Pack"] = "Desen: Yeşil İpek Sırt Çantası" end
if B["Pattern: Green Whelp Armor"] == nil then B["Pattern: Green Whelp Armor"] = "Desen: Yeşil Yavru Ejderha Zırhı" end
if B["Pattern: Green Whelp Bracers"] == nil then B["Pattern: Green Whelp Bracers"] = "Desen: Yeşil Yavru Ejderha Bileklikleri" end
if B["Pattern: Green Woolen Bag"] == nil then B["Pattern: Green Woolen Bag"] = "Desen: Yeşil Yün Çanta" end
if B["Pattern: Green Woolen Robe"] == nil then B["Pattern: Green Woolen Robe"] = "Desen: Yeşil Yün Cüppe" end
if B["Pattern: Guardian Armor"] == nil then B["Pattern: Guardian Armor"] = "Desen: Muhafız Zırhı" end
if B["Pattern: Guardian Belt"] == nil then B["Pattern: Guardian Belt"] = "Desen: Muhafız Kemeri" end
if B["Pattern: Guardian Cloak"] == nil then B["Pattern: Guardian Cloak"] = "Desen: Muhafız Pelerini" end
if B["Pattern: Guardian Leather Bracers"] == nil then B["Pattern: Guardian Leather Bracers"] = "Desen: Muhafız Deri Bileklikleri" end
if B["Pattern: Hands of Darkness"] == nil then B["Pattern: Hands of Darkness"] = "Desen: Karanlığın Elleri" end
if B["Pattern: Heavy Earthen Gloves"] == nil then B["Pattern: Heavy Earthen Gloves"] = "Desen: Ağır Topraksı Eldivenler" end
if B["Pattern: Heavy Leather Ball"] == nil then B["Pattern: Heavy Leather Ball"] = "Desen: Ağır Deri Top" end
if B["Pattern: Heavy Scorpid Belt"] == nil then B["Pattern: Heavy Scorpid Belt"] = "Desen: Ağır Scorpid Kemer" end
if B["Pattern: Heavy Scorpid Bracers"] == nil then B["Pattern: Heavy Scorpid Bracers"] = "Desen: Ağır Scorpid Bileklikler" end
if B["Pattern: Heavy Scorpid Gauntlets"] == nil then B["Pattern: Heavy Scorpid Gauntlets"] = "Desen: Ağır Scorpid Demir Eldivenler" end
if B["Pattern: Heavy Scorpid Helm"] == nil then B["Pattern: Heavy Scorpid Helm"] = "Desen: Ağır Scorpid Miğfer" end
if B["Pattern: Heavy Scorpid Leggings"] == nil then B["Pattern: Heavy Scorpid Leggings"] = "Desen: Ağır Scorpid Tozluk" end
if B["Pattern: Heavy Scorpid Shoulders"] == nil then B["Pattern: Heavy Scorpid Shoulders"] = "Desen: Ağır Scorpid Omuzluklar" end
if B["Pattern: Heavy Scorpid Vest"] == nil then B["Pattern: Heavy Scorpid Vest"] = "Desen: Ağır Scorpid Yelek" end
if B["Pattern: Heavy Woolen Cloak"] == nil then B["Pattern: Heavy Woolen Cloak"] = "Desen: Ağır Yün Pelerin" end
if B["Pattern: Herbalist's Gloves"] == nil then B["Pattern: Herbalist's Gloves"] = "Desen: Otacı Eldivenleri" end
if B["Pattern: Hide of the Wild"] == nil then B["Pattern: Hide of the Wild"] = "Desen: Vahşi Doğanın Postu" end
if B["Pattern: Hillman's Belt"] == nil then B["Pattern: Hillman's Belt"] = "Desen: Dağlı Kemeri" end
if B["Pattern: Hillman's Leather Vest"] == nil then B["Pattern: Hillman's Leather Vest"] = "Desen: Dağlı Deri Yeleği" end
if B["Pattern: Icy Cloak"] == nil then B["Pattern: Icy Cloak"] = "Desen: Buzlu Pelerin" end
if B["Pattern: Icy Scale Bracers"] == nil then B["Pattern: Icy Scale Bracers"] = "Desen: Buzlu Pul Bileklikler" end
if B["Pattern: Icy Scale Breastplate"] == nil then B["Pattern: Icy Scale Breastplate"] = "Desen: Buzlu Pul Göğüs Zırhı" end
if B["Pattern: Icy Scale Gauntlets"] == nil then B["Pattern: Icy Scale Gauntlets"] = "Desen: Buzlu Pul Demir Eldivenler" end
if B["Pattern: Inferno Gloves"] == nil then B["Pattern: Inferno Gloves"] = "Desen: Cehennem Ateşi Eldivenleri" end
if B["Pattern: Ironfeather Breastplate"] == nil then B["Pattern: Ironfeather Breastplate"] = "Desen: Demir Tüy Göğüs Zırhı" end
if B["Pattern: Ironfeather Shoulders"] == nil then B["Pattern: Ironfeather Shoulders"] = "Desen: Demir Tüy Omuzlukları" end
if B["Pattern: Kodo Hide Bag"] == nil then B["Pattern: Kodo Hide Bag"] = "Desen: Kodo Postu Çanta" end
if B["Pattern: Lava Belt"] == nil then B["Pattern: Lava Belt"] = "Desen: Lav Kemeri" end
if B["Pattern: Lavender Mageweave Shirt"] == nil then B["Pattern: Lavender Mageweave Shirt"] = "Desen: Lavanta Büyü Kumaşı Gömlek" end
if B["Pattern: Light Winter Boots"] == nil then B["Pattern: Light Winter Boots"] = "Desen: Hafif Kış Çizmeleri" end
if B["Pattern: Light Winter Cloak"] == nil then B["Pattern: Light Winter Cloak"] = "Desen: Hafif Kış Pelerini" end
if B["Pattern: Living Breastplate"] == nil then B["Pattern: Living Breastplate"] = "Desen: Canlı Göğüs Zırhı" end
if B["Pattern: Living Leggings"] == nil then B["Pattern: Living Leggings"] = "Desen: Canlı Tozluk" end
if B["Pattern: Living Shoulders"] == nil then B["Pattern: Living Shoulders"] = "Desen: Canlı Omuzluklar" end
if B["Pattern: Mantle of the Timbermaw"] == nil then B["Pattern: Mantle of the Timbermaw"] = "Desen: Timbermaw Omuzluğu" end
if B["Pattern: Might of the Timbermaw"] == nil then B["Pattern: Might of the Timbermaw"] = "Desen: Timbermaw Kudreti" end
if B["Pattern: Molten Belt"] == nil then B["Pattern: Molten Belt"] = "Desen: Erimiş Kemer" end
if B["Pattern: Molten Helm"] == nil then B["Pattern: Molten Helm"] = "Desen: Erimiş Miğfer" end
if B["Pattern: Mongoose Boots"] == nil then B["Pattern: Mongoose Boots"] = "Desen: Firavun Faresi Çizmeleri" end
if B["Pattern: Mooncloth Bag"] == nil then B["Pattern: Mooncloth Bag"] = "Desen: Ay Kumaşı Çanta" end
if B["Pattern: Mooncloth Circlet"] == nil then B["Pattern: Mooncloth Circlet"] = "Desen: Ay Kumaşı Diadem" end
if B["Pattern: Mooncloth Gloves"] == nil then B["Pattern: Mooncloth Gloves"] = "Desen: Ay Kumaşı Eldivenler" end
if B["Pattern: Mooncloth Leggings"] == nil then B["Pattern: Mooncloth Leggings"] = "Desen: Ay Kumaşı Tozluk" end
if B["Pattern: Mooncloth Robe"] == nil then B["Pattern: Mooncloth Robe"] = "Desen: Ay Kumaşı Cüppe" end
if B["Pattern: Mooncloth Shoulders"] == nil then B["Pattern: Mooncloth Shoulders"] = "Desen: Ay Kumaşı Omuzluklar" end
if B["Pattern: Mooncloth Vest"] == nil then B["Pattern: Mooncloth Vest"] = "Desen: Ay Kumaşı Yelek" end
if B["Pattern: Moonglow Vest"] == nil then B["Pattern: Moonglow Vest"] = "Desen: Ay Işıltısı Yeleği" end
if B["Pattern: Murloc Scale Belt"] == nil then B["Pattern: Murloc Scale Belt"] = "Desen: Murloc Pulu Kemer" end
if B["Pattern: Murloc Scale Bracers"] == nil then B["Pattern: Murloc Scale Bracers"] = "Desen: Murloc Pulu Bileklikler" end
if B["Pattern: Murloc Scale Breastplate"] == nil then B["Pattern: Murloc Scale Breastplate"] = "Desen: Murloc Pulu Göğüs Zırhı" end
if B["Pattern: Nightscape Cloak"] == nil then B["Pattern: Nightscape Cloak"] = "Desen: Nightscape Pelerini" end
if B["Pattern: Nightscape Shoulders"] == nil then B["Pattern: Nightscape Shoulders"] = "Desen: Nightscape Omuzlukları" end
if B["Pattern: Onyxia Scale Breastplate"] == nil then B["Pattern: Onyxia Scale Breastplate"] = "Desen: Onyxia Pulu Göğüs Zırhı" end
if B["Pattern: Onyxia Scale Cloak"] == nil then B["Pattern: Onyxia Scale Cloak"] = "Desen: Onyxia Pulu Pelerin" end
if B["Pattern: Orange Martial Shirt"] == nil then B["Pattern: Orange Martial Shirt"] = "Desen: Turuncu Dövüş Gömleği" end
if B["Pattern: Phoenix Gloves"] == nil then B["Pattern: Phoenix Gloves"] = "Desen: Anka Eldivenleri" end
if B["Pattern: Phoenix Pants"] == nil then B["Pattern: Phoenix Pants"] = "Desen: Anka Pantolonu" end
if B["Pattern: Pilferer's Gloves"] == nil then B["Pattern: Pilferer's Gloves"] = "Desen: Hırsız Eldivenleri" end
if B["Pattern: Pink Mageweave Shirt"] == nil then B["Pattern: Pink Mageweave Shirt"] = "Desen: Pembe Büyü Kumaşı Gömlek" end
if B["Pattern: Polar Bracers"] == nil then B["Pattern: Polar Bracers"] = "Desen: Kutup Bileklikleri" end
if B["Pattern: Polar Gloves"] == nil then B["Pattern: Polar Gloves"] = "Desen: Kutup Eldivenleri" end
if B["Pattern: Polar Tunic"] == nil then B["Pattern: Polar Tunic"] = "Desen: Kutup Tuniği" end
if B["Pattern: Primal Batskin Bracers"] == nil then B["Pattern: Primal Batskin Bracers"] = "Desen: İlkel Yarasa Derisi Bileklikler" end
if B["Pattern: Primal Batskin Gloves"] == nil then B["Pattern: Primal Batskin Gloves"] = "Desen: İlkel Yarasa Derisi Eldivenler" end
if B["Pattern: Primal Batskin Jerkin"] == nil then B["Pattern: Primal Batskin Jerkin"] = "Desen: İlkel Yarasa Derisi Ceket" end
if B["Pattern: Raptor Hide Belt"] == nil then B["Pattern: Raptor Hide Belt"] = "Desen: Raptor Derisi Kemer" end
if B["Pattern: Red Dragonscale Breastplate"] == nil then B["Pattern: Red Dragonscale Breastplate"] = "Desen: Kırmızı Ejderha Pulu Göğüs Zırhı" end
if B["Pattern: Red Linen Bag"] == nil then B["Pattern: Red Linen Bag"] = "Desen: Kırmızı Keten Çanta" end
if B["Pattern: Red Linen Robe"] == nil then B["Pattern: Red Linen Robe"] = "Desen: Kırmızı Keten Cüppe" end
if B["Pattern: Red Linen Vest"] == nil then B["Pattern: Red Linen Vest"] = "Desen: Kırmızı Keten Yelek" end
if B["Pattern: Red Mageweave Gloves"] == nil then B["Pattern: Red Mageweave Gloves"] = "Desen: Kırmızı Büyü Kumaşı Eldivenler" end
if B["Pattern: Red Mageweave Headband"] == nil then B["Pattern: Red Mageweave Headband"] = "Desen: Kırmızı Büyü Kumaşı Kafa Bandı" end
if B["Pattern: Red Mageweave Pants"] == nil then B["Pattern: Red Mageweave Pants"] = "Desen: Kırmızı Büyü Kumaşı Pantolon" end
if B["Pattern: Red Mageweave Shoulders"] == nil then B["Pattern: Red Mageweave Shoulders"] = "Desen: Kırmızı Büyü Kumaşı Omuzluklar" end
if B["Pattern: Red Mageweave Vest"] == nil then B["Pattern: Red Mageweave Vest"] = "Desen: Kırmızı Büyü Kumaşı Yelek" end
if B["Pattern: Red Whelp Gloves"] == nil then B["Pattern: Red Whelp Gloves"] = "Desen: Kırmızı Yavru Ejderha Eldivenleri" end
if B["Pattern: Red Woolen Bag"] == nil then B["Pattern: Red Woolen Bag"] = "Desen: Kırmızı Yün Çanta" end
if B["Pattern: Red Woolen Boots"] == nil then B["Pattern: Red Woolen Boots"] = "Desen: Kırmızı Yün Çizmeler" end
if B["Pattern: Reinforced Woolen Shoulders"] == nil then B["Pattern: Reinforced Woolen Shoulders"] = "Desen: Takviyeli Yün Omuzluklar" end
if B["Pattern: Rich Purple Silk Shirt"] == nil then B["Pattern: Rich Purple Silk Shirt"] = "Desen: Koyu Mor İpek Gömlek" end
if B["Pattern: Robe of Winter Night"] == nil then B["Pattern: Robe of Winter Night"] = "Desen: Kış Gecesi Cüppesi" end
if B["Pattern: Robe of the Archmage"] == nil then B["Pattern: Robe of the Archmage"] = "Desen: Başbüyücünün Cüppesi" end
if B["Pattern: Robe of the Void"] == nil then B["Pattern: Robe of the Void"] = "Desen: Boşluğun Cüppesi" end
if B["Pattern: Robes of Arcana"] == nil then B["Pattern: Robes of Arcana"] = "Desen: Arkana Cüppesi" end
if B["Pattern: Rugged Leather Pants"] == nil then B["Pattern: Rugged Leather Pants"] = "Desen: Kaba Deri Pantolon" end
if B["Pattern: Runecloth Bag"] == nil then B["Pattern: Runecloth Bag"] = "Desen: Rün Kumaşı Çanta" end
if B["Pattern: Runecloth Boots"] == nil then B["Pattern: Runecloth Boots"] = "Desen: Rün Kumaşı Çizmeler" end
if B["Pattern: Runecloth Cloak"] == nil then B["Pattern: Runecloth Cloak"] = "Desen: Rün Kumaşı Pelerin" end
if B["Pattern: Runecloth Gloves"] == nil then B["Pattern: Runecloth Gloves"] = "Desen: Rün Kumaşı Eldivenler" end
if B["Pattern: Runecloth Headband"] == nil then B["Pattern: Runecloth Headband"] = "Desen: Rün Kumaşı Kafa Bandı" end
if B["Pattern: Runecloth Pants"] == nil then B["Pattern: Runecloth Pants"] = "Desen: Rün Kumaşı Pantolon" end
if B["Pattern: Runecloth Robe"] == nil then B["Pattern: Runecloth Robe"] = "Desen: Rün Kumaşı Cüppe" end
if B["Pattern: Runecloth Shoulders"] == nil then B["Pattern: Runecloth Shoulders"] = "Desen: Rün Kumaşı Omuzluklar" end
if B["Pattern: Runecloth Tunic"] == nil then B["Pattern: Runecloth Tunic"] = "Desen: Rün Kumaşı Tunik" end
if B["Pattern: Runed Stygian Belt"] == nil then B["Pattern: Runed Stygian Belt"] = "Desen: Rünlü Stygian Kemer" end
if B["Pattern: Runed Stygian Boots"] == nil then B["Pattern: Runed Stygian Boots"] = "Desen: Rünlü Stygian Çizmeler" end
if B["Pattern: Runed Stygian Leggings"] == nil then B["Pattern: Runed Stygian Leggings"] = "Desen: Rünlü Stygian Tozluk" end
if B["Pattern: Runic Leather Armor"] == nil then B["Pattern: Runic Leather Armor"] = "Desen: Rünlü Deri Zırh" end
if B["Pattern: Runic Leather Belt"] == nil then B["Pattern: Runic Leather Belt"] = "Desen: Rünlü Deri Kemer" end
if B["Pattern: Runic Leather Bracers"] == nil then B["Pattern: Runic Leather Bracers"] = "Desen: Rünlü Deri Bileklikler" end
if B["Pattern: Runic Leather Gauntlets"] == nil then B["Pattern: Runic Leather Gauntlets"] = "Desen: Rünlü Deri Eldivenler" end
if B["Pattern: Runic Leather Headband"] == nil then B["Pattern: Runic Leather Headband"] = "Desen: Rünlü Deri Kafa Bandı" end
if B["Pattern: Runic Leather Pants"] == nil then B["Pattern: Runic Leather Pants"] = "Desen: Rünlü Deri Pantolon" end
if B["Pattern: Runic Leather Shoulders"] == nil then B["Pattern: Runic Leather Shoulders"] = "Desen: Rünlü Deri Omuzluklar" end
if B["Pattern: Sandstalker Bracers"] == nil then B["Pattern: Sandstalker Bracers"] = "Desen: Kum Avcısı Bileklikleri" end
if B["Pattern: Sandstalker Breastplate"] == nil then B["Pattern: Sandstalker Breastplate"] = "Desen: Kum Avcısı Göğüs Zırhı" end
if B["Pattern: Sandstalker Gauntlets"] == nil then B["Pattern: Sandstalker Gauntlets"] = "Desen: Kum Avcısı Demir Eldivenleri" end
if B["Pattern: Satchel of Cenarius"] == nil then B["Pattern: Satchel of Cenarius"] = "Desen: Cenarius'un Heybesi" end
if B["Pattern: Shadow Hood"] == nil then B["Pattern: Shadow Hood"] = "Desen: Gölge Kukuletası" end
if B["Pattern: Shadoweave Mask"] == nil then B["Pattern: Shadoweave Mask"] = "Desen: Gölge Dokuma Maske" end
if B["Pattern: Shadowskin Gloves"] == nil then B["Pattern: Shadowskin Gloves"] = "Desen: Gölge Derisi Eldivenler" end
if B["Pattern: Shifting Cloak"] == nil then B["Pattern: Shifting Cloak"] = "Desen: Değişken Pelerin" end
if B["Pattern: Soul Pouch"] == nil then B["Pattern: Soul Pouch"] = "Desen: Ruh Kesesi" end
if B["Pattern: Spider Belt"] == nil then B["Pattern: Spider Belt"] = "Desen: Örümcek Kemeri" end
if B["Pattern: Spider Silk Slippers"] == nil then B["Pattern: Spider Silk Slippers"] = "Desen: Örümcek İpeği Terlikler" end
if B["Pattern: Spitfire Bracers"] == nil then B["Pattern: Spitfire Bracers"] = "Desen: Alev Saçan Bileklikler" end
if B["Pattern: Spitfire Breastplate"] == nil then B["Pattern: Spitfire Breastplate"] = "Desen: Alev Saçan Göğüs Zırhı" end
if B["Pattern: Spitfire Gauntlets"] == nil then B["Pattern: Spitfire Gauntlets"] = "Desen: Alev Saçan Demir Eldivenler" end
if B["Pattern: Star Belt"] == nil then B["Pattern: Star Belt"] = "Desen: Yıldız Kemeri" end
if B["Pattern: Stormcloth Boots"] == nil then B["Pattern: Stormcloth Boots"] = "Desen: Fırtına Kumaşı Çizmeler" end
if B["Pattern: Stormcloth Gloves"] == nil then B["Pattern: Stormcloth Gloves"] = "Desen: Fırtına Kumaşı Eldivenler" end
if B["Pattern: Stormcloth Headband"] == nil then B["Pattern: Stormcloth Headband"] = "Desen: Fırtına Kumaşı Kafa Bandı" end
if B["Pattern: Stormcloth Pants"] == nil then B["Pattern: Stormcloth Pants"] = "Desen: Fırtına Kumaşı Pantolon" end
if B["Pattern: Stormcloth Vest"] == nil then B["Pattern: Stormcloth Vest"] = "Desen: Fırtına Kumaşı Yelek" end
if B["Pattern: Stormshroud Armor"] == nil then B["Pattern: Stormshroud Armor"] = "Desen: Fırtına Örtüsü Zırhı" end
if B["Pattern: Stormshroud Gloves"] == nil then B["Pattern: Stormshroud Gloves"] = "Desen: Fırtına Örtüsü Eldivenleri" end
if B["Pattern: Stormshroud Pants"] == nil then B["Pattern: Stormshroud Pants"] = "Desen: Fırtına Örtüsü Pantolonu" end
if B["Pattern: Stormshroud Shoulders"] == nil then B["Pattern: Stormshroud Shoulders"] = "Desen: Fırtına Örtüsü Omuzlukları" end
if B["Pattern: Stylish Blue Shirt"] == nil then B["Pattern: Stylish Blue Shirt"] = "Desen: Şık Mavi Gömlek" end
if B["Pattern: Stylish Green Shirt"] == nil then B["Pattern: Stylish Green Shirt"] = "Desen: Şık Yeşil Gömlek" end
if B["Pattern: Swift Boots"] == nil then B["Pattern: Swift Boots"] = "Desen: Süratli Çizmeler" end
if B["Pattern: Swift Flight Bracers"] == nil then B["Pattern: Swift Flight Bracers"] = "Desen: Süratli Uçuş Bileklikleri" end
if B["Pattern: Sylvan Crown"] == nil then B["Pattern: Sylvan Crown"] = "Desen: Orman Tacı" end
if B["Pattern: Sylvan Shoulders"] == nil then B["Pattern: Sylvan Shoulders"] = "Desen: Orman Omuzlukları" end
if B["Pattern: Sylvan Vest"] == nil then B["Pattern: Sylvan Vest"] = "Desen: Orman Yeleği" end
if B["Pattern: Thick Murloc Armor"] == nil then B["Pattern: Thick Murloc Armor"] = "Desen: Kalın Murloc Zırhı" end
if B["Pattern: Timbermaw Brawlers"] == nil then B["Pattern: Timbermaw Brawlers"] = "Desen: Timbermaw Dövüş Eldivenleri" end
if B["Pattern: Tough Scorpid Boots"] == nil then B["Pattern: Tough Scorpid Boots"] = "Desen: Sağlam Scorpid Çizmeler" end
if B["Pattern: Tough Scorpid Bracers"] == nil then B["Pattern: Tough Scorpid Bracers"] = "Desen: Sağlam Scorpid Bileklikler" end
if B["Pattern: Tough Scorpid Breastplate"] == nil then B["Pattern: Tough Scorpid Breastplate"] = "Desen: Sağlam Scorpid Göğüs Zırhı" end
if B["Pattern: Tough Scorpid Gloves"] == nil then B["Pattern: Tough Scorpid Gloves"] = "Desen: Sağlam Scorpid Eldivenler" end
if B["Pattern: Tough Scorpid Helm"] == nil then B["Pattern: Tough Scorpid Helm"] = "Desen: Sağlam Scorpid Miğfer" end
if B["Pattern: Tough Scorpid Leggings"] == nil then B["Pattern: Tough Scorpid Leggings"] = "Desen: Sağlam Scorpid Tozluk" end
if B["Pattern: Tough Scorpid Shoulders"] == nil then B["Pattern: Tough Scorpid Shoulders"] = "Desen: Sağlam Scorpid Omuzluklar" end
if B["Pattern: Truefaith Gloves"] == nil then B["Pattern: Truefaith Gloves"] = "Desen: Hakiki İnanç Eldivenleri" end
if B["Pattern: Truefaith Vestments"] == nil then B["Pattern: Truefaith Vestments"] = "Desen: Hakiki İnanç Giysileri" end
if B["Pattern: Turtle Scale Gloves"] == nil then B["Pattern: Turtle Scale Gloves"] = "Desen: Kaplumbağa Pulu Eldivenler" end
if B["Pattern: Tuxedo Jacket"] == nil then B["Pattern: Tuxedo Jacket"] = "Desen: Smokin Ceketi" end
if B["Pattern: Tuxedo Pants"] == nil then B["Pattern: Tuxedo Pants"] = "Desen: Smokin Pantolonu" end
if B["Pattern: Tuxedo Shirt"] == nil then B["Pattern: Tuxedo Shirt"] = "Desen: Smokin Gömleği" end
if B["Pattern: Volcanic Breastplate"] == nil then B["Pattern: Volcanic Breastplate"] = "Desen: Volkanik Göğüs Zırhı" end
if B["Pattern: Volcanic Leggings"] == nil then B["Pattern: Volcanic Leggings"] = "Desen: Volkanik Tozluk" end
if B["Pattern: Volcanic Shoulders"] == nil then B["Pattern: Volcanic Shoulders"] = "Desen: Volkanik Omuzluklar" end
if B["Pattern: Warbear Harness"] == nil then B["Pattern: Warbear Harness"] = "Desen: Savaş Ayısı Koşumu" end
if B["Pattern: Warbear Woolies"] == nil then B["Pattern: Warbear Woolies"] = "Desen: Savaş Ayısı Yünlüleri" end
if B["Pattern: White Bandit Mask"] == nil then B["Pattern: White Bandit Mask"] = "Desen: Beyaz Haydut Maskesi" end
if B["Pattern: White Leather Jerkin"] == nil then B["Pattern: White Leather Jerkin"] = "Desen: Beyaz Deri Ceket" end
if B["Pattern: White Wedding Dress"] == nil then B["Pattern: White Wedding Dress"] = "Desen: Beyaz Gelinlik" end
if B["Pattern: Wicked Leather Armor"] == nil then B["Pattern: Wicked Leather Armor"] = "Desen: Kötücül Deri Zırh" end
if B["Pattern: Wicked Leather Belt"] == nil then B["Pattern: Wicked Leather Belt"] = "Desen: Kötücül Deri Kemer" end
if B["Pattern: Wicked Leather Bracers"] == nil then B["Pattern: Wicked Leather Bracers"] = "Desen: Kötücül Deri Bileklikler" end
if B["Pattern: Wicked Leather Gauntlets"] == nil then B["Pattern: Wicked Leather Gauntlets"] = "Desen: Kötücül Deri Eldivenler" end
if B["Pattern: Wicked Leather Headband"] == nil then B["Pattern: Wicked Leather Headband"] = "Desen: Kötücül Deri Kafa Bandı" end
if B["Pattern: Wicked Leather Pants"] == nil then B["Pattern: Wicked Leather Pants"] = "Desen: Kötücül Deri Pantolon" end
if B["Pattern: Wild Leather Boots"] == nil then B["Pattern: Wild Leather Boots"] = "Desen: Yabani Deri Çizmeler" end
if B["Pattern: Wild Leather Cloak"] == nil then B["Pattern: Wild Leather Cloak"] = "Desen: Yabani Deri Pelerin" end
if B["Pattern: Wild Leather Helmet"] == nil then B["Pattern: Wild Leather Helmet"] = "Desen: Yabani Deri Miğfer" end
if B["Pattern: Wild Leather Leggings"] == nil then B["Pattern: Wild Leather Leggings"] = "Desen: Yabani Deri Tozluk" end
if B["Pattern: Wild Leather Shoulders"] == nil then B["Pattern: Wild Leather Shoulders"] = "Desen: Yabani Deri Omuzluklar" end
if B["Pattern: Wild Leather Vest"] == nil then B["Pattern: Wild Leather Vest"] = "Desen: Yabani Deri Yelek" end
if B["Pattern: Wisdom of the Timbermaw"] == nil then B["Pattern: Wisdom of the Timbermaw"] = "Desen: Timbermaw Bilgeliği" end
if B["Pattern: Wizardweave Leggings"] == nil then B["Pattern: Wizardweave Leggings"] = "Desen: Büyücü Dokuma Tozluk" end
if B["Pattern: Wizardweave Robe"] == nil then B["Pattern: Wizardweave Robe"] = "Desen: Büyücü Dokuma Cüppe" end
if B["Pattern: Wizardweave Turban"] == nil then B["Pattern: Wizardweave Turban"] = "Desen: Büyücü Dokuma Sarık" end
if B["Perfume"] == nil then B["Perfume"] = "Parfüm" end
if B["Perm. Illusion Dreaming Whelp"] == nil then B["Perm. Illusion Dreaming Whelp"] = "Kalıcı İllüzyon: Rüya Gören Ejder Yavrusu" end
if B["Perm. Illusion HE Hunter"] == nil then B["Perm. Illusion HE Hunter"] = "Kalıcı İllüzyon: Yüksek Elf Avcı" end
if B["Perm. Illusion Shade"] == nil then B["Perm. Illusion Shade"] = "Kalıcı İllüzyon: Gölge" end
if B["Perm. Illusion Skeleton"] == nil then B["Perm. Illusion Skeleton"] = "Kalıcı İllüzyon: İskelet" end
if B["Perm. Illusion Slime"] == nil then B["Perm. Illusion Slime"] = "Kalıcı İllüzyon: Balçık" end
if B["Perm. Illusion Succubus"] == nil then B["Perm. Illusion Succubus"] = "Kalıcı İllüzyon: Succubus" end
if B["Permanent Cerebral Cortex Compound"] == nil then B["Permanent Cerebral Cortex Compound"] = "Kalıcı Beyin Korteksi Bileşimi" end
if B["Permanent Ground Scorpok Assay"] == nil then B["Permanent Ground Scorpok Assay"] = "Kalıcı Öğütülmüş Scorpok Tahlili" end
if B["Permanent Lung Juice Cocktail"] == nil then B["Permanent Lung Juice Cocktail"] = "Kalıcı Akciğer Suyu Kokteyli" end
if B["Permanent R.O.I.D.S."] == nil then B["Permanent R.O.I.D.S."] = "Kalıcı R.O.I.D.S." end
if B["Permanent Sheen of Zanza"] == nil then B["Permanent Sheen of Zanza"] = "Kalıcı Zanza Parıltısı" end
if B["Permanent Spirit of Zanza"] == nil then B["Permanent Spirit of Zanza"] = "Kalıcı Zanza Ruhu" end
if B["Permanent Swiftness of Zanza"] == nil then B["Permanent Swiftness of Zanza"] = "Kalıcı Zanza Çevikliği" end
if B["Persistent Shield"] == nil then B["Persistent Shield"] = "Kalıcı Kalkan" end
if B["Pet Fish"] == nil then B["Pet Fish"] = "Evcil Balık" end
if B["Pet Stone"] == nil then B["Pet Stone"] = "Evcil Taş" end
if B["Petrification"] == nil then B["Petrification"] = "Taşlaşma" end
if B["Phantom Strike"] == nil then B["Phantom Strike"] = "Hayalet Darbe" end
if B["Phase Shift"] == nil then B["Phase Shift"] = "Faz Kayması" end
if B["Physical Protection"] == nil then B["Physical Protection"] = "Fiziksel Koruma" end
if B["Piccolo of the Flaming Fire"] == nil then B["Piccolo of the Flaming Fire"] = "Alevli Ateşin Pikolosu" end
if B["Picnic Blanket"] == nil then B["Picnic Blanket"] = "Piknik Örtüsü" end
if B["Pillar Delving"] == nil then B["Pillar Delving"] = "Sütunu Araştır" end
if B["Pinto Horse"] == nil then B["Pinto Horse"] = "Alaca At" end
if B["Pirate Costume"] == nil then B["Pirate Costume"] = "Korsan Kostümü" end
if B["Place Arcanite Buoy"] == nil then B["Place Arcanite Buoy"] = "Arcanite Şamandıra Yerleştir" end
if B["Place Ghost Magnet"] == nil then B["Place Ghost Magnet"] = "Hayalet Mıknatısı Yerleştir" end
if B["Place Lion Carcass"] == nil then B["Place Lion Carcass"] = "Aslan Leşi Yerleştir" end
if B["Place Loot"] == nil then B["Place Loot"] = "Ganimet Yerleştir" end
if B["Place Scryer"] == nil then B["Place Scryer"] = "Kâhin Gözü Yerleştir" end
if B["Place Threshadon Carcass"] == nil then B["Place Threshadon Carcass"] = "Threshadon Leşi Yerleştir" end
if B["Place Toxic Fogger"] == nil then B["Place Toxic Fogger"] = "Zehirli Sisleyici Yerleştir" end
if B["Place Unfired Blade"] == nil then B["Place Unfired Blade"] = "Pişirilmemiş Kılıç Yerleştir" end
if B["Place Unforged Seal"] == nil then B["Place Unforged Seal"] = "Dövülmemiş Mühür Yerleştir" end
if B["Placing Beacon Torch"] == nil then B["Placing Beacon Torch"] = "İşaret Meşalesi Yerleştiriliyor" end
if B["Placing Bear Trap"] == nil then B["Placing Bear Trap"] = "Ayı Kapanı Yerleştiriliyor" end
if B["Placing Message to the Wildhammer"] == nil then B["Placing Message to the Wildhammer"] = "Wildhammer'a Mesaj Yerleştiriliyor" end
if B["Placing Pendant"] == nil then B["Placing Pendant"] = "Kolye Yerleştiriliyor" end
if B["Placing Smokey's Explosives"] == nil then B["Placing Smokey's Explosives"] = "Smokey'nin Patlayıcıları Yerleştiriliyor" end
if B["Plans: Annihilator"] == nil then B["Plans: Annihilator"] = "Plan: Yok Edici" end
if B["Plans: Arcanite Champion"] == nil then B["Plans: Arcanite Champion"] = "Plan: Arcanite Şampiyon" end
if B["Plans: Arcanite Reaper"] == nil then B["Plans: Arcanite Reaper"] = "Plan: Arcanite Biçici" end
if B["Plans: Barbaric Iron Boots"] == nil then B["Plans: Barbaric Iron Boots"] = "Plan: Barbar Demir Çizmeler" end
if B["Plans: Barbaric Iron Breastplate"] == nil then B["Plans: Barbaric Iron Breastplate"] = "Plan: Barbar Demir Göğüs Zırhı" end
if B["Plans: Barbaric Iron Gloves"] == nil then B["Plans: Barbaric Iron Gloves"] = "Plan: Barbar Demir Eldivenler" end
if B["Plans: Barbaric Iron Helm"] == nil then B["Plans: Barbaric Iron Helm"] = "Plan: Barbar Demir Miğfer" end
if B["Plans: Barbaric Iron Shoulders"] == nil then B["Plans: Barbaric Iron Shoulders"] = "Plan: Barbar Demir Omuzluklar" end
if B["Plans: Black Amnesty"] == nil then B["Plans: Black Amnesty"] = "Plan: Kara Af" end
if B["Plans: Black Grasp of the Destroyer"] == nil then B["Plans: Black Grasp of the Destroyer"] = "Plan: Yok Edicinin Kara Kavrayışı" end
if B["Plans: Blackfury"] == nil then B["Plans: Blackfury"] = "Plan: Kara Öfke" end
if B["Plans: Blackguard"] == nil then B["Plans: Blackguard"] = "Plan: Kara Muhafız" end
if B["Plans: Blazing Rapier"] == nil then B["Plans: Blazing Rapier"] = "Plan: Alevli Meç" end
if B["Plans: Bleakwood Hew"] == nil then B["Plans: Bleakwood Hew"] = "Plan: Kasvet Ağacı Kesici" end
if B["Plans: Blood Talon"] == nil then B["Plans: Blood Talon"] = "Plan: Kan Pençesi" end
if B["Plans: Bloodsoul Breastplate"] == nil then B["Plans: Bloodsoul Breastplate"] = "Plan: Kan Ruhu Göğüs Zırhı" end
if B["Plans: Bloodsoul Gauntlets"] == nil then B["Plans: Bloodsoul Gauntlets"] = "Plan: Kan Ruhu Demir Eldivenleri" end
if B["Plans: Bloodsoul Shoulders"] == nil then B["Plans: Bloodsoul Shoulders"] = "Plan: Kan Ruhu Omuzlukları" end
if B["Plans: Blue Glittering Axe"] == nil then B["Plans: Blue Glittering Axe"] = "Plan: Mavi Parıltılı Balta" end
if B["Plans: Copper Chain Vest"] == nil then B["Plans: Copper Chain Vest"] = "Plan: Bakır Zincir Yelek" end
if B["Plans: Corruption"] == nil then B["Plans: Corruption"] = "Plan: Yozlaşma" end
if B["Plans: Dark Iron Boots"] == nil then B["Plans: Dark Iron Boots"] = "Plan: Dark Iron Çizmeleri" end
if B["Plans: Dark Iron Bracers"] == nil then B["Plans: Dark Iron Bracers"] = "Plan: Dark Iron Bileklikleri" end
if B["Plans: Dark Iron Destroyer"] == nil then B["Plans: Dark Iron Destroyer"] = "Plan: Dark Iron Yok Edicisi" end
if B["Plans: Dark Iron Gauntlets"] == nil then B["Plans: Dark Iron Gauntlets"] = "Plan: Dark Iron Demir Eldivenleri" end
if B["Plans: Dark Iron Helm"] == nil then B["Plans: Dark Iron Helm"] = "Plan: Dark Iron Miğferi" end
if B["Plans: Dark Iron Leggings"] == nil then B["Plans: Dark Iron Leggings"] = "Plan: Dark Iron Tozluğu" end
if B["Plans: Dark Iron Mail"] == nil then B["Plans: Dark Iron Mail"] = "Plan: Dark Iron Zincir Zırhı" end
if B["Plans: Dark Iron Plate"] == nil then B["Plans: Dark Iron Plate"] = "Plan: Dark Iron Levha Zırhı" end
if B["Plans: Dark Iron Pulverizer"] == nil then B["Plans: Dark Iron Pulverizer"] = "Plan: Dark Iron Ezicisi" end
if B["Plans: Dark Iron Reaver"] == nil then B["Plans: Dark Iron Reaver"] = "Plan: Dark Iron Biçicisi" end
if B["Plans: Dark Iron Shoulders"] == nil then B["Plans: Dark Iron Shoulders"] = "Plan: Dark Iron Omuzlukları" end
if B["Plans: Dark Iron Sunderer"] == nil then B["Plans: Dark Iron Sunderer"] = "Plan: Dark Iron Yarıcısı" end
if B["Plans: Darkrune Breastplate"] == nil then B["Plans: Darkrune Breastplate"] = "Plan: Kara Rün Göğüs Zırhı" end
if B["Plans: Darkrune Gauntlets"] == nil then B["Plans: Darkrune Gauntlets"] = "Plan: Kara Rün Demir Eldivenleri" end
if B["Plans: Darkrune Helm"] == nil then B["Plans: Darkrune Helm"] = "Plan: Kara Rün Miğferi" end
if B["Plans: Darksoul Breastplate"] == nil then B["Plans: Darksoul Breastplate"] = "Plan: Kara Ruh Göğüs Zırhı" end
if B["Plans: Darksoul Leggings"] == nil then B["Plans: Darksoul Leggings"] = "Plan: Kara Ruh Tozluğu" end
if B["Plans: Darksoul Shoulders"] == nil then B["Plans: Darksoul Shoulders"] = "Plan: Kara Ruh Omuzlukları" end
if B["Plans: Darkspear"] == nil then B["Plans: Darkspear"] = "Plan: Darkspear" end
if B["Plans: Dawn's Edge"] == nil then B["Plans: Dawn's Edge"] = "Plan: Şafağın Keskinliği" end
if B["Plans: Dawnbringer Shoulders"] == nil then B["Plans: Dawnbringer Shoulders"] = "Plan: Şafak Getiren Omuzlukları" end
if B["Plans: Deadly Bronze Poniard"] == nil then B["Plans: Deadly Bronze Poniard"] = "Plan: Ölümcül Bronz Hançer" end
if B["Plans: Demon Forged Breastplate"] == nil then B["Plans: Demon Forged Breastplate"] = "Plan: İblis Dövmesi Göğüs Zırhı" end
if B["Plans: Ebon Hand"] == nil then B["Plans: Ebon Hand"] = "Plan: Abanoz El" end
if B["Plans: Ebon Shiv"] == nil then B["Plans: Ebon Shiv"] = "Plan: Abanoz Bıçak" end
if B["Plans: Edge of Winter"] == nil then B["Plans: Edge of Winter"] = "Plan: Kışın Keskinliği" end
if B["Plans: Elemental Sharpening Stone"] == nil then B["Plans: Elemental Sharpening Stone"] = "Plan: Elemental Bileme Taşı" end
if B["Plans: Enchanted Battlehammer"] == nil then B["Plans: Enchanted Battlehammer"] = "Plan: Efsunlu Savaş Çekici" end
if B["Plans: Enchanted Thorium Breastplate"] == nil then B["Plans: Enchanted Thorium Breastplate"] = "Plan: Efsunlu Toryum Göğüs Zırhı" end
if B["Plans: Enchanted Thorium Helm"] == nil then B["Plans: Enchanted Thorium Helm"] = "Plan: Efsunlu Toryum Miğfer" end
if B["Plans: Enchanted Thorium Leggings"] == nil then B["Plans: Enchanted Thorium Leggings"] = "Plan: Efsunlu Toryum Tozluk" end
if B["Plans: Fiery Chain Girdle"] == nil then B["Plans: Fiery Chain Girdle"] = "Plan: Ateşli Zincir Kuşak" end
if B["Plans: Fiery Chain Shoulders"] == nil then B["Plans: Fiery Chain Shoulders"] = "Plan: Ateşli Zincir Omuzluklar" end
if B["Plans: Fiery Plate Gauntlets"] == nil then B["Plans: Fiery Plate Gauntlets"] = "Plan: Ateşli Levha Demir Eldivenler" end
if B["Plans: Frost Tiger Blade"] == nil then B["Plans: Frost Tiger Blade"] = "Plan: Ayaz Kaplanı Kılıcı" end
if B["Plans: Frostguard"] == nil then B["Plans: Frostguard"] = "Plan: Ayaz Muhafızı" end
if B["Plans: Gemmed Copper Gauntlets"] == nil then B["Plans: Gemmed Copper Gauntlets"] = "Plan: Mücevherli Bakır Eldivenler" end
if B["Plans: Girdle of the Dawn"] == nil then B["Plans: Girdle of the Dawn"] = "Plan: Şafağın Kuşağı" end
if B["Plans: Gloves of the Dawn"] == nil then B["Plans: Gloves of the Dawn"] = "Plan: Şafağın Eldivenleri" end
if B["Plans: Golden Iron Destroyer"] == nil then B["Plans: Golden Iron Destroyer"] = "Plan: Altın Demir Yok Edici" end
if B["Plans: Golden Scale Boots"] == nil then B["Plans: Golden Scale Boots"] = "Plan: Altın Pul Çizmeler" end
if B["Plans: Golden Scale Coif"] == nil then B["Plans: Golden Scale Coif"] = "Plan: Altın Pul Zincir Başlık" end
if B["Plans: Golden Scale Cuirass"] == nil then B["Plans: Golden Scale Cuirass"] = "Plan: Altın Pul Göğüs Zırhı" end
if B["Plans: Golden Scale Gauntlets"] == nil then B["Plans: Golden Scale Gauntlets"] = "Plan: Altın Pul Demir Eldivenler" end
if B["Plans: Golden Scale Leggings"] == nil then B["Plans: Golden Scale Leggings"] = "Plan: Altın Pul Tozluk" end
if B["Plans: Golden Scale Shoulders"] == nil then B["Plans: Golden Scale Shoulders"] = "Plan: Altın Pul Omuzluklar" end
if B["Plans: Green Iron Boots"] == nil then B["Plans: Green Iron Boots"] = "Plan: Yeşil Demir Çizmeler" end
if B["Plans: Green Iron Gauntlets"] == nil then B["Plans: Green Iron Gauntlets"] = "Plan: Yeşil Demir Eldivenler" end
if B["Plans: Green Iron Shoulders"] == nil then B["Plans: Green Iron Shoulders"] = "Plan: Yeşil Demir Omuzluklar" end
if B["Plans: Hammer of the Titans"] == nil then B["Plans: Hammer of the Titans"] = "Plan: Titanların Çekici" end
if B["Plans: Hardened Iron Shortsword"] == nil then B["Plans: Hardened Iron Shortsword"] = "Plan: Sertleştirilmiş Demir Kısa Kılıç" end
if B["Plans: Heartseeker"] == nil then B["Plans: Heartseeker"] = "Plan: Kalp Arayan" end
if B["Plans: Heavy Mithril Helm"] == nil then B["Plans: Heavy Mithril Helm"] = "Plan: Ağır Mithril Miğfer" end
if B["Plans: Heavy Mithril Pants"] == nil then B["Plans: Heavy Mithril Pants"] = "Plan: Ağır Mithril Pantolon" end
if B["Plans: Heavy Obsidian Belt"] == nil then B["Plans: Heavy Obsidian Belt"] = "Plan: Ağır Obsidyen Kemer" end
if B["Plans: Heavy Timbermaw Belt"] == nil then B["Plans: Heavy Timbermaw Belt"] = "Plan: Ağır Timbermaw Kemeri" end
if B["Plans: Heavy Timbermaw Boots"] == nil then B["Plans: Heavy Timbermaw Boots"] = "Plan: Ağır Timbermaw Çizmesi" end
if B["Plans: Helm of the Great Chief"] == nil then B["Plans: Helm of the Great Chief"] = "Plan: Büyük Şefin Miğferi" end
if B["Plans: Huge Thorium Battleaxe"] == nil then B["Plans: Huge Thorium Battleaxe"] = "Plan: Kocaman Toryum Savaş Baltası" end
if B["Plans: Icebane Bracers"] == nil then B["Plans: Icebane Bracers"] = "Plan: Icebane Bileklik" end
if B["Plans: Icebane Breastplate"] == nil then B["Plans: Icebane Breastplate"] = "Plan: Icebane Göğüs Zırhı" end
if B["Plans: Icebane Gauntlets"] == nil then B["Plans: Icebane Gauntlets"] = "Plan: Icebane Demir Eldiven" end
if B["Plans: Imperial Plate Belt"] == nil then B["Plans: Imperial Plate Belt"] = "Plan: İmparatorluk Levha Kemeri" end
if B["Plans: Imperial Plate Boots"] == nil then B["Plans: Imperial Plate Boots"] = "Plan: İmparatorluk Levha Çizmesi" end
if B["Plans: Imperial Plate Bracers"] == nil then B["Plans: Imperial Plate Bracers"] = "Plan: İmparatorluk Levha Bilekliği" end
if B["Plans: Imperial Plate Chest"] == nil then B["Plans: Imperial Plate Chest"] = "Plan: İmparatorluk Levha Göğüslüğü" end
if B["Plans: Imperial Plate Helm"] == nil then B["Plans: Imperial Plate Helm"] = "Plan: İmparatorluk Levha Miğferi" end
if B["Plans: Imperial Plate Leggings"] == nil then B["Plans: Imperial Plate Leggings"] = "Plan: İmparatorluk Levha Tozluğu" end
if B["Plans: Imperial Plate Shoulders"] == nil then B["Plans: Imperial Plate Shoulders"] = "Plan: İmparatorluk Levha Omuzluğu" end
if B["Plans: Inlaid Thorium Hammer"] == nil then B["Plans: Inlaid Thorium Hammer"] = "Plan: Kakmalı Toryum Çekiç" end
if B["Plans: Invulnerable Mail"] == nil then B["Plans: Invulnerable Mail"] = "Plan: Yenilmez Zincir Zırh" end
if B["Plans: Iridescent Hammer"] == nil then B["Plans: Iridescent Hammer"] = "Plan: Yanardöner Çekiç" end
if B["Plans: Iron Counterweight"] == nil then B["Plans: Iron Counterweight"] = "Plan: Demir Karşı Ağırlık" end
if B["Plans: Iron Shield Spike"] == nil then B["Plans: Iron Shield Spike"] = "Plan: Demir Kalkan Dikeni" end
if B["Plans: Ironvine Belt"] == nil then B["Plans: Ironvine Belt"] = "Plan: Ironvine Kemer" end
if B["Plans: Ironvine Breastplate"] == nil then B["Plans: Ironvine Breastplate"] = "Plan: Ironvine Göğüs Zırhı" end
if B["Plans: Ironvine Gloves"] == nil then B["Plans: Ironvine Gloves"] = "Plan: Ironvine Eldiven" end
if B["Plans: Jade Serpentblade"] == nil then B["Plans: Jade Serpentblade"] = "Plan: Yeşim Yılan Kılıcı" end
if B["Plans: Jagged Obsidian Shield"] == nil then B["Plans: Jagged Obsidian Shield"] = "Plan: Tırtıklı Obsidyen Kalkan" end
if B["Plans: Light Obsidian Belt"] == nil then B["Plans: Light Obsidian Belt"] = "Plan: Hafif Obsidyen Kemer" end
if B["Plans: Lionheart Helm"] == nil then B["Plans: Lionheart Helm"] = "Plan: Aslan Yürekli Miğfer" end
if B["Plans: Massive Iron Axe"] == nil then B["Plans: Massive Iron Axe"] = "Plan: Devasa Demir Balta" end
if B["Plans: Masterwork Stormhammer"] == nil then B["Plans: Masterwork Stormhammer"] = "Plan: Ustalık İşi Fırtına Çekici" end
if B["Plans: Mighty Iron Hammer"] == nil then B["Plans: Mighty Iron Hammer"] = "Plan: Kudretli Demir Çekiç" end
if B["Plans: Mithril Scale Bracers"] == nil then B["Plans: Mithril Scale Bracers"] = "Plan: Mithril Pul Bileklik" end
if B["Plans: Mithril Scale Gloves"] == nil then B["Plans: Mithril Scale Gloves"] = "Plan: Mithril Pul Eldiven" end
if B["Plans: Mithril Scale Shoulders"] == nil then B["Plans: Mithril Scale Shoulders"] = "Plan: Mithril Pul Omuzluk" end
if B["Plans: Mithril Shield Spike"] == nil then B["Plans: Mithril Shield Spike"] = "Plan: Mithril Kalkan Dikeni" end
if B["Plans: Mithril Spurs"] == nil then B["Plans: Mithril Spurs"] = "Plan: Mithril Mahmuz" end
if B["Plans: Moonsteel Broadsword"] == nil then B["Plans: Moonsteel Broadsword"] = "Plan: Ay Çeliği Geniş Kılıç" end
if B["Plans: Nightfall"] == nil then B["Plans: Nightfall"] = "Plan: Akşam Karanlığı" end
if B["Plans: Obsidian Mail Tunic"] == nil then B["Plans: Obsidian Mail Tunic"] = "Plan: Obsidyen Zincir Tunik" end
if B["Plans: Orcish War Leggings"] == nil then B["Plans: Orcish War Leggings"] = "Plan: Ork Savaş Tozluğu" end
if B["Plans: Ornate Mithril Boots"] == nil then B["Plans: Ornate Mithril Boots"] = "Plan: Süslü Mithril Çizme" end
if B["Plans: Ornate Mithril Breastplate"] == nil then B["Plans: Ornate Mithril Breastplate"] = "Plan: Süslü Mithril Göğüs Zırhı" end
if B["Plans: Ornate Mithril Gloves"] == nil then B["Plans: Ornate Mithril Gloves"] = "Plan: Süslü Mithril Eldiven" end
if B["Plans: Ornate Mithril Helm"] == nil then B["Plans: Ornate Mithril Helm"] = "Plan: Süslü Mithril Miğfer" end
if B["Plans: Ornate Mithril Pants"] == nil then B["Plans: Ornate Mithril Pants"] = "Plan: Süslü Mithril Pantolon" end
if B["Plans: Ornate Mithril Shoulders"] == nil then B["Plans: Ornate Mithril Shoulders"] = "Plan: Süslü Mithril Omuzluk" end
if B["Plans: Ornate Thorium Handaxe"] == nil then B["Plans: Ornate Thorium Handaxe"] = "Plan: Süslü Toryum El Baltası" end
if B["Plans: Persuader"] == nil then B["Plans: Persuader"] = "Plan: İkna Edici" end
if B["Plans: Polished Steel Boots"] == nil then B["Plans: Polished Steel Boots"] = "Plan: Cilalı Çelik Çizme" end
if B["Plans: Radiant Belt"] == nil then B["Plans: Radiant Belt"] = "Plan: Işıltılı Kemer" end
if B["Plans: Radiant Boots"] == nil then B["Plans: Radiant Boots"] = "Plan: Işıltılı Çizme" end
if B["Plans: Radiant Breastplate"] == nil then B["Plans: Radiant Breastplate"] = "Plan: Işıltılı Göğüs Zırhı" end
if B["Plans: Radiant Circlet"] == nil then B["Plans: Radiant Circlet"] = "Plan: Işıltılı Taç" end
if B["Plans: Radiant Gloves"] == nil then B["Plans: Radiant Gloves"] = "Plan: Işıltılı Eldiven" end
if B["Plans: Radiant Leggings"] == nil then B["Plans: Radiant Leggings"] = "Plan: Işıltılı Tozluk" end
if B["Plans: Rough Bronze Bracers"] == nil then B["Plans: Rough Bronze Bracers"] = "Plan: Kaba Bronz Bileklik" end
if B["Plans: Rune Edge"] == nil then B["Plans: Rune Edge"] = "Plan: Rün Ağzı" end
if B["Plans: Runed Copper Breastplate"] == nil then B["Plans: Runed Copper Breastplate"] = "Plan: Rünlü Bakır Göğüs Zırhı" end
if B["Plans: Runed Mithril Hammer"] == nil then B["Plans: Runed Mithril Hammer"] = "Plan: Rünlü Mithril Çekiç" end
if B["Plans: Runic Breastplate"] == nil then B["Plans: Runic Breastplate"] = "Plan: Rünik Göğüs Zırhı" end
if B["Plans: Runic Plate Boots"] == nil then B["Plans: Runic Plate Boots"] = "Plan: Rünik Levha Çizme" end
if B["Plans: Runic Plate Helm"] == nil then B["Plans: Runic Plate Helm"] = "Plan: Rünik Levha Miğfer" end
if B["Plans: Runic Plate Leggings"] == nil then B["Plans: Runic Plate Leggings"] = "Plan: Rünik Levha Tozluk" end
if B["Plans: Runic Plate Shoulders"] == nil then B["Plans: Runic Plate Shoulders"] = "Plan: Rünik Levha Omuzluk" end
if B["Plans: Sageblade"] == nil then B["Plans: Sageblade"] = "Plan: Bilge Kılıcı" end
if B["Plans: Searing Golden Blade"] == nil then B["Plans: Searing Golden Blade"] = "Plan: Kavurucu Altın Kılıç" end
if B["Plans: Serenity"] == nil then B["Plans: Serenity"] = "Plan: Dinginlik" end
if B["Plans: Shadow Crescent Axe"] == nil then B["Plans: Shadow Crescent Axe"] = "Plan: Gölge Hilal Baltası" end
if B["Plans: Silvered Bronze Breastplate"] == nil then B["Plans: Silvered Bronze Breastplate"] = "Plan: Gümüş Kaplama Bronz Göğüs Zırhı" end
if B["Plans: Silvered Bronze Leggings"] == nil then B["Plans: Silvered Bronze Leggings"] = "Plan: Gümüş Kaplama Bronz Tozluk" end
if B["Plans: Silvered Bronze Shoulders"] == nil then B["Plans: Silvered Bronze Shoulders"] = "Plan: Gümüş Kaplama Bronz Omuzluk" end
if B["Plans: Solid Iron Maul"] == nil then B["Plans: Solid Iron Maul"] = "Plan: Sağlam Demir Varyos" end
if B["Plans: Steel Weapon Chain"] == nil then B["Plans: Steel Weapon Chain"] = "Plan: Çelik Silah Zinciri" end
if B["Plans: Storm Gauntlets"] == nil then B["Plans: Storm Gauntlets"] = "Plan: Fırtına Demir Eldiveni" end
if B["Plans: Stronghold Gauntlets"] == nil then B["Plans: Stronghold Gauntlets"] = "Plan: Kale Demir Eldiveni" end
if B["Plans: Sulfuron Hammer"] == nil then B["Plans: Sulfuron Hammer"] = "Plan: Sulfuron Çekici" end
if B["Plans: Thick Obsidian Breastplate"] == nil then B["Plans: Thick Obsidian Breastplate"] = "Plan: Kalın Obsidyen Göğüs Zırhı" end
if B["Plans: Thorium Armor"] == nil then B["Plans: Thorium Armor"] = "Plan: Toryum Zırh" end
if B["Plans: Thorium Belt"] == nil then B["Plans: Thorium Belt"] = "Plan: Toryum Kemer" end
if B["Plans: Thorium Boots"] == nil then B["Plans: Thorium Boots"] = "Plan: Toryum Çizme" end
if B["Plans: Thorium Bracers"] == nil then B["Plans: Thorium Bracers"] = "Plan: Toryum Bileklik" end
if B["Plans: Thorium Greatsword"] == nil then B["Plans: Thorium Greatsword"] = "Plan: Toryum Büyük Kılıç" end
if B["Plans: Thorium Helm"] == nil then B["Plans: Thorium Helm"] = "Plan: Toryum Miğfer" end
if B["Plans: Thorium Leggings"] == nil then B["Plans: Thorium Leggings"] = "Plan: Toryum Tozluk" end
if B["Plans: Thorium Shield Spike"] == nil then B["Plans: Thorium Shield Spike"] = "Plan: Toryum Kalkan Dikeni" end
if B["Plans: Titanic Leggings"] == nil then B["Plans: Titanic Leggings"] = "Plan: Titanik Tozluk" end
if B["Plans: Volcanic Hammer"] == nil then B["Plans: Volcanic Hammer"] = "Plan: Volkanik Çekiç" end
if B["Plans: Whitesoul Helm"] == nil then B["Plans: Whitesoul Helm"] = "Plan: Ak Ruh Miğferi" end
if B["Plans: Wicked Mithril Blade"] == nil then B["Plans: Wicked Mithril Blade"] = "Plan: Kötücül Mithril Kılıç" end
if B["Plans: Wildthorn Mail"] == nil then B["Plans: Wildthorn Mail"] = "Plan: Yaban Dikeni Zırhı" end
if B["Plant Gor'tesh Head"] == nil then B["Plant Gor'tesh Head"] = "Gor'tesh'in Kafasını Dik" end
if B["Plant Magic Beans"] == nil then B["Plant Magic Beans"] = "Sihirli Fasulyeleri Ek" end
if B["Plant Seeds"] == nil then B["Plant Seeds"] = "Tohumları Ek" end
if B["Plant Thornling"] == nil then B["Plant Thornling"] = "Dikencik Ek" end
if B["Planting Banner"] == nil then B["Planting Banner"] = "Sancak Dikme" end
if B["Planting Guse's Beacon"] == nil then B["Planting Guse's Beacon"] = "Guse'nin İşaret Fenerini Dikme" end
if B["Planting Ichman's Beacon"] == nil then B["Planting Ichman's Beacon"] = "Ichman'ın İşaret Fenerini Dikme" end
if B["Planting Jeztor's Beacon"] == nil then B["Planting Jeztor's Beacon"] = "Jeztor'un İşaret Fenerini Dikme" end
if B["Planting Mulverick's Beacon"] == nil then B["Planting Mulverick's Beacon"] = "Mulverick'in İşaret Fenerini Dikme" end
if B["Planting Ryson's Beacon"] == nil then B["Planting Ryson's Beacon"] = "Ryson'ın İşaret Fenerini Dikme" end
if B["Planting Slidore's Beacon"] == nil then B["Planting Slidore's Beacon"] = "Slidore'un İşaret Fenerini Dikme" end
if B["Planting Vipore's Beacon"] == nil then B["Planting Vipore's Beacon"] = "Vipore'un İşaret Fenerini Dikme" end
if B["Plunging Blade into Onyxia"] == nil then B["Plunging Blade into Onyxia"] = "Kılıcı Onyxia'ya Saplama" end
if B["Poison"] == nil then B["Poison"] = "Zehir" end
if B["Poison Cloud"] == nil then B["Poison Cloud"] = "Zehir Bulutu" end
if B["Poison Mushroom"] == nil then B["Poison Mushroom"] = "Zehirli Mantar" end
if B["Polly Eats the E.C.A.C."] == nil then B["Polly Eats the E.C.A.C."] = "Polly E.C.A.C.'ı Yiyor" end
if B["Polymorph: Chicken"] == nil then B["Polymorph: Chicken"] = "Dönüşüm: Tavuk" end
if B["Polymorph: Pig"] == nil then B["Polymorph: Pig"] = "Dönüşüm: Domuz" end
if B["Polymorph: Sheep"] == nil then B["Polymorph: Sheep"] = "Dönüşüm: Koyun" end
if B["Polymorph: Turtle"] == nil then B["Polymorph: Turtle"] = "Dönüşüm: Kaplumbağa" end
if B["Portal: Karazhan"] == nil then B["Portal: Karazhan"] = "Geçit: Karazhan" end
if B["Portals Deck"] == nil then B["Portals Deck"] = "Geçitler Destesi" end
if B["Potent Alcohol"] == nil then B["Potent Alcohol"] = "Sert Alkol" end
if B["Power of the Guardian"] == nil then B["Power of the Guardian"] = "Muhafızın Gücü" end
if B["Power of the Scourge"] == nil then B["Power of the Scourge"] = "Scourge'un Gücü" end
if B["Powerful Anti-Venom"] == nil then B["Powerful Anti-Venom"] = "Kuvvetli Panzehir" end
if B["Powerful Seaforium Charge"] == nil then B["Powerful Seaforium Charge"] = "Güçlü Seaforium Patlayıcısı" end
if B["Powerful Smelling Salts"] == nil then B["Powerful Smelling Salts"] = "Güçlü Koklama Tuzu" end
if B["Prayer Beads Blessing"] == nil then B["Prayer Beads Blessing"] = "Tespih Kutsaması" end
if B["Presence of Might"] == nil then B["Presence of Might"] = "Kudret Varlığı" end
if B["Presence of Sight"] == nil then B["Presence of Sight"] = "Görüş Varlığı" end
if B["Primal Instinct"] == nil then B["Primal Instinct"] = "İlkel İçgüdü" end
if B["Primal Leopard"] == nil then B["Primal Leopard"] = "İlkel Leopar" end
if B["Prismstone"] == nil then B["Prismstone"] = "Prizma Taşı" end
if B["Proc Self Heal 22"] == nil then B["Proc Self Heal 22"] = "Kendini İyileştirme Tetiklemesi 22" end
if B["Proc Self Invulnerability"] == nil then B["Proc Self Invulnerability"] = "Kendine Dokunulmazlık Tetiklemesi" end
if B["Prophetic Aura"] == nil then B["Prophetic Aura"] = "Kehanet Aurası" end
if B["Puncture Armor"] == nil then B["Puncture Armor"] = "Zırh Del" end
if B["Purification"] == nil then B["Purification"] = "Arınma" end
if B["Purify and Place Food"] == nil then B["Purify and Place Food"] = "Yiyeceği Arındır ve Yerleştir" end
if B["Purple Firework"] == nil then B["Purple Firework"] = "Mor Havai Fişek" end
if B["Purple Firework Cluster"] == nil then B["Purple Firework Cluster"] = "Mor Havai Fişek Demeti" end
if B["Purple Mechanostrider"] == nil then B["Purple Mechanostrider"] = "Mor Mechanostrider" end
if B["Purple Skeletal Warhorse"] == nil then B["Purple Skeletal Warhorse"] = "Mor İskelet Savaş Atı" end
if B["Quest - Prepare Field Duty Papers"] == nil then B["Quest - Prepare Field Duty Papers"] = "Görev - Saha Görevi Belgelerini Hazırla" end
if B["Quest Suicide"] == nil then B["Quest Suicide"] = "Görev İntiharı" end
if B["Quick Fade"] == nil then B["Quick Fade"] = "Hızlı Silikleşme" end
if B["Quill Shot"] == nil then B["Quill Shot"] = "Diken Atışı" end
if B["Rage"] == nil then B["Rage"] = "Öfke" end
if B["Rage of Ages"] == nil then B["Rage of Ages"] = "Çağların Öfkesi" end
if B["Ragged John's Neverending Cup"] == nil then B["Ragged John's Neverending Cup"] = "Ragged John'un Bitmeyen Kupası" end
if B["Raid Buffs"] == nil then B["Raid Buffs"] = "Baskın Güçlendirmeleri" end
if B["Ramstein's Lightning Bolts"] == nil then B["Ramstein's Lightning Bolts"] = "Ramstein'ın Yıldırımları" end
if B["Random Costume"] == nil then B["Random Costume"] = "Rastgele Kostüm" end
if B["Rapid Healing"] == nil then B["Rapid Healing"] = "Hızlı İyileşme" end
if B["Raptor Feather"] == nil then B["Raptor Feather"] = "Raptor Tüyü" end
if B["Raptor Punch"] == nil then B["Raptor Punch"] = "Raptor Punçu" end
if B["Raze Attack"] == nil then B["Raze Attack"] = "Yıkım Saldırısı" end
if B["Razorlash Root"] == nil then B["Razorlash Root"] = "Kamçıdiken Kökü" end
if B["Recall"] == nil then B["Recall"] = "Geri Çağır" end
if B["Recipe: Alchemist's Stone"] == nil then B["Recipe: Alchemist's Stone"] = "Tarif: Simyacı Taşı" end
if B["Recipe: Baked Salmon"] == nil then B["Recipe: Baked Salmon"] = "Tarif: Fırında Somon" end
if B["Recipe: Beer Basted Boar Ribs"] == nil then B["Recipe: Beer Basted Boar Ribs"] = "Tarif: Biralı Yaban Domuzu Kaburgası" end
if B["Recipe: Big Bear Steak"] == nil then B["Recipe: Big Bear Steak"] = "Tarif: Büyük Ayı Bifteği" end
if B["Recipe: Blood Sausage"] == nil then B["Recipe: Blood Sausage"] = "Tarif: Kan Sucuğu" end
if B["Recipe: Brilliant Smallfish"] == nil then B["Recipe: Brilliant Smallfish"] = "Tarif: Parlak Küçük Balık" end
if B["Recipe: Bristle Whisker Catfish"] == nil then B["Recipe: Bristle Whisker Catfish"] = "Tarif: Sert Bıyıklı Yayın Balığı" end
if B["Recipe: Carrion Surprise"] == nil then B["Recipe: Carrion Surprise"] = "Tarif: Leş Sürprizi" end
if B["Recipe: Clam Chowder"] == nil then B["Recipe: Clam Chowder"] = "Tarif: Midye Çorbası" end
if B["Recipe: Cooked Crab Claw"] == nil then B["Recipe: Cooked Crab Claw"] = "Tarif: Pişmiş Yengeç Kıskacı" end
if B["Recipe: Cooked Glossy Mightfish"] == nil then B["Recipe: Cooked Glossy Mightfish"] = "Tarif: Pişmiş Parlak Kudret Balığı" end
if B["Recipe: Cowardly Flight Potion"] == nil then B["Recipe: Cowardly Flight Potion"] = "Tarif: Korkak Kaçış İksiri" end
if B["Recipe: Crispy Bat Wing"] == nil then B["Recipe: Crispy Bat Wing"] = "Tarif: Çıtır Yarasa Kanadı" end
if B["Recipe: Crispy Lizard Tail"] == nil then B["Recipe: Crispy Lizard Tail"] = "Tarif: Çıtır Kertenkele Kuyruğu" end
if B["Recipe: Crocolisk Gumbo"] == nil then B["Recipe: Crocolisk Gumbo"] = "Tarif: Krokolisk Gumbosu" end
if B["Recipe: Crocolisk Steak"] == nil then B["Recipe: Crocolisk Steak"] = "Tarif: Krokolisk Bifteği" end
if B["Recipe: Crystal Throat Lozenge"] == nil then B["Recipe: Crystal Throat Lozenge"] = "Tarif: Kristal Boğaz Pastili" end
if B["Recipe: Curiously Tasty Omelet"] == nil then B["Recipe: Curiously Tasty Omelet"] = "Tarif: Tuhaf Lezzetli Omlet" end
if B["Recipe: Dig Rat Stew"] == nil then B["Recipe: Dig Rat Stew"] = "Tarif: Kazıcı Fare Yahnisi" end
if B["Recipe: Dirge's Kickin' Chimaerok Chops"] == nil then B["Recipe: Dirge's Kickin' Chimaerok Chops"] = "Tarif: Dirge'in Acılı Chimaerok Pirzolası" end
if B["Recipe: Discolored Healing Potion"] == nil then B["Recipe: Discolored Healing Potion"] = "Tarif: Solgun Şifa İksiri" end
if B["Recipe: Dragonbreath Chili"] == nil then B["Recipe: Dragonbreath Chili"] = "Tarif: Ejder Nefesi Chili" end
if B["Recipe: Egg Nog"] == nil then B["Recipe: Egg Nog"] = "Tarif: Yumurta Likörü" end
if B["Recipe: Elixir of Brute Force"] == nil then B["Recipe: Elixir of Brute Force"] = "Tarif: Kaba Kuvvet Eliksiri" end
if B["Recipe: Elixir of Demonslaying"] == nil then B["Recipe: Elixir of Demonslaying"] = "Tarif: İblis Avlama Eliksiri" end
if B["Recipe: Elixir of Detect Lesser Invisibility"] == nil then B["Recipe: Elixir of Detect Lesser Invisibility"] = "Tarif: Küçük Görünmezliği Algılama Eliksiri" end
if B["Recipe: Elixir of Dream Vision"] == nil then B["Recipe: Elixir of Dream Vision"] = "Tarif: Rüya Görüsü Eliksiri" end
if B["Recipe: Elixir of Fortitude"] == nil then B["Recipe: Elixir of Fortitude"] = "Tarif: Metanet Eliksiri" end
if B["Recipe: Elixir of Frost Power"] == nil then B["Recipe: Elixir of Frost Power"] = "Tarif: Buz Gücü Eliksiri" end
if B["Recipe: Elixir of Giant Growth"] == nil then B["Recipe: Elixir of Giant Growth"] = "Tarif: Dev Büyüme Eliksiri" end
if B["Recipe: Elixir of Giants"] == nil then B["Recipe: Elixir of Giants"] = "Tarif: Devler Eliksiri" end
if B["Recipe: Elixir of Greater Firepower"] == nil then B["Recipe: Elixir of Greater Firepower"] = "Tarif: Büyük Ateş Gücü Eliksiri" end
if B["Recipe: Elixir of Lesser Agility"] == nil then B["Recipe: Elixir of Lesser Agility"] = "Tarif: Küçük Çeviklik Eliksiri" end
if B["Recipe: Elixir of Minor Agility"] == nil then B["Recipe: Elixir of Minor Agility"] = "Tarif: Ufak Çeviklik Eliksiri" end
if B["Recipe: Elixir of Minor Fortitude"] == nil then B["Recipe: Elixir of Minor Fortitude"] = "Tarif: Ufak Metanet Eliksiri" end
if B["Recipe: Elixir of Ogre's Strength"] == nil then B["Recipe: Elixir of Ogre's Strength"] = "Tarif: Ogre Gücü Eliksiri" end
if B["Recipe: Elixir of Poison Resistance"] == nil then B["Recipe: Elixir of Poison Resistance"] = "Tarif: Zehir Direnci Eliksiri" end
if B["Recipe: Elixir of Shadow Power"] == nil then B["Recipe: Elixir of Shadow Power"] = "Tarif: Gölge Gücü Eliksiri" end
if B["Recipe: Elixir of Superior Defense"] == nil then B["Recipe: Elixir of Superior Defense"] = "Tarif: Üstün Savunma Eliksiri" end
if B["Recipe: Elixir of Tongues"] == nil then B["Recipe: Elixir of Tongues"] = "Tarif: Diller Eliksiri" end
if B["Recipe: Elixir of the Mongoose"] == nil then B["Recipe: Elixir of the Mongoose"] = "Tarif: Firavunfaresi Eliksiri" end
if B["Recipe: Elixir of the Sages"] == nil then B["Recipe: Elixir of the Sages"] = "Tarif: Bilgeler Eliksiri" end
if B["Recipe: Filet of Redgill"] == nil then B["Recipe: Filet of Redgill"] = "Tarif: Redgill Filetosu" end
if B["Recipe: Fillet of Frenzy"] == nil then B["Recipe: Fillet of Frenzy"] = "Tarif: Frenzy Filetosu" end
if B["Recipe: Fire Protection Potion"] == nil then B["Recipe: Fire Protection Potion"] = "Tarif: Ateşten Korunma İksiri" end
if B["Recipe: Flask of Chromatic Resistance"] == nil then B["Recipe: Flask of Chromatic Resistance"] = "Tarif: Kromatik Direnç Şişesi" end
if B["Recipe: Flask of Distilled Wisdom"] == nil then B["Recipe: Flask of Distilled Wisdom"] = "Tarif: Damıtılmış Bilgelik Şişesi" end
if B["Recipe: Flask of Petrification"] == nil then B["Recipe: Flask of Petrification"] = "Tarif: Taşlaşma Şişesi" end
if B["Recipe: Flask of Supreme Power"] == nil then B["Recipe: Flask of Supreme Power"] = "Tarif: Üstün Güç Şişesi" end
if B["Recipe: Flask of the Titans"] == nil then B["Recipe: Flask of the Titans"] = "Tarif: Titanlar Şişesi" end
if B["Recipe: Free Action Potion"] == nil then B["Recipe: Free Action Potion"] = "Tarif: Serbest Hareket İksiri" end
if B["Recipe: Frost Oil"] == nil then B["Recipe: Frost Oil"] = "Tarif: Ayaz Yağı" end
if B["Recipe: Frost Protection Potion"] == nil then B["Recipe: Frost Protection Potion"] = "Tarif: Buzdan Korunma İksiri" end
if B["Recipe: Ghost Dye"] == nil then B["Recipe: Ghost Dye"] = "Tarif: Hayalet Boyası" end
if B["Recipe: Giant Clam Scorcho"] == nil then B["Recipe: Giant Clam Scorcho"] = "Tarif: Kızarmış Dev Midye" end
if B["Recipe: Gift of Arthas"] == nil then B["Recipe: Gift of Arthas"] = "Tarif: Arthas'ın Armağanı" end
if B["Recipe: Gingerbread Cookie"] == nil then B["Recipe: Gingerbread Cookie"] = "Tarif: Zencefilli Kurabiye" end
if B["Recipe: Goblin Rocket Fuel"] == nil then B["Recipe: Goblin Rocket Fuel"] = "Tarif: Goblin Roket Yakıtı" end
if B["Recipe: Gooey Spider Cake"] == nil then B["Recipe: Gooey Spider Cake"] = "Tarif: Yapışkan Örümcek Keki" end
if B["Recipe: Goretusk Liver Pie"] == nil then B["Recipe: Goretusk Liver Pie"] = "Tarif: Goretusk Ciğer Turtası" end
if B["Recipe: Great Rage Potion"] == nil then B["Recipe: Great Rage Potion"] = "Tarif: Büyük Öfke İksiri" end
if B["Recipe: Greater Arcane Elixir"] == nil then B["Recipe: Greater Arcane Elixir"] = "Tarif: Büyük Arkan Eliksiri" end
if B["Recipe: Greater Arcane Protection Potion"] == nil then B["Recipe: Greater Arcane Protection Potion"] = "Tarif: Büyük Arkandan Korunma İksiri" end
if B["Recipe: Greater Dreamless Sleep Potion"] == nil then B["Recipe: Greater Dreamless Sleep Potion"] = "Tarif: Büyük Rüyasız Uyku İksiri" end
if B["Recipe: Greater Fire Protection Potion"] == nil then B["Recipe: Greater Fire Protection Potion"] = "Tarif: Büyük Ateşten Korunma İksiri" end
if B["Recipe: Greater Frost Protection Potion"] == nil then B["Recipe: Greater Frost Protection Potion"] = "Tarif: Büyük Buzdan Korunma İksiri" end
if B["Recipe: Greater Holy Protection Potion"] == nil then B["Recipe: Greater Holy Protection Potion"] = "Tarif: Büyük Kutsaldan Korunma İksiri" end
if B["Recipe: Greater Nature Protection Potion"] == nil then B["Recipe: Greater Nature Protection Potion"] = "Tarif: Büyük Doğadan Korunma İksiri" end
if B["Recipe: Greater Shadow Protection Potion"] == nil then B["Recipe: Greater Shadow Protection Potion"] = "Tarif: Büyük Gölgeden Korunma İksiri" end
if B["Recipe: Greater Stoneshield Potion"] == nil then B["Recipe: Greater Stoneshield Potion"] = "Tarif: Büyük Taş Kalkan İksiri" end
if B["Recipe: Grilled Squid"] == nil then B["Recipe: Grilled Squid"] = "Tarif: Izgara Kalamar" end
if B["Recipe: Heavy Crocilisk Stew"] == nil then B["Recipe: Heavy Crocilisk Stew"] = "Tarif: Ağır Krokolisk Yahnisi" end
if B["Recipe: Heavy Kodo Stew"] == nil then B["Recipe: Heavy Kodo Stew"] = "Tarif: Ağır Kodo Yahnisi" end
if B["Recipe: Herb Baked Egg"] == nil then B["Recipe: Herb Baked Egg"] = "Tarif: Otlu Fırın Yumurta" end
if B["Recipe: Holy Protection Potion"] == nil then B["Recipe: Holy Protection Potion"] = "Tarif: Kutsaldan Korunma İksiri" end
if B["Recipe: Hot Lion Chops"] == nil then B["Recipe: Hot Lion Chops"] = "Tarif: Acılı Aslan Pirzolası" end
if B["Recipe: Hot Smoked Bass"] == nil then B["Recipe: Hot Smoked Bass"] = "Tarif: Sıcak Tütsülenmiş Levrek" end
if B["Recipe: Hot Wolf Ribs"] == nil then B["Recipe: Hot Wolf Ribs"] = "Tarif: Acılı Kurt Kaburgası" end
if B["Recipe: Inlaid Mithril Cylinder"] == nil then B["Recipe: Inlaid Mithril Cylinder"] = "Tarif: Kakmalı Mithril Silindir" end
if B["Recipe: Instant Toxin"] == nil then B["Recipe: Instant Toxin"] = "Tarif: Ani Toksin" end
if B["Recipe: Invisibility Potion"] == nil then B["Recipe: Invisibility Potion"] = "Tarif: Görünmezlik İksiri" end
if B["Recipe: Jungle Stew"] == nil then B["Recipe: Jungle Stew"] = "Tarif: Orman Yahnisi" end
if B["Recipe: Kaldorei Spider Kabob"] == nil then B["Recipe: Kaldorei Spider Kabob"] = "Tarif: Kaldorei Örümcek Kebabı" end
if B["Recipe: Lean Venison"] == nil then B["Recipe: Lean Venison"] = "Tarif: Yağsız Geyik Eti" end
if B["Recipe: Lean Wolf Steak"] == nil then B["Recipe: Lean Wolf Steak"] = "Tarif: Yağsız Kurt Bifteği" end
if B["Recipe: Lesser Stoneshield Potion"] == nil then B["Recipe: Lesser Stoneshield Potion"] = "Tarif: Küçük Taş Kalkan İksiri" end
if B["Recipe: Limited Invulnerability Potion"] == nil then B["Recipe: Limited Invulnerability Potion"] = "Tarif: Sınırlı Dokunulmazlık İksiri" end
if B["Recipe: Living Action Potion"] == nil then B["Recipe: Living Action Potion"] = "Tarif: Canlı Hareket İksiri" end
if B["Recipe: Lobster Stew"] == nil then B["Recipe: Lobster Stew"] = "Tarif: Istakoz Yahnisi" end
if B["Recipe: Loch Frenzy Delight"] == nil then B["Recipe: Loch Frenzy Delight"] = "Tarif: Loch Frenzy Lezzeti" end
if B["Recipe: Longjaw Mud Snapper"] == nil then B["Recipe: Longjaw Mud Snapper"] = "Tarif: Uzun Çeneli Çamur Balığı" end
if B["Recipe: Mageblood Potion"] == nil then B["Recipe: Mageblood Potion"] = "Tarif: Büyücü Kanı İksiri" end
if B["Recipe: Magic Resistance Potion"] == nil then B["Recipe: Magic Resistance Potion"] = "Tarif: Büyü Direnci İksiri" end
if B["Recipe: Major Healing Potion"] == nil then B["Recipe: Major Healing Potion"] = "Tarif: Büyük Şifa İksiri" end
if B["Recipe: Major Mana Potion"] == nil then B["Recipe: Major Mana Potion"] = "Tarif: Büyük Mana İksiri" end
if B["Recipe: Major Rejuvenation Potion"] == nil then B["Recipe: Major Rejuvenation Potion"] = "Tarif: Büyük Gençleşme İksiri" end
if B["Recipe: Major Troll's Blood Potion"] == nil then B["Recipe: Major Troll's Blood Potion"] = "Tarif: Büyük Trol Kanı İksiri" end
if B["Recipe: Mightfish Steak"] == nil then B["Recipe: Mightfish Steak"] = "Tarif: Kudret Balığı Bifteği" end
if B["Recipe: Mighty Rage Potion"] == nil then B["Recipe: Mighty Rage Potion"] = "Tarif: Kudretli Öfke İksiri" end
if B["Recipe: Mighty Troll's Blood Potion"] == nil then B["Recipe: Mighty Troll's Blood Potion"] = "Tarif: Kudretli Trol Kanı İksiri" end
if B["Recipe: Minor Magic Resistance Potion"] == nil then B["Recipe: Minor Magic Resistance Potion"] = "Tarif: Ufak Büyü Direnci İksiri" end
if B["Recipe: Mithril Head Trout"] == nil then B["Recipe: Mithril Head Trout"] = "Tarif: Mithril Başlı Alabalık" end
if B["Recipe: Monster Omelet"] == nil then B["Recipe: Monster Omelet"] = "Tarif: Canavar Omleti" end
if B["Recipe: Murloc Fin Soup"] == nil then B["Recipe: Murloc Fin Soup"] = "Tarif: Murloc Yüzgeci Çorbası" end
if B["Recipe: Mystery Stew"] == nil then B["Recipe: Mystery Stew"] = "Tarif: Gizemli Yahni" end
if B["Recipe: Nature Protection Potion"] == nil then B["Recipe: Nature Protection Potion"] = "Tarif: Doğadan Korunma İksiri" end
if B["Recipe: Nightfin Soup"] == nil then B["Recipe: Nightfin Soup"] = "Tarif: Gece Yüzgeci Çorbası" end
if B["Recipe: Philosophers' Stone"] == nil then B["Recipe: Philosophers' Stone"] = "Tarif: Filozof Taşı" end
if B["Recipe: Poached Sunscale Salmon"] == nil then B["Recipe: Poached Sunscale Salmon"] = "Tarif: Haşlanmış Güneş Pullu Somon" end
if B["Recipe: Purification Potion"] == nil then B["Recipe: Purification Potion"] = "Tarif: Arınma İksiri" end
if B["Recipe: Rage Potion"] == nil then B["Recipe: Rage Potion"] = "Tarif: Öfke İksiri" end
if B["Recipe: Rainbow Fin Albacore"] == nil then B["Recipe: Rainbow Fin Albacore"] = "Tarif: Gökkuşağı Yüzgeçli Ton Balığı" end
if B["Recipe: Redridge Goulash"] == nil then B["Recipe: Redridge Goulash"] = "Tarif: Redridge Gulaşı" end
if B["Recipe: Roast Raptor"] == nil then B["Recipe: Roast Raptor"] = "Tarif: Kızarmış Raptor" end
if B["Recipe: Roasted Kodo Meat"] == nil then B["Recipe: Roasted Kodo Meat"] = "Tarif: Kızarmış Kodo Eti" end
if B["Recipe: Rockscale Cod"] == nil then B["Recipe: Rockscale Cod"] = "Tarif: Kaya Pullu Morina" end
if B["Recipe: Runn Tum Tuber Surprise"] == nil then B["Recipe: Runn Tum Tuber Surprise"] = "Tarif: Runn Tum Yumrusu Sürprizi" end
if B["Recipe: Sagefish Delight"] == nil then B["Recipe: Sagefish Delight"] = "Tarif: Adaçayı Balığı Lezzeti" end
if B["Recipe: Savory Deviate Delight"] == nil then B["Recipe: Savory Deviate Delight"] = "Tarif: Lezzetli Deviate Ziyafeti" end
if B["Recipe: Scorpid Surprise"] == nil then B["Recipe: Scorpid Surprise"] = "Tarif: Scorpid Sürprizi" end
if B["Recipe: Seasoned Wolf Kabob"] == nil then B["Recipe: Seasoned Wolf Kabob"] = "Tarif: Baharatlı Kurt Kebabı" end
if B["Recipe: Shadow Oil"] == nil then B["Recipe: Shadow Oil"] = "Tarif: Gölge Yağı" end
if B["Recipe: Shadow Protection Potion"] == nil then B["Recipe: Shadow Protection Potion"] = "Tarif: Gölgeden Korunma İksiri" end
if B["Recipe: Slitherskin Mackerel"] == nil then B["Recipe: Slitherskin Mackerel"] = "Tarif: Kaygan Derili Uskumru" end
if B["Recipe: Smoked Bear Meat"] == nil then B["Recipe: Smoked Bear Meat"] = "Tarif: Tütsülenmiş Ayı Eti" end
if B["Recipe: Smoked Sagefish"] == nil then B["Recipe: Smoked Sagefish"] = "Tarif: Tütsülenmiş Adaçayı Balığı" end
if B["Recipe: Soothing Turtle Bisque"] == nil then B["Recipe: Soothing Turtle Bisque"] = "Tarif: Yatıştırıcı Kaplumbağa Çorbası" end
if B["Recipe: Spiced Chili Crab"] == nil then B["Recipe: Spiced Chili Crab"] = "Tarif: Baharatlı Acı Biberli Yengeç" end
if B["Recipe: Spotted Yellowtail"] == nil then B["Recipe: Spotted Yellowtail"] = "Tarif: Benekli Sarıkuyruk" end
if B["Recipe: Strider Stew"] == nil then B["Recipe: Strider Stew"] = "Tarif: Koşarkuş Yahnisi" end
if B["Recipe: Succulent Pork Ribs"] == nil then B["Recipe: Succulent Pork Ribs"] = "Tarif: Sulu Domuz Kaburgası" end
if B["Recipe: Superior Mana Potion"] == nil then B["Recipe: Superior Mana Potion"] = "Tarif: Üstün Mana İksiri" end
if B["Recipe: Swiftness Potion"] == nil then B["Recipe: Swiftness Potion"] = "Tarif: Sürat İksiri" end
if B["Recipe: Tasty Lion Steak"] == nil then B["Recipe: Tasty Lion Steak"] = "Tarif: Lezzetli Aslan Bifteği" end
if B["Recipe: Tender Wolf Steak"] == nil then B["Recipe: Tender Wolf Steak"] = "Tarif: Yumuşak Kurt Bifteği" end
if B["Recipe: Thistle Tea"] == nil then B["Recipe: Thistle Tea"] = "Tarif: Devedikeni Çayı" end
if B["Recipe: Transmute Air to Fire"] == nil then B["Recipe: Transmute Air to Fire"] = "Tarif: Havadan Ateşe Dönüştürme" end
if B["Recipe: Transmute Arcanite"] == nil then B["Recipe: Transmute Arcanite"] = "Tarif: Arcanite Dönüştürme" end
if B["Recipe: Transmute Earth to Life"] == nil then B["Recipe: Transmute Earth to Life"] = "Tarif: Topraktan Yaşama Dönüştürme" end
if B["Recipe: Transmute Earth to Water"] == nil then B["Recipe: Transmute Earth to Water"] = "Tarif: Topraktan Suya Dönüştürme" end
if B["Recipe: Transmute Elemental Fire"] == nil then B["Recipe: Transmute Elemental Fire"] = "Tarif: Elemental Ateş Dönüştürme" end
if B["Recipe: Transmute Fire to Earth"] == nil then B["Recipe: Transmute Fire to Earth"] = "Tarif: Ateşten Toprağa Dönüştürme" end
if B["Recipe: Transmute Iron to Gold"] == nil then B["Recipe: Transmute Iron to Gold"] = "Tarif: Demirden Altına Dönüştürme" end
if B["Recipe: Transmute Life to Earth"] == nil then B["Recipe: Transmute Life to Earth"] = "Tarif: Yaşamdan Toprağa Dönüştürme" end
if B["Recipe: Transmute Mithril to Truesilver"] == nil then B["Recipe: Transmute Mithril to Truesilver"] = "Tarif: Mithrilden Gerçek Gümüşe Dönüştürme" end
if B["Recipe: Transmute Undeath to Water"] == nil then B["Recipe: Transmute Undeath to Water"] = "Tarif: Ölümsüzlükten Suya Dönüştürme" end
if B["Recipe: Transmute Water to Air"] == nil then B["Recipe: Transmute Water to Air"] = "Tarif: Sudan Havaya Dönüştürme" end
if B["Recipe: Transmute Water to Undeath"] == nil then B["Recipe: Transmute Water to Undeath"] = "Tarif: Sudan Ölümsüzlüğe Dönüştürme" end
if B["Recipe: Undermine Clam Chowder"] == nil then B["Recipe: Undermine Clam Chowder"] = "Tarif: Undermine Midye Çorbası" end
if B["Recipe: Westfall Stew"] == nil then B["Recipe: Westfall Stew"] = "Tarif: Westfall Yahnisi" end
if B["Recipe: Wildvine"] == nil then B["Recipe: Wildvine"] = "Tarif: Yabani Sarmaşık" end
if B["Recite Words of Celebras"] == nil then B["Recite Words of Celebras"] = "Celebras'ın Sözlerini Oku" end
if B["Reckless Charge"] == nil then B["Reckless Charge"] = "Pervasız Hücum" end
if B["Recombobulate"] == nil then B["Recombobulate"] = "Yeniden Birleştir" end
if B["Red & Blue Mechanostrider"] == nil then B["Red & Blue Mechanostrider"] = "Kırmızı ve Mavi Mechanostrider" end
if B["Red Firework"] == nil then B["Red Firework"] = "Kırmızı Havai Fişek" end
if B["Red Firework Cluster"] == nil then B["Red Firework Cluster"] = "Kırmızı Havai Fişek Demeti" end
if B["Red Mechanostrider"] == nil then B["Red Mechanostrider"] = "Kırmızı Mechanostrider" end
if B["Red Ogre Costume"] == nil then B["Red Ogre Costume"] = "Kırmızı Ogre Kostümü" end
if B["Red Skeletal Horse"] == nil then B["Red Skeletal Horse"] = "Kırmızı İskelet At" end
if B["Red Skeletal Warhorse"] == nil then B["Red Skeletal Warhorse"] = "Kırmızı İskelet Savaş Atı" end
if B["Red Streaks Firework"] == nil then B["Red Streaks Firework"] = "Kırmızı Çizgili Havai Fişek" end
if B["Red Wolf"] == nil then B["Red Wolf"] = "Kırmızı Kurt" end
if B["Red, White and Blue Firework"] == nil then B["Red, White and Blue Firework"] = "Kırmızı, Beyaz ve Mavi Havai Fişek" end
if B["Redeeming the Soul"] == nil then B["Redeeming the Soul"] = "Ruhu Kurtarma" end
if B["Reduce Threat"] == nil then B["Reduce Threat"] = "Tehdidi Azalt" end
if B["Reduced Claw and Rake Cost"] == nil then B["Reduced Claw and Rake Cost"] = "Azaltılmış Pençe ve Tırmalama Maliyeti" end
if B["Reduced Maul and Swipe Cost"] == nil then B["Reduced Maul and Swipe Cost"] = "Azaltılmış Hırpalama ve Savurma Maliyeti" end
if B["Reduced Reincarnation Cooldown"] == nil then B["Reduced Reincarnation Cooldown"] = "Azaltılmış Reenkarnasyon Bekleme Süresi" end
if B["Refocus"] == nil then B["Refocus"] = "Yeniden Odaklan" end
if B["Refreshing Red Apple"] == nil then B["Refreshing Red Apple"] = "Ferahlatıcı Kırmızı Elma" end
if B["Reindeer"] == nil then B["Reindeer"] = "Ren Geyiği" end
if B["Reindeer Transformation"] == nil then B["Reindeer Transformation"] = "Ren Geyiği Dönüşümü" end
if B["Rejuvenation Potion"] == nil then B["Rejuvenation Potion"] = "Gençleşme İksiri" end
if B["Release Imp"] == nil then B["Release Imp"] = "Imp'i Serbest Bırak" end
if B["Release J'eevee"] == nil then B["Release J'eevee"] = "J'eevee'yi Serbest Bırak" end
if B["Release Rageclaw"] == nil then B["Release Rageclaw"] = "Rageclaw'ı Serbest Bırak" end
if B["Release Umi's Yeti"] == nil then B["Release Umi's Yeti"] = "Umi'nin Yeti'sini Serbest Bırak" end
if B["Release the Hounds"] == nil then B["Release the Hounds"] = "Tazıları Sal" end
if B["Releasing Corrupt Ooze"] == nil then B["Releasing Corrupt Ooze"] = "Bozulmuş Balçığı Salma" end
if B["Remote Detonate"] == nil then B["Remote Detonate"] = "Uzaktan Patlat" end
if B["Repair the Blade of Heroes"] == nil then B["Repair the Blade of Heroes"] = "Kahramanların Kılıcını Onar" end
if B["Replenish Mana"] == nil then B["Replenish Mana"] = "Manayı Doldur" end
if B["Replenish Mana I"] == nil then B["Replenish Mana I"] = "Manayı Doldur I" end
if B["Replenish Mana II"] == nil then B["Replenish Mana II"] = "Manayı Doldur II" end
if B["Resilience of the Scourge"] == nil then B["Resilience of the Scourge"] = "Scourge'un Dayanıklılığı" end
if B["Resist Silence"] == nil then B["Resist Silence"] = "Susturmaya Direnç" end
if B["Resistance"] == nil then B["Resistance"] = "Direnç" end
if B["Restless Strength"] == nil then B["Restless Strength"] = "Huzursuz Güç" end
if B["Restoration"] == nil then B["Restoration"] = "Yenilenme" end
if B["Restore Energy"] == nil then B["Restore Energy"] = "Enerji Yenile" end
if B["Restore Life"] == nil then B["Restore Life"] = "Yaşamı Geri Getir" end
if B["Restore Mana"] == nil then B["Restore Mana"] = "Mana Yenile" end
if B["Revive Dig Rat"] == nil then B["Revive Dig Rat"] = "Kazıcı Fareyi Dirilt" end
if B["Revive Ringo"] == nil then B["Revive Ringo"] = "Ringo'yu Dirilt" end
if B["Riding Kodo"] == nil then B["Riding Kodo"] = "Binek Kodo" end
if B["Riding Turtle"] == nil then B["Riding Turtle"] = "Binek Kaplumbağa" end
if B["Right Piece of Lord Valthalak's Amulet"] == nil then B["Right Piece of Lord Valthalak's Amulet"] = "Lord Valthalak'ın Muskasının Sağ Parçası" end
if B["Ritual of Doom"] == nil then B["Ritual of Doom"] = "Kıyamet Ritüeli" end
if B["Ritual: Mooncloth"] == nil then B["Ritual: Mooncloth"] = "Ritüel: Ay Kumaşı" end
if B["Rocket Blast"] == nil then B["Rocket Blast"] = "Roket Patlaması" end
if B["Rough Copper Bomb"] == nil then B["Rough Copper Bomb"] = "Kaba Bakır Bomba" end
if B["Rough Dynamite"] == nil then B["Rough Dynamite"] = "Kaba Dinamit" end
if B["Rumsey Rum"] == nil then B["Rumsey Rum"] = "Rumsey Romu" end
if B["Rumsey Rum Black Label"] == nil then B["Rumsey Rum Black Label"] = "Rumsey Romu Siyah Etiket" end
if B["Rumsey Rum Dark"] == nil then B["Rumsey Rum Dark"] = "Rumsey Koyu Rom" end
if B["Rumsey Rum Light"] == nil then B["Rumsey Rum Light"] = "Rumsey Hafif Rom" end
if B["Rune of Opening"] == nil then B["Rune of Opening"] = "Açılış Rünü" end
if B["Rune of the Dawn"] == nil then B["Rune of the Dawn"] = "Şafak Rünü" end
if B["Running Speed"] == nil then B["Running Speed"] = "Koşma Hızı" end
if B["Ryson's Eye in the Sky"] == nil then B["Ryson's Eye in the Sky"] = "Ryson'ın Gökteki Gözü" end
if B["Sacred Cleansing"] == nil then B["Sacred Cleansing"] = "Kutsal Arınma" end
if B["Sacrifice"] == nil then B["Sacrifice"] = "Kurban" end
if B["Sacrifice Spinneret"] == nil then B["Sacrifice Spinneret"] = "Ağ Bezini Kurban Et" end
if B["Salt Shaker"] == nil then B["Salt Shaker"] = "Tuzluk" end
if B["Sanctified Orb"] == nil then B["Sanctified Orb"] = "Kutsanmış Küre" end
if B["Sanctuary"] == nil then B["Sanctuary"] = "Sığınak" end
if B["Sapta Sight"] == nil then B["Sapta Sight"] = "Sapta Görüşü" end
if B["Savage Guard"] == nil then B["Savage Guard"] = "Vahşi Muhafız" end
if B["Savior's Sacrifice"] == nil then B["Savior's Sacrifice"] = "Kurtarıcının Fedakârlığı" end
if B["Scarlet Illusion"] == nil then B["Scarlet Illusion"] = "Kızıl İllüzyon" end
if B["Schematic: Accurate Scope"] == nil then B["Schematic: Accurate Scope"] = "Şema: Hassas Dürbün" end
if B["Schematic: Alarm-O-Bot"] == nil then B["Schematic: Alarm-O-Bot"] = "Şema: Alarm-O-Bot" end
if B["Schematic: Arcane Bomb"] == nil then B["Schematic: Arcane Bomb"] = "Şema: Arkan Bomba" end
if B["Schematic: Arcanite Dragonling"] == nil then B["Schematic: Arcanite Dragonling"] = "Şema: Arcanite Ejder Yavrusu" end
if B["Schematic: Biznicks 247x128 Accurascope"] == nil then B["Schematic: Biznicks 247x128 Accurascope"] = "Şema: Biznicks 247x128 Hassas Dürbün" end
if B["Schematic: Bloodvine Goggles"] == nil then B["Schematic: Bloodvine Goggles"] = "Şema: Kan Sarmaşığı Gözlüğü" end
if B["Schematic: Bloodvine Lens"] == nil then B["Schematic: Bloodvine Lens"] = "Şema: Kan Sarmaşığı Merceği" end
if B["Schematic: Blue Firework"] == nil then B["Schematic: Blue Firework"] = "Şema: Mavi Havai Fişek" end
if B["Schematic: Blue Rocket Cluster"] == nil then B["Schematic: Blue Rocket Cluster"] = "Şema: Mavi Roket Demeti" end
if B["Schematic: Bright-Eye Goggles"] == nil then B["Schematic: Bright-Eye Goggles"] = "Şema: Parlak Göz Gözlüğü" end
if B["Schematic: Catseye Ultra Goggles"] == nil then B["Schematic: Catseye Ultra Goggles"] = "Şema: Kedi Gözü Ultra Gözlük" end
if B["Schematic: Core Marksman Rifle"] == nil then B["Schematic: Core Marksman Rifle"] = "Şema: Çekirdek Nişancı Tüfeği" end
if B["Schematic: Craftsman's Monocle"] == nil then B["Schematic: Craftsman's Monocle"] = "Şema: Zanaatkâr Monoklu" end
if B["Schematic: Dark Iron Bomb"] == nil then B["Schematic: Dark Iron Bomb"] = "Şema: Kara Demir Bombası" end
if B["Schematic: Dark Iron Rifle"] == nil then B["Schematic: Dark Iron Rifle"] = "Şema: Kara Demir Tüfek" end
if B["Schematic: Deadly Scope"] == nil then B["Schematic: Deadly Scope"] = "Şema: Ölümcül Dürbün" end
if B["Schematic: Deepdive Helmet"] == nil then B["Schematic: Deepdive Helmet"] = "Şema: Derin Dalış Miğferi" end
if B["Schematic: Delicate Arcanite Converter"] == nil then B["Schematic: Delicate Arcanite Converter"] = "Şema: Hassas Arcanite Dönüştürücü" end
if B["Schematic: Discombobulator Ray"] == nil then B["Schematic: Discombobulator Ray"] = "Şema: Kafa Karıştırıcı Işın" end
if B["Schematic: EZ-Thro Dynamite"] == nil then B["Schematic: EZ-Thro Dynamite"] = "Şema: Kolay Atılır Dinamit" end
if B["Schematic: EZ-Thro Dynamite II"] == nil then B["Schematic: EZ-Thro Dynamite II"] = "Şema: Kolay Atılır Dinamit II" end
if B["Schematic: Field Repair Bot 74A"] == nil then B["Schematic: Field Repair Bot 74A"] = "Şema: Saha Tamir Robotu 74A" end
if B["Schematic: Firework Cluster Launcher"] == nil then B["Schematic: Firework Cluster Launcher"] = "Şema: Havai Fişek Demeti Atar" end
if B["Schematic: Firework Launcher"] == nil then B["Schematic: Firework Launcher"] = "Şema: Havai Fişek Atar" end
if B["Schematic: Flame Deflector"] == nil then B["Schematic: Flame Deflector"] = "Şema: Alev Saptırıcı" end
if B["Schematic: Flash Bomb"] == nil then B["Schematic: Flash Bomb"] = "Şema: Flaş Bombası" end
if B["Schematic: Flawless Arcanite Rifle"] == nil then B["Schematic: Flawless Arcanite Rifle"] = "Şema: Kusursuz Arcanite Tüfek" end
if B["Schematic: Force Reactive Disk"] == nil then B["Schematic: Force Reactive Disk"] = "Şema: Kuvvet Tepkili Disk" end
if B["Schematic: Gnomish Cloaking Device"] == nil then B["Schematic: Gnomish Cloaking Device"] = "Şema: Gnome Gizlenme Cihazı" end
if B["Schematic: Gnomish Universal Remote"] == nil then B["Schematic: Gnomish Universal Remote"] = "Şema: Gnome Evrensel Kumandası" end
if B["Schematic: Goblin Jumper Cable XL"] == nil then B["Schematic: Goblin Jumper Cable XL"] = "Şema: Goblin Takviye Kablosu XL" end
if B["Schematic: Goblin Jumper Cables"] == nil then B["Schematic: Goblin Jumper Cables"] = "Şema: Goblin Takviye Kabloları" end
if B["Schematic: Goblin Land Mine"] == nil then B["Schematic: Goblin Land Mine"] = "Şema: Goblin Kara Mayını" end
if B["Schematic: Green Firework"] == nil then B["Schematic: Green Firework"] = "Şema: Yeşil Havai Fişek" end
if B["Schematic: Green Rocket Cluster"] == nil then B["Schematic: Green Rocket Cluster"] = "Şema: Yeşil Roket Demeti" end
if B["Schematic: Gyrofreeze Ice Reflector"] == nil then B["Schematic: Gyrofreeze Ice Reflector"] = "Şema: Jiro Dondurucu Buz Yansıtıcı" end
if B["Schematic: Hyper-Radiant Flame Reflector"] == nil then B["Schematic: Hyper-Radiant Flame Reflector"] = "Şema: Süper Işıltılı Alev Yansıtıcı" end
if B["Schematic: Ice Deflector"] == nil then B["Schematic: Ice Deflector"] = "Şema: Buz Saptırıcı" end
if B["Schematic: Large Blue Rocket"] == nil then B["Schematic: Large Blue Rocket"] = "Şema: Büyük Mavi Roket" end
if B["Schematic: Large Blue Rocket Cluster"] == nil then B["Schematic: Large Blue Rocket Cluster"] = "Şema: Büyük Mavi Roket Demeti" end
if B["Schematic: Large Green Rocket"] == nil then B["Schematic: Large Green Rocket"] = "Şema: Büyük Yeşil Roket" end
if B["Schematic: Large Green Rocket Cluster"] == nil then B["Schematic: Large Green Rocket Cluster"] = "Şema: Büyük Yeşil Roket Demeti" end
if B["Schematic: Large Red Rocket"] == nil then B["Schematic: Large Red Rocket"] = "Şema: Büyük Kırmızı Roket" end
if B["Schematic: Large Red Rocket Cluster"] == nil then B["Schematic: Large Red Rocket Cluster"] = "Şema: Büyük Kırmızı Roket Demeti" end
if B["Schematic: Large Seaforium Charge"] == nil then B["Schematic: Large Seaforium Charge"] = "Şema: Büyük Seaforium Patlayıcısı" end
if B["Schematic: Lifelike Mechanical Toad"] == nil then B["Schematic: Lifelike Mechanical Toad"] = "Şema: Canlı Gibi Mekanik Kurbağa" end
if B["Schematic: Lil' Smoky"] == nil then B["Schematic: Lil' Smoky"] = "Şema: Küçük Dumanlı" end
if B["Schematic: Lovingly Crafted Boomstick"] == nil then B["Schematic: Lovingly Crafted Boomstick"] = "Şema: Özenle Yapılmış Patlangaç" end
if B["Schematic: Major Recombobulator"] == nil then B["Schematic: Major Recombobulator"] = "Şema: Büyük Yeniden Birleştirici" end
if B["Schematic: Master Engineer's Goggles"] == nil then B["Schematic: Master Engineer's Goggles"] = "Şema: Usta Mühendisin Gözlüğü" end
if B["Schematic: Mechanical Dragonling"] == nil then B["Schematic: Mechanical Dragonling"] = "Şema: Mekanik Ejder Yavrusu" end
if B["Schematic: Mechanical Squirrel"] == nil then B["Schematic: Mechanical Squirrel"] = "Şema: Mekanik Sincap" end
if B["Schematic: Minor Recombobulator"] == nil then B["Schematic: Minor Recombobulator"] = "Şema: Ufak Yeniden Birleştirici" end
if B["Schematic: Mithril Heavy-bore Rifle"] == nil then B["Schematic: Mithril Heavy-bore Rifle"] = "Şema: Mithril Geniş Namlulu Tüfek" end
if B["Schematic: Mithril Mechanical Dragonling"] == nil then B["Schematic: Mithril Mechanical Dragonling"] = "Şema: Mithril Mekanik Ejder Yavrusu" end
if B["Schematic: Moonsight Rifle"] == nil then B["Schematic: Moonsight Rifle"] = "Şema: Ay Görüşü Tüfeği" end
if B["Schematic: Parachute Cloak"] == nil then B["Schematic: Parachute Cloak"] = "Şema: Paraşüt Pelerini" end
if B["Schematic: Pet Bombling"] == nil then B["Schematic: Pet Bombling"] = "Şema: Evcil Bombacık" end
if B["Schematic: Portable Bronze Mortar"] == nil then B["Schematic: Portable Bronze Mortar"] = "Şema: Taşınabilir Bronz Havan" end
if B["Schematic: Powerful Seaforium Charge"] == nil then B["Schematic: Powerful Seaforium Charge"] = "Şema: Güçlü Seaforium Patlayıcısı" end
if B["Schematic: Red Firework"] == nil then B["Schematic: Red Firework"] = "Şema: Kırmızı Havai Fişek" end
if B["Schematic: Red Rocket Cluster"] == nil then B["Schematic: Red Rocket Cluster"] = "Şema: Kırmızı Roket Demeti" end
if B["Schematic: Shadow Goggles"] == nil then B["Schematic: Shadow Goggles"] = "Şema: Gölge Gözlüğü" end
if B["Schematic: Small Blue Rocket"] == nil then B["Schematic: Small Blue Rocket"] = "Şema: Küçük Mavi Roket" end
if B["Schematic: Small Green Rocket"] == nil then B["Schematic: Small Green Rocket"] = "Şema: Küçük Yeşil Roket" end
if B["Schematic: Small Red Rocket"] == nil then B["Schematic: Small Red Rocket"] = "Şema: Küçük Kırmızı Roket" end
if B["Schematic: Small Seaforium Charge"] == nil then B["Schematic: Small Seaforium Charge"] = "Şema: Küçük Seaforium Patlayıcısı" end
if B["Schematic: Snake Burst Firework"] == nil then B["Schematic: Snake Burst Firework"] = "Şema: Yılan Patlaması Havai Fişeği" end
if B["Schematic: Sniper Scope"] == nil then B["Schematic: Sniper Scope"] = "Şema: Keskin Nişancı Dürbünü" end
if B["Schematic: Snowmaster 9000"] == nil then B["Schematic: Snowmaster 9000"] = "Şema: Kar Ustası 9000" end
if B["Schematic: Spellpower Goggles Xtreme"] == nil then B["Schematic: Spellpower Goggles Xtreme"] = "Şema: Büyü Gücü Gözlüğü Xtreme" end
if B["Schematic: Spellpower Goggles Xtreme Plus"] == nil then B["Schematic: Spellpower Goggles Xtreme Plus"] = "Şema: Büyü Gücü Gözlüğü Xtreme Plus" end
if B["Schematic: Steam Tonk Controller"] == nil then B["Schematic: Steam Tonk Controller"] = "Şema: Buharlı Tonk Kumandası" end
if B["Schematic: Thorium Grenade"] == nil then B["Schematic: Thorium Grenade"] = "Şema: Toryum El Bombası" end
if B["Schematic: Thorium Rifle"] == nil then B["Schematic: Thorium Rifle"] = "Şema: Toryum Tüfek" end
if B["Schematic: Thorium Shells"] == nil then B["Schematic: Thorium Shells"] = "Şema: Toryum Mermiler" end
if B["Schematic: Thorium Tube"] == nil then B["Schematic: Thorium Tube"] = "Şema: Toryum Boru" end
if B["Schematic: Thorium Widget"] == nil then B["Schematic: Thorium Widget"] = "Şema: Toryum Düzenek" end
if B["Schematic: Truesilver Transformer"] == nil then B["Schematic: Truesilver Transformer"] = "Şema: Gerçek Gümüş Dönüştürücü" end
if B["Schematic: Ultra-Flash Shadow Reflector"] == nil then B["Schematic: Ultra-Flash Shadow Reflector"] = "Şema: Ultra Flaş Gölge Yansıtıcı" end
if B["Schematic: Voice Amplification Modulator"] == nil then B["Schematic: Voice Amplification Modulator"] = "Şema: Ses Yükseltme Modülatörü" end
if B["Schematic: World Enlarger"] == nil then B["Schematic: World Enlarger"] = "Şema: Dünya Büyüteci" end
if B["Scooby Snack Effect"] == nil then B["Scooby Snack Effect"] = "Scooby Atıştırmalığı Etkisi" end
if B["Scorpid Sample"] == nil then B["Scorpid Sample"] = "Scorpid Örneği" end
if B["Scraping"] == nil then B["Scraping"] = "Kazıma" end
if B["Seal Cost Reduced"] == nil then B["Seal Cost Reduced"] = "Mühür Maliyeti Azaltıldı" end
if B["Seal Felvine Shard"] == nil then B["Seal Felvine Shard"] = "Felvine Parçasını Mühürle" end
if B["Seal of Fury"] == nil then B["Seal of Fury"] = "Öfke Mührü" end
if B["Seal of Might"] == nil then B["Seal of Might"] = "Kudret Mührü" end
if B["Seal of Protection"] == nil then B["Seal of Protection"] = "Koruma Mührü" end
if B["Seal of Reckoning"] == nil then B["Seal of Reckoning"] = "Hesaplaşma Mührü" end
if B["Seal of Sacrifice"] == nil then B["Seal of Sacrifice"] = "Fedakârlık Mührü" end
if B["Seal of Salvation"] == nil then B["Seal of Salvation"] = "Kurtuluş Mührü" end
if B["Seal of the Crusader Judgement Increase"] == nil then B["Seal of the Crusader Judgement Increase"] = "Haçlı Mührü Yargı Artışı" end
if B["Seal of the Dawn"] == nil then B["Seal of the Dawn"] = "Şafağın Mührü" end
if B["Searing Arrow"] == nil then B["Searing Arrow"] = "Kavurucu Ok" end
if B["Searing Blast"] == nil then B["Searing Blast"] = "Kavurucu Patlama" end
if B["Searing Pain Cast Pushback Reduction"] == nil then B["Searing Pain Cast Pushback Reduction"] = "Kavurucu Acı Büyü Kesintisi Azaltma" end
if B["Second Wind"] == nil then B["Second Wind"] = "İkinci Nefes" end
if B["Seduction"] == nil then B["Seduction"] = "Baştan Çıkarma" end
if B["Seeping Willow"] == nil then B["Seeping Willow"] = "Sızan Söğüt" end
if B["Sense Undead"] == nil then B["Sense Undead"] = "Ölümsüzleri Sez" end
if B["Serpent's Hiss"] == nil then B["Serpent's Hiss"] = "Yılanın Tıslaması" end
if B["Set NG-5 Charge (Blue)"] == nil then B["Set NG-5 Charge (Blue)"] = "NG-5 Patlayıcısını Kur (Mavi)" end
if B["Set NG-5 Charge (Red)"] == nil then B["Set NG-5 Charge (Red)"] = "NG-5 Patlayıcısını Kur (Kırmızı)" end
if B["Shadow Guard"] == nil then B["Shadow Guard"] = "Gölge Muhafızı" end
if B["Shadow Mantle of the Dawn"] == nil then B["Shadow Mantle of the Dawn"] = "Şafağın Gölge Pelerini" end
if B["Shadow Oil"] == nil then B["Shadow Oil"] = "Gölge Yağı" end
if B["Shadow Power"] == nil then B["Shadow Power"] = "Gölge Gücü" end
if B["Shadow Protection "] == nil then B["Shadow Protection "] = "Gölge Koruması" end
if B["Shadow Reflector"] == nil then B["Shadow Reflector"] = "Gölge Yansıtıcı" end
if B["Shadow Shot"] == nil then B["Shadow Shot"] = "Gölge Atışı" end
if B["Shadow Word: Befuddle"] == nil then B["Shadow Word: Befuddle"] = "Gölge Sözü: Şaşırtma" end
if B["Shadow Word: Fumble"] == nil then B["Shadow Word: Fumble"] = "Gölge Sözü: Sakarlık" end
if B["Shadowbolt"] == nil then B["Shadowbolt"] = "Gölge Oku" end
if B["Shard of the Fallen Star"] == nil then B["Shard of the Fallen Star"] = "Düşen Yıldızın Kırığı" end
if B["Sharp Dresser"] == nil then B["Sharp Dresser"] = "Şık Giyinen" end
if B["Sharpen Blade"] == nil then B["Sharpen Blade"] = "Kılıcı Bile" end
if B["Sharpen Blade II"] == nil then B["Sharpen Blade II"] = "Kılıcı Bile II" end
if B["Sharpen Blade III"] == nil then B["Sharpen Blade III"] = "Kılıcı Bile III" end
if B["Sharpen Blade IV"] == nil then B["Sharpen Blade IV"] = "Kılıcı Bile IV" end
if B["Sharpen Blade V"] == nil then B["Sharpen Blade V"] = "Kılıcı Bile V" end
if B["Sharpen Weapon - Critical"] == nil then B["Sharpen Weapon - Critical"] = "Silahı Bile - Kritik" end
if B["Shatter Soul Gem"] == nil then B["Shatter Soul Gem"] = "Ruh Taşını Parçala" end
if B["Shay's Bell"] == nil then B["Shay's Bell"] = "Shay'in Çanı" end
if B["Sheen of Zanza"] == nil then B["Sheen of Zanza"] = "Zanza'nın Parıltısı" end
if B["Shimmer Stout"] == nil then B["Shimmer Stout"] = "Parıltı Birası" end
if B["Shiny Bauble"] == nil then B["Shiny Bauble"] = "Parlak Süs" end
if B["Shock"] == nil then B["Shock"] = "Şok" end
if B["Shrink Ray"] == nil then B["Shrink Ray"] = "Küçültme Işını" end
if B["Signing"] == nil then B["Signing"] = "İmzalama" end
if B["Silence Trigger"] == nil then B["Silence Trigger"] = "Susturma Tetikleyicisi" end
if B["Silver Skeleton Key"] == nil then B["Silver Skeleton Key"] = "Gümüş Maymuncuk" end
if B["Siphon Health"] == nil then B["Siphon Health"] = "Can Emme" end
if B["Six Demon Bag"] == nil then B["Six Demon Bag"] = "Altı İblis Çantası" end
if B["Skeletal Horse"] == nil then B["Skeletal Horse"] = "İskelet At" end
if B["Skeletal Steed"] == nil then B["Skeletal Steed"] = "İskelet Binek Atı" end
if B["Skeleton Costume"] == nil then B["Skeleton Costume"] = "İskelet Kostümü" end
if B["Skullforge Brand"] == nil then B["Skullforge Brand"] = "Skullforge Damgası" end
if B["Slayer's Crest"] == nil then B["Slayer's Crest"] = "Katil Arması" end
if B["Sleep"] == nil then B["Sleep"] = "Uyku" end
if B["Slow"] == nil then B["Slow"] = "Yavaşlat" end
if B["Small Blue Rocket"] == nil then B["Small Blue Rocket"] = "Küçük Mavi Roket" end
if B["Small Bronze Bomb"] == nil then B["Small Bronze Bomb"] = "Küçük Bronz Bomba" end
if B["Small Green Rocket"] == nil then B["Small Green Rocket"] = "Küçük Yeşil Roket" end
if B["Small Purple Rocket"] == nil then B["Small Purple Rocket"] = "Küçük Mor Roket" end
if B["Small Red Rocket"] == nil then B["Small Red Rocket"] = "Küçük Kırmızı Roket" end
if B["Small Seaforium Charge"] == nil then B["Small Seaforium Charge"] = "Küçük Seaforium Patlayıcısı" end
if B["Small White Rocket"] == nil then B["Small White Rocket"] = "Küçük Beyaz Roket" end
if B["Small Yellow Rocket"] == nil then B["Small Yellow Rocket"] = "Küçük Sarı Roket" end
if B["Smokey's Lighter"] == nil then B["Smokey's Lighter"] = "Smokey'nin Çakmağı" end
if B["Sneezing Fit"] == nil then B["Sneezing Fit"] = "Hapşırık Nöbeti" end
if B["Sniper Scope"] == nil then B["Sniper Scope"] = "Keskin Nişancı Dürbünü" end
if B["SnowMaster 9000"] == nil then B["SnowMaster 9000"] = "Kar Ustası 9000" end
if B["Snowball"] == nil then B["Snowball"] = "Kar Topu" end
if B["Snowman"] == nil then B["Snowman"] = "Kardan Adam" end
if B["Snufflenose Command"] == nil then B["Snufflenose Command"] = "Snufflenose Komutu" end
if B["Solid Dynamite"] == nil then B["Solid Dynamite"] = "Sağlam Dinamit" end
if B["Soothing Kiss"] == nil then B["Soothing Kiss"] = "Yatıştırıcı Öpücük" end
if B["Soul Breaker"] == nil then B["Soul Breaker"] = "Ruh Kıran" end
if B["Soul Claim"] == nil then B["Soul Claim"] = "Ruh Sahiplenme" end
if B["Soulstone Resurrection"] == nil then B["Soulstone Resurrection"] = "Ruh Taşı Dirilişi" end
if B["South Seas Pirate Disguise"] == nil then B["South Seas Pirate Disguise"] = "Güney Denizleri Korsanı Kılığı" end
if B["Spawn Challenge to Urok"] == nil then B["Spawn Challenge to Urok"] = "Urok'a Meydan Okuma Çağır" end
if B["Speed"] == nil then B["Speed"] = "Hız" end
if B["Spell Blasting"] == nil then B["Spell Blasting"] = "Büyü Patlatma" end
if B["Spell Damage Reduction"] == nil then B["Spell Damage Reduction"] = "Büyü Hasarı Azaltma" end
if B["Spell Lock"] == nil then B["Spell Lock"] = "Büyü Kilidi" end
if B["Spell Penetration"] == nil then B["Spell Penetration"] = "Büyü Delme" end
if B["Spell Penetration 15"] == nil then B["Spell Penetration 15"] = "Büyü Delme 15" end
if B["Spell Penetration 150 Fire Resist"] == nil then B["Spell Penetration 150 Fire Resist"] = "Büyü Delme 150 Ateş Direnci" end
if B["Spell Penetration 150 Frost Resist"] == nil then B["Spell Penetration 150 Frost Resist"] = "Büyü Delme 150 Buz Direnci" end
if B["Spell Vulnerability"] == nil then B["Spell Vulnerability"] = "Büyü Zafiyeti" end
if B["Spellstone"] == nil then B["Spellstone"] = "Büyü Taşı" end
if B["Spinal Reaper"] == nil then B["Spinal Reaper"] = "Omurga Biçici" end
if B["Spirit"] == nil then B["Spirit"] = "Ruh" end
if B["Spirit Armor"] == nil then B["Spirit Armor"] = "Ruh Zırhı" end
if B["Spirit of Boar"] == nil then B["Spirit of Boar"] = "Yaban Domuzu Ruhu" end
if B["Spirit of Zanza"] == nil then B["Spirit of Zanza"] = "Zanza'nın Ruhu" end
if B["Spiritual Domination"] == nil then B["Spiritual Domination"] = "Ruhsal Hakimiyet" end
if B["Spore Burst"] == nil then B["Spore Burst"] = "Spor Patlaması" end
if B["Spotlight"] == nil then B["Spotlight"] = "Spot Işığı" end
if B["Spotted Frostsaber"] == nil then B["Spotted Frostsaber"] = "Benekli Frostsaber" end
if B["Spotted Panther"] == nil then B["Spotted Panther"] = "Benekli Panter" end
if B["Sprinkling Purified Water"] == nil then B["Sprinkling Purified Water"] = "Arındırılmış Su Serpme" end
if B["Sprint Duration Increase"] == nil then B["Sprint Duration Increase"] = "Koşu Süresi Artışı" end
if B["Stamina"] == nil then B["Stamina"] = "Dayanıklılık" end
if B["Standard Alcohol"] == nil then B["Standard Alcohol"] = "Standart Alkol" end
if B["Standard Scope"] == nil then B["Standard Scope"] = "Standart Dürbün" end
if B["Static Electricity"] == nil then B["Static Electricity"] = "Statik Elektrik" end
if B["Stealth +8"] == nil then B["Stealth +8"] = "Gizlilik +8" end
if B["Stealth 5"] == nil then B["Stealth 5"] = "Gizlilik 5" end
if B["Stealth Detection"] == nil then B["Stealth Detection"] = "Gizlilik Tespiti" end
if B["Stoneshield"] == nil then B["Stoneshield"] = "Taş Kalkan" end
if B["Stonesplinter Disguise"] == nil then B["Stonesplinter Disguise"] = "Stonesplinter Kılığı" end
if B["Stormpike Battle Charger"] == nil then B["Stormpike Battle Charger"] = "Stormpike Savaş Atı" end
if B["Stormwind Gift of Friendship"] == nil then B["Stormwind Gift of Friendship"] = "Stormwind Dostluk Hediyesi" end
if B["Stout Heart"] == nil then B["Stout Heart"] = "Yiğit Yürek" end
if B["Stratholme Holy Water"] == nil then B["Stratholme Holy Water"] = "Stratholme Kutsal Suyu" end
if B["Strength"] == nil then B["Strength"] = "Güç" end
if B["Strength of Stone"] == nil then B["Strength of Stone"] = "Taşın Gücü" end
if B["Strength of the Champion"] == nil then B["Strength of the Champion"] = "Şampiyonun Gücü" end
if B["Strike of the Scorpok"] == nil then B["Strike of the Scorpok"] = "Scorpok Vuruşu" end
if B["String Together Heads"] == nil then B["String Together Heads"] = "Kafaları Birbirine Diz" end
if B["Striped Frostsaber"] == nil then B["Striped Frostsaber"] = "Çizgili Frostsaber" end
if B["Striped Nightsaber"] == nil then B["Striped Nightsaber"] = "Çizgili Nightsaber" end
if B["Strong Alcohol"] == nil then B["Strong Alcohol"] = "Güçlü Alkol" end
if B["Strong Anti-Venom"] == nil then B["Strong Anti-Venom"] = "Güçlü Panzehir" end
if B["Stun"] == nil then B["Stun"] = "Sersemletme" end
if B["Stunning Blow"] == nil then B["Stunning Blow"] = "Sersemletici Darbe" end
if B["Stygian Grasp"] == nil then B["Stygian Grasp"] = "Cehennemi Kavrayış" end
if B["Suffering"] == nil then B["Suffering"] = "Acı Çekme" end
if B["Summon Alarm-o-Bot"] == nil then B["Summon Alarm-o-Bot"] = "Alarm-o-Bot Çağır" end
if B["Summon Albino Snapjaw"] == nil then B["Summon Albino Snapjaw"] = "Albino Snapjaw Çağır" end
if B["Summon Ancient Spirits"] == nil then B["Summon Ancient Spirits"] = "Kadim Ruhları Çağır" end
if B["Summon Ancona"] == nil then B["Summon Ancona"] = "Ancona Çağır" end
if B["Summon Aquementas"] == nil then B["Summon Aquementas"] = "Aquementas Çağır" end
if B["Summon Ar'lia"] == nil then B["Summon Ar'lia"] = "Ar'lia Çağır" end
if B["Summon Baby Shark"] == nil then B["Summon Baby Shark"] = "Yavru Köpekbalığı Çağır" end
if B["Summon Black Kingsnake"] == nil then B["Summon Black Kingsnake"] = "Kara Şah Yılanı Çağır" end
if B["Summon Black Qiraji Battle Tank"] == nil then B["Summon Black Qiraji Battle Tank"] = "Kara Qiraji Savaş Tankı Çağır" end
if B["Summon Blood Parrot"] == nil then B["Summon Blood Parrot"] = "Kan Papağanı Çağır" end
if B["Summon Blue Qiraji Battle Tank"] == nil then B["Summon Blue Qiraji Battle Tank"] = "Mavi Qiraji Savaş Tankı Çağır" end
if B["Summon Bomb"] == nil then B["Summon Bomb"] = "Bomba Çağır" end
if B["Summon Bombay"] == nil then B["Summon Bombay"] = "Bombay Çağır" end
if B["Summon Brown Snake"] == nil then B["Summon Brown Snake"] = "Kahverengi Yılan Çağır" end
if B["Summon Cinder Elemental"] == nil then B["Summon Cinder Elemental"] = "Kor Elementali Çağır" end
if B["Summon Cockatiel"] == nil then B["Summon Cockatiel"] = "Sultan Papağanı Çağır" end
if B["Summon Cockroach"] == nil then B["Summon Cockroach"] = "Hamamböceği Çağır" end
if B["Summon Common Kitten"] == nil then B["Summon Common Kitten"] = "Sıradan Kedi Yavrusu Çağır" end
if B["Summon Cornish Rex"] == nil then B["Summon Cornish Rex"] = "Cornish Rex Çağır" end
if B["Summon Corrupted Kitten"] == nil then B["Summon Corrupted Kitten"] = "Bozulmuş Kedi Yavrusu Çağır" end
if B["Summon Crimson Cannon"] == nil then B["Summon Crimson Cannon"] = "Kızıl Top Çağır" end
if B["Summon Crimson Snake"] == nil then B["Summon Crimson Snake"] = "Kızıl Yılan Çağır" end
if B["Summon Crimson Whelpling"] == nil then B["Summon Crimson Whelpling"] = "Kızıl Ejder Yavrusu Çağır" end
if B["Summon Dagun"] == nil then B["Summon Dagun"] = "Dagun Çağır" end
if B["Summon Dark Whelpling"] == nil then B["Summon Dark Whelpling"] = "Karanlık Ejder Yavrusu Çağır" end
if B["Summon Diablo"] == nil then B["Summon Diablo"] = "Diablo Çağır" end
if B["Summon Disgusting Oozeling"] == nil then B["Summon Disgusting Oozeling"] = "İğrenç Balçıkçık Çağır" end
if B["Summon Echeyakee"] == nil then B["Summon Echeyakee"] = "Echeyakee Çağır" end
if B["Summon Edana Hatetalon"] == nil then B["Summon Edana Hatetalon"] = "Edana Hatetalon Çağır" end
if B["Summon Emerald Whelpling"] == nil then B["Summon Emerald Whelpling"] = "Zümrüt Ejder Yavrusu Çağır" end
if B["Summon Farm Chicken"] == nil then B["Summon Farm Chicken"] = "Çiftlik Tavuğu Çağır" end
if B["Summon Felhunter"] == nil then B["Summon Felhunter"] = "Felhunter Çağır" end
if B["Summon Ghost Saber"] == nil then B["Summon Ghost Saber"] = "Hayalet Kaplan Çağır" end
if B["Summon Great Horned Owl"] == nil then B["Summon Great Horned Owl"] = "Büyük Boynuzlu Baykuş Çağır" end
if B["Summon Green Qiraji Battle Tank"] == nil then B["Summon Green Qiraji Battle Tank"] = "Yeşil Qiraji Savaş Tankı Çağır" end
if B["Summon Green Wing Macaw"] == nil then B["Summon Green Wing Macaw"] = "Yeşil Kanatlı Ara Papağanı Çağır" end
if B["Summon Gurky"] == nil then B["Summon Gurky"] = "Gurky Çağır" end
if B["Summon Hawk Owl"] == nil then B["Summon Hawk Owl"] = "Atmaca Baykuşu Çağır" end
if B["Summon Hawksbill Snapjaw"] == nil then B["Summon Hawksbill Snapjaw"] = "Hawksbill Snapjaw Çağır" end
if B["Summon Helper"] == nil then B["Summon Helper"] = "Yardımcı Çağır" end
if B["Summon Hippogryph Hatchling"] == nil then B["Summon Hippogryph Hatchling"] = "Hipogrif Yavrusu Çağır" end
if B["Summon Hyacinth Macaw"] == nil then B["Summon Hyacinth Macaw"] = "Sümbül Ara Papağanı Çağır" end
if B["Summon Imp"] == nil then B["Summon Imp"] = "Imp Çağır" end
if B["Summon Ishamuhale"] == nil then B["Summon Ishamuhale"] = "Ishamuhale Çağır" end
if B["Summon Jubling"] == nil then B["Summon Jubling"] = "Jubling Çağır" end
if B["Summon Karang's Banner"] == nil then B["Summon Karang's Banner"] = "Karang'ın Sancağını Çağır" end
if B["Summon Leatherback Snapjaw"] == nil then B["Summon Leatherback Snapjaw"] = "Leatherback Snapjaw Çağır" end
if B["Summon Lifelike Toad"] == nil then B["Summon Lifelike Toad"] = "Canlı Gibi Kurbağa Çağır" end
if B["Summon Loggerhead Snapjaw"] == nil then B["Summon Loggerhead Snapjaw"] = "Loggerhead Snapjaw Çağır" end
if B["Summon Lunaclaw"] == nil then B["Summon Lunaclaw"] = "Lunaclaw Çağır" end
if B["Summon Maine Coon"] == nil then B["Summon Maine Coon"] = "Maine Coon Çağır" end
if B["Summon Mechanical Chicken"] == nil then B["Summon Mechanical Chicken"] = "Mekanik Tavuk Çağır" end
if B["Summon Mechanical Greench"] == nil then B["Summon Mechanical Greench"] = "Mekanik Greench Çağır" end
if B["Summon Mechanical Yeti"] == nil then B["Summon Mechanical Yeti"] = "Mekanik Yeti Çağır" end
if B["Summon Mr. Wiggles"] == nil then B["Summon Mr. Wiggles"] = "Mr. Wiggles Çağır" end
if B["Summon Murki"] == nil then B["Summon Murki"] = "Murki Çağır" end
if B["Summon Murky"] == nil then B["Summon Murky"] = "Murky Çağır" end
if B["Summon Myzrael"] == nil then B["Summon Myzrael"] = "Myzrael Çağır" end
if B["Summon Olive Snapjaw"] == nil then B["Summon Olive Snapjaw"] = "Olive Snapjaw Çağır" end
if B["Summon Orange Tabby"] == nil then B["Summon Orange Tabby"] = "Turuncu Tekir Çağır" end
if B["Summon Orphan"] == nil then B["Summon Orphan"] = "Yetim Çağır" end
if B["Summon Panda"] == nil then B["Summon Panda"] = "Panda Çağır" end
if B["Summon Peddlefeet"] == nil then B["Summon Peddlefeet"] = "Peddlefeet Çağır" end
if B["Summon Poley"] == nil then B["Summon Poley"] = "Poley Çağır" end
if B["Summon Prairie Dog"] == nil then B["Summon Prairie Dog"] = "Çayır Köpeği Çağır" end
if B["Summon RC Tank"] == nil then B["Summon RC Tank"] = "RC Tankı Çağır" end
if B["Summon Razelikh"] == nil then B["Summon Razelikh"] = "Razelikh Çağır" end
if B["Summon Red Qiraji Battle Tank"] == nil then B["Summon Red Qiraji Battle Tank"] = "Kırmızı Qiraji Savaş Tankı Çağır" end
if B["Summon Reindeer"] == nil then B["Summon Reindeer"] = "Ren Geyiği Çağır" end
if B["Summon Riding Gryphon"] == nil then B["Summon Riding Gryphon"] = "Binek Grifon Çağır" end
if B["Summon Robot"] == nil then B["Summon Robot"] = "Robot Çağır" end
if B["Summon Screecher Spirit"] == nil then B["Summon Screecher Spirit"] = "Çığlıkçı Ruhu Çağır" end
if B["Summon Senegal"] == nil then B["Summon Senegal"] = "Senegal Papağanı Çağır" end
if B["Summon Shadowstrike"] == nil then B["Summon Shadowstrike"] = "Shadowstrike Çağır" end
if B["Summon Shy-Rotam"] == nil then B["Summon Shy-Rotam"] = "Shy-Rotam Çağır" end
if B["Summon Siamese"] == nil then B["Summon Siamese"] = "Siyam Kedisi Çağır" end
if B["Summon Silver Tabby"] == nil then B["Summon Silver Tabby"] = "Gümüş Tekir Çağır" end
if B["Summon Skeleton"] == nil then B["Summon Skeleton"] = "İskelet Çağır" end
if B["Summon Smithing Hammer"] == nil then B["Summon Smithing Hammer"] = "Demirci Çekici Çağır" end
if B["Summon Smolderweb"] == nil then B["Summon Smolderweb"] = "Smolderweb Çağır" end
if B["Summon Snowman"] == nil then B["Summon Snowman"] = "Kardan Adam Çağır" end
if B["Summon Snowshoe Rabbit"] == nil then B["Summon Snowshoe Rabbit"] = "Kar Tavşanı Çağır" end
if B["Summon Snufflenose"] == nil then B["Summon Snufflenose"] = "Snufflenose Çağır" end
if B["Summon Speedy"] == nil then B["Summon Speedy"] = "Speedy Çağır" end
if B["Summon Spider God"] == nil then B["Summon Spider God"] = "Örümcek Tanrı Çağır" end
if B["Summon Spirit of Summer"] == nil then B["Summon Spirit of Summer"] = "Yaz Ruhu Çağır" end
if B["Summon Sprite Darter Hatchling"] == nil then B["Summon Sprite Darter Hatchling"] = "Peri Ejderi Yavrusu Çağır" end
if B["Summon Succubus"] == nil then B["Summon Succubus"] = "Succubus Çağır" end
if B["Summon Terky"] == nil then B["Summon Terky"] = "Terky Çağır" end
if B["Summon Thunderstrike"] == nil then B["Summon Thunderstrike"] = "Thunderstrike Çağır" end
if B["Summon Timberling"] == nil then B["Summon Timberling"] = "Timberling Çağır" end
if B["Summon Tiny Green Dragon"] == nil then B["Summon Tiny Green Dragon"] = "Minik Yeşil Ejderha Çağır" end
if B["Summon Tiny Red Dragon"] == nil then B["Summon Tiny Red Dragon"] = "Minik Kırmızı Ejderha Çağır" end
if B["Summon Tracking Hound"] == nil then B["Summon Tracking Hound"] = "İz Süren Tazı Çağır" end
if B["Summon Tranquil Mechanical Yeti"] == nil then B["Summon Tranquil Mechanical Yeti"] = "Sakin Mekanik Yeti Çağır" end
if B["Summon Tree Frog"] == nil then B["Summon Tree Frog"] = "Ağaç Kurbağası Çağır" end
if B["Summon Voidwalker"] == nil then B["Summon Voidwalker"] = "Voidwalker Çağır" end
if B["Summon Whiskers"] == nil then B["Summon Whiskers"] = "Whiskers Çağır" end
if B["Summon White Kitten"] == nil then B["Summon White Kitten"] = "Beyaz Kedi Yavrusu Çağır" end
if B["Summon White Tiger Cub"] == nil then B["Summon White Tiger Cub"] = "Beyaz Kaplan Yavrusu Çağır" end
if B["Summon Wood Frog"] == nil then B["Summon Wood Frog"] = "Orman Kurbağası Çağır" end
if B["Summon Worg Pup"] == nil then B["Summon Worg Pup"] = "Worg Yavrusu Çağır" end
if B["Summon Xorothian Dreadsteed"] == nil then B["Summon Xorothian Dreadsteed"] = "Xoroth Dehşet Atı Çağır" end
if B["Summon Yellow Qiraji Battle Tank"] == nil then B["Summon Yellow Qiraji Battle Tank"] = "Sarı Qiraji Savaş Tankı Çağır" end
if B["Summon Zergling"] == nil then B["Summon Zergling"] = "Zergling Çağır" end
if B["Supreme Power"] == nil then B["Supreme Power"] = "Üstün Güç" end
if B["Sweet Surprise"] == nil then B["Sweet Surprise"] = "Tatlı Sürpriz" end
if B["Swift Blue Raptor"] == nil then B["Swift Blue Raptor"] = "Süratli Mavi Raptor" end
if B["Swift Brown Ram"] == nil then B["Swift Brown Ram"] = "Süratli Kahverengi Koç" end
if B["Swift Brown Steed"] == nil then B["Swift Brown Steed"] = "Süratli Kahverengi At" end
if B["Swift Brown Wolf"] == nil then B["Swift Brown Wolf"] = "Süratli Kahverengi Kurt" end
if B["Swift Dawnsaber"] == nil then B["Swift Dawnsaber"] = "Süratli Dawnsaber" end
if B["Swift Frostsaber"] == nil then B["Swift Frostsaber"] = "Süratli Frostsaber" end
if B["Swift Gray Ram"] == nil then B["Swift Gray Ram"] = "Süratli Gri Koç" end
if B["Swift Gray Wolf"] == nil then B["Swift Gray Wolf"] = "Süratli Gri Kurt" end
if B["Swift Green Mechanostrider"] == nil then B["Swift Green Mechanostrider"] = "Süratli Yeşil Mechanostrider" end
if B["Swift Mistsaber"] == nil then B["Swift Mistsaber"] = "Süratli Mistsaber" end
if B["Swift Olive Raptor"] == nil then B["Swift Olive Raptor"] = "Süratli Zeytin Yeşili Raptor" end
if B["Swift Orange Raptor"] == nil then B["Swift Orange Raptor"] = "Süratli Turuncu Raptor" end
if B["Swift Palomino"] == nil then B["Swift Palomino"] = "Süratli Palomino" end
if B["Swift Stormsaber"] == nil then B["Swift Stormsaber"] = "Süratli Stormsaber" end
if B["Swift Timber Wolf"] == nil then B["Swift Timber Wolf"] = "Süratli Orman Kurdu" end
if B["Swift White Mechanostrider"] == nil then B["Swift White Mechanostrider"] = "Süratli Beyaz Mechanostrider" end
if B["Swift White Ram"] == nil then B["Swift White Ram"] = "Süratli Beyaz Koç" end
if B["Swift White Steed"] == nil then B["Swift White Steed"] = "Süratli Beyaz At" end
if B["Swift Yellow Mechanostrider"] == nil then B["Swift Yellow Mechanostrider"] = "Süratli Sarı Mechanostrider" end
if B["Swift Zulian Tiger"] == nil then B["Swift Zulian Tiger"] = "Süratli Zulian Kaplanı" end
if B["Swiftness of Zanza"] == nil then B["Swiftness of Zanza"] = "Zanza'nın Sürati" end
if B["Swim Speed"] == nil then B["Swim Speed"] = "Yüzme Hızı" end
if B["Swimming Speed"] == nil then B["Swimming Speed"] = "Yüzme Hızı" end
if B["Symbol of Life"] == nil then B["Symbol of Life"] = "Yaşam Sembolü" end
if B["Syncretist's Sigil"] == nil then B["Syncretist's Sigil"] = "Bağdaştırıcının Mührü" end
if B["Syndicate Disguise"] == nil then B["Syndicate Disguise"] = "Syndicate Kılığı" end
if B["Taint of Shadow"] == nil then B["Taint of Shadow"] = "Gölge Lekesi" end
if B["Tainted Blood"] == nil then B["Tainted Blood"] = "Bozulmuş Kan" end
if B["Taking Moon Well Sample"] == nil then B["Taking Moon Well Sample"] = "Ay Kuyusu Örneği Alma" end
if B["Talisman of Binding"] == nil then B["Talisman of Binding"] = "Bağlama Tılsımı" end
if B["Tame Adult Plainstrider"] == nil then B["Tame Adult Plainstrider"] = "Yetişkin Ova Koşarkuşu Evcilleştir" end
if B["Tame Armored Scorpid"] == nil then B["Tame Armored Scorpid"] = "Zırhlı Scorpid Evcilleştir" end
if B["Tame Dire Mottled Boar"] == nil then B["Tame Dire Mottled Boar"] = "Korkunç Benekli Yaban Domuzu Evcilleştir" end
if B["Tame Ice Claw Bear"] == nil then B["Tame Ice Claw Bear"] = "Buz Pençeli Ayı Evcilleştir" end
if B["Tame Large Crag Boar"] == nil then B["Tame Large Crag Boar"] = "Büyük Kayalık Yaban Domuzu Evcilleştir" end
if B["Tame Nightsaber Stalker"] == nil then B["Tame Nightsaber Stalker"] = "Nightsaber Sinsi Avcısı Evcilleştir" end
if B["Tame Prairie Stalker"] == nil then B["Tame Prairie Stalker"] = "Çayır Sinsi Avcısı Evcilleştir" end
if B["Tame Snow Leopard"] == nil then B["Tame Snow Leopard"] = "Kar Leoparı Evcilleştir" end
if B["Tame Strigid Screecher"] == nil then B["Tame Strigid Screecher"] = "Strigid Çığlıkçı Evcilleştir" end
if B["Tame Surf Crawler"] == nil then B["Tame Surf Crawler"] = "Dalga Yengeci Evcilleştir" end
if B["Tame Swoop"] == nil then B["Tame Swoop"] = "Swoop Evcilleştir" end
if B["Tame Webwood Lurker"] == nil then B["Tame Webwood Lurker"] = "Webwood Pusucusu Evcilleştir" end
if B["Tasty Summer Treat"] == nil then B["Tasty Summer Treat"] = "Lezzetli Yaz İkramı" end
if B["Taunt"] == nil then B["Taunt"] = "Kışkırt" end
if B["Tawny Sabercat"] == nil then B["Tawny Sabercat"] = "Kumral Kılıç Dişli Kedi" end
if B["Tea with Sugar"] == nil then B["Tea with Sugar"] = "Şekerli Çay" end
if B["Teal Kodo"] == nil then B["Teal Kodo"] = "Camgöbeği Kodo" end
if B["Temperature Reading"] == nil then B["Temperature Reading"] = "Sıcaklık Ölçümü" end
if B["Tentacle Call"] == nil then B["Tentacle Call"] = "Dokunaç Çağrısı" end
if B["Thaumaturgy Channel"] == nil then B["Thaumaturgy Channel"] = "Taumaturji Kanalı" end
if B["The Big One"] == nil then B["The Big One"] = "Büyük Olan" end
if B["The Breaking"] == nil then B["The Breaking"] = "Kırılış" end
if B["The Burrower's Shell"] == nil then B["The Burrower's Shell"] = "Oyucunun Kabuğu" end
if B["The Eye of Diminution"] == nil then B["The Eye of Diminution"] = "Küçülme Gözü" end
if B["The Eye of the Dead"] == nil then B["The Eye of the Dead"] = "Ölülerin Gözü" end
if B["The Forming"] == nil then B["The Forming"] = "Biçimleniş" end
if B["The Green Tower"] == nil then B["The Green Tower"] = "Yeşil Kule" end
if B["The Lion Horn of Stormwind"] == nil then B["The Lion Horn of Stormwind"] = "Stormwind'in Aslan Borusu" end
if B["Thorium Grenade"] == nil then B["Thorium Grenade"] = "Toryum El Bombası" end
if B["Thorium Shield Spike"] == nil then B["Thorium Shield Spike"] = "Toryum Kalkan Dikeni" end
if B["Thorns Dmg +3"] == nil then B["Thorns Dmg +3"] = "Diken Hasarı +3" end
if B["Thrash"] == nil then B["Thrash"] = "Hırpalama" end
if B["Throw Cupid's Dart"] == nil then B["Throw Cupid's Dart"] = "Aşk Okunu Fırlat" end
if B["Throw Dark Iron Ale"] == nil then B["Throw Dark Iron Ale"] = "Kara Demir Birası Fırlat" end
if B["Throw Rock"] == nil then B["Throw Rock"] = "Taş Fırlat" end
if B["Thunder Bluff Gift of Friendship"] == nil then B["Thunder Bluff Gift of Friendship"] = "Thunder Bluff Dostluk Hediyesi" end
if B["Thunderbolt"] == nil then B["Thunderbolt"] = "Yıldırım" end
if B["Thunderbrew Lager"] == nil then B["Thunderbrew Lager"] = "Thunderbrew Lager Birası" end
if B["Thunderclap"] == nil then B["Thunderclap"] = "Gök Gürültüsü" end
if B["Tidal Charm"] == nil then B["Tidal Charm"] = "Gelgit Tılsımı" end
if B["Tiger"] == nil then B["Tiger"] = "Kaplan" end
if B["Toast"] == nil then B["Toast"] = "Kadeh Kaldır" end
if B["Toast Smorc"] == nil then B["Toast Smorc"] = "Smorc Kızart" end
if B["Toasted Smorc"] == nil then B["Toasted Smorc"] = "Kızarmış Smorc" end
if B["Top Piece of Lord Valthalak's Amulet"] == nil then B["Top Piece of Lord Valthalak's Amulet"] = "Lord Valthalak'ın Muskasının Üst Parçası" end
if B["Torment"] == nil then B["Torment"] = "Eziyet" end
if B["Toss Fuel on Bonfire"] == nil then B["Toss Fuel on Bonfire"] = "Şenlik Ateşine Yakıt At" end
if B["Toss Stink Bomb"] == nil then B["Toss Stink Bomb"] = "Pis Koku Bombası At" end
if B["Touch of Zanzil Cure"] == nil then B["Touch of Zanzil Cure"] = "Zanzil'in Dokunuşu Tedavisi" end
if B["Tranquilizing Shot"] == nil then B["Tranquilizing Shot"] = "Sakinleştirici Atış" end
if B["Transform to Dancer"] == nil then B["Transform to Dancer"] = "Dansçıya Dönüş" end
if B["Transmogrify!"] == nil then B["Transmogrify!"] = "Dönüştür!" end
if B["Trap"] == nil then B["Trap"] = "Tuzak" end
if B["Triage"] == nil then B["Triage"] = "Triyaj" end
if B["Trogg Ale"] == nil then B["Trogg Ale"] = "Trogg Birası" end
if B["Truesilver Skeleton Key"] == nil then B["Truesilver Skeleton Key"] = "Gerçek Gümüş Maymuncuk" end
if B["Turquoise Raptor"] == nil then B["Turquoise Raptor"] = "Turkuaz Raptor" end
if B["Twilight Cultist Disguise"] == nil then B["Twilight Cultist Disguise"] = "Alacakaranlık Tarikatçısı Kılığı" end
if B["Uldaman Key Staff"] == nil then B["Uldaman Key Staff"] = "Uldaman Anahtar Asası" end
if B["Undead Slayer 30"] == nil then B["Undead Slayer 30"] = "Ölümsüz Avcısı 30" end
if B["Undead Slayer 45"] == nil then B["Undead Slayer 45"] = "Ölümsüz Avcısı 45" end
if B["Undead Slayer 60"] == nil then B["Undead Slayer 60"] = "Ölümsüz Avcısı 60" end
if B["Undead Slayer 66"] == nil then B["Undead Slayer 66"] = "Ölümsüz Avcısı 66" end
if B["Undead Slayer 81"] == nil then B["Undead Slayer 81"] = "Ölümsüz Avcısı 81" end
if B["Undercity Gift of Friendship"] == nil then B["Undercity Gift of Friendship"] = "Undercity Dostluk Hediyesi" end
if B["Undo Crowd Control Rogue"] == nil then B["Undo Crowd Control Rogue"] = "Kalabalık Kontrolünü Kaldır (Haydut)" end
if B["Undying Strength"] == nil then B["Undying Strength"] = "Ölmeyen Güç" end
if B["Unholy Aura"] == nil then B["Unholy Aura"] = "Kutsal Olmayan Aura" end
if B["Universal Remote"] == nil then B["Universal Remote"] = "Evrensel Kumanda" end
if B["Unlock Maury's Foot"] == nil then B["Unlock Maury's Foot"] = "Maury'nin Ayağının Kilidini Aç" end
if B["Unlocking"] == nil then B["Unlocking"] = "Kilit Açma" end
if B["Unpainted Mechanostrider"] == nil then B["Unpainted Mechanostrider"] = "Boyanmamış Mechanostrider" end
if B["Unstable Power"] == nil then B["Unstable Power"] = "Dengesiz Güç" end
if B["Untamed Fury"] == nil then B["Untamed Fury"] = "Dizginlenmemiş Öfke" end
if B["Unyielding Will"] == nil then B["Unyielding Will"] = "Boyun Eğmez İrade" end
if B["Use Bauble"] == nil then B["Use Bauble"] = "Süsü Kullan" end
if B["Uther's Light"] == nil then B["Uther's Light"] = "Uther'in Işığı" end
if B["Uther's Tribute"] == nil then B["Uther's Tribute"] = "Uther'e Saygı" end
if B["Venom Shot"] == nil then B["Venom Shot"] = "Zehir Atışı" end
if B["Venomous Totem"] == nil then B["Venomous Totem"] = "Zehirli Totem" end
if B["Very Berry Cream"] == nil then B["Very Berry Cream"] = "Bol Meyveli Krema" end
if B["Violet Raptor"] == nil then B["Violet Raptor"] = "Eflatun Raptor" end
if B["Visions of the Past"] == nil then B["Visions of the Past"] = "Geçmişin Görüntüleri" end
if B["Vitality"] == nil then B["Vitality"] = "Canlılık" end
if B["Vodouisant's Vigilant Embrace"] == nil then B["Vodouisant's Vigilant Embrace"] = "Vodouisant'ın Uyanık Kucağı" end
if B["Voodoo Hex"] == nil then B["Voodoo Hex"] = "Vudu Laneti" end
if B["Wail of the Banshee"] == nil then B["Wail of the Banshee"] = "Banshee'nin Feryadı" end
if B["Warlord Deck"] == nil then B["Warlord Deck"] = "Savaş Lordu Destesi" end
if B["Warsong Gulch Enriched Ration"] == nil then B["Warsong Gulch Enriched Ration"] = "Warsong Gulch Zenginleştirilmiş Erzakı" end
if B["Warsong Gulch Field Ration"] == nil then B["Warsong Gulch Field Ration"] = "Warsong Gulch Sahra Erzakı" end
if B["Warsong Gulch Iron Ration"] == nil then B["Warsong Gulch Iron Ration"] = "Warsong Gulch Dayanıklı Erzakı" end
if B["Water Elemental"] == nil then B["Water Elemental"] = "Su Elementali" end
if B["Water Sample"] == nil then B["Water Sample"] = "Su Örneği" end
if B["Watered-down Beer"] == nil then B["Watered-down Beer"] = "Sulandırılmış Bira" end
if B["Weak Alcohol"] == nil then B["Weak Alcohol"] = "Zayıf Alkol" end
if B["Weakening Disease"] == nil then B["Weakening Disease"] = "Zayıflatıcı Hastalık" end
if B["Weapon Chain"] == nil then B["Weapon Chain"] = "Silah Zinciri" end
if B["Weapon Counterweight"] == nil then B["Weapon Counterweight"] = "Silah Karşı Ağırlığı" end
if B["Weapon Damage 04"] == nil then B["Weapon Damage 04"] = "Silah Hasarı 04" end
if B["Whipper Root Tuber"] == nil then B["Whipper Root Tuber"] = "Whipper Kökü Yumrusu" end
if B["White Firework Cluster"] == nil then B["White Firework Cluster"] = "Beyaz Havai Fişek Demeti" end
if B["White Mechanostrider"] == nil then B["White Mechanostrider"] = "Beyaz Mechanostrider" end
if B["White Ram"] == nil then B["White Ram"] = "Beyaz Koç" end
if B["White Stallion"] == nil then B["White Stallion"] = "Beyaz Aygır" end
if B["Wildvine Potion"] == nil then B["Wildvine Potion"] = "Yabani Sarmaşık İksiri" end
if B["Windblossom Berries"] == nil then B["Windblossom Berries"] = "Rüzgâr Çiçeği Meyveleri" end
if B["Windreaper"] == nil then B["Windreaper"] = "Rüzgâr Biçen" end
if B["Winter Wolf"] == nil then B["Winter Wolf"] = "Kış Kurdu" end
if B["Winterfall Firewater"] == nil then B["Winterfall Firewater"] = "Winterfall Ateş Suyu" end
if B["Wisp Costume"] == nil then B["Wisp Costume"] = "Wisp Kostümü" end
if B["Wizard Oil"] == nil then B["Wizard Oil"] = "Büyücü Yağı" end
if B["Wolfshead Helm"] == nil then B["Wolfshead Helm"] = "Kurt Başı Miğferi" end
if B["Word of Thawing"] == nil then B["Word of Thawing"] = "Çözülme Sözü" end
if B["World Enlarger"] == nil then B["World Enlarger"] = "Dünya Büyüteci" end
if B["Wound"] == nil then B["Wound"] = "Yara" end
if B["Xiggs Signal Flare"] == nil then B["Xiggs Signal Flare"] = "Xiggs İşaret Fişeği" end
if B["Yellow Firework Cluster"] == nil then B["Yellow Firework Cluster"] = "Sarı Havai Fişek Demeti" end
if B["Yellow Rose Firework"] == nil then B["Yellow Rose Firework"] = "Sarı Gül Havai Fişeği" end
if B["Yenniku's Release"] == nil then B["Yenniku's Release"] = "Yenniku'nun Serbest Bırakılması" end
if B["Zandalar Signet of Might"] == nil then B["Zandalar Signet of Might"] = "Zandalar Kudret Mührü" end
if B["Zandalar Signet of Mojo"] == nil then B["Zandalar Signet of Mojo"] = "Zandalar Mojo Mührü" end
if B["Zandalar Signet of Serenity"] == nil then B["Zandalar Signet of Serenity"] = "Zandalar Dinginlik Mührü" end
if B["Zeal"] == nil then B["Zeal"] = "Gayret" end
if B["Zulian Slice"] == nil then B["Zulian Slice"] = "Zulian Dilimi" end
