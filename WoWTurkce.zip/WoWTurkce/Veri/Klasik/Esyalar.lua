if WoWTurkce.RETAIL or WoWTurkce.FOREVER then return end -- yalnızca Classic Era
-- Eşya ipucu satırları, eşya adları ve eşya numaraları
local G = WoWTurkce
do local function _()
local T = G.Esya
T["Teaches you how to craft Winter Boots."] = "Winter Boots üretmeyi öğretir."
T["Teaches you how to make a Mageblood Elixir."] = "Mageblood Elixir yapmayı öğretir."
T["Teaches you how to make a Major Troll's Blood Elixir."] = "Major Troll's Blood Elixir yapmayı öğretir."
T["Teaches you how to sew Green Winter Clothes."] = "Green Winter Clothes dikmeyi öğretir."
T["Teaches you how to sew Red Winter Clothes."] = "Red Winter Clothes dikmeyi öğretir."
T["Teaches you how to summon this mount."] = "Bu bineği çağırmayı öğretir."
local T = G.EsyaAdi
T["Biornskin Moccasins"] = "Biorn Derisi Mokasenler"
T["Coral-Edge Band"] = "Mercan Kenarlı Yüzük"
T["Faulty Countermeasure"] = "Kusurlu Karşı Önlem"
T["Glaivemaster's Studded Grips"] = "Glaive Ustasının Çivili Eldivenleri"
T["Loot-A-Rang"] = "Ganimet-A-Rang"
T["Nightborne Noble's Cloak"] = "Nightborne Asilzadesinin Pelerini"
T["Shen'dorei Windwell"] = "Shen'dorei Rüzgâr Kuyusu"
T["Swordsinger's Shoulders"] = "Kılıç Ozanının Omuzlukları"
T["Twinblades of the Deceiver"] = "Aldatıcının İkiz Kılıçları"
T["Valor-Bound Legwraps"] = "Cesarete Bağlı Bacak Sargıları"
T["Vest of Rupturing Diamonds"] = "Parçalanan Elmasların Yeleği"
T["Wristwraps of the Shattered Abyss"] = "Parçalanmış Uçurumun Bileklikleri"
end _() end
