local mod	= DBM:NewMod("AtrexistheGraveKnight", "DBM-Party-Forever", 4)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20261107034458")
mod:EnableGenericTrash()
--mod:SetCreatureID(11517)
mod:SetEncounterID(3311)
mod:SetModelID(145787)
mod:SetZone(2959)

mod:RegisterCombat("combat")

--mod:AddAuraSoundOption(123456, true, 123456, 1, 1, "targetyou", 2, 0)
