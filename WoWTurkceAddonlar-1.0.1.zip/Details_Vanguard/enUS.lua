local Loc = LibStub("AceLocale-3.0"):NewLocale("Details_Vanguard", "enUS", true) 

if (not Loc) then
	return 
end 

Loc ["STRING_PLUGIN_NAME"] = "Vanguard"
Loc ["STRING_HEALVSDAMAGETOOLTIP"] = "Gelen iyileştirme, sonraki saniyelerde beklenen iyileştirme miktarıdır.\nGelen hasar, Vanguard tarafından son saniyelerde alınan\nortalama hasarla hesaplanır.\n\n|cff33CC00*Daha fazla bilgi için tıklayın."
Loc ["STRING_AVOIDVSHITSTOOLTIP"] = "Bu, son birkaç saniyede alınan başarılı vuruşlara\nkarşı kaçınma ve savuşturma miktarıdır.\n\n|cff33CC00*Daha fazla bilgi için tıklayın."
Loc ["STRING_DAMAGESCROLL"] = "En son alınan hasar miktarı."
Loc ["STRING_REPORT"] = "Details Vanguard Raporu"
Loc ["STRING_REPORT_AVOIDANCE"] = "Kaçınma istatistiği:"
Loc ["STRING_REPORT_AVOIDANCE_TOOLTIP"] = "Kaçınma raporu gönder"

Loc ["STRING_HEALRECEIVED"] = "Alınan İyileştirme"
Loc ["STRING_HPS"] = "RHPS"
Loc ["STRING_HITS"] = "Alınan Vuruşlar"
Loc ["STRING_DODGE"] = "Kaçınma"
Loc ["STRING_PARRY"] = "Savuşturma"
Loc ["STRING_DAMAGETAKEN"] = "Alınan Hasar"
Loc ["STRING_DTPS"] = "DTPS"
Loc ["STRING_DEBUFF"] = "Zayıflatma"
Loc ["STRING_DURATION"] = "Süre"
