-- Zindan ve Raid adları İngilizce kalır (kullanıcı tercihi). Çeviri eklemek için z(en, tr) kullan.
local Z = {}
WoWTurkce.ZindanAdi = Z
local function z(en, tr, the)
	Z[en] = tr
	if the ~= false then Z["The " .. en] = tr end
end
