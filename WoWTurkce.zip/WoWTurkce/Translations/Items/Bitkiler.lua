-- Bitki adları: Türkçe ad; eşya ipucunda orijinal İngilizce ad gri olarak yanında görünür.
-- Toplanabilir bitki nesnelerinde (haritadaki bitkiler) orijinal ad parantez içinde yazılır.
local E, N, A = WoWTurkce.EsyaAdi, WoWTurkce.Nesne, WoWTurkce.Arayuz
local B = {
	["Peacebloom"] = "Barış Çiçeği", ["Silverleaf"] = "Gümüş Yaprak", ["Earthroot"] = "Toprak Kökü",
	["Mageroyal"] = "Asil Büyü Otu", ["Briarthorn"] = "Böğürtlen Dikeni", ["Stranglekelp"] = "Boğan Yosun",
	["Bruiseweed"] = "Bere Otu", ["Wild Steelbloom"] = "Yabani Çelik Çiçeği", ["Grave Moss"] = "Mezar Yosunu",
	["Kingsblood"] = "Kral Kanı", ["Liferoot"] = "Yaşam Kökü", ["Fadeleaf"] = "Solgun Yaprak",
	["Goldthorn"] = "Altın Diken", ["Khadgar's Whisker"] = "Khadgar'ın Bıyığı", ["Wintersbite"] = "Kış Isırığı",
	["Firebloom"] = "Ateş Çiçeği", ["Purple Lotus"] = "Mor Lotus", ["Arthas' Tears"] = "Arthas'ın Gözyaşları",
	["Sungrass"] = "Güneş Otu", ["Blindweed"] = "Kör Ot", ["Ghost Mushroom"] = "Hayalet Mantarı",
	["Gromsblood"] = "Grom Kanı", ["Golden Sansam"] = "Altın Sansam", ["Dreamfoil"] = "Rüya Yaprağı",
	["Mountain Silversage"] = "Dağ Gümüş Adaçayı", ["Plaguebloom"] = "Veba Çiçeği", ["Icecap"] = "Buz Başlığı",
	["Black Lotus"] = "Kara Lotus", ["Swiftthistle"] = "Çevik Devedikeni", ["Wildvine"] = "Yabani Asma",
	["Bloodthistle"] = "Kan Dikeni", ["Blood Scythe"] = "Kan Tırpanı",
}
for en, tr in pairs(B) do
	E[en] = tr
	local n = tr .. " (" .. en .. ")"
	N[en] = n
	A[en] = n
end
