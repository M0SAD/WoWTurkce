-- Meslek rütbe büyüleri (eğitmen listesi): "Apprentice Skinning" -> "Deri Yüzme (Çırak)"
local A = WoWTurkce.BuyuAdi
local MESLEK = {
	Alchemy = "Simya", Blacksmithing = "Demircilik", Enchanting = "Efsunculuk", Engineering = "Mühendislik",
	Herbalism = "Bitkicilik", Leatherworking = "Dericilik", Mining = "Madencilik", Skinning = "Deri Yüzme",
	Tailoring = "Terzilik", Cooking = "Aşçılık", ["First Aid"] = "İlk Yardım", Fishing = "Balıkçılık",
	Jewelcrafting = "Kuyumculuk", Inscription = "Yazıtçılık", Riding = "Binicilik", Lockpicking = "Kilit Açma",
}
local RUTBE = {
	Apprentice = "Çırak", Journeyman = "Kalfa", Expert = "Uzman", Artisan = "Usta", Master = "Üstat",
	["Grand Master"] = "Büyük Üstat", Illustrious = "Ünlü",
}
for men, mtr in pairs(MESLEK) do
	if A[men] == nil then A[men] = mtr end
	for ren, rtr in pairs(RUTBE) do
		local k = ren .. " " .. men
		if A[k] == nil then A[k] = mtr .. " (" .. rtr .. ")" end
	end
end

-- Meslek tarifleri ve uzmanlıklar (meslek penceresindeki adlar)
local function ek(en, tr) if A[en] == nil then A[en] = tr end end
for en, tr in pairs({
	["Smelt Copper"] = "Bakır Erit", ["Smelt Tin"] = "Kalay Erit", ["Smelt Bronze"] = "Bronz Erit", ["Smelt Silver"] = "Gümüş Erit",
	["Smelt Iron"] = "Demir Erit", ["Smelt Gold"] = "Altın Erit", ["Smelt Steel"] = "Çelik Erit", ["Smelt Mithril"] = "Mithril Erit",
	["Smelt Truesilver"] = "Gerçekgümüş Erit", ["Smelt Thorium"] = "Toryum Erit", ["Smelt Dark Iron"] = "Dark Iron Erit",
	["Smelt Elementium"] = "Elementium Erit",
	["Transmute: Arcanite"] = "Dönüştür: Arcanite", ["Transmute: Iron to Gold"] = "Dönüştür: Demirden Altına",
	["Transmute: Mithril to Truesilver"] = "Dönüştür: Mithrilden Gerçekgümüşe", ["Transmute: Air to Fire"] = "Dönüştür: Havadan Ateşe",
	["Transmute: Fire to Earth"] = "Dönüştür: Ateşten Toprağa", ["Transmute: Earth to Water"] = "Dönüştür: Topraktan Suya",
	["Transmute: Water to Air"] = "Dönüştür: Sudan Havaya", ["Transmute: Earth to Life"] = "Dönüştür: Topraktan Yaşama",
	["Transmute: Life to Earth"] = "Dönüştür: Yaşamdan Toprağa", ["Transmute: Undeath to Water"] = "Dönüştür: Ölümsüzlükten Suya",
	["Transmute: Water to Undeath"] = "Dönüştür: Sudan Ölümsüzlüğe", ["Transmute: Elemental Fire"] = "Dönüştür: Element Ateşi",
	["Philosophers' Stone"] = "Felsefe Taşı", ["Alchemist's Stone"] = "Simyacı Taşı", ["Elixir of Waterwalking"] = "Su Üstünde Yürüme Eliksiri",
	["Elixir of Tongues"] = "Diller Eliksiri", ["Goblin Rocket Fuel Recipe"] = "Goblin Roket Yakıtı Tarifi",
	["Enchant Bracer - Minor Health"] = "Bilezik Büyüsü - Küçük Can",
	["Enchant Chest - Minor Health"] = "Göğüs Büyüsü - Küçük Can", ["Enchant Chest - Lesser Health"] = "Göğüs Büyüsü - Hafif Can",
	["Enchant Chest - Health"] = "Göğüs Büyüsü - Can", ["Enchant Chest - Greater Health"] = "Göğüs Büyüsü - Büyük Can",
	["Enchant Chest - Superior Health"] = "Göğüs Büyüsü - Üstün Can", ["Enchant Chest - Major Health"] = "Göğüs Büyüsü - Yüce Can",
	["Enchant Chest - Minor Mana"] = "Göğüs Büyüsü - Küçük Mana", ["Enchant Chest - Lesser Mana"] = "Göğüs Büyüsü - Hafif Mana",
	["Enchant Chest - Mana"] = "Göğüs Büyüsü - Mana", ["Enchant Chest - Greater Mana"] = "Göğüs Büyüsü - Büyük Mana",
	["Enchant Chest - Superior Mana"] = "Göğüs Büyüsü - Üstün Mana", ["Enchant Chest - Major Mana"] = "Göğüs Büyüsü - Yüce Mana",
	["Enchant  Weapon - Healing Power"] = "Silah Büyüsü - İyileştirme Gücü", ["Enchant Weapon - Healing Power"] = "Silah Büyüsü - İyileştirme Gücü",
	["Enchant  Weapon - Spell Power"] = "Silah Büyüsü - Büyü Gücü", ["Enchant Weapon - Spell Power"] = "Silah Büyüsü - Büyü Gücü",
	["Enchanted Thorium"] = "Efsunlu Toryum",
	["Armorsmith"] = "Zırh Ustası", ["Weaponsmith"] = "Silah Ustası", ["Master Axesmith"] = "Usta Balta Demircisi",
	["Master Hammersmith"] = "Usta Çekiç Demircisi", ["Master Swordsmith"] = "Usta Kılıç Demircisi",
	["Dragonscale Leatherworking"] = "Ejderha Pulu Dericiliği", ["Elemental Leatherworking"] = "Element Dericiliği",
	["Tribal Leatherworking"] = "Kabile Dericiliği", ["Gnomish Engineer"] = "Gnome Mühendisi", ["Goblin Engineer"] = "Goblin Mühendisi",
	["Herb Gathering"] = "Bitki Toplama", ["Fishing Poles"] = "Olta",
	["Alarm-O-Bot"] = "Alarm-O-Bot", ["Battle Chicken"] = "Savaş Tavuğu", ["EZ-Thro Dynamite"] = "Kolay Atılan Dinamit",
	["EZ-Thro Dynamite II"] = "Kolay Atılan Dinamit II", ["Firework Cluster Launcher"] = "Havai Fişek Salvo Atar",
	["Summon Goblin Bomb"] = "Goblin Bombası Çağır", ["The Mortar: Reloaded"] = "Havan Topu: Yeniden Dolduruldu",
	["Ultrasafe Transporter - Gadgetzan"] = "Süper Güvenli Işınlayıcı - Gadgetzan", ["Inlaid Mithril Cylinder Plans"] = "İşlemeli Mithril Silindir Planı",
	["Dazzling Mithril Rapier"] = "Göz Kamaştırıcı Mithril Meç", ["Ornate Mithril Shoulders"] = "Süslü Mithril Omuzluk",
	["Heavy Scorpid Gauntlets"] = "Ağır Scorpid Eldivenleri", ["Festive Red Dress"] = "Şenlikli Kırmızı Elbise",
	["Festive Red Pant Suit"] = "Şenlikli Kırmızı Pantolon Takımı", ["Mithril Headed Trout"] = "Mithril Kafalı Alabalık",
	["Monster Omelet"] = "Canavar Omlet",
}) do ek(en, tr) end
