-- WoWTurkce: Zindan Rehberi icerigi Turkce (Ingilizce istemcide gosterilir)
local ADDON_NAME, FDJ = ...
FDJ = FDJ or _G.ForeverDungeonJournal_NS
FDJ.ContentLocales = FDJ.ContentLocales or {}
local T = {}
FDJ.ContentLocales.enUS = T
T.dungeons = {
}
T.quests = {
    [-96901] = { ["name"] = "Coldbringer'ın Gözü", ["objective"] = "Coldbringer'ın Gözü'nü Razorfen Downs'tan geri al." },
    [-96902] = { ["name"] = "Cadı Doktorun Kafası", ["objective"] = "Witch Doctor Zum'rah'ı öldür ve Zum'rah'ın Kafası'nı Dalaran'daki Archmage Lan'dalock'a getir." },
    [-96903] = { ["objective"] = "Varian Wrynn'in akıbetiyle ilgili haberi Orgrimmar'daki Thrall'a götür.", ["pickup"] = "Commander Folkar, Alcaz Prison içinde", ["turnin"] = "Thrall, Valley of Wisdom, Orgrimmar (32.0, 37.8)" },
    [-96904] = { ["objective"] = "Alcaz Prison içinde Commander Folkar'ı bul.", ["pickup"] = "Sergeant Ulka, Alcaz Prison'ın dışında, Dustwallow Marsh (70.4, 19.0)", ["turnin"] = "Commander Folkar, Alcaz Prison içinde" },
    [-96905] = { ["objective"] = "Alcaz Prison'da King Varian Wrynn'i ara.", ["pickup"] = "Commander Folkar, Alcaz Prison içinde", ["turnin"] = "Parfümlü Not, Blazeroar'dan sonra, Alcaz Prison içinde" },
    [-96906] = { ["objective"] = "Alcaz Prison'a gir ve oradaki insan muhafızlardan 8 Kan Kırmızısı Bandana topla.", ["pickup"] = "Henüz bilinmiyor (muhtemelen Alcaz Prison'daki Kor'kron'dan Sergeant Ulka veya Commander Folkar)" },
    [-96907] = { ["note"] = "Görev veren henüz bilinmiyor. Bir Horde oyuncusu tarafından görüldü; Alliance'ın da alıp almadığı henüz bilinmiyor.", ["objective"] = "Alcaz Prison'da 15 Strashaz Soldier ve 8 Strashaz Enchantress öldür ve Ca'zass'ın Kafası'nı getir.", ["pickup"] = "Henüz bilinmiyor", ["turnin"] = "Henüz bilinmiyor" },
    [-96908] = { ["name"] = "Folkar İçin Kötü Haber", ["objective"] = "Commander Folkar'a bulduklarını anlat.", ["pickup"] = "Parfümlü Not, Blazeroar'dan sonra, Alcaz Prison içinde", ["turnin"] = "Commander Folkar, Alcaz Prison içinde" },
    [1013] = { ["name"] = "Ur'un Kitabı", ["objective"] = "Ur'un Kitabı'nı Undercity'deki Apothecarium'da bulunan Muhafız Bel'dugur'a getir." },
    [1014] = { ["name"] = "Arugal Ölmeli", ["note"] = "Güncel Forever görev verisi ödül olarak öğrenilen Arcane Intellect'i de listeliyor.", ["objective"] = "Arugal'ı öldür ve kellesini Sepulcher'daki Dalar Dawnweaver'a getir." },
    [1048] = { ["name"] = "Scarlet Monastery'ye", ["note"] = "Herod Armory'de; Loksey Library'de; Mograine ve Whitemane Cathedral'da.", ["objective"] = "Yüce Engizitör Whitemane'i, Kızıl Komutan Mograine'i, Kızıl Şampiyon Herod'u ve Tazı Ustası Loksey'i öldür, ardından Undercity'deki Varimathras'a rapor ver." },
    [1049] = { ["name"] = "Düşmüşlerin Derlemesi", ["objective"] = "Tirisfal Glades'teki Manastır'dan Düşmüşlerin Derlemesi'ni al ve Thunder Bluff'taki Bilge Truthseeker'a dön.", ["warning"] = "Undead'ler bu görevi alamaz" },
    [1050] = { ["name"] = "Titanların Mitolojisi", ["objective"] = "Manastır'dan Titanların Mitolojisi'ni al ve Ironforge'daki Kütüphaneci Mae Paledust'a getir." },
    [1051] = { ["name"] = "Vorrel'in İntikamı", ["objective"] = "Vorrel Sengutz'un alyansını Tarren Mill'deki Monika Sengutz'a geri götür.", ["pickup"] = "Vorrel Sengutz, Graveyard içinde" },
    [1052] = { ["name"] = "Kızıl Yol", ["objective"] = "Brother Anton'un Takdir Mektubunu Southshore'daki Dindar Raleigh'e götür." },
    [1053] = { ["name"] = "Işık Adına", ["note"] = "Herod Armory'de; Loksey Library'de; Mograine ve Whitemane Cathedral'da.\n\nİsteğe bağlı giriş görevi:", ["objective"] = "Yüce Engizitör Whitemane'i, Kızıl Komutan Mograine'i, Kızıl Şampiyon Herod'u ve Tazı Ustası Loksey'i öldür, ardından Southshore'daki Dindar Raleigh'e rapor ver." },
    [1098] = { ["name"] = "Shadowfang'deki Ölüm Avcıları", ["objective"] = "Ölüm Avcısı Adamant ile Ölüm Avcısı Vincent'ı bul.", ["turnin"] = "Deathstalker Vincent, Shadowfang Keep içinde" },
    [1100] = { ["description"] = "The Crone of the Kraul öncesi gerekli.", ["name"] = "Lonebrow'un Günlüğü", ["objective"] = "Henrig Lonebrow'un Günlüğünü oku.", ["pickup"] = "Henrig Lonebrow'un Günlüğü, Great Lift'in dibinde cesedinin yanında" },
    [1101] = { ["name"] = "Kraul'un Cadısı", ["objective"] = "Razorflank'in Madalyonu'nu Thalanaar'daki Falfindel Waywarder'a getir." },
    [1102] = { ["name"] = "İntikamcı Bir Kader", ["objective"] = "Razorflank'in Kalbi'ni Thunder Bluff'taki Auld Stonespire'a getir." },
    [1109] = { ["description"] = "Hearts of Zeal öncesi gerekli.", ["name"] = "Ver Elini Gübre!", ["objective"] = "Undercity'deki Usta Eczacı Faranell'e 1 yığın Kraul Gübresi getir." },
    [1113] = { ["name"] = "Bağnazlık Yürekleri", ["note"] = "Manastır genelinde toplama: Cathedral'a giden yoldaki herhangi bir Scarlet insansısı Şevk Kalbi düşürebilir.", ["objective"] = "Undercity'deki Baş Simyacı Faranell 20 Bağnazlık Yüreği istiyor." },
    [1139] = { ["name"] = "Kayıp İrade Tabletleri", ["objective"] = "İrade Tableti'ni bul ve Ironforge'daki Danışman Belgrum'a getir." },
    [1142] = { ["name"] = "Can Çekişen", ["objective"] = "Treshala'nın Kolyesi'ni bul ve Darnassus'taki Treshala Fallowbrook'a geri götür.", ["pickup"] = "Heralath Fallowbrook, Razorfen Kraul içinde" },
    [1144] = { ["name"] = "İthalatçı Willix", ["objective"] = "İthalatçı Willix'e Razorfen Kraul'dan çıkana kadar eşlik et.", ["pickup"] = "Willix the Importer, Razorfen Kraul içinde", ["turnin"] = "Willix the Importer, Razorfen Kraul içinde" },
    [1149] = { ["name"] = "İnanç Sınavı", ["objective"] = "İnancın varsa Thousand Needles'a bakan kalaslardan atla." },
    [1150] = { ["name"] = "Dayanıklılık Sınavı", ["objective"] = "Grenka'nın Pençesini Thousand Needles'taki Dorn Plainstalker'a getir." },
    [1151] = { ["name"] = "Güç Sınavı", ["objective"] = "Rok'Alim'in Parçalarını Thousand Needles'taki Dorn Plainstalker'a getir." },
    [1152] = { ["name"] = "Bilgi Sınavı", ["objective"] = "Stonetalon Mountains'ta Talondeep Path girişi yakınındaki Braug Dimspirit'i bul." },
    [1154] = { ["name"] = "Bilgi Sınavı", ["objective"] = "Legacy of the Aspects'i bul ve Stonetalon Mountains'ta Talondeep Path girişi yakınındaki Braug Dimspirit'e getir." },
    [1159] = { ["name"] = "Bilgi Sınavı", ["objective"] = "Undercity'deki Parqual Fintallas'ı bul." },
    [1160] = { ["description"] = "Kitap Scarlet Monastery: Library içinde.", ["name"] = "Bilgi Sınavı", ["objective"] = "Ölümsüz Tehdidin Başlangıcı'nı bul ve Undercity'deki Parqual Fintallas'a getir." },
    [1198] = { ["description"] = "Blackfathom Villainy'nin Alliance sürümü öncesi gerekli.", ["name"] = "Thaelrid'in Peşinde", ["objective"] = "Blackfathom Deeps'te Argent Muhafızı Thaelrid'i bul.", ["turnin"] = "Argent Guard Thaelrid, Blackfathom Deeps içinde" },
    [1199] = { ["name"] = "Alacakaranlığın Düşüşü", ["objective"] = "10 Alacakaranlık Kolyesi'ni Darnassus'taki Argent Muhafızı Manados'a götür.", ["pickup"] = "Argent Guard Manados, Craftsmen's Terrace, Darnassus (55, 24)" },
    [1200] = { ["name"] = "Blackfathom'un Kötülüğü", ["objective"] = "Alacakaranlık Lordu Kelris'in başını Darnassus'taki Şafak Gözcüsü Selgorm'a götür.", ["pickup"] = "Argent Guard Thaelrid, Blackfathom Deeps içinde" },
    [1221] = { ["name"] = "Mavi Yaprak Yumruları", ["objective"] = "Bir Delikli Sandık al.$BBir Snufflenose Komuta Çubuğu al.$BSnufflenose Kullanım Kılavuzu'nu al ve oku.$B$BRazorfen Kraul'da Delikli Sandık'ı kullanarak bir Snufflenose Sincabı çağır, sonra Komuta Çubuğu'nu sincabın üzerinde kullanarak Yumru aramasını sağla.$B$B6 Mavi Yaprak Yumrusu'nu, Snufflenose Komuta Çubuğu'nu ve Delikli Sandık'ı Ratchet'taki Mebok Mizzyrix'e getir." },
    [1275] = { ["name"] = "Yozlaşmayı Araştırmak", ["note"] = "İsteğe bağlı giriş görevi:", ["objective"] = "Auberdine'daki Gershala Nightwhisper 8 Yozlaşmış Beyin Sapı istiyor.", ["pickup"] = "Gershala Nightwhisper, Auberdine, Darkshore (38.3, 43.1)" },
    [132] = { ["description"] = "Defias Brotherhood zincirinin ikinci adımı.", ["name"] = "Defias Kardeşliği", ["objective"] = "Wiley'nin Notunu Westfall'daki Gryan Stoutmantle'a götür." },
    [135] = { ["description"] = "Shaw, Defias ile Taş Ustaları arasındaki bağlantıyı araştırıyor.", ["name"] = "Defias Kardeşliği", ["objective"] = "Wiley'nin Notunu Stormwind'deki Mathias Shaw'a götür." },
    [1360] = { ["name"] = "Geri Alınan Hazineler", ["objective"] = "Uldaman'ın Kuzey Ortak Salonu'ndaki sandığından Krom Stoutarm'ın değerli varlığını al ve Ironforge'da ona getir." },
    [1394] = { ["name"] = "Son Geçit", ["objective"] = "Thousand Needles'taki Dorn Plainstalker ile konuş.", ["warning"] = "Bu, bir adımı Library'de olan uzun bir zincir" },
    [141] = { ["description"] = "Shaw'ın Edwin VanCleef hakkındaki bulgularını Gryan'a geri götürür.", ["name"] = "Defias Kardeşliği", ["objective"] = "Shaw'ın raporunu Westfall'daki Gryan Stoutmantle'a götür." },
    [142] = { ["description"] = "Ulak, Moonbrook, Gold Coast Quarry ve Jangolode Mine arasındaki yollarda dolaşır.", ["name"] = "Defias Kardeşliği", ["note"] = "Defias Messenger, Moonbrook, Gold Coast Quarry ve Jangolode Mine arasındaki yollarda devriye gezer.", ["objective"] = "Westfall'daki Defias Ulağını bul ve mesajını Stoutmantle'a getir." },
    [1424] = { ["name"] = "Gözyaşı Havuzu", ["objective"] = "Stonard'daki Fel'zerul 10 Atal'ai Eseri toplamanı istiyor." },
    [1429] = { ["name"] = "Atal'ai Sürgünü", ["objective"] = "Atal'ai Eserleri Bohçasını Hinterlands'teki Atal'ai Exile'a götür." },
    [1444] = { ["name"] = "Fel'Zerul'a Dönüş", ["objective"] = "Stonard'daki Fel'Zerul'a dön." },
    [1445] = { ["name"] = "Temple of Atal'Hakkar", ["note"] = "Atal'ai trollerinden 20 Hakkar Fetişi topla; dış tapınaktaki troller de düşürür.", ["objective"] = "20 Hakkar Fetişi topla ve Stonard'daki Fel'Zerul'a getir." },
    [1446] = { ["name"] = "Kâhin Jammal'an", ["note"] = "Jammal'an'ın bariyerini düşürmek için balkonlardaki altı trol muhafızını öldür, sonra kafasını geri getir.", ["objective"] = "The Hinterlands'teki Atal'ai Sürgünü, Jammal'an'ın Başı'nı istiyor." },
    [1448] = { ["name"] = "Tapınağın Peşinde", ["objective"] = "Stormwind'deki Brohann Caskbelly senden Temple of Atal'Hakkar'ı aramanı istiyor." },
    [1449] = { ["name"] = "Hinterlands'e", ["objective"] = "Hinterlands'deki Aerie Peak'te Yüce Thane Falstad Wildhammer ile konuş." },
    [1450] = { ["name"] = "Grifon Ustası Talonaxe", ["objective"] = "Aerie Peak Kuşhanesi'nin içindeki Grifon Ustası Talonaxe ile konuş." },
    [1451] = { ["name"] = "Rhapsody Shindigger", ["objective"] = "Hinterlands'de Rhapsody Shindigger'ı bul." },
    [1452] = { ["name"] = "Rhapsody'nin Kalimdor Kokteyli", ["objective"] = "Hinterlands'deki Rhapsody Shindigger ona 3 Roc Taşlığı, 3 Groddoc Ciğeri ve 3 Ironfur Ciğeri getirmeni istiyor." },
    [1469] = { ["name"] = "Rhapsody'nin Hikâyesi", ["objective"] = "Atal'ai Tablet Parçası'nı Stormwind'deki Brohann Caskbelly'ye götür." },
    [1475] = { ["name"] = "Temple of Atal'Hakkar'a Giriş", ["note"] = "Tapınağın çevresinden 10 Atal'ai Tableti topla; dış tapınaktaki tabletler de sayılır.", ["objective"] = "Stormwind'deki Brohann Caskbelly için 10 Atal'ai Tableti topla." },
    [1486] = { ["name"] = "Sapkın Postlar", ["objective"] = "Wailing Caverns'taki Nalpak 20 Sapkın Post istiyor.", ["pickup"] = "Nalpak, Wailing Caverns girişinin üstünde, The Barrens", ["turnin"] = "Nalpak, Wailing Caverns girişinin üstünde, The Barrens" },
    [1487] = { ["name"] = "Sapkınların Kökünü Kazımak", ["objective"] = "Wailing Caverns'taki Ebru senden 7 Sapkın Yağmacı, 7 Sapkın Engerek, 7 Sapkın Sendeleyen ve 7 Sapkın Dehşetdiş öldürmeni istiyor.", ["pickup"] = "Ebru, Wailing Caverns girişinin üstünde, The Barrens", ["turnin"] = "Ebru, Wailing Caverns girişinin üstünde, The Barrens" },
    [1489] = { ["description"] = "Tonga, Altered Beings'ten sonra seni Hamuul'a gönderir.", ["name"] = "Hamuul Runetotem", ["objective"] = "Hamuul Runetotem ile konuş." },
    [1490] = { ["description"] = "Nara Wildmane, Leaders of the Fang açılmadan önceki son ön koşul.", ["name"] = "Nara Wildmane", ["objective"] = "Nara Wildmane ile konuş." },
    [1491] = { ["name"] = "Zekâ İksirleri", ["objective"] = "Ratchet'taki Mebok Mizzyrix'e 6 porsiyon Ağıt Özü getir." },
    [153] = { ["description"] = "Red Silk Bandanas öncesi gerekli.", ["objective"] = "15 Kırmızı Deri Bandanayı Sentinel Hill'deki Scout Galiaan'a getir." },
    [155] = { ["description"] = "The Defias Brotherhood'un zindan adımı öncesi son ön koşul.", ["name"] = "Defias Kardeşliği", ["objective"] = "Defias Hainine Defias Kardeşliği'nin gizli sığınağına kadar eşlik et. Defias Haini sana VanCleef ve adamlarının nerede saklandığını gösterince bilgiyle Gryan Stoutmantle'a dön." },
    [1651] = { ["name"] = "Yiğitlik Kitabı", ["objective"] = "Daphne Stilwell'i Defias saldırısından koru.$B$BBaşarmak istiyorsan ikinizin de ruhu ölümlü bedeninden ayrılmamalı.$B$BBaşardıktan sonra Daphne Stilwell ile tekrar konuş." },
    [1652] = { ["name"] = "Yiğitlik Kitabı", ["objective"] = "Stormwind'deki Duthorian Rall ile konuş." },
    [1653] = { ["name"] = "Doğruluk Sınavı", ["objective"] = "Ironforge'daki Jordan Stilwell ile konuş" },
    [1654] = { ["name"] = "Doğruluk Sınavı", ["objective"] = "Jordan'ın Silah Notlarını kullanarak biraz Whitestone Meşe Kerestesi, Bailor'ın Arıtılmış Cevher Sevkiyatı, Jordan'ın Demirci Çekici ve bir Kor Taşı bul ve Ironforge'daki Jordan Stilwell'e getir." },
    [166] = { ["name"] = "Defias Kardeşliği", ["note"] = "Defias Brotherhood zincirinin son zindan adımı; önce önceki adımları tamamla.", ["objective"] = "Edwin VanCleef'i öldür ve kellesini Gryan Stoutmantle'a getir.", ["pickup"] = "Gryan Stoutmantle, Sentinel Hill kulesi, Westfall (56.4, 47.5)" },
    [167] = { ["name"] = "Ah Kardeşim...", ["note"] = "Ustabaşı, zindan portalından önceki tünellerde.", ["objective"] = "Ustabaşı Thistlenettle'ın Explorers' League Rozeti'ni Stormwind'deki Wilder Thistlenettle'a getir." },
    [168] = { ["name"] = "Anıları Toplamak", ["note"] = "Undead yan tüneli zindan portalından önce.", ["objective"] = "4 Madenciler Sendikası Kartı bul ve Stormwind'deki Wilder Thistlenettle'a geri getir." },
    [17] = { ["name"] = "Uldaman Malzeme Seferi", ["objective"] = "Thelsamar'daki Ghak Healtouch'a 12 Macenta Mantar Şapkası getir." },
    [1740] = { ["name"] = "Soran'ruk Küresi", ["note"] = "Warlock sınıf görevi. Parçalar Shadowfang Keep ve Blackfathom Deeps'ten gelir.", ["objective"] = "3 Soran'ruk Parçası ve 1 Büyük Soran'ruk Parçası bul ve bunları Barrens'taki Doan Karhan'a geri getir." },
    [1806] = { ["description"] = "Son adım. Ödül: Verigan's Fist.", ["name"] = "Doğruluk Sınavı", ["note"] = "İnsanlar ve cüceler için Paladin sınıf görevi. Bu zindanda: Whitestone Meşe Kerestesi Goblin Woodcarver'lardan düşer. Diğer parçalar Jordan's Smithing Hammer (Shadowfang Keep), Kor Gem (Blackfathom Deeps) ve Jordan'ın cevher sevkiyatı (Loch Modan).", ["objective"] = "Jordan Stilwell'in senin için bir silah dövmeyi bitirmesini bekle.", ["warning"] = "Bu, bir adımı The Deadmines'ta olan bir zincir görev" },
    [1954] = { ["name"] = "Cehennem Küresi", ["objective"] = "Dustwallow Marsh'taki Tabetha'ya bir Cehennem Küresi götür." },
    [1955] = { ["name"] = "Kovma Ayini", ["objective"] = "Küre İblisi'ni öldür, sonra Tabetha ile konuş." },
    [1956] = { ["name"] = "Uldaman'daki Güç", ["note"] = "Mage sınıf görevi. Obsidian Sentinel, Uldaman'ın arka girişini korur. Celestial Orb veya Celestial Stave için Mana Surges ile devam eder.", ["objective"] = "Bir Obsidyen Güç Kaynağı elde et ve onu Dustwallow Marsh'taki Tabetha'ya götür." },
    [203] = { ["name"] = "İkinci İsyan", ["note"] = "Sergeant Yohwa'nın iki görevinden diğeriyle (The Second Rebellion ve Bad Medicine) birlikte yapılır; ikisi de teslim edilince Brother Nimetz Kurzen's Mystery görevini sunar.", ["objective"] = "15 Kurzen Jungle Fighter öldür.$B$BAsi Kampı'ndaki Sergeant Yohwa'ya dön." },
    [204] = { ["name"] = "Kötü İlaç", ["note"] = "Sergeant Yohwa'nın iki görevinden diğeriyle (The Second Rebellion ve Bad Medicine) birlikte yapılır; ikisi de teslim edilince Brother Nimetz Kurzen's Mystery görevini sunar.", ["objective"] = "Asi Kampı'ndaki Sergeant Yohwa'ya 7 Orman İlacı ve 1 Zehirli Eğrelti Özütü getir." },
    [2040] = { ["name"] = "Yeraltı Saldırısı", ["note"] = "Speak with Shoni görevinden sonra gelir.", ["objective"] = "Deadmines'tan Gnoam Sprecklesprocket'ı al ve Stormwind'deki Sessiz Shoni'ye geri götür." },
    [2041] = { ["description"] = "Bu, doğrudan Underground Assault görevine götürür.", ["objective"] = "Stormwind'deki Sessiz Shoni ile konuş." },
    [205] = { ["name"] = "Trol Büyücülüğü", ["objective"] = "Asi Kampı'ndaki Brother Nimetz'e 4 Skullsplitter Fetişi getir." },
    [207] = { ["name"] = "Kurzen'in Gizemi", ["objective"] = "4 tableti bul ve efsanelerini Brother Nimetz'e getir." },
    [214] = { ["name"] = "Kırmızı İpek Bandanalar", ["note"] = "Defias Brotherhood eskort adımı gerekir.", ["objective"] = "Sentinel Hill Kulesi'ndeki Gözcü Riell, kendisine 10 Kırmızı İpek Bandana getirmeni istiyor.", ["pickup"] = "Scout Riell, Sentinel Hill kulesi, Westfall", ["turnin"] = "Scout Riell, Sentinel Hill kulesi, Westfall" },
    [2198] = { ["name"] = "Parçalanmış Kolye", ["objective"] = "Parçalanmış kolyenin olası değerini öğrenmek için asıl yapımcısını ara.", ["pickup"] = "Parçalanmış Kolye (Uldaman'da düşer)" },
    [2199] = { ["name"] = "Bedeli Olan Bilgi", ["objective"] = "Ironforge'daki Talvash del Kissel'e beş gümüş külçe getir." },
    [2200] = { ["name"] = "Uldaman'a Dönüş", ["objective"] = "Uldaman'da Talvash'ın kolyesinin şu anki durumuna dair ipuçları ara. Bahsettiği öldürülmüş paladin kolyeye en son sahip olan kişiydi." },
    [2201] = { ["name"] = "Mücevherleri Bul", ["note"] = "Safir Grimlok'tan düşer.", ["objective"] = "Uldaman'ın dört bir yanına dağılmış yakutu, safiri ve topazı bul. Hepsini aldıktan sonra Talvash del Kissel'in sana daha önce verdiği Kâhinlik Şişesi'ni kullanarak onunla uzaktan iletişim kur.$B$BGünlükten bildiğin kadarıyla...$B* Yakut, barikatlı bir Shadowforge bölgesine saklanmış.$B* Topaz, Trogg bölgelerinden birinde, birkaç İttifak dwarf'ının yakınındaki bir kavanoza gizlenmiş.$B$B* Safiri trogg lideri Grimlok sahiplenmiş.", ["turnin"] = "Talvash del Kissel (Kehanet Şişesi)" },
    [2202] = { ["name"] = "Uldaman Malzeme Seferi", ["objective"] = "Kargath'taki Jarkal Mossmeld'e 12 Macenta Mantar Şapkası getir." },
    [2204] = { ["name"] = "Kolyeyi Onarmak", ["note"] = "Güç kaynağı Archaedas'tan düşer. Bitirmek Talvash's Enhancing Necklace'ı açar.", ["objective"] = "Uldaman'da bulabildiğin en güçlü yapay yaratıktan bir güç kaynağı al ve Ironforge'daki Talvash del Kissel'e teslim et." },
    [2240] = { ["name"] = "Gizli Oda", ["note"] = "İsteğe bağlı giriş görevi:", ["objective"] = "Baelog'un Günlüğü'nü oku, gizli odayı keşfet, sonra Kâşif Stormpike'a rapor ver." },
    [2258] = { ["name"] = "Badlands Reaktif Turu", ["objective"] = "Badlands'te Kargath'taki Jarkal Mossmeld'e 5 Akbaba Taşlığı, 10 Crag Coyote Dişi ve 5 Kaya Elementali Parçası getir." },
    [2278] = { ["name"] = "Platin Diskler", ["note"] = "Diskler, Ironaya'yı geçince Map Chamber'da.", ["objective"] = "Taş gözcüyle konuş ve sakladığı kadim bilgiyi öğren. Sunduğu bilgiyi öğrendikten sonra Norgannon Diskleri'ni etkinleştir." },
    [2279] = { ["name"] = "Platin Diskler", ["note"] = "Önce Stone Watcher ile konuş ve diskleri etkinleştir. Sonra ödül senedini Ironforge kasasındaki Dinita Stonemantle'a ver ve ödülünü seç.", ["objective"] = "Norgannon Diskleri'nin minyatür kopyasını Ironforge'daki Kâşifler Birliği'ne götür." },
    [2280] = { ["name"] = "Platin Diskler", ["note"] = "Önce Stone Watcher ile konuş ve diskleri etkinleştir. Sonra ödül senedini Thunder Bluff'taki Bena Winterhoof'a ver ve ödülünü seç.", ["objective"] = "Norgannon Diskleri'nin minyatür kopyasını Thunder Bluff'taki bilgelerden birine götür." },
    [2283] = { ["name"] = "Kolyeyi Kurtarmak", ["objective"] = "Uldaman kazı alanında değerli bir kolye ara ve Orgrimmar'daki Dran Droffers'a getir. Kolye hasarlı olabilir." },
    [2284] = { ["name"] = "Kolyeyi Kurtarmak, 2. Deneme", ["objective"] = "Uldaman'ın derinliklerinde mücevherlerin yerine dair bir ipucu bul." },
    [2318] = { ["name"] = "Günlüğü Çevirmek", ["objective"] = "Paladin'in günlüğünü çevirebilecek birini bul.  Birinin olabileceği en yakın yer, Badlands'deki Kargath." },
    [2338] = { ["name"] = "Günlüğü Tercüme Etmek", ["objective"] = "Jarkal'ın kolyeyi ödünç almasına izin ver. Karşılığında sana günlüğü tercüme edecek." },
    [2339] = { ["name"] = "Mücevherleri ve Güç Kaynağını Bul", ["note"] = "Safir Grimlok'tan, güç kaynağı ise Archaedas'tan düşer.", ["objective"] = "Uldaman'dan üç mücevheri ve kolye için bir güç kaynağını al, sonra hepsini Kargath'taki Jarkal Mossmeld'e getir. Jarkal, bir güç kaynağının Uldaman'daki en güçlü yapay yaratıkta bulunabileceğini düşünüyor.$B$BGünlükten bildiğin kadarıyla...$B* Yakut, barikatlı bir Shadowforge bölgesine saklanmış.$B* Topaz, Trogg bölgelerinden birinde, birkaç İttifak dwarf'ının yakınındaki bir kavanoza gizlenmiş.$B* Safiri trogg lideri Grimlok sahiplenmiş." },
    [2342] = { ["name"] = "Geri Alınan Hazineler", ["objective"] = "Uldaman'ın Güney Ortak Salonu'ndaki aile sandığından Patrick Garrett'ın aile hazinesini al ve Undercity'de ona getir." },
    [2398] = { ["name"] = "Kayıp Dwarf'lar", ["note"] = "The Hidden Chamber görevine götüren giriş adımı.", ["objective"] = "Uldaman'da Baelog'u bul.", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [2418] = { ["name"] = "Güç Taşları", ["note"] = "Güç taşları, dış mağaradaki Shadowforge cücelerinden düşer.", ["objective"] = "Badlands'deki Rigglefuzz'a 8 Dentrium Güç Taşı ve 8 An'Alleum Güç Taşı getir." },
    [2500] = { ["name"] = "Badlands Malzeme Turu", ["objective"] = "Ghak Healtouch'un ihtiyaç duyduğu malzemeleri Badlands'ten edin, sonra Thelsamar'daki sahibine dön." },
    [261] = { ["name"] = "Kızıl Yol", ["objective"] = "30 Undead Ravager yok et, sonra Nijel's Point'teki Brother Anton'a dön." },
    [275] = { ["description"] = "Horrors in the Highland öncesi gerekli son adım.", ["name"] = "Topraktaki Kabarcıklar", ["objective"] = "8 Fen Creeper öldür, sonra Wetlands'teki Rethiel the Greenwarden'a dön." },
    [276] = { ["description"] = "Horrors in the Highland öncesi gerekli ikinci adım.", ["name"] = "Ezen Pençeler", ["objective"] = "15 Mosshide Gnoll ve 10 Mosshide Mongrel öldür, sonra Wetlands'teki Rethiel the Greenwarden'a dön." },
    [2768] = { ["name"] = "Kehanomatik Çubuk", ["note"] = "Asa, piramit olayından sonra Sergeant Bly'dan düşer.", ["objective"] = "Kehanomatik Çubuk'u Gadgetzan'daki Baş Mühendis Bilgewhizzle'a getir." },
    [2769] = { ["name"] = "Brassbolts Kardeşler", ["note"] = "Gahz'rilla görevine götüren giriş adımı.", ["objective"] = "Shimmering Flats'teki Wizzle Brassbolts ile konuş.", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [277] = { ["description"] = "Horrors in the Highland öncesi gerekli üçüncü adım.", ["name"] = "Ateş Yasağı", ["objective"] = "Rethiel the Greenwarden'a 9 Kaba Çakmaktaşı getir." },
    [2770] = { ["name"] = "Gahz'rilla", ["note"] = "İsteğe bağlı giriş görevi:", ["objective"] = "Gahz'rilla'nın Elektrikli Pulu'nu Shimmering Flats'teki Wizzle Brassbolts'a getir." },
    [2841] = { ["description"] = "Forever'da ışınlayıcı zincirini açmak için Rig Wars'un devam ediyor olması gerekir.", ["name"] = "Platform Savaşları", ["note"] = "Önce Rig Wars'u kabul et; Chief Engineer Scooty için tamamlanması gerekmez.", ["objective"] = "Araç Planları'nı ve Thermaplugg'ın Kasa Şifresi'ni Gnomeregan'dan alıp Orgrimmar'daki Nogg'a götür.$B", ["warning"] = "Chief Engineer Scooty'den önce Rig Wars'u kabul et. Rig Wars kaybolursa Chief Engineer Scooty'yi bırak, yeniden görünecektir." },
    [2842] = { ["description"] = "Gnomer-gooooone! öncesi gerekli.", ["name"] = "Baş Mühendis Scooty", ["objective"] = "Booty Bay'deki Scooty ile konuş." },
    [2843] = { ["name"] = "Gnomer-gooooone!", ["objective"] = "Scooty'nin Goblin Vericisi'ni ayarlamasını bekle." },
    [2846] = { ["name"] = "Derinliklerin Tacı", ["note"] = "Taç, Hydromancer Velratha'dan düşer.\n\nİsteğe bağlı giriş görevi:", ["objective"] = "Derinliklerin Tacı'nı Dustwallow Marsh'taki Tabetha'ya getir." },
    [2861] = { ["name"] = "Tabetha'nın Görevi", ["note"] = "Tiara of the Deep görevine götüren giriş adımı.", ["objective"] = "Dustwallow Marsh'taki Tabetha ile konuş.", ["pickup"] = "Mage eğitmenleri (yalnızca mage'ler)", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [2864] = { ["name"] = "Tran'rek", ["note"] = "Scarab Shells görevine götüren giriş adımı.", ["objective"] = "Gadgetzan'daki Tran'rek ile konuş.", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [2865] = { ["name"] = "Skarabe Kabukları", ["note"] = "İsteğe bağlı giriş görevi:", ["objective"] = "5 Çatlamamış Skarabe Kabuğu'nu Gadgetzan'daki Tran'rek'e getir." },
    [2904] = { ["name"] = "Tam Bir Rezalet", ["objective"] = "Kernobee'ye Clockwerk Run çıkışına kadar eşlik et, ardından Booty Bay'deki Scooty'ye rapor ver.", ["pickup"] = "Kernobee, Gnomeregan içinde" },
    [2922] = { ["name"] = "Techbot'un Beynini Kurtar!", ["objective"] = "Techbot'un Hafıza Çekirdeği'ni Ironforge'daki Tamirci Ustası Overspark'a götür." },
    [2924] = { ["name"] = "Temel Yapaylar", ["objective"] = "12 Temel Yapay'ı Ironforge'daki Klockmort Spannerspan'e götür." },
    [2926] = { ["description"] = "The Only Cure is More Green Glow öncesi gerekli.", ["name"] = "Gnogaine", ["objective"] = "Radyoaktif serpinti toplamak için Boş Kurşun Toplama Şişesi'ni Işınlanmış İstilacılar ya da Işınlanmış Yağmacılar üzerinde kullan. Şişe dolunca onu Kharanos'taki Ozzie Togglevolt'a geri götür." },
    [2928] = { ["name"] = "Gyrodrillmatic Kazıcılar", ["objective"] = "Stormwind'deki Shoni'ye yirmi dört Robo-mekanik Bağırsak getir." },
    [2929] = { ["name"] = "Büyük İhanet", ["objective"] = "Gnomeregan'a git ve Mekgineer Thermaplugg'ı öldür. Görev tamamlanınca Yüce Tamirci Mekkatorque'a dön." },
    [2930] = { ["name"] = "Veri Kurtarma", ["objective"] = "Bir Prizmatik Delikli Kart'ı Ironforge'daki Usta Mekanikçi Castpipe'a götür." },
    [2930001] = { ["description"] = "Rastgele düşer; genellikle dış bölgeyi ilk temizleyişinde alırsın.", ["name"] = "Beyaz Delikli Kart", ["objective"] = "Beyaz Delikli Kart düşene kadar dış Gnomeregan bölgesindeki yaratıkları öldür.", ["pickup"] = "Caverndeep Pillager, Caverndeep Invader, Irradiated Invader ve Addled Leper'lar, zindanın dışında", ["turnin"] = "Kartı Matrix Punchograph 3005-A için sakla" },
    [2930002] = { ["description"] = "Zindanın dışındaki tek delgeçler: Train Depot'daki yükseltilmiş platformda ve Workshop (arka kapı) girişinin yanında.", ["name"] = "Sarı Delikli Kart (Punchograph 3005-A)", ["objective"] = "Sarı Delikli Kart almak için Beyaz Delikli Kart ile Matrix Punchograph 3005-A'yı kullan.", ["pickup"] = "Matrix Punchograph 3005-A, Train Depot'nun atölye bölümü, zindanın dışında", ["turnin"] = "Bir Sarı Delikli Kart alırsın" },
    [2930003] = { ["description"] = "Zindanın içinde, Dormitory'de.", ["name"] = "Mavi Delikli Kart (Punchograph 3005-B)", ["objective"] = "Mavi Delikli Kart almak için Sarı Delikli Kart ile Matrix Punchograph 3005-B'yi kullan.", ["pickup"] = "Matrix Punchograph 3005-B, The Dormitory (Clean Zone'u hemen geçince), zindanın içinde", ["turnin"] = "Bir Mavi Delikli Kart alırsın" },
    [2930004] = { ["description"] = "Electrocutioner 6000'in platformunda.", ["name"] = "Kırmızı Delikli Kart (Punchograph 3005-C)", ["objective"] = "Kırmızı Delikli Kart almak için Mavi Delikli Kart ile Matrix Punchograph 3005-C'yi kullan.", ["pickup"] = "Matrix Punchograph 3005-C, Electrocutioner 6000'in bulunduğu Launch Bay'in üst platformu", ["turnin"] = "Bir Kırmızı Delikli Kart alırsın" },
    [2930005] = { ["description"] = "Asansörle aşağı in; terminal sağdaki ilk geçitte.", ["name"] = "Prizmatik Delikli Kart (Punchograph 3005-D)", ["objective"] = "Prizmatik Delikli Kart almak için Kırmızı Delikli Kart ile Matrix Punchograph 3005-D'yi kullan, sonra onu Ironforge'daki Master Mechanic Castpipe'a götür.", ["pickup"] = "Matrix Punchograph 3005-D, Engineering Labs'in alt katının batı tarafı" },
    [2933] = { ["name"] = "Zehir Şişeleri", ["objective"] = "Bir Zehir Şişesi'ni Tarren Mill'deki bir eczacıya götür." },
    [2934] = { ["name"] = "Hasarsız Zehir Kesesi", ["objective"] = "Tarren Mill'deki Eczacı Lydon'a bir Hasarsız Zehir Kesesi getir." },
    [2935] = { ["name"] = "Usta Gadrin'e Danış", ["objective"] = "Sen'jin Village'daki Usta Gadrin ile konuş." },
    [2936] = { ["name"] = "Örümcek Tanrı", ["note"] = "Theka Tableti, Theka the Martyr'ın odasında.", ["objective"] = "Witherbark örümcek tanrısının adını öğrenmek için Theka'nın Tableti'ni oku, ardından Usta Gadrin'e dön." },
    [2945] = { ["name"] = "Kirle Kaplı Yüzük", ["objective"] = "Kirle Kaplı Yüzük'teki kiri temizlemenin bir yolunu bul.", ["pickup"] = "Kirle Kaplı Yüzük, Gnomeregan'daki Dark Iron cücelerinden düşer", ["turnin"] = "The Sparklematic 5200, Gnomeregan içinde" },
    [2947] = { ["description"] = "Gnome Improvement öncesi gerekli Alliance adımı.", ["name"] = "Yüzüğün Dönüşü", ["objective"] = "Yüzüğü kendine saklayabilir ya da halkanın iç kısmındaki mühür izinden ve kazımalardan sorumlu kişiyi bulabilirsin.", ["pickup"] = "The Sparklematic 5200, Gnomeregan içinde" },
    [2948] = { ["name"] = "Gnom İşi Geliştirme", ["objective"] = "Parlak Altın Yüzük'ü, bir Gümüş Külçe'yi, bir Yosun Akik'i ve 30 gümüş sikkeyi Ironforge'daki Talvash del Kissel'e getir." },
    [2949] = { ["description"] = "Nogg's Ring Redo öncesi gerekli Horde adımı.", ["name"] = "Yüzüğün Dönüşü", ["objective"] = "Yüzüğü kendine saklayabilir ya da halkanın iç kısmındaki mühür izinden ve kazımalardan sorumlu kişiyi bulabilirsin.", ["pickup"] = "The Sparklematic 5200, Gnomeregan içinde" },
    [2950] = { ["name"] = "Nogg'un Yüzük Tamiri", ["objective"] = "Parlak Altın Yüzük'ü, bir Gümüş Külçe'yi, bir Yosun Akik'i ve 30 gümüş sikkeyi Orgrimmar'daki Nogg'a getir." },
    [2951] = { ["name"] = "Sparklematic 5200!", ["objective"] = "Kirle Kaplı bir Eşyayı Sparklematic 5200'e yerleştir ve makineyi çalıştırmak için yanında üç gümüş sikke bulunduğundan emin ol.", ["pickup"] = "The Sparklematic 5200, Gnomeregan içinde", ["turnin"] = "The Sparklematic 5200, Gnomeregan içinde" },
    [2962] = { ["name"] = "Tek Çare Daha Fazla Yeşil Parıltı", ["objective"] = "Gnomeregan'a git ve Yüksek Etkili Radyoaktif Serpinti getir. Uyarayım, serpinti kararsızdır ve oldukça çabuk bozulur.$B$BGörev tamamlandığında Ozzie, Ağır Kurşun Toplama Şişeni de isteyecek.$B" },
    [2988] = { ["name"] = "Witherbark Kafesleri", ["objective"] = "İki Witherbark köyündeki kafesleri kontrol et, sonra Grifon Ustası Talonaxe'a dön." },
    [2989] = { ["name"] = "Zul Sunağı", ["objective"] = "Altar of Zul'un tepesini kontrol et, sonra Grifon Ustası Talonaxe'a dön." },
    [2990] = { ["name"] = "Thadius Grimshade", ["objective"] = "Sharpbeak'in Tüyü'nü Blasted Lands'teki Thadius Grimshade'e götür." },
    [2991] = { ["name"] = "Nekrum'un Madalyonu", ["note"] = "Madalyon Nekrum Gutchewer'dan düşer.", ["objective"] = "Nekrum'un Madalyonu'nu Blasted Lands'teki Thadius Grimshade'e getir." },
    [303] = { ["description"] = "The Fury Runs Deep'i açmak için The Dark Iron War'u tamamla.", ["name"] = "Kara Demir Savaşı", ["objective"] = "Dun Modr'daki Motley Garmason 10 Dark Iron Dwarf, 5 Dark Iron Tunneler, 5 Dark Iron Saboteur ve 5 Dark Iron Demolitionist öldürmeni istiyor." },
    [3042] = { ["name"] = "Trol Sertleştiricisi", ["objective"] = "20 Şişe Trol Sertleştiricisi'ni Gadgetzan'daki Trenton Lighthammer'a getir." },
    [3341] = { ["name"] = "Sonu Getir", ["objective"] = "Andrew Brownell, Soğukgetiren Amnennar'ı öldürüp kafatasını getirmeni istiyor." },
    [3373] = { ["name"] = "Eranikus'un Özü", ["objective"] = "Eranikus'un Özü'nü Sunken Temple'daki bu inde bulunan Öz Pınarı'na yerleştir.", ["pickup"] = "Eranikus'un Özü (Shade of Eranikus'tan düşer)" },
    [3444] = { ["name"] = "Taş Çember", ["objective"] = "Taş Çember'i Ratchet'teki Marvon Rivetseeker'ın atölyesinden al." },
    [3446] = { ["name"] = "Derinliklere", ["note"] = "Tapınak bodrumundaki Hakkar Sunağı'nı incele. The Stone Circle'dan sonra Marvon Rivetseeker'dan başlar.", ["objective"] = "Swamp of Sorrows'taki Sunken Temple'da Hakkar Sunağı'nı bul." },
    [3447] = { ["name"] = "Çemberin Sırrı", ["note"] = "Atal'alarion'u çağırmak için çemberin etrafındaki heykelleri doğru sırayla yak.", ["objective"] = "Sunken Temple'a git ve heykel çemberinde saklı sırrı keşfet." },
    [3520] = { ["name"] = "Çığlıkçı Ruhları", ["objective"] = "Feralas'ta 3 screecher'ın ruhunu yakala, sonra Steamwheedle Port'taki Yeh'kinya'ya dön." },
    [3523] = { ["name"] = "Downs'ın Belası", ["objective"] = "Belnistrasz'a yardım etmeyi kabul ediyorsan onunla tekrar konuş ve sana verdiği Yemin Taşı'nı ona geri ver." },
    [3525] = { ["name"] = "Putu Söndürmek", ["note"] = "Ritüel sırasında undead dalgaları saldırır. Bitirmek için ardından idolün yanındaki mangalla konuş.", ["objective"] = "Razorfen Downs'taki Quilboar putuna kadar Belnistrasz'a eşlik et.$B$BBelnistrasz putu kapatmak için ayini gerçekleştirirken onu koru." },
    [3527] = { ["name"] = "Mosh'aru Kehaneti", ["note"] = "Tabletler Theka the Martyr ve Hydromancer Velratha'dan düşer.", ["objective"] = "Birinci ve İkinci Mosh'aru Tabletleri'ni Tanaris'teki Yeh'kinya'ya getir." },
    [3528] = { ["name"] = "Tanrı Hakkar", ["note"] = "Avatar of Hakkar'ı çağırmak için Hakkar Yumurtası'nı Hakkari Bloodkeeper'lardan doldur.", ["objective"] = "Dolu Hakkar Yumurtası'nı Tanaris'teki Yeh'kinya'ya getir." },
    [356] = { ["description"] = "İkisi de Linnea'nın kampının doğusundaki Balnir Farmstead'de.", ["name"] = "Artçı Devriyesi", ["objective"] = "8 Bleeding Horror ve 8 Wandering Spirit öldür, sonra kampındaki Linnea'ya rapor ver.", ["pickup"] = "Deathguard Linnea, Brill'in güneydoğusundaki kamp, Tirisfal Glades", ["turnin"] = "Deathguard Linnea, Brill'in güneydoğusundaki kamp, Tirisfal Glades" },
    [3636] = { ["name"] = "Işığı Getir", ["objective"] = "Başpiskopos Bendictus, Razorfen Downs'ta Soğukgetiren Amnennar'ı öldürmeni istiyor." },
    [3701] = { ["name"] = "Thaurissan'ın Tüten Harabeleri", ["objective"] = "Burning Steppes'teki Ruins of Thaurissan'a git ve Thaurissan Kalıntıları'ndan bilgi topla. Bilgiyi topladığında Kraliyet Tarihçisi Archesonus'a dön." },
    [3702] = { ["name"] = "Thaurissan'ın Tüten Harabeleri", ["objective"] = "Kraliyet Tarihçisi Archesonus'un Thaurissan tarihini anlatmasını dinle." },
    [373] = { ["description"] = "The Stockade Riots görevine götüren gerekli ilk adım.", ["name"] = "Gönderilmemiş Mektup", ["note"] = "Bazil Thredd ile devam eden bir zincir başlatır.", ["objective"] = "Şehir Mimarına Mektup'u Stormwind'deki Baros Alexston'a teslim et.", ["pickup"] = "Edwin VanCleef'ten alınan An Unsent Letter'ı kullan." },
    [3765] = { ["description"] = "Researching the Corruption görevine götüren isteğe bağlı Alliance yönlendirme görevi.", ["name"] = "Uzaklardaki Yozlaşma", ["note"] = "Researching the Corruption görevine götüren giriş adımı.", ["objective"] = "Auberdine'daki Gershala Nightwhisper'a git.", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [377] = { ["name"] = "Suç ve Ceza", ["objective"] = "Darkshire'dan Meclis Üyesi Millstipe, Dextren Ward'ın elini kendisine getirmeni istiyor." },
    [378] = { ["name"] = "Öfke Derinlerde", ["note"] = "Bu görevin açılması için önce The Dark Iron War gerekir.", ["objective"] = "Motley Garmason, Kam Deepfury'nin kellesinin Dun Modr'da kendisine getirilmesini istiyor." },
    [3801] = { ["name"] = "Dark Iron Mirası", ["objective"] = "Şehrin ana anahtarını elde etmekle ilgileniyorsan Franclorn Forgewright ile konuş.", ["warning"] = "Bu adamla konuşmak için ölü olman gerekir. Blackrock Mountain'da, zincirden BRD'ye inerken bir odada." },
    [3802] = { ["name"] = "Dark Iron Mirası", ["note"] = "Ölüyken Franclorn'un hayaletiyle konuş. Ironfel için Fineous Darkvire'ı öldür ve onu Ring of Law yanındaki Franclorn anıtına yerleştir. Shadowforge Anahtarı BRD içindeki kısayolları açar.", ["objective"] = "Fineous Darkvire'ı öldür ve büyük çekiç Ironfel'i geri al. Ironfel'i Thaurissan Tapınağı'na götür ve Franclorn Forgewright'ın heykeline yerleştir." },
    [386] = { ["name"] = "Ne Ekersen...", ["objective"] = "Dehşet Targorr'un kafasını Lakeshire'daki Muhafız Berton'a getir." },
    [387] = { ["name"] = "İsyanı Bastır", ["objective"] = "Stormwind'den Gardiyan Thelwater, The Stockade'de 10 Defias Mahkûmu, 8 Defias Hükümlüsü ve 8 Defias Asisi öldürmeni istiyor.", ["pickup"] = "Warden Thelwater, The Stockade'in dışında, Stormwind", ["turnin"] = "Warden Thelwater, The Stockade'in dışında, Stormwind" },
    [388] = { ["name"] = "Kanın Rengi", ["objective"] = "Stormwind'den Nikova Raskol, 10 Kırmızı Yün Bandana toplamanı istiyor." },
    [389] = { ["description"] = "The Stockade Riots görevine götüren ikinci gerekli adım.", ["name"] = "Bazil Thredd", ["objective"] = "Stockade'deki Gardiyan Thelwater ile konuş.", ["turnin"] = "Warden Thelwater, The Stockade'in dışında, Stormwind" },
    [3906] = { ["name"] = "Alevin Uyumsuzluğu", ["objective"] = "Blackrock Mountain'daki taş ocağına git ve Baş Efendi Pyron'u öldür. Bu görevi tamamladığında Thunderheart'a dön.$B" },
    [3907] = { ["name"] = "Ateşin Uyumsuzluğu", ["note"] = "BRD içindeki Black Anvil'de Lord Incendius'u öldür ve Kurniya Tableti'ni geri getir.", ["objective"] = "Blackrock Depths'e gir ve Lord Incendius'un izini sür. Onu öldür ve bulabileceğin her türlü bilgi kaynağını Thunderheart'a getir.$B" },
    [391] = { ["name"] = "Stockade İsyanı", ["note"] = "The Deadmines'ta Edwin VanCleef'ten gelen The Unsent Letter ile başlayan zincirin parçası.", ["objective"] = "Bazil Thredd'i öldür ve kellesini Stockade'deki Gardiyan Thelwater'a getir.", ["pickup"] = "Warden Thelwater, The Stockade'in dışında, Stormwind", ["turnin"] = "Warden Thelwater, The Stockade'in dışında, Stormwind" },
    [3981] = { ["name"] = "Komutan Gor'shak", ["objective"] = "Blackrock Depths'te Komutan Gor'shak'ı bul.$B$BOrk'un kabaca çizilmiş resminin portresinin üzerinde parmaklıklar çizili olduğunu hatırlıyorsun. Belki bir tür hapishane aramalısın." },
    [3982] = { ["name"] = "Neler Oluyor?", ["note"] = "High Interrogator Gerstahn'dan alınan Hapishane Hücresi Anahtarı ile hücresini aç, sonra onu savun.", ["objective"] = "Gor'shak'ı savun." },
    [4001] = { ["name"] = "Neler Oluyor?", ["objective"] = "Kharan Mighthammer ile konuş ve Prenses Moira Bronzebeard'ün kaçırılması hakkında bilgi topla. Bu bilgileri Orgrimmar'daki Thrall'a götür.$B$BGor'shak'ın, Kharan'ın yakınlardaki bir hücrede tutulduğundan bahsettiğini hatırlıyorsun.$B" },
    [4002] = { ["name"] = "Doğu Krallığı", ["objective"] = "Planladığı görevi üstlenmeye hazırsan Thrall ile konuş." },
    [4003] = { ["name"] = "Kraliyet Kurtarma Operasyonu", ["note"] = "Princess Moira'yı hayatta tut ve Emperor Thaurissan öldükten sonra onunla konuş. Onun The Princess Saved? görevi ödül için seni Thrall'a geri gönderir.", ["objective"] = "İmparator Dagran Thaurissan'ı öldür ve Prenses Moira Bronzebeard'ü onun kötü büyüsünden kurtar.$B" },
    [4024] = { ["name"] = "Alevin Tadı", ["note"] = "Önce Cyrus'a bir Kara Ejderha Uçuşu Deri Döküntüsü göster (A Taste of Flame ya da çağırdığı drake'i öldür). Sonra Bael'Gar'ı öldür ve Kaplı Ateşli Öz'ü toplamak için Değiştirilmiş Kara Ejderha Uçuşu Deri Döküntüsü'nü kalıntıları üzerinde kullan.", ["objective"] = "Blackrock Depths'e git ve Bael'Gar'ı öldür.$B$BTek bildiğin, devin Blackrock Depths'in içinde yaşadığı. Ateşli Öz'ü yakalamak için Değiştirilmiş Kara Ejderha Soyu Deri Kabuğu'nu Bael'Gar'ın kalıntıları üzerinde kullanmayı unutma.$B$BMuhafazalı Ateşli Öz'ü Cyrus Therepentous'a götür.$B$B" },
    [4061] = { ["name"] = "Makinelerin Yükselişi", ["objective"] = "Burning Steppes'e git ve Hierophant Theodora Mulvadania için 10 Kırık Element Parçası topla.$B$BTheodora'nın o bölgenin golemlerini ve elementallerini bu parçaların kaynağı olarak andığını hatırlıyorsun." },
    [4062] = { ["name"] = "Makinelerin Yükselişi", ["objective"] = "Element Parçası Örneğini Lotwil Veriatus'a götür.$B$BTheodora'nın Lotwil'in doğudaki bir kampta konuşlandığını söylediğini hatırlıyorsun." },
    [4063] = { ["name"] = "Makinelerin Yükselişi", ["note"] = "Kafası için Golem Lord Argelmach'ı öldür ve onu koruyan yapılardan 10 Sağlam Elemental Çekirdek topla.", ["objective"] = "Golem Lordu Argelmach'ı bul ve öldür. Kafasını Lotwil'e getir. Ayrıca Argelmach'ı koruyan Ragereaver Golemleri ile Warbringer Yapılarından 10 Sağlam Element Çekirdeği toplaman gerekecek. Bunu biliyorsun, çünkü medyumsun." },
    [4081] = { ["name"] = "GÖRÜLDÜĞÜ YERDE ÖLDÜR: Dark Iron Cüceleri", ["objective"] = "Blackrock Depths'e git ve alçak saldırganları yok et!$B$BSavaş Lordu Goretooth senden 15 Anvilrage Muhafızı, 10 Anvilrage Gardiyanı ve 5 Anvilrage Piyadesi öldürmeni istiyor. Görevin bittiğinde ona geri dön.$B$B" },
    [4082] = { ["name"] = "GÖRÜNCE ÖLDÜR: Üst Rütbeli Dark Iron Yetkilileri", ["objective"] = "Blackrock Depths'e git ve alçak saldırganları yok et!$B$BSavaş Lordu Goretooth, 10 Anvilrage Hekimi, 10 Anvilrage Askeri ve 10 Anvilrage Subayı öldürmeni istiyor. Görev tamamlanınca ona dön." },
    [4083] = { ["name"] = "Hayalet Kadeh", ["note"] = "Madencilik 230. Seven savaşından önce Gloom'rel ile konuş; Smelt Dark Iron'u öğrenmek için Hayalet Kadeh'e 2 Yıldız Yakutu, 20 Altın Külçe ve 10 Truesilver Külçe ver.", ["objective"] = "Gloom'rel'e 2 Yıldız Yakutu, 20 Altın Külçe ve 10 Truesilver Külçe getir, sonra bunları Summoners' Tomb'daki Hayalet Kadeh'e koy." },
    [4121] = { ["name"] = "Tehlikeli Durum", ["objective"] = "Mahkûmun Grark Lorkrub'u Burning Steppes'ten ve Blackrock Mountain'dan geçirerek Searing Gorge'a götür.$B$BLexlort'un adamlarını karşı tarafta Grark'ı gözaltına almak için bekleteceğini söylediğini hatırlıyorsun.$B$BAyrıca Toryum Kelepçelerini Lexlort'a teslim etmen gerekecek." },
    [4122] = { ["name"] = "Grark Lorkrub", ["objective"] = "Burning Steppes'e git ve Grark Lorkrub'ı bul. Lexlort'un, onun en son devasa bir Blackrock kalesinde görüldüğünden bahsettiğini hatırlıyorsun.$B$BGrark Lorkrub'ı bulduğunda, onu bağlamak için Toryum Prangalarını kullan ve ardından Blackrock Mountain'dan geçirerek Searing Gorge'a geri götür. Lexlort'un adamları, Grark'ı gözaltına almak için diğer tarafta bekliyor olacak.$B" },
    [4123] = { ["name"] = "Dağın Kalbi", ["note"] = "Dağın Kalbi, Dark Keeper'lardan sonra kasadaki kasada.", ["objective"] = "Dağın Kalbi'ni Burning Steppes'teki Maxwort Uberglint'e getir." },
    [4126] = { ["name"] = "Hurley Blackbreath", ["note"] = "Hurley Blackbreath ve muhafızlarını ortaya çıkarmak için Grim Guzzler deposundaki üç fıçıyı kır.\n\nİsteğe bağlı giriş görevi:", ["objective"] = "Kayıp Thunderbrew Tarifi'ni Kharanos'taki Ragnar Thunderbrew'a getir." },
    [4128] = { ["name"] = "Ragnar Thunderbrew", ["note"] = "Hurley Blackbreath görevine götüren giriş adımı.", ["objective"] = "Ragnar Thunderbrew ile konuş.", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [4132] = { ["name"] = "Operasyon: Angerforge'a Ölüm", ["note"] = "Önce her iki KILL ON SIGHT görevi ve Grark Lorkrub eskortu gerekir.", ["objective"] = "Blackrock Depths'e git ve General Angerforge'u öldür! Görev tamamlanınca Savaş Lordu Goretooth'a dön." },
    [4133] = { ["name"] = "Vivian Lagrave", ["note"] = "Lost Thunderbrew Recipe görevine götüren giriş adımı.", ["objective"] = "Kargath'taki Gölge Ustası Vivian Lagrave ile konuş.", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [4134] = { ["name"] = "Kayıp Thunderbrew Tarifi", ["note"] = "Hurley Blackbreath ve muhafızlarını ortaya çıkarmak için Grim Guzzler deposundaki üç fıçıyı kır.\n\nİsteğe bağlı giriş görevi:", ["objective"] = "Kayıp Thunderbrew Tarifi'ni Kargath'taki Vivian Lagrave'e getir." },
    [4136] = { ["name"] = "Ribbly Screwspigot", ["note"] = "İsteğe bağlı giriş görevi:", ["objective"] = "Ribbly'nin Kafası'nı Burning Steppes'teki Yuka Screwspigot'a götür." },
    [4141] = { ["name"] = "Muigin ve Larion", ["objective"] = "15 Bloodpetal topla ve Muigin'e dön." },
    [4142] = { ["name"] = "Gregan'a Bir Ziyaret", ["objective"] = "Bir Bloodpetal'ı Feralas'taki Gregan Brewspewer'a götür." },
    [4143] = { ["name"] = "Kötülük Pusu", ["note"] = "Atal'ai Sisi, tapınağın solucanlarından, pusucularından ve balçıklarından düşer.", ["objective"] = "5 Atal'ai Pusu örneği topla, ardından Un'Goro Crater'daki Muigin'e dön." },
    [4145] = { ["name"] = "Larion ve Muigin", ["objective"] = "Marshal's Refuge'daki Larion için 5 Bloodpetal Lasher, 5 Bloodpetal Thresher, 5 Bloodpetal Flayer ve 5 Bloodpetal Trapper avla." },
    [4146] = { ["name"] = "Böcek Çarpıcı Yakıtı", ["note"] = "Atal'ai Sisi, tapınağın solucanlarından, pusucularından ve balçıklarından düşer.", ["objective"] = "Boş Böcek Çarpıcı'yı ve 5 Atal'ai Pusu örneğini Marshal's Refuge'daki Larion'a götür." },
    [4147] = { ["name"] = "Marvon'un Atölyesi", ["objective"] = "Ratchet'taki Marvon Rivetseeker'ın atölyesine git." },
    [4182] = { ["name"] = "Ejderha Soyu Tehdidi", ["objective"] = "15 Black Broodling, 10 Black Dragonspawn, 4 Black Wyrmkin ve 1 Black Drake öldür. Görev tamamlanınca Helendis Riverhorn'a dön." },
    [4183] = { ["name"] = "Gerçek Efendiler", ["objective"] = "Lakeshire'a git ve Helendis Riverhorn'un Mektubu'nu Yargıç Solomon'a teslim et." },
    [4184] = { ["name"] = "Gerçek Efendiler", ["objective"] = "Stormwind'e git ve Solomon'un Yalvarısı'nı Highlord Bolvar Fordragon'a teslim et.$B$BBolvar, Stormwind Keep'te oturuyor. " },
    [4185] = { ["name"] = "Gerçek Efendiler", ["objective"] = "Lady Katrana Prestor ile konuştuktan sonra Highlord Bolvar Fordragon ile konuş." },
    [4186] = { ["name"] = "Gerçek Efendiler", ["objective"] = "Bolvar'ın Fermanı'nı Lakeshire'daki Yargıç Solomon'a götür.$B" },
    [4201] = { ["name"] = "Aşk İksiri", ["note"] = "Gromsblood, Dev Gümüş Damarları (Azshara uçurum devleri) ve Un'Goro'daki Golakka Hot Springs'te doldurulan şişe. Sonraki ziyaretlerde bardan barışçıl bir geçiş açar.", ["objective"] = "4 Gromsblood, 10 Dev Gümüş Damarı ve Nagmara'nın Dolu Şişesi'ni Blackrock Depths'teki Mistress Nagmara'ya getir." },
    [4223] = { ["name"] = "Gerçek Efendiler", ["objective"] = "Burning Steppes'teki Mareşal Maxwell ile konuş." },
    [4224] = { ["name"] = "Gerçek Efendiler", ["objective"] = "Mareşal Windsor'un akıbetini öğrenmek için Ragged John ile konuş ve bu görevi tamamlayınca Mareşal Maxwell'e dön.$B$BMareşal Maxwell'in onu kuzeydeki bir mağarada aramanı söylediğini hatırlıyorsun." },
    [4241] = { ["name"] = "Mareşal Windsor", ["objective"] = "Kuzeybatıdaki Blackrock Mountain'a git ve Blackrock Depths'e gir. Mareşal Windsor'a ne olduğunu öğren.$B$BRagged John'un, Windsor'ın bir hapishaneye sürüklendiğinden bahsettiğini hatırlıyorsun." },
    [4242] = { ["name"] = "Terk Edilmiş Umut", ["objective"] = "Mareşal Maxwell'e kötü haberi ver." },
    [4262] = { ["name"] = "Baş Efendi Pyron", ["objective"] = "Baş Efendi Pyron'u öldür ve Jalinda Sprig'e dön.$B$BJalinda'nın, Pyron'un taş ocağını koruduğundan bahsettiğini hatırlıyorsun. Belki de orayı aramalısın?" },
    [4263] = { ["name"] = "Incendius!", ["note"] = "BRD içindeki Black Anvil'de Lord Incendius'u öldür.", ["objective"] = "Blackrock Depths'te Lord Incendius'u bul ve yok et!" },
    [4264] = { ["name"] = "Buruşuk Bir Not", ["objective"] = "Belki de Marshal Windsor'un görmek isteyeceği bir şeye rastladın. Sonuçta umut olabilir.", ["pickup"] = "Buruşturulmuş Bir Not (Dark Iron cücelerinden düşer)" },
    [4282] = { ["name"] = "Bir Umut Kırıntısı", ["objective"] = "Mareşal Windsor'ın Kayıp Bilgileri'ni geri getir.$B$BMareşal Windsor, bilgilerin Golem Lordu Argelmach ve General Angerforge'un elinde olduğuna inanıyor." },
    [4286] = { ["name"] = "İyi Şeyler", ["note"] = "Dark Iron Bel Çantaları, BRD'deki Dark Iron cücelerinden düşer.", ["objective"] = "Blackrock Depths'e git ve 20 Dark Iron Bel Çantası topla. Bu görevi tamamladığında Oralius'a dön. Blackrock Depths'teki Dark Iron cücelerinin bu 'bel çantası' denen zımbırtıları taşıdığını tahmin ediyorsun.$B" },
    [4295] = { ["name"] = "Rocknot'un Birası", ["note"] = "Plugger Spazzring'den Dark Iron Bira Kupası satın al ve Rocknot'a vermeye devam et. Sarhoşluk olayı bar yolunu açar ve Phalanx'ı düşman yapabilir.", ["objective"] = "Er Rocknot'a iki Dark Iron Bira Kupası getir." },
    [4322] = { ["name"] = "Firar!", ["note"] = "Marshal Windsor'a hapishane boyunca eşlik et. Önce devriyeleri temizle ve başlamadan önce herkesin hazır olmasını sağla.", ["objective"] = "Mareşal Windsor'ın teçhizatını geri almasına ve dostlarını serbest bırakmasına yardım et. Başarırsan Mareşal Maxwell'e dön." },
    [4324] = { ["name"] = "Yuka Screwspigot", ["note"] = "Ribbly Screwspigot görevine götüren giriş adımı.", ["objective"] = "Burning Steppes'teki Yuka Screwspigot ile konuş.", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [4341] = { ["name"] = "Kharan Mighthammer", ["objective"] = "Blackrock Depths'e git ve Kharan Mighthammer'ı bul.$B$BKral, Kharan'ın orada esir tutulduğundan bahsetti; belki de bir hapishane aramalısın." },
    [4342] = { ["name"] = "Kharan'ın Hikâyesi", ["objective"] = "Kharan Mighthammer hikâyesini anlatırken dinle." },
    [4361] = { ["name"] = "Kötü Haber Getiren", ["objective"] = "Ironforge'a dön ve kötü haberi Kral Magni Bronzebeard'a ilet." },
    [4362] = { ["name"] = "Krallığın Kaderi", ["note"] = "Princess Moira'yı hayatta tut ve Emperor Thaurissan öldükten sonra onunla konuş. Onun The Princess's Surprise görevi ödül için seni Magni'ye geri gönderir.", ["objective"] = "Blackrock Depths'e dön ve Prenses Moira Bronzebeard'ü İmparator Dagran Thaurissan'ın kötü pençelerinden kurtar.$B" },
    [447] = { ["name"] = "Ölümün Tarifi", ["objective"] = "6 Boz Ayı Kalbi ve 6 Skittering Kanı örneği topla ve Undercity'deki Master Apothecary Faranell'e teslim et." },
    [450] = { ["name"] = "Ölümün Tarifi", ["objective"] = "Apothecary Berard'ın günlüğünü Pyrewood Village'dan al ve Sepulcher'daki Apothecary Renferrel'e götür.", ["warning"] = "Grup görevi: han, düşman köylülerin arasında, Pyrewood Village'da." },
    [451] = { ["name"] = "Ölümün Tarifi", ["objective"] = "Undercity'deki Master Apothecary Faranell'e 6 Lake Creeper Yosunu örneği, 6 Lake Skulker Yosunu örneği ve bir Sertleşmiş Tümör getir." },
    [463] = { ["description"] = "Horrors in the Highland öncesi gerekli ilk adım.", ["name"] = "Greenwarden", ["objective"] = "Greenwarden'ı bul." },
    [4701] = { ["name"] = "Onu Yere Ser", ["note"] = "Worg ini annesi Halycon'u öldür. Hemen ardından sana gelecek olan Gizrul the Slavener'a hazır ol.", ["objective"] = "Blackrock Spire'a git ve worg tehdidinin kaynağını yok et. Helendis'ten ayrılırken bir isim haykırdı: Halycon. Orklar worg'lar için böyle diyor." },
    [4724] = { ["name"] = "Sürünün Hanımı", ["note"] = "Worg ini annesi Halycon'u öldür. Hemen ardından sana gelecek olan Gizrul the Slavener'a hazır ol.", ["objective"] = "Bloodaxe worglarının sürü hanımı Halycon'u öldür." },
    [4726] = { ["name"] = "Yavru Ejderha Özü", ["objective"] = "Burning Steppes'teki Flame Crest'te bulunan Tinkee Steamboil'e 8 Yavru Ejderha Özü ve Draco-Incarcinatrix 900'ü getir." },
    [4729] = { ["name"] = "Kibler'ın Egzotik Evcil Hayvanları", ["note"] = "Verilen kafesi worg bölgesindeki bir Bloodaxe Worg Yavrusu üzerinde kullan.", ["objective"] = "Blackrock Spire'a git ve Bloodaxe Worg Yavrularını bul. Vahşi küçük canavarları taşımak için kafesi kullan. Kibler'a Kafesli Worg Yavrusu getir." },
    [4734] = { ["name"] = "Yumurta Dondurma", ["objective"] = "Yumurtaskop Prototipi'ni Yuvalık'taki bir yumurtanın üzerinde kullan." },
    [4735] = { ["name"] = "Yumurta Toplama", ["note"] = "Modülü Rookery'deki yumurtalarda kullanmak yavruların çıkmasına yol açabilir.", ["objective"] = "8 Toplanmış Ejderha Yumurtası'nı ve Toplatronik Modül'ü Burning Steppes'teki Flame Crest'te bulunan Tinkee Steamboil'e götür." },
    [4742] = { ["name"] = "Yükseliş Mührü", ["objective"] = "Üç komuta mücevherini bul: Smolderthorn Mücevheri, Spirestone Mücevheri ve Bloodaxe Mücevheri. Bunları Süssüz Yükseliş Mührü ile birlikte Vaelan'a götür.$B$BVaelan'ın sana söylediğine göre generaller şunlardır: Smolderthorn'dan Savaş Ustası Voone, Spirestone'dan Yüce Lord Omokk ve Bloodaxe'tan Derebeyi Wyrmthalak.", ["pickup"] = "Vaelan (Scarshield Infiltrator), Lower Blackrock Spire", ["turnin"] = "Vaelan (Scarshield Infiltrator), Lower Blackrock Spire" },
    [4743] = { ["name"] = "Yükseliş Mührü", ["note"] = "Dövülmemiş Mühür'ü ve Ejderha Enerjisi Küresi'ni Dustwallow Marsh'taki Wyrmbog'da Emberstrife'a götür. Dövülmüş mühür UBRS kapısını açar.", ["objective"] = "Dustwallow Marsh'taki Wyrmbog'a git. Kadim ejder Emberstrife'ı bul ve iradesi kırılana dek onu acımadan döv.$B$BTam o anda Dövülmemiş Yükseliş Mührü'nü o büyük yaratığın önüne koymalısın. Ardından hızla Ejderha Enerjisi Küresi'ni zayıf düşmüş bedeni üzerinde kullanmalı ve zihnine hükmetmelisin. Yaratığı kontrol et ve Kara Ejderha Soyu'nun Alevleri'ni Dövülmemiş Yükseliş Mührü'ne püskürtmeye zorla!" },
    [4764] = { ["name"] = "Doomrigger'ın Tokası", ["note"] = "Doomrigger'ın Sandığı Rookery'de. Ardından ödül için Delivery to Ridgewell'i Stormwind Keep'teki Count Remington Ridgewell'e götür.\n\nİsteğe bağlı giriş görevi:", ["objective"] = "Doomrigger'ın Tokası'nı Burning Steppes'teki Mayara Brightwing'e götür." },
    [4766] = { ["name"] = "Mayara Brightwing", ["note"] = "Doomrigger's Clasp görevine götüren giriş adımı.", ["objective"] = "Burning Steppes'teki Mayara Brightwing ile konuş.", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [4768] = { ["name"] = "Darkstone Tableti", ["note"] = "Darkstone Tableti Rookery'de yerde duruyor.\n\nİsteğe bağlı giriş görevi:", ["objective"] = "Darkstone Tableti'ni Kargath'taki Gölge Büyücüsü Vivian Lagrave'e götür." },
    [4769] = { ["name"] = "Vivian Lagrave ve Darkstone Tableti", ["note"] = "The Darkstone Tablet görevine götüren giriş adımı.", ["objective"] = "Gölge Büyücüsü Vivian Lagrave ile konuş.", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [4771] = { ["name"] = "Şafak Kumarı", ["note"] = "Viewing Room'da Dawn's Gambit'i kullan ve Vectus'u yen.", ["objective"] = "Şafak Kumarı'nı Scholomance'taki Seyir Odası'na yerleştir. Vectus'u yen, ardından Betina Bigglezink'e dön." },
    [4787] = { ["name"] = "Kadim Yumurta", ["objective"] = "Kadim Yumurta'yı Tanaris'teki Yeh'kinya'ya getir." },
    [4788] = { ["name"] = "Son Tabletler", ["note"] = "Beşinci ve altıncı Mosh'aru tabletleri Smolderthorn trol bölgesinde. Confront Yeh'kinya ve The Hand of Rastakhan ile devam eder.", ["objective"] = "Beşinci ve Altıncı Mosh'aru Tabletleri'ni Tanaris'teki Maden Arayıcısı Ironboot'a götür." },
    [4808] = { ["name"] = "Felnok Steelspring", ["objective"] = "Tinkee'nin Mektubu'nu Felnok Steelspring'e ver." },
    [4809] = { ["name"] = "Chillwind Boynuzları", ["objective"] = "Felnok Steelspring'e 8 Çatlamamış Chillwind Boynuzu getir." },
    [4810] = { ["name"] = "Tinkee'ye Dönüş", ["objective"] = "Felnok'un Paketi'ni Burning Steppes'teki Tinkee Steamboil'e götür." },
    [484] = { ["description"] = "Highland Hides öncesi gerekli. Forever'da Daily Delivery gerekli değil.", ["name"] = "Genç Timsah Derileri", ["objective"] = "Menethil Harbor'daki James Halloran için 4 Genç Timsah Derisi edin." },
    [4862] = { ["name"] = "Evcilleştirme Sanatı", ["note"] = "Spire Örümcek Yumurtaları örümcek tünellerinde.", ["objective"] = "Blackrock Spire'a git ve Kibler için 15 Kule Örümceği Yumurtası topla.$B$BAnlaşılan bu yumurtalar örümceklerin yakınında bulunabilir.$B" },
    [4866] = { ["name"] = "Ana Sütü", ["note"] = "Mother Smolderweb tarafından zehirlen ve hâlâ zehirliyken Ragged John'a ulaş. Kimsenin zehri temizlemesine izin verme.", ["objective"] = "Blackrock Spire'ın kalbinde Mother Smolderweb'i bulacaksın. Onunla savaş ve seni zehirlemesini sağla. Büyük ihtimalle onu öldürmen de gerekecek. Zehirlendiğinde, seni 'sağabilmesi' için Ragged John'a dön." },
    [4867] = { ["name"] = "Urok Doomhowl", ["note"] = "Dalgaları başlatmak için Highlord Omokk'un Kafası'nı ve bir Roughshod Mızrağı'nı örümceklerin ötesindeki Urok's Tribute Pile'a getir.", ["objective"] = "Warosh'un Parşömeni'ni oku. Warosh'un Mojosu'nu Warosh'a getir." },
    [4903] = { ["name"] = "Savaş Beyi'nin Emri", ["note"] = "Command eşyasını almak için Goretooth ile konuş ve görevi başlatmak için ona tıkla. Önemli Blackrock Belgeleri üç generalin yakınında çıkar.", ["objective"] = "Yüce Lord Omokk'u, Savaş Ustası Voone'u ve Derebeyi Wyrmthalak'ı öldür. Önemli Blackrock Belgeleri'ni ele geçir. Görev tamamlandığında Kargath'taki Savaş Beyi Goretooth'a dön." },
    [4907] = { ["name"] = "Tinkee Steamboil", ["objective"] = "Tinkee Steamboil ile konuş." },
    [4941] = { ["name"] = "Eitrigg'in Bilgeliği", ["objective"] = "Orgrimmar'daki Eitrigg ile konuş. Eitrigg ile meseleleri görüştükten sonra Thrall'a danış.$B$BEitrigg'i Thrall'ın odasında gördüğünü hatırlıyorsun." },
    [4974] = { ["name"] = "Horde İçin!", ["objective"] = "Blackrock Spire'a git ve Savaş Şefi Rend Blackhand'i öldür. Kellesini al ve Orgrimmar'a dön." },
    [4981] = { ["name"] = "Ajan Bijou", ["objective"] = "Blackrock Spire'a git ve Bijou'ya ne olduğunu öğren.", ["turnin"] = "Bijou, Lower Blackrock Spire içinde" },
    [4982] = { ["name"] = "Bijou'nun Eşyaları", ["note"] = "Ardından ödül için Bijou's Reconnaissance Report'u Kargath'taki Lexlort'a götür.", ["objective"] = "Bijou'nun Eşyaları'nı bul ve ona geri götür. Onları şehrin en alt katına sakladığından bahsettiğini hatırlıyorsun.$B" },
    [5001] = { ["name"] = "Bijou'nun Eşyaları", ["note"] = "Bijou, ilk köprülerin ötesindeki bir girintide saklanır. Eşyaları trol ve ork odalarının çevresindeki birkaç yerden birinde çıkar.", ["objective"] = "Bijou'nun Eşyaları'nı bul ve ona geri götür. Bol şans!$B" },
    [5002] = { ["name"] = "Maxwell'e Mesaj", ["objective"] = "Burning Steppes'e git ve Bijou'nun Bilgileri'ni Mareşal Maxwell'e ver." },
    [5047] = { ["name"] = "Finkle Einhorn, Hizmetinizde!", ["note"] = "Savaştan sonra The Beast'in cesedinden çıkar. Malyfous ardından Pristine Hide of the Beast takaslarını sunar.", ["objective"] = "Everlook'taki Malyfous Darkhammer ile konuş.", ["pickup"] = "The Beast'in cesedinden, Upper Blackrock Spire" },
    [5065] = { ["name"] = "Mosh'aru'nun Kayıp Tabletleri", ["objective"] = "Üçüncü ve Dördüncü Mosh'aru Tabletleri'ni Tanaris'teki Maden Arayıcı Ironboot'a getir." },
    [5081] = { ["name"] = "Maxwell'in Görevi", ["objective"] = "Blackrock Spire'a git ve Savaş Ustası Voone'u, Yüce Lord Omokk'u ve Derebeyi Wyrmthalak'ı yok et. İş bittiğinde Mareşal Maxwell'e dön." },
    [5089] = { ["name"] = "General Drakkisath'ın Emri", ["note"] = "Upper Blackrock Spire'daki General Drakkisath's Demise görevine götürür.", ["objective"] = "General Drakkisath'ın Emri'ni Burning Steppes'teki Mareşal Maxwell'e götür.", ["pickup"] = "General Drakkisath's Command (Overlord Wyrmthalak'tan düşer)" },
    [5102] = { ["name"] = "General Drakkisath'ın Sonu", ["note"] = "UBRS'nin sonunda General Drakkisath'ı öldür.", ["objective"] = "Blackrock Spire'a git ve General Drakkisath'ı yok et. İş bittiğinde Mareşal Maxwell'e dön.$B" },
    [5122] = { ["name"] = "İnanç Madalyonu", ["note"] = "Madalyon, Scarlet Bastion'daki Malor'un Kasası'nda. Baron ile savaşmadan önce onu şapeldeki Aurius'a ver.", ["objective"] = "İnanç Madalyonu'nu Scarlet Bastion'daki Malor the Zealous'tan al ve Aurius'a geri getir." },
    [5125] = { ["name"] = "Aurius'un Hesaplaşması", ["note"] = "Baron savaşından önce İnanç Madalyonu'nu Aurius'a ver; Baron Rivendare öldükten sonra onunla konuş.", ["objective"] = "İnanç Madalyonu'nu Aurius'a ver; Baron Rivendare'e karşı savaşa katılır. Savaştan sonra ödülünü al." },
    [5127] = { ["name"] = "İblis Ocağı", ["note"] = "Demircilik 270 (Zırh Ustası). Kana Bulanmış Mızrak'ı Goraluk'un cesedinde kullan ve yakındaki Dövülmemiş Rün Kaplı Göğüslük'ü al.", ["objective"] = "Blackrock Spire'a git ve Goraluk Anvilcrack'ı bul. Onu öldür, sonra Kana Bulanmış Mızrak'ı cesedi üzerinde kullan. Ruhu emildikten sonra mızrak Ruha Bulanmış hale gelecek.$B$BAyrıca Dövülmemiş Rün Kaplı Göğüs Zırhı'nı da bulmalısın.$B$BHem Ruha Bulanmış Mızrak'ı hem de Dövülmemiş Rün Kaplı Göğüs Zırhı'nı Winterspring'deki Lorax'a götür." },
    [5160] = { ["name"] = "Koruyucu Ana", ["note"] = "Awbee, Rend'den sonra arena yolunun yakınındaki yaralı mavi ejderha. Haleh'e ulaşmak için Mazthoril mağarasının derinlerindeki rünü kullan.", ["objective"] = "Winterspring'e git ve Haleh'i bul. Ona Awbee'nin pulunu ver." },
    [5212] = { ["name"] = "Et Yalan Söylemez", ["note"] = "Stratholme'daki her undead Vebalı Et Örneği düşürebilir.", ["objective"] = "Stratholme'dan 10 Vebalı Et Örneği al ve Betina Bigglezink'e getir. Stratholme'daki her yaratığın bu et örneğini taşıyacağından şüpheleniyorsun." },
    [5213] = { ["name"] = "Etkin Madde", ["objective"] = "Stratholme'e git ve zigguratları ara. Yeni Scourge Verileri'ni bul ve Betina Bigglezink'e getir.$B" },
    [5214] = { ["name"] = "Büyük Fras Siabi", ["note"] = "Daha yeni Classic kayıtları ona Ezra Grimm der. Tütün dükkânını temizle, tütün kutusuna dokun ve dükkân sahibini öldür.", ["objective"] = "Stratholme'de Fras Siabi'nin tütün dükkânını bul ve bir kutu Siabi'nin Seçkin Tütünü'nü getir. İş bitince Smokey LaRue'ya dön.$B" },
    [5243] = { ["name"] = "Kutsalın Evleri", ["note"] = "Sokaklardaki erzak sandıklarından 5 Stratholme Kutsal Suyu topla; bazı sandıklardan düşman çıkar.", ["objective"] = "Kuzeydeki Stratholme'a git. Şehri dolduran erzak sandıklarını ara ve 5 Stratholme Kutsal Suyu bul. Yeterince kutsal sıvı topladığında Saygıdeğer Leonid Barthalomew'e dön." },
    [5244] = { ["name"] = "Kel'Theril Harabeleri", ["objective"] = "Starfall Village'daki Jaron Stoneshaper ile konuş." },
    [5245] = { ["name"] = "Kel'Theril'in Huzursuz Ruhları", ["objective"] = "Jaron'un Kazması'nı kullanarak dört Highborne Kalıntı Parçası'nı bul. Onları Eastern Plaguelands'teki Aurora Skycaller'a götür." },
    [5246] = { ["name"] = "Geçmişin Parçaları", ["objective"] = "Azshara'daki Zin-Malor Tapınağı'nda Kutsal Highborne Yazıları'nı bul ve Eastern Plaguelands'te Northpass Tower yakınındaki Aurora Skycaller'a getir." },
    [5247] = { ["name"] = "Geçmişin Parçaları", ["note"] = "Dire Maul West'te Eldreth Row boyunca uğursuz havuzda şişesini doldur; ayrıca 1 Efsunlu Thorium Külçesi ve 5 Crystal Restore getir.\n\nİsteğe bağlı giriş görevi:", ["objective"] = "Eastern Plaguelands'te Northpass Tower yakınındaki Aurora Skycaller'a bir Büyülü Toryum Külçesi, 5 Crystal Restore ve bir Şişe Uğursuz Su getir." },
    [5250] = { ["name"] = "Starfall", ["note"] = "Fragments of the Past görevine götüren giriş adımı.", ["objective"] = "Winterspring'de Starfall'u bul ve Wynd Nightchaser ile konuş.", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [5251] = { ["name"] = "Arşivci", ["note"] = "Scarlet Bastion'da Archivist Galford'u öldür ve arşivleri yak.", ["objective"] = "Stratholme'e git ve Scarlet Crusade'den Arşivci Galford'u bul. Onu yok et ve Scarlet Arşivi'ni yakıp kül et." },
    [5262] = { ["name"] = "Gerçek Bütün Ağırlığıyla Çöküyor", ["note"] = "Önce The Archivist'i teslim et, yoksa Balnazzar'ın kafası bu görevi başlatmaz.", ["objective"] = "Balnazzar'ın Kafası'nı Eastern Plaguelands'teki Dük Nicholas Zverenhoff'a götür.", ["pickup"] = "Balnazzar'ın Kafası (Balnazzar'dan düşer)" },
    [5263] = { ["name"] = "Beklentilerin Ötesinde", ["note"] = "Ardından Light's Hope Chapel'daki Lord Maxwell Tyrosus ve The Argent Hold silah veya kalkan ödülünü verir.", ["objective"] = "Stratholme'e git ve Baron Rivendare'i yok et. Kafasını al ve Dük Nicholas Zverenhoff'a dön.$B" },
    [5281] = { ["name"] = "Huzursuz Ruhlar", ["note"] = "The Restless Souls görevine götüren giriş adımı.", ["objective"] = "Egan'ı bul. Yalnızca en son Stratholme civarında görüldüğünü biliyorsun.", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [5282] = { ["name"] = "Huzursuz Ruhlar", ["note"] = "İsteğe bağlı giriş görevi:", ["objective"] = "Egan'ın Patlatıcısı'nı Stratholme'ün hayaletimsi ve tayfsı sakinleri üzerinde kullan. Huzursuz ruhlar hayalet kabuklarından kurtulduğunda patlatıcıyı yeniden kullan; özgürlüklerine kavuşacaklar!$B$B15 Huzursuz Ruh'u özgür bırak ve Egan'a dön." },
    [5341] = { ["name"] = "Barov Ailesinin Serveti", ["note"] = "Dört tapu: ilk büyük salonda Southshore, yavrulardan önce Tarren Mill, Ras Frostwhisper'ın yanında Brill, Lord Alexei Barov'un yanında Caer Darrow. Devam görevi The Last Barov seni rakip kardeşi öldürmeye gönderir.", ["objective"] = "Scholomance'a git ve Barov ailesinin servetini geri getir. Bu servet dört tapudan oluşuyor: Caer Darrow Tapusu, Brill Tapusu, Tarren Mill Tapusu ve Southshore Tapusu. Bu görevi tamamladığında Alexi Barov'a dön." },
    [5343] = { ["name"] = "Barov Ailesinin Serveti", ["note"] = "Dört tapu: ilk büyük salonda Southshore, yavrulardan önce Tarren Mill, Ras Frostwhisper'ın yanında Brill, Lord Alexei Barov'un yanında Caer Darrow. Devam görevi The Last Barov seni rakip kardeşi öldürmeye gönderir.", ["objective"] = "Scholomance'a git ve Barov ailesinin servetini geri getir. Bu servet dört tapudan oluşuyor: Caer Darrow Tapusu, Brill Tapusu, Tarren Mill Tapusu ve Southshore Tapusu. Bu görevi tamamladığında Weldon Barov'a dön." },
    [5382] = { ["name"] = "Doktor Theolen Krastinov, Kasap", ["objective"] = "Scholomance'ın içinde Doktor Theolen Krastinov'u bul. Onu yok et, ardından Eva Sarkhoff'un Kalıntıları'nı ve Lucien Sarkhoff'un Kalıntıları'nı yak. Görev tamamlandığında Eva Sarkhoff'a dön.$B" },
    [5384] = { ["name"] = "Haberci Kirtonos", ["note"] = "Masumların Kanı'nı Scholomance verandasındaki mangalda kullan. Ödül: Spectral Essence.", ["objective"] = "Masumların Kanı ile Scholomance'a dön. Sundurmayı bul ve Masumların Kanı'nı mangala koy. Kirtonos ruhunla ziyafet çekmeye gelecek.$B$BYiğitçe savaş, bir adım bile geri atma! Kirtonos'u yok et ve Eva Sarkhoff'a dön.$B" },
    [544] = { ["name"] = "Hapishaneye Sızma", ["note"] = "Aynı anda Magus Wordeen Voidglare'den Key to the City görevini de al.", ["objective"] = "Hainleri bul ve eserlerini geri al, sonra Tarren Mill'deki Magus Voidglare'e dön." },
    [545] = { ["description"] = "Prison Break In tamamlandıktan sonra alınabilir.", ["name"] = "Dalaran Devriyeleri", ["objective"] = "6 Dalaran Summoner ve 12 Elemental Slave öldür, sonra Tarren Mill'deki Magus Voidglare'e dön." },
    [5461] = { ["name"] = "İnsan, Ras Frostwhisper", ["objective"] = "Arathi Highlands'e, Stromgarde harabelerine git. Stromgarde'da bir Anma Hatırası ara. Böyle bir eşya bulursan onunla Yargıç Marduke'a dön." },
    [5462] = { ["name"] = "Ölmekte Olan, Ras Frostwhisper", ["objective"] = "Eastern Plaguelands'teki Light's Hope'a git ve Saygıdeğer Leonid Barthalomew'i bul. Ona Anma Hatırası'nı göster ve keşfettiğin her şeyi anlat." },
    [5463] = { ["name"] = "Menethil'in Armağanı", ["note"] = "Baron Rivendare öldükten sonra odasının zeminindeki parlayan rünü kullan, sonra devam görevini Leonid'e geri götür.", ["objective"] = "Stratholme'a git ve Menethil's Gift'i bul. Anma Yadigârı'nı kutsal olmayan toprağa yerleştir. " },
    [5464] = { ["name"] = "Menethil'in Hediyesi", ["objective"] = "Ruha Bağlı Hatıra'yı Eastern Plaguelands'teki Leonid Barthalomew'e götür." },
    [5465] = { ["name"] = "Ruha Bağlı Hatıra", ["objective"] = "Caer Darrow'daki Yargıç Marduke'a dön. Ona Ruha Bağlı Hatıra'yı göster." },
    [5466] = { ["name"] = "Lich Ras Frostwhisper", ["note"] = "Soulbound Keepsake'i Ras Frostwhisper üzerinde kullanarak onu insana dönüştür, sonra onu öldür ve insan kafasını geri getir.", ["objective"] = "Scholomance'ta Ras Frostwhisper'ı bul. Onu bulduğunda, Ruha Bağlı Hatıra'yı ölümsüz suretine karşı kullan. Onu ölümlüye dönüştürmeyi başarırsan, yere ser ve Ras Frostwhisper'ın İnsan Başı'nı al. Başı Yargıç Marduke'a götür." },
    [5515] = { ["name"] = "Krastinov'un Dehşet Çantası", ["note"] = "Çanta Jandice Barov'dan düşer.", ["objective"] = "Scholomance'ta Jandice Barov'u bul ve yok et. Cesedinden Krastinov'un Dehşet Çantası'nı al. Çantayı Eva Sarkhoff'a götür." },
    [5518] = { ["name"] = "Gordok Ogre Kostümü", ["note"] = "4 Rün Kumaşı Topu, 8 Sağlam Deri, 2 Rün İpliği ve 1 Ogre Tanen'i (Knot'un ötesinde üst kattaki sepet) getir. Knot'u serbest bırakmadan önce istediğin takımları yap ve deseni öğren, çünkü gidiyor.", ["objective"] = "4 Top Rün Kumaşı, 8 Sert Deri, 2 Rün İpliği ve Ogre Tanen Özü'nü Knot Thimblejack'e getir. Kendisi şu anda Dire Maul'un Gordok kanadında zincirli durumda." },
    [5522] = { ["name"] = "Leonid Barthalomew", ["objective"] = "Donmuş Yumurtalar'ı Eastern Plaguelands'teki Leonid Barthalomew'e götür." },
    [5525] = { ["name"] = "Knot'u Kurtar!", ["note"] = "North ogrelerinden bir Gordok Pranga Anahtarı al ve Knot'u serbest bırak; zulasında ganimet var.", ["objective"] = "Gordok kanadındaki ogrelerden bir Gordok Pranga Anahtarı bul ve Knot Thimblejack'i serbest bırakmak için kullan." },
    [5526] = { ["name"] = "Felvine Parçaları", ["note"] = "Alzzin the Wildshaper'ı öldür, sarmaşığın yanından bir Felvine Parçası al ve onu Reliquary of Purity'ye mühürle.", ["objective"] = "Dire Maul'da Felvine'ı bul ve ondan bir parça elde et. Büyük ihtimalle bir parçayı ancak Vahşibiçimci Alzzin'in ölümüyle elde edebileceksin. Parçayı güvenle içine mühürlemek için Saflık Mahfazası'nı kullan ve onu Moonglade, Nighthaven'daki Rabine Saturna'ya götür." },
    [5527] = { ["name"] = "Bir Saflık Mahfazası", ["objective"] = "Silithus'a git ve Southwind Village harabelerinde bir Saflık Mahfazası ara. Bulabilirsen onu Moonglade, Nighthaven'daki Rabine Saturna'ya getir." },
    [5529] = { ["name"] = "Vebalı Yavrular", ["note"] = "20 Vebalı Yavru öldür. Bunu teslim ettikten sonra yavrular, Betina'ya tekrarlanabilir teslim başlatan Sağlıklı Ejderha Pulu düşürebilir.", ["objective"] = "20 Vebalı Yavru öldür, ardından Light's Hope Chapel'daki Betina Bigglezink'e dön." },
    [5531] = { ["name"] = "Betina Bigglezink", ["objective"] = "Donmuş Yumurtalar'ı Betina Bigglezink'e götür." },
    [5542] = { ["name"] = "İblis Köpekleri", ["objective"] = "20 Plaguehound Runt, 5 Plaguehound ve 5 Frenzied Plaguehound öldür. Görev tamamlanınca Tirion Fordring'e dön." },
    [5543] = { ["name"] = "Kanla Lekelenmiş Gökyüzü", ["objective"] = "30 Veba Yarasası öldür ve Tirion Fordring'e dön." },
    [5544] = { ["name"] = "Leş Yemeği", ["objective"] = "Bölgedeki Carrion Grub ve Devourer'ları bul. Onları öldür ve etlerini topla. 15 Dilim Leş Kurdu Eti topladığında Tirion Fordring'e dön.$B" },
    [5722] = { ["name"] = "Kayıp Çantayı Aramak", ["note"] = "İlk büyük üç yollu kavşaktan sağdaki tünele gir, onu yokuş yukarı çıkmaza doğru takip et, sonra soldaki küçük yan odaya gir. Oradaki Maur'un cesediyle etkileşime geç.", ["objective"] = "Ragefire Chasm'de Maur Grimtotem'in cesedini ara ve üzerinde ilgi çekici bir şey olup olmadığına bak.", ["turnin"] = "Maur Grimtotem'in cesedi, Ragefire Chasm içinde" },
    [5723] = { ["name"] = "Düşmanın Gücünü Sınamak", ["objective"] = "Orgrimmar'da Ragefire Chasm'i ara, ardından Thunder Bluff'taki Rahauro'ya dönmeden önce 8 Ragefire Trogg'u ve 8 Ragefire Şamanı öldür." },
    [5724] = { ["name"] = "Kayıp Çantayı Geri Götürmek", ["objective"] = "Grimtotem Çantası'nı Thunder Bluff'taki Rahauro'ya götür.", ["pickup"] = "Grimtotem Heybesi, Ragefire Chasm içindeki Maur Grimtotem'in cesedinden alınır" },
    [5725] = { ["name"] = "Yok Etme Gücü...", ["objective"] = "Gölge Büyüleri ve Nether'den Efsunlar adlı kitapları Undercity'deki Varimathras'a getir." },
    [5726] = { ["description"] = "Ragefire Chasm zinciri için gerekli ilk Hidden Enemies adımı.", ["name"] = "Gizli Düşmanlar", ["objective"] = "Orgrimmar'daki Thrall'a bir Teğmen Nişanı getir." },
    [5727] = { ["description"] = "Neeru, Ragefire Chasm girişinin yakınındaki Cleft of Shadow'da.", ["name"] = "Gizli Düşmanlar", ["objective"] = "Teğmen Nişanı'nı Neeru Fireblade'e götür ve onunla konuş. Seni Burning Blade üyesi sanıp sanmadığını anla, sonra Orgrimmar'daki Thrall'a dön." },
    [5728] = { ["name"] = "Gizli Düşmanlar", ["note"] = "Orgrimmar'daki önceki Hidden Enemies zincir adımları gerekir. Sonraki Hidden Enemies adımı daha sonra şunları sunar:", ["objective"] = "Orgrimmar'daki Thrall'a dönmeden önce Bazzalan'ı ve Çağırıcı Jergosh'u öldür." },
    [5742] = { ["name"] = "Kefaret", ["objective"] = "Tirion Fordring'in söyleyeceklerini dinle." },
    [5761] = { ["name"] = "Canavarı Öldürmek", ["objective"] = "Ragefire Chasm'e gir ve Aç Gözlü Taragaman'ı öldür, ardından kalbini Orgrimmar'daki Neeru Fireblade'e getir." },
    [5781] = { ["name"] = "Unutulmuş Anılar", ["objective"] = "Eastern Plaguelands'in en güney kesimindeki Undercroft'a git ve Taelan'ın Çekici'ni geri al. Hedefini tamamladıktan sonra Tirion Fordring'e dön." },
    [5845] = { ["name"] = "Kayıp Onur", ["objective"] = "Eastern Plaguelands'in kuzeydoğusundaki Northdale'e git ve Kayıp Onur Sembolü'nü geri al. Hedefini tamamladıktan sonra Tirion Fordring'e dön." },
    [5846] = { ["name"] = "Sevgi ve Aile", ["objective"] = "Veba Topraklarının güney-orta bölgesindeki Caer Darrow adasına git ve tablonun nerede olduğuna dair ipucu ara." },
    [5848] = { ["name"] = "Aşka ve Aileye Dair", ["note"] = "Arşivleri yakmadan önce Archivist Galford'un odasındaki ikiz aylar resminin arkasına gizlenmiş tabloyu al.", ["objective"] = "Plaguelands'in kuzeyindeki Stratholme'e git. 'Aşka ve Aileye Dair' tablosunu Scarlet Bastion'da, dünyamızın ikiz aylarını tasvir eden başka bir tablonun arkasına gizlenmiş hâlde bulacaksın.$B$BTabloyu Tirion Fordring'e getir." },
    [5961] = { ["name"] = "Banshee Kraliçesi'nin Şampiyonu", ["note"] = "Ramstein görevine götüren giriş adımı.", ["objective"] = "Eastern Plaguelands'deki Nathanos Blightcaller ile konuş. Söylendiğine göre Marris Stead'e yerleşmiş.$B", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [6022] = { ["name"] = "Bir Amaçla Öldürmek", ["objective"] = "Doğudaki Corin's Crossing'e git ve kasabada yaşayan Scourge'u katlet. 10 dakikadan kısa sürede 7 parça Canlı Çürük topla. Canlı Çürüğü Pıhtılaşmış Çürüğe öğütmek için Havan ve Tokmak'ı kullan." },
    [6042] = { ["name"] = "Ölümsüzlüğün Küçük Dertleri", ["objective"] = "20 Noxious Plaguebat ve 10 Monstrous Plaguebat öldür. Bitirince Nathanos Blightcaller'a dön." },
    [6133] = { ["name"] = "Korucu Lordun Emri", ["objective"] = "Eastern Plaguelands'in kuzey sınırlarına git ve Quel'Thalas Kaydı'nı geri al. Eşya Quel'Lithien kulübesinde bir yerde.$B$BAyrıca 8 Ranger, 8 Pathstrider ve 8 Woodsman öldürmelisin." },
    [6135] = { ["name"] = "Duskwing, Ah Senden Nasıl Nefret Ediyorum...", ["objective"] = "Duskwing'i bul ve öldür. Cesedinden bir Duskwing Tüyü Parçası al ve Nathanos Blightcaller'a getir.$B$BDuskwing'in Marris Stead'in kuzeyindeki kırsalda dolaştığı söyleniyor." },
    [6136] = { ["name"] = "Şişko Olan", ["objective"] = "Eastern Plaguelands'in kuzey çorak topraklarında Borelgore'u bul ve yok et. Görev tamamlanınca Nathanos Blightcaller'a dön." },
    [6141] = { ["name"] = "Brother Anton", ["note"] = "In the Name of the Light görevine götüren giriş adımı.", ["objective"] = "Desolace'taki Brother Anton ile konuş.", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [6163] = { ["name"] = "Ramstein", ["note"] = "İsteğe bağlı giriş görevi:", ["objective"] = "Stratholme'e git ve Obur Ramstein'ı öldür. Nathanos için hatıra olarak kafasını al." },
    [629] = { ["name"] = "Vile Reef", ["objective"] = "Grom'gol Üssü'ndeki Kin'weelay'e bir Tablet Parçası getir.", ["warning"] = "Grup görevi: Vile Reef'teki Saltscale murlocları elit." },
    [6402] = { ["name"] = "Stormwind Buluşması", ["objective"] = "Stormwind City'ye git ve şehir kapılarına ilerle. Marshal Windsor'a geldiğini bildirmesi için Squire Rowe ile konuş." },
    [6403] = { ["name"] = "Büyük Maskeli Balo", ["objective"] = "Reginald Windsor'u Stormwind boyunca takip et. Onu zarardan koru!" },
    [65] = { ["description"] = "Gerekli Defias Brotherhood zincirinin ilk adımı.", ["name"] = "Defias Kardeşliği", ["objective"] = "Gryan Stoutmantle, Lakeshire'daki Wiley ile konuşmanı istiyor." },
    [6501] = { ["name"] = "Ejderhanın Gözü", ["objective"] = "Ejderhanın Gözü Parçası'nın gücünü geri getirebilecek bir varlık için dünyayı ara. Böyle bir varlık hakkında sahip olduğun tek bilgi, var olduğu." },
    [6502] = { ["name"] = "Drakefire Muskası", ["note"] = "Onyxia uyumlanmasının parçası.", ["objective"] = "Kara Ejderha Şampiyonunun Kanı'nı General Drakkisath'tan almalısın. Drakkisath, Blackrock Spire'da Yükseliş Salonları'nın ardındaki taht odasında bulunabilir." },
    [6521] = { ["description"] = "Son adım. Ambassador Malcin, Razorfen Downs'ın dışında.", ["name"] = "Kirli Bir İttifak", ["note"] = "Ambassador Malcin, zindan portalından önce, dış diken labirentindeki çadırlarda. Razorfen Kraul'da Charlga Razorflank'in düşürdüğü Küçük Parşömen ile başlar.", ["objective"] = "Elçi Malcin'in Kafası'nı Undercity'deki Varimathras'a getir.", ["warning"] = "Bu görev Razorfen Downs'ın DIŞINDAKİ bölgede tamamlanır." },
    [6522] = { ["name"] = "Kirli Bir İttifak", ["objective"] = "Küçük Parşömen'i Undercity'deki Varimathras'a götür.", ["pickup"] = "Küçük Parşömen, Charlga Razorflank düşürür" },
    [6561] = { ["name"] = "Blackfathom'un Kötülüğü", ["objective"] = "Alacakaranlık Lordu Kelris'in başını Thunder Bluff'taki Bashana Runetotem'e götür.", ["pickup"] = "Argent Guard Thaelrid, Blackfathom Deeps içinde" },
    [6562] = { ["name"] = "Derinliklerdeki Sorun", ["note"] = "The Essence of Aku'Mai görevine götüren giriş adımı.", ["objective"] = "Ashenvale'deki Je'neu Sancrea ile konuş.", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [6563] = { ["name"] = "Aku'Mai'nin Özü", ["note"] = "İsteğe bağlı giriş görevi:", ["objective"] = "20 Aku'Mai Safiri'ni Ashenvale'deki Je'neu Sancrea'ya götür.", ["pickup"] = "Je'neu Sancrea, Zoram'gar Outpost, Ashenvale (12, 34)" },
    [6564] = { ["name"] = "Kadim Tanrılara Bağlılık", ["objective"] = "Islak Not'u Ashenvale'deki Je'neu Sancrea'ya götür.", ["pickup"] = "Blackfathom Tide Priestess'lerin düşürdüğü Nemli Not'u kullan" },
    [6565] = { ["name"] = "Kadim Tanrılara Bağlılık", ["note"] = "Allegiance to the Old Gods görevinin Nemli Not sürümünden sonra gelir.", ["objective"] = "Blackfathom Deeps'te Lorgus Jett'i öldür ve ardından Ashenvale'deki Je'neu Sancrea'ya dön.", ["pickup"] = "Je'neu Sancrea, Zoram'gar Outpost, Ashenvale (12, 34)" },
    [6566] = { ["name"] = "Rüzgârın Taşıdıkları", ["objective"] = "Thrall'ı dinle." },
    [6567] = { ["name"] = "Horde'un Şampiyonu", ["objective"] = "Rexxar'ı bul. Savaş Şefi sana nerede olduğunu anlattı. Stonetalon Mountains ile Feralas arasındaki Desolace yollarını ara." },
    [6568] = { ["name"] = "Rexxar'ın Vasiyeti", ["objective"] = "Rexxar'ın Mektubunu Western Plaguelands'teki Cadı Myranda'ya teslim et." },
    [6569] = { ["name"] = "Oculus İllüzyonları", ["note"] = "Horde Onyxia zincirinin parçası. Kara Ejderha Yavrusu Gözleri UBRS'deki dragonspawn'lardan düşer.", ["objective"] = "Blackrock Spire'a git ve 20 Kara Ejderha Türevi Gözü topla. Görev tamamlandığında Cadı Myranda'ya dön." },
    [6570] = { ["name"] = "Emberstrife", ["objective"] = "Dustwallow Marsh'taki Wyrmbog'a git ve Emberstrife'ın İni'ni bul. İçeri girince Ejderha Yıkım Muskası'nı tak ve Emberstrife ile konuş." },
    [6582] = { ["name"] = "Kafatası Sınavı, Scryer", ["objective"] = "Mavi ejderha soyunun ejder şampiyonu Scryer'ı bul ve öldür. Kafatasını cesedinden sök ve Emberstrife'a getir.$B$BScryer'ın Winterspring'de bulunabileceğini biliyorsun." },
    [6583] = { ["name"] = "Kafatası Sınavı, Somnus", ["objective"] = "Yeşil Soy'un ejder şampiyonu Somnus'u yok et. Kafatasını al ve Emberstrife'a getir." },
    [6584] = { ["name"] = "Kafatası Sınavı, Chronalis", ["objective"] = "Tanaris Çölü'ndeki Caverns of Time'ı Nozdormu'nun çocuğu Chronalis koruyor. Onu yok et ve kafatasını Emberstrife'a getir." },
    [6585] = { ["name"] = "Kafatası Sınavı, Axtroz", ["objective"] = "Grim Batol'a git ve Kızıl Soy'un ejder şampiyonu Axtroz'un izini sür. Onu yok et ve kafatasını al. Kafatasını Emberstrife'a getir." },
    [6601] = { ["name"] = "Yükseliş...", ["objective"] = "Görünüşe göre maskaralık bitti. Cadı Myranda'nın senin için yaptığı Ejderha Yıkım Muskası'nın Blackrock Spire'da çalışmayacağını biliyorsun. Belki Rexxar'ı bulup durumunu açıklamalısın. Ona Sönük Ejder Ateşi Muskası'nı göster. Umarım ne yapılacağını bilir." },
    [6602] = { ["name"] = "Kara Ejderha Şampiyonu'nun Kanı", ["note"] = "Onyxia uyumlanmasının parçası.", ["objective"] = "Blackrock Spire'a git ve General Drakkisath'ı öldür. Kanını topla ve Rexxar'a götür." },
    [6626] = { ["name"] = "Kötülük Ordusu", ["note"] = "Bu yaratıklar zindanın dışında, girişin çevresinde.", ["objective"] = "8 Razorfen Savaş Muhafızı, 8 Razorfen Dikenördücüsü ve 8 Death's Head Tarikatçısı öldür ve Razorfen Downs girişinin yakınındaki Myriam Moonsinger'a dön.", ["pickup"] = "Myriam Moonsinger, Razorfen Downs diken labirenti, The Barrens", ["turnin"] = "Myriam Moonsinger, Razorfen Downs diken labirenti, The Barrens" },
    [6627] = { ["name"] = "Bilgi Sınavı", ["objective"] = "Braug Dimspirit'in sorusunu doğru cevapla, sonra onunla tekrar konuş. Hazır olduğunda Stonetalon Mountains'ta olacak.", ["warning"] = "CEVAP: Neltharion" },
    [6628] = { ["name"] = "Bilgi Sınavı", ["objective"] = "Parqual Fintallas'ın sorusunu doğru cevapla, sonra onunla tekrar konuş. Sen hazır olana dek Undercity'de kalacak.", ["warning"] = "CEVAP: Ner'zhul" },
    [6921] = { ["name"] = "Harabelerin Arasında", ["note"] = "Fathom Taşı, isteğe bağlı Baron Aquanis karşılaşmasıyla da ilişkilidir.", ["objective"] = "Derinlik Çekirdeği'ni Ashenvale'deki Zoram'gar Üssü'nde bulunan Je'neu Sancrea'ya götür.", ["pickup"] = "Je'neu Sancrea, Zoram'gar Outpost, Ashenvale (12, 34)" },
    [6922] = { ["name"] = "Baron Aquanis", ["objective"] = "Tuhaf Su Küresini Ashenvale'de Zoram'gar Outpost'taki Je'neu Sancrea'ya getir.", ["pickup"] = "Garip Su Küresi, Blackfathom Deeps içinde Baron Aquanis düşürür", ["warning"] = "Baron Aquanis, 'Amongst the Ruins' görevindeki Fathom Çekirdeği alınınca ortaya çıkar." },
    [6981] = { ["name"] = "Parlayan Kristal Parçası", ["note"] = "Doğrudan görevin eşya ödülü yok. Devamı olan In Nightmares daha sonra şunları sunar:", ["objective"] = "Parlayan parça hakkında sana daha fazlasını anlatabilecek birini bulmak için Ratchet'a git.$B$BArdından parçayı sana söylenen yere teslim et.", ["objectiveWhere"] = "Sputtervalve, Ratchet'taki uçuş ustasının yanında (63.0, 37.2); başının üstünde ? yok", ["pickup"] = "Eşyayla başlar: Glowing Shard, Mutanus the Devourer düşürür", ["turnin"] = "Falla Sagewind, Wailing Caverns'ın üstündeki dağın tepesinde, The Barrens (48.2, 32.8)" },
    [7028] = { ["name"] = "Çarpık Kötülükler", ["note"] = "Maraudon'daki her yaratık Theradric Kristal Oymalarını düşürebilir.", ["objective"] = "Desolace'taki Willow için 15 Theradric Kristal Oyması topla." },
    [7029] = { ["name"] = "Vyletongue Yozlaşması", ["note"] = "Kaplanmış Gök Mavisi Şişe'yi dış mağaralardaki turuncu kristal havuzunda doldur, sonra içerideki (turuncu taraf) Vylestem Sarmaşıkları üzerinde kullan ve 8 bitkiyi iyileştirmek için Noxxious Scion'ları öldür.", ["objective"] = "Kaplamalı Gök Mavisi Şişe'yi Maraudon'daki turuncu kristal havuzda doldur.$B$BDolu Gök Mavisi Şişe'yi Vylestem Sarmaşıkları üzerinde kullanarak yozlaşmış Noxxious Filizi'nin ortaya çıkmasını sağla.$B$BBu Noxxious Filizleri'ni öldürerek 8 bitkiyi iyileştir, ardından Shadowprey Village'daki Vark Battlescar'a dön." },
    [704] = { ["name"] = "Agmond'un Akıbeti", ["note"] = "Küpler, zindan portalından önce, dış Uldaman mağarasında.\n\nİsteğe bağlı giriş görevi:", ["objective"] = "Loch Modan'daki Kâşif Ironband'e 4 Oyma Taş Kavanoz getir." },
    [7041] = { ["name"] = "Vyletongue Yozlaşması", ["note"] = "Kaplanmış Gök Mavisi Şişe'yi dış mağaralardaki turuncu kristal havuzunda doldur, sonra içerideki (turuncu taraf) Vylestem Sarmaşıkları üzerinde kullan ve 8 bitkiyi iyileştirmek için Noxxious Scion'ları öldür.", ["objective"] = "Kaplamalı Gök Mavisi Şişe'yi Maraudon'daki turuncu kristal havuzda doldur.$B$BDolu Gök Mavisi Şişe'yi Vylestem Sarmaşıkları üzerinde kullanarak yozlaşmış Noxxious Filizi'nin ortaya çıkmasını sağla.$B$BBu Noxxious Filizleri'ni öldürerek 8 bitkiyi iyileştir, ardından Nijel's Point'teki Talendria'ya dön." },
    [7044] = { ["name"] = "Maraudon Efsaneleri", ["note"] = "Celebrian Asası Noxxion'dan, Celebrian Elması ise Lord Vyletongue'dan düşer.", ["objective"] = "Celebras Asası'nın iki parçasını geri al: Celebrian Çubuğu ve Celebrian Elması.$B$BCelebras ile konuşmanın bir yolunu bul." },
    [7046] = { ["name"] = "Celebras Asası", ["note"] = "Yolların birleştiği yerde Celebras the Cursed'ü yen ve Legends of Maraudon'u Celebras the Redeemed'e teslim et, sonra ritüeline yardım et ve asa için onunla tekrar konuş.", ["objective"] = "Kurtarılmış Celebras, Celebras Asası'nı yaratırken ona yardım et.$B$BRitüel tamamlandığında onunla konuş." },
    [7064] = { ["name"] = "Toprağın ve Tohumun Yozlaşması", ["note"] = "İç mağarada Princess Theradras'ı öldür.", ["objective"] = "Prenses Theradras'ı öldür ve Desolace'taki Shadowprey Village yakınlarında bulunan Selendra'ya dön." },
    [7065] = { ["name"] = "Toprağın ve Tohumun Yozlaşması", ["note"] = "İç mağarada Princess Theradras'ı öldür.", ["objective"] = "Prenses Theradras'ı öldür ve Desolace'taki Nijel's Point'te bulunan Bekçi Marandis'e dön." },
    [7066] = { ["name"] = "Yaşam Tohumu", ["note"] = "Zaetar's Spirit, Princess Theradras öldükten sonra belirir.", ["objective"] = "Moonglade'deki Remulos'u bul ve ona Yaşam Tohumu'nu ver." },
    [7067] = { ["name"] = "Dışlanmışın Talimatları", ["note"] = "Dış mağaralardaki Nameless Prophet'ten Ruhlar Muskası'nı al, sonra beş Khan ile savaşmak için kullan: üçü dış mağaralarda, biri mor rotada ve biri turuncu rotada. Taşlarını muskayla birleştir.", ["objective"] = "Dışlanmışın Talimatları'nı oku. Ardından Maraudon'dan Birlik Tılsımı'nı al ve güney Desolace'taki Kentaur Dışlanmışı'na götür.", ["pickup"] = "Centaur Pariah, güney Desolace", ["turnin"] = "Centaur Pariah, güney Desolace" },
    [7068] = { ["name"] = "Gölge Kırığı Parçaları", ["note"] = "Dıştaki mor kristalli mağaralardaki Shadowshard elementalleri. Zindana girmeden yapılabilir.", ["objective"] = "Maraudon'dan 10 Gölge Kırığı Parçası topla ve Orgrimmar'daki Uthel'nay'a götür." },
    [707] = { ["name"] = "Ironband Seni İstiyor!", ["note"] = "Agmond's Fate görevine götüren giriş adımı.", ["objective"] = "Loch Modan'daki Ironband Kazı Alanı'nda Maden Arayıcısı Ironband ile konuş.", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [7070] = { ["name"] = "Gölge Kırığı Parçaları", ["note"] = "Dıştaki mor kristalli mağaralardaki Shadowshard elementalleri. Zindana girmeden yapılabilir.", ["objective"] = "Maraudon'dan 10 Gölge Kırığı Parçası topla ve Dustwallow Marsh kıyısındaki Theramore'da bulunan Başbüyücü Tervosh'a götür." },
    [709] = { ["name"] = "Kıyamete Çare", ["objective"] = "Ryun'eh Tableti'ni Kayıp Theldurin'e getir." },
    [720] = { ["name"] = "Bir Umut İşareti", ["objective"] = "Maden Arayıcı Ryedol'u bul ve ona Hammertoe Grez'in hayatta olduğunu bildir." },
    [7201] = { ["name"] = "Son Element", ["note"] = "Elementlerin Özü, BRD elementallerinden ve golemlerinden düşer.", ["objective"] = "Blackrock Depths'e git ve 10 Elementlerin Özü topla. İlk aklına gelen golemleri ve golem yapımcılarını aramak. Vivian Lagrave'in de elementallerle ilgili bir şeyler mırıldandığını hatırlıyorsun.$B" },
    [721] = { ["name"] = "Bir Umut Işığı", ["objective"] = "Uldaman'da Hammertoe Grez'i bul." },
    [722] = { ["name"] = "Sırlar Muskası", ["objective"] = "Hammertoe'nun Muskası'nı bul ve Uldaman'da ona geri götür.", ["pickup"] = "Hammertoe Grez, Uldaman kazısı (zindanın dışında)", ["turnin"] = "Hammertoe Grez, Uldaman kazısı (zindanın dışında)" },
    [723] = { ["name"] = "İnanç Arayışı", ["objective"] = "Hammertoe'nun Muskasını Badlands'teki Maden Arayıcı Ryedol'a götür." },
    [724] = { ["name"] = "İnanç Arayışı", ["objective"] = "Hammertoe'nun Muskasını Ironforge'daki Tarihçi Karnik'e götür." },
    [725] = { ["name"] = "Tehdit Haberini İletmek", ["objective"] = "Danışman Belgrum'u bul ve notunu ona ver." },
    [726] = { ["name"] = "Tehdit Haberini İletmek", ["objective"] = "Tarihçi Karnik ile konuş." },
    [738] = { ["name"] = "Agmond'u Bul", ["objective"] = "Agmond'u bul." },
    [739] = { ["name"] = "Murdaloc", ["objective"] = "Agmond'un katili Murdaloc'u öldür.$B$B12 Stonevault Bonesnapper öldür.$B$BLoch Modan'daki Maden Arayıcı Ironband'e rapor ver." },
    [7441] = { ["name"] = "Pusillin ve Yaşlı Azj'Tordin", ["note"] = "Pusillin'i kanat boyunca kovala ve o savaşana kadar onunla konuş, sonra kitap için onu öldür. Hilal Anahtarı'nı da düşürür.", ["objective"] = "Dire Maul'a git ve imp Pusillin'i bul. Gereken her yolu kullanarak Pusillin'i sana Azj'Tordin'in Büyü Kitabı'nı vermeye ikna et.$B$BBüyü Kitabı'nı geri alırsan Feralas'taki Lariss Pavilion'da bulunan Azj'Tordin'e dön." },
    [7461] = { ["name"] = "İçerideki Delilik", ["note"] = "Beş pilonun hepsinin muhafızlarını, sonra Immol'thar'ı, sonra Prince Tortheldrin'i öldür. Ancient'a dön, The Treasure of the Shen'dralar'ı al ve ödül için kütüphane merdivenlerinin altındaki sandığı aç.", ["objective"] = "Immol'thar'ın Hapishanesi'ne güç veren 5 Kule'yi çevreleyen muhafızları yok etmelisin. Kuleler devre dışı kaldığında Immol'thar'ı çevreleyen güç kalkanı dağılmış olacak.$B$BSonra Immol'thar'ın Hapishanesi'ne gir ve kalbinde duran iğrenç iblisi yok et. Son olarak Athenaeum'da Prens Tortheldrin'le yüzleş.$B$BBu görevi tamamlarsan avludaki Shen'dralar Kadimi'ne dön." },
    [7463] = { ["name"] = "Gizemli Ferahlık", ["note"] = "Mage sınıf görevi. Lydros, Athenaeum'da (Kuzey/Batı); Hydrospawn Özü, Doğu'daki Hydrospawn'dan düşer. Ödül: Conjure Water (Rütbe 7).", ["objective"] = "Dire Maul'un Warpwood Quarter bölgesine git ve su elementali Hydrospawn'ı öldür. Hydrospawn Özü ile Athenaeum'daki Bilge Lydros'a dön." },
    [7481] = { ["name"] = "Elf Efsaneleri", ["note"] = "Athenaeum'da Lorekeeper Lydros'un yanındaki Telmius Dreamseeker'ın İskelet Kalıntıları ile etkileşime geç. Lydros'un libram takaslarını açar.", ["objective"] = "Dire Maul'da Kariel Winthalus'u ara. Bulabildiğin her bilgiyle Camp Mojache'deki Bilge Korolusk'a rapor ver." },
    [7482] = { ["name"] = "Elf Efsaneleri", ["note"] = "Athenaeum'da Lorekeeper Lydros'un yanındaki Telmius Dreamseeker'ın İskelet Kalıntıları ile etkileşime geç. Lydros'un libram takaslarını açar.", ["objective"] = "Dire Maul'da Kariel Winthalus'u ara. Bulabildiğin her bilgiyle Feathermoon'daki Bilgin Runethorn'a rapor ver." },
    [7483] = { ["name"] = "Çabukluk Duaları Kitabı", ["note"] = "Tekrarlanabilir. Önce fraksiyonunun Elven Legends görevinin teslim edilmiş olması gerekir.", ["objective"] = "Çabukluk Mührü almak için bir Çabukluk Duaları Kitabı, 1 Kusursuz Siyah Elmas, 2 Büyük Parlak Kristal ve 2 Kahramanların Kanı'nı Dire Maul'daki Bilge Lydros'a getir." },
    [7484] = { ["name"] = "Odak Duaları Kitabı", ["note"] = "Tekrarlanabilir. Önce fraksiyonunun Elven Legends görevinin teslim edilmiş olması gerekir.", ["objective"] = "Odak Mührü almak için bir Odak Duaları Kitabı, 1 Kusursuz Siyah Elmas, 4 Büyük Parlak Kristal ve 2 Gölge Derisi'ni Dire Maul'daki Bilge Lydros'a getir." },
    [7485] = { ["name"] = "Koruma Duaları Kitabı", ["note"] = "Tekrarlanabilir. Önce fraksiyonunun Elven Legends görevinin teslim edilmiş olması gerekir.", ["objective"] = "Koruma Mührü almak için bir Koruma Duaları Kitabı, 1 Kusursuz Siyah Elmas, 2 Büyük Parlak Kristal ve 1 Yıpranmış Abomination Dikişi'ni Dire Maul'daki Bilge Lydros'a getir." },
    [7488] = { ["name"] = "Lethtendris'in Ağı", ["note"] = "Ağ, Lethtendris'ten düşer.\n\nİsteğe bağlı giriş görevi:", ["objective"] = "Lethtendris'in Ağı'nı Feralas'taki Feathermoon Stronghold'da bulunan Latronicus Moonspear'a götür." },
    [7489] = { ["name"] = "Lethtendris'in Ağı", ["note"] = "Ağ, Lethtendris'ten düşer.\n\nİsteğe bağlı giriş görevi:", ["objective"] = "Lethtendris'in Ağı'nı Feralas'taki Camp Mojache'de bulunan Talo Thornhoof'a götür." },
    [7492] = { ["name"] = "Camp Mojache", ["note"] = "Lethtendris's Web görevine götüren giriş adımı.", ["objective"] = "Feralas'taki Camp Mojache'de bulunan Talo Thornhoof ile konuş.", ["pickup"] = "Harbinger Balthazad, Undercity (veya Warcaller Gorlach, Orgrimmar / Bluff Runner Windstrider, Thunder Bluff)", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [7494] = { ["name"] = "Feathermoon Stronghold", ["note"] = "Lethtendris's Web görevine götüren giriş adımı.", ["objective"] = "Feralas'taki Feathermoon Stronghold'da bulunan Latronicus Moonspear ile konuş.", ["pickup"] = "Crier Goodman, Stormwind (veya Courier Hammerfall, Ironforge / Herald Moonstalker, Darnassus)", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [7498] = { ["name"] = "Garona: Gizlilik ve İhanet Üzerine Bir İnceleme", ["note"] = "Rogue sınıf kitabı. Görevi başlatmak için kitaba tıkla.", ["objective"] = "Kitabı gerçek sahiplerine geri götür.", ["pickup"] = "Garona: A Study on Stealth and Treachery (kitap, Dire Maul ganimeti)" },
    [7499] = { ["name"] = "Savunma Kodeksi", ["note"] = "Warrior sınıf kitabı. Görevi başlatmak için kitaba tıkla.", ["objective"] = "Kitabı gerçek sahiplerine geri götür.", ["pickup"] = "Codex of Defense (kitap, Dire Maul ganimeti)" },
    [7500] = { ["name"] = "Arcanist'in Yemek Kitabı", ["note"] = "Mage sınıf kitabı. Görevi başlatmak için kitaba tıkla.", ["objective"] = "Kitabı gerçek sahiplerine geri götür.", ["pickup"] = "The Arcanist's Cookbook (kitap, Dire Maul ganimeti)" },
    [7501] = { ["name"] = "Işık ve Onu Nasıl Savurmalı", ["note"] = "Paladin sınıf kitabı. Görevi başlatmak için kitaba tıkla.", ["objective"] = "Kitabı gerçek sahiplerine geri götür.", ["pickup"] = "The Light and How To Swing It (kitap, Dire Maul ganimeti)" },
    [7502] = { ["name"] = "Gölgeleri Dizginlemek", ["note"] = "Warlock sınıf kitabı. Görevi başlatmak için kitaba tıkla.", ["objective"] = "Kitabı gerçek sahiplerine geri götür.", ["pickup"] = "Harnessing Shadows (kitap, Dire Maul ganimeti)" },
    [7503] = { ["name"] = "Avcıların En Büyük Irkı", ["note"] = "Hunter sınıf kitabı. Görevi başlatmak için kitaba tıkla.", ["objective"] = "Kitabı gerçek sahiplerine geri götür.", ["pickup"] = "The Greatest Race of Hunters (kitap, Dire Maul ganimeti)" },
    [7504] = { ["name"] = "Kutsal Saçmalık: Işık'ın Sana Söylemedikleri", ["note"] = "Priest sınıf kitabı. Görevi başlatmak için kitaba tıkla.", ["objective"] = "Kitabı gerçek sahiplerine geri götür.", ["pickup"] = "Holy Bologna: What the Light Won't Tell You (kitap, Dire Maul ganimeti)" },
    [7505] = { ["name"] = "Ayaz Şoku ve Sen", ["note"] = "Shaman sınıf kitabı. Görevi başlatmak için kitaba tıkla.", ["objective"] = "Kitabı gerçek sahiplerine geri götür.", ["pickup"] = "Frost Shock and You (kitap, Dire Maul ganimeti)" },
    [7506] = { ["name"] = "Zümrüt Rüya...", ["note"] = "Druid sınıf kitabı. Görevi başlatmak için kitaba tıkla.", ["objective"] = "Kitabı gerçek sahiplerine geri götür.", ["pickup"] = "The Emerald Dream (kitap, Dire Maul ganimeti)" },
    [7507] = { ["name"] = "Foror'un Derlemesi", ["note"] = "Warrior ve Paladin'ler. Lydros ardından Onyxia's Lair'de tamamlanan The Forging of Quel'Serrar'ı verir.", ["objective"] = "Foror'un Ejderha Avcılığı Derlemesi'ni Athenaeum'a geri götür.", ["pickup"] = "Nostro's Compendium of Dragon Slaying (nadir Dire Maul ganimeti)" },
    [7563] = { ["name"] = "Kanın Öfkesi", ["objective"] = "30 şişe Kudurmuş Canavar Kanı'nı Burning Steppes'teki Mor'zul Bloodbringer'a getir." },
    [7564] = { ["name"] = "Wildeyes", ["objective"] = "Kan Kutusu'nu Burning Steppes'teki Gorzeeki Wildeyes'a getir." },
    [7604] = { ["name"] = "Bağlayıcı Bir Sözleşme", ["note"] = "Demircilik. Sözleşmeyi almak için Grim Guzzler'daki Lokhtos'a bir Sulfuron Külçesi (Golemagg, Molten Core) getir, sonra Sulfuron Çekici planları için geri teslim et.", ["objective"] = "Sulfuron planlarını almak istiyorsan Thorium Brotherhood Sözleşmesi'ni Lokhtos Darkbargainer'a teslim et.", ["pickup"] = "Thorium Brotherhood Sözleşmesi (bir Sulfuron Külçesi karşılığında Lokhtos Darkbargainer'dan)" },
    [762] = { ["name"] = "Bir Kötülük Elçisi", ["objective"] = "Angor Fortress'ta Ambassador Infernus'u öldür ve ölümünün kanıtını Ironforge'daki Danışman Belgrum'a getir." },
    [7623] = { ["name"] = "Lord Banehollow", ["objective"] = "Burning Steppes'teki Gorzeeki'den Gölgeli İksir satın al.$B$BBu iksirleri kullanarak Jaedenar'dan geç ve Lord Banehollow ile konuş." },
    [7624] = { ["name"] = "Hain Ulathek", ["objective"] = "Ulathek ile yüzleş, ardından Hainin Kalbi'ni Jaedenar'daki Lord Banehollow'a getir." },
    [7625] = { ["name"] = "Xoroth Yıldız Tozu", ["objective"] = "Ur'dan'dan Xoroth Yıldız Tozu satın al. Onu Burning Steppes'teki Gorzeeki Wildeyes'a getir." },
    [7626] = { ["name"] = "Dethmoora'nın Çanı", ["objective"] = "10 Gölge Gücü İksiri'ni Burning Steppes'teki Gorzeeki Wildeyes'a getir." },
    [7627] = { ["name"] = "Kara Yürüyüş Çarkı", ["objective"] = "6 Büyük Parlak Kırık ve 25 Dark Iron Cevheri'ni Burning Steppes'teki Gorzeeki'ye getir." },
    [7628] = { ["name"] = "Kıyamet Mumu", ["objective"] = "35 Kara Ejderha Pulu'nu Burning Steppes'teki Gorzeeki Wildeyes'a getir." },
    [7629] = { ["name"] = "Imp Teslimatı", ["note"] = "Warlock dreadsteed görevi. Ras Frostwhisper'ın odasındaki simya laboratuvarında Kavanozdaki İmp'i serbest bırak ve parşömeni bekle.", ["objective"] = "Kavanozdaki Imp'i Scholomance'taki simya laboratuvarına götür. Parşömen yapıldıktan sonra kavanozu Gorzeeki Wildeyes'a geri getir." },
    [7630] = { ["name"] = "Arcanite", ["objective"] = "3 Arcanite Külçesi'ni Burning Steppes'teki Gorzeeki'ye getir." },
    [7631] = { ["name"] = "Xoroth'un Dreadsteed'i", ["note"] = "Warlock dreadsteed görevi. Immol'thar öldükten sonra J'eevee'nin Kavanozu, Kara Mıknatıs Taşı ve Xorothian Glifleri ile onun hapishanesinde ritüeli yap. Ruh Kırıkları getir.", ["objective"] = "Mor'zul'un Talimatları'nı oku. Bir Xoroth Dreadsteed'i çağır, onu yen ve ruhunu kendine bağla." },
    [7637] = { ["name"] = "Fedakârlığa Vurgu", ["objective"] = "Ironforge'a git ve Yüksek Rahip Rohan'ın Şeytan Kovma Buhurdanı'nı al. Onu edinmek için 150 altın bağış yapman gerekecek." },
    [7639] = { ["name"] = "Hak Edilmiş Adaleti Göstermek", ["objective"] = "Şeytan Kovma Buhurdanı'nı Stormwind'in Cathedral District'indeki Lord Grayson Shadowbreaker'a götür." },
    [7640] = { ["name"] = "Terrordale'i Arındırmak", ["objective"] = "Şeytan Kovma Buhurdanı'nı kullanarak Terrordale'e eziyet eden ruhları kov. 25 Terrordale Ruhu'nu öldürdüğünde Stormwind'in Cathedral District'indeki Lord Grayson Shadowbreaker'a dön." },
    [7641] = { ["name"] = "Grimand Elmore'un Ustalığı", ["objective"] = "Stormwind'in Dwarven District'indeki Grimand Elmore ile konuş." },
    [7642] = { ["name"] = "Malzeme Toplama", ["objective"] = "40 Runecloth, 6 Arcanite Külçesi, 10 Arthas' Tears, 5 şişe Stratholme Kutsal Suyu ve 150 altını Stormwind'in Dwarven District'indeki Grimand Elmore'a götür." },
    [7643] = { ["name"] = "Kadim At Ruhu", ["note"] = "Paladin savaş atı görevi. Tendris Warpwood'u öldür, sonra Ancient Equine Spirit'i besle ve ona Arcanite Barding'i ver. Manna ile Zenginleştirilmiş At Yemi'ni Southshore'daki Merideth Carlson'dan getir.", ["objective"] = "Bir ruh atını beslemek için kullanılan özel at yemini edin. Görünüşe göre bu yemin kaynağı Southshore'daki Merideth Carlson.$B$BFeralas'taki Dire Maul zindanına git ve Tendris Warpwood'u öldür. Böylece Kadim At Ruhu'nu özgür bırakacaksın. Ona özel at yemini yedirerek ruhu yatıştır. Son olarak, kutsaması için ona Arcanite At Zırhı'nı ver." },
    [7644] = { ["name"] = "Kutsanmış Arcanite At Zırhı", ["objective"] = "Kutsanmış Arcanite At Zırhı ile Stormwind'in Cathedral District'indeki Lord Grayson Shadowbreaker'a dön." },
    [7645] = { ["name"] = "Mana ile Zenginleştirilmiş At Yemi", ["objective"] = "Southshore, Hillsbrad Foothills'teki Merideth Carlson için Mana ile Zenginleştirilmiş At Yemi'nin temel malzemesi olan 20 Zenginleştirilmiş Mana Bisküvisi getir. Bisküvilerin tek satıcısının Argent Dawn olduğu biliniyor.$B$BAyrıca kırılan gururunu okşamak için ona 50 altın vermen gerekiyor." },
    [7646] = { ["name"] = "Kehanet Kristali", ["objective"] = "Bir Azerothian Elmas ile bir Kusursuz Kara Elmas'ı Stormwind'in Cathedral District'indeki Lord Grayson Shadowbreaker'a götür." },
    [7647] = { ["name"] = "Hüküm ve Kurtuluş", ["note"] = "Paladin savaş atı görevi. Great Ossuary'de Rattlegore'un bodrumunu temizle, Divination Scryer'ı kullan ve ruhları ve Death Knight Darkreaver'ı yen.", ["objective"] = "Kehanet Kristali'ni Scholomance'taki Great Ossuary'nin bodrumunun tam ortasında kullan. Bu, yargılaman gereken ruhları ortaya çıkaracak. Bu ruhları yenmek Ölüm Şövalyesi Darkreaver'ı çağıracak. Onu yen ve düşmüş savaş atının kayıp ruhunu geri al.$B$BSavaş Atının Kurtarılmış Ruhu'nu ve Kutsanmış Efsunlu At Zırhı'nı Darkreaver'ın Düşmüş Savaş Atı'na ver." },
    [7648] = { ["name"] = "Grimand'ın En İyi İşi", ["objective"] = "Arcanite At Zırhı'nı incelemesi için Stormwind'in Cathedral District'indeki Lord Grayson Shadowbreaker'a götür." },
    [7667] = { ["name"] = "Maddi Yardım", ["objective"] = "Orgrimmar'ın Valley of Wisdom bölgesindeki Sagorne Crestrider'a yardım etmek istersen ona bir Azeroth Elması ve bir Kusursuz Kara Elmas getir." },
    [7668] = { ["name"] = "Darkreaver Tehdidi", ["note"] = "Shaman görevi. Rattlegore'un bodrumunu temizle, kâhin aletini kullan ve Death Knight Darkreaver'ı yen; kafasını geri getir.", ["objective"] = "Scholomance'taki Great Ossuary'nin bodrumunun tam ortasında Kehanet Aleti'ni kullan. Bu, savaşman gereken ruhları ortaya çıkaracak. Bu ruhları yenmek Ölüm Şövalyesi Darkreaver'ı çağıracak; onu yen.$B$BDarkreaver'ın Kellesi'ni Orgrimmar'daki Valley of Wisdom'da Sagorne Creststrider'a götür." },
    [7703] = { ["name"] = "Gordok'un Yarım Kalan İşi", ["note"] = "Batı hedefi: Gordok Gücü Eldiveni, Prince Tortheldrin'in yakınındaki bir sandıkta. Görevin kendisi, Gordok kralı olduktan sonra Dire Maul North'taki dost Captain Kromcrush'tan gelir.", ["objective"] = "Gordok Kudreti Demir Eldiveni'ni bul ve Dire Maul'daki Kaptan Kromcrush'a geri getir.$B$BKromcrush'a göre \"eski zaman hikâyesi\", kendine prens diyen \"ürkütücü\" bir elf olan Tortheldrin'in onu Gordok krallarından birinden çaldığını söylüyor." },
    [7761] = { ["name"] = "Blackhand'in Emri", ["note"] = "Scarshield Quartermaster, Spire portalının dışındaki koridorda. General Drakkisath'ın arkasındaki Drakkisath's Brand'e dokun; bu, Blackwing Lair'e giden Orb of Command kısayolunu açar.", ["objective"] = "Bu ork gerçekten aptalın teki. Görünüşe göre Komuta Küresi'ne erişmek için bu dağlama demirini bulup Drakkisath'ın Damgası'nı edinmen gerekiyor.$B$BMektuba göre dağlama demirini General Drakkisath koruyor. Belki de araştırmalısın.", ["pickup"] = "Blackhand's Command (Scarshield Quartermaster'dan mektup, Blackrock Mountain)" },
    [78261] = { ["name"] = "Xelthos'un Borusu", ["objective"] = "Shadowfang Keep'in içinde Xelthos'un Borusu'nu bul. Ardından onu Pyrewood Village yakınlarındaki C'nin gizli teslim noktasına götür. Bu işi tek başına tamamlamalısın.", ["warning"] = "Tek kişilik iş: herhangi bir grubun dışında, tek başına yapmalısın." },
    [78307] = { ["description"] = "C'nin bir sonraki mektubu sana bir başkentte ulaştıktan sonra sunulur.", ["name"] = "Xelthos'un Borusu", ["note"] = "Rogue sınıf görevi. C'nin mektubu 20. seviyede bir başkentte gelir; işi Pyrewood Village yakınındaki Dead Drop'tan al. Bir çanta yuvasını boş tut.", ["objective"] = "C'nin ödemesini Pyrewood Village yakınındaki Dead Drop'tan al.", ["warning"] = "Tek kişilik iş: herhangi bir grubun dışında, tek başına yapmalısın." },
    [7848] = { ["name"] = "Çekirdeğe Uyumlanma", ["note"] = "Çekirdek Parçası, BRD'nin derinlerinde Molten Core portalının yanındaki kayanın üzerinde. Lothos'un Molten Core'a ışınlamasını açar.", ["objective"] = "Blackrock Depths'teki Molten Core giriş geçidine git ve bir Çekirdek Parçası al. Çekirdek Parçası'nı aldığında Blackrock Mountain'daki Lothos Riftwaker'a dön." },
    [78676] = { ["name"] = "Bhossca'nın Gözü", ["objective"] = "Scarlet Monastery'nin içinde Bhossca'nın Gözü'nü bul. Ardından onu Pyrewood Village yakınındaki C'nin gizli bırakma noktasına götür. Bu işi tek başına tamamlamalısın.", ["warning"] = "Tek kişilik iş: herhangi bir grubun dışında, tek başına yapmalısın." },
    [78699] = { ["description"] = "C'nin bir sonraki mektubu sana bir başkentte ulaştıktan sonra sunulur.", ["name"] = "Bhossca'nın Gözü", ["note"] = "The Horn of Xelthos'tan sonraki Rogue sınıf görevi; C'nin bir sonraki mektubu (yaklaşık 30. seviyede) seni Dead Drop'a geri gönderir. Her kanatta Scarlet Initiate's Uniform giy: gizlenmek ya da saldırmak onu çıkarır.", ["objective"] = "Kayıt", ["warning"] = "Tek kişilik iş: herhangi bir grubun dışında, tek başına yapmalısın." },
    [79007] = { ["objective"] = "Notun kömürleşmiş kalıntıları tek rehberin.", ["pickup"] = "Camp Taurajo'nun güneyindeki yol üzerinde yanık kuledeki yanmış kalıntılar, The Barrens (46.3, 73.9)", ["turnin"] = "Alexston Farmstead'deki araba enkazının içindeki yanmış kalıntılar, Westfall (37.3, 50.6)" },
    [79008] = { ["name"] = "... ve bulduğun o not", ["objective"] = "Notun yanmış kalıntıları tek rehberin.", ["pickup"] = "Alexston Farmstead'deki araba enkazının içindeki yanmış kalıntılar, Westfall (37.3, 50.6)", ["turnin"] = "Camp Taurajo'nun güneyindeki yol üzerinde yanık kuledeki yanmış kalıntılar, The Barrens (46.3, 73.9)" },
    [79192] = { ["name"] = "Basamak Taşları", ["note"] = "Sun Rock Retreat'in (50.9, 52.3) kuzeydoğusundaki yoldan terk edilmiş kampa çık; cep döküntüleri bir kutunun üzerinde. İsteğe bağlı: bu görevden gelen Basit Odun ve Çakmaktaşı ile kampın ortasındaki ateş çukurunu yak (Rekindle).", ["objective"] = "Notu tahtadan koparıp üzerindeki karalanmış yazıyı okuyorsun.", ["pickup"] = "Camp Taurajo'nun güneyindeki yanık kulenin yanında çivili tahta, The Barrens (46.4, 73.8)", ["turnin"] = "Terk edilmiş kamptaki bir kutunun üzerinde cep döküntüleri, Stonetalon Mountains (40.8, 52.6)" },
    [79974] = { ["name"] = "Islak İş", ["note"] = "Heykelciğe ulaşmak için barajın Wetlands'e bakan tarafındaki oyma kafaların üzerine atla. Oraya ulaşmak Horde için zordur.", ["objective"] = "Topraktan baş gösteren bir haberci çantasının tozunu silkelediğinde, erzakların arasına sıkışmış bir parşömen buluyorsun.", ["pickup"] = "Kampın kuzeyindeki uçurumun altındaki toprak yığını, Stonetalon Mountains (39.6, 49.9)", ["turnin"] = "Stonewrought Dam'in oyma kafalarının üzerindeki oyma heykelcik, Loch Modan (49.4, 12.9)" },
    [79975] = { ["name"] = "Kartal Yumruğu", ["note"] = "Hillsbrad tarafındaki arabadan (87.3, 49.6) Thoradin's Wall'a tırman, duvardaki odadan geç ve dışarıya, sağa bak: çanta orada asılı.", ["objective"] = "Su serpintisi havayı nemlendiriyor, manzara inanılmaz.", ["pickup"] = "Stonewrought Dam'in oyma kafalarının üzerindeki oyma heykelcik, Loch Modan (49.4, 12.9)", ["turnin"] = "Thoradin's Wall'da asılı Ulak Çantası, Hillsbrad Foothills (85.7, 52.2)" },
    [79976] = { ["name"] = "Burası Olmalı", ["objective"] = "Burada her kim idiyse, onları kıl payı kaçırdın.", ["pickup"] = "Thoradin's Wall'da asılı Ulak Çantası, Hillsbrad Foothills (85.7, 52.2)", ["turnin"] = "Aceleyle Sarılmış Heybe, Ulak Çantası'nın hemen altında" },
    [79980] = { ["name"] = "Telaş", ["note"] = "Kamptan dümdüz kuzeye git, tepeye tırman ve kenarından toprak yığınına atla. Adımına dikkat et.", ["objective"] = "Seni neyin beklediğini bul.", ["pickup"] = "Terk edilmiş kamptaki bir kutunun üzerinde cep döküntüleri, Stonetalon Mountains (40.8, 52.6)", ["turnin"] = "Kampın kuzeyindeki uçurumun altındaki toprak yığını, Stonetalon Mountains (39.6, 49.9)" },
    [8151] = { ["name"] = "Avcının Tılsımı", ["note"] = "The Green Drake görevine götüren giriş adımı.", ["objective"] = "Azshara'daki Ogtinc ile konuş.", ["pickup"] = "Hunter eğitmenleri", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [8153] = { ["name"] = "Koşucu Geyik Boynuzları", ["objective"] = "Azshara'daki Ogtinc'e bir çift Kusursuz Koşucu Geyik Boynuzu getir. Ogtinc, Ruins of Eldarath'ın kuzeydoğusundaki yamaçların tepesinde yaşıyor." },
    [8231] = { ["name"] = "Dalgadöven Avı", ["objective"] = "Azshara'daki Ogtinc'e 6 Dalgadöven Pulu getir. Ogtinc, Ruins of Eldarath'ın kuzeydoğusundaki yamaçların tepesinde yaşıyor." },
    [8232] = { ["name"] = "Yeşil Ejder", ["note"] = "Hunter sınıf görevi. Morphaz'ın Dişi Morphaz'dan düşer.\n\nİsteğe bağlı giriş görevi:", ["objective"] = "Morphaz'ın Dişi'ni Azshara'daki Ogtinc'e getir. Ogtinc, Ruins of Eldarath'ın kuzeydoğusundaki yamaçların tepesinde yaşıyor." },
    [8233] = { ["name"] = "Basit Bir Rica", ["note"] = "The Azure Key görevine götüren giriş adımı.", ["objective"] = "Ravenholdt Malikânesi'ndeki Lord Jorach Ravenholdt ile konuş.", ["pickup"] = "Rogue eğitmenleri", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [8234] = { ["name"] = "Mühürlü Mavi Kese", ["objective"] = "Mühürlü Mavi Kese'yi Azshara'daki Timbermaw Şamanı'ndan geri al. Sonra keseyi yine Azshara'da bulunan Başbüyücü Xylem'e götür." },
    [8235] = { ["name"] = "Şifreli Parçalar", ["objective"] = "Azshara'daki Başbüyücü Xylem'e 10 Şifreli Parça getir." },
    [8236] = { ["name"] = "Mavi Anahtar", ["note"] = "Rogue sınıf görevi. Gök Mavisi Anahtar Morphaz'dan düşer.\n\nİsteğe bağlı giriş görevi:", ["objective"] = "Mavi Anahtar'ı Lord Jorach Ravenholdt'a götür." },
    [8250] = { ["name"] = "Büyücülük Sanatı", ["note"] = "Destroy Morphaz görevine götüren giriş adımı.", ["objective"] = "Sanath Lim-yo'yu bul ve Başbüyücü Xylem'i görmek için geçiş izni al.", ["pickup"] = "Mage eğitmenleri", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [8251] = { ["name"] = "Büyülü Toz", ["objective"] = "Başbüyücü Xylem'e 10 Parıltılı Toz getir." },
    [8252] = { ["name"] = "Sirenin Mercanı", ["objective"] = "6 Büyülü Mercan topla ve Başbüyücü Xylem'e dön." },
    [8253] = { ["name"] = "Morphaz'ı Yok Et", ["note"] = "Mage sınıf görevi. Arkan Kırığı Morphaz'dan düşer.\n\nİsteğe bağlı giriş görevi:", ["objective"] = "Morphaz'dan Gizemli Kristal Parçası'nı al ve Başbüyücü Xylem'e dön." },
    [8254] = { ["name"] = "Cenarion Yardımı", ["note"] = "Blood of Morphaz görevine götüren giriş adımı.", ["objective"] = "Azshara'daki Ogtinc'i bul.", ["pickup"] = "Priest eğitmenleri", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [8255] = { ["name"] = "Koşucuları İyi Tanırız", ["objective"] = "4 Sağlıklı Koşucu Bezi edin ve Azshara'daki Ogtinc'e getir. Ogtinc, Ruins of Eldarath'ın kuzeydoğusundaki uçurumların tepesinde yaşar." },
    [8256] = { ["name"] = "Ölümsüzlüğün İrini", ["objective"] = "Azshara'daki Ogtinc için bir Ölümsüzlük İrini edin. Ogtinc, Ruins of Eldarath'ın kuzeydoğusundaki uçurumların tepesinde yaşar." },
    [8257] = { ["name"] = "Morphaz'ın Kanı", ["note"] = "Priest sınıf görevi. Morphaz'ın kanı Ogtinc'e değil, Greta Mosshoof'a teslim edilir.\n\nİsteğe bağlı giriş görevi:", ["objective"] = "Batık Atal'Hakkar tapınağında Morphaz'ı öldür ve kanını Felwood'daki Greta Mosshoof'a götür. Batık tapınağın girişi Swamp of Sorrows'ta bulunur." },
    [8410] = { ["name"] = "Element Ustalığı", ["objective"] = "Rüzgârgözcüsü Bath'rah için hava, ateş, toprak ve su örneklerini topla." },
    [8412] = { ["name"] = "Ruh Totemi", ["objective"] = "Ruh totemi için gereken parçaları Rüzgârgözcüsü Bath'rah'a getir." },
    [8413] = { ["name"] = "Vudu İşi", ["note"] = "Shaman sınıf görevi. Altı trol muhafızından 2 kehribar, 2 mavi ve 2 yeşil Vudu Tüyü gerekir: Gasher, Mijan, Zolo, Hukku, Zul'Lor ve Loro.", ["objective"] = "Vudu tüylerini Rüzgârgözcüsü Bath'rah'a getir." },
    [8414] = { ["name"] = "Kötülüğü Arındırmak", ["objective"] = "20 Hizmetkâr Scourge Taşı topla ve Western Plaguelands'teki Yüksek Rahip Thel'danis'e götür." },
    [8415] = { ["name"] = "Chillwind Point", ["note"] = "Forging the Mightstone görevine götüren giriş adımı.", ["objective"] = "Chillwind Camp'teki Komutan Ashlam Valorfist ile konuş.", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [8416] = { ["name"] = "Etkisiz Scourge Taşları", ["objective"] = "Etkisiz Scourge Taşı'nı Chillwind Point'teki Komutan Ashlan Valorfist'e götür." },
    [8417] = { ["name"] = "Huzursuz Bir Ruh", ["note"] = "Voodoo Feathers görevine götüren giriş adımı.", ["objective"] = "Blasted Lands'in girişindeki Horde'un Düşmüş Kahramanı ile konuş.", ["pickup"] = "Warrior eğitmenleri", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [8418] = { ["name"] = "Kudret Taşı'nı Dövmek", ["note"] = "Paladin sınıf görevi. Altı trol muhafızından 2 kehribar, 2 mavi ve 2 yeşil Vudu Tüyü gerekir: Gasher, Mijan, Zolo, Hukku, Zul'Lor ve Loro.\n\nİsteğe bağlı giriş görevi:", ["objective"] = "Vudu tüylerini Ashlam Valorfist'e götür." },
    [8419] = { ["name"] = "Bir Imp'in Ricası", ["objective"] = "Felwood'daki Impsy'ye bir parça fel kumaşı getir.", ["pickup"] = "Sınıf eğitmenin" },
    [8420] = { ["name"] = "Sıcak ve Kaşındırıcı", ["objective"] = "Felwood'daki Impsy'ye bir parça fel kumaşı getir." },
    [8421] = { ["name"] = "Yanlış Malzeme", ["objective"] = "10 Çürüyen Odun ve 4 Bloodvenom Özütü'nü Felwood'daki Impsy'ye getir." },
    [8422] = { ["name"] = "Aynı Tüyün Trolleri", ["note"] = "Warlock sınıf görevi. Altı trol muhafızından 2 kehribar, 2 mavi ve 2 yeşil Vudu Tüyü gerekir: Gasher, Mijan, Zolo, Hukku, Zul'Lor ve Loro.", ["objective"] = "Batık tapınaktaki trollerden toplam 6 Vudu Tüyü getir." },
    [8423] = { ["name"] = "Savaşçı Akrabalığı", ["objective"] = "Blasted Lands'te 7 Helboar öldür ve Horde'un Düşmüş Kahramanı'na dön." },
    [8424] = { ["name"] = "Shadowsworn'a Karşı Savaş", ["objective"] = "Blasted Lands'teki Shadowsworn'u katlet ve Horde'un Düşmüş Kahramanı'na dön." },
    [8425] = { ["name"] = "Voodoo Tüyleri", ["note"] = "Her iki fraksiyon için Warrior sınıf görevi. Altı trol muhafızından 2 kehribar, 2 mavi ve 2 yeşil Vudu Tüyü gerekir: Gasher, Mijan, Zolo, Hukku, Zul'Lor ve Loro.\n\nİsteğe bağlı giriş görevi:", ["objective"] = "Sunken Temple'daki Troll'lardan aldığın Voodoo Tüyleri'ni Horde'un Düşmüş Kahramanı'na getir." },
    [865] = { ["description"] = "Smart Drinks açılmadan önce gerekli.", ["name"] = "Raptor Boynuzları", ["objective"] = "Sunscale Scytheclaw'lardan 5 Sağlam Raptor Boynuzu topla ve Ratchet'teki Mebok Mizzyrix'e getir." },
    [870] = { ["description"] = "Forgotten Pools'un altındaki yarığı araştır.", ["name"] = "Unutulmuş Havuzlar", ["objective"] = "Bulduklarınla Tonga Runetotem'e rapor ver." },
    [877] = { ["description"] = "The Forgotten Pools'tan sonraki gerekli vaha araştırması.", ["name"] = "Durgun Vaha", ["objective"] = "Stagnant Oasis'i araştırdıktan sonra Crossroads'taki Tonga'ya dön." },
    [880] = { ["description"] = "Altered Beings'i tamamlamak Hamuul Runetotem'i açar.", ["name"] = "Değişmiş Varlıklar", ["objective"] = "Crossroads'taki Tonga Runetotem'e 8 Değişmiş Snapjaw Kabuğu getir." },
    [8945] = { ["name"] = "Ölü Adamın Yakarışı", ["note"] = "Süreli: Baron Rivendare'i 45 dakika içinde öldürerek Ysida Harmon'u kurtar. Anthion'u görmek için Boyutlar Ötesi Hayalet Gösterici'yi kullan.", ["objective"] = "Stratholme'e gir ve Ysida Harmon'u Baron Rivendare'in elinden kurtar." },
    [9051] = { ["name"] = "Zehir Testi", ["objective"] = "Devilsaur Dikeni'ni bir Devilsaura sapla. Bu görevi tamamladığında Un'Goro Crater'daki Torwa Pathfinder'a dön." },
    [9052] = { ["name"] = "Kanyaprağı Zehri", ["objective"] = "8 Kan Başlığı ve 8 Gorishi İğnesi topla, ardından Un'Goro Crater'daki Torwa Pathfinder'a dön." },
    [9053] = { ["name"] = "Daha İyi Bir Malzeme", ["note"] = "Druid sınıf görevi. Çürümüş Sarmaşık, tapınak bodrumundaki Atal'alarion'dan düşer.\n\nİsteğe bağlı giriş görevi:", ["objective"] = "Sunken Temple'ın dibindeki muhafızdan bir Çürümüş Sarmaşık al ve Torwa Pathfinder'a dön." },
    [9063] = { ["name"] = "Torwa Pathfinder", ["note"] = "A Better Ingredient görevine götüren giriş adımı.", ["objective"] = "Un'Goro Crater'daki Torwa Pathfinder ile konuş.", ["pickup"] = "Druid eğitmenleri", ["warning"] = "İSTEĞE BAĞLI, gerekli değil" },
    [914] = { ["name"] = "Diş'in Önderleri", ["note"] = "Barrens vaha görev zinciri gerekir. Leaders of the Fang açılmadan önce The Barrens Oases, The Forgotten Pools, The Stagnant Oasis ve Altered Beings'i, ardından Hamuul Runetotem ve Nara Wildmane'i tamamla.", ["objective"] = "Cobrahn, Anacondra, Pythas ve Serpentis'in Mücevherleri'ni Thunder Bluff'taki Nara Wildmane'e getir." },
    [92401] = { ["name"] = "Korku Dolu Bir Rica", ["objective"] = "Ruins of Lordaeron'da Edward Heartweaver'ın ortadan kayboluşunu araştır." },
    [92415] = { ["name"] = "Seni Sevdiğimi Unutma", ["note"] = "Blood-Stained Letter ile başlayan görev.", ["objective"] = "Kana Bulanmış Mektup'u Stormwind City'deki Yetimhane Başhemşiresi Nightingale'e götür.", ["pickup"] = "Eşyayla başlar: Blood-Stained Letter, Ruins of Lordaeron içindeki mezarlık" },
    [92421] = { ["name"] = "Işığın Adaleti", ["objective"] = "Undercity'deki Morbin Lightbane için The Ruins of Lordaeron'da 25 Sağlam Uzuv topla." },
    [92422] = { ["name"] = "Rath'mael'in Gazabı", ["objective"] = "Brill'deki Ölüm Muhafızı Kristof için Ruins of Lordaeron'da Rath'mael'i öldür." },
    [92432] = { ["description"] = "Heart of Disruption ve Starving Arcane görevlerine götüren giriş görevi.", ["name"] = "Endişe Verici Bir Talep", ["objective"] = "City of Dalaran yakınlarındaki Başbüyücü Modera'nın Sureti'ne rapor ver.", ["turnin"] = "Image of Archmage Modera, Dalaran yakınındaki Lordamere Lake" },
    [92434] = { ["name"] = "Sokaklarda Kan", ["note"] = "Magus Wordeen Voidglare'in Dalaran görevleri gerekir. Keeper Bel'varil'in Stone Tokens ve Bracers of Binding görevleri isteğe bağlıdır, uyumlanma için gerekli değildir.", ["objective"] = "Lordamere Lake boyunca Dalaran'a girmenin bir yolunu bul.", ["turnin"] = "Image of Archmage Modera, Dalaran yakınındaki Lordamere Lake" },
    [92456] = { ["name"] = "Yeşil Bir Numune", ["note"] = "Görev verisi betada kaydedildi; zindana erişim mümkün olmayabilir.", ["objective"] = "Stormwind City'deki Shylamiir için City of Dalaran'dan bir Fel Aşılı Çiçek topla." },
    [92457] = { ["name"] = "Arkan Açlığı", ["note"] = "İçeride bu yaratıklardan tek seferde bitirmeye yetecek kadar olmayabilir.", ["objective"] = "Dalaran'ın dışındaki Başbüyücü Modera için City of Dalaran'ın içinde 8 Seeking Remnant, 8 Saturated Remnant ve 8 Mana Echo yen.", ["pickup"] = "Image of Archmage Modera, Dalaran yakınındaki Lordamere Lake", ["turnin"] = "Image of Archmage Modera, Dalaran yakınındaki Lordamere Lake" },
    [92458] = { ["name"] = "Bozulmanın Kalbi", ["objective"] = "City of Dalaran yakınlarındaki Başbüyücü Modera'nın Sureti için Arkan Zerre'yi topla.", ["pickup"] = "Image of Archmage Modera, Dalaran yakınındaki Lordamere Lake", ["turnin"] = "Image of Archmage Modera, Dalaran yakınındaki Lordamere Lake" },
    [92489] = { ["name"] = "Ezici Güç", ["note"] = "Görev verisi betada kaydedildi; zindana erişim mümkün olmayabilir.", ["objective"] = "Stormwind City'deki Yüce Büyücü Andromath için City of Dalaran'daki Mana Elementali'ni öldür." },
    [92742] = { ["description"] = "Toxic Soil zincirinin ilk görevi.", ["name"] = "Kuyuları Test Etmek", ["objective"] = "Kuyu Suyu Örnek Kiti'ni kullanarak Jansen Stead ve Molsen Farm'daki kuyulardan örnek al.", ["pickup"] = "Alba Fairmoon, Sentinel Hill hanı, Westfall", ["turnin"] = "Alba Fairmoon, Sentinel Hill hanı, Westfall" },
    [92744] = { ["description"] = "Toxic Soil zincirinin ikinci görevi.", ["name"] = "Murloc Solungaçları", ["objective"] = "Alba Fairmoon, Westfall kıyı şeridi boyunca 7 Longshore Murloc Solungacı toplamanı istiyor.", ["pickup"] = "Alba Fairmoon, Sentinel Hill hanı, Westfall", ["turnin"] = "Alba Fairmoon, Sentinel Hill hanı, Westfall" },
    [92745] = { ["description"] = "Westfall madenlerinin kirlenmeye yol açıp açmadığını araştır.", ["name"] = "Madenlerin Durumu", ["objective"] = "Jangolode Mine'da 4 Kobold Digger ve Gold Coast Quarry'de 6 Riverpaw Miner öldür.", ["pickup"] = "Alba Fairmoon, Sentinel Hill hanı, Westfall", ["turnin"] = "Alba Fairmoon, Sentinel Hill hanı, Westfall" },
    [92747] = { ["description"] = "Erzaklar, Deadmines girişine doğru giden mağaralarda bulunur.", ["name"] = "Moonbrook Casusluğu", ["objective"] = "Moonbrook'tan 8 Şüpheli Endüstriyel Malzeme topla.", ["pickup"] = "Alba Fairmoon, Sentinel Hill hanı, Westfall", ["turnin"] = "Alba Fairmoon, Sentinel Hill hanı, Westfall" },
    [92748] = { ["description"] = "Toxic Soil zincirinin patlayıcı bölümünü başlatır.", ["name"] = "Patlayıcı Danışmanlık", ["objective"] = "Stormwind'deki Dwarven District'e git ve yardım edebilecek bir mühendis bul.", ["pickup"] = "Alba Fairmoon, Sentinel Hill hanı, Westfall" },
    [92749] = { ["description"] = "Kaba Dinamit üretilebilir, takas edilebilir ya da müzayede evinden alınabilir.", ["name"] = "Dinamit Gibi Bir Plan", ["note"] = "Kaba Dinamit üretilebilir, takas edilebilir ya da müzayede evinden alınabilir.", ["objective"] = "Üreterek, takas ederek ya da müzayede salonundan 10 Kaba Dinamit edin, ardından Stormwind'in Dwarven District'indeki Sprite Jumpsprocket'a dön." },
    [92750] = { ["description"] = "Planlanan patlama için uzaktan bir fünye gerekiyor.", ["name"] = "Uzaktan Patlatma", ["objective"] = "Uzaktan kumandalı bir patlatıcı edinmek için Stormwind İstihbaratı'ndan biriyle konuş.", ["turnin"] = "Jasper Fel, SI:7, Old Town, Stormwind" },
    [92751] = { ["description"] = "Uzaktan fünyeyi mühendise geri götürür.", ["name"] = "Uzaktan Patlatma", ["objective"] = "Uzaktan Patlatıcı Kiti'ni Stormwind'in Dwarven District'indeki Sprite Jumpsprocket'a götür.", ["pickup"] = "Jasper Fel, SI:7, Old Town, Stormwind" },
    [92752] = { ["description"] = "Deadmines'taki Destruction öncesi son hazırlık.", ["name"] = "Patlayıcı Danışmanlık", ["objective"] = "Westfall'daki Alba Fairmoon'a dön.", ["turnin"] = "Alba Fairmoon, Sentinel Hill hanı, Westfall" },
    [92753] = { ["description"] = "Patlayıcıları demirhanenin yanına yerleştir, sonra Deadmines çıkışında Alba Fairmoon ile buluş.", ["name"] = "Deadmines'ta Yıkım", ["objective"] = "Deadmines'ta gizlenmiş demirhaneyi bul ve Ekstra Yıkıcı Patlayıcılar'ı yakınına yerleştir. Ardından Deadmines çıkışında Alba Fairmoon ile buluş.", ["pickup"] = "Extra-Destructive Explosives görev başlatma eşyası", ["turnin"] = "Alba Fairmoon, Moonbrook'un arkasındaki tepelerde (Deadmines çıkışında), Westfall" },
    [92819] = { ["name"] = "Deadmines'ta Yıkım", ["note"] = "Deadmines kısmı zincirin 10. adımı: Extra-Destructive Explosives'i Deadmines içindeki demirhanenin yanına yerleştir, sonra Deadmines çıkışında Alba Fairmoon ile buluş.", ["objective"] = "Patlatıcıyı kullan.", ["pickup"] = "Alba Fairmoon, Moonbrook'un arkasındaki tepelerde (Deadmines çıkışında), Westfall", ["turnin"] = "Alba Fairmoon, Moonbrook'un arkasındaki tepelerde (Deadmines çıkışında), Westfall" },
    [93680] = { ["name"] = "Şehrin Anahtarı", ["note"] = "Bu görev Prison Break In ile aynı anda kabul edilebilir.", ["objective"] = "Tarren Mill'deki Büyücü Wordeen Voidglare için Dalaran Lağım Anahtarı'nı edin." },
    [94907] = { ["name"] = "Küçük Bir İyilik", ["objective"] = "Twilight's Shroud içindeki bir kanaldan bir Twilight's Thrall çağır ve onu Amberhall'un Ruh Taşı ile yakala.", ["pickup"] = "Ashe Amberhall, Riverglades (tam yeri henüz bilinmiyor)" },
    [94968] = { ["name"] = "Mugg'ın Gözü", ["objective"] = "Krol'dok Stronghold'a sız ve liderlerinin ölümünün kanıtıyla Krom'rosh'a dön.", ["pickup"] = "Krom'rosh, Riverglades (tam yeri henüz bilinmiyor)" },
    [94972] = { ["name"] = "Alacakaranlık Cildi", ["objective"] = "Alacakaranlık Cildi'ni Krol'dok Stronghold'dan geri al.", ["pickup"] = "Riverglades (görev veren henüz bilinmiyor)", ["turnin"] = "Riverglades (henüz bilinmiyor)" },
    [94975] = { ["name"] = "Bir İntikam Nişanesi", ["objective"] = "Krol'dok Stronghold'daki Twilight's Hammer'dan 15 Tarikatçı Kulağı topla.", ["pickup"] = "Riverglades (görev veren henüz bilinmiyor)", ["turnin"] = "Riverglades (henüz bilinmiyor)" },
    [94982] = { ["name"] = "Mugg'ın Gözü", ["objective"] = "Krol'dok Stronghold'a sız ve liderlerinin ölümünün kanıtıyla Commander Brant'e dön.", ["pickup"] = "Commander Demar Brant, Farholde Keep, Riverglades (tam yeri henüz bilinmiyor)" },
    [94983] = { ["name"] = "Alacakaranlık Hatıraları", ["objective"] = "Krol'dok Stronghold'daki Twilight's Hammer'dan 8 Alacakaranlık Bileziği topla.", ["pickup"] = "Farholde Keep, Riverglades (görev veren henüz bilinmiyor)", ["turnin"] = "Farholde Keep, Riverglades (henüz bilinmiyor)" },
    [94984] = { ["name"] = "Alacakaranlık Cildi", ["objective"] = "Krol'dok Stronghold'da Nar'gurk'u öldür ve değerli her bilgiyi ele geçir.", ["pickup"] = "Ashe Amberhall, Riverglades (tam yeri henüz bilinmiyor)" },
    [95034] = { ["description"] = "Görev zinciri 18. seviyede Tirisfal Glades'teki Bandarion Keep'te Danitha Morr'dan Diplomatic Incident ile başlar. Seni Fenris Keep'ten Lumina Windsinger'ı kurtardığın Fenris Isle'a götürür.", ["name"] = "Borç", ["objective"] = "The Sepulcher'daki Lumina Windsinger ile konuş." },
    [95036] = { ["name"] = "Ayın Öptüğü Kılıç", ["objective"] = "The Sepulcher'daki Trevan Rol ile konuş ve ona ihtiyaç duyduğu malzemeleri getir." },
    [95111] = { ["name"] = "Hafife Alınan Bir Yetenek", ["objective"] = "Ott ile konuş ve kılıcını dövmesini iste." },
    [95125] = { ["name"] = "Ott'un Başyapıtı", ["objective"] = "Ott kılıcını döverken onu izle." },
    [95126] = { ["name"] = "Ay Gümüşü Kılıç", ["objective"] = "Ott'un Başyapıtı'nı Silverpine Forest'taki Trevan Rol'e götür." },
    [95140] = { ["description"] = "Son adım. Old Fire-Eye, güney Silverpine Forest'taki Greymane Wall'da. Ödül: Wolfsbane.", ["name"] = "Yaşlı Ateşgöz", ["note"] = "Undead'ler ve taurenler için Paladin sınıf görevi. Bu zindanda: Whitestone Meşe Kerestesi Goblin Woodcarver'lardan düşer. Diğer parçalar Enchanted Silver Ingot (Shadowfang Keep) ve Purified Kor Gem (Blackfathom Deeps).", ["objective"] = "Silverpine Forest'taki Old Fire-Eye'ı yok etmek için Ay Gümüşü Kılıç'ı kullan.", ["warning"] = "Bu, bir adımı The Deadmines'ta olan bir zincir görev" },
    [95189] = { ["name"] = "Lordaeron Arması", ["note"] = "Topluluk bildirimlerine göre Arma, zindanın içinde birkaç farklı yerde çıkabiliyor. Bildirilen yerler arasında kulelerin üst katları, The Baron yakınındaki yan/mahzen odaları ve Bjork'un çevresi var.", ["objective"] = "Lordaeron Arması'nı Stormwind City'deki Leydi Dena Kennedy'ye geri götür.", ["pickup"] = "Eşyayla başlar: Crest of Lordaeron, Ruins of Lordaeron içinde" },
    [95195] = { ["name"] = "Kana Bulanmış Nişan", ["objective"] = "10 Kana Bulanmış Nişan topla ve onları Stormwind City'deki General Marcus Jonathan'a götür.", ["pickup"] = "Eşyayla başlar: Bloodied Insignia, Ruins of Lordaeron içinde" },
    [95204] = { ["name"] = "Lordaeron Arması", ["note"] = "Topluluk bildirimlerine göre Arma, zindanın içinde birkaç farklı yerde çıkabiliyor. Bildirilen yerler arasında kulelerin üst katları, The Baron yakınındaki yan/mahzen odaları ve Bjork'un çevresi var.", ["objective"] = "Lordaeron Arması'nı Undercity'deki Oran Snakewrithe'a götür.", ["pickup"] = "Eşyayla başlar: Crest of Lordaeron, Ruins of Lordaeron içinde" },
    [95216] = { ["name"] = "Yeni Veba", ["objective"] = "Undercity'deki Theodore Griffs için Ruins of Lordaeron'daki Witherfang'den Son Derece Zehirli Suş'u topla." },
    [95250] = { ["name"] = "İğrenç Yaratıklar", ["objective"] = "Ruins of Lordaeron'da Baron'un Kafası'nı ele geçir ve Yüzbaşı Truman'a geri getir.", ["pickup"] = "Captain Truman, Ruins of Lordaeron'un hemen içinde (girişin solunda)", ["turnin"] = "Captain Truman, Ruins of Lordaeron'un hemen içinde" },
    [95646] = { ["name"] = "Yaylalardaki Dehşet", ["objective"] = "Excavation Sites'ta bir Highland Horror öldür ve kök çekirdeğini Wetlands'teki Yeşil Muhafız Rethiel'e götür." },
    [95647] = { ["description"] = "Heartwoven öncesi gerekli.", ["name"] = "Çalılıkta Kaybolanlar", ["objective"] = "Excavation Sites'ta Ardin Grassman'i bul.", ["turnin"] = "Ardin Grassman, Excavation Site: Wetlands içinde" },
    [95663] = { ["description"] = "Open the Maw öncesi gerekli.", ["name"] = "Dragonmaw Söylentileri", ["objective"] = "Wetlands'e git ve Dragonmaw kampının yukarısındaki tepelerde Ölüm Takipçisi Ajanı ile buluş.", ["turnin"] = "Deathstalker Agent, Dragonmaw kampının üstündeki tepeler, Wetlands" },
    [95664] = { ["name"] = "Kadim Bilgi", ["objective"] = "Titan Kalıntısı'nı Thunder Bluff'taki Elder Rise'a götür ve sana onun hakkında daha fazlasını anlatabilecek birini ara.", ["pickup"] = "Titan Kalıntısı (Relic Guardian düşürür)" },
    [95682] = { ["name"] = "Dragonmaw İnini Aç", ["note"] = "İlgili giriş görevi: Dragonmaw Rumors. Dragonmaw Gönderisi, zindanın içindeki Dragonmaw kuvvetlerinden alınır.", ["objective"] = "Excavation Site'taki Dragonmaw kuvvetlerini katlet ve ele geçirdiğin her şeyle dışarıdaki Ölüm Takipçisi Ajanı'na dön.", ["pickup"] = "Deathstalker Agent, Excavation Site: Wetlands'in hemen dışında", ["turnin"] = "Deathstalker Agent, Excavation Site: Wetlands'in hemen dışında" },
    [95697] = { ["name"] = "Değişen Damak Zevkleri", ["note"] = "Thicket Raptor Eti, Shadetooth'un bölgesi olan Stalker's Thicket'teki Thicket raptorlarından (Thicket Lurker, Thicket Hunter, Thicket Matriarch) gelir.", ["objective"] = "Wetlands'teki Excavation Sites'a gir ve Çalılık Raptoru Eti getir." },
    [95748] = { ["name"] = "Eski Gurubashi Efsaneleri", ["objective"] = "Postu ve kömürü kullanarak Üçüncü Trol Efsanesi tabletinin bir kopyasını çıkar." },
    [95770] = { ["description"] = "Mağara, Sunken Hollow'da, yaklaşık 21, 28 civarında su altında: Drowned City'nin girişi.", ["name"] = "Kayıp Şehrin İzinde", ["objective"] = "Vile Reef'i keşfet ve mağara girişini bul." },
    [95772] = { ["name"] = "Songblade'i Aramak", ["objective"] = "Dorin Songblade'in kardeşi Daewyn'i Whelgar's Excavation Site'ta ara.", ["turnin"] = "Daewyn Songblade, Excavation Site: Wetlands içinde" },
    [95773] = { ["name"] = "Sulardaki Düşmanlar", ["note"] = "Commander Aggro'gosh, The Gurubashi Legends of Old teslim edilince bunu sunar.", ["objective"] = "Brinescale Skirmisher'lardan 10 Brinescale Mızrağı topla." },
    [95775] = { ["name"] = "Batık Şehir", ["objective"] = "Batık Şehir'de bulunan tabletlerin izlerini çıkarmak için postu ve kömürü kullan." },
    [95776] = { ["name"] = "Tek İyi Brinescale...", ["note"] = "Commander Aggro'gosh, Enemies in the Water ve Locating the Lost City (Kin'weelay) görevlerinin ikisi de teslim edilince bunu sunar.", ["objective"] = "Batık Şehir'de Var'Taka'yı öldür." },
    [95786] = { ["name"] = "Southshore'da Bir Tanıdık", ["objective"] = "Savage Coast Rapor Destesi'ni (fetişler, trol efsaneleri ve keşif raporu) Southshore'daki Loremaster Dibbs'e götür." },
    [95787] = { ["name"] = "Suyla İki Tane Al", ["note"] = "Görev veren henüz doğrulanmadı. Giriş görevi: An Acquaintance in Southshore, Savage Coast Rapor Destesi'ni Loremaster Dibbs'e götürmek.", ["objective"] = "Drowned City'deki dört I'lalai Tableti'nin kopyasını çıkar." },
    [95788] = { ["name"] = "Drowned City'nin Büyüleri", ["objective"] = "Drowned City'deki trollerden 5 I'lalai Fetişi topla." },
    [95789] = { ["name"] = "Şüpheli Saltseer'lar", ["objective"] = "Drowned City'deki Saltseer korsanlarından 10 Vuduyla Dolu Eser topla." },
    [95791] = { ["name"] = "Saltseer Kaptanı", ["objective"] = "Drowned City'de Captain Dreadrise'ı ve 3 Saltseer Coroner'ı öldür." },
    [95795] = { ["name"] = "Bataklıkta Düşenler", ["objective"] = "Dorin Songblade'e dön.", ["pickup"] = "Daewyn Songblade, Excavation Site: Wetlands içinde" },
    [95798] = { ["note"] = "Kirin Tor, Dalaran'a yalnızca kayda değer ziyaretçileri alıyor.", ["objective"] = "I'lalai Fetişi'ni Dalaran'daki Abra Cadabra'ya götür." },
    [95799] = { ["name"] = "Explorer's League İçin Bulgular", ["objective"] = "Dibbs'in I'lalai Çevirileri'ni Ironforge'daki Historian Karnik'e götür." },
    [95809] = { ["name"] = "Yürekten Dokunmuş", ["objective"] = "Menethil Harbor'daki Caitlin Grassman'e dön.", ["pickup"] = "Ardin Grassman, Excavation Site: Wetlands içinde" },
    [95810] = { ["name"] = "Kayıp Kalıntının Taşınması", ["objective"] = "Titan Kalıntısı'nı Wetlands kazı alanındaki Kâşif Whelgar'a götür.", ["pickup"] = "Titan Kalıntısı (Relic Guardian düşürür)" },
    [959] = { ["name"] = "Rıhtımda Sorun", ["objective"] = "Ratchet'taki Vinç Operatörü Bigglefuzz, Wailing Caverns'ta saklanan Mad Magglish'ten 99 Yıllık Porto şişesini geri almanı istiyor." },
    [962] = { ["name"] = "Yılançiçeği", ["objective"] = "Thunder Bluff'taki Simyacı Zamah 10 Yılançiçeği toplamanı istiyor." },
    [96391] = { ["description"] = "Dark Iron Haritası bu görevi başlatır ve doğrudan Old Ironforge Incursion görevine götürür.", ["name"] = "Yeraltı Haritası", ["objective"] = "Dark Iron Haritası'nı Dun Morogh'daki Toprak Kâhini Farsen'e teslim et.", ["pickup"] = "Dark Iron Haritası, Ironband's Compound'daki Dark Iron Casusları düşürür, Dun Morogh" },
    [96393] = { ["name"] = "Old Ironforge Baskını", ["note"] = "Zincir, Dun Morogh'daki Dark Iron Casuslarından Dark Iron Haritası düşmesiyle başlar.", ["objective"] = "Old Ironforge'un altındaki Hall of Thanes'e gir ve Durgen Dirgehammer'ın Kafası'nı al.", ["pickup"] = "Earthseer Farsen, Dun Morogh (Yeraltı Haritası'ndan sonra)" },
    [96394] = { ["name"] = "Huzursuz Ölüler", ["objective"] = "15 Enraged Apparition ve 10 Tormented Soul öldür, ardından Anvilmar'ın ruhunu huzura kavuştur.", ["pickup"] = "Afadra Dunwall, Old Ironforge'un tepesinde, zindanın dışında" },
    [96395] = { ["name"] = "Kadim Bir Kin", ["objective"] = "Faldrim Anvilmar'ın ruhunu huzura kavuştur, ardından Hall of Thanes'teki Hayalet Hizmetkâr'a dön.", ["pickup"] = "Ghostly Attendant, Hall of Thanes içinde, ilk odadan sonra", ["turnin"] = "Ghostly Attendant, zindanın içinde" },
    [96403] = { ["name"] = "Önemli Yadigârlar", ["objective"] = "Hall of Thanes'ten 8 Cüce Yadigârı topla.", ["pickup"] = "Thom Filch, Ironforge'daki köprü / kasa girişinin yanında", ["turnin"] = "Thom Filch, zindan girişinin yakınında" },
    [96771] = { ["name"] = "Highborne'un İntikamı", ["note"] = "Zalfan Moonshadow, kalenin içindeki Twilight's Hammer arasında bir highborne; nerede durduğu henüz bilinmiyor.", ["objective"] = "Krol'dok Stronghold'a git ve Zalfan Moonshadow'u öldür.", ["pickup"] = "Ranath Nightstride, Dalaran'daki hanın içinde, Alterac Mountains", ["turnin"] = "Ranath Nightstride, Dalaran'daki hanın içinde, Alterac Mountains" },
    [96774] = { ["name"] = "Kadim Gurubashi Putu", ["objective"] = "Batık Şehir'den Kadim bir Gurubashi Putu'nu geri getir." },
    [96800] = { ["name"] = "Vadesi Geçmiş", ["note"] = "Forever'da yeni. Kitap Arcanist Doan'dadır.", ["objective"] = "Runemaster'ların Kayıp Büyüsü adlı kitabı Scarlet Monastery'den geri getir." },
    [96984] = { ["name"] = "Bozulmanın Kalbi", ["note"] = "Horde Dalaran uyumlanması. Stone Tokens ve Bracers of Binding zincirle birlikte yapılabilir ama isteğe bağlıdır, uyumlanma için gerekli değildir.", ["objective"] = "Tarren Mill'deki Magus Wordeen Voidglare için City of Dalaran'da Arkan Zerre'yi topla.", ["pickup"] = "Image of Archmage Modera, Dalaran yakınındaki Lordamere Lake" },
    [96986] = { ["name"] = "Mezar Şövalyesi", ["note"] = "Görev verisi betada kaydedildi; zindana erişim mümkün olmayabilir.", ["objective"] = "Tarren Mill'deki Melisara için City of Dalaran'da Mezar Şövalyesi Atrexis'i yen." },
    [96987] = { ["name"] = "Fırsatçı Eğitim", ["note"] = "Görev verisi betada kaydedildi; zindana erişim mümkün olmayabilir.", ["objective"] = "Kanalizasyon girişinin yakınındaki Rexxie Copperclutch için City of Dalaran'dan \"Dalaran'ın Kuruluşu\" kitabını topla.", ["pickup"] = "Rexxie Copperclutch, zindanın içinde, lağım girişinin yakınında", ["turnin"] = "Rexxie Copperclutch, zindanın içinde, lağım girişinin yakınında" },
    [96988] = { ["name"] = "Gücün Kaynağı", ["note"] = "Görev verisi betada kaydedildi; zindana erişim mümkün olmayabilir.", ["objective"] = "Undercity'deki Doktor Martin Felben için City of Dalaran'da 6 Çatlak Nöbetçi Çekirdeği topla." },
    [971] = { ["name"] = "Derinliklerdeki Bilgi", ["note"] = "Lorgalis Elyazması, Ghamoo-ra'nın kaplumbağa odasını hemen geçince kuzey girintide, Pool of Ask'ar'da su altındaki bir Oyuk Demir Sandık'ın içinde.", ["objective"] = "Lorgalis El Yazması'nı Ironforge'daki Forlorn Cavern'da bulunan Gerrig Bonegrip'e götür.", ["pickup"] = "Gerrig Bonegrip, Forlorn Cavern, Ironforge (50.8, 5.6)" },
    [97130] = { ["name"] = "Kadim Gurubashi Sırları", ["objective"] = "Drowned City'den bir Kadim Gurubashi İdolü geri al.", ["pickup"] = "Archmage Timear, Violet Hold'un eskiden durduğu yerin dışında, Dalaran, Alterac Mountains", ["turnin"] = "Archmage Timear, Dalaran (doğrulanmadı)" },
    [97196] = { ["name"] = "Coldbringer'ın Gözü", ["note"] = "Görev veren henüz bilinmiyor. Küre, son boss olan Amnennar the Coldbringer'da.", ["objective"] = "Coldbringer'ın Gözü'nü Razorfen Downs'tan geri al.", ["pickup"] = "Henüz bilinmiyor", ["turnin"] = "Henüz bilinmiyor" },
    [97288] = { ["name"] = "Bitmeyen Azap", ["note"] = "Eşya seçimi, Undercity'deki sonraki Unending Torment adımında verilir.", ["objective"] = "İğrenç Kafa'yı Undercity'deki Usta Eczacı Faranell'e teslim et.", ["pickup"] = "Eşyayla başlar: Abominable Head, Ruins of Lordaeron içinde", ["rewardHeader"] = "Zincir ödülü — devam görevi" },
    [98423] = { ["name"] = "Anlaşma Antlaşması", ["note"] = "Tablet, Durgen Dirgehammer'ın son boss odasında, Reliquary of Kings'teki kasalardan birinin içinde. Zindandan ayrılmadan önce kasaları aç ve tabletle etkileşime geç.", ["objective"] = "Anlaşma Antlaşması'nı Ironforge'daki Magni Bronzebeard'a teslim et.", ["pickup"] = "Reliquary of Kings'teki bir kasanın içindeki taş tablet (Durgen Dirgehammer'ın odası)" },
    [98815] = { ["name"] = "Yayla Postları", ["objective"] = "4 Çalılık Raptoru Postu'nu Menethil Harbor'daki tabak James Halloran'a götür." },
    [98823] = { ["name"] = "Toprağın Yankısı", ["objective"] = "Titan Kalıntısı'nı Mulgore'un kuzeybatısındaki Skywatcher Plateau'da bulunan Muln Earthfury'ye götür." },
    [98824] = { ["name"] = "Tarih Öncesi Prizma", ["objective"] = "Titan Kalıntısı'nı Ironforge'daki Hall of Explorers'ta bulunan Baş Kâşif Magellas'a götür." },
    [99156] = { ["name"] = "Artçı Devriyesi", ["objective"] = "Riptear'ın Kalbi'ni Deathguard Linnea'ya getir.", ["pickup"] = "Deathguard Linnea, Brill'in güneydoğusundaki kamp, Tirisfal Glades", ["turnin"] = "Deathguard Linnea, Brill'in güneydoğusundaki kamp, Tirisfal Glades", ["warning"] = "Grup görevi: Riptear 13. seviye elit." },
}
T.places = {
    ["Rare spawn in the side passage after Rhahk'Zor."] = "Rhahk'Zor'dan sonraki yan geçitte nadir doğan.",
    ["Paladin class quest for humans and dwarves. In this dungeon: the Corrupted Kor Gem drops from Blackfathom Sea Witches inside, and from Blackfathom Tide Priestesses and Oracles at the entrance in Ashenvale. Thundris Windweaver in Auberdine purifies it. The other parts are Whitestone Oak Lumber (The Deadmines), Jordan's Smithing Hammer (Shadowfang Keep) and Jordan's ore shipment (Loch Modan)."] = "İnsan ve cüceler için Paladin sınıf görevi. Bu zindanda: Corrupted Kor Gem içerideki Blackfathom Sea Witch'lerden, Ashenvale'deki girişte de Blackfathom Tide Priestess ve Oracle'lardan düşer. Auberdine'deki Thundris Windweaver onu arındırır. Diğer parçalar Whitestone Oak Lumber (The Deadmines), Jordan's Smithing Hammer (Shadowfang Keep) ve Jordan'ın cevher sevkiyatıdır (Loch Modan).",
    ["Paladin class quest for undead and tauren. In this dungeon: the Corrupted Kor Gem drops from Blackfathom Sea Witches inside, and from Blackfathom Tide Priestesses and Oracles at the entrance in Ashenvale, once you have Seeking the Kor Gem from Ulric Frostveil at Zoram'gar Outpost. He purifies it. The other parts are Whitestone Oak Lumber (The Deadmines) and the Enchanted Silver Ingot (Shadowfang Keep)."] = "Undead ve tauren için Paladin sınıf görevi. Bu zindanda: Zoram'gar Outpost'taki Ulric Frostveil'den Seeking the Kor Gem görevini aldıktan sonra Corrupted Kor Gem içerideki Blackfathom Sea Witch'lerden, Ashenvale'deki girişte de Blackfathom Tide Priestess ve Oracle'lardan düşer. Onu Ulric arındırır. Diğer parçalar Whitestone Oak Lumber (The Deadmines) ve Enchanted Silver Ingot'tur (Shadowfang Keep).",
    ["Paladin class quest for humans and dwarves. In this dungeon: Jordan's Smithing Hammer is picked up from the object Jordan's Hammer in the courtyard. The other parts are Whitestone Oak Lumber (The Deadmines), the Kor Gem (Blackfathom Deeps) and Jordan's ore shipment (Loch Modan)."] = "İnsan ve cüceler için Paladin sınıf görevi. Bu zindanda: Jordan's Smithing Hammer avludaki Jordan's Hammer nesnesinden alınır. Diğer parçalar Whitestone Oak Lumber (The Deadmines), Kor Gem (Blackfathom Deeps) ve Jordan'ın cevher sevkiyatıdır (Loch Modan).",
    ["Paladin class quest for undead and tauren. In this dungeon: the Enchanted Silver Ingot lies on a table in Archmage Arugal's room, after you kill him. The other parts are Whitestone Oak Lumber (The Deadmines) and the Purified Kor Gem (Blackfathom Deeps)."] = "Undead ve tauren için Paladin sınıf görevi. Bu zindanda: Enchanted Silver Ingot, Archmage Arugal'ı öldürdükten sonra onun odasındaki bir masada durur. Diğer parçalar Whitestone Oak Lumber (The Deadmines) ve Purified Kor Gem'dir (Blackfathom Deeps).",
    ["A white crocolisk."] = "Beyaz bir crocolisk.",
    ["A giant violet raptor, leader of the Thicket raptors."] = "Thicket raptorlarının lideri, dev mor bir raptor.",
    ["Final boss: a stone Titan construct."] = "Son boss: taştan bir Titan yapısı.",
    ["At the ritual circle in the Underbelly, surrounded by Kirin Tor Necromancers and rising skeletons. Disarms."] = "Underbelly'deki ritüel çemberinde, Kirin Tor Necromancer'ları ve yükselen iskeletlerle çevrili. Silahsızlandırır.",
    ["On a round terrace in the streets after leaving the sewers. Casts Arcane Bolt and Focal Blast."] = "Kanalizasyondan çıktıktan sonra sokaklardaki yuvarlak bir terasta. Arcane Bolt ve Focal Blast yapar.",
    ["A fel-touched treant in the streets, among Suffused Treants."] = "Sokaklarda, Suffused Treant'ların arasında fel dokunmuş bir treant.",
    ["An arcane golem by the Magus Commerce Exchange, with Angry Tomes. Malfunction hits everyone within 25 yards."] = "Magus Commerce Exchange yanında, Angry Tome'larla birlikte arkan bir golem. Malfunction 25 metre içindeki herkese vurur.",
    ["Rare elite."] = "Nadir elit.",
    ["Final boss, in the Purple Parlor of the Violet Citadel. Don't stand in line with the Bounding Mana target; he polymorphs the group and resets if someone leaves the room."] = "Son boss, Violet Citadel'in Purple Parlor'ında. Bounding Mana hedefiyle aynı hizada durmayın; grubu dönüştürür ve biri odadan çıkarsa sıfırlanır.",
    ["With his pet Chomper, in the trogg cave off the outer ring."] = "Evcil hayvanı Chomper ile, dış halkanın yanındaki trogg mağarasında.",
    ["An irradiated ooze in the Hall of Gears."] = "Hall of Gears'ta ışınlanmış bir balçık.",
    ["In the Engineering Labs. Drops the Workshop Key."] = "Engineering Labs'ta. Workshop Key düşürür.",
    ["In the Launch Bay arena."] = "Launch Bay arenasında.",
    ["Final boss, in Tinkers' Court. Hit the bomb-face buttons to stop the walking bombs."] = "Son boss, Tinkers' Court'ta. Yürüyen bombaları durdurmak için bomba yüzlü düğmelere basın.",
    ["Rare spawn among the Dark Iron agents."] = "Dark Iron ajanları arasında nadir doğan.",
    ["A quilboar geomancer near the start of the Kraul."] = "Kraul'un başına yakın bir quilboar geomancer.",
    ["Final boss, deep in the Kraul."] = "Son boss, Kraul'un derinliklerinde.",
    ["Rare spawn in the bat caves."] = "Yarasa mağaralarında nadir doğan.",
    ["In the Huntsman's Cloister."] = "Huntsman's Cloister'da.",
    ["Monastery-wide collection: any Scarlet humanoid on the way to the Armory can drop Hearts of Zeal."] = "Manastır geneli toplama: Armory yolundaki herhangi bir Scarlet insansı Hearts of Zeal düşürebilir.",
    ["Final boss, in the Hall of Champions. When he dies a wave of Scarlet Trainees rushes in."] = "Son boss, Hall of Champions'ta. Öldüğünde bir Scarlet Trainee dalgası içeri hücum eder.",
    ["Hidden behind the altar room, through the door at the back of the chapel."] = "Sunak odasının arkasında, şapelin arkasındaki kapıdan geçince saklı.",
    ["At the altar of the Crusader's Chapel. Whitemane comes to raise him when he falls."] = "Crusader's Chapel'in sunağında. Düştüğünde Whitemane onu diriltmeye gelir.",
    ["Final boss. Comes out of the back room when Mograine dies and resurrects him."] = "Son boss. Mograine ölünce arka odadan çıkar ve onu diriltir.",
    ["Spider boss. Ring the gong on the Spiral of Thorns to summon him."] = "Örümcek boss. Onu çağırmak için Spiral of Thorns'taki gongu çalın.",
    ["In the room with the bone pile and the floating skulls."] = "Kemik yığını ve uçan kafataslarının olduğu odada.",
    ["On the path up the Downs, after Mordresh."] = "Downs'a çıkan yolda, Mordresh'ten sonra.",
    ["Rare spawn, near the top of the Downs. No special loot."] = "Downs'un tepesine yakın nadir doğan. Özel ganimeti yok.",
    ["Rare spawn, in the cave below the bridge. No special loot."] = "Köprünün altındaki mağarada nadir doğan. Özel ganimeti yok.",
    ["Final boss, at the top of the Downs. Drops the Skull of the Coldbringer for Bring the End."] = "Son boss, Downs'un tepesinde. Bring the End için Skull of the Coldbringer düşürür.",
    ["In the cave before Ironaya's chamber. Drops The Shaft of Tsol for Staff of Prehistoria."] = "Ironaya'nın odasından önceki mağarada. Staff of Prehistoria için The Shaft of Tsol düşürür.",
    ["Baelog, Eric \"The Swift\" and Olaf, fought together in Dig Two. Horde only: they are friendly to the Alliance."] = "Baelog, Eric \"The Swift\" ve Olaf; Dig Two'da birlikte savaşılır. Yalnızca Horde: Alliance'a dosttur.",
    ["In the Map Chamber. Use the Staff of Prehistoria on the altar to open her door."] = "Map Chamber'da. Kapısını açmak için Staff of Prehistoria'yı sunakta kullanın.",
    ["In the Temple Hall."] = "Temple Hall'da.",
    ["In the Dig Three area, past the Shadowforge dwarves."] = "Dig Three bölgesinde, Shadowforge cücelerinin ilerisinde.",
    ["Trogg leader in the Stone Vault. Drops the sapphire for the necklace quests."] = "Stone Vault'taki trogg lideri. Kolye görevleri için safiri düşürür.",
    ["Final boss, in the Chamber of Khaz'Mul. Use the altar to wake him. Drops the power source for the necklace quests."] = "Son boss, Chamber of Khaz'Mul'da. Uyandırmak için sunağı kullanın. Kolye görevleri için güç kaynağını düşürür.",
    ["In the basilisk pit at Sul'lithuz Sandcrawlers. Kill his servants when he calls them."] = "Sul'lithuz Sandcrawlers'daki basilisk çukurunda. Hizmetkârlarını çağırınca onları öldürün.",
    ["In the graveyard. Zombies rise from the graves when he is pulled."] = "Mezarlıkta. Çekildiğinde mezarlardan zombiler yükselir.",
    ["At the top of the pyramid, after the Sergeant Bly event."] = "Piramidin tepesinde, Sergeant Bly olayından sonra.",
    ["Summoned at the Gong of Zul'Farrak with the Mallet of Zul'Farrak. Drops the Electrified Scale for Gahz'rilla."] = "Zul'Farrak Gongu'nda Mallet of Zul'Farrak ile çağrılır. Gahz'rilla için Electrified Scale düşürür.",
    ["Rare spawn, patrols the sand dunes outside the temple."] = "Nadir doğan, tapınağın dışındaki kum tepelerinde devriye gezer.",
    ["Rare spawn, on the sand dunes outside the temple."] = "Nadir doğan, tapınağın dışındaki kum tepelerinde.",
    ["Rare spawn, near the top of the pyramid."] = "Nadir doğan, piramidin tepesine yakın.",
    ["Fights alongside Chief Ukorz Sandscalp."] = "Chief Ukorz Sandscalp ile birlikte savaşır.",
    ["Final boss, on the top of the temple with Ruuzlu."] = "Son boss, tapınağın tepesinde Ruuzlu ile.",
    ["First boss, an undead troll. Enrages near death and hits the whole group hard."] = "İlk boss, ölümsüz bir trol. Ölmeye yakın öfkelenir ve tüm gruba sert vurur.",
    ["Leader of the naga; the Horde quest The Only Good Brinescale... asks for his death. BlizzCon previews called the second boss Zin'aka."] = "Nagaların lideri; Horde görevi The Only Good Brinescale... onun ölümünü ister. BlizzCon önizlemelerinde ikinci bossun adı Zin'aka idi.",
    ["Fought together with a Primeval Elemental."] = "Bir Primeval Elemental ile birlikte savaşılır.",
    ["Final boss: the Gurubashi witch doctor Min'loth, whose seat of power was I'lalai."] = "Son boss: güç merkezi I'lalai olan Gurubashi cadı doktoru Min'loth.",
    ["Summoned in the statue circle on the upper level (Secret of the Circle)."] = "Üst kattaki heykel çemberinde çağrılır (Secret of the Circle).",
    ["Green dragon on the upper balcony, together with Weaver."] = "Üst balkondaki yeşil ejderha, Weaver ile birlikte.",
    ["Green dragon on the upper balcony, together with Dreamscythe."] = "Üst balkondaki yeşil ejderha, Dreamscythe ile birlikte.",
    ["Summoned at the central altar with the Filled Egg of Hakkar (The God Hakkar)."] = "Merkez sunakta Filled Egg of Hakkar ile çağrılır (The God Hakkar).",
    ["Fought together with Ogom the Wretched, after the six troll minibosses on the balconies are dead. Drops the Head of Jammal'an."] = "Balkonlardaki altı trol mini boss öldükten sonra Ogom the Wretched ile birlikte savaşılır. Head of Jammal'an düşürür.",
    ["Fights beside Jammal'an the Prophet."] = "Jammal'an the Prophet'in yanında savaşır.",
    ["Green dragon in the lower halls, guarding the way to Eranikus."] = "Alt salonlardaki yeşil ejderha, Eranikus'a giden yolu korur.",
    ["Final boss, in his lair at the bottom of the temple. Drops the Essence of Eranikus."] = "Son boss, tapınağın dibindeki inində. Essence of Eranikus düşürür.",
    ["Summoned on the porch with the Blood of Innocents (Kirtonos the Herald)."] = "Verandada Blood of Innocents ile çağrılır (Kirtonos the Herald).",
    ["In the Hall of Secrets; splits into illusions. Drops Krastinov's Bag of Horrors."] = "Hall of Secrets'ta; illüzyonlara bölünür. Krastinov's Bag of Horrors düşürür.",
    ["Bone golem in the Great Ossuary."] = "Great Ossuary'deki kemik golem.",
    ["In the Viewing Room, together with Vectus."] = "Viewing Room'da, Vectus ile birlikte.",
    ["In the Viewing Room; Dawn's Gambit turns the students against him."] = "Viewing Room'da; Dawn's Gambit öğrencileri ona karşı çevirir.",
    ["Lich in the Barov family vault. Use the Soulbound Keepsake on him for The Lich, Ras Frostwhisper."] = "Barov ailesi mahzenindeki lich. The Lich, Ras Frostwhisper için Soulbound Keepsake'i ona kullanın.",
    ["One of the six bosses in the side rooms; all six must die to summon Gandling."] = "Yan odalardaki altı bosstan biri; Gandling'i çağırmak için altısının da ölmesi gerekir.",
    ["The Butcher, in the side rooms. Burn the Sarkhoff remains after killing him."] = "Kasap, yan odalarda. Öldürdükten sonra Sarkhoff kalıntılarını yakın.",
    ["One of the six bosses in the side rooms."] = "Yan odalardaki altı bosstan biri.",
    ["One of the six bosses in the side rooms. Drops a Barov deed."] = "Yan odalardaki altı bosstan biri. Bir Barov tapusu düşürür.",
    ["Final boss, in the Headmaster's Study once the six side-room bosses are dead. He teleports players into the side rooms."] = "Son boss, altı yan oda bossu öldükten sonra Headmaster's Study'de. Oyuncuları yan odalara ışınlar.",
    ["Orange (Vyletongue) wing. Drops the Celebrian Rod."] = "Turuncu (Vyletongue) kanat. Celebrian Rod düşürür.",
    ["Orange wing, patrolling near Noxxion."] = "Turuncu kanat, Noxxion yakınında devriye gezer.",
    ["Purple wing. Drops the Celebrian Diamond."] = "Mor kanat. Celebrian Diamond düşürür.",
    ["Rare spawn in the purple wing."] = "Mor kanatta nadir doğan.",
    ["In the Wicked Grotto. After he dies, Celebras the Redeemed starts The Scepter of Celebras."] = "Wicked Grotto'da. Öldükten sonra Celebras the Redeemed, The Scepter of Celebras görevini başlatır.",
    ["In the Foulspore Cavern, past Celebras."] = "Foulspore Cavern'da, Celebras'ın ilerisinde.",
    ["Goblin engineer in the Foulspore Cavern."] = "Foulspore Cavern'daki goblin mühendis.",
    ["Crocolisk in the waterfall cave below Princess Theradras."] = "Princess Theradras'ın altındaki şelale mağarasında bir crocolisk.",
    ["Final boss, in the Earth Song Falls. Zaetar's Spirit appears after her death."] = "Son boss, Earth Song Falls'ta. Ölümünden sonra Zaetar's Spirit belirir.",
    ["Satyr at the sacrificial altar in the Warpwood Quarter."] = "Warpwood Quarter'daki kurban sunağında bir satir.",
    ["Water elemental in the pool below the bridge."] = "Köprünün altındaki havuzda bir su elementali.",
    ["Blood elf with her pet Pimgib, in the room before Alzzin. Drops Lethtendris's Web."] = "Evcil hayvanı Pimgib ile, Alzzin'den önceki odada bir blood elf. Lethtendris's Web düşürür.",
    ["Final boss, deep in the Warpwood Quarter."] = "Son boss, Warpwood Quarter'ın derinliklerinde.",
    ["Treant guarding the Capital Gardens."] = "Capital Gardens'ı koruyan treant.",
    ["Hunter with her bear Ferra, on the pylon terraces."] = "Ayısı Ferra ile pilon teraslarında bir avcı.",
    ["Rare spawn, stealthed in the Capital Gardens."] = "Nadir doğan, Capital Gardens'ta gizlenmiş.",
    ["Shadow priest on the pylon terraces."] = "Pilon teraslarında bir gölge rahibi.",
    ["Demon in the Prison of Immol'thar; the force field drops once all five pylons are shut down."] = "Prison of Immol'thar'daki iblis; beş pilonun hepsi kapatılınca güç alanı düşer.",
    ["Summoned by warlocks in the pentagram near Immol'thar (Dreadsteed of Xoroth)."] = "Immol'thar yakınındaki pentagramda büyücüler tarafından çağrılır (Dreadsteed of Xoroth).",
    ["Final boss, in the Athenaeum. Drops the Gauntlet of Gordok Might for Unfinished Gordok Business."] = "Son boss, Athenaeum'da. Unfinished Gordok Business için Gauntlet of Gordok Might düşürür.",
    ["Talk to a friendly Captain Kromcrush after you become the Gordok king. The Gauntlet of Gordok Might is in a chest near Prince Tortheldrin in Dire Maul West."] = "Gordok kralı olduktan sonra dost Captain Kromcrush ile konuşun. Gauntlet of Gordok Might, Dire Maul West'te Prince Tortheldrin yakınındaki bir sandıkta.",
    ["Ogre guard at the entrance of Gordok Commons."] = "Gordok Commons girişindeki ogre muhafız.",
    ["Drunk ogre brewer; after the Tribute Run he sells the Gordok brews."] = "Sarhoş ogre biracı; Tribute Run'dan sonra Gordok biralarını satar.",
    ["Ogre guard in the courtyard."] = "Avludaki ogre muhafız.",
    ["Ogre guard behind the trap; the Gordok Ogre Suit lets you walk past him."] = "Tuzağın arkasındaki ogre muhafız; Gordok Ogre Suit onun yanından geçmenizi sağlar.",
    ["Gives Unfinished Gordok Business; with the Ogre Suit you can talk to him instead of fighting."] = "Unfinished Gordok Business görevini verir; Ogre Suit ile savaşmak yerine onunla konuşabilirsiniz.",
    ["Ogre mage fought together with King Gordok."] = "King Gordok ile birlikte savaşılan ogre büyücü.",
    ["Final boss. Killing him makes you the new Gordok king and opens the tribute chest."] = "Son boss. Onu öldürmek sizi yeni Gordok kralı yapar ve haraç sandığını açar.",
    ["Rare spawn near the entrance."] = "Girişe yakın nadir doğan.",
    ["Rare spawn in one of the houses on Festival Lane."] = "Festival Lane'deki evlerden birinde nadir doğan.",
    ["Ghost in the square past the gate, surrounded by spectral citizens."] = "Kapının ilerisindeki meydanda, hayalet vatandaşlarla çevrili bir hayalet.",
    ["Appears in Crusaders' Square once the Scourge there are cleared."] = "Oradaki Scourge temizlenince Crusaders' Square'de belirir.",
    ["Summoned by opening the three mailboxes with the Key to the City."] = "Key to the City ile üç posta kutusunu açınca çağrılır.",
    ["On Market Row, in front of the Scarlet Bastion."] = "Market Row'da, Scarlet Bastion'ın önünde.",
    ["In the Scarlet Archive; burn the archive afterwards (The Archivist)."] = "Scarlet Archive'da; ardından arşivi yakın (The Archivist).",
    ["Final boss: Grand Crusader Dathrohan in the Hall of Lights turns into the dreadlord Balnazzar. Drops the Head of Balnazzar."] = "Son boss: Hall of Lights'taki Grand Crusader Dathrohan, dreadlord Balnazzar'a dönüşür. Head of Balnazzar düşürür.",
    ["Rare gargoyle near the start of the Undead side."] = "Undead tarafının başına yakın nadir gargoyle.",
    ["Runs from Elders' Square to the gate of the Baron's stronghold; kill him before the timer if you go for Ysida."] = "Elders' Square'den Baron'un kalesinin kapısına koşar; Ysida için gidiyorsanız süre bitmeden öldürün.",
    ["Crypt lord in one of the three ziggurats."] = "Üç zigguratın birindeki crypt lord.",
    ["Banshee in one of the three ziggurats; she mind-controls players."] = "Üç zigguratın birindeki banshee; oyuncuları zihin kontrolüne alır.",
    ["Lich in one of the three ziggurats."] = "Üç zigguratın birindeki lich.",
    ["Abomination in the Slaughter Square, after the three ziggurats are cleared."] = "Üç ziggurat temizlendikten sonra Slaughter Square'deki abomination.",
    ["Final boss, in the Slaughter House. Rescue Ysida Harmon by killing him within 45 minutes."] = "Son boss, Slaughter House'ta. Onu 45 dakika içinde öldürerek Ysida Harmon'u kurtarın.",
    ["Detention Block. Drops the Prison Cell Key."] = "Detention Block. Prison Cell Key düşürür.",
    ["Earth elemental on the ring above the Detention Block."] = "Detention Block'un üstündeki halkada bir toprak elementali.",
    ["Kennel master with his hounds on the ring above the Detention Block."] = "Detention Block'un üstündeki halkada köpekleriyle bir köpek ustası.",
    ["Ring of Law: one of six possible challengers."] = "Ring of Law: olası altı rakipten biri.",
    ["Shrine of Thaurissan, behind the Ring of Law."] = "Shrine of Thaurissan, Ring of Law'un arkasında.",
    ["Hall of Crafting. Drops Ironfel for Dark Iron Legacy."] = "Hall of Crafting. Dark Iron Legacy için Ironfel düşürür.",
    ["In the vault with his pet Verek, after the six Dark Keepers."] = "Altı Dark Keeper'dan sonra kasada, evcil hayvanı Verek ile.",
    ["The Black Anvil in the Black Forge."] = "Black Forge'daki Black Anvil.",
    ["Fire giant at the end of the Dark Iron Highway."] = "Dark Iron Highway'in sonundaki ateş devi.",
    ["West Garrison; calls for help at low health."] = "West Garrison; canı azalınca yardım çağırır.",
    ["Manufactory, north of the West Garrison."] = "Manufactory, West Garrison'ın kuzeyinde.",
    ["Grim Guzzler: break the Thunderbrew kegs to make him appear."] = "Grim Guzzler: ortaya çıkması için Thunderbrew fıçılarını kırın.",
    ["Comes to life at the Grim Guzzler door after Hurley or the bar fight."] = "Hurley veya bar kavgasından sonra Grim Guzzler kapısında canlanır.",
    ["Grim Guzzler. Kill him for Yuka Screwspigot's bounty."] = "Grim Guzzler. Yuka Screwspigot'un ödülü için öldürün.",
    ["Grim Guzzler barkeep; turns hostile if you steal his ale."] = "Grim Guzzler barmeni; birasını çalarsanız düşmanlaşır.",
    ["Chamber of Enchantment; keep the Burning Spirits off him."] = "Chamber of Enchantment; Burning Spirit'leri ondan uzak tutun.",
    ["Rare golem that can replace the guards around the West Garrison."] = "West Garrison çevresindeki muhafızların yerine geçebilen nadir golem.",
    ["Summoners' Tomb: talk to Doom'rel and defeat the seven dwarf spirits one after another. Loot is in the Chest of The Seven."] = "Summoners' Tomb: Doom'rel ile konuşun ve yedi cüce ruhunu art arda yenin. Ganimet Chest of The Seven içinde.",
    ["Guards the door to the Imperial Seat; the braziers shoot fire while he lives."] = "Imperial Seat kapısını korur; o yaşarken mangallar ateş püskürtür.",
    ["Heals the Emperor. Don't kill her if you are on the Royal Rescue or Fate of the Kingdom quest."] = "İmparatoru iyileştirir. Royal Rescue veya Fate of the Kingdom görevindeyseniz onu öldürmeyin.",
    ["Final boss, on the throne of the Imperial Seat."] = "Son boss, Imperial Seat'in tahtında.",
    ["Hall of Binding: use the altar to wake him once the Blackhand Incarcerators are dead."] = "Hall of Binding: Blackhand Incarcerator'lar ölünce onu uyandırmak için sunağı kullanın.",
    ["The Rookery: touch the Father Flame and fight off the whelp waves until he arrives."] = "The Rookery: Father Flame'e dokunun ve o gelene kadar yavru ejder dalgalarını püskürtün.",
    ["Rare: sometimes waits in the hall before the Blackrock Stadium."] = "Nadir: bazen Blackrock Stadium'dan önceki salonda bekler.",
    ["Dark Horde blacksmith. Use the Blood Stained Pike on him for The Demon Forge."] = "Dark Horde demircisi. The Demon Forge için Blood Stained Pike'ı ona kullanın.",
    ["Blackrock Stadium: Rend's black dragon, released after the arena waves."] = "Blackrock Stadium: Rend'in kara ejderhası, arena dalgalarından sonra salınır.",
    ["Rides Gyth into the Blackrock Stadium and jumps off when the dragon is low."] = "Gyth'e binip Blackrock Stadium'a girer ve ejderhanın canı azalınca atlar.",
    ["Giant core hound in its den past the Stadium. Fights back with fireballs and fear."] = "Stadium'un ilerisindeki ininde dev bir core hound. Ateş topları ve korkuyla karşılık verir.",
    ["Summoned with the Brazier of Beckoning from the Dungeon Set 2 quests."] = "Dungeon Set 2 görevlerinden Brazier of Beckoning ile çağrılır.",
    ["Final boss, in the throne room with his two Chromatic Elite Guards. Guards Drakkisath's Brand."] = "Son boss, iki Chromatic Elite Guard ile taht odasında. Drakkisath's Brand'i korur.",
    ["Rare ogre in the Spirestone area before Highlord Omokk."] = "Highlord Omokk'tan önceki Spirestone bölgesinde nadir ogre.",
    ["Rare ogre near Highlord Omokk."] = "Highlord Omokk yakınında nadir ogre.",
    ["Rare ogre caster near Highlord Omokk."] = "Highlord Omokk yakınında nadir ogre büyücü.",
    ["Spirestone ogre chief on the ledge in Hordemar City. Drops the Gemstone of Spirestone."] = "Hordemar City'deki çıkıntıda Spirestone ogre şefi. Gemstone of Spirestone düşürür.",
    ["Smolderthorn troll shadow hunter on the way to Voone."] = "Voone'a giden yolda Smolderthorn trol gölge avcısı.",
    ["Smolderthorn troll leader in Mok'Doom. Drops the Gemstone of Smolderthorn."] = "Mok'Doom'daki Smolderthorn trol lideri. Gemstone of Smolderthorn düşürür.",
    ["Spider queen in the Skitterweb Tunnels. Get poisoned for Mother's Milk."] = "Skitterweb Tunnels'taki örümcek kraliçe. Mother's Milk için zehirlenin.",
    ["Rare spider in the Skitterweb Tunnels."] = "Skitterweb Tunnels'ta nadir örümcek.",
    ["Summoned at his pike with Warosh's quest items, along with waves of ogres."] = "Warosh'un görev eşyalarıyla mızrağının başında, ogre dalgalarıyla birlikte çağrılır.",
    ["Rare Firebrand champion near the Storehouse."] = "Storehouse yakınında nadir Firebrand şampiyonu.",
    ["In the Storehouse, guarded by Bloodaxe ogres."] = "Storehouse'ta, Bloodaxe ogrelerince korunur.",
    ["Bloodaxe worg pack mistress in her den. Gizrul comes out after she dies."] = "İnindeki Bloodaxe worg sürüsü hanımı. O ölünce Gizrul çıkar.",
    ["Comes for you shortly after Halycon dies."] = "Halycon öldükten kısa süre sonra size gelir.",
    ["Rare Bloodaxe champion on the bridge to Wyrmthalak."] = "Wyrmthalak'a giden köprüde nadir Bloodaxe şampiyonu.",
    ["Final boss: Bloodaxe overlord in the Chamber of Battle; calls two Bloodaxe Veterans at low health. Drops the Gemstone of Bloodaxe."] = "Son boss: Chamber of Battle'daki Bloodaxe derebeyi; canı azalınca iki Bloodaxe Veteran çağırır. Gemstone of Bloodaxe düşürür.",
    ["A Crumpled Up Note (drops from Dark Iron dwarves)"] = "Buruşturulmuş Bir Not (Dark Iron cücelerinden düşer)",
    ["A Small Favor"] = "Küçük Bir İyilik",
    ["A Titan dig site trapped in time above Whelgar's Excavation, where errant Titan constructs have stopped obeying anyone. Areas inside: Lost Marsh, Stalker's Thicket, Site of the Guardian and Lost Dig Site."] = "Whelgar's Excavation'ın üstünde zamanda donmuş bir Titan kazı alanı; başıboş Titan yapıları artık kimseye itaat etmiyor. İçerideki bölgeler: Lost Marsh, Stalker's Thicket, Site of the Guardian ve Lost Dig Site.",
    ["A Token of Vengeance"] = "Bir İntikam Nişanesi",
    ["A chest in a hut beside Pyrewood Village"] = "Pyrewood Village'ın yanındaki bir kulübede sandık",
    ["A chest in a hut beside Pyrewood Village, Silverpine Forest"] = "Pyrewood Village'ın yanındaki bir kulübede sandık, Silverpine Forest",
    ["A flooded night elf ruin on the Zoram Strand, occupied by naga, murlocs and Twilight's Hammer cultists serving Aku'mai."] = "Zoram Strand'de nagaların, murlocların ve Aku'mai'ye hizmet eden Twilight's Hammer tarikatçılarının işgal ettiği sular altında kalmış bir gece elfi harabesi.",
    ["A rubbing of the tablet inside the Drowned City"] = "Drowned City içindeki tabletin kopyası",
    ["A sprawling thorn maze occupied by the quilboar of Razorfen Kraul."] = "Razorfen Kraul domuzadamlarının işgal ettiği uçsuz bucaksız bir diken labirenti.",
    ["ANSWER: Neltharion"] = "CEVAP: Neltharion",
    ["ANSWER: Ner'zhul"] = "CEVAP: Ner'zhul",
    ["Abra Cadabra in Dalaran, Alterac Mountains"] = "Abra Cadabra, Dalaran, Alterac Mountains",
    ["Accept %s before %s. If %s disappears, abandon %s and it will reappear."] = "%s görevini %s görevinden önce kabul et. %s kaybolursa %s görevini bırak, yeniden görünecektir.",
    ["Accept Rig Wars before Chief Engineer Scooty. If Rig Wars disappears, abandon Chief Engineer Scooty and it will reappear."] = "Chief Engineer Scooty'den önce Rig Wars'u kabul et. Rig Wars kaybolursa Chief Engineer Scooty'yi bırak, yeniden görünecektir.",
    ["Accept Rig Wars first; completion is not required for Chief Engineer Scooty."] = "Önce Rig Wars'u kabul et; Chief Engineer Scooty için tamamlanması gerekmez.",
    ["Accept Rig Wars here"] = "Rig Wars'u burada kabul et",
    ["Acquire the Grimy Key for Magus Wordeen Voidglare in Tarren Mill."] = "Tarren Mill'deki Magus Wordeen Voidglare için Kirli Anahtar'ı edin.",
    ["Afadra Dunwall — top of Old Ironforge"] = "Afadra Dunwall — Old Ironforge'un tepesi",
    ["Afadra Dunwall, top of Old Ironforge, outside the dungeon"] = "Afadra Dunwall, Old Ironforge'un tepesinde, zindanın dışında",
    ["After Baron Rivendare dies, use the glowing rune on the floor of his room, then take the follow-up back to Leonid."] = "Baron Rivendare öldükten sonra odasının zeminindeki parlayan rünü kullan, sonra devam görevini Leonid'e geri götür.",
    ["Alba Fairmoon is inside the Sentinel Hill inn"] = "Alba Fairmoon, Sentinel Hill hanının içinde",
    ["Alba Fairmoon — Sentinel Hill inn"] = "Alba Fairmoon — Sentinel Hill hanı",
    ["Alba Fairmoon, Sentinel Hill inn, Westfall"] = "Alba Fairmoon, Sentinel Hill hanı, Westfall",
    ["Alba Fairmoon, in the hills behind Moonbrook (at the Deadmines exit), Westfall"] = "Alba Fairmoon, Moonbrook'un arkasındaki tepelerde (Deadmines çıkışında), Westfall",
    ["Alliance step required before Gnome Improvement."] = "Gnome Improvement öncesi gerekli Alliance adımı.",
    ["Ambassador Malcin is in the tents of the outdoor thorn maze, before the instance portal. Starts from the Small Scroll dropped by Charlga Razorflank in Razorfen Kraul."] = "Ambassador Malcin, zindan portalından önce, dış diken labirentindeki çadırlarda. Razorfen Kraul'da Charlga Razorflank'in düşürdüğü Küçük Parşömen ile başlar.",
    ["An Acquaintance in Southshore"] = "Southshore'da Bir Tanıdık",
    ["An ancient titan facility in the northern hills of Un'Goro Crater, overlooking dinosaurs, tar pits and powerful crystals. Collect power crystals across Un'Goro and use them at the consoles inside the terrace. Known bosses so far: Nanaya, Cinder, Bolt and Snowtalon."] = "Un'Goro Crater'ın kuzey tepelerinde, dinozorlara, katran çukurlarına ve güçlü kristallere bakan kadim bir titan tesisi. Un'Goro genelinde güç kristalleri topla ve onları terasın içindeki konsollarda kullan. Şimdilik bilinen bosslar: Nanaya, Cinder, Bolt ve Snowtalon.",
    ["An ancient titan vault buried beneath the Badlands, overrun by troggs and Shadowforge dwarves. Archaedas guards the Discs of Norgannon in its deepest chamber."] = "Badlands'in altına gömülü, trogglar ve Shadowforge cüceleri tarafından istila edilmiş kadim bir titan kasası. Archaedas en derin odada Discs of Norgannon'u korur.",
    ["Ancient Gurubashi Secrets"] = "Kadim Gurubashi Sırları",
    ["Answer Braug Dimspirit's question successfully and then speak to him again."] = "Braug Dimspirit'in sorusunu doğru yanıtla, sonra onunla yeniden konuş.",
    ["Answer Parqual Fintallas' question successfully and then speak to him again."] = "Parqual Fintallas'ın sorusunu doğru yanıtla, sonra onunla yeniden konuş.",
    ["Anthion Harmon — outside the Stratholme main gate (needs the Ghost Revealer)"] = "Anthion Harmon — Stratholme ana kapısının dışında (Hayalet Gösterici gerekir)",
    ["Anthion Harmon: outside the Stratholme main gate (needs the Ghost Revealer)"] = "Anthion Harmon: Stratholme ana kapısının dışında (Hayalet Gösterici gerekir)",
    ["Any Maraudon creature can drop the Theradric Crystal Carvings."] = "Maraudon'daki her yaratık Theradric Kristal Oymalarını düşürebilir.",
    ["Any undead in Stratholme can drop Plagued Flesh Samples."] = "Stratholme'daki her undead Vebalı Et Örneği düşürebilir.",
    ["Apothecary Zinge: The Apothecarium, Undercity"] = "Apothecary Zinge: The Apothecarium, Undercity",
    ["Arch Druid Hamuul Runetotem: Elder Rise, Thunder Bluff"] = "Arch Druid Hamuul Runetotem: Elder Rise, Thunder Bluff",
    ["Archmage Arugal and his worgen followers hold the keep above Pyrewood Village."] = "Archmage Arugal ve worgen takipçileri Pyrewood Village'ın üstündeki kaleyi elinde tutuyor.",
    ["Archmage Timear, Dalaran (not confirmed)"] = "Archmage Timear, Dalaran (doğrulanmadı)",
    ["Archmage Timear, outside where the Violet Hold stood in Dalaran, Alterac Mountains"] = "Archmage Timear, Dalaran'da Violet Hold'un eskiden durduğu yerin dışında, Alterac Mountains",
    ["Archmage Timear, outside where the Violet Hold stood, Dalaran, Alterac Mountains"] = "Archmage Timear, Violet Hold'un eskiden durduğu yerin dışında, Dalaran, Alterac Mountains",
    ["Ardin Grassman, inside Excavation Site: Wetlands"] = "Ardin Grassman, Excavation Site: Wetlands içinde",
    ["Argent Guard Manados, Craftsmen's Terrace, Darnassus (55, 24)"] = "Argent Guard Manados, Craftsmen's Terrace, Darnassus (55, 24)",
    ["Argent Guard Thaelrid, inside Blackfathom Deeps"] = "Argent Guard Thaelrid, Blackfathom Deeps içinde",
    ["Argos Nightwhisper is in The Park, beside the moonwell area."] = "Argos Nightwhisper, The Park'ta, ay kuyusu alanının yanında.",
    ["Ashe Amberhall, Riverglades (exact spot not known yet)"] = "Ashe Amberhall, Riverglades (tam yeri henüz bilinmiyor)",
    ["Atal'ai Haze drops from the temple's worms, lurkers and oozes."] = "Atal'ai Sisi, tapınağın solucanlarından, pusucularından ve balçıklarından düşer.",
    ["Available after completing Prison Break In."] = "Prison Break In tamamlandıktan sonra alınabilir.",
    ["Awbee is the wounded blue dragon near the arena route after Rend. Use the rune deep in the Mazthoril cave to reach Haleh."] = "Awbee, Rend'den sonra arena yolunun yakınındaki yaralı mavi ejderha. Haleh'e ulaşmak için Mazthoril mağarasının derinlerindeki rünü kullan.",
    ["Bad News for Folkar"] = "Folkar İçin Kötü Haber",
    ["Baron Aquanis spawns by looting the Fathom Core from the 'Amongst the Ruins' quest."] = "Baron Aquanis, 'Amongst the Ruins' görevindeki Fathom Çekirdeği alınınca ortaya çıkar.",
    ["Battered Dwarven Skeleton: Agmond's End, Badlands"] = "Hırpalanmış Cüce İskeleti: Agmond's End, Badlands",
    ["Begins the explosives portion of the Toxic Soil chain."] = "Toxic Soil zincirinin patlayıcı bölümünü başlatır.",
    ["Below the cliff north of the abandoned camp"] = "Terk edilmiş kampın kuzeyindeki uçurumun altında",
    ["Beneath Ironforge, Dun Morogh"] = "Ironforge'un altında, Dun Morogh",
    ["Beside the Burned-Out Remains at the Alexston Farmstead"] = "Alexston Farmstead'de, Yanmış Kalıntılar'ın yanında",
    ["Beside the Burned-Out Remains, south of Camp Taurajo"] = "Yanmış kalıntıların yanında, Camp Taurajo'nun güneyinde",
    ["Beyond a long-sealed gate in Azshara lies the furbolg city of the Blackmaw clan, fighting a corruption that spreads through its groves and mountain tunnels. A large max-level dungeon with several routes and bosses; its depths may lead even farther below Azeroth."] = "Azshara'da uzun süredir mühürlü bir kapının ardında, korularına ve dağ tünellerine yayılan bir bozulmayla savaşan Blackmaw klanının furbolg şehri yatıyor. Birkaç rotası ve bossu olan büyük bir en üst seviye zindan; derinlikleri Azeroth'un daha da altına inebilir.",
    ["Bijou hides in a recess beyond the early bridges. Her belongings spawn in one of several places around the troll and orc rooms."] = "Bijou, ilk köprülerin ötesindeki bir girintide saklanır. Eşyaları trol ve ork odalarının çevresindeki birkaç yerden birinde çıkar.",
    ["Bijou, inside Lower Blackrock Spire"] = "Bijou, Lower Blackrock Spire içinde",
    ["Blackhand's Command (letter from the Scarshield Quartermaster, Blackrock Mountain)"] = "Blackhand's Command (Scarshield Quartermaster'dan mektup, Blackrock Mountain)",
    ["Blacksmithing 270 (Armorsmith). Use the Blood Stained Pike on Goraluk's corpse and loot the Unforged Rune Covered Breastplate nearby."] = "Demircilik 270 (Zırh Ustası). Kana Bulanmış Mızrak'ı Goraluk'un cesedinde kullan ve yakındaki Dövülmemiş Rün Kaplı Göğüslük'ü al.",
    ["Blacksmithing. Bring a Sulfuron Ingot (Golemagg, Molten Core) to Lokhtos in the Grim Guzzler to get the contract, then hand it back for the Sulfuron Hammer plans."] = "Demircilik. Sözleşmeyi almak için Grim Guzzler'daki Lokhtos'a bir Sulfuron Külçesi (Golemagg, Molten Core) getir, sonra Sulfuron Çekici planları için geri teslim et.",
    ["Blue Punch Card (Punchograph 3005-B)"] = "Mavi Delikli Kart (Punchograph 3005-B)",
    ["Both are at the Balnir Farmstead, east of Linnea's camp."] = "İkisi de Linnea'nın kampının doğusundaki Balnir Farmstead'de.",
    ["Break the three kegs in the Grim Guzzler storeroom to spawn Hurley Blackbreath and his guards.\n\nOptional introductory quest:"] = "Hurley Blackbreath ve muhafızlarını ortaya çıkarmak için Grim Guzzler deposundaki üç fıçıyı kır.\n\nİsteğe bağlı giriş görevi:",
    ["Brinescale Skirmishers on the sea floor west of Grom'gol (around 22, 26)"] = "Grom'gol'un batısında deniz tabanındaki Brinescale Skirmisher'lar (yaklaşık 22, 26)",
    ["Bring 4 Bolts of Runecloth, 8 Rugged Leather, 2 Rune Threads and 1 Ogre Tannin (basket on the upper level beyond Knot). Make any suits and learn the pattern before freeing Knot, because he leaves."] = "4 Rün Kumaşı Topu, 8 Sağlam Deri, 2 Rün İpliği ve 1 Ogre Tanen'i (Knot'un ötesinde üst kattaki sepet) getir. Knot'u serbest bırakmadan önce istediğin takımları yap ve deseni öğren, çünkü gidiyor.",
    ["Bring 6 samples of Lake Creeper Moss, 6 samples of Lake Skulker Moss and a Hardened Tumor to Master Apothecary Faranell in the Undercity."] = "6 Lake Creeper Yosunu, 6 Lake Skulker Yosunu örneği ve bir Sertleşmiş Ur'u Undercity'deki Usta Eczacı Faranell'e getir.",
    ["Bring Ambassador Malcin's Head to Varimathras in the Undercity."] = "Ambassador Malcin'in Kafası'nı Undercity'deki Varimathras'a götür.",
    ["Bring Fragments of Rok'Alim to Dorn Plainstalker in Thousand Needles."] = "Rok'Alim Parçaları'nı Thousand Needles'taki Dorn Plainstalker'a getir.",
    ["Bring Gloom'rel 2 Star Rubies, 20 Gold Bars and 10 Truesilver Bars, then place them in the Spectral Chalice in the Summoners' Tomb."] = "Gloom'rel'e 2 Yıldız Yakutu, 20 Altın Külçe ve 10 Truesilver Külçe getir, sonra bunları Summoners' Tomb'daki Hayalet Kadeh'e koy.",
    ["Bring Grenka's Claw to Dorn Plainstalker in Thousand Needles."] = "Grenka'nın Pençesi'ni Thousand Needles'taki Dorn Plainstalker'a getir.",
    ["Bring Highlord Omokk's Head and a Roughshod Pike to Urok's Tribute Pile beyond the spiders to start the waves."] = "Dalgaları başlatmak için Highlord Omokk'un Kafası'nı ve bir Roughshod Mızrağı'nı örümceklerin ötesindeki Urok's Tribute Pile'a getir.",
    ["Bring Ott's Masterwork to Trevan Rol in Silverpine Forest."] = "Ott'un Ustalık Eseri'ni Silverpine Forest'taki Trevan Rol'e götür.",
    ["Bring Private Rocknot two Dark Iron Ale Mugs."] = "Er Rocknot'a iki Dark Iron Bira Kupası getir.",
    ["Bring a Tablet Shard to Kin'weelay at Grom'gol Base Camp."] = "Grom'gol Base Camp'teki Kin'weelay'e bir Tablet Parçası getir.",
    ["Bring the Dragonmaw Dispatch to the Deathstalker Agent just outside Excavation Site: Wetlands."] = "Dragonmaw Gönderisi'ni Excavation Site: Wetlands'in hemen dışındaki Deathstalker Agent'a getir.",
    ["Bring word of Varian Wrynn's fate to Thrall in Orgrimmar."] = "Varian Wrynn'in akıbetiyle ilgili haberi Orgrimmar'daki Thrall'a götür.",
    ["Brother Crowley: Cathedral of Light, Stormwind"] = "Brother Crowley: Cathedral of Light, Stormwind",
    ["Brother Nimetz at the Rebel Camp, northern Stranglethorn Vale"] = "Brother Nimetz, Rebel Camp, kuzey Stranglethorn Vale",
    ["Burned-Out Remains at the burnt tower on the road south of Camp Taurajo, The Barrens (46.3, 73.9)"] = "Camp Taurajo'nun güneyindeki yol üzerinde yanık kuledeki yanmış kalıntılar, The Barrens (46.3, 73.9)",
    ["Burned-Out Remains in the cart wreckage at the Alexston Farmstead, Westfall (37.3, 50.6)"] = "Alexston Farmstead'deki araba enkazının içindeki yanmış kalıntılar, Westfall (37.3, 50.6)",
    ["Buy Dark Iron Ale Mugs from Plugger Spazzring and keep handing them to Rocknot. The drunken event opens the bar route and can turn Phalanx hostile."] = "Plugger Spazzring'den Dark Iron Bira Kupası satın al ve Rocknot'a vermeye devam et. Sarhoşluk olayı bar yolunu açar ve Phalanx'ı düşman yapabilir.",
    ["By the flight master in Ratchet; he has no ? over his head"] = "Ratchet'teki uçuş ustasının yanında; başının üstünde ? yok",
    ["Captain Truman, just inside Ruins of Lordaeron"] = "Captain Truman, Ruins of Lordaeron'un hemen içinde",
    ["Captain Truman, just inside Ruins of Lordaeron (left of the entrance)"] = "Captain Truman, Ruins of Lordaeron'un hemen içinde (girişin solunda)",
    ["Carved Figurine on the carved heads of the Stonewrought Dam, Loch Modan (49.4, 12.9)"] = "Stonewrought Dam'in oyma kafalarının üzerindeki oyma heykelcik, Loch Modan (49.4, 12.9)",
    ["Caverndeep Pillagers, Caverndeep Invaders, Irradiated Invaders and Addled Lepers, outside the instance"] = "Caverndeep Pillager, Caverndeep Invader, Irradiated Invader ve Addled Leper'lar, zindanın dışında",
    ["Cavindra: Maraudon orange-side caverns, Desolace"] = "Cavindra: Maraudon turuncu taraf mağaraları, Desolace",
    ["Centaur Pariah, southern Desolace"] = "Centaur Pariah, güney Desolace",
    ["Chain reward — follow-up"] = "Zincir ödülü — devam görevi",
    ["Chase and talk to Pusillin through the wing until he fights, then kill him for the book. He also drops the Crescent Key."] = "Pusillin'i kanat boyunca kovala ve o savaşana kadar onunla konuş, sonra kitap için onu öldür. Hilal Anahtarı'nı da düşürür.",
    ["Chest, Cloth"] = "Göğüs, Kumaş",
    ["Climb into Thoradin's Wall from the cart on the Hillsbrad side (87.3, 49.6), go through the room in the wall and look outside to the right: the bag hangs there."] = "Hillsbrad tarafındaki arabadan (87.3, 49.6) Thoradin's Wall'a tırman, duvardaki odadan geç ve dışarıya, sağa bak: çanta orada asılı.",
    ["Codex of Defense (book, Dire Maul drop)"] = "Codex of Defense (kitap, Dire Maul ganimeti)",
    ["Collect 10 Atal'ai Tablets around the temple; tablets in the outer temple also count."] = "Tapınağın çevresinden 10 Atal'ai Tableti topla; dış tapınaktaki tabletler de sayılır.",
    ["Collect 10 Voodoo-Infused Artifacts from the Saltseer pirates in the Drowned City."] = "Drowned City'deki Saltseer korsanlarından 10 Vuduyla Dolu Eser topla.",
    ["Collect 15 Cultist Ears from the Twilight's Hammer in Krol'dok Stronghold."] = "Krol'dok Stronghold'daki Twilight's Hammer'dan 15 Tarikatçı Kulağı topla.",
    ["Collect 20 Fetishes of Hakkar from Atal'ai trolls; outer-temple trolls also drop them."] = "Atal'ai trollerinden 20 Hakkar Fetişi topla; dış tapınaktaki troller de düşürür.",
    ["Collect 4 Thicket Raptor Hides and take them to James Halloran in Menethil Harbor."] = "4 Thicket Raptor Postu topla ve Menethil Harbor'daki James Halloran'a götür.",
    ["Collect 5 I'lalai Fetishes from the trolls in the Drowned City."] = "Drowned City'deki trollerden 5 I'lalai Fetişi topla.",
    ["Collect 5 Stratholme Holy Water from the supply crates in the streets; some crates spawn enemies."] = "Sokaklardaki erzak sandıklarından 5 Stratholme Kutsal Suyu topla; bazı sandıklardan düşman çıkar.",
    ["Collect 6 Cracked Sentry Cores from the constructs in Dalaran."] = "Dalaran'daki yapılardan 6 Çatlak Nöbetçi Çekirdeği topla.",
    ["Collect 6 Grizzled Bear Hearts and 6 samples of Skittering Blood and deliver them to Master Apothecary Faranell in the Undercity."] = "6 Grizzled Bear Kalbi ve 6 Skittering Kanı örneği topla ve Undercity'deki Usta Eczacı Faranell'e teslim et.",
    ["Collect 8 Twilight Bangles from the Twilight's Hammer in Krol'dok Stronghold."] = "Krol'dok Stronghold'daki Twilight's Hammer'dan 8 Alacakaranlık Bileziği topla.",
    ["Collect C's payment from the Dead Drop near Pyrewood Village."] = "C'nin ödemesini Pyrewood Village yakınındaki Dead Drop'tan al.",
    ["Combine the Sister's Half-Key and the Brother's Half-Key, picked from the sister (dining hall) and the brother (upstairs) in Shadowfang Keep. Combining them breaks stealth"] = "Shadowfang Keep'teki kız kardeşten (yemek salonu) ve erkek kardeşten (üst kat) çalınan Kız Kardeşin Yarım Anahtarı ile Erkek Kardeşin Yarım Anahtarı'nı birleştir. Birleştirmek gizlenmeyi bozar",
    ["Commander Aggro'gosh at Grom'gol Base Camp, Stranglethorn Vale"] = "Commander Aggro'gosh, Grom'gol Base Camp, Stranglethorn Vale",
    ["Commander Aggro'gosh offers it once Enemies in the Water and Locating the Lost City (Kin'weelay) are both handed in."] = "Commander Aggro'gosh, Enemies in the Water ve Locating the Lost City (Kin'weelay) görevlerinin ikisi de teslim edilince bunu sunar.",
    ["Commander Aggro'gosh offers it once The Gurubashi Legends of Old is handed in."] = "Commander Aggro'gosh, The Gurubashi Legends of Old teslim edilince bunu sunar.",
    ["Commander Demar Brant, Farholde Keep, Riverglades (exact spot not known yet)"] = "Commander Demar Brant, Farholde Keep, Riverglades (tam yeri henüz bilinmiyor)",
    ["Commander Folkar, inside Alcaz Prison"] = "Commander Folkar, Alcaz Prison içinde",
    ["Community reports indicate the Crest can spawn at one of several locations inside the dungeon. Reported spots include upper floors of towers, side/crypt rooms near The Baron, and the area around Bjork."] = "Topluluk bildirimlerine göre Arma, zindanın içinde birkaç farklı yerde çıkabiliyor. Bildirilen yerler arasında kulelerin üst katları, The Baron yakınındaki yan/mahzen odaları ve Bjork'un çevresi var.",
    ["Complete Daily Delivery first."] = "Önce Daily Delivery'yi tamamla.",
    ["Complete The Dark Iron War to unlock The Fury Runs Deep."] = "The Fury Runs Deep'i açmak için The Dark Iron War'u tamamla.",
    ["Completing Altered Beings unlocks Hamuul Runetotem."] = "Altered Beings'i tamamlamak Hamuul Runetotem'i açar.",
    ["Continue the chain with Bazil Thredd here"] = "Zincire burada Bazil Thredd ile devam et",
    ["Continue with Blisters on The Land here"] = "Burada Blisters on The Land ile devam et",
    ["Continue with Fire Taboo here"] = "Burada Fire Taboo ile devam et",
    ["Continue with Tramping Paws here"] = "Burada Tramping Paws ile devam et",
    ["Continues with Earthen Echo, which sends you to Muln Earthfury in northwest Mulgore."] = "Seni kuzeybatı Mulgore'daki Muln Earthfury'ye gönderen Earthen Echo ile devam eder.",
    ["Count Remington Ridgewell: Stormwind Keep"] = "Count Remington Ridgewell: Stormwind Keep",
    ["Crier Goodman — Stormwind (walks around)"] = "Crier Goodman — Stormwind (dolaşır)",
    ["Crier Goodman, Stormwind (or Courier Hammerfall, Ironforge / Herald Moonstalker, Darnassus)"] = "Crier Goodman, Stormwind (veya Courier Hammerfall, Ironforge / Herald Moonstalker, Darnassus)",
    ["Crier Goodman: Trade District, Stormwind (walks around)"] = "Crier Goodman: Trade District, Stormwind (dolaşır)",
    ["Daewyn Songblade, inside Excavation Site: Wetlands"] = "Daewyn Songblade, Excavation Site: Wetlands içinde",
    ["Dalaran sewer entrance"] = "Dalaran lağım girişi",
    ["Daphne Stilwell is in the far south of Westfall"] = "Daphne Stilwell, Westfall'un en güneyinde",
    ["Daphne Stilwell — southern Westfall"] = "Daphne Stilwell — güney Westfall",
    ["Daphne Stilwell: Stilwell farm, southern Westfall"] = "Daphne Stilwell: Stilwell çiftliği, güney Westfall",
    ["Dark Iron Fanny Packs drop from Dark Iron dwarves in BRD."] = "Dark Iron Bel Çantaları, BRD'deki Dark Iron cücelerinden düşer.",
    ["Dark Iron Map drops from Dark Iron Spies around Ironband's Compound"] = "Dark Iron Haritası, Ironband's Compound çevresindeki Dark Iron Casuslarından düşer",
    ["Dark Iron Map, dropped by Dark Iron Spies at Ironband's Compound, Dun Morogh"] = "Dark Iron Haritası, Ironband's Compound'daki Dark Iron Casusları düşürür, Dun Morogh",
    ["Daryn Lightwind: Rut'theran Village, Teldrassil"] = "Daryn Lightwind: Rut'theran Village, Teldrassil",
    ["Deathguard Kristof — southeast of Brill"] = "Deathguard Kristof — Brill'in güneydoğusu",
    ["Deathguard Linnea, camp south-east of Brill, Tirisfal Glades"] = "Deathguard Linnea, Brill'in güneydoğusundaki kamp, Tirisfal Glades",
    ["Deathstalker Agent, hills above the Dragonmaw camp, Wetlands"] = "Deathstalker Agent, Dragonmaw kampının üstündeki tepeler, Wetlands",
    ["Deathstalker Agent, just outside Excavation Site: Wetlands"] = "Deathstalker Agent, Excavation Site: Wetlands'in hemen dışında",
    ["Deathstalker Vincent, inside Shadowfang Keep"] = "Deathstalker Vincent, Shadowfang Keep içinde",
    ["Deep beneath the Barrens, druids and fanglords guard the sleeping Naralex while twisted beasts prowl the caverns."] = "Barrens'ın derinliklerinde druidler ve fanglordlar uyuyan Naralex'i korurken çarpık canavarlar mağaralarda dolaşıyor.",
    ["Defeat 2 Dragonmaw Saboteurs and 4 Dragonmaw Warders, recover the Dragonmaw Dispatch, and report to the Deathstalker Agent outside the dungeon."] = "2 Dragonmaw Saboteur ve 4 Dragonmaw Warder'ı yen, Dragonmaw Gönderisi'ni ele geçir ve zindanın dışındaki Deathstalker Agent'a rapor ver.",
    ["Defeat Atrexis the Grave Knight in the Dalaran Underbelly."] = "Dalaran Underbelly'de Atrexis the Grave Knight'ı yen.",
    ["Defeat Celebras the Cursed where the paths meet and turn in Legends of Maraudon to Celebras the Redeemed, then help with his ritual and speak to him again for the scepter."] = "Yolların birleştiği yerde Celebras the Cursed'ü yen ve Legends of Maraudon'u Celebras the Redeemed'e teslim et, sonra ritüeline yardım et ve asa için onunla tekrar konuş.",
    ["Defias Traitor: Sentinel Hill, Westfall"] = "Defias Hainı: Sentinel Hill, Westfall",
    ["Defias prisoners have overrun Stormwind's prison beneath the Canal District."] = "Defias tutsakları Canal District'in altındaki Stormwind hapishanesini ele geçirmiş.",
    ["Deliver the Titan Relic to High Explorer Magellas in the Hall of Explorers."] = "Titan Kalıntısı'nı Hall of Explorers'taki High Explorer Magellas'a teslim et.",
    ["Deliver the Titan Relic to Muln Earthfury on Skywatcher Plateau in northwest Mulgore."] = "Titan Kalıntısı'nı kuzeybatı Mulgore'daki Skywatcher Plateau'da Muln Earthfury'ye teslim et.",
    ["Deliver the Titan Relic to Prospector Whelgar at the Wetlands excavation site."] = "Titan Kalıntısı'nı Wetlands kazı alanındaki Prospector Whelgar'a teslim et.",
    ["Done together with the other of Sergeant Yohwa's two quests (The Second Rebellion and Bad Medicine); Brother Nimetz offers Kurzen's Mystery once both are handed in."] = "Sergeant Yohwa'nın iki görevinden diğeriyle (The Second Rebellion ve Bad Medicine) birlikte yapılır; ikisi de teslim edilince Brother Nimetz Kurzen's Mystery görevini sunar.",
    ["Doomrigger's Coffer is in the Rookery. Then take Delivery to Ridgewell to Count Remington Ridgewell in Stormwind Keep for the reward.\n\nOptional introductory quest:"] = "Doomrigger'ın Sandığı Rookery'de. Ardından ödül için Delivery to Ridgewell'i Stormwind Keep'teki Count Remington Ridgewell'e götür.\n\nİsteğe bağlı giriş görevi:",
    ["Dorn Plainstalker in Thousand Needles"] = "Dorn Plainstalker, Thousand Needles'ta",
    ["Down the path towards the Charred Vale"] = "Patikadan Charred Vale'e doğru in",
    ["Dropped by Balnazzar (hand in The Archivist first)"] = "Balnazzar düşürür (önce The Archivist'i teslim et)",
    ["Dropped by Brinescale Skirmishers around the Vile Reef, west of Grom'gol (around 22, 26)"] = "Grom'gol'un batısındaki Vile Reef çevresindeki (yaklaşık 22, 26) Brinescale Skirmisher'lar düşürür",
    ["Dropped by Dark Iron dwarves in Gnomeregan"] = "Gnomeregan'daki Dark Iron cüceleri düşürür",
    ["Dropped by Ferocious Grizzled Bears and Giant Grizzled Bears all over Silverpine Forest"] = "Silverpine Forest'ın her yerindeki Ferocious Grizzled Bear ve Giant Grizzled Bear'lar düşürür",
    ["Dropped by Highlord Omokk, Lower Blackrock Spire"] = "Lower Blackrock Spire'da Highlord Omokk düşürür",
    ["Dropped by Lake Creepers and Elder Lake Creepers on the Dawning Isles in Lordamere Lake (around 77, 25)"] = "Lordamere Lake'teki Dawning Isles'ta (yaklaşık 77, 25) Lake Creeper ve Elder Lake Creeper'lar düşürür",
    ["Dropped by Lake Skulkers and Elder Lake Skulkers on the Dawning Isles in Lordamere Lake (around 72, 35)"] = "Lordamere Lake'teki Dawning Isles'ta (yaklaşık 72, 35) Lake Skulker ve Elder Lake Skulker'lar düşürür",
    ["Dropped by Moss Stalkers and Mist Creepers in the Skittering Dark, north-west of the Sepulcher (around 35, 12)"] = "Sepulcher'ın kuzeybatısındaki Skittering Dark'taki (yaklaşık 35, 12) Moss Stalker ve Mist Creeper'lar düşürür",
    ["Dropped by Overlord Wyrmthalak in Lower Blackrock Spire"] = "Lower Blackrock Spire'da Overlord Wyrmthalak düşürür",
    ["Dropped by Overlord Wyrmthalak, Lower Blackrock Spire"] = "Lower Blackrock Spire'da Overlord Wyrmthalak düşürür",
    ["Dropped by Riptear (level 13 elite) in Venomweb Vale, north-east Tirisfal Glades (around 84, 44)"] = "Kuzeydoğu Tirisfal Glades'teki Venomweb Vale'de (yaklaşık 84, 44) Riptear (13. seviye elit) düşürür",
    ["Dropped by Skullsplitter Witchdoctors and Mystics in the troll ruins south of the Rebel Camp (4 needed)"] = "Rebel Camp'in güneyindeki trol harabelerinde Skullsplitter Witchdoctor ve Mystic'ler düşürür (4 gerekli)",
    ["Dropped by War Master Voone, Lower Blackrock Spire"] = "Lower Blackrock Spire'da War Master Voone düşürür",
    ["Dropped by the Kurzen trolls in and around Kurzen's Compound"] = "Kurzen's Compound içinde ve çevresindeki Kurzen trolleri düşürür",
    ["Dropped by the Kurzen trolls in and around Kurzen's Compound (7 needed)"] = "Kurzen's Compound içinde ve çevresindeki Kurzen trolleri düşürür (7 gerekli)",
    ["Dropped by the Saltseer pirates in the Drowned City"] = "Drowned City'deki Saltseer korsanları düşürür",
    ["Dropped by the Scarshield Quartermaster in the hallway outside the Spire portal"] = "Spire portalının dışındaki koridorda Scarshield Quartermaster düşürür",
    ["Dropped by the Shade of Eranikus"] = "Shade of Eranikus düşürür",
    ["Dropped by the Twilight's Hammer cultists in Krol'dok Stronghold"] = "Krol'dok Stronghold'daki Twilight's Hammer tarikatçıları düşürür",
    ["Dropped by the trolls in the Drowned City"] = "Drowned City'deki troller düşürür",
    ["Dropped by the trolls in the Drowned City (5 needed)"] = "Drowned City'deki troller düşürür (5 gerekli)",
    ["Dropped by:"] = "Düşüren:",
    ["Dropped by: Dark Iron Agents"] = "Düşüren: Dark Iron Agents",
    ["Dropped by: Dark Iron Spies in Dun Morogh"] = "Düşüren: Dun Morogh'daki Dark Iron Casusları",
    ["Dropped by: Goblin Woodcarver, The Deadmines"] = "Düşüren: Goblin Woodcarver, The Deadmines",
    ["Dropped by: Mutanus the Devourer"] = "Düşüren: Mutanus the Devourer",
    ["Dropped by: Relic Guardian"] = "Düşüren: Relic Guardian",
    ["Dropped by: The Baron"] = "Düşüren: The Baron",
    ["Dropped by: undead enemies inside Ruins of Lordaeron"] = "Düşüren: Ruins of Lordaeron içindeki undead düşmanlar",
    ["Drops from Baron Aquanis inside Blackfathom Deeps."] = "Blackfathom Deeps içinde Baron Aquanis'ten düşer.",
    ["Drops from Blackfathom Tide Priestess in the entrance tunnels leading to Blackfathom Deeps."] = "Blackfathom Deeps'e giden giriş tünellerindeki Blackfathom Tide Priestess'lerden düşer.",
    ["Drops from Charlga Razorflank in Razorfen Kraul"] = "Razorfen Kraul'da Charlga Razorflank'ten düşer",
    ["Drops from Dark Iron dwarves in Blackrock Depths once Abandoned Hope is turned in"] = "Abandoned Hope teslim edildikten sonra Blackrock Depths'teki Dark Iron cücelerinden düşer",
    ["Drops from the dwarves and troggs in Uldaman"] = "Uldaman'daki cücelerden ve trogglardan düşer",
    ["Drops in Dire Maul; also tradeable"] = "Dire Maul'da düşer; takas da edilebilir",
    ["Druid class book. Click the book to start the quest."] = "Druid sınıf kitabı. Görevi başlatmak için kitaba tıkla.",
    ["Druid class quest. The Putrid Vine drops from Atal'alarion in the temple basement.\n\nOptional introductory quest:"] = "Druid sınıf görevi. Çürümüş Sarmaşık, tapınak bodrumundaki Atal'alarion'dan düşer.\n\nİsteğe bağlı giriş görevi:",
    ["Druid trainers"] = "Druid eğitmenleri",
    ["Durgen Dirgehammer's room"] = "Durgen Dirgehammer'ın odası",
    ["Duthorian Rall: Cathedral of Light, Stormwind"] = "Duthorian Rall: Cathedral of Light, Stormwind",
    ["Earthseer Farsen, Dun Morogh (after Underground Map)"] = "Earthseer Farsen, Dun Morogh (Yeraltı Haritası'ndan sonra)",
    ["Ebru, above the entrance to Wailing Caverns, The Barrens"] = "Ebru, Wailing Caverns girişinin üstünde, The Barrens",
    ["Emissary Jacques in Southshore, Hillsbrad Foothills"] = "Emissary Jacques, Southshore, Hillsbrad Foothills",
    ["Enohar Thunderbrew: Nethergarde Keep, Blasted Lands"] = "Enohar Thunderbrew: Nethergarde Keep, Blasted Lands",
    ["Enter Alcaz Prison and collect 8 Blood Red Bandanas from the human guards there."] = "Alcaz Prison'a gir ve oradaki insan muhafızlardan 8 Kan Kırmızısı Bandana topla.",
    ["Enter the Excavation Sites in the Wetlands and bring back 4 Thicket Raptor Meat."] = "Wetlands'teki Excavation Sites'a gir ve 4 Thicket Raptor Eti getir.",
    ["Escort Marshal Windsor through the prison. Clear the patrols first and have everyone ready before you start."] = "Marshal Windsor'a hapishane boyunca eşlik et. Önce devriyeleri temizle ve başlamadan önce herkesin hazır olmasını sağla.",
    ["Essence of Eranikus (drops from the Shade of Eranikus)"] = "Eranikus'un Özü (Shade of Eranikus'tan düşer)",
    ["Essence of the Elements drops from BRD elementals and golems."] = "Elementlerin Özü, BRD elementallerinden ve golemlerinden düşer.",
    ["Examine the Altar of Hakkar in the temple basement. Started from Marvon Rivetseeker after The Stone Circle."] = "Tapınak bodrumundaki Hakkar Sunağı'nı incele. The Stone Circle'dan sonra Marvon Rivetseeker'dan başlar.",
    ["Explore just west of the Vile Reef and find the cavern entrance, then report back to Kin'weelay."] = "Vile Reef'in hemen batısını keşfet ve mağara girişini bul, sonra Kin'weelay'e rapor ver.",
    ["Extra-Destructive Explosives quest-start item"] = "Extra-Destructive Explosives görev başlatma eşyası",
    ["Eye of Mugg"] = "Mugg'ın Gözü",
    ["Falla Sagewind — above Wailing Caverns"] = "Falla Sagewind — Wailing Caverns'ın üstünde",
    ["Falla Sagewind, on top of the mountain above Wailing Caverns, The Barrens (48.2, 32.8)"] = "Falla Sagewind, Wailing Caverns'ın üstündeki dağın tepesinde, The Barrens (48.2, 32.8)",
    ["Farholde Keep — Riverglades (who takes it is not known yet)"] = "Farholde Keep — Riverglades (kimin aldığı henüz bilinmiyor)",
    ["Farholde Keep, Riverglades (giver not known yet)"] = "Farholde Keep, Riverglades (görev veren henüz bilinmiyor)",
    ["Farholde Keep, Riverglades (not known yet)"] = "Farholde Keep, Riverglades (henüz bilinmiyor)",
    ["Farm Dark Iron Spies here for the Dark Iron Map"] = "Dark Iron Haritası için Dark Iron Casuslarını burada kes",
    ["Fill her vial at the dire pool along Eldreth Row in Dire Maul West; also bring 1 Enchanted Thorium Bar and 5 Crystal Restore.\n\nOptional introductory quest:"] = "Dire Maul West'te Eldreth Row boyunca uğursuz havuzda şişesini doldur; ayrıca 1 Efsunlu Thorium Külçesi ve 5 Crystal Restore getir.\n\nİsteğe bağlı giriş görevi:",
    ["Fill the Coated Cerulean Vial at the orange crystal pool in the outer caves, then use it on Vylestem Vines inside (orange side) and kill the Noxxious Scions to heal 8 plants."] = "Kaplanmış Gök Mavisi Şişe'yi dış mağaralardaki turuncu kristal havuzunda doldur, sonra içerideki (turuncu taraf) Vylestem Sarmaşıkları üzerinde kullan ve 8 bitkiyi iyileştirmek için Noxxious Scion'ları öldür.",
    ["Fill the Egg of Hakkar from the Hakkari Bloodkeepers to summon the Avatar of Hakkar."] = "Avatar of Hakkar'ı çağırmak için Hakkar Yumurtası'nı Hakkari Bloodkeeper'lardan doldur.",
    ["Final boss, in Honor's Tomb."] = "Son boss, Honor's Tomb'da.",
    ["Final boss, in the Athenaeum. Doan's Strongbox behind him holds The Scarlet Key."] = "Son boss, Athenaeum'da. Arkasındaki Doan's Strongbox'ta The Scarlet Key var.",
    ["Final dungeon step of the Defias Brotherhood chain; complete the earlier steps first."] = "Defias Brotherhood zincirinin son zindan adımı; önce önceki adımları tamamla.",
    ["Final preparation before Destruction in Deadmines."] = "Deadmines'taki Destruction öncesi son hazırlık.",
    ["Final prerequisite before the dungeon step of The Defias Brotherhood."] = "The Defias Brotherhood'un zindan adımı öncesi son ön koşul.",
    ["Final required step before Horrors in the Highland."] = "Horrors in the Highland öncesi gerekli son adım.",
    ["Final step of the Toxic Soil chain."] = "Toxic Soil zincirinin son adımı.",
    ["Final step. Ambassador Malcin is outside Razorfen Downs."] = "Son adım. Ambassador Malcin, Razorfen Downs'ın dışında.",
    ["Final step. Old Fire-Eye is at the Greymane Wall in southern Silverpine Forest. Rewards Wolfsbane."] = "Son adım. Old Fire-Eye, güney Silverpine Forest'taki Greymane Wall'da. Ödül: Wolfsbane.",
    ["Final step. Rewards Verigan's Fist."] = "Son adım. Ödül: Verigan's Fist.",
    ["Find Ardin Grassman in the Excavation Sites. Learn what happened to Ardin Grassman."] = "Excavation Sites'ta Ardin Grassman'ı bul. Ardin Grassman'a ne olduğunu öğren.",
    ["Find Braug Dimspirit near the entrance to Talondeep Path in Stonetalon Mountains."] = "Stonetalon Mountains'taki Talondeep Path girişinin yakınında Braug Dimspirit'i bul.",
    ["Find Commander Folkar inside Alcaz Prison."] = "Alcaz Prison içinde Commander Folkar'ı bul.",
    ["Find Daewyn inside the dungeon. Fallen in the Fen sends you back to Dorin Songblade in Lakeshire."] = "Daewyn'i zindanın içinde bul. Fallen in the Fen seni Lakeshire'daki Dorin Songblade'e geri gönderir.",
    ["Find Maur Grimtotem's corpse inside Ragefire Chasm and search it for anything of interest."] = "Ragefire Chasm'ın içinde Maur Grimtotem'in cesedini bul ve ilgi çekici bir şey var mı diye ara.",
    ["Find Parqual Fintallas in Undercity."] = "Undercity'deki Parqual Fintallas'ı bul.",
    ["Find The Beginnings of the Undead Threat and return it to Parqual Fintallas in Undercity."] = "The Beginnings of the Undead Threat kitabını bul ve Undercity'deki Parqual Fintallas'a geri götür.",
    ["Find The Eye of Bhossca inside of the Scarlet Monastery. Then, return it to C's dead drop near Pyrewood Village. You must complete the job alone."] = "Scarlet Monastery'nin içinde The Eye of Bhossca'yı bul. Sonra onu Pyrewood Village yakınındaki C'nin gizli bırakma noktasına götür. İşi yalnız tamamlamalısın.",
    ["Find The Horn of Xelthos inside of Shadowfang Keep. Then, return it to C's dead drop near Pyrewood Village. You must complete the job alone."] = "Shadowfang Keep'in içinde The Horn of Xelthos'u bul. Sonra onu Pyrewood Village yakınındaki C'nin gizli bırakma noktasına götür. İşi yalnız tamamlamalısın.",
    ["Find a Gordok Shackle Key on the ogres of the Gordok wing and use it to free Knot Thimblejack."] = "Gordok kanadındaki ogrelerden bir Gordok Pranga Anahtarı bul ve Knot Thimblejack'i serbest bırakmak için kullan.",
    ["Find a way into Dalaran along Lordamere Lake."] = "Lordamere Lake boyunca Dalaran'a girmenin bir yolunu bul.",
    ["Find the Legacy of the Aspects and return it to Braug Dimspirit near the entrance to Talondeep Path in Stonetalon Mountains."] = "Aspects'in Mirası'nı bul ve Stonetalon Mountains'taki Talondeep Path girişinin yakınındaki Braug Dimspirit'e geri götür.",
    ["Find the Messenger Bag at Thoradin's Wall, between Hillsbrad Foothills and the Arathi Highlands."] = "Hillsbrad Foothills ile Arathi Highlands arasındaki Thoradin's Wall'da Haberci Çantası'nı bul.",
    ["Find the cozy spot in the mountains between The Barrens and Desolace: the Pocket Litter at an abandoned camp in Stonetalon Mountains."] = "The Barrens ile Desolace arasındaki dağlarda o sıcak köşeyi bul: Stonetalon Mountains'ta terk edilmiş bir kamptaki Cep Döküntüleri.",
    ["Find the eagle's nest on the face of the Stonewrought Dam in Loch Modan: the Carved Figurine."] = "Loch Modan'daki Stonewrought Dam'in yüzündeki kartal yuvasını bul: Oyma Heykelcik.",
    ["Find the four Forsaken traitors at the Lordamere Internment Camp, recover their Bloodstone artifacts, and return to Magus Wordeen Voidglare."] = "Lordamere Internment Camp'teki dört Forsaken hainini bul, Bloodstone eserlerini geri al ve Magus Wordeen Voidglare'e dön.",
    ["Findings for the Explorer's League"] = "Explorer's League İçin Bulgular",
    ["First quest of the Toxic Soil chain."] = "Toxic Soil zincirinin ilk görevi.",
    ["First required Hidden Enemies step for the Ragefire Chasm chain."] = "Ragefire Chasm zinciri için gerekli ilk Hidden Enemies adımı.",
    ["First required step before Horrors in the Highland."] = "Horrors in the Highland öncesi gerekli ilk adım.",
    ["First required step leading to The Stockade Riots."] = "The Stockade Riots görevine götüren gerekli ilk adım.",
    ["First step of the required Defias Brotherhood chain."] = "Gerekli Defias Brotherhood zincirinin ilk adımı.",
    ["Follow the charred note from The Barrens to its twin place: the Burned-Out Remains at the Alexston Farmstead in Westfall."] = "Kömürleşmiş notu The Barrens'tan ikiz yerine kadar takip et: Westfall'daki Alexston Farmstead'de bulunan Yanmış Kalıntılar.",
    ["Follow the charred note from Westfall to its twin place: the Burned-Out Remains at the burnt tower south of Camp Taurajo in The Barrens."] = "Kömürleşmiş notu Westfall'dan ikiz yerine kadar takip et: The Barrens'ta Camp Taurajo'nun güneyindeki yanık kuledeki Yanmış Kalıntılar.",
    ["Follow-up of Lost in the Thicket Things."] = "Lost in the Thicket Things görevinin devamı.",
    ["Follows Speak with Shoni."] = "Speak with Shoni görevinden sonra gelir.",
    ["Follows the Damp Note version of Allegiance to the Old Gods."] = "Allegiance to the Old Gods görevinin Nemli Not sürümünden sonra gelir.",
    ["Fought together with Deathless Marrow."] = "Deathless Marrow ile birlikte dövüşülür.",
    ["Found in a Pitted Iron Chest underwater in the Pool of Ask'ar, in the northern alcove just past Ghamoo-ra's turtle room."] = "Ghamoo-ra'nın kaplumbağa odasını hemen geçince kuzey girintide, Pool of Ask'ar'da su altındaki bir Oyuk Demir Sandık'ta bulunur.",
    ["Found in the graveyard inside Ruins of Lordaeron"] = "Ruins of Lordaeron içindeki mezarlıkta bulunur",
    ["Found in: Jordan's Hammer, Shadowfang Keep courtyard"] = "Bulunduğu yer: Jordan's Hammer, Shadowfang Keep avlusu",
    ["Found in: a locked chest in the courtyard stables of Shadowfang Keep. Open it with the Twin Key"] = "Bulunduğu yer: Shadowfang Keep avlusundaki ahırda kilitli bir sandık. Twin Key ile aç",
    ["Found in: the Padlocked Reliquary in the first small room on the left of the Scarlet Monastery Library. Open it with the Reliquary Key"] = "Bulunduğu yer: Scarlet Monastery Library'nin solundaki ilk küçük odadaki Asma Kilitli Emanet Sandığı. Reliquary Key ile aç",
    ["Found in: the Personal Letterbox in Arcanist Doan's room, Scarlet Monastery Library. Open it with the Scryer's Key"] = "Bulunduğu yer: Scarlet Monastery Library'de Arcanist Doan'ın odasındaki Kişisel Mektup Kutusu. Scryer's Key ile aç",
    ["Found in: the Stone Coffer in the mausoleum on the north side of the Scarlet Monastery Graveyard. It opens after you sit on both benches between the two statues"] = "Bulunduğu yer: Scarlet Monastery Graveyard'ın kuzey tarafındaki türbedeki Taş Sandık. İki heykel arasındaki iki banka da oturduktan sonra açılır",
    ["Found in: the Supply Locker in the stables behind the Scarlet Monastery. Wear it to pass the Scarlet Crusade"] = "Bulunduğu yer: Scarlet Monastery'nin arkasındaki ahırdaki Erzak Dolabı. Scarlet Crusade'in arasından geçmek için giy",
    ["Found on Berard's Bookshelf in the Pyrewood Village inn (Silverpine Forest 43, 73)"] = "Pyrewood Village hanındaki Berard'ın Kitaplığı'nda bulunur (Silverpine Forest 43, 73)",
    ["Found on a table in Archmage Arugal's room at the end of Shadowfang Keep, after you kill him"] = "Shadowfang Keep'in sonunda Archmage Arugal'ı öldürdükten sonra odasındaki bir masada bulunur",
    ["Found while investigating the Dalaran forces around the Lordamere Internment Camp"] = "Lordamere Internment Camp çevresindeki Dalaran kuvvetleri araştırılırken bulunur",
    ["From Amnennar the Coldbringer, the last boss of Razorfen Downs"] = "Razorfen Downs'ın son boss'u Amnennar the Coldbringer'dan",
    ["From Nar'gurk in Krol'dok Stronghold"] = "Krol'dok Stronghold'daki Nar'gurk'tan",
    ["From Overlord Mugg, the last boss of Krol'dok Stronghold"] = "Krol'dok Stronghold'un son boss'u Overlord Mugg'dan",
    ["From The Beast's corpse, Upper Blackrock Spire"] = "The Beast'in cesedinden, Upper Blackrock Spire",
    ["From Veenix, Stonetalon Mountains, for a Venture Co. Work Order. Blows open the courtyard gate of Shadowfang Keep"] = "Bir Venture Co. İş Emri karşılığında Stonetalon Mountains'taki Veenix'ten. Shadowfang Keep'in avlu kapısını patlatarak açar",
    ["From Witch Doctor Zum'rah, Zul'Farrak"] = "Zul'Farrak'taki Witch Doctor Zum'rah'tan",
    ["From the Defias guards in Alcaz Prison"] = "Alcaz Prison'daki Defias muhafızlarından",
    ["From the first major three-way junction, take the right-hand tunnel, follow it uphill toward the dead end, then enter the small side room on the left. Interact with Maur's corpse there."] = "İlk büyük üç yollu kavşaktan sağdaki tünele gir, onu yokuş yukarı çıkmaza doğru takip et, sonra soldaki küçük yan odaya gir. Oradaki Maur'un cesediyle etkileşime geç.",
    ["From the most powerful priest in the Drowned City"] = "Drowned City'deki en güçlü rahipten",
    ["From the tablet Fall of Gurubashi, in the troll ruins on the coast north of the Vile Reef (around 23, 12)"] = "Fall of Gurubashi tabletinden, Vile Reef'in kuzeyindeki kıyıda trol harabelerinde (yaklaşık 23, 12)",
    ["From the tablet Gri'lek the Wanderer, at the bottom of the Vile Reef (around 25, 23)"] = "Gri'lek the Wanderer tabletinden, Vile Reef'in dibinde (yaklaşık 25, 23)",
    ["From the tablet Moon Over the Vale (around 29, 19)"] = "Moon Over the Vale tabletinden (yaklaşık 29, 19)",
    ["From the tablet The Emperor's Tomb (around 25, 9)"] = "The Emperor's Tomb tabletinden (yaklaşık 25, 9)",
    ["Frost Shock and You (book, Dire Maul drop)"] = "Frost Shock and You (kitap, Dire Maul ganimeti)",
    ["Garona: A Study on Stealth and Treachery (book, Dire Maul drop)"] = "Garona: A Study on Stealth and Treachery (kitap, Dire Maul ganimeti)",
    ["Gather 10 Brinescale Tridents from Brinescale Skirmishers."] = "Brinescale Skirmisher'lardan 10 Brinescale Trident topla.",
    ["General Drakkisath's Command (drops from Overlord Wyrmthalak)"] = "General Drakkisath's Command (Overlord Wyrmthalak'tan düşer)",
    ["Gerrig Bonegrip, Forlorn Cavern, Ironforge (50.8, 5.6)"] = "Gerrig Bonegrip, Forlorn Cavern, Ironforge (50.8, 5.6)",
    ["Gershala Nightwhisper, Auberdine, Darkshore (38.3, 43.1)"] = "Gershala Nightwhisper, Auberdine, Darkshore (38.3, 43.1)",
    ["Get a Gordok Shackle Key from the North ogres and free Knot; his cache has loot."] = "North ogrelerinden bir Gordok Pranga Anahtarı al ve Knot'u serbest bırak; zulasında ganimet var.",
    ["Get poisoned by Mother Smolderweb and reach Ragged John while still poisoned. Don't let anyone cleanse it."] = "Mother Smolderweb tarafından zehirlen ve hâlâ zehirliyken Ragged John'a ulaş. Kimsenin zehri temizlemesine izin verme.",
    ["Ghostly Attendant, inside Hall of Thanes, after the first room"] = "Ghostly Attendant, Hall of Thanes içinde, ilk odadan sonra",
    ["Ghostly Attendant, inside the dungeon"] = "Ghostly Attendant, zindanın içinde",
    ["Give Aurius the Medallion of Faith before the Baron fight; speak to him after Baron Rivendare dies."] = "Baron savaşından önce İnanç Madalyonu'nu Aurius'a ver; Baron Rivendare öldükten sonra onunla konuş.",
    ["Give Aurius the Medallion of Faith; he joins the fight against Baron Rivendare. Claim his reward after the battle."] = "İnanç Madalyonu'nu Aurius'a ver; Baron Rivendare'e karşı savaşa katılır. Savaştan sonra ödülünü al.",
    ["Given by Ashe Amberhall when you accept the quest"] = "Görevi kabul ettiğinde Ashe Amberhall verir",
    ["Given by Brother Nimetz when you accept the quest"] = "Görevi kabul ettiğinde Brother Nimetz verir",
    ["Given by Jordan Stilwell when you accept the quest"] = "Görevi kabul ettiğinde Jordan Stilwell verir",
    ["Given by Trevan Rol in the Sepulcher"] = "Sepulcher'daki Trevan Rol verir",
    ["Gnomeregan — outer area"] = "Gnomeregan — dış bölge",
    ["Gordok Commons, the ogre-held northern wing. Kill King Gordok to become the new king; leave the guards alive (the Tribute Run) for a bigger tribute chest."] = "Ogrelerin elindeki kuzey kanadı Gordok Commons. Yeni kral olmak için King Gordok'u öldür; daha büyük bir haraç sandığı için muhafızları hayatta bırak (Tribute Run).",
    ["Grime-Encrusted Ring, dropped by Dark Iron dwarves in Gnomeregan"] = "Kirle Kaplı Yüzük, Gnomeregan'daki Dark Iron cücelerinden düşer",
    ["Grimtotem Satchel, taken from Maur Grimtotem's corpse inside Ragefire Chasm"] = "Grimtotem Heybesi, Ragefire Chasm içindeki Maur Grimtotem'in cesedinden alınır",
    ["Grom'gol Base Camp, Stranglethorn Vale (not known yet)"] = "Grom'gol Base Camp, Stranglethorn Vale (henüz bilinmiyor)",
    ["Grom'gol Base Camp, Stranglethorn Vale (quest giver not known yet)"] = "Grom'gol Base Camp, Stranglethorn Vale (görev veren henüz bilinmiyor)",
    ["Gromsblood, Giant Silver Veins (Azshara cliff giants) and the vial filled at Golakka Hot Springs in Un'Goro. Opens a peaceful way through the bar on later visits."] = "Gromsblood, Dev Gümüş Damarları (Azshara uçurum devleri) ve Un'Goro'daki Golakka Hot Springs'te doldurulan şişe. Sonraki ziyaretlerde bardan barışçıl bir geçiş açar.",
    ["Group quest: Riptear is a level 13 elite."] = "Grup görevi: Riptear 13. seviye elit.",
    ["Group quest: the Saltscale murlocs at the Vile Reef are elite."] = "Grup görevi: Vile Reef'teki Saltscale murlocları elit.",
    ["Group quest: the inn is in Pyrewood Village, among hostile villagers."] = "Grup görevi: han, düşman köylülerin arasında, Pyrewood Village'da.",
    ["Gryan Stoutmantle, Sentinel Hill tower, Westfall (56.4, 47.5)"] = "Gryan Stoutmantle, Sentinel Hill kulesi, Westfall (56.4, 47.5)",
    ["Gryan Stoutmantle: Sentinel Hill, Westfall"] = "Gryan Stoutmantle: Sentinel Hill, Westfall",
    ["Halfway down: the path right (east), into the mountains"] = "Yarı yolda: sağdaki (doğu) patika, dağlara",
    ["Hammertoe Grez — Uldaman excavation (outside the instance)"] = "Hammertoe Grez — Uldaman kazısı (zindanın dışında)",
    ["Hammertoe Grez, Uldaman excavation (outside the instance)"] = "Hammertoe Grez, Uldaman kazısı (zindanın dışında)",
    ["Hammertoe is in the outer excavation caves, before the instance portal"] = "Hammertoe, zindan portalından önce dış kazı mağaralarında",
    ["Hand in The Archivist first, or Balnazzar's head will not start this quest."] = "Önce The Archivist'i teslim et, yoksa Balnazzar'ın kafası bu görevi başlatmaz.",
    ["Hands, Leather"] = "Eller, Deri",
    ["Hanging outside the room in Thoradin's Wall"] = "Thoradin's Wall'daki odanın dışında asılı",
    ["Harbinger Balthazad — Undercity (walks around)"] = "Harbinger Balthazad — Undercity (dolaşır)",
    ["Harbinger Balthazad, Undercity (or Warcaller Gorlach, Orgrimmar / Bluff Runner Windstrider, Thunder Bluff)"] = "Harbinger Balthazad, Undercity (veya Warcaller Gorlach, Orgrimmar / Bluff Runner Windstrider, Thunder Bluff)",
    ["Harbinger Balthazad: Trade Quarter, Undercity (walks around)"] = "Harbinger Balthazad: Trade Quarter, Undercity (dolaşır)",
    ["Harnessing Shadows (book, Dire Maul drop)"] = "Harnessing Shadows (kitap, Dire Maul ganimeti)",
    ["Hastily Rolled-Up Satchel, right under the Messenger Bag"] = "Aceleyle Sarılmış Heybe, Ulak Çantası'nın hemen altında",
    ["He appears from The Beast's corpse after the fight. Malyfous then offers the Pristine Hide of the Beast exchanges."] = "Savaştan sonra The Beast'in cesedinden çıkar. Malyfous ardından Pristine Hide of the Beast takaslarını sunar.",
    ["Head of Balnazzar (drops from Balnazzar)"] = "Balnazzar'ın Kafası (Balnazzar'dan düşer)",
    ["Head straight north from the camp, climb the hill and jump down from its edge to the Mound of Dirt. Watch your step."] = "Kamptan dümdüz kuzeye git, tepeye tırman ve kenarından toprak yığınına atla. Adımına dikkat et.",
    ["Head, Mail"] = "Baş, Zincir",
    ["Henrig Lonebrow — bottom of the Great Lift"] = "Henrig Lonebrow — Great Lift'in dibi",
    ["Henrig Lonebrow's Journal beside his corpse at the bottom of the Great Lift"] = "Henrig Lonebrow'un Günlüğü, Great Lift'in dibinde cesedinin yanında",
    ["Heralath Fallowbrook, inside Razorfen Kraul"] = "Heralath Fallowbrook, Razorfen Kraul içinde",
    ["Herod is in the Armory; Loksey in the Library; Mograine and Whitemane in the Cathedral."] = "Herod Armory'de; Loksey Library'de; Mograine ve Whitemane Cathedral'da.",
    ["Herod is in the Armory; Loksey in the Library; Mograine and Whitemane in the Cathedral.\n\nOptional introductory quest:"] = "Herod Armory'de; Loksey Library'de; Mograine ve Whitemane Cathedral'da.\n\nİsteğe bağlı giriş görevi:",
    ["Historian Karnik in the Hall of Explorers, Ironforge"] = "Historian Karnik, Hall of Explorers, Ironforge",
    ["Holy Bologna: What the Light Won't Tell You (book, Dire Maul drop)"] = "Holy Bologna: What the Light Won't Tell You (kitap, Dire Maul ganimeti)",
    ["Horde Dalaran attunement. Stone Tokens and Bracers of Binding can be done alongside the chain, but they are optional and are not required for attunement."] = "Horde Dalaran uyumlanması. Stone Tokens ve Bracers of Binding zincirle birlikte yapılabilir ama isteğe bağlıdır, uyumlanma için gerekli değildir.",
    ["Horde step required before Nogg's Ring Redo."] = "Nogg's Ring Redo öncesi gerekli Horde adımı.",
    ["Hunter class book. Click the book to start the quest."] = "Hunter sınıf kitabı. Görevi başlatmak için kitaba tıkla.",
    ["Hunter class quest. The Tooth of Morphaz drops from Morphaz.\n\nOptional introductory quest:"] = "Hunter sınıf görevi. Morphaz'ın Dişi Morphaz'dan düşer.\n\nİsteğe bağlı giriş görevi:",
    ["Hunter trainers"] = "Hunter eğitmenleri",
    ["I'lalai, a lost Gurubashi troll city, has risen from the sea off the coast of Stranglethorn Vale, west of Grom'gol. Trolls and naga roam the streets of this open-air dungeon, a pirate ship lies wrecked nearby, and the weather builds into a full storm before the final fight. Dive underwater to find the entrance."] = "Kayıp bir Gurubashi trol şehri olan I'lalai, Stranglethorn Vale kıyısı açıklarında, Grom'gol'un batısında denizden yükseldi. Bu açık hava zindanının sokaklarında troller ve nagalar dolaşıyor, yakında bir korsan gemisi batık yatıyor ve son savaştan önce hava tam bir fırtınaya dönüşüyor. Girişi bulmak için su altına dal.",
    ["If you have faith, leap from the planks overlooking Thousand Needles."] = "İnancın varsa, Thousand Needles'a bakan tahtalardan atla.",
    ["Image of Archmage Modera — Lordamere Lake near Dalaran"] = "Image of Archmage Modera — Dalaran yakınındaki Lordamere Lake",
    ["Image of Archmage Modera, Lordamere Lake near Dalaran"] = "Image of Archmage Modera, Dalaran yakınındaki Lordamere Lake",
    ["In Krol'dok Stronghold (the Alliance quest of the same name takes it from Nar'gurk)"] = "Krol'dok Stronghold'da (aynı adlı Alliance görevi onu Nar'gurk'tan alır)",
    ["In a tent on top of the mountain above Wailing Caverns"] = "Wailing Caverns'ın üstündeki dağın tepesinde bir çadırda",
    ["In the Chamber of Atonement. Drops Vorrel's Wedding Ring for Vorrel's Revenge."] = "Chamber of Atonement'ta. Vorrel's Revenge için Vorrel's Wedding Ring düşürür.",
    ["In the Map Chamber beyond Archaedas, inside Uldaman"] = "Uldaman içinde, Archaedas'ın ötesindeki Map Chamber'da",
    ["Infiltrate Krol'dok Stronghold and return to Commander Brant with proof of their leader's demise."] = "Krol'dok Stronghold'a sız ve liderlerinin ölümünün kanıtıyla Commander Brant'e dön.",
    ["Infiltrate Krol'dok Stronghold and return to Krom'rosh with proof of their leader's demise."] = "Krol'dok Stronghold'a sız ve liderlerinin ölümünün kanıtıyla Krom'rosh'a dön.",
    ["Inside a vault in the Reliquary of Kings (Durgen Dirgehammer's room)"] = "Reliquary of Kings'teki bir kasanın içinde (Durgen Dirgehammer'ın odası)",
    ["Inside the building in Tarren Mill"] = "Tarren Mill'deki binanın içinde",
    ["Inside the instance, in the Dormitory."] = "Zindanın içinde, Dormitory'de.",
    ["Interact with the Skeletal Remains of Telmius Dreamseeker beside Lorekeeper Lydros in the Athenaeum. Unlocks Lydros's libram exchanges."] = "Athenaeum'da Lorekeeper Lydros'un yanındaki Telmius Dreamseeker'ın İskelet Kalıntıları ile etkileşime geç. Lydros'un libram takaslarını açar.",
    ["Introductory quest leading to Heart of Disruption and Starving Arcane."] = "Heart of Disruption ve Starving Arcane görevlerine götüren giriş görevi.",
    ["Introductory step leading to A Better Ingredient."] = "A Better Ingredient görevine götüren giriş adımı.",
    ["Introductory step leading to Agmond's Fate."] = "Agmond's Fate görevine götüren giriş adımı.",
    ["Introductory step leading to Blood of Morphaz."] = "Blood of Morphaz görevine götüren giriş adımı.",
    ["Introductory step leading to Destroy Morphaz."] = "Destroy Morphaz görevine götüren giriş adımı.",
    ["Introductory step leading to Doomrigger's Clasp."] = "Doomrigger's Clasp görevine götüren giriş adımı.",
    ["Introductory step leading to Forging the Mightstone."] = "Forging the Mightstone görevine götüren giriş adımı.",
    ["Introductory step leading to Fragments of the Past."] = "Fragments of the Past görevine götüren giriş adımı.",
    ["Introductory step leading to Gahz'rilla."] = "Gahz'rilla görevine götüren giriş adımı.",
    ["Introductory step leading to Hurley Blackbreath."] = "Hurley Blackbreath görevine götüren giriş adımı.",
    ["Introductory step leading to In the Name of the Light."] = "In the Name of the Light görevine götüren giriş adımı.",
    ["Introductory step leading to Lethtendris's Web."] = "Lethtendris's Web görevine götüren giriş adımı.",
    ["Introductory step leading to Lost Thunderbrew Recipe."] = "Lost Thunderbrew Recipe görevine götüren giriş adımı.",
    ["Introductory step leading to Ramstein."] = "Ramstein görevine götüren giriş adımı.",
    ["Introductory step leading to Researching the Corruption."] = "Researching the Corruption görevine götüren giriş adımı.",
    ["Introductory step leading to Ribbly Screwspigot."] = "Ribbly Screwspigot görevine götüren giriş adımı.",
    ["Introductory step leading to Scarab Shells."] = "Scarab Shells görevine götüren giriş adımı.",
    ["Introductory step leading to The Azure Key."] = "The Azure Key görevine götüren giriş adımı.",
    ["Introductory step leading to The Darkstone Tablet."] = "The Darkstone Tablet görevine götüren giriş adımı.",
    ["Introductory step leading to The Essence of Aku'Mai."] = "The Essence of Aku'Mai görevine götüren giriş adımı.",
    ["Introductory step leading to The Green Drake."] = "The Green Drake görevine götüren giriş adımı.",
    ["Introductory step leading to The Hidden Chamber."] = "The Hidden Chamber görevine götüren giriş adımı.",
    ["Introductory step leading to The Restless Souls."] = "The Restless Souls görevine götüren giriş adımı.",
    ["Introductory step leading to Tiara of the Deep."] = "Tiara of the Deep görevine götüren giriş adımı.",
    ["Introductory step leading to Voodoo Feathers."] = "Voodoo Feathers görevine götüren giriş adımı.",
    ["Investigate the fissure beneath the Forgotten Pools."] = "Forgotten Pools'un altındaki yarığı araştır.",
    ["Investigate whether Westfall's mines are causing the contamination."] = "Westfall madenlerinin kirlenmeye yol açıp açmadığını araştır.",
    ["Item start:"] = "Eşyayla başlar:",
    ["Item start: Abominable Head, inside Ruins of Lordaeron"] = "Eşyayla başlar: Abominable Head, Ruins of Lordaeron içinde",
    ["Item start: Blood-Stained Letter, graveyard inside Ruins of Lordaeron"] = "Eşyayla başlar: Blood-Stained Letter, Ruins of Lordaeron içindeki mezarlık",
    ["Item start: Bloodied Insignia, inside Ruins of Lordaeron"] = "Eşyayla başlar: Bloodied Insignia, Ruins of Lordaeron içinde",
    ["Item start: Crest of Lordaeron, inside Ruins of Lordaeron"] = "Eşyayla başlar: Crest of Lordaeron, Ruins of Lordaeron içinde",
    ["Item start: Glowing Shard, dropped by Mutanus the Devourer"] = "Eşyayla başlar: Glowing Shard, Mutanus the Devourer düşürür",
    ["Item-start quest from the Blood-Stained Letter."] = "Blood-Stained Letter ile başlayan görev.",
    ["Jasper Fel, SI:7, Old Town, Stormwind"] = "Jasper Fel, SI:7, Old Town, Stormwind",
    ["Jasper Fel: SI:7, Old Town, Stormwind"] = "Jasper Fel: SI:7, Old Town, Stormwind",
    ["Je'neu Sancrea, Zoram'gar Outpost, Ashenvale (12, 34)"] = "Je'neu Sancrea, Zoram'gar Outpost, Ashenvale (12, 34)",
    ["Jordan Stilwell stands outside the gates of Ironforge"] = "Jordan Stilwell, Ironforge kapılarının dışında duruyor",
    ["Jump onto the carved heads of the dam, on the side facing the Wetlands, to reach the figurine. Getting there is tricky for the Horde."] = "Heykelciğe ulaşmak için barajın Wetlands'e bakan tarafındaki oyma kafaların üzerine atla. Oraya ulaşmak Horde için zordur.",
    ["KILL ON SIGHT poster"] = "GÖRÜLDÜĞÜ YERDE ÖLDÜR afişi",
    ["KILL ON SIGHT poster — Kargath, Badlands"] = "GÖRÜLDÜĞÜ YERDE ÖLDÜR afişi — Kargath, Badlands",
    ["Keep Princess Moira alive and speak to her after Emperor Thaurissan dies. Her The Princess Saved? sends you back to Thrall for the reward."] = "Princess Moira'yı hayatta tut ve Emperor Thaurissan öldükten sonra onunla konuş. Onun The Princess Saved? görevi ödül için seni Thrall'a geri gönderir.",
    ["Keep Princess Moira alive and speak to her after Emperor Thaurissan dies. Her The Princess's Surprise sends you back to Magni for the reward."] = "Princess Moira'yı hayatta tut ve Emperor Thaurissan öldükten sonra onunla konuş. Onun The Princess's Surprise görevi ödül için seni Magni'ye geri gönderir.",
    ["Keep the card for Matrix Punchograph 3005-A"] = "Kartı Matrix Punchograph 3005-A için sakla",
    ["Kernobee, inside Gnomeregan"] = "Kernobee, Gnomeregan içinde",
    ["Kill 20 Plagued Hatchlings. After turning this in, hatchlings can drop Healthy Dragon Scales, which start a repeatable turn-in to Betina."] = "20 Vebalı Yavru öldür. Bunu teslim ettikten sonra yavrular, Betina'ya tekrarlanabilir teslim başlatan Sağlıklı Ejderha Pulu düşürebilir.",
    ["Kill 6 Dalaran Summoners and 12 Elemental Slaves, then return to Magus Wordeen Voidglare in Tarren Mill."] = "6 Dalaran Summoner ve 12 Elemental Slave öldür, sonra Tarren Mill'deki Magus Wordeen Voidglare'e dön.",
    ["Kill Alzzin the Wildshaper, pick up a Felvine Shard near the vine and seal it in the Reliquary of Purity."] = "Alzzin the Wildshaper'ı öldür, sarmaşığın yanından bir Felvine Parçası al ve onu Reliquary of Purity'ye mühürle.",
    ["Kill Archivist Galford in the Scarlet Bastion and burn the archives."] = "Scarlet Bastion'da Archivist Galford'u öldür ve arşivleri yak.",
    ["Kill General Drakkisath at the end of UBRS."] = "UBRS'nin sonunda General Drakkisath'ı öldür.",
    ["Kill Golem Lord Argelmach for his head and collect 10 Intact Elemental Cores from the constructs guarding him."] = "Kafası için Golem Lord Argelmach'ı öldür ve onu koruyan yapılardan 10 Sağlam Elemental Çekirdek topla.",
    ["Kill Halycon, the worg den mother. Be ready for Gizrul the Slavener, who comes for you right after."] = "Worg ini annesi Halycon'u öldür. Hemen ardından sana gelecek olan Gizrul the Slavener'a hazır ol.",
    ["Kill Lord Incendius at the Black Anvil inside BRD and bring back the Tablet of Kurniya."] = "BRD içindeki Black Anvil'de Lord Incendius'u öldür ve Kurniya Tableti'ni geri getir.",
    ["Kill Lord Incendius at the Black Anvil inside BRD."] = "BRD içindeki Black Anvil'de Lord Incendius'u öldür.",
    ["Kill Nar'gurk in Krol'dok Stronghold and recover any valuable information."] = "Krol'dok Stronghold'da Nar'gurk'u öldür ve değerli her bilgiyi ele geçir.",
    ["Kill Princess Theradras in the inner cavern."] = "İç mağarada Princess Theradras'ı öldür.",
    ["Kill Riptear in north-east Tirisfal Glades and bring Riptear's Heart to Deathguard Linnea."] = "Kuzeydoğu Tirisfal Glades'teki Riptear'ı öldür ve Riptear'ın Kalbi'ni Deathguard Linnea'ya getir.",
    ["Kill a Highland Horror within Excavation Sites and bring its root core to Rethiel the Greenwarden in the Wetlands."] = "Excavation Sites içinde bir Highland Horror öldür ve kök çekirdeğini Wetlands'teki Rethiel the Greenwarden'a getir.",
    ["Kill mobs in the outer Gnomeregan area until a White Punch Card drops."] = "Beyaz Delikli Kart düşene kadar dış Gnomeregan bölgesindeki yaratıkları öldür.",
    ["Kill the guardians of all five pylons, then Immol'thar, then Prince Tortheldrin. Return to the Ancient, take The Treasure of the Shen'dralar and open the chest under the library stairs for the reward."] = "Beş pilonun hepsinin muhafızlarını, sonra Immol'thar'ı, sonra Prince Tortheldrin'i öldür. Ancient'a dön, The Treasure of the Shen'dralar'ı al ve ödül için kütüphane merdivenlerinin altındaki sandığı aç.",
    ["Kill the six troll guardians on the balconies to drop Jammal'an's barrier, then bring back his head."] = "Jammal'an'ın bariyerini düşürmek için balkonlardaki altı trol muhafızını öldür, sonra kafasını geri getir.",
    ["Kin'weelay at Grom'gol Base Camp, Stranglethorn Vale"] = "Kin'weelay, Grom'gol Base Camp, Stranglethorn Vale",
    ["Klockmort Spannerspan: Tinker Town, Ironforge"] = "Klockmort Spannerspan: Tinker Town, Ironforge",
    ["Krazek — upper floor"] = "Krazek — üst kat",
    ["Krazek, Booty Bay, Stranglethorn Vale (not confirmed)"] = "Krazek, Booty Bay, Stranglethorn Vale (doğrulanmadı)",
    ["Krazek, upstairs in Booty Bay, Stranglethorn Vale"] = "Krazek, Booty Bay'de üst katta, Stranglethorn Vale",
    ["Krazek: Booty Bay inn, upper floor"] = "Krazek: Booty Bay hanı, üst kat",
    ["Krom'rosh, Riverglades (exact spot not known yet)"] = "Krom'rosh, Riverglades (tam yeri henüz bilinmiyor)",
    ["Leads to General Drakkisath's Demise in Upper Blackrock Spire."] = "Upper Blackrock Spire'daki General Drakkisath's Demise görevine götürür.",
    ["Legs, Leather"] = "Bacaklar, Deri",
    ["Light the statues around the circle in the right order to summon Atal'alarion."] = "Atal'alarion'u çağırmak için çemberin etrafındaki heykelleri doğru sırayla yak.",
    ["Long rumored to hold high-ranking prisoners, including King Varian Wrynn, the prison on Alcaz Island has been out of reach until now. Inside, the Defias Brotherhood and the naga are at war."] = "Uzun zamandır King Varian Wrynn dahil üst düzey tutsakları barındırdığı söylenen Alcaz Island'daki hapishaneye şimdiye kadar ulaşılamıyordu. İçeride Defias Brotherhood ile nagalar savaş hâlinde.",
    ["Long rumored to hold high-ranking prisoners, including King Varian Wrynn, the prison on Alcaz Island has been out of reach until now. Inside, the Defias Brotherhood and the naga are at war. Known bosses so far: Blazeroar."] = "Uzun zamandır King Varian Wrynn dahil üst düzey tutsakları barındırdığı söylenen Alcaz Island'daki hapishaneye şimdiye kadar ulaşılamıyordu. İçeride Defias Brotherhood ile nagalar savaş hâlinde. Şimdilik bilinen bosslar: Blazeroar.",
    ["Look for Dorin Songblade's brother, Daewyn, in Whelgar's Excavation Site."] = "Dorin Songblade'in kardeşi Daewyn'i Whelgar's Excavation Site'ta ara.",
    ["Look for King Varian Wrynn in Alcaz Prison."] = "Alcaz Prison'da King Varian Wrynn'i ara.",
    ["Loot Lonebrow's Journal here"] = "Lonebrow'un Günlüğü'nü buradan al",
    ["Loot the Amulet of Spirits from the Nameless Prophet in the outer caves, then use it to fight the five Khans: three in the outer caves, one on the purple route and one on the orange route. Combine their gems with the amulet."] = "Dış mağaralardaki Nameless Prophet'ten Ruhlar Muskası'nı al, sonra beş Khan ile savaşmak için kullan: üçü dış mağaralarda, biri mor rotada ve biri turuncu rotada. Taşlarını muskayla birleştir.",
    ["Looted from"] = "Alındığı yer:",
    ["Looted from Edwin VanCleef"] = "Edwin VanCleef'ten alınır",
    ["Loremaster Dibbs in Southshore, Hillsbrad Foothills"] = "Loremaster Dibbs, Southshore, Hillsbrad Foothills",
    ["Lying at the dwarf dig site west of Hammertoe's Digsite, Badlands"] = "Badlands'te Hammertoe's Digsite'ın batısındaki cüce kazı alanında yerde duruyor",
    ["Mage class book. Click the book to start the quest."] = "Mage sınıf kitabı. Görevi başlatmak için kitaba tıkla.",
    ["Mage class quest. Lydros is in the Athenaeum (North/West); Hydrospawn Essence drops from Hydrospawn in East. Rewards Conjure Water (Rank 7)."] = "Mage sınıf görevi. Lydros, Athenaeum'da (Kuzey/Batı); Hydrospawn Özü, Doğu'daki Hydrospawn'dan düşer. Ödül: Conjure Water (Rütbe 7).",
    ["Mage class quest. The Arcane Shard drops from Morphaz.\n\nOptional introductory quest:"] = "Mage sınıf görevi. Arkan Kırığı Morphaz'dan düşer.\n\nİsteğe bağlı giriş görevi:",
    ["Mage class quest. The Obsidian Sentinel guards the back entrance of Uldaman. Continues with Mana Surges for the Celestial Orb or Celestial Stave."] = "Mage sınıf görevi. Obsidian Sentinel, Uldaman'ın arka girişini korur. Celestial Orb veya Celestial Stave için Mana Surges ile devam eder.",
    ["Mage trainers"] = "Mage eğitmenleri",
    ["Mage trainers (mages only)"] = "Mage eğitmenleri (yalnızca mage'ler)",
    ["Magics of the Drowned City"] = "Drowned City'nin Büyüleri",
    ["Main Hand, Sword"] = "Ana El, Kılıç",
    ["Make rubbings of the four Tablets of I'lalai in the Drowned City."] = "Drowned City'deki dört I'lalai Tableti'nin kopyasını çıkar.",
    ["Malor's Strongbox in the Scarlet Bastion holds the medallion. Give it to Aurius in the chapel before fighting the Baron."] = "Madalyon, Scarlet Bastion'daki Malor'un Kasası'nda. Baron ile savaşmadan önce onu şapeldeki Aurius'a ver.",
    ["Master Mathias Shaw: SI:7, Old Town, Stormwind"] = "Master Mathias Shaw: SI:7, Old Town, Stormwind",
    ["Matrix Punchograph 3005-A, Workshop area of the Train Depot, outside the instance"] = "Matrix Punchograph 3005-A, Train Depot'nun atölye bölümü, zindanın dışında",
    ["Matrix Punchograph 3005-B, The Dormitory (just past the Clean Zone), inside the instance"] = "Matrix Punchograph 3005-B, The Dormitory (Clean Zone'u hemen geçince), zindanın içinde",
    ["Matrix Punchograph 3005-C, upper platform of the Launch Bay with Electrocutioner 6000"] = "Matrix Punchograph 3005-C, Electrocutioner 6000'in bulunduğu Launch Bay'in üst platformu",
    ["Matrix Punchograph 3005-D, west side of the lower level of the Engineering Labs"] = "Matrix Punchograph 3005-D, Engineering Labs'in alt katının batı tarafı",
    ["Maur Grimtotem's corpse"] = "Maur Grimtotem'in cesedi",
    ["Maur Grimtotem's corpse inside Ragefire Chasm. From the first major three-way junction, take the right-hand tunnel, follow it uphill toward the dead end, then enter the small side room on the left. Interact with Maur's corpse there."] = "Ragefire Chasm içindeki Maur Grimtotem'in cesedi. İlk büyük üç yollu kavşaktan sağdaki tünele gir, onu yokuş yukarı çıkmaza doğru takip et, sonra soldaki küçük yan odaya gir. Oradaki Maur'un cesediyle etkileşime geç.",
    ["Maur Grimtotem's corpse, inside Ragefire Chasm"] = "Maur Grimtotem'in cesedi, Ragefire Chasm içinde",
    ["Mazu'kon of the Earthen Ring, north-west Mulgore"] = "Earthen Ring'den Mazu'kon, kuzeybatı Mulgore",
    ["Messenger Bag hanging at Thoradin's Wall, Hillsbrad Foothills (85.7, 52.2)"] = "Thoradin's Wall'da asılı Ulak Çantası, Hillsbrad Foothills (85.7, 52.2)",
    ["Mining 230. Talk to Gloom'rel before the Seven fight; give the Spectral Chalice 2 Star Rubies, 20 Gold Bars and 10 Truesilver Bars to learn Smelt Dark Iron."] = "Madencilik 230. Seven savaşından önce Gloom'rel ile konuş; Smelt Dark Iron'u öğrenmek için Hayalet Kadeh'e 2 Yıldız Yakutu, 20 Altın Külçe ve 10 Truesilver Külçe ver.",
    ["Monastery-wide collection: any Scarlet humanoid on the way to the Cathedral can drop Hearts of Zeal."] = "Manastır genelinde toplama: Cathedral'a giden yoldaki herhangi bir Scarlet insansısı Şevk Kalbi düşürebilir.",
    ["Mound of Dirt below the cliff north of the camp, Stonetalon Mountains (39.6, 49.9)"] = "Kampın kuzeyindeki uçurumun altındaki toprak yığını, Stonetalon Mountains (39.6, 49.9)",
    ["Myriam Moonsinger, Razorfen Downs thorn maze, The Barrens"] = "Myriam Moonsinger, Razorfen Downs diken labirenti, The Barrens",
    ["Nailed Plank next to the Burned-Out Remains at the Alexston Farmstead, Westfall (37.4, 50.9)"] = "Çivili Tahta, Alexston Farmstead'deki Yanmış Kalıntılar'ın yanında, Westfall (37.4, 50.9)",
    ["Nailed Plank on the side of the burnt tower south of Camp Taurajo, The Barrens (46.4, 73.8)"] = "Camp Taurajo'nun güneyindeki yanık kulenin yanında çivili tahta, The Barrens (46.4, 73.8)",
    ["Nalpak, above the entrance to Wailing Caverns, The Barrens"] = "Nalpak, Wailing Caverns girişinin üstünde, The Barrens",
    ["Nara Wildmane is the final prerequisite before Leaders of the Fang becomes available."] = "Nara Wildmane, Leaders of the Fang açılmadan önceki son ön koşul.",
    ["Near the entrance to Talondeep Path"] = "Talondeep Path girişinin yakınında",
    ["Needs both KILL ON SIGHT quests and the Grark Lorkrub escort first."] = "Önce her iki KILL ON SIGHT görevi ve Grark Lorkrub eskortu gerekir.",
    ["Neeru is in the Cleft of Shadow near the Ragefire Chasm entrance."] = "Neeru, Ragefire Chasm girişinin yakınındaki Cleft of Shadow'da.",
    ["New in Forever. The book is held by Arcanist Doan."] = "Forever'da yeni. Kitap Arcanist Doan'dadır.",
    ["Newer Classic records call him Ezra Grimm. Clear the smoke shop, touch the tobacco box and kill the shopkeeper."] = "Daha yeni Classic kayıtları ona Ezra Grimm der. Tütün dükkânını temizle, tütün kutusuna dokun ve dükkân sahibini öldür.",
    ["Northern Barrens"] = "Kuzey Barrens",
    ["Nostro's Compendium of Dragon Slaying (rare Dire Maul drop)"] = "Nostro's Compendium of Dragon Slaying (nadir Dire Maul ganimeti)",
    ["Not confirmed yet"] = "Henüz doğrulanmadı",
    ["Not confirmed, but probable drop"] = "Doğrulanmadı, ama olası düşüş",
    ["Not known yet"] = "Henüz bilinmiyor",
    ["Not known yet (a Kirin Tor mage who works with Archmage Lan'dalock in Dalaran)"] = "Henüz bilinmiyor (Dalaran'da Archmage Lan'dalock ile çalışan bir Kirin Tor büyücüsü)",
    ["Not known yet (a highborne; Kirin Tor reputation, so probably in Dalaran)"] = "Henüz bilinmiyor (bir highborne; Kirin Tor itibarı, yani muhtemelen Dalaran'da)",
    ["Not known yet (probably Sergeant Ulka or Commander Folkar, of the Kor'kron at Alcaz Prison)"] = "Henüz bilinmiyor (muhtemelen Alcaz Prison'daki Kor'kron'dan Sergeant Ulka veya Commander Folkar)",
    ["OPTIONAL, not required"] = "İSTEĞE BAĞLI, gerekli değil",
    ["Objective not confirmed yet."] = "Hedef henüz doğrulanmadı.",
    ["Off Hand, Shield"] = "Yan El, Kalkan",
    ["Offered after C's next letter reaches you in a capital city."] = "C'nin bir sonraki mektubu sana bir başkentte ulaştıktan sonra sunulur.",
    ["Ogre outrunners have been kidnapping travelers and raiding settlements across the Riverglades. Their trail leads to a fortress of workshops, encampments and guarded inner passages, where strange chanting is heard after nightfall."] = "Ogre akıncıları Riverglades genelinde yolcuları kaçırıyor ve yerleşimlere baskın yapıyor. İzleri atölyeler, kamplar ve korunan iç geçitlerden oluşan, gece çökünce tuhaf ilahilerin duyulduğu bir kaleye çıkıyor.",
    ["Old Toolbox"] = "Eski Alet Kutusu",
    ["On Electrocutioner 6000's platform."] = "Electrocutioner 6000'in platformunda.",
    ["On a box at the abandoned camp"] = "Terk edilmiş kamptaki bir kutunun üzerinde",
    ["On the carved heads of the dam, facing the Wetlands"] = "Barajın Wetlands'e bakan oyma kafalarının üzerinde",
    ["On the ground at Agmond's End, southern Badlands"] = "Güney Badlands'te Agmond's End'de yerde",
    ["On the ground in the Witherbark troll camps, The Hinterlands"] = "Witherbark trol kamplarında yerde, The Hinterlands",
    ["On the wall in Kargath, Badlands"] = "Kargath'ta duvarda, Badlands",
    ["Open his cell with the Prison Cell Key from High Interrogator Gerstahn, then defend him."] = "High Interrogator Gerstahn'dan alınan Hapishane Hücresi Anahtarı ile hücresini aç, sonra onu savun.",
    ["Optional Alliance breadcrumb leading to Researching the Corruption."] = "Researching the Corruption görevine götüren isteğe bağlı Alliance yönlendirme görevi.",
    ["Optional introductory quest:"] = "İsteğe bağlı giriş görevi:",
    ["Orc, Tauren and Troll only; Undead cannot take this quest."] = "Yalnızca Orc, Tauren ve Troll; Undead'ler bu görevi alamaz.",
    ["Out of Sun Rock Retreat: its east exit, to the road"] = "Sun Rock Retreat'ten çık: doğu çıkışından yola",
    ["Outside Dalaran near Lordamere Lake"] = "Lordamere Lake yakınında, Dalaran'ın dışında",
    ["Paladin charger quest. Clear Rattlegore's basement in the Great Ossuary, use the Divination Scryer and defeat the spirits and Death Knight Darkreaver."] = "Paladin savaş atı görevi. Great Ossuary'de Rattlegore'un bodrumunu temizle, Divination Scryer'ı kullan ve ruhları ve Death Knight Darkreaver'ı yen.",
    ["Paladin charger quest. Kill Tendris Warpwood, then feed the Ancient Equine Spirit and give it the Arcanite Barding. Bring the Manna-Enriched Horse Feed from Merideth Carlson in Southshore."] = "Paladin savaş atı görevi. Tendris Warpwood'u öldür, sonra Ancient Equine Spirit'i besle ve ona Arcanite Barding'i ver. Manna ile Zenginleştirilmiş At Yemi'ni Southshore'daki Merideth Carlson'dan getir.",
    ["Paladin class book. Click the book to start the quest."] = "Paladin sınıf kitabı. Görevi başlatmak için kitaba tıkla.",
    ["Paladin class quest for humans and dwarves. In this dungeon: Whitestone Oak Lumber drops from Goblin Woodcarvers. The other parts are Jordan's Smithing Hammer (Shadowfang Keep), the Kor Gem (Blackfathom Deeps) and Jordan's ore shipment (Loch Modan)."] = "İnsanlar ve cüceler için Paladin sınıf görevi. Bu zindanda: Whitestone Meşe Kerestesi Goblin Woodcarver'lardan düşer. Diğer parçalar Jordan's Smithing Hammer (Shadowfang Keep), Kor Gem (Blackfathom Deeps) ve Jordan'ın cevher sevkiyatı (Loch Modan).",
    ["Paladin class quest for undead and tauren. In this dungeon: Whitestone Oak Lumber drops from Goblin Woodcarvers. The other parts are the Enchanted Silver Ingot (Shadowfang Keep) and the Purified Kor Gem (Blackfathom Deeps)."] = "Undead'ler ve taurenler için Paladin sınıf görevi. Bu zindanda: Whitestone Meşe Kerestesi Goblin Woodcarver'lardan düşer. Diğer parçalar Enchanted Silver Ingot (Shadowfang Keep) ve Purified Kor Gem (Blackfathom Deeps).",
    ["Paladin class quest. Needs 2 amber, 2 blue and 2 green Voodoo Feathers from the six troll guardians: Gasher, Mijan, Zolo, Hukku, Zul'Lor and Loro.\n\nOptional introductory quest:"] = "Paladin sınıf görevi. Altı trol muhafızından 2 kehribar, 2 mavi ve 2 yeşil Vudu Tüyü gerekir: Gasher, Mijan, Zolo, Hukku, Zul'Lor ve Loro.\n\nİsteğe bağlı giriş görevi:",
    ["Parqual Fintallas in Undercity"] = "Parqual Fintallas, Undercity'de",
    ["Part of the Horde Onyxia chain. Black Dragonspawn Eyes drop from the dragonspawn in UBRS."] = "Horde Onyxia zincirinin parçası. Kara Ejderha Yavrusu Gözleri UBRS'deki dragonspawn'lardan düşer.",
    ["Part of the Onyxia attunement."] = "Onyxia uyumlanmasının parçası.",
    ["Part of the chain that begins with The Unsent Letter from Edwin VanCleef in The Deadmines."] = "The Deadmines'ta Edwin VanCleef'ten gelen The Unsent Letter ile başlayan zincirin parçası.",
    ["Perfumed Note, after Blazeroar, inside Alcaz Prison"] = "Parfümlü Not, Blazeroar'dan sonra, Alcaz Prison içinde",
    ["Pick pocket a Scarlet Scryer in the first big room of the Scarlet Monastery Graveyard"] = "Scarlet Monastery Graveyard'ın ilk büyük odasındaki bir Scarlet Scryer'ın cebini çal",
    ["Pick up Key to the City from Magus Wordeen Voidglare at the same time."] = "Aynı anda Magus Wordeen Voidglare'den Key to the City görevini de al.",
    ["Plant the explosives at the forge, then return to Alba Fairmoon."] = "Patlayıcıları demirhaneye yerleştir, sonra Alba Fairmoon'a dön.",
    ["Plant the explosives beside the forge, then meet Alba Fairmoon at the Deadmines exit."] = "Patlayıcıları demirhanenin yanına yerleştir, sonra Deadmines çıkışında Alba Fairmoon ile buluş.",
    ["Pocket Litter on a box at the abandoned camp, Stonetalon Mountains (40.8, 52.6)"] = "Terk edilmiş kamptaki bir kutunun üzerinde cep döküntüleri, Stonetalon Mountains (40.8, 52.6)",
    ["Priest class book. Click the book to start the quest."] = "Priest sınıf kitabı. Görevi başlatmak için kitaba tıkla.",
    ["Priest class quest. Morphaz's blood is turned in to Greta Mosshoof, not Ogtinc.\n\nOptional introductory quest:"] = "Priest sınıf görevi. Morphaz'ın kanı Ogtinc'e değil, Greta Mosshoof'a teslim edilir.\n\nİsteğe bağlı giriş görevi:",
    ["Priest trainers"] = "Priest eğitmenleri",
    ["Prismatic Punch Card (Punchograph 3005-D)"] = "Prizmatik Delikli Kart (Punchograph 3005-D)",
    ["Provided for Blood in the Streets"] = "Blood in the Streets için verilir",
    ["Quest data is recorded in the beta; dungeon access may be unavailable."] = "Görev verisi betada kaydedildi; zindana erişim mümkün olmayabilir.",
    ["Quest giver not confirmed yet. Lead-in: An Acquaintance in Southshore, taking the Savage Coast Report Bundle to Loremaster Dibbs."] = "Görev veren henüz doğrulanmadı. Giriş görevi: An Acquaintance in Southshore, Savage Coast Rapor Destesi'ni Loremaster Dibbs'e götürmek.",
    ["Quest giver not confirmed yet: it is handed in to Archmage Lan'dalock."] = "Görev veren henüz doğrulanmadı: Archmage Lan'dalock'a teslim edilir.",
    ["Quest giver not known yet. Amnennar the Coldbringer, the last boss, has the orb."] = "Görev veren henüz bilinmiyor. Küre, son boss olan Amnennar the Coldbringer'da.",
    ["Quest giver not known yet. Seen by a Horde player; whether the Alliance gets it too is not known yet."] = "Görev veren henüz bilinmiyor. Bir Horde oyuncusu tarafından görüldü; Alliance'ın da alıp almadığı henüz bilinmiyor.",
    ["Ranath Nightstride, in the inn in Dalaran, Alterac Mountains"] = "Ranath Nightstride, Dalaran'daki hanın içinde, Alterac Mountains",
    ["Random drop from Blackrock Spire trash"] = "Blackrock Spire'daki sıradan yaratıklardan rastgele düşer",
    ["Random drop from mobs outside the Gnomeregan instance"] = "Gnomeregan zindanı dışındaki yaratıklardan rastgele düşer",
    ["Random drop; you usually get it during your first clear of the outer area."] = "Rastgele düşer; genellikle dış bölgeyi ilk temizleyişinde alırsın.",
    ["Ranged, Gun"] = "Menzilli, Tüfek",
    ["Rare drop from Vile Fin murlocs around Lordamere Lake; the higher-level ones on the Dawning Isles and on the south-west shore behind Ambermill are the best bet"] = "Lordamere Lake çevresindeki Vile Fin murloclarından nadiren düşer; en iyi şans Dawning Isles'taki ve Ambermill'in arkasındaki güneybatı kıyısındaki yüksek seviyeli olanlarda",
    ["Rare spawn."] = "Nadir yaratık.",
    ["Recover The Coldbringer's Eye from Razorfen Downs."] = "Coldbringer'ın Gözü'nü Razorfen Downs'tan geri al.",
    ["Recover The Founding of Dalaran and deliver it to Rexxie Copperclutch."] = "The Founding of Dalaran'ı geri al ve Rexxie Copperclutch'a teslim et.",
    ["Recover an Ancient Gurubashi Idol from the Drowned City."] = "Drowned City'den bir Kadim Gurubashi İdolü geri al.",
    ["Recover the Tome of Twilight from Krol'dok Stronghold."] = "Alacakaranlık Cildi'ni Krol'dok Stronghold'dan geri al.",
    ["Red Punch Card (Punchograph 3005-C)"] = "Kırmızı Delikli Kart (Punchograph 3005-C)",
    ["Related lead-in: Dragonmaw Rumors. The Dragonmaw Dispatch is recovered from the Dragonmaw forces inside the dungeon."] = "İlgili giriş görevi: Dragonmaw Rumors. Dragonmaw Gönderisi, zindanın içindeki Dragonmaw kuvvetlerinden alınır.",
    ["Repeatable. Needs your faction's Elven Legends turned in first."] = "Tekrarlanabilir. Önce fraksiyonunun Elven Legends görevinin teslim edilmiş olması gerekir.",
    ["Report Daewyn's fate to Dorin Songblade in Lakeshire."] = "Daewyn'in akıbetini Lakeshire'daki Dorin Songblade'e bildir.",
    ["Report to the Image of Archmage Modera near the City of Dalaran."] = "City of Dalaran yakınındaki Image of Archmage Modera'ya rapor ver.",
    ["Reported random spawn inside Ruins of Lordaeron; check towers, side rooms and the Bjork area"] = "Ruins of Lordaeron içinde rastgele çıktığı bildiriliyor; kulelere, yan odalara ve Bjork bölgesine bak",
    ["Required before Gnomer-gooooone!"] = "Gnomer-gooooone! öncesi gerekli.",
    ["Required before Hearts of Zeal."] = "Hearts of Zeal öncesi gerekli.",
    ["Required before Heartwoven."] = "Heartwoven öncesi gerekli.",
    ["Required before Highland Hides. Daily Delivery is not required in Forever."] = "Highland Hides öncesi gerekli. Forever'da Daily Delivery gerekli değil.",
    ["Required before Open the Maw."] = "Open the Maw öncesi gerekli.",
    ["Required before Red Silk Bandanas."] = "Red Silk Bandanas öncesi gerekli.",
    ["Required before Smart Drinks becomes available."] = "Smart Drinks açılmadan önce gerekli.",
    ["Required before The Crone of the Kraul."] = "The Crone of the Kraul öncesi gerekli.",
    ["Required before The Only Cure is More Green Glow."] = "The Only Cure is More Green Glow öncesi gerekli.",
    ["Required before the Alliance version of Blackfathom Villainy."] = "Blackfathom Villainy'nin Alliance sürümü öncesi gerekli.",
    ["Requires Magus Wordeen Voidglare's Dalaran quests. Stone Tokens and Bracers of Binding from Keeper Bel'varil are optional and are not required for attunement."] = "Magus Wordeen Voidglare'in Dalaran görevleri gerekir. Keeper Bel'varil'in Stone Tokens ve Bracers of Binding görevleri isteğe bağlıdır, uyumlanma için gerekli değildir.",
    ["Requires The Dark Iron War before this quest becomes available."] = "Bu görevin açılması için önce The Dark Iron War gerekir.",
    ["Requires the Barrens oasis quest chain. Complete The Barrens Oases, The Forgotten Pools, The Stagnant Oasis and Altered Beings, then Hamuul Runetotem and Nara Wildmane before Leaders of the Fang becomes available."] = "Barrens vaha görev zinciri gerekir. Leaders of the Fang açılmadan önce The Barrens Oases, The Forgotten Pools, The Stagnant Oasis ve Altered Beings'i, ardından Hamuul Runetotem ve Nara Wildmane'i tamamla.",
    ["Requires the Defias Brotherhood escort step."] = "Defias Brotherhood eskort adımı gerekir.",
    ["Requires the earlier Hidden Enemies chain steps in Orgrimmar. The next Hidden Enemies step later offers:"] = "Orgrimmar'daki önceki Hidden Enemies zincir adımları gerekir. Sonraki Hidden Enemies adımı daha sonra şunları sunar:",
    ["Retrieve a Fel Infused Blossom from Dalaran's central garden."] = "Dalaran'ın merkez bahçesinden bir Fel ile Dolu Çiçek al.",
    ["Retrieve the Medallion of Faith from Malor the Zealous in the Scarlet Bastion and bring it back to Aurius."] = "İnanç Madalyonu'nu Scarlet Bastion'daki Malor the Zealous'tan al ve Aurius'a geri getir.",
    ["Return to Caitlin Grassman in Menethil Harbor."] = "Menethil Harbor'daki Caitlin Grassman'a dön.",
    ["Returns Shaw's findings about Edwin VanCleef to Gryan."] = "Shaw'ın Edwin VanCleef hakkındaki bulgularını Gryan'a geri götürür.",
    ["Returns the remote detonator to the engineer."] = "Uzaktan fünyeyi mühendise geri götürür.",
    ["Reward from the quest Bailor's Ore Shipment: Bailor Stonehand, Thelsamar, Loch Modan"] = "Bailor's Ore Shipment görevinin ödülü: Bailor Stonehand, Thelsamar, Loch Modan",
    ["Reward from the quest Seeking the Kor Gem: Thundris Windweaver, Auberdine, Darkshore. The Corrupted Kor Gem he asks for drops from Blackfathom Tide Priestesses and Oracles at the Blackfathom Deeps entrance and from Blackfathom Sea Witches inside."] = "Seeking the Kor Gem görevinin ödülü: Thundris Windweaver, Auberdine, Darkshore. İstediği Bozulmuş Kor Taşı, Blackfathom Deeps girişindeki Blackfathom Tide Priestess ve Oracle'lardan ve içerideki Blackfathom Sea Witch'lerden düşer.",
    ["Reward from the quest Seeking the Kor Gem: Ulric Frostveil, Zoram'gar Outpost, Ashenvale. The Corrupted Kor Gem he asks for drops from Blackfathom Tide Priestesses and Oracles at the Blackfathom Deeps entrance and from Blackfathom Sea Witches inside, once you have his quest."] = "Seeking the Kor Gem görevinin ödülü: Ulric Frostveil, Zoram'gar Outpost, Ashenvale. İstediği Bozulmuş Kor Taşı, görevini aldıktan sonra Blackfathom Deeps girişindeki Blackfathom Tide Priestess ve Oracle'lardan ve içerideki Blackfathom Sea Witch'lerden düşer.",
    ["Rexxie Copperclutch, inside the dungeon, near the sewer entrance"] = "Rexxie Copperclutch, zindanın içinde, lağım girişinin yakınında",
    ["Rig Wars must be in progress to unlock the transporter chain in Forever."] = "Forever'da ışınlayıcı zincirini açmak için Rig Wars'un devam ediyor olması gerekir.",
    ["Right under the Messenger Bag"] = "Ulak Çantası'nın hemen altında",
    ["Riverglades (giver not known yet)"] = "Riverglades (görev veren henüz bilinmiyor)",
    ["Riverglades (not known yet)"] = "Riverglades (henüz bilinmiyor)",
    ["Rogue class book. Click the book to start the quest."] = "Rogue sınıf kitabı. Görevi başlatmak için kitaba tıkla.",
    ["Rogue class quest after The Horn of Xelthos; C's next letter (around level 30) sends you back to the Dead Drop. Wear the Scarlet Initiate's Uniform in every wing: stealth or attacking removes it."] = "The Horn of Xelthos'tan sonraki Rogue sınıf görevi; C'nin bir sonraki mektubu (yaklaşık 30. seviyede) seni Dead Drop'a geri gönderir. Her kanatta Scarlet Initiate's Uniform giy: gizlenmek ya da saldırmak onu çıkarır.",
    ["Rogue class quest. C's letter arrives at level 20 in a capital city; take the job at the Dead Drop near Pyrewood Village. Keep a bag slot free."] = "Rogue sınıf görevi. C'nin mektubu 20. seviyede bir başkentte gelir; işi Pyrewood Village yakınındaki Dead Drop'tan al. Bir çanta yuvasını boş tut.",
    ["Rogue class quest. The Azure Key drops from Morphaz.\n\nOptional introductory quest:"] = "Rogue sınıf görevi. Gök Mavisi Anahtar Morphaz'dan düşer.\n\nİsteğe bağlı giriş görevi:",
    ["Rogue trainers"] = "Rogue eğitmenleri",
    ["Rough Dynamite can be crafted, traded or bought from the auction house."] = "Kaba Dinamit üretilebilir, takas edilebilir ya da müzayede evinden alınabilir.",
    ["Rubbing of the tablet Fall of Gurubashi, in the troll ruins on the coast north of the Vile Reef (around 23, 12)"] = "Fall of Gurubashi tabletinin kopyası, Vile Reef'in kuzeyindeki kıyıda trol harabelerinde (yaklaşık 23, 12)",
    ["Scarlet Monastery trash (Chain of the Scarlet Crusade)"] = "Scarlet Monastery'deki sıradan yaratıklar (Chain of the Scarlet Crusade)",
    ["Scarlet Monastery trash (very rare)"] = "Scarlet Monastery'deki sıradan yaratıklar (çok nadir)",
    ["Scourge forces still haunt the ruined capital while a necromancer gathers power within the city."] = "Bir nekromans şehrin içinde güç toplarken Scourge kuvvetleri hâlâ yıkık başkentin peşini bırakmıyor.",
    ["Scout Riell, Sentinel Hill tower, Westfall"] = "Scout Riell, Sentinel Hill kulesi, Westfall",
    ["Search the Hastily Rolled-Up Satchel under the Messenger Bag at Thoradin's Wall."] = "Thoradin's Wall'daki Haberci Çantası'nın altındaki Aceleyle Sarılmış Heybe'yi ara.",
    ["Second quest of the Toxic Soil chain."] = "Toxic Soil zincirinin ikinci görevi.",
    ["Second required step before Horrors in the Highland."] = "Horrors in the Highland öncesi gerekli ikinci adım.",
    ["Second required step leading to The Stockade Riots."] = "The Stockade Riots görevine götüren ikinci gerekli adım.",
    ["Second step of the Defias Brotherhood chain."] = "Defias Brotherhood zincirinin ikinci adımı.",
    ["Sentinel Hill inn"] = "Sentinel Hill hanı",
    ["Sentinel Hill tower"] = "Sentinel Hill kulesi",
    ["Sergeant Ulka, outside Alcaz Prison on Alcaz Island"] = "Sergeant Ulka, Alcaz Island'da Alcaz Prison'ın dışında",
    ["Sergeant Ulka, outside Alcaz Prison, Dustwallow Marsh (70.4, 19.0)"] = "Sergeant Ulka, Alcaz Prison'ın dışında, Dustwallow Marsh (70.4, 19.0)",
    ["Sergeant Yohwa at the Rebel Camp, northern Stranglethorn Vale"] = "Sergeant Yohwa, Rebel Camp, kuzey Stranglethorn Vale",
    ["Serpentbloom starts from Apothecary Zamah in the Pools of Vision beneath Spirit Rise"] = "Serpentbloom, Spirit Rise'ın altındaki Pools of Vision'da Apothecary Zamah'tan başlar",
    ["Shadowshard elementals in the outer purple-crystal caves. It can be done without entering the instance."] = "Dıştaki mor kristalli mağaralardaki Shadowshard elementalleri. Zindana girmeden yapılabilir.",
    ["Shady Saltseers"] = "Şüpheli Saltseer'lar",
    ["Shaman class book. Click the book to start the quest."] = "Shaman sınıf kitabı. Görevi başlatmak için kitaba tıkla.",
    ["Shaman class quest. Needs 2 amber, 2 blue and 2 green Voodoo Feathers from the six troll guardians: Gasher, Mijan, Zolo, Hukku, Zul'Lor and Loro."] = "Shaman sınıf görevi. Altı trol muhafızından 2 kehribar, 2 mavi ve 2 yeşil Vudu Tüyü gerekir: Gasher, Mijan, Zolo, Hukku, Zul'Lor ve Loro.",
    ["Shaman quest. Clear Rattlegore's basement, use the scryer and defeat Death Knight Darkreaver; return his head."] = "Shaman görevi. Rattlegore'un bodrumunu temizle, kâhin aletini kullan ve Death Knight Darkreaver'ı yen; kafasını geri getir.",
    ["Shattered Necklace (drops in Uldaman)"] = "Parçalanmış Kolye (Uldaman'da düşer)",
    ["Shaw investigates the connection between the Defias and the Stonemasons."] = "Shaw, Defias ile Taş Ustaları arasındaki bağlantıyı araştırıyor.",
    ["Shoulder, Mail"] = "Omuz, Zincir",
    ["Show Cyrus a Black Dragonflight Molt first (A Taste of Flame, or kill the drake he summons). Then kill Bael'Gar and use the Altered Black Dragonflight Molt on his remains to collect the Encased Fiery Essence."] = "Önce Cyrus'a bir Kara Ejderha Uçuşu Deri Döküntüsü göster (A Taste of Flame ya da çağırdığı drake'i öldür). Sonra Bael'Gar'ı öldür ve Kaplı Ateşli Öz'ü toplamak için Değiştirilmiş Kara Ejderha Uçuşu Deri Döküntüsü'nü kalıntıları üzerinde kullan.",
    ["Slay 15 Strashaz Soldiers and 8 Strashaz Enchantresses in Alcaz Prison, and bring Ca'zass's Head."] = "Alcaz Prison'da 15 Strashaz Soldier ve 8 Strashaz Enchantress öldür ve Ca'zass'ın Kafası'nı getir.",
    ["Slay Arcanic Enigma, the Mana Elemental in the City of Dalaran, and return to High Sorcerer Andromath in Stormwind City."] = "City of Dalaran'daki Mana Elementali Arcanic Enigma'yı öldür ve Stormwind City'deki High Sorcerer Andromath'a dön.",
    ["Slay Captain Dreadrise and 3 Saltseer Coroners in the Drowned City."] = "Drowned City'de Captain Dreadrise'ı ve 3 Saltseer Coroner'ı öldür.",
    ["Slay Witch Doctor Zum'rah and bring Zum'rah's Head to Archmage Lan'dalock in Dalaran."] = "Witch Doctor Zum'rah'ı öldür ve Zum'rah'ın Kafası'nı Dalaran'daki Archmage Lan'dalock'a getir.",
    ["Small Scroll, dropped by Charlga Razorflank"] = "Küçük Parşömen, Charlga Razorflank düşürür",
    ["Solo job: you must do it alone, outside any group."] = "Tek kişilik iş: herhangi bir grubun dışında, tek başına yapmalısın.",
    ["Someone has broken into the royal dwarven burial chamber beneath Ironforge."] = "Biri Ironforge'un altındaki kraliyet cüce mezar odasına girmiş.",
    ["Someone on the Elder Rise, Thunder Bluff"] = "Thunder Bluff'taki Elder Rise'da biri",
    ["Speak to Franclorn's ghost while dead. Kill Fineous Darkvire for Ironfel and place it on Franclorn's monument by the Ring of Law. The Shadowforge Key opens shortcuts inside BRD."] = "Ölüyken Franclorn'un hayaletiyle konuş. Ironfel için Fineous Darkvire'ı öldür ve onu Ring of Law yanındaki Franclorn anıtına yerleştir. Shadowforge Anahtarı BRD içindeki kısayolları açar.",
    ["Speak to Jordan Stilwell in Ironforge."] = "Ironforge'daki Jordan Stilwell ile konuş.",
    ["Speak with Lumina Windsinger in the Sepulcher."] = "Sepulcher'daki Lumina Windsinger ile konuş.",
    ["Speak with Ott and ask him to forge your blade."] = "Ott ile konuş ve kılıcını dövmesini iste.",
    ["Speak with Sputtervalve in Ratchet about the Glowing Shard, then deliver it to Falla Sagewind on top of the mountain above Wailing Caverns."] = "Ratchet'teki Sputtervalve ile Parlayan Kıymık hakkında konuş, sonra onu Wailing Caverns'ın üstündeki dağın tepesindeki Falla Sagewind'e teslim et.",
    ["Speak with Trevan Rol in the Sepulcher and bring him the materials he requires."] = "Sepulcher'daki Trevan Rol ile konuş ve istediği malzemeleri ona getir.",
    ["Speak with the Stone Watcher and activate the discs first. Then hand the reward voucher to Bena Winterhoof in Thunder Bluff and choose your reward."] = "Önce Stone Watcher ile konuş ve diskleri etkinleştir. Sonra ödül senedini Thunder Bluff'taki Bena Winterhoof'a ver ve ödülünü seç.",
    ["Speak with the Stone Watcher and activate the discs first. Then hand the reward voucher to Dinita Stonemantle in the Ironforge vault and choose your reward."] = "Önce Stone Watcher ile konuş ve diskleri etkinleştir. Sonra ödül senedini Ironforge kasasındaki Dinita Stonemantle'a ver ve ödülünü seç.",
    ["Spire Spider Eggs are in the spider tunnels."] = "Spire Örümcek Yumurtaları örümcek tünellerinde.",
    ["Sprite Jumpsprocket: Dwarven District, Stormwind"] = "Sprite Jumpsprocket: Dwarven District, Stormwind",
    ["Sputtervalve, by the flight master in Ratchet (63.0, 37.2); he has no ? over his head"] = "Sputtervalve, Ratchet'taki uçuş ustasının yanında (63.0, 37.2); başının üstünde ? yok",
    ["Staging Area"] = "Hazırlık Alanı",
    ["Start Chief Engineer Scooty here"] = "Chief Engineer Scooty'yi burada başlat",
    ["Start Dragonmaw Rumors here"] = "Dragonmaw Rumors'u burada başlat",
    ["Start Gnogaine here"] = "Gnogaine'i burada başlat",
    ["Start Going, Going, Guano! here"] = "Going, Going, Guano!'yu burada başlat",
    ["Start Hidden Enemies here"] = "Hidden Enemies'i burada başlat",
    ["Start In Search of Thaelrid here"] = "In Search of Thaelrid'i burada başlat",
    ["Start Lost in the Thicket Things here"] = "Lost in the Thicket Things'i burada başlat",
    ["Start Raptor Horns here"] = "Raptor Horns'u burada başlat",
    ["Start Red Leather Bandanas here"] = "Red Leather Bandanas'ı burada başlat",
    ["Start Speak with Shoni here"] = "Speak with Shoni'yi burada başlat",
    ["Start Testing the Wells here"] = "Testing the Wells'i burada başlat",
    ["Start The Dark Iron War here"] = "The Dark Iron War'u burada başlat",
    ["Start The Defias Brotherhood here"] = "The Defias Brotherhood'u burada başlat",
    ["Start The Forgotten Pools here"] = "The Forgotten Pools'u burada başlat",
    ["Start The Greenwarden here"] = "The Greenwarden'ı burada başlat",
    ["Start Young Crocolisk Skins here"] = "Young Crocolisk Skins'i burada başlat",
    ["Starts a follow-up chain that continues with Bazil Thredd."] = "Bazil Thredd ile devam eden bir zincir başlatır.",
    ["Stone tablet inside a vault in the Reliquary of Kings"] = "Reliquary of Kings'teki bir kasanın içindeki taş tablet",
    ["Stone tablet inside a vault in the Reliquary of Kings (Durgen Dirgehammer's room)"] = "Reliquary of Kings'teki bir kasanın içindeki taş tablet (Durgen Dirgehammer'ın odası)",
    ["Strange Water Globe, dropped by Baron Aquanis inside Blackfathom Deeps"] = "Garip Su Küresi, Blackfathom Deeps içinde Baron Aquanis düşürür",
    ["Summon a Twilight's Thrall from a conduit within the Twilight's Shroud and capture it with Amberhall's Soulstone."] = "Twilight's Shroud içindeki bir kanaldan bir Twilight's Thrall çağır ve onu Amberhall'un Ruh Taşı ile yakala.",
    ["Supplied by Sprite Jumpsprocket during Explosive Consultation; plant it at the Deadmines forge"] = "Explosive Consultation sırasında Sprite Jumpsprocket verir; onu Deadmines demirhanesine yerleştir",
    ["Take Dibbs' I'lalai Translations to Historian Karnik in Ironforge."] = "Dibbs'in I'lalai Çevirileri'ni Ironforge'daki Historian Karnik'e götür.",
    ["Take Two With Water"] = "Suyla İki Tane Al",
    ["Take a hundred paces due north of the camp and find the Mound of Dirt below the cliff."] = "Kampın tam kuzeyine yüz adım at ve uçurumun altındaki Toprak Yığını'nı bul.",
    ["Take the I'lalai Fetish to Abra Cadabra in Dalaran."] = "I'lalai Fetişi'ni Dalaran'daki Abra Cadabra'ya götür.",
    ["Take the Reed-woven Heart back to Caitlin Grassman in Menethil Harbor."] = "Sazdan Örülmüş Kalp'i Menethil Harbor'daki Caitlin Grassman'a geri götür.",
    ["Take the Savage Coast Report Bundle (the fetishes, the troll legends and the scouting report) to Loremaster Dibbs in Southshore."] = "Savage Coast Rapor Destesi'ni (fetişler, trol efsaneleri ve keşif raporu) Southshore'daki Loremaster Dibbs'e götür.",
    ["Take the Small Scroll to Varimathras in the Undercity."] = "Küçük Parşömen'i Undercity'deki Varimathras'a götür.",
    ["Take the Titan Relic to the Elder Rise in Thunder Bluff and look for someone who can tell you more about it."] = "Titan Kalıntısı'nı Thunder Bluff'taki Elder Rise'a götür ve sana onun hakkında daha fazlasını anlatabilecek birini ara.",
    ["Take the Unforged Seal and the Orb of Draconic Energy to Emberstrife in the Wyrmbog, Dustwallow Marsh. The forged seal opens the UBRS door."] = "Dövülmemiş Mühür'ü ve Ejderha Enerjisi Küresi'ni Dustwallow Marsh'taki Wyrmbog'da Emberstrife'a götür. Dövülmüş mühür UBRS kapısını açar.",
    ["Take the elevator down; the terminal is in the first passage on the right."] = "Asansörle aşağı in; terminal sağdaki ilk geçitte.",
    ["Take the painting hidden behind the twin-moons picture in Archivist Galford's room before you burn the archives."] = "Arşivleri yakmadan önce Archivist Galford'un odasındaki ikiz aylar resminin arkasına gizlenmiş tabloyu al.",
    ["Take the path north-east of Sun Rock Retreat (50.9, 52.3) up to the abandoned camp; the Pocket Litter lies on a box. Optional: light the Firepit in the middle of the camp with the Simple Wood and Flint and Tinder from this quest (Rekindle)."] = "Sun Rock Retreat'in (50.9, 52.3) kuzeydoğusundaki yoldan terk edilmiş kampa çık; cep döküntüleri bir kutunun üzerinde. İsteğe bağlı: bu görevden gelen Basit Odun ve Çakmaktaşı ile kampın ortasındaki ateş çukurunu yak (Rekindle).",
    ["Talk to Goretooth to receive his Command item and click it to start the quest. The Important Blackrock Documents spawn near the three generals."] = "Command eşyasını almak için Goretooth ile konuş ve görevi başlatmak için ona tıkla. Önemli Blackrock Belgeleri üç generalin yakınında çıkar.",
    ["Talvash del Kissel (Phial of Scrying)"] = "Talvash del Kissel (Kehanet Şişesi)",
    ["Tell Commander Folkar what you found."] = "Commander Folkar'a bulduklarını anlat.",
    ["The Arcanist's Cookbook (book, Dire Maul drop)"] = "The Arcanist's Cookbook (kitap, Dire Maul ganimeti)",
    ["The Barov family crypt on Caer Darrow, turned into the Cult of the Damned's school of necromancy. Darkmaster Gandling rules the halls; the Skeleton Key from the Barov quests opens the doors."] = "Caer Darrow'daki Barov ailesi mahzeni, Cult of the Damned'in nekromansi okuluna dönüşmüş. Salonları Darkmaster Gandling yönetir; Barov görevlerinden gelen İskelet Anahtarı kapıları açar.",
    ["The Capital Gardens and the Court of the Highborne, where the last Shen'dralar keep the demon Immol'thar imprisoned behind five pylons. Needs the Crescent Key from Pusillin."] = "Son Shen'dralar'ın şeytan Immol'thar'ı beş pilonun arkasında hapsettiği Capital Gardens ve Court of the Highborne. Pusillin'den Hilal Anahtarı gerekir.",
    ["The Celebrian Rod drops from Noxxion and the Celebrian Diamond from Lord Vyletongue."] = "Celebrian Asası Noxxion'dan, Celebrian Elması ise Lord Vyletongue'dan düşer.",
    ["The Coldbringer's Eye"] = "Coldbringer'ın Gözü",
    ["The Core Fragment is on the rock beside the Molten Core portal deep inside BRD. Unlocks Lothos's teleport to Molten Core."] = "Çekirdek Parçası, BRD'nin derinlerinde Molten Core portalının yanındaki kayanın üzerinde. Lothos'un Molten Core'a ışınlamasını açar.",
    ["The Dark Iron Map starts this quest and leads directly into Old Ironforge Incursion."] = "Dark Iron Haritası bu görevi başlatır ve doğrudan Old Ironforge Incursion görevine götürür.",
    ["The Darkstone Tablet lies on the ground in the Rookery.\n\nOptional introductory quest:"] = "Darkstone Tableti Rookery'de yerde duruyor.\n\nİsteğe bağlı giriş görevi:",
    ["The Deadmines part is step 10 of the chain: plant the Extra-Destructive Explosives beside the forge inside the Deadmines, then meet Alba Fairmoon at the Deadmines exit."] = "Deadmines kısmı zincirin 10. adımı: Extra-Destructive Explosives'i Deadmines içindeki demirhanenin yanına yerleştir, sonra Deadmines çıkışında Alba Fairmoon ile buluş.",
    ["The Deathstalker Agent waits at the new dig camp right outside the portal. He takes the Dragonmaw Dispatch off your hands; where the Dispatch drops has not been confirmed yet."] = "Deathstalker Agent, portalın hemen dışındaki yeni kazı kampında bekliyor. Dragonmaw Gönderisi'ni senden alır; Gönderi'nin nereden düştüğü henüz doğrulanmadı.",
    ["The Defias Brotherhood is building a warship in the mines beneath Moonbrook."] = "Defias Brotherhood, Moonbrook'un altındaki madenlerde bir savaş gemisi inşa ediyor.",
    ["The Defias Messenger patrols the roads between Moonbrook, Gold Coast Quarry and Jangolode Mine."] = "Defias Messenger, Moonbrook, Gold Coast Quarry ve Jangolode Mine arasındaki yollarda devriye gezer.",
    ["The Emerald Dream (book, Dire Maul drop)"] = "The Emerald Dream (kitap, Dire Maul ganimeti)",
    ["The Fathom Stone is also associated with the optional Baron Aquanis encounter."] = "Fathom Taşı, isteğe bağlı Baron Aquanis karşılaşmasıyla da ilişkilidir.",
    ["The Greatest Race of Hunters (book, Dire Maul drop)"] = "The Greatest Race of Hunters (kitap, Dire Maul ganimeti)",
    ["The Heart of the Mountain is in the vault safe after the Dark Keepers."] = "Dağın Kalbi, Dark Keeper'lardan sonra kasadaki kasada.",
    ["The Kirin Tor only let noteworthy visitors into Dalaran."] = "Kirin Tor, Dalaran'a yalnızca kayda değer ziyaretçileri alıyor.",
    ["The Light and How To Swing It (book, Dire Maul drop)"] = "The Light and How To Swing It (kitap, Dire Maul ganimeti)",
    ["The Lorgalis Manuscript is inside a Pitted Iron Chest underwater in the Pool of Ask'ar, in the northern alcove just past Ghamoo-ra's turtle room."] = "Lorgalis Elyazması, Ghamoo-ra'nın kaplumbağa odasını hemen geçince kuzey girintide, Pool of Ask'ar'da su altındaki bir Oyuk Demir Sandık'ın içinde.",
    ["The Saltseer Captain"] = "Saltseer Kaptanı",
    ["The Scarshield Quartermaster is in the hallway outside the Spire portal. Touch Drakkisath's Brand behind General Drakkisath; this unlocks the Orb of Command shortcut to Blackwing Lair."] = "Scarshield Quartermaster, Spire portalının dışındaki koridorda. General Drakkisath'ın arkasındaki Drakkisath's Brand'e dokun; bu, Blackwing Lair'e giden Orb of Command kısayolunu açar.",
    ["The Sparklematic 5200, inside Gnomeregan"] = "The Sparklematic 5200, Gnomeregan içinde",
    ["The Tablet of Theka is in Theka the Martyr's room."] = "Theka Tableti, Theka the Martyr'ın odasında.",
    ["The Temple of Atal'Hakkar, sunk beneath the Pool of Tears in the Swamp of Sorrows. The Atal'ai trolls try to summon their blood god Hakkar here, while the green dragons of Eranikus guard the lower halls."] = "Swamp of Sorrows'taki Pool of Tears'ın altına batmış Temple of Atal'Hakkar. Atal'ai trolleri burada kan tanrıları Hakkar'ı çağırmaya çalışırken Eranikus'un yeşil ejderhaları alt salonları korur.",
    ["The Tiara drops from Hydromancer Velratha.\n\nOptional introductory quest:"] = "Taç, Hydromancer Velratha'dan düşer.\n\nİsteğe bağlı giriş görevi:",
    ["The Witch Doctor's Head"] = "Cadı Doktorun Kafası",
    ["The ancient burial grounds of the quilboar, now held by the Scourge. Amnennar the Coldbringer leads the undead from the top of the Downs."] = "Domuzadamların kadim mezarlığı, artık Scourge'un elinde. Amnennar the Coldbringer, Downs'ın tepesinden undead'leri yönetiyor.",
    ["The armory wing of the Scarlet Monastery, where the Crusade drills its recruits under the eye of Herod, the Scarlet Champion. The door is locked: you need The Scarlet Key from the Library."] = "Haçlı Seferi'nin acemilerini Scarlet Champion Herod'un gözetiminde eğittiği Scarlet Monastery'nin cephanelik kanadı. Kapı kilitli: Library'den The Scarlet Key gerekir.",
    ["The bag drops from Jandice Barov."] = "Çanta Jandice Barov'dan düşer.",
    ["The book is inside Scarlet Monastery: Library."] = "Kitap Scarlet Monastery: Library içinde.",
    ["The burnt tower on the road south of Camp Taurajo"] = "Camp Taurajo'nun güneyindeki yol üzerindeki yanık kule",
    ["The capital of the Dark Iron dwarves beneath Blackrock Mountain: the Detention Block, the Ring of Law, the Grim Guzzler and Shadowforge City, ruled by Emperor Dagran Thaurissan."] = "Blackrock Mountain'ın altındaki Dark Iron cücelerinin başkenti: Emperor Dagran Thaurissan'ın yönettiği Detention Block, Ring of Law, Grim Guzzler ve Shadowforge City.",
    ["The cart wreckage at the Alexston Farmstead"] = "Alexston Farmstead'deki araba enkazı",
    ["The cave is in Sunken Hollow, underwater around 21, 28: the entrance to the Drowned City."] = "Mağara, Sunken Hollow'da, yaklaşık 21, 28 civarında su altında: Drowned City'nin girişi.",
    ["The chain begins by dropping Dark Iron Map from Dark Iron Spies in Dun Morogh."] = "Zincir, Dun Morogh'daki Dark Iron Casuslarından Dark Iron Haritası düşmesiyle başlar.",
    ["The current Forever quest data also lists Arcane Intellect as a learned reward."] = "Güncel Forever görev verisi ödül olarak öğrenilen Arcane Intellect'i de listeliyor.",
    ["The direct quest has no item reward. Its follow-up, In Nightmares, later offers:"] = "Doğrudan görevin eşya ödülü yok. Devamı olan In Nightmares daha sonra şunları sunar:",
    ["The discs are in the Map Chamber, past Ironaya."] = "Diskler, Ironaya'yı geçince Map Chamber'da.",
    ["The eastern quarter of the ruined Highborne city of Eldre'Thalas, overgrown by the Warpwood and ruled by the satyr Alzzin the Wildshaper. Pusillin carries the Crescent Key that opens the other wings."] = "Warpwood ile kaplanmış ve satir Alzzin the Wildshaper'ın yönettiği yıkık Highborne şehri Eldre'Thalas'ın doğu mahallesi. Pusillin, diğer kanatları açan Hilal Anahtarı'nı taşır.",
    ["The fallen cart at Thoradin's Wall: climb it"] = "Thoradin's Wall'daki devrilmiş araba: üstüne tırman",
    ["The fifth and sixth Mosh'aru tablets are in the Smolderthorn troll area. Continues with Confront Yeh'kinya and The Hand of Rastakhan."] = "Beşinci ve altıncı Mosh'aru tabletleri Smolderthorn trol bölgesinde. Confront Yeh'kinya ve The Hand of Rastakhan ile devam eder.",
    ["The foreman is in the tunnels before the instance portal."] = "Ustabaşı, zindan portalından önceki tünellerde.",
    ["The four deeds: Southshore in the first large chamber, Tarren Mill before the hatchlings, Brill by Ras Frostwhisper, Caer Darrow by Lord Alexei Barov. The follow-up The Last Barov sends you to kill the rival brother."] = "Dört tapu: ilk büyük salonda Southshore, yavrulardan önce Tarren Mill, Ras Frostwhisper'ın yanında Brill, Lord Alexei Barov'un yanında Caer Darrow. Devam görevi The Last Barov seni rakip kardeşi öldürmeye gönderir.",
    ["The glowing rune on the floor of Baron Rivendare's room, Stratholme (Undead side)"] = "Baron Rivendare'in odasının zeminindeki parlayan rün, Stratholme (Undead tarafı)",
    ["The graveyard wing of the Scarlet Monastery, haunted by restless dead and Scarlet defenders."] = "Scarlet Monastery'nin mezarlık kanadı; huzursuz ölüler ve Scarlet savunucularıyla dolu.",
    ["The heart of the Scarlet Monastery: the Chapel Gardens and the Crusader's Chapel, held by Scarlet Commander Mograine and High Inquisitor Whitemane. The door is locked: you need The Scarlet Key from the Library."] = "Scarlet Monastery'nin kalbi: Scarlet Commander Mograine ve High Inquisitor Whitemane'in elindeki Chapel Gardens ve Crusader's Chapel. Kapı kilitli: Library'den The Scarlet Key gerekir.",
    ["The hill path, west"] = "Tepe patikası, batı",
    ["The irradiated underground city of the gnomes, overrun by troggs and Mekgineer Thermaplugg's forces."] = "Troggların ve Mekgineer Thermaplugg'ın kuvvetlerinin istila ettiği, gnomların radyasyonlu yeraltı şehri.",
    ["The item choice is awarded on the follow-up Unending Torment step in Undercity."] = "Eşya seçimi, Undercity'deki sonraki Unending Torment adımında verilir.",
    ["The library wing of the Scarlet Monastery, home to the Houndmaster's kennels and Arcanist Doan's athenaeum."] = "Scarlet Monastery'nin kütüphane kanadı; Houndmaster'ın köpek kulübeleri ve Arcanist Doan'ın okuma salonu burada.",
    ["The lower halls of Blackrock Spire, held by the Spirestone, Smolderthorn and Bloodaxe clans of the Dark Horde under Overlord Wyrmthalak."] = "Overlord Wyrmthalak komutasındaki Dark Horde'un Spirestone, Smolderthorn ve Bloodaxe klanlarının elindeki Blackrock Spire'ın alt salonları.",
    ["The main gate of Stratholme: the burning streets, the Scarlet Bastion and the Hall of Lights, where Grand Crusader Dathrohan reveals himself as the dreadlord Balnazzar."] = "Stratholme'un ana kapısı: yanan sokaklar, Scarlet Bastion ve Grand Crusader Dathrohan'ın kendini dehşet lordu Balnazzar olarak gösterdiği Hall of Lights.",
    ["The main road, north"] = "Ana yol, kuzey",
    ["The medallion drops from Nekrum Gutchewer."] = "Madalyon Nekrum Gutchewer'dan düşer.",
    ["The messenger travels the roads between Moonbrook, Gold Coast Quarry and Jangolode Mine."] = "Ulak, Moonbrook, Gold Coast Quarry ve Jangolode Mine arasındaki yollarda dolaşır.",
    ["The next required oasis investigation after The Forgotten Pools."] = "The Forgotten Pools'tan sonraki gerekli vaha araştırması.",
    ["The only punchographs outside the instance: on the raised platform in the Train Depot and by the Workshop (back door) entrance."] = "Zindanın dışındaki tek delgeçler: Train Depot'daki yükseltilmiş platformda ve Workshop (arka kapı) girişinin yanında.",
    ["The power source drops from Archaedas. Finishing it unlocks Talvash's Enhancing Necklace."] = "Güç kaynağı Archaedas'tan düşer. Bitirmek Talvash's Enhancing Necklace'ı açar.",
    ["The power stones drop from Shadowforge dwarves in the outer cave."] = "Güç taşları, dış mağaradaki Shadowforge cücelerinden düşer.",
    ["The questline starts at level 18 with Diplomatic Incident from Danitha Morr at Bandarion Keep, Tirisfal Glades. It takes you to Fenris Isle, where you free Lumina Windsinger from Fenris Keep."] = "Görev zinciri 18. seviyede Tirisfal Glades'teki Bandarion Keep'te Danitha Morr'dan Diplomatic Incident ile başlar. Seni Fenris Keep'ten Lumina Windsinger'ı kurtardığın Fenris Isle'a götürür.",
    ["The restored mage city of Dalaran has become a new five-player dungeon in WoW Forever. Enter through the sewers and the Underbelly, then fight through the streets to the Violet Citadel."] = "Yeniden kurulan büyücü şehri Dalaran, WoW Forever'da beş kişilik yeni bir zindan oldu. Lağımlardan ve Underbelly'den gir, sonra sokaklarda savaşarak Violet Citadel'e ulaş.",
    ["The road into Stonetalon (round Honor's Stand)"] = "Stonetalon'a giden yol (Honor's Stand'in çevresinden)",
    ["The road north, past Webwinder Path"] = "Kuzeye giden yol, Webwinder Path'in ötesine",
    ["The road south"] = "Güneye giden yol",
    ["The road south out of Stonetalon Peak"] = "Stonetalon Peak'ten güneye çıkan yol",
    ["The road west out of the Barrens"] = "Barrens'tan batıya çıkan yol",
    ["The rod drops from Sergeant Bly after the pyramid event."] = "Asa, piramit olayından sonra Sergeant Bly'dan düşer.",
    ["The ruined city of Lordaeron"] = "Yıkık Lordaeron şehri",
    ["The sacred caverns of the centaur in Desolace, where Princess Theradras and her corrupted earth elementals rule beneath Zaetar's grave. The orange and purple wings lead to the inner caves; the Scepter of Celebras opens the shortcut to the waterfall."] = "Desolace'teki kentaurların kutsal mağaraları; Princess Theradras ve bozulmuş toprak elementalleri Zaetar'ın mezarının altında hüküm sürüyor. Turuncu ve mor kanatlar iç mağaralara çıkar; Celebras Asası şelaleye giden kısayolu açar.",
    ["The sapphire drops from Grimlok and the power source from Archaedas."] = "Safir Grimlok'tan, güç kaynağı ise Archaedas'tan düşer.",
    ["The sapphire drops from Grimlok."] = "Safir Grimlok'tan düşer.",
    ["The service entrance side of Stratholme, held by the Scourge: the three ziggurats, the Slaughter House and Baron Rivendare's stronghold. Kill the Baron within 45 minutes to save Ysida Harmon."] = "Stratholme'un Scourge elindeki servis girişi tarafı: üç ziggurat, Slaughter House ve Baron Rivendare'in kalesi. Ysida Harmon'u kurtarmak için Baron'u 45 dakika içinde öldür.",
    ["The sun-baked troll city in the deserts of Tanaris, home of the Sandfury tribe and their chief, Ukorz Sandscalp."] = "Tanaris çöllerinde güneşte kavrulan trol şehri; Sandfury kabilesinin ve şefleri Ukorz Sandscalp'ın yurdu.",
    ["The supplies are found in the caves leading toward the Deadmines entrance."] = "Erzaklar, Deadmines girişine doğru giden mağaralarda bulunur.",
    ["The tablet at the bottom of the Vile Reef (around 25, 23)"] = "Vile Reef'in dibindeki tablet (yaklaşık 25, 23)",
    ["The tablet in the troll ruins on the coast (around 23, 12)"] = "Kıyıdaki trol kalıntılarındaki tablet (yaklaşık 23, 12)",
    ["The tablet is inside one of the vaults in the Reliquary of Kings, in Durgen Dirgehammer's final boss room. Open the vaults and interact with the tablet before leaving the dungeon."] = "Tablet, Durgen Dirgehammer'ın son boss odasında, Reliquary of Kings'teki kasalardan birinin içinde. Zindandan ayrılmadan önce kasaları aç ve tabletle etkileşime geç.",
    ["The tablets drop from Theka the Martyr and Hydromancer Velratha."] = "Tabletler Theka the Martyr ve Hydromancer Velratha'dan düşer.",
    ["The top of Blackrock Spire, held by Rend Blackhand's Dark Horde and General Drakkisath's black dragonflight. The door needs the Seal of Ascension."] = "Rend Blackhand'in Dark Horde'unun ve General Drakkisath'ın kara ejderha uçuşunun elindeki Blackrock Spire'ın tepesi. Kapı için Seal of Ascension gerekir.",
    ["The undead side tunnel is before the instance portal."] = "Undead yan tüneli zindan portalından önce.",
    ["The urns are in the outer Uldaman cave, before the instance portal.\n\nOptional introductory quest:"] = "Küpler, zindan portalından önce, dış Uldaman mağarasında.\n\nİsteğe bağlı giriş görevi:",
    ["The web drops from Lethtendris.\n\nOptional introductory quest:"] = "Ağ, Lethtendris'ten düşer.\n\nİsteğe bağlı giriş görevi:",
    ["Then Lord Maxwell Tyrosus and The Argent Hold, in Light's Hope Chapel, give the weapon or shield reward."] = "Ardından Light's Hope Chapel'daki Lord Maxwell Tyrosus ve The Argent Hold silah veya kalkan ödülünü verir.",
    ["Then take Bijou's Reconnaissance Report to Lexlort in Kargath for the reward."] = "Ardından ödül için Bijou's Reconnaissance Report'u Kargath'taki Lexlort'a götür.",
    ["There may not be enough of these mobs inside to finish it in one run."] = "İçeride bu yaratıklardan tek seferde bitirmeye yetecek kadar olmayabilir.",
    ["These mobs are outside the instance, around the entrance."] = "Bu yaratıklar zindanın dışında, girişin çevresinde.",
    ["Thicket Raptor Meat comes from the Thicket raptors (Thicket Lurker, Thicket Hunter, Thicket Matriarch) in Stalker's Thicket, the area of Shadetooth."] = "Thicket Raptor Eti, Shadetooth'un bölgesi olan Stalker's Thicket'teki Thicket raptorlarından (Thicket Lurker, Thicket Hunter, Thicket Matriarch) gelir.",
    ["Third required step before Horrors in the Highland."] = "Horrors in the Highland öncesi gerekli üçüncü adım.",
    ["This is a chain quest with a step in Blackfathom Deeps"] = "Bu, bir adımı Blackfathom Deeps'te olan bir zincir görev",
    ["This is a chain quest with a step in Shadowfang Keep"] = "Bu, bir adımı Shadowfang Keep'te olan bir zincir görev",
    ["This is a chain quest with a step in The Deadmines"] = "Bu, bir adımı The Deadmines'ta olan bir zincir görev",
    ["This is a long chain that has a step in the Library"] = "Bu, bir adımı Library'de olan uzun bir zincir",
    ["This leads directly into Underground Assault."] = "Bu, doğrudan Underground Assault görevine götürür.",
    ["This quest can be accepted alongside Prison Break In."] = "Bu görev Prison Break In ile aynı anda kabul edilebilir.",
    ["This quest is completed in the area OUTSIDE Razorfen Downs."] = "Bu görev Razorfen Downs'ın DIŞINDAKİ bölgede tamamlanır.",
    ["Thom Filch — Hall of Thanes portal, Ironforge"] = "Thom Filch — Hall of Thanes portalı, Ironforge",
    ["Thom Filch, by the bridge / vault entrance in Ironforge"] = "Thom Filch, Ironforge'daki köprü / kasa girişinin yanında",
    ["Thom Filch, near the dungeon entrance"] = "Thom Filch, zindan girişinin yakınında",
    ["Thorium Brotherhood Contract (from Lokhtos Darkbargainer with a Sulfuron Ingot)"] = "Thorium Brotherhood Sözleşmesi (bir Sulfuron Külçesi karşılığında Lokhtos Darkbargainer'dan)",
    ["Thrall, Valley of Wisdom, Orgrimmar (32.0, 37.8)"] = "Thrall, Valley of Wisdom, Orgrimmar (32.0, 37.8)",
    ["Thrall: Grommash Hold, Orgrimmar"] = "Thrall: Grommash Hold, Orgrimmar",
    ["Timed: rescue Ysida Harmon by killing Baron Rivendare within 45 minutes. Use the Extra-Dimensional Ghost Revealer to see Anthion."] = "Süreli: Baron Rivendare'i 45 dakika içinde öldürerek Ysida Harmon'u kurtar. Anthion'u görmek için Boyutlar Ötesi Hayalet Gösterici'yi kullan.",
    ["Titan Relic (dropped by Relic Guardian)"] = "Titan Kalıntısı (Relic Guardian düşürür)",
    ["Tome of Twilight"] = "Alacakaranlık Cildi",
    ["Tonga Runetotem: The Crossroads, The Barrens"] = "Tonga Runetotem: The Crossroads, The Barrens",
    ["Tonga sends you to Hamuul after Altered Beings."] = "Tonga, Altered Beings'ten sonra seni Hamuul'a gönderir.",
    ["Top of Old Ironforge, outside the dungeon"] = "Old Ironforge'un tepesi, zindanın dışında",
    ["Travel to Krol'dok Stronghold and slay Zalfan Moonshadow."] = "Krol'dok Stronghold'a git ve Zalfan Moonshadow'u öldür.",
    ["Troggs and Burning Blade cultists infest the molten caverns beneath Orgrimmar."] = "Trogglar ve Burning Blade tarikatçıları Orgrimmar'ın altındaki erimiş mağaraları istila etmiş.",
    ["Twilight Mementos"] = "Alacakaranlık Hatıraları",
    ["Two-Hand, Polearm"] = "İki El, Mızrak",
    ["Two-Hand, Staff"] = "İki El, Asa",
    ["Undead cannot take this quest"] = "Undead'ler bu görevi alamaz",
    ["Up the mountain path to the camp"] = "Dağ patikasından kampa çık",
    ["Up the path into the hills"] = "Patikadan tepelere çık",
    ["Use An Unsent Letter, looted from Edwin VanCleef."] = "Edwin VanCleef'ten alınan An Unsent Letter'ı kullan.",
    ["Use Dawn's Gambit in the Viewing Room and defeat Vectus."] = "Viewing Room'da Dawn's Gambit'i kullan ve Vectus'u yen.",
    ["Use Matrix Punchograph 3005-A with the White Punch Card to get a Yellow Punch Card."] = "Sarı Delikli Kart almak için Beyaz Delikli Kart ile Matrix Punchograph 3005-A'yı kullan.",
    ["Use Matrix Punchograph 3005-B with the Yellow Punch Card to get a Blue Punch Card."] = "Mavi Delikli Kart almak için Sarı Delikli Kart ile Matrix Punchograph 3005-B'yi kullan.",
    ["Use Matrix Punchograph 3005-C with the Blue Punch Card to get a Red Punch Card."] = "Kırmızı Delikli Kart almak için Mavi Delikli Kart ile Matrix Punchograph 3005-C'yi kullan.",
    ["Use Matrix Punchograph 3005-D with the Red Punch Card to get the Prismatic Punch Card, then bring it to Master Mechanic Castpipe in Ironforge."] = "Prizmatik Delikli Kart almak için Kırmızı Delikli Kart ile Matrix Punchograph 3005-D'yi kullan, sonra onu Ironforge'daki Master Mechanic Castpipe'a götür.",
    ["Use the Blood of Innocents at the brazier on the Scholomance porch. Rewards the Spectral Essence."] = "Masumların Kanı'nı Scholomance verandasındaki mangalda kullan. Ödül: Spectral Essence.",
    ["Use the Damp Note dropped by Blackfathom Tide Priestesses"] = "Blackfathom Tide Priestess'lerin düşürdüğü Nemli Not'u kullan",
    ["Use the Extra-Destructive Explosives quest-start item."] = "Extra-Destructive Explosives görev başlatma eşyasını kullan.",
    ["Use the Moonsilver Blade to destroy Old-Fire Eye in Silverpine Forest."] = "Moonsilver Blade'i kullanarak Silverpine Forest'taki Old Fire-Eye'ı yok et.",
    ["Use the Soulbound Keepsake on Ras Frostwhisper to make him human, then kill him and bring back his human head."] = "Soulbound Keepsake'i Ras Frostwhisper üzerinde kullanarak onu insana dönüştür, sonra onu öldür ve insan kafasını geri getir.",
    ["Use the hide and charcoal to make a rubbing of the Third Troll Legend tablet."] = "Deri ve kömürü kullanarak Üçüncü Trol Efsanesi tabletinin bir kopyasını çıkar.",
    ["Use the supplied cage on a Bloodaxe Worg Pup in the worg area."] = "Verilen kafesi worg bölgesindeki bir Bloodaxe Worg Yavrusu üzerinde kullan.",
    ["Using the module on the eggs in the Rookery can hatch whelps."] = "Modülü Rookery'deki yumurtalarda kullanmak yavruların çıkmasına yol açabilir.",
    ["Vaelan (Scarshield Infiltrator), Lower Blackrock Spire"] = "Vaelan (Scarshield Infiltrator), Lower Blackrock Spire",
    ["Vengeance of the Highborne"] = "Highborne'un İntikamı",
    ["Vile Fin murlocs — Lordamere Lake"] = "Vile Fin murlocları — Lordamere Lake",
    ["Vorrel Sengutz, inside the Graveyard"] = "Vorrel Sengutz, Graveyard içinde",
    ["WANTED poster"] = "ARANIYOR afişi",
    ["WANTED poster — Kargath, Badlands"] = "ARANIYOR afişi — Kargath, Badlands",
    ["Waist, Cloth"] = "Bel, Kumaş",
    ["Warden Thelwater, outside The Stockade, Stormwind"] = "Warden Thelwater, The Stockade'in dışında, Stormwind",
    ["Warlock class book. Click the book to start the quest."] = "Warlock sınıf kitabı. Görevi başlatmak için kitaba tıkla.",
    ["Warlock class quest. Needs 2 amber, 2 blue and 2 green Voodoo Feathers from the six troll guardians: Gasher, Mijan, Zolo, Hukku, Zul'Lor and Loro."] = "Warlock sınıf görevi. Altı trol muhafızından 2 kehribar, 2 mavi ve 2 yeşil Vudu Tüyü gerekir: Gasher, Mijan, Zolo, Hukku, Zul'Lor ve Loro.",
    ["Warlock class quest. The fragments come from Shadowfang Keep and Blackfathom Deeps."] = "Warlock sınıf görevi. Parçalar Shadowfang Keep ve Blackfathom Deeps'ten gelir.",
    ["Warlock dreadsteed quest. After Immol'thar dies, run the ritual in his prison with J'eevee's Jar, the Black Lodestone and the Xorothian Glyphs. Bring Soul Shards."] = "Warlock dreadsteed görevi. Immol'thar öldükten sonra J'eevee'nin Kavanozu, Kara Mıknatıs Taşı ve Xorothian Glifleri ile onun hapishanesinde ritüeli yap. Ruh Kırıkları getir.",
    ["Warlock dreadsteed quest. Release the Imp in a Jar at the alchemy lab in Ras Frostwhisper's room and wait for the parchment."] = "Warlock dreadsteed görevi. Ras Frostwhisper'ın odasındaki simya laboratuvarında Kavanozdaki İmp'i serbest bırak ve parşömeni bekle.",
    ["Warrior class book. Click the book to start the quest."] = "Warrior sınıf kitabı. Görevi başlatmak için kitaba tıkla.",
    ["Warrior class quest for both factions. Needs 2 amber, 2 blue and 2 green Voodoo Feathers from the six troll guardians: Gasher, Mijan, Zolo, Hukku, Zul'Lor and Loro.\n\nOptional introductory quest:"] = "Her iki fraksiyon için Warrior sınıf görevi. Altı trol muhafızından 2 kehribar, 2 mavi ve 2 yeşil Vudu Tüyü gerekir: Gasher, Mijan, Zolo, Hukku, Zul'Lor ve Loro.\n\nİsteğe bağlı giriş görevi:",
    ["Warrior trainers"] = "Warrior eğitmenleri",
    ["Warriors and Paladins. Lydros then gives The Forging of Quel'Serrar, which is finished in Onyxia's Lair."] = "Warrior ve Paladin'ler. Lydros ardından Onyxia's Lair'de tamamlanan The Forging of Quel'Serrar'ı verir.",
    ["Watch as Ott forges your blade."] = "Ott'un kılıcını dövmesini izle.",
    ["Waves of undead attack during the ritual. Talk to the brazier near the idol afterwards to finish."] = "Ritüel sırasında undead dalgaları saldırır. Bitirmek için ardından idolün yanındaki mangalla konuş.",
    ["West objective: the Gauntlet of Gordok Might is in a chest near Prince Tortheldrin. The quest itself comes from a friendly Captain Kromcrush in Dire Maul North after you become the Gordok king."] = "Batı hedefi: Gordok Gücü Eldiveni, Prince Tortheldrin'in yakınındaki bir sandıkta. Görevin kendisi, Gordok kralı olduktan sonra Dire Maul North'taki dost Captain Kromcrush'tan gelir.",
    ["West, down towards the Charred Vale"] = "Batı, Charred Vale'e doğru aşağı",
    ["Where the path into the hills leaves the road (left side)"] = "Tepelere giden patikanın yoldan ayrıldığı yer (sol taraf)",
    ["White Punch Card"] = "Beyaz Delikli Kart",
    ["White Punch Cards drop from the mobs here"] = "Beyaz Delikli Kartlar buradaki yaratıklardan düşer",
    ["Wiley the Black: Lakeshire inn, Redridge Mountains"] = "Wiley the Black: Lakeshire hanı, Redridge Mountains",
    ["Willix the Importer, inside Razorfen Kraul"] = "Willix the Importer, Razorfen Kraul içinde",
    ["Wrist, Leather"] = "Bilek, Deri",
    ["Wrist, Mail"] = "Bilek, Zincir",
    ["Yellow Punch Card (Punchograph 3005-A)"] = "Sarı Delikli Kart (Punchograph 3005-A)",
    ["Yorba Screwspigot: Steamwheedle Port, Tanaris"] = "Yorba Screwspigot: Steamwheedle Port, Tanaris",
    ["You have to be dead to talk to this guy. He's in Blackrock Mountain, in a room while walking the chain down to BRD."] = "Bu adamla konuşmak için ölü olman gerekir. Blackrock Mountain'da, zincirden BRD'ye inerken bir odada.",
    ["You need a remote detonator for the planned explosion."] = "Planlanan patlama için uzaktan bir fünye gerekiyor.",
    ["You receive a Blue Punch Card"] = "Bir Mavi Delikli Kart alırsın",
    ["You receive a Red Punch Card"] = "Bir Kırmızı Delikli Kart alırsın",
    ["You receive a Yellow Punch Card"] = "Bir Sarı Delikli Kart alırsın",
    ["Your class trainer"] = "Sınıf eğitmenin",
    ["Zaetar's Spirit appears after Princess Theradras dies."] = "Zaetar's Spirit, Princess Theradras öldükten sonra belirir.",
    ["Zalfan Moonshadow, a highborne among the Twilight's Hammer inside the stronghold; where he stands is not known yet."] = "Zalfan Moonshadow, kalenin içindeki Twilight's Hammer arasında bir highborne; nerede durduğu henüz bilinmiyor.",
    ["above the entrance to"] = "girişin üstünde",
    ["after the first room"] = "ilk odadan sonra",
    ["beneath Spirit Rise"] = "Spirit Rise'ın altında",
    ["beside the moonwell area"] = "ay kuyusu alanının yanında",
    ["dropped by Dark Iron Spies"] = "Dark Iron Casusları düşürür",
    ["graveyard inside Ruins of Lordaeron"] = "Ruins of Lordaeron içindeki mezarlık",
    ["inside Blackfathom Deeps"] = "Blackfathom Deeps içinde",
    ["inside Excavation Site: Wetlands"] = "Excavation Site: Wetlands içinde",
    ["inside Gnomeregan"] = "Gnomeregan içinde",
    ["inside Hall of Thanes"] = "Hall of Thanes içinde",
    ["inside Ragefire Chasm"] = "Ragefire Chasm içinde",
    ["inside Razorfen Kraul"] = "Razorfen Kraul içinde",
    ["inside Ruins of Lordaeron"] = "Ruins of Lordaeron içinde",
    ["inside Shadowfang Keep"] = "Shadowfang Keep içinde",
    ["inside the Deadmines"] = "Deadmines içinde",
    ["inside the Graveyard"] = "Graveyard içinde",
    ["inside the dungeon"] = "zindanın içinde",
    ["just inside Ruins of Lordaeron"] = "Ruins of Lordaeron'un hemen içinde",
    ["just outside Excavation Site: Wetlands"] = "Excavation Site: Wetlands'in hemen dışında",
    ["left of the entrance"] = "girişin solunda",
    ["near the Dalaran sewer entrance"] = "Dalaran lağım girişinin yakınında",
    ["near the dungeon entrance"] = "zindan girişinin yakınında",
    ["near the sewer entrance"] = "lağım girişinin yakınında",
    ["outside Excavation Site: Wetlands"] = "Excavation Site: Wetlands'in dışında",
    ["southeast of Brill"] = "Brill'in güneydoğusunda",
    ["the dungeon entrance"] = "zindan girişi",
}
T.bosses = { ["Trash Drops"] = "Trash Ganimeti" }
T.slotParts = {
    ["Chest"] = "Göğüs", ["Leather"] = "Deri", ["Wrist"] = "Bilek", ["Cloth"] = "Kumaş", ["Back"] = "Sırt", ["Waist"] = "Bel", ["Mail"] = "Zincir",
    ["Hands"] = "Eller", ["Feet"] = "Ayaklar", ["Legs"] = "Bacaklar", ["Neck"] = "Boyun", ["Finger"] = "Parmak", ["Trinket"] = "Takı", ["Bag"] = "Çanta",
    ["One-Hand"] = "Tek El", ["Main Hand"] = "Ana El", ["Off Hand"] = "Yardımcı El", ["Two-Hand"] = "İki El", ["Dagger"] = "Hançer", ["Sword"] = "Kılıç",
    ["Axe"] = "Balta", ["Mace"] = "Topuz", ["Staff"] = "Asa", ["Shield"] = "Kalkan", ["Polearm"] = "Mızrak", ["Ranged"] = "Menzilli", ["Wand"] = "Değnek",
    ["Thrown"] = "Fırlatma", ["Engineering"] = "Mühendislik", ["Quest Item"] = "Görev Eşyası", ["Head"] = "Baş", ["Shoulder"] = "Omuz", ["Bow"] = "Yay",
    ["Crossbow"] = "Arbalet", ["Fist Weapon"] = "Yumruk Silahı", ["Leatherworking Recipe"] = "Dericilik Tarifi", ["Held In Off-hand"] = "Yardımcı Elde Tutulur",
}
T.replacements = {}

-- WoWTurkce ek: zindan aciklamalari ve odul satirlari
T.dungeons = T.dungeons or {}
T.dungeons["Alcaz Prison"] = T.dungeons["Alcaz Prison"] or {}; T.dungeons["Alcaz Prison"].description = "Kral Varian Wrynn dahil üst düzey tutsakları barındırdığı uzun süredir söylenen Alcaz Adası'ndaki hapishaneye şimdiye kadar ulaşılamıyordu. İçeride Defias Kardeşliği ile nagalar savaş hâlinde."
T.dungeons["Blackfathom Deeps"] = T.dungeons["Blackfathom Deeps"] or {}; T.dungeons["Blackfathom Deeps"].description = "Zoram Strand'deki sular altında kalmış bir gece elfi harabesi; Aku'mai'ye hizmet eden nagalar, murloklar ve Twilight's Hammer tarikatçıları tarafından işgal edilmiş."
T.dungeons["Blackmaw Hold"] = T.dungeons["Blackmaw Hold"] or {}; T.dungeons["Blackmaw Hold"].description = "Azshara'da uzun süredir mühürlü bir kapının ardında, korularına ve dağ tünellerine yayılan bir bozulmayla savaşan Blackmaw klanının furbolg şehri yatıyor. Birçok yolu ve bossu olan büyük bir en üst seviye zindan; derinlikleri Azeroth'un daha da altına inebilir."
T.dungeons["Blackrock Depths"] = T.dungeons["Blackrock Depths"] or {}; T.dungeons["Blackrock Depths"].description = "Blackrock Mountain'ın altındaki Dark Iron cücelerinin başkenti: Detention Block, Ring of Law, Grim Guzzler ve İmparator Dagran Thaurissan'ın yönettiği Shadowforge City."
T.dungeons["City of Dalaran"] = T.dungeons["City of Dalaran"] or {}; T.dungeons["City of Dalaran"].description = "Yeniden kurulan büyücü şehri Dalaran, WoW Forever'da beş kişilik yeni bir zindan oldu. Kanalizasyon ve Underbelly'den girip sokaklarda savaşarak Violet Citadel'e ilerle."
T.dungeons["Dire Maul: East"] = T.dungeons["Dire Maul: East"] or {}; T.dungeons["Dire Maul: East"].description = "Yüce Doğuşluların harap şehri Eldre'Thalas'ın Warpwood ile kaplanmış, satir Alzzin the Wildshaper'ın yönettiği doğu bölümü. Diğer kanatları açan Crescent Key, Pusillin'dedir."
T.dungeons["Dire Maul: North"] = T.dungeons["Dire Maul: North"] or {}; T.dungeons["Dire Maul: North"].description = "Ogrelerin elindeki kuzey kanadı Gordok Commons. Yeni kral olmak için King Gordok'u öldür; daha büyük haraç sandığı için muhafızları canlı bırak (Tribute Run)."
T.dungeons["Dire Maul: West"] = T.dungeons["Dire Maul: West"] or {}; T.dungeons["Dire Maul: West"].description = "Son Shen'dralar'ın iblis Immol'thar'ı beş sütunun ardında hapsettiği Capital Gardens ve Court of the Highborne. Pusillin'den alınan Crescent Key gerekir."
T.dungeons["Excavation Site: Wetlands"] = T.dungeons["Excavation Site: Wetlands"] or {}; T.dungeons["Excavation Site: Wetlands"].description = "Whelgar's Excavation'ın üstünde zamanda donmuş bir Titan kazı alanı; başıboş Titan yapıtları artık kimseyi dinlemiyor. İçerideki bölgeler: Lost Marsh, Stalker's Thicket, Site of the Guardian ve Lost Dig Site."
T.dungeons["Gnomeregan"] = T.dungeons["Gnomeregan"] or {}; T.dungeons["Gnomeregan"].description = "Troglar ve Mekgineer Thermaplugg'ın güçleri tarafından istila edilmiş, radyasyonlu yeraltı gnome şehri."
T.dungeons["Hall of Thanes"] = T.dungeons["Hall of Thanes"] or {}; T.dungeons["Hall of Thanes"].description = "Biri Ironforge'un altındaki kraliyet cüce mezar odasına girdi."
T.dungeons["Krol'dok Stronghold"] = T.dungeons["Krol'dok Stronghold"] or {}; T.dungeons["Krol'dok Stronghold"].description = "Ogre akıncıları Riverglades boyunca yolcuları kaçırıyor ve yerleşimlere baskın yapıyor. İzleri atölyeler, kamplar ve korunan iç geçitlerden oluşan bir kaleye çıkıyor; gece çökünce oradan tuhaf ilahiler duyuluyor."
T.dungeons["Lower Blackrock Spire"] = T.dungeons["Lower Blackrock Spire"] or {}; T.dungeons["Lower Blackrock Spire"].description = "Overlord Wyrmthalak komutasındaki Dark Horde'un Spirestone, Smolderthorn ve Bloodaxe klanlarının tuttuğu Blackrock Spire'ın alt salonları."
T.dungeons["Maraudon"] = T.dungeons["Maraudon"] or {}; T.dungeons["Maraudon"].description = "Desolace'taki centaurların kutsal mağaraları; Prenses Theradras ve bozulmuş toprak elementalleri Zaetar'ın mezarının altında hüküm sürüyor. Turuncu ve mor kanatlar iç mağaralara çıkar; Scepter of Celebras şelaleye giden kestirmeyi açar."
T.dungeons["Ragefire Chasm"] = T.dungeons["Ragefire Chasm"] or {}; T.dungeons["Ragefire Chasm"].description = "Troglar ve Burning Blade tarikatçıları Orgrimmar'ın altındaki erimiş mağaraları istila etmiş."
T.dungeons["Razorfen Downs"] = T.dungeons["Razorfen Downs"] or {}; T.dungeons["Razorfen Downs"].description = "Quilboarların kadim mezarlığı, şimdi Scourge'un elinde. Amnennar the Coldbringer ölümsüzleri Downs'un tepesinden yönetiyor."
T.dungeons["Razorfen Kraul"] = T.dungeons["Razorfen Kraul"] or {}; T.dungeons["Razorfen Kraul"].description = "Razorfen Kraul quilboarlarının işgal ettiği uçsuz bucaksız bir diken labirenti."
T.dungeons["Ruins of Lordaeron"] = T.dungeons["Ruins of Lordaeron"] or {}; T.dungeons["Ruins of Lordaeron"].description = "Scourge güçleri harap başkenti hâlâ musallat ediyor, bir nekromant da şehrin içinde güç topluyor."
T.dungeons["Scarlet Monastery: Armory"] = T.dungeons["Scarlet Monastery: Armory"] or {}; T.dungeons["Scarlet Monastery: Armory"].description = "Kızıl Haçlıların, Scarlet Champion Herod'un gözetiminde acemilerini eğittiği Scarlet Monastery cephanelik kanadı. Kapı kilitli: Library'den The Scarlet Key gerekir."
T.dungeons["Scarlet Monastery: Cathedral"] = T.dungeons["Scarlet Monastery: Cathedral"] or {}; T.dungeons["Scarlet Monastery: Cathedral"].description = "Scarlet Monastery'nin kalbi: Scarlet Commander Mograine ile High Inquisitor Whitemane'in tuttuğu Chapel Gardens ve Crusader's Chapel. Kapı kilitli: Library'den The Scarlet Key gerekir."
T.dungeons["Scarlet Monastery: Graveyard"] = T.dungeons["Scarlet Monastery: Graveyard"] or {}; T.dungeons["Scarlet Monastery: Graveyard"].description = "Scarlet Monastery'nin huzursuz ölüler ve Kızıl savunucuların musallat olduğu mezarlık kanadı."
T.dungeons["Scarlet Monastery: Library"] = T.dungeons["Scarlet Monastery: Library"] or {}; T.dungeons["Scarlet Monastery: Library"].description = "Scarlet Monastery'nin, Houndmaster'ın köpek kulübelerine ve Arcanist Doan'ın kütüphanesine ev sahipliği yapan kütüphane kanadı."
T.dungeons["Scholomance"] = T.dungeons["Scholomance"] or {}; T.dungeons["Scholomance"].description = "Caer Darrow'daki Barov ailesi mahzeni, Cult of the Damned'in nekromansi okuluna dönüştürülmüş. Salonları Darkmaster Gandling yönetiyor; Barov görevlerinden alınan Skeleton Key kapıları açar."
T.dungeons["Shadowfang Keep"] = T.dungeons["Shadowfang Keep"] or {}; T.dungeons["Shadowfang Keep"].description = "Archmage Arugal ve worgen takipçileri, Pyrewood Village'ın yukarısındaki kaleyi tutuyor."
T.dungeons["Shaper's Terrace"] = T.dungeons["Shaper's Terrace"] or {}; T.dungeons["Shaper's Terrace"].description = "Un'Goro Crater'ın kuzey tepelerinde dinozorlara, katran çukurlarına ve güçlü kristallere bakan kadim bir titan tesisi. Un'Goro'nun dört bir yanından güç kristalleri topla ve teras içindeki konsollarda kullan. Şu ana kadar bilinen bosslar: Nanaya, Cinder, Bolt ve Snowtalon."
T.dungeons["Stratholme: Living"] = T.dungeons["Stratholme: Living"] or {}; T.dungeons["Stratholme: Living"].description = "Stratholme'un ana kapısı: yanan sokaklar, Scarlet Bastion ve Grand Crusader Dathrohan'ın kendini dehşet lordu Balnazzar olarak açığa çıkardığı Hall of Lights."
T.dungeons["Stratholme: Undead"] = T.dungeons["Stratholme: Undead"] or {}; T.dungeons["Stratholme: Undead"].description = "Stratholme'un Scourge'un elindeki servis girişi tarafı: üç ziggurat, Slaughter House ve Baron Rivendare'in kalesi. Ysida Harmon'ı kurtarmak için Baron'u 45 dakika içinde öldür."
T.dungeons["Sunken Temple"] = T.dungeons["Sunken Temple"] or {}; T.dungeons["Sunken Temple"].description = "Swamp of Sorrows'taki Pool of Tears'ın altına gömülmüş Atal'Hakkar Tapınağı. Atal'ai trolleri burada kan tanrıları Hakkar'ı çağırmaya çalışırken Eranikus'un yeşil ejderhaları alt salonları koruyor."
T.dungeons["The Deadmines"] = T.dungeons["The Deadmines"] or {}; T.dungeons["The Deadmines"].description = "Defias Kardeşliği, Moonbrook'un altındaki madenlerde bir savaş gemisi inşa ediyor."
T.dungeons["The Drowned City"] = T.dungeons["The Drowned City"] or {}; T.dungeons["The Drowned City"].description = "Kayıp bir Gurubashi troll şehri olan I'lalai, Grom'gol'ün batısında Stranglethorn Vale kıyısı açıklarında denizden yükseldi. Bu açık hava zindanının sokaklarında troller ve nagalar dolaşıyor, yakında bir korsan gemisi batık yatıyor ve son savaştan önce hava tam bir fırtınaya dönüyor. Girişi bulmak için suyun altına dal."
T.dungeons["The Stockade"] = T.dungeons["The Stockade"] or {}; T.dungeons["The Stockade"].description = "Defias tutsakları Stormwind'in Canal District altındaki hapishanesini ele geçirdi."
T.dungeons["Uldaman"] = T.dungeons["Uldaman"] or {}; T.dungeons["Uldaman"].description = "Badlands'in altına gömülmüş, troglar ve Shadowforge cüceleri tarafından istila edilmiş kadim bir titan mahzeni. Archaedas en derin odada Discs of Norgannon'u koruyor."
T.dungeons["Upper Blackrock Spire"] = T.dungeons["Upper Blackrock Spire"] or {}; T.dungeons["Upper Blackrock Spire"].description = "Rend Blackhand'in Dark Horde'u ve General Drakkisath'ın kara ejderha sürüsünün tuttuğu Blackrock Spire'ın tepesi. Kapı için Seal of Ascension gerekir."
T.dungeons["Wailing Caverns"] = T.dungeons["Wailing Caverns"] or {}; T.dungeons["Wailing Caverns"].description = "Barrens'ın derinliklerinde druidler ve fanglordlar uyuyan Naralex'i korurken bozulmuş canavarlar mağaralarda dolaşıyor."
T.dungeons["Zul'Farrak"] = T.dungeons["Zul'Farrak"] or {}; T.dungeons["Zul'Farrak"].description = "Tanaris çöllerinde güneşten kavrulmuş troll şehri; Sandfury kabilesinin ve reisleri Ukorz Sandscalp'ın yurdu."

-- WoWTurkce: boss, yaratık, eşya ve görev adları İngilizce kalır (kullanıcı isteği)
do
	local Q = T.quests
	if Q[-96908] then Q[-96908].name = nil end
	if Q[-96902] then Q[-96902].name = nil end
	if Q[-96901] then Q[-96901].name = nil end
	if Q[17] then Q[17].name = nil end
	if Q[65] then Q[65].name = nil end
	if Q[132] then Q[132].name = nil end
	if Q[135] then Q[135].name = nil end
	if Q[141] then Q[141].name = nil end
	if Q[142] then Q[142].name = nil end
	if Q[155] then Q[155].name = nil end
	if Q[166] then Q[166].name = nil end
	if Q[167] then Q[167].name = nil end
	if Q[168] then Q[168].name = nil end
	if Q[203] then Q[203].name = nil end
	if Q[204] then Q[204].name = nil end
	if Q[205] then Q[205].name = nil end
	if Q[207] then Q[207].name = nil end
	if Q[214] then Q[214].name = nil end
	if Q[261] then Q[261].name = nil end
	if Q[275] then Q[275].name = nil end
	if Q[276] then Q[276].name = nil end
	if Q[277] then Q[277].name = nil end
	if Q[303] then Q[303].name = nil end
	if Q[356] then Q[356].name = nil end
	if Q[373] then Q[373].name = nil end
	if Q[377] then Q[377].name = nil end
	if Q[378] then Q[378].name = nil end
	if Q[386] then Q[386].name = nil end
	if Q[387] then Q[387].name = nil end
	if Q[388] then Q[388].name = nil end
	if Q[389] then Q[389].name = nil end
	if Q[391] then Q[391].name = nil end
	if Q[447] then Q[447].name = nil end
	if Q[450] then Q[450].name = nil end
	if Q[451] then Q[451].name = nil end
	if Q[463] then Q[463].name = nil end
	if Q[484] then Q[484].name = nil end
	if Q[544] then Q[544].name = nil end
	if Q[545] then Q[545].name = nil end
	if Q[629] then Q[629].name = nil end
	if Q[704] then Q[704].name = nil end
	if Q[707] then Q[707].name = nil end
	if Q[709] then Q[709].name = nil end
	if Q[720] then Q[720].name = nil end
	if Q[721] then Q[721].name = nil end
	if Q[722] then Q[722].name = nil end
	if Q[723] then Q[723].name = nil end
	if Q[724] then Q[724].name = nil end
	if Q[725] then Q[725].name = nil end
	if Q[726] then Q[726].name = nil end
	if Q[738] then Q[738].name = nil end
	if Q[739] then Q[739].name = nil end
	if Q[762] then Q[762].name = nil end
	if Q[865] then Q[865].name = nil end
	if Q[870] then Q[870].name = nil end
	if Q[877] then Q[877].name = nil end
	if Q[880] then Q[880].name = nil end
	if Q[914] then Q[914].name = nil end
	if Q[959] then Q[959].name = nil end
	if Q[962] then Q[962].name = nil end
	if Q[971] then Q[971].name = nil end
	if Q[1013] then Q[1013].name = nil end
	if Q[1014] then Q[1014].name = nil end
	if Q[1048] then Q[1048].name = nil end
	if Q[1049] then Q[1049].name = nil end
	if Q[1050] then Q[1050].name = nil end
	if Q[1051] then Q[1051].name = nil end
	if Q[1052] then Q[1052].name = nil end
	if Q[1053] then Q[1053].name = nil end
	if Q[1098] then Q[1098].name = nil end
	if Q[1100] then Q[1100].name = nil end
	if Q[1101] then Q[1101].name = nil end
	if Q[1102] then Q[1102].name = nil end
	if Q[1109] then Q[1109].name = nil end
	if Q[1113] then Q[1113].name = nil end
	if Q[1139] then Q[1139].name = nil end
	if Q[1142] then Q[1142].name = nil end
	if Q[1144] then Q[1144].name = nil end
	if Q[1149] then Q[1149].name = nil end
	if Q[1150] then Q[1150].name = nil end
	if Q[1151] then Q[1151].name = nil end
	if Q[1152] then Q[1152].name = nil end
	if Q[1154] then Q[1154].name = nil end
	if Q[1159] then Q[1159].name = nil end
	if Q[1160] then Q[1160].name = nil end
	if Q[1198] then Q[1198].name = nil end
	if Q[1199] then Q[1199].name = nil end
	if Q[1200] then Q[1200].name = nil end
	if Q[1221] then Q[1221].name = nil end
	if Q[1275] then Q[1275].name = nil end
	if Q[1360] then Q[1360].name = nil end
	if Q[1394] then Q[1394].name = nil end
	if Q[1424] then Q[1424].name = nil end
	if Q[1429] then Q[1429].name = nil end
	if Q[1444] then Q[1444].name = nil end
	if Q[1445] then Q[1445].name = nil end
	if Q[1446] then Q[1446].name = nil end
	if Q[1448] then Q[1448].name = nil end
	if Q[1449] then Q[1449].name = nil end
	if Q[1450] then Q[1450].name = nil end
	if Q[1451] then Q[1451].name = nil end
	if Q[1452] then Q[1452].name = nil end
	if Q[1469] then Q[1469].name = nil end
	if Q[1475] then Q[1475].name = nil end
	if Q[1486] then Q[1486].name = nil end
	if Q[1487] then Q[1487].name = nil end
	if Q[1489] then Q[1489].name = nil end
	if Q[1490] then Q[1490].name = nil end
	if Q[1491] then Q[1491].name = nil end
	if Q[1651] then Q[1651].name = nil end
	if Q[1652] then Q[1652].name = nil end
	if Q[1653] then Q[1653].name = nil end
	if Q[1654] then Q[1654].name = nil end
	if Q[1740] then Q[1740].name = nil end
	if Q[1806] then Q[1806].name = nil end
	if Q[1954] then Q[1954].name = nil end
	if Q[1955] then Q[1955].name = nil end
	if Q[1956] then Q[1956].name = nil end
	if Q[2040] then Q[2040].name = nil end
	if Q[2198] then Q[2198].name = nil end
	if Q[2199] then Q[2199].name = nil end
	if Q[2200] then Q[2200].name = nil end
	if Q[2201] then Q[2201].name = nil end
	if Q[2202] then Q[2202].name = nil end
	if Q[2204] then Q[2204].name = nil end
	if Q[2240] then Q[2240].name = nil end
	if Q[2258] then Q[2258].name = nil end
	if Q[2278] then Q[2278].name = nil end
	if Q[2279] then Q[2279].name = nil end
	if Q[2280] then Q[2280].name = nil end
	if Q[2283] then Q[2283].name = nil end
	if Q[2284] then Q[2284].name = nil end
	if Q[2318] then Q[2318].name = nil end
	if Q[2338] then Q[2338].name = nil end
	if Q[2339] then Q[2339].name = nil end
	if Q[2342] then Q[2342].name = nil end
	if Q[2398] then Q[2398].name = nil end
	if Q[2418] then Q[2418].name = nil end
	if Q[2500] then Q[2500].name = nil end
	if Q[2768] then Q[2768].name = nil end
	if Q[2769] then Q[2769].name = nil end
	if Q[2770] then Q[2770].name = nil end
	if Q[2841] then Q[2841].name = nil end
	if Q[2842] then Q[2842].name = nil end
	if Q[2843] then Q[2843].name = nil end
	if Q[2846] then Q[2846].name = nil end
	if Q[2861] then Q[2861].name = nil end
	if Q[2864] then Q[2864].name = nil end
	if Q[2865] then Q[2865].name = nil end
	if Q[2904] then Q[2904].name = nil end
	if Q[2922] then Q[2922].name = nil end
	if Q[2924] then Q[2924].name = nil end
	if Q[2926] then Q[2926].name = nil end
	if Q[2928] then Q[2928].name = nil end
	if Q[2929] then Q[2929].name = nil end
	if Q[2930] then Q[2930].name = nil end
	if Q[2933] then Q[2933].name = nil end
	if Q[2934] then Q[2934].name = nil end
	if Q[2935] then Q[2935].name = nil end
	if Q[2936] then Q[2936].name = nil end
	if Q[2945] then Q[2945].name = nil end
	if Q[2947] then Q[2947].name = nil end
	if Q[2948] then Q[2948].name = nil end
	if Q[2949] then Q[2949].name = nil end
	if Q[2950] then Q[2950].name = nil end
	if Q[2951] then Q[2951].name = nil end
	if Q[2962] then Q[2962].name = nil end
	if Q[2988] then Q[2988].name = nil end
	if Q[2989] then Q[2989].name = nil end
	if Q[2990] then Q[2990].name = nil end
	if Q[2991] then Q[2991].name = nil end
	if Q[3042] then Q[3042].name = nil end
	if Q[3341] then Q[3341].name = nil end
	if Q[3373] then Q[3373].name = nil end
	if Q[3444] then Q[3444].name = nil end
	if Q[3446] then Q[3446].name = nil end
	if Q[3447] then Q[3447].name = nil end
	if Q[3520] then Q[3520].name = nil end
	if Q[3523] then Q[3523].name = nil end
	if Q[3525] then Q[3525].name = nil end
	if Q[3527] then Q[3527].name = nil end
	if Q[3528] then Q[3528].name = nil end
	if Q[3636] then Q[3636].name = nil end
	if Q[3701] then Q[3701].name = nil end
	if Q[3702] then Q[3702].name = nil end
	if Q[3765] then Q[3765].name = nil end
	if Q[3801] then Q[3801].name = nil end
	if Q[3802] then Q[3802].name = nil end
	if Q[3906] then Q[3906].name = nil end
	if Q[3907] then Q[3907].name = nil end
	if Q[3981] then Q[3981].name = nil end
	if Q[3982] then Q[3982].name = nil end
	if Q[4001] then Q[4001].name = nil end
	if Q[4002] then Q[4002].name = nil end
	if Q[4003] then Q[4003].name = nil end
	if Q[4024] then Q[4024].name = nil end
	if Q[4061] then Q[4061].name = nil end
	if Q[4062] then Q[4062].name = nil end
	if Q[4063] then Q[4063].name = nil end
	if Q[4081] then Q[4081].name = nil end
	if Q[4082] then Q[4082].name = nil end
	if Q[4083] then Q[4083].name = nil end
	if Q[4121] then Q[4121].name = nil end
	if Q[4122] then Q[4122].name = nil end
	if Q[4123] then Q[4123].name = nil end
	if Q[4126] then Q[4126].name = nil end
	if Q[4128] then Q[4128].name = nil end
	if Q[4132] then Q[4132].name = nil end
	if Q[4133] then Q[4133].name = nil end
	if Q[4134] then Q[4134].name = nil end
	if Q[4136] then Q[4136].name = nil end
	if Q[4141] then Q[4141].name = nil end
	if Q[4142] then Q[4142].name = nil end
	if Q[4143] then Q[4143].name = nil end
	if Q[4145] then Q[4145].name = nil end
	if Q[4146] then Q[4146].name = nil end
	if Q[4147] then Q[4147].name = nil end
	if Q[4182] then Q[4182].name = nil end
	if Q[4183] then Q[4183].name = nil end
	if Q[4184] then Q[4184].name = nil end
	if Q[4185] then Q[4185].name = nil end
	if Q[4186] then Q[4186].name = nil end
	if Q[4201] then Q[4201].name = nil end
	if Q[4223] then Q[4223].name = nil end
	if Q[4224] then Q[4224].name = nil end
	if Q[4241] then Q[4241].name = nil end
	if Q[4242] then Q[4242].name = nil end
	if Q[4262] then Q[4262].name = nil end
	if Q[4263] then Q[4263].name = nil end
	if Q[4264] then Q[4264].name = nil end
	if Q[4282] then Q[4282].name = nil end
	if Q[4286] then Q[4286].name = nil end
	if Q[4295] then Q[4295].name = nil end
	if Q[4322] then Q[4322].name = nil end
	if Q[4324] then Q[4324].name = nil end
	if Q[4341] then Q[4341].name = nil end
	if Q[4342] then Q[4342].name = nil end
	if Q[4361] then Q[4361].name = nil end
	if Q[4362] then Q[4362].name = nil end
	if Q[4701] then Q[4701].name = nil end
	if Q[4724] then Q[4724].name = nil end
	if Q[4726] then Q[4726].name = nil end
	if Q[4729] then Q[4729].name = nil end
	if Q[4734] then Q[4734].name = nil end
	if Q[4735] then Q[4735].name = nil end
	if Q[4742] then Q[4742].name = nil end
	if Q[4743] then Q[4743].name = nil end
	if Q[4764] then Q[4764].name = nil end
	if Q[4766] then Q[4766].name = nil end
	if Q[4768] then Q[4768].name = nil end
	if Q[4769] then Q[4769].name = nil end
	if Q[4771] then Q[4771].name = nil end
	if Q[4787] then Q[4787].name = nil end
	if Q[4788] then Q[4788].name = nil end
	if Q[4808] then Q[4808].name = nil end
	if Q[4809] then Q[4809].name = nil end
	if Q[4810] then Q[4810].name = nil end
	if Q[4862] then Q[4862].name = nil end
	if Q[4866] then Q[4866].name = nil end
	if Q[4867] then Q[4867].name = nil end
	if Q[4903] then Q[4903].name = nil end
	if Q[4907] then Q[4907].name = nil end
	if Q[4941] then Q[4941].name = nil end
	if Q[4974] then Q[4974].name = nil end
	if Q[4981] then Q[4981].name = nil end
	if Q[4982] then Q[4982].name = nil end
	if Q[5001] then Q[5001].name = nil end
	if Q[5002] then Q[5002].name = nil end
	if Q[5047] then Q[5047].name = nil end
	if Q[5065] then Q[5065].name = nil end
	if Q[5081] then Q[5081].name = nil end
	if Q[5089] then Q[5089].name = nil end
	if Q[5102] then Q[5102].name = nil end
	if Q[5122] then Q[5122].name = nil end
	if Q[5125] then Q[5125].name = nil end
	if Q[5127] then Q[5127].name = nil end
	if Q[5160] then Q[5160].name = nil end
	if Q[5212] then Q[5212].name = nil end
	if Q[5213] then Q[5213].name = nil end
	if Q[5214] then Q[5214].name = nil end
	if Q[5243] then Q[5243].name = nil end
	if Q[5244] then Q[5244].name = nil end
	if Q[5245] then Q[5245].name = nil end
	if Q[5246] then Q[5246].name = nil end
	if Q[5247] then Q[5247].name = nil end
	if Q[5250] then Q[5250].name = nil end
	if Q[5251] then Q[5251].name = nil end
	if Q[5262] then Q[5262].name = nil end
	if Q[5263] then Q[5263].name = nil end
	if Q[5281] then Q[5281].name = nil end
	if Q[5282] then Q[5282].name = nil end
	if Q[5341] then Q[5341].name = nil end
	if Q[5343] then Q[5343].name = nil end
	if Q[5382] then Q[5382].name = nil end
	if Q[5384] then Q[5384].name = nil end
	if Q[5461] then Q[5461].name = nil end
	if Q[5462] then Q[5462].name = nil end
	if Q[5463] then Q[5463].name = nil end
	if Q[5464] then Q[5464].name = nil end
	if Q[5465] then Q[5465].name = nil end
	if Q[5466] then Q[5466].name = nil end
	if Q[5515] then Q[5515].name = nil end
	if Q[5518] then Q[5518].name = nil end
	if Q[5522] then Q[5522].name = nil end
	if Q[5525] then Q[5525].name = nil end
	if Q[5526] then Q[5526].name = nil end
	if Q[5527] then Q[5527].name = nil end
	if Q[5529] then Q[5529].name = nil end
	if Q[5531] then Q[5531].name = nil end
	if Q[5542] then Q[5542].name = nil end
	if Q[5543] then Q[5543].name = nil end
	if Q[5544] then Q[5544].name = nil end
	if Q[5722] then Q[5722].name = nil end
	if Q[5723] then Q[5723].name = nil end
	if Q[5724] then Q[5724].name = nil end
	if Q[5725] then Q[5725].name = nil end
	if Q[5726] then Q[5726].name = nil end
	if Q[5727] then Q[5727].name = nil end
	if Q[5728] then Q[5728].name = nil end
	if Q[5742] then Q[5742].name = nil end
	if Q[5761] then Q[5761].name = nil end
	if Q[5781] then Q[5781].name = nil end
	if Q[5845] then Q[5845].name = nil end
	if Q[5846] then Q[5846].name = nil end
	if Q[5848] then Q[5848].name = nil end
	if Q[5961] then Q[5961].name = nil end
	if Q[6022] then Q[6022].name = nil end
	if Q[6042] then Q[6042].name = nil end
	if Q[6133] then Q[6133].name = nil end
	if Q[6135] then Q[6135].name = nil end
	if Q[6136] then Q[6136].name = nil end
	if Q[6141] then Q[6141].name = nil end
	if Q[6163] then Q[6163].name = nil end
	if Q[6402] then Q[6402].name = nil end
	if Q[6403] then Q[6403].name = nil end
	if Q[6501] then Q[6501].name = nil end
	if Q[6502] then Q[6502].name = nil end
	if Q[6521] then Q[6521].name = nil end
	if Q[6522] then Q[6522].name = nil end
	if Q[6561] then Q[6561].name = nil end
	if Q[6562] then Q[6562].name = nil end
	if Q[6563] then Q[6563].name = nil end
	if Q[6564] then Q[6564].name = nil end
	if Q[6565] then Q[6565].name = nil end
	if Q[6566] then Q[6566].name = nil end
	if Q[6567] then Q[6567].name = nil end
	if Q[6568] then Q[6568].name = nil end
	if Q[6569] then Q[6569].name = nil end
	if Q[6570] then Q[6570].name = nil end
	if Q[6582] then Q[6582].name = nil end
	if Q[6583] then Q[6583].name = nil end
	if Q[6584] then Q[6584].name = nil end
	if Q[6585] then Q[6585].name = nil end
	if Q[6601] then Q[6601].name = nil end
	if Q[6602] then Q[6602].name = nil end
	if Q[6626] then Q[6626].name = nil end
	if Q[6627] then Q[6627].name = nil end
	if Q[6628] then Q[6628].name = nil end
	if Q[6921] then Q[6921].name = nil end
	if Q[6922] then Q[6922].name = nil end
	if Q[6981] then Q[6981].name = nil end
	if Q[7028] then Q[7028].name = nil end
	if Q[7029] then Q[7029].name = nil end
	if Q[7041] then Q[7041].name = nil end
	if Q[7044] then Q[7044].name = nil end
	if Q[7046] then Q[7046].name = nil end
	if Q[7064] then Q[7064].name = nil end
	if Q[7065] then Q[7065].name = nil end
	if Q[7066] then Q[7066].name = nil end
	if Q[7067] then Q[7067].name = nil end
	if Q[7068] then Q[7068].name = nil end
	if Q[7070] then Q[7070].name = nil end
	if Q[7201] then Q[7201].name = nil end
	if Q[7441] then Q[7441].name = nil end
	if Q[7461] then Q[7461].name = nil end
	if Q[7463] then Q[7463].name = nil end
	if Q[7481] then Q[7481].name = nil end
	if Q[7482] then Q[7482].name = nil end
	if Q[7483] then Q[7483].name = nil end
	if Q[7484] then Q[7484].name = nil end
	if Q[7485] then Q[7485].name = nil end
	if Q[7488] then Q[7488].name = nil end
	if Q[7489] then Q[7489].name = nil end
	if Q[7492] then Q[7492].name = nil end
	if Q[7494] then Q[7494].name = nil end
	if Q[7498] then Q[7498].name = nil end
	if Q[7499] then Q[7499].name = nil end
	if Q[7500] then Q[7500].name = nil end
	if Q[7501] then Q[7501].name = nil end
	if Q[7502] then Q[7502].name = nil end
	if Q[7503] then Q[7503].name = nil end
	if Q[7504] then Q[7504].name = nil end
	if Q[7505] then Q[7505].name = nil end
	if Q[7506] then Q[7506].name = nil end
	if Q[7507] then Q[7507].name = nil end
	if Q[7563] then Q[7563].name = nil end
	if Q[7564] then Q[7564].name = nil end
	if Q[7604] then Q[7604].name = nil end
	if Q[7623] then Q[7623].name = nil end
	if Q[7624] then Q[7624].name = nil end
	if Q[7625] then Q[7625].name = nil end
	if Q[7626] then Q[7626].name = nil end
	if Q[7627] then Q[7627].name = nil end
	if Q[7628] then Q[7628].name = nil end
	if Q[7629] then Q[7629].name = nil end
	if Q[7630] then Q[7630].name = nil end
	if Q[7631] then Q[7631].name = nil end
	if Q[7637] then Q[7637].name = nil end
	if Q[7639] then Q[7639].name = nil end
	if Q[7640] then Q[7640].name = nil end
	if Q[7641] then Q[7641].name = nil end
	if Q[7642] then Q[7642].name = nil end
	if Q[7643] then Q[7643].name = nil end
	if Q[7644] then Q[7644].name = nil end
	if Q[7645] then Q[7645].name = nil end
	if Q[7646] then Q[7646].name = nil end
	if Q[7647] then Q[7647].name = nil end
	if Q[7648] then Q[7648].name = nil end
	if Q[7667] then Q[7667].name = nil end
	if Q[7668] then Q[7668].name = nil end
	if Q[7703] then Q[7703].name = nil end
	if Q[7761] then Q[7761].name = nil end
	if Q[7848] then Q[7848].name = nil end
	if Q[8151] then Q[8151].name = nil end
	if Q[8153] then Q[8153].name = nil end
	if Q[8231] then Q[8231].name = nil end
	if Q[8232] then Q[8232].name = nil end
	if Q[8233] then Q[8233].name = nil end
	if Q[8234] then Q[8234].name = nil end
	if Q[8235] then Q[8235].name = nil end
	if Q[8236] then Q[8236].name = nil end
	if Q[8250] then Q[8250].name = nil end
	if Q[8251] then Q[8251].name = nil end
	if Q[8252] then Q[8252].name = nil end
	if Q[8253] then Q[8253].name = nil end
	if Q[8254] then Q[8254].name = nil end
	if Q[8255] then Q[8255].name = nil end
	if Q[8256] then Q[8256].name = nil end
	if Q[8257] then Q[8257].name = nil end
	if Q[8410] then Q[8410].name = nil end
	if Q[8412] then Q[8412].name = nil end
	if Q[8413] then Q[8413].name = nil end
	if Q[8414] then Q[8414].name = nil end
	if Q[8415] then Q[8415].name = nil end
	if Q[8416] then Q[8416].name = nil end
	if Q[8417] then Q[8417].name = nil end
	if Q[8418] then Q[8418].name = nil end
	if Q[8419] then Q[8419].name = nil end
	if Q[8420] then Q[8420].name = nil end
	if Q[8421] then Q[8421].name = nil end
	if Q[8422] then Q[8422].name = nil end
	if Q[8423] then Q[8423].name = nil end
	if Q[8424] then Q[8424].name = nil end
	if Q[8425] then Q[8425].name = nil end
	if Q[8945] then Q[8945].name = nil end
	if Q[9051] then Q[9051].name = nil end
	if Q[9052] then Q[9052].name = nil end
	if Q[9053] then Q[9053].name = nil end
	if Q[9063] then Q[9063].name = nil end
	if Q[78261] then Q[78261].name = nil end
	if Q[78307] then Q[78307].name = nil end
	if Q[78676] then Q[78676].name = nil end
	if Q[78699] then Q[78699].name = nil end
	if Q[79008] then Q[79008].name = nil end
	if Q[79192] then Q[79192].name = nil end
	if Q[79974] then Q[79974].name = nil end
	if Q[79975] then Q[79975].name = nil end
	if Q[79976] then Q[79976].name = nil end
	if Q[79980] then Q[79980].name = nil end
	if Q[92401] then Q[92401].name = nil end
	if Q[92415] then Q[92415].name = nil end
	if Q[92421] then Q[92421].name = nil end
	if Q[92422] then Q[92422].name = nil end
	if Q[92432] then Q[92432].name = nil end
	if Q[92434] then Q[92434].name = nil end
	if Q[92456] then Q[92456].name = nil end
	if Q[92457] then Q[92457].name = nil end
	if Q[92458] then Q[92458].name = nil end
	if Q[92489] then Q[92489].name = nil end
	if Q[92742] then Q[92742].name = nil end
	if Q[92744] then Q[92744].name = nil end
	if Q[92745] then Q[92745].name = nil end
	if Q[92747] then Q[92747].name = nil end
	if Q[92748] then Q[92748].name = nil end
	if Q[92749] then Q[92749].name = nil end
	if Q[92750] then Q[92750].name = nil end
	if Q[92751] then Q[92751].name = nil end
	if Q[92752] then Q[92752].name = nil end
	if Q[92753] then Q[92753].name = nil end
	if Q[92819] then Q[92819].name = nil end
	if Q[93680] then Q[93680].name = nil end
	if Q[94907] then Q[94907].name = nil end
	if Q[94968] then Q[94968].name = nil end
	if Q[94972] then Q[94972].name = nil end
	if Q[94975] then Q[94975].name = nil end
	if Q[94982] then Q[94982].name = nil end
	if Q[94983] then Q[94983].name = nil end
	if Q[94984] then Q[94984].name = nil end
	if Q[95034] then Q[95034].name = nil end
	if Q[95036] then Q[95036].name = nil end
	if Q[95111] then Q[95111].name = nil end
	if Q[95125] then Q[95125].name = nil end
	if Q[95126] then Q[95126].name = nil end
	if Q[95140] then Q[95140].name = nil end
	if Q[95189] then Q[95189].name = nil end
	if Q[95195] then Q[95195].name = nil end
	if Q[95204] then Q[95204].name = nil end
	if Q[95216] then Q[95216].name = nil end
	if Q[95250] then Q[95250].name = nil end
	if Q[95646] then Q[95646].name = nil end
	if Q[95647] then Q[95647].name = nil end
	if Q[95663] then Q[95663].name = nil end
	if Q[95664] then Q[95664].name = nil end
	if Q[95682] then Q[95682].name = nil end
	if Q[95697] then Q[95697].name = nil end
	if Q[95748] then Q[95748].name = nil end
	if Q[95770] then Q[95770].name = nil end
	if Q[95772] then Q[95772].name = nil end
	if Q[95773] then Q[95773].name = nil end
	if Q[95775] then Q[95775].name = nil end
	if Q[95776] then Q[95776].name = nil end
	if Q[95786] then Q[95786].name = nil end
	if Q[95787] then Q[95787].name = nil end
	if Q[95788] then Q[95788].name = nil end
	if Q[95789] then Q[95789].name = nil end
	if Q[95791] then Q[95791].name = nil end
	if Q[95795] then Q[95795].name = nil end
	if Q[95799] then Q[95799].name = nil end
	if Q[95809] then Q[95809].name = nil end
	if Q[95810] then Q[95810].name = nil end
	if Q[96391] then Q[96391].name = nil end
	if Q[96393] then Q[96393].name = nil end
	if Q[96394] then Q[96394].name = nil end
	if Q[96395] then Q[96395].name = nil end
	if Q[96403] then Q[96403].name = nil end
	if Q[96771] then Q[96771].name = nil end
	if Q[96774] then Q[96774].name = nil end
	if Q[96800] then Q[96800].name = nil end
	if Q[96984] then Q[96984].name = nil end
	if Q[96986] then Q[96986].name = nil end
	if Q[96987] then Q[96987].name = nil end
	if Q[96988] then Q[96988].name = nil end
	if Q[97130] then Q[97130].name = nil end
	if Q[97196] then Q[97196].name = nil end
	if Q[97288] then Q[97288].name = nil end
	if Q[98423] then Q[98423].name = nil end
	if Q[98815] then Q[98815].name = nil end
	if Q[98823] then Q[98823].name = nil end
	if Q[98824] then Q[98824].name = nil end
	if Q[99156] then Q[99156].name = nil end
	if Q[2930001] then Q[2930001].name = nil end
	if Q[2930002] then Q[2930002].name = nil end
	if Q[2930003] then Q[2930003].name = nil end
	if Q[2930004] then Q[2930004].name = nil end
	if Q[2930005] then Q[2930005].name = nil end
	if Q[5127] then Q[5127].note = "Demircilik 270 (Zırh Ustası). Blood Stained Pike'i Goraluk'un cesedinde kullan ve yakındaki Unforged Rune Covered Breastplate'ı al." end
	if Q[5127] then Q[5127].objective = "Blackrock Spire'a git ve Goraluk Anvilcrack'ı bul. Onu öldür, sonra Blood Stained Pike'i cesedi üzerinde kullan. Ruhu emildikten sonra mızrak Ruha Bulanmış hale gelecek.$B$BAyrıca Dövülmemiş Rün Kaplı Göğüs Zırhı'nı da bulmalısın.$B$BHem Ruha Bulanmış Mızrak'ı hem de Dövülmemiş Rün Kaplı Göğüs Zırhı'nı Winterspring'deki Lorax'a götür." end
	if Q[8232] then Q[8232].note = "Hunter sınıf görevi. Tooth of Morphaz Morphaz'dan düşer.\n\nİsteğe bağlı giriş görevi:" end
	if Q[8232] then Q[8232].objective = "Tooth of Morphaz'ı Azshara'daki Ogtinc'e getir. Ogtinc, Ruins of Eldarath'ın kuzeydoğusundaki yamaçların tepesinde yaşıyor." end
	if Q[4136] then Q[4136].objective = "Ribbly's Head'ı Burning Steppes'teki Yuka Screwspigot'a götür." end
	if Q[95140] then Q[95140].note = "Undead'ler ve taurenler için Paladin sınıf görevi. Bu zindanda: Whitestone Oak Lumber Goblin Woodcarver'lardan düşer. Diğer parçalar Enchanted Silver Ingot (Shadowfang Keep) ve Purified Kor Gem (Blackfathom Deeps)." end
	if Q[95140] then Q[95140].objective = "Silverpine Forest'taki Old Fire-Eye'ı yok etmek için Moonsilver Blade'ı kullan." end
	if Q[95204] then Q[95204].objective = "Crest of Lordaeron'u Undercity'deki Oran Snakewrithe'a götür." end
	if Q[1049] then Q[1049].objective = "Tirisfal Glades'teki Manastır'dan Compendium of the Fallen'i al ve Thunder Bluff'taki Sage Truthseeker'a dön." end
	if Q[1050] then Q[1050].objective = "Manastır'dan Mythology of the Titans'ı al ve Ironforge'daki Librarian Mae Paledust'a getir." end
	if Q[1052] then Q[1052].objective = "Brother Anton'un Letter of Commendation'u Southshore'daki Dindar Raleigh'e götür." end
	if Q[8424] then Q[8424].objective = "Blasted Lands'teki Shadowsworn'u katlet ve Horde'un Fallen Hero'ya dön." end
	if Q[5243] then Q[5243].note = "Sokaklardaki erzak sandıklarından 5 Stratholme Holy Water topla; bazı sandıklardan düşman çıkar." end
	if Q[5243] then Q[5243].objective = "Kuzeydeki Stratholme'a git. Şehri dolduran erzak sandıklarını ara ve 5 Stratholme Holy Water bul. Yeterince kutsal sıvı topladığında Saygıdeğer Leonid Barthalomew'e dön." end
	if Q[92456] then Q[92456].objective = "Stormwind City'deki Shylamiir için City of Dalaran'dan bir Fel Infused Blossom topla." end
	if Q[4264] then Q[4264].pickup = "A Crumpled Up Note (Dark Iron cücelerinden düşer)" end
	if Q[135] then Q[135].objective = "Wiley's Note'u Stormwind'deki Mathias Shaw'a götür." end
	if Q[7441] then Q[7441].note = "Pusillin'i kanat boyunca kovala ve o savaşana kadar onunla konuş, sonra kitap için onu öldür. Crescent Key'i da düşürür." end
	if Q[2930002] then Q[2930002].objective = "Yellow Punch Card almak için White Punch Card ile Matrix Punchograph 3005-A'yı kullan." end
	if Q[2930002] then Q[2930002].turnin = "Bir Yellow Punch Card alırsın" end
	if Q[1100] then Q[1100].pickup = "Henrig Lonebrow's Journal, Great Lift'in dibinde cesedinin yanında" end
	if Q[1100] then Q[1100].objective = "Henrig Lonebrow's Journal'ı oku." end
	if Q[1101] then Q[1101].objective = "Razorflank's Medallion'u Thalanaar'daki Falfindel Waywarder'a getir." end
	if Q[1102] then Q[1102].objective = "Razorflank's Heart'ı Thunder Bluff'taki Auld Stonespire'a getir." end
	if Q[7481] then Q[7481].note = "Athenaeum'da Lorekeeper Lydros'un yanındaki Telmius Dreamseeker'ın Skeletal Remains ile etkileşime geç. Lydros'un libram takaslarını açar." end
	if Q[277] then Q[277].objective = "Rethiel the Greenwarden'a 9 Crude Flint getir." end
	if Q[7489] then Q[7489].objective = "Lethtendris's Web'i Feralas'taki Camp Mojache'de bulunan Talo Thornhoof'a götür." end
	if Q[1109] then Q[1109].objective = "Undercity'deki Master Apothecary Faranell'e 1 yığın Kraul Guano getir." end
	if Q[6502] then Q[6502].objective = "Blood of the Black Dragon Champion'u General Drakkisath'tan almalısın. Drakkisath, Blackrock Spire'da Yükseliş Salonları'nın ardındaki taht odasında bulunabilir." end
	if Q[141] then Q[141].objective = "Shaw's Report'u Westfall'daki Gryan Stoutmantle'a götür." end
	if Q[5531] then Q[5531].objective = "Frozen Eggs'i Betina Bigglezink'e götür." end
	if Q[2258] then Q[2258].objective = "Badlands'te Kargath'taki Jarkal Mossmeld'e 5 Vulture Gizzard, 10 Crag Coyote Dişi ve 5 Rock Elemental Shard getir." end
	if Q[5543] then Q[5543].objective = "30 Plaguebat öldür ve Tirion Fordring'e dön." end
	if Q[142] then Q[142].objective = "Westfall'daki Defias Messenger'i bul ve mesajını Stoutmantle'a getir." end
	if Q[6582] then Q[6582].objective = "Blue Dragon soyunun ejder şampiyonu Scryer'ı bul ve öldür. Kafatasını cesedinden sök ve Emberstrife'a getir.$B$BScryer'ın Winterspring'de bulunabileceğini biliyorsun." end
	if Q[1139] then Q[1139].objective = "Tablet of Will'i bul ve Ironforge'daki Advisor Belgrum'a getir." end
	if Q[1142] then Q[1142].objective = "Treshala's Pendant'ı bul ve Darnassus'taki Treshala Fallowbrook'a geri götür." end
	if Q[1150] then Q[1150].objective = "Grenka's Claw'ı Thousand Needles'taki Dorn Plainstalker'a getir." end
	if Q[95787] then Q[95787].note = "Görev veren henüz doğrulanmadı. Giriş görevi: An Acquaintance in Southshore, Savage Coast Report Bundle'u Loremaster Dibbs'e götürmek." end
	if Q[7761] then Q[7761].objective = "Bu ork gerçekten aptalın teki. Görünüşe göre Komuta Orb'a erişmek için bu dağlama demirini bulup Drakkisath'ın Damgası'nı edinmen gerekiyor.$B$BMektuba göre dağlama demirini General Drakkisath koruyor. Belki de araştırmalısın." end
	if Q[3373] then Q[3373].pickup = "Essence of Eranikus (Shade of Eranikus'tan düşer)" end
	if Q[3373] then Q[3373].objective = "Essence of Eranikus'u Sunken Temple'daki bu inde bulunan Öz Pınarı'na yerleştir." end
	if Q[5727] then Q[5727].objective = "Lieutenant's Insignia'yı Neeru Fireblade'e götür ve onunla konuş. Seni Burning Blade üyesi sanıp sanmadığını anla, sonra Orgrimmar'daki Thrall'a dön." end
	if Q[8425] then Q[8425].objective = "Sunken Temple'daki Troll'lardan aldığın Voodoo Feathers'i Horde'un Fallen Hero'ya getir." end
	if Q[4764] then Q[4764].objective = "Doomrigger's Clasp'ı Burning Steppes'teki Mayara Brightwing'e götür." end
	if Q[4768] then Q[4768].note = "Darkstone Tablet Rookery'de yerde duruyor.\n\nİsteğe bağlı giriş görevi:" end
	if Q[4768] then Q[4768].objective = "Darkstone Tablet'i Kargath'taki Shadow Mage Vivian Lagrave'e götür." end
	if Q[1198] then Q[1198].objective = "Blackfathom Deeps'te Argent Guard Thaelrid'i bul." end
	if Q[4808] then Q[4808].objective = "Tinkee's Letter'i Felnok Steelspring'e ver." end
	if Q[95663] then Q[95663].objective = "Go to Wetlands ve Dragonmaw kampının yukarısındaki tepelerde Ölüm Takipçisi Ajanı ile buluş." end
	if Q[95664] then Q[95664].pickup = "Titan Relic (Relic Guardian düşürür)" end
	if Q[95664] then Q[95664].objective = "Titan Relic'i Thunder Bluff'taki Elder Rise'a götür ve sana onun hakkında daha fazlasını anlatabilecek birini ara." end
	if Q[8945] then Q[8945].note = "Süreli: Baron Rivendare'i 45 dakika içinde öldürerek Ysida Harmon'u kurtar. Anthion'u görmek için Extra-Dimensional Ghost Revealer'i kullan." end
	if Q[6163] then Q[6163].objective = "Stratholme'e git ve Gorger Ramstein'ı öldür. Nathanos için hatıra olarak kafasını al." end
	if Q[4201] then Q[4201].objective = "4 Gromsblood, 10 Dev Gümüş Damarı ve Nagmara's Filled Vial'ı Blackrock Depths'teki Mistress Nagmara'ya getir." end
	if Q[7482] then Q[7482].note = "Athenaeum'da Lorekeeper Lydros'un yanındaki Telmius Dreamseeker'ın Skeletal Remains ile etkileşime geç. Lydros'un libram takaslarını açar." end
	if Q[5464] then Q[5464].objective = "Soulbound Keepsake'ı Eastern Plaguelands'teki Leonid Barthalomew'e götür." end
	if Q[2768] then Q[2768].objective = "Kehanomatik Çubuk'u Gadgetzan'daki Chief Engineer Bilgewhizzle'a getir." end
	if Q[2770] then Q[2770].objective = "Gahz'rilla's Electrified Scale'ı Shimmering Flats'teki Wizzle Brassbolts'a getir." end
	if Q[7626] then Q[7626].objective = "10 Elixir of Shadow Power'i Burning Steppes'teki Gorzeeki Wildeyes'a getir." end
	if Q[7630] then Q[7630].objective = "3 Arcanite Bar'ı Burning Steppes'teki Gorzeeki'ye getir." end
	if Q[7642] then Q[7642].objective = "40 Runecloth, 6 Arcanite Bar, 10 Arthas' Tears, 5 şişe Stratholme Holy Water ve 150 altını Stormwind'in Dwarven District'indeki Grimand Elmore'a götür." end
	if Q[7646] then Q[7646].objective = "Bir Azerothian Elmas ile bir Pristine Black Diamond'u Stormwind'in Cathedral District'indeki Lord Grayson Shadowbreaker'a götür." end
	if Q[94907] then Q[94907].objective = "Twilight's Shroud içindeki bir kanaldan bir Twilight's Thrall çağır ve onu Amberhall's Soulstone ile yakala." end
	if Q[709] then Q[709].objective = "Tablet of Ryun'eh'i Kayıp Theldurin'e getir." end
	if Q[8251] then Q[8251].objective = "Başbüyücü Xylem'e 10 Glittering Dust getir." end
	if Q[1424] then Q[1424].objective = "Stonard'daki Fel'zerul 10 Atal'ai Artifact toplamanı istiyor." end
	if Q[5728] then Q[5728].objective = "Orgrimmar'daki Thrall'a dönmeden önce Bazzalan'ı ve Invoker Jergosh'u öldür." end
	if Q[4729] then Q[4729].note = "Verilen kafesi worg bölgesindeki bir Bloodaxe Worg Pup üzerinde kullan." end
	if Q[4729] then Q[4729].objective = "Blackrock Spire'a git ve Bloodaxe Worg Yavrularını bul. Vahşi küçük canavarları taşımak için kafesi kullan. Kibler'a Kafesli Worg Pup getir." end
	if Q[3907] then Q[3907].note = "BRD içindeki Black Anvil'de Lord Incendius'u öldür ve Tablet of Kurniya'yı geri getir." end
	if Q[1446] then Q[1446].objective = "The Hinterlands'teki Atal'ai Exile, Jammal'an'ın Başı'nı istiyor." end
	if Q[724] then Q[724].objective = "Hammertoe's Amulet'i Ironforge'daki Tarihçi Karnik'e götür." end
	if Q[1452] then Q[1452].objective = "Hinterlands'deki Rhapsody Shindigger ona 3 Roc Gizzard, 3 Groddoc Liver ve 3 Ironfur Liver getirmeni istiyor." end
	if Q[4809] then Q[4809].objective = "Felnok Steelspring'e 8 Uncracked Chillwind Horn getir." end
	if Q[2926] then Q[2926].objective = "Radyoaktif serpinti toplamak için Empty Leaden Collection Phial'ı Işınlanmış İstilacılar ya da Işınlanmış Yağmacılar üzerinde kullan. Şişe dolunca onu Kharanos'taki Ozzie Togglevolt'a geri götür." end
	if Q[2930] then Q[2930].objective = "Bir Prismatic Punch Card'ı Ironforge'daki Master Mechanic Castpipe'a götür." end
	if Q[2934] then Q[2934].objective = "Tarren Mill'deki Eczacı Lydon'a bir Undamaged Venom Sac getir." end
	if Q[1469] then Q[1469].objective = "Atal'ai Tablet Fragment'i Stormwind'deki Brohann Caskbelly'ye götür." end
	if Q[94975] then Q[94975].objective = "Krol'dok Stronghold'daki Twilight's Hammer'dan 15 Cultist Kulağı topla." end
	if Q[2950] then Q[2950].objective = "Brilliant Gold Ring'i, bir Silver Bar'ı, bir Yosun Akik'i ve 30 gümüş sikkeyi Orgrimmar'daki Nogg'a getir." end
	if Q[2962] then Q[2962].objective = "Gnomeregan'a git ve High Potency Radioactive Fallout getir. Uyarayım, serpinti kararsızdır ve oldukça çabuk bozulur.$B$BGörev tamamlandığında Ozzie, Ağır Kurşun Toplama Şişeni de isteyecek.$B" end
	if Q[2990] then Q[2990].objective = "Sharpbeak's Feather'i Blasted Lands'teki Thadius Grimshade'e götür." end
	if Q[5001] then Q[5001].objective = "Bijou's Belongings'i bul ve ona geri götür. Bol şans!$B" end
	if Q[7067] then Q[7067].note = "Dış mağaralardaki Nameless Prophet'ten Amulet of Spirits'i al, sonra beş Khan ile savaşmak için kullan: üçü dış mağaralarda, biri mor rotada ve biri turuncu rotada. Taşlarını muskayla birleştir." end
	if Q[9051] then Q[9051].objective = "Devilsaur Barb'ı bir Devilsaura sapla. Bu görevi tamamladığında Un'Goro Crater'daki Torwa Pathfinder'a dön." end
	if Q[4083] then Q[4083].note = "Madencilik 230. Seven savaşından önce Gloom'rel ile konuş; Smelt Dark Iron'u öğrenmek için Spectral Kadeh'e 2 Star Yakutu, 20 Altın Külçe ve 10 Truesilver Külçe ver." end
	if Q[4083] then Q[4083].objective = "Gloom'rel'e 2 Star Yakutu, 20 Altın Külçe ve 10 Truesilver Külçe getir, sonra bunları Summoners' Tomb'daki Spectral Kadeh'e koy." end
	if Q[95810] then Q[95810].pickup = "Titan Relic (Relic Guardian düşürür)" end
	if Q[95810] then Q[95810].objective = "Titan Relic'i Wetlands kazı alanındaki Kâşif Whelgar'a götür." end
	if Q[5125] then Q[5125].note = "Baron savaşından önce Medallion of Faith'i Aurius'a ver; Baron Rivendare öldükten sonra onunla konuş." end
	if Q[5125] then Q[5125].objective = "Medallion of Faith'i Aurius'a ver; Baron Rivendare'e karşı savaşa katılır. Savaştan sonra ödülünü al." end
	if Q[386] then Q[386].objective = "Dehşet Targorr'un kafasını Lakeshire'daki Guard Berton'a getir." end
	if Q[4122] then Q[4122].objective = "Burning Steppes'e git ve Grark Lorkrub'ı bul. Lexlort'un, onun en son devasa bir Blackrock kalesinde görüldüğünden bahsettiğini hatırlıyorsun.$B$BGrark Lorkrub'ı bulduğunda, onu bağlamak için Thorium Shackles'ini kullan ve ardından Blackrock Mountain'dan geçirerek Searing Gorge'a geri götür. Lexlort'un adamları, Grark'ı gözaltına almak için diğer tarafta bekliyor olacak.$B" end
	if Q[4126] then Q[4126].objective = "Lost Thunderbrew Recipe'i Kharanos'taki Ragnar Thunderbrew'a getir." end
	if Q[4134] then Q[4134].objective = "Lost Thunderbrew Recipe'i Kargath'taki Vivian Lagrave'e getir." end
	if Q[78676] then Q[78676].objective = "Scarlet Monastery'nin içinde Eye of Bhossca'yı bul. Ardından onu Pyrewood Village yakınındaki C'nin gizli bırakma noktasına götür. Bu işi tek başına tamamlamalısın." end
	if Q[4186] then Q[4186].objective = "Bolvar's Decree'yi Lakeshire'daki Yargıç Solomon'a götür.$B" end
	if Q[5213] then Q[5213].objective = "Stratholme'e git ve zigguratları ara. Yeni Scourge Data'yı bul ve Betina Bigglezink'e getir.$B" end
	if Q[391] then Q[391].objective = "Bazil Thredd'i öldür ve kellesini Stockade'deki Warden Thelwater'a getir." end
	if Q[8412] then Q[8412].objective = "Spirit Totem için gereken parçaları Rüzgârgözcüsü Bath'rah'a getir." end
	if Q[5245] then Q[5245].objective = "Jaron's Pick'i kullanarak dört Highborne Kalıntı Parçası'nı bul. Onları Eastern Plaguelands'teki Aurora Skycaller'a götür." end
	if Q[92744] then Q[92744].objective = "Alba Fairmoon, Westfall kıyı şeridi boyunca 7 Longshore Murloc Gill toplamanı istiyor." end
	if Q[4282] then Q[4282].objective = "Marshal Windsor's Lost Information'u geri getir.$B$BMareşal Windsor, bilgilerin Golem Lordu Argelmach ve General Angerforge'un elinde olduğuna inanıyor." end
	if Q[5341] then Q[5341].objective = "Scholomance'a git ve Barov ailesinin servetini geri getir. Bu servet dört tapudan oluşuyor: The Deed to Caer Darrow, The Deed to Brill, The Deed to Tarren Mill ve The Deed to Southshore. Bu görevi tamamladığında Alexi Barov'a dön." end
	if Q[92489] then Q[92489].objective = "Stormwind City'deki High Sorcerer Andromath için City of Dalaran'daki Mana Elemental'ı öldür." end
	if Q[4362] then Q[4362].objective = "Blackrock Depths'e dön ve Princess Moira Bronzebeard'ü Emperor Dagran Thaurissan'ın kötü pençelerinden kurtar.$B" end
	if Q[2201] then Q[2201].turnin = "Talvash del Kissel (Phial of Scrying)" end
	if Q[96774] then Q[96774].objective = "Batık Şehir'den Ancient bir Gurubashi Putu'nu geri getir." end
	if Q[7483] then Q[7483].objective = "Çabukluk Mührü almak için bir Çabukluk Duaları Kitabı, 1 Kusursuz Siyah Elmas, 2 Büyük Parlak Kristal ve 2 Blood of Heroes'i Dire Maul'daki Lorekeeper Lydros'a getir." end
	if Q[-96902] then Q[-96902].objective = "Witch Doctor Zum'rah'ı öldür ve Zum'rah's Head'ı Dalaran'daki Archmage Lan'dalock'a getir." end
	if Q[5461] then Q[5461].objective = "Arathi Highlands'e, Stromgarde harabelerine git. Stromgarde'da bir Keepsake of Remembrance ara. Böyle bir eşya bulursan onunla Yargıç Marduke'a dön." end
	if Q[5465] then Q[5465].objective = "Caer Darrow'daki Yargıç Marduke'a dön. Ona Soulbound Keepsake'ı göster." end
	if Q[79192] then Q[79192].note = "Sun Rock Retreat'in (50.9, 52.3) kuzeydoğusundaki yoldan terk edilmiş kampa çık; cep döküntüleri bir kutunun üzerinde. İsteğe bağlı: bu görevden gelen Simple Wood ve Çakmaktaşı ile kampın ortasındaki ateş çukurunu yak (Rekindle)." end
	if Q[204] then Q[204].objective = "Asi Kampı'ndaki Sergeant Yohwa'ya 7 Orman İlacı ve 1 Venom Fern Extract'tı getir." end
	if Q[205] then Q[205].objective = "Asi Kampı'ndaki Brother Nimetz'e 4 Skullsplitter Fetish getir." end
	if Q[5525] then Q[5525].note = "North ogrelerinden bir Gordok Shackle Key al ve Knot'u serbest bırak; zulasında ganimet var." end
	if Q[5525] then Q[5525].objective = "Gordok kanadındaki ogrelerden bir Gordok Shackle Key bul ve Knot Thimblejack'i serbest bırakmak için kullan." end
	if Q[5529] then Q[5529].note = "20 Vebalı Yavru öldür. Bunu teslim ettikten sonra yavrular, Betina'ya tekrarlanabilir teslim başlatan Sağlıklı Dragon Pulu düşürebilir." end
	if Q[6564] then Q[6564].pickup = "Blackfathom Tide Priestess'lerin düşürdüğü Damp Note'u kullan" end
	if Q[9052] then Q[9052].objective = "8 Kan Başlığı ve 8 Gorishi Sting topla, ardından Un'Goro Crater'daki Torwa Pathfinder'a dön." end
	if Q[1654] then Q[1654].objective = "Jordan's Weapon Notes'i kullanarak biraz Whitestone Oak Lumber, Bailor'ın Arıtılmış Cevher Sevkiyatı, Jordan's Smithing Hammer ve bir Kor Taşı bul ve Ironforge'daki Jordan Stilwell'e getir." end
	if Q[7639] then Q[7639].objective = "Exorcism Censer'i Stormwind'in Cathedral District'indeki Lord Grayson Shadowbreaker'a götür." end
	if Q[7643] then Q[7643].objective = "Bir ruh atını beslemek için kullanılan özel at yemini edin. Görünüşe göre bu yemin kaynağı Southshore'daki Merideth Carlson.$B$BFeralas'taki Dire Maul zindanına git ve Tendris Warpwood'u öldür. Böylece Ancient Equine Spirit'i özgür bırakacaksın. Ona özel at yemini yedirerek ruhu yatıştır. Son olarak, kutsaması için ona Arcanite Barding'i ver." end
	if Q[7647] then Q[7647].objective = "Divination Scryer'i Scholomance'taki Great Ossuary'nin bodrumunun tam ortasında kullan. Bu, yargılaman gereken ruhları ortaya çıkaracak. Bu ruhları yenmek Death Knight Darkreaver'i çağıracak. Onu yen ve düşmüş savaş atının kayıp ruhunu geri al.$B$BSavaş Atının Kurtarılmış Ruhu'nu ve Kutsanmış Efsunlu At Zırhı'nı Darkreaver's Fallen Charger'e ver." end
	if Q[98823] then Q[98823].objective = "Titan Relic'i Mulgore'un kuzeybatısındaki Skywatcher Plateau'da bulunan Muln Earthfury'ye götür." end
	if Q[7667] then Q[7667].objective = "Orgrimmar'ın Valley of Wisdom bölgesindeki Sagorne Crestrider'a yardım etmek istersen ona bir Azerothian Diamond ve bir Pristine Black Diamond getir." end
	if Q[7703] then Q[7703].note = "West hedefi: Gordok Gücü Eldiveni, Prince Tortheldrin'in yakınındaki bir sandıkta. Görevin kendisi, Gordok kralı olduktan sonra Dire Maul North'taki dost Captain Kromcrush'tan gelir." end
	if Q[8253] then Q[8253].note = "Mage sınıf görevi. Arcane Kırığı Morphaz'dan düşer.\n\nİsteğe bağlı giriş görevi:" end
	if Q[98824] then Q[98824].objective = "Titan Relic'i Ironforge'daki Hall of Explorers'ta bulunan High Explorer Magellas'a götür." end
	if Q[-96906] then Q[-96906].objective = "Alcaz Prison'a gir ve oradaki insan muhafızlardan 8 Blood Red Bandana topla." end
	if Q[5725] then Q[5725].objective = "Spells of Shadow ve Nether'den Efsunlar adlı kitapları Undercity'deki Varimathras'a getir." end
	if Q[4734] then Q[4734].objective = "Eggscilloscope Prototype'i Yuvalık'taki bir yumurtanın üzerinde kullan." end
	if Q[-96907] then Q[-96907].objective = "Alcaz Prison'da 15 Strashaz Soldier ve 8 Strashaz Enchantress öldür ve Ca'zass's Head'ı getir." end
	if Q[4742] then Q[4742].objective = "Üç komuta mücevherini bul: Smolderthorn Mücevheri, Spirestone Mücevheri ve Bloodaxe Mücevheri. Bunları Unadorned Seal of Ascension ile birlikte Vaelan'a götür.$B$BVaelan'ın sana söylediğine göre generaller şunlardır: Smolderthorn'dan War Master Voone, Spirestone'dan Highlord Omokk ve Bloodaxe'tan Overlord Wyrmthalak." end
	if Q[5781] then Q[5781].objective = "Eastern Plaguelands'in en güney kesimindeki Undercroft'a git ve Taelan's Hammer'i geri al. Hedefini tamamladıktan sonra Tirion Fordring'e dön." end
	if Q[4810] then Q[4810].objective = "Felnok's Package'ı Burning Steppes'teki Tinkee Steamboil'e götür." end
	if Q[5845] then Q[5845].objective = "Eastern Plaguelands'in kuzeydoğusundaki Northdale'e git ve Symbol of Lost Honor'u geri al. Hedefini tamamladıktan sonra Tirion Fordring'e dön." end
	if Q[3444] then Q[3444].objective = "Stone Circle'i Ratchet'teki Marvon Rivetseeker'ın atölyesinden al." end
	if Q[4862] then Q[4862].note = "Spire Spider Eggs örümcek tünellerinde." end
	if Q[4862] then Q[4862].objective = "Blackrock Spire'a git ve Kibler için 15 Spire Spider Yumurtası topla.$B$BAnlaşılan bu yumurtalar örümceklerin yakınında bulunabilir.$B" end
	if Q[1740] then Q[1740].objective = "3 Soran'ruk Fragment ve 1 Large Soran'ruk Fragment bul ve bunları Barrens'taki Doan Karhan'a geri getir." end
	if Q[4982] then Q[4982].objective = "Bijou's Belongings'i bul ve ona geri götür. Onları şehrin en alt katına sakladığından bahsettiğini hatırlıyorsun.$B" end
	if Q[7044] then Q[7044].note = "Celebrian Asası Noxxion'dan, Celebrian Diamond ise Lord Vyletongue'dan düşer." end
	if Q[7044] then Q[7044].objective = "Celebras Asası'nın iki parçasını geri al: Celebrian Rod ve Celebrian Diamond.$B$BCelebras ile konuşmanın bir yolunu bul." end
	if Q[5002] then Q[5002].objective = "Burning Steppes'e git ve Bijou's Information'u Mareşal Maxwell'e ver." end
	if Q[3528] then Q[3528].note = "Avatar of Hakkar'ı çağırmak için Egg of Hakkar'ı Hakkari Bloodkeeper'lardan doldur." end
	if Q[3528] then Q[3528].objective = "Filled Egg of Hakkar'ı Tanaris'teki Yeh'kinya'ya getir." end
	if Q[7064] then Q[7064].objective = "Princess Theradras'ı öldür ve Desolace'taki Shadowprey Village yakınlarında bulunan Selendra'ya dön." end
	if Q[95697] then Q[95697].objective = "Wetlands'teki Excavation Sites'a gir ve Thicket Raptor Meat getir." end
	if Q[95250] then Q[95250].objective = "Ruins of Lordaeron'da Head of the Baron'u ele geçir ve Yüzbaşı Truman'a geri getir." end
	if Q[447] then Q[447].objective = "6 Grizzled Bear Heart ve 6 Skittering Blood örneği topla ve Undercity'deki Master Apothecary Faranell'e teslim et." end
	if Q[5122] then Q[5122].objective = "Medallion of Faith'i Scarlet Bastion'daki Malor the Zealous'tan al ve Aurius'a geri getir." end
	if Q[450] then Q[450].objective = "Apothecary Berard's Journal'ı Pyrewood Village'dan al ve Sepulcher'daki Apothecary Renferrel'e götür." end
	if Q[4123] then Q[4123].note = "Heart of the Mountain, Dark Keeper'lardan sonra kasadaki kasada." end
	if Q[4123] then Q[4123].objective = "Heart of the Mountain'i Burning Steppes'teki Maxwort Uberglint'e getir." end
	if Q[451] then Q[451].objective = "Undercity'deki Master Apothecary Faranell'e 6 Lake Creeper Moss örneği, 6 Lake Skulker Moss örneği ve bir Hardened Tumor getir." end
	if Q[4143] then Q[4143].note = "Atal'ai Haze, tapınağın solucanlarından, pusucularından ve balçıklarından düşer." end
	if Q[1806] then Q[1806].note = "İnsanlar ve cüceler için Paladin sınıf görevi. Bu zindanda: Whitestone Oak Lumber Goblin Woodcarver'lardan düşer. Diğer parçalar Jordan's Smithing Hammer (Shadowfang Keep), Kor Gem (Blackfathom Deeps) ve Jordan'ın cevher sevkiyatı (Loch Modan)." end
	if Q[99156] then Q[99156].objective = "Riptear's Heart'ı Deathguard Linnea'ya getir." end
	if Q[4183] then Q[4183].objective = "Lakeshire'a git ve Helendis Riverhorn's Letter'i Yargıç Solomon'a teslim et." end
	if Q[5214] then Q[5214].objective = "Stratholme'de Fras Siabi'nin tütün dükkânını bul ve bir kutu Siabi's Premium Tobacco'yu getir. İş bitince Smokey LaRue'ya dön.$B" end
	if Q[97288] then Q[97288].objective = "Abominable Head'ı Undercity'deki Usta Eczacı Faranell'e teslim et." end
	if Q[97288] then Q[97288].rewardHeader = "Chain ödülü — devam görevi" end
	if Q[97130] then Q[97130].objective = "Drowned City'den bir Ancient Gurubashi İdolü geri al." end
	if Q[723] then Q[723].objective = "Hammertoe's Amulet'i Badlands'teki Maden Arayıcı Ryedol'a götür." end
	if Q[5262] then Q[5262].pickup = "Head of Balnazzar (Balnazzar'dan düşer)" end
	if Q[5262] then Q[5262].objective = "Head of Balnazzar'ı Eastern Plaguelands'teki Duke Nicholas Zverenhoff'a götür." end
	if Q[96987] then Q[96987].objective = "Kanalizasyon girişinin yakınındaki Rexxie Copperclutch için City of Dalaran'dan \"The Founding of Dalaran\" kitabını topla." end
	if Q[7461] then Q[7461].objective = "Immol'thar'ın Hapishanesi'ne güç veren 5 Kule'yi çevreleyen muhafızları yok etmelisin. Kuleler devre dışı kaldığında Immol'thar'ı çevreleyen güç kalkanı dağılmış olacak.$B$BSonra Immol'thar'ın Hapishanesi'ne gir ve kalbinde duran iğrenç iblisi yok et. Son olarak Athenaeum'da Prince Tortheldrin'le yüzleş.$B$BBu görevi tamamlarsan avludaki Shen'dralar Ancient'e dön." end
	if Q[5282] then Q[5282].objective = "Egan's Blaster'i Stratholme'ün hayaletimsi ve tayfsı sakinleri üzerinde kullan. Huzursuz ruhlar hayalet kabuklarından kurtulduğunda patlatıcıyı yeniden kullan; özgürlüklerine kavuşacaklar!$B$B15 Huzursuz Ruh'u özgür bırak ve Egan'a dön." end
	if Q[96393] then Q[96393].pickup = "Earthseer Farsen, Dun Morogh (Underground Map'tan sonra)" end
	if Q[96393] then Q[96393].note = "Zincir, Dun Morogh'daki Dark Iron Casuslarından Dark Iron Map düşmesiyle başlar." end
	if Q[96393] then Q[96393].objective = "Old Ironforge'un altındaki Hall of Thanes'e gir ve Durgen Dirgehammer'ın Head'ı al." end
	if Q[96391] then Q[96391].pickup = "Dark Iron Map, Ironband's Compound'daki Dark Iron Casusları düşürür, Dun Morogh" end
	if Q[96391] then Q[96391].objective = "Dark Iron Map'ı Dun Morogh'daki Toprak Kâhini Farsen'e teslim et." end
	if Q[96391] then Q[96391].description = "Dark Iron Map bu görevi başlatır ve doğrudan Old Ironforge Incursion görevine götürür." end
	if Q[962] then Q[962].objective = "Thunder Bluff'taki Simyacı Zamah 10 Serpentbloom toplamanı istiyor." end
	if Q[7631] then Q[7631].note = "Warlock dreadsteed görevi. Immol'thar öldükten sonra J'eevee's Jar, Black Lodestone ve Xorothian Glyphs ile onun hapishanesinde ritüeli yap. Ruh Kırıkları getir." end
	if Q[7631] then Q[7631].objective = "Mor'zul's Instructions'u oku. Bir Xoroth Dreadsteed'i çağır, onu yen ve ruhunu kendine bağla." end
	if Q[95126] then Q[95126].objective = "Ott's Masterwork'u Silverpine Forest'taki Trevan Rol'e götür." end
	if Q[95786] then Q[95786].objective = "Savage Coast Report Bundle'u (fetişler, trol efsaneleri ve keşif raporu) Southshore'daki Loremaster Dibbs'e götür." end
	if Q[4743] then Q[4743].note = "Dövülmemiş Mühür'ü ve Ejderha Energy'si Orb'u Dustwallow Marsh'taki Wyrmbog'da Emberstrife'a götür. Dövülmüş mühür UBRS kapısını açar." end
	if Q[4743] then Q[4743].objective = "Dustwallow Marsh'taki Wyrmbog'a git. Kadim ejder Emberstrife'ı bul ve iradesi kırılana dek onu acımadan döv.$B$BTam o anda Unforged Seal of Ascension'u o büyük yaratığın önüne koymalısın. Ardından hızla Ejderha Energy'si Orb'u zayıf düşmüş bedeni üzerinde kullanmalı ve zihnine hükmetmelisin. Yaratığı kontrol et ve Kara Ejderha Soyu'nun Flames'i Unforged Seal of Ascension'a püskürtmeye zorla!" end
	if Q[95748] then Q[95748].objective = "Postu ve kömürü kullanarak The Third Troll Legend tabletinin bir kopyasını çıkar." end
	if Q[7627] then Q[7627].objective = "6 Büyük Parlak Kırık ve 25 Dark Iron Ore'u Burning Steppes'teki Gorzeeki'ye getir." end
	if Q[95189] then Q[95189].objective = "Crest of Lordaeron'u Stormwind City'deki Leydi Dena Kennedy'ye geri götür." end
	if Q[92749] then Q[92749].objective = "Üreterek, takas ederek ya da müzayede salonundan 10 Coarse Dynamite edin, ardından Stormwind'in Dwarven District'indeki Sprite Jumpsprocket'a dön." end
	if Q[92749] then Q[92749].note = "Coarse Dynamite üretilebilir, takas edilebilir ya da müzayede evinden alınabilir." end
	if Q[92749] then Q[92749].description = "Coarse Dynamite üretilebilir, takas edilebilir ya da müzayede evinden alınabilir." end
	if Q[92458] then Q[92458].objective = "City of Dalaran yakınlarındaki Archmage Modera'nın Sureti için Arcane Mote'u topla." end
	if Q[7484] then Q[7484].objective = "Odak Mührü almak için bir Odak Duaları Kitabı, 1 Kusursuz Siyah Elmas, 4 Büyük Parlak Kristal ve 2 Skin of Shadow'u Dire Maul'daki Lorekeeper Lydros'a getir." end
	if Q[5462] then Q[5462].objective = "Eastern Plaguelands'teki Light's Hope'a git ve Saygıdeğer Leonid Barthalomew'i bul. Ona Keepsake of Remembrance'ı göster ve keşfettiğin her şeyi anlat." end
	if Q[5466] then Q[5466].objective = "Scholomance'ta Ras Frostwhisper'ı bul. Onu bulduğunda, Soulbound Keepsake'ı ölümsüz suretine karşı kullan. Onu ölümlüye dönüştürmeyi başarırsan, yere ser ve Ras Frostwhisper'ın İnsan Başı'nı al. Magistrate Marduke'a götür." end
	if Q[880] then Q[880].objective = "Crossroads'taki Tonga Runetotem'e 8 Altered Snapjaw Shell getir." end
	if Q[865] then Q[865].objective = "Sunscale Scytheclaw'lardan 5 Intact Raptor Horn topla ve Ratchet'teki Mebok Mizzyrix'e getir." end
	if Q[2930005] then Q[2930005].objective = "Prismatic Punch Card almak için Red Punch Card ile Matrix Punchograph 3005-D'yi kullan, sonra onu Ironforge'daki Master Mechanic Castpipe'a götür." end
	if Q[8421] then Q[8421].objective = "10 Rotting Wood ve 4 Bloodvenom Özütü'nü Felwood'daki Impsy'ye getir." end
	if Q[6521] then Q[6521].objective = "Ambassador Malcin's Head'ı Undercity'deki Varimathras'a getir." end
	if Q[8417] then Q[8417].objective = "Blasted Lands'in girişindeki Horde'un Fallen Hero'u ile konuş." end
	if Q[8256] then Q[8256].objective = "Azshara'daki Ogtinc için bir Ichor of Undeath edin. Ogtinc, Ruins of Eldarath'ın kuzeydoğusundaki uçurumların tepesinde yaşar." end
	if Q[7563] then Q[7563].objective = "30 şişe Raging Beast's Blood'u Burning Steppes'teki Mor'zul Bloodbringer'a getir." end
	if Q[5518] then Q[5518].note = "4 Runecloth Topu, 8 Rugged Leather, 2 Rün İpliği ve 1 Ogre Tanen'i (Knot'un ötesinde üst kattaki sepet) getir. Knot'u serbest bırakmadan önce istediğin takımları yap ve deseni öğren, çünkü gidiyor." end
	if Q[5518] then Q[5518].objective = "4 Top Runecloth, 8 Sert Deri, 2 Rün İpliği ve Ogre Tanen Özü'nü Knot Thimblejack'e getir. Kendisi şu anda Dire Maul'un Gordok kanadında zincirli durumda." end
	if Q[5522] then Q[5522].objective = "Frozen Eggs'i Eastern Plaguelands'teki Leonid Barthalomew'e götür." end
	if Q[5526] then Q[5526].objective = "Dire Maul'da Felvine'ı bul ve ondan bir parça elde et. Büyük ihtimalle bir parçayı ancak Vahşibiçimci Alzzin'in ölümüyle elde edebileceksin. Parçayı güvenle içine mühürlemek için Purity Mahfazası'nı kullan ve onu Moonglade, Nighthaven'daki Rabine Saturna'ya götür." end
	if Q[3802] then Q[3802].note = "Ölüyken Franclorn'un hayaletiyle konuş. Ironfel için Fineous Darkvire'ı öldür ve onu Ring of Law yanındaki Franclorn anıtına yerleştir. Shadowforge Key BRD içindeki kısayolları açar." end
	if Q[7604] then Q[7604].pickup = "Thorium Brotherhood Contract (bir Sulfuron Ingot karşılığında Lokhtos Darkbargainer'dan)" end
	if Q[7604] then Q[7604].note = "Demircilik. Sözleşmeyi almak için Grim Guzzler'daki Lokhtos'a bir Sulfuron Ingot (Golemagg, Molten Core) getir, sonra Sulfuron Hammer planları için geri teslim et." end
	if Q[7604] then Q[7604].objective = "Sulfuron planlarını almak istiyorsan Thorium Brotherhood Contract'ı Lokhtos Darkbargainer'a teslim et." end
	if Q[96984] then Q[96984].objective = "Tarren Mill'deki Magus Wordeen Voidglare için City of Dalaran'da Arcane Mote'u topla." end
	if Q[8234] then Q[8234].objective = "Mühürlü Mavi Kese'yi Azshara'daki Timbermaw Shaman'dan geri al. Sonra keseyi yine Azshara'da bulunan Başbüyücü Xylem'e götür." end
	if Q[7628] then Q[7628].objective = "35 Black Dragonscale'ı Burning Steppes'teki Gorzeeki Wildeyes'a getir." end
	if Q[7624] then Q[7624].objective = "Ulathek ile yüzleş, ardından The Traitor's Heart'ı Jaedenar'daki Lord Banehollow'a getir." end
	if Q[6922] then Q[6922].pickup = "Garip Water Globe, Blackfathom Deeps içinde Baron Aquanis düşürür" end
	if Q[6922] then Q[6922].objective = "Strange Water Globe'u Ashenvale'de Zoram'gar Outpost'taki Je'neu Sancrea'ya getir." end
	if Q[7640] then Q[7640].objective = "Exorcism Censer'i kullanarak Terrordale'e eziyet eden ruhları kov. 25 Terrordale Spirit'i öldürdüğünde Stormwind'in Cathedral District'indeki Lord Grayson Shadowbreaker'a dön." end
	if Q[7644] then Q[7644].objective = "Blessed Arcanite Barding ile Stormwind'in Cathedral District'indeki Lord Grayson Shadowbreaker'a dön." end
	if Q[7648] then Q[7648].objective = "Arcanite Barding'i incelemesi için Stormwind'in Cathedral District'indeki Lord Grayson Shadowbreaker'a götür." end
	if Q[7668] then Q[7668].objective = "Scholomance'taki Great Ossuary'nin bodrumunun tam ortasında Kehanet Aleti'ni kullan. Bu, savaşman gereken ruhları ortaya çıkaracak. Bu ruhları yenmek Death Knight Darkreaver'i çağıracak; onu yen.$B$BDarkreaver'ın Kellesi'ni Orgrimmar'daki Valley of Wisdom'da Sagorne Creststrider'a götür." end
	if Q[7637] then Q[7637].objective = "Ironforge'a git ve Yüksek Rahip Rohan's Exorcism Censer'i al. Onu edinmek için 150 altın bağış yapman gerekecek." end
	if Q[7623] then Q[7623].objective = "Burning Steppes'teki Gorzeeki'den Shadowy Potion satın al.$B$BBu iksirleri kullanarak Jaedenar'dan geç ve Lord Banehollow ile konuş." end
	if Q[7507] then Q[7507].objective = "Foror'un Dragon Avcılığı Derlemesi'ni Athenaeum'a geri götür." end
	if Q[2841] then Q[2841].objective = "Araç Planları'nı ve Thermaplugg's Safe Combination'u Gnomeregan'dan alıp Orgrimmar'daki Nogg'a götür.$B" end
	if Q[7485] then Q[7485].objective = "Koruma Mührü almak için bir Koruma Duaları Kitabı, 1 Kusursuz Siyah Elmas, 2 Büyük Parlak Kristal ve 1 Frayed Abomination Stitching'i Dire Maul'daki Lorekeeper Lydros'a getir." end
	if Q[7463] then Q[7463].note = "Mage sınıf görevi. Lydros, Athenaeum'da (Kuzey/West); Hydrospawn Essence, East'takı Hydrospawn'dan düşer. Ödül: Conjure Water (Rütbe 7)." end
	if Q[7463] then Q[7463].objective = "Dire Maul'un Warpwood Quarter bölgesine git ve su elementali Hydrospawn'ı öldür. Hydrospawn Essence ile Athenaeum'daki Lorekeeper Lydros'a dön." end
	if Q[96986] then Q[96986].objective = "Tarren Mill'deki Melisara için City of Dalaran'da Mezar Knight'si Atrexis'i yen." end
	if Q[971] then Q[971].note = "Lorgalis Manuscript, Ghamoo-ra'nın kaplumbağa odasını hemen geçince kuzey girintide, Pool of Ask'ar'da su altındaki bir Oyuk Demir Sandık'ın içinde." end
	if Q[722] then Q[722].objective = "Hammertoe's Amulet'i bul ve Uldaman'da ona geri götür." end
	if Q[7201] then Q[7201].note = "Essence of the Elements, BRD elementallerinden ve golemlerinden düşer." end
	if Q[7201] then Q[7201].objective = "Blackrock Depths'e git ve 10 Essence of the Elements topla. İlk aklına gelen golemleri ve golem yapımcılarını aramak. Vivian Lagrave'in de elementallerle ilgili bir şeyler mırıldandığını hatırlıyorsun.$B" end
	if Q[7065] then Q[7065].objective = "Princess Theradras'ı öldür ve Desolace'taki Nijel's Point'te bulunan Keeper Marandis'e dön." end
	if Q[8423] then Q[8423].objective = "Blasted Lands'te 7 Helboar öldür ve Horde'un Fallen Hero'ya dön." end
	if Q[4735] then Q[4735].objective = "8 Toplanmış Dragon Yumurtası'nı ve Collectronic Module'u Burning Steppes'teki Flame Crest'te bulunan Tinkee Steamboil'e götür." end
	if Q[1956] then Q[1956].objective = "Bir Obsidian Power Source elde et ve onu Dustwallow Marsh'taki Tabetha'ya götür." end
	if Q[7028] then Q[7028].note = "Maraudon'daki her yaratık Theradric Crystal Oymalarını düşürebilir." end
	if Q[7028] then Q[7028].objective = "Desolace'taki Willow için 15 Theradric Crystal Oyması topla." end
	if Q[4146] then Q[4146].note = "Atal'ai Haze, tapınağın solucanlarından, pusucularından ve balçıklarından düşer." end
	if Q[6921] then Q[6921].objective = "Fathom Core'u Ashenvale'deki Zoram'gar Üssü'nde bulunan Je'neu Sancrea'ya götür." end
	if Q[7848] then Q[7848].note = "Core Fragment, BRD'nin derinlerinde Molten Core portalının yanındaki kayanın üzerinde. Lothos'un Molten Core'a ışınlamasını açar." end
	if Q[7848] then Q[7848].objective = "Blackrock Depths'teki Molten Core giriş geçidine git ve bir Core Fragment al. Core Fragment'i aldığında Blackrock Mountain'daki Lothos Riftwaker'a dön." end
	if Q[4787] then Q[4787].objective = "Ancient Egg'i Tanaris'teki Yeh'kinya'ya getir." end
	if Q[6565] then Q[6565].note = "Allegiance to the Old Gods görevinin Damp Note sürümünden sonra gelir." end
	if Q[96988] then Q[96988].objective = "Undercity'deki Doktor Martin Felben için City of Dalaran'da 6 Çatlak Sentry Çekirdeği topla." end
	if Q[2930004] then Q[2930004].objective = "Red Punch Card almak için Blue Punch Card ile Matrix Punchograph 3005-C'yi kullan." end
	if Q[2930004] then Q[2930004].turnin = "Bir Red Punch Card alırsın" end
	if Q[5726] then Q[5726].objective = "Orgrimmar'daki Thrall'a bir Lieutenant's Insignia getir." end
	if Q[5724] then Q[5724].pickup = "Grimtotem Satchel, Ragefire Chasm içindeki Maur Grimtotem'in cesedinden alınır" end
	if Q[5515] then Q[5515].objective = "Scholomance'ta Jandice Barov'u bul ve yok et. Cesedinden Krastinov's Bag of Horrors'u al. Çantayı Eva Sarkhoff'a götür." end
	if Q[2933] then Q[2933].objective = "Bir Venom Bottle'u Tarren Mill'deki bir eczacıya götür." end
	if Q[5384] then Q[5384].note = "Blood of Innocents'i Scholomance verandasındaki mangalda kullan. Ödül: Spectral Essence." end
	if Q[5384] then Q[5384].objective = "Blood of Innocents ile Scholomance'a dön. Sundurmayı bul ve Blood of Innocents'i mangala koy. Kirtonos ruhunla ziyafet çekmeye gelecek.$B$BYiğitçe savaş, bir adım bile geri atma! Kirtonos'u yok et ve Eva Sarkhoff'a dön.$B" end
	if Q[5343] then Q[5343].objective = "Scholomance'a git ve Barov ailesinin servetini geri getir. Bu servet dört tapudan oluşuyor: The Deed to Caer Darrow, The Deed to Brill, The Deed to Tarren Mill ve The Deed to Southshore. Bu görevi tamamladığında Weldon Barov'a dön." end
	if Q[5247] then Q[5247].objective = "Eastern Plaguelands'te Northpass Tower yakınındaki Aurora Skycaller'a bir Enchanted Thorium Bar'sı, 5 Crystal Restore ve bir Şişe Uğursuz Su getir." end
	if Q[5089] then Q[5089].objective = "General Drakkisath's Command'ı Burning Steppes'teki Marshal Maxwell'e götür." end
	if Q[3982] then Q[3982].note = "High Interrogator Gerstahn'dan alınan Prison Cell Anahtarı ile hücresini aç, sonra onu savun." end
	if Q[4867] then Q[4867].note = "Dalgaları başlatmak için Highlord Omokk's Head'ı ve bir Roughshod Pike'i örümceklerin ötesindeki Urok's Tribute Pile'a getir." end
	if Q[4867] then Q[4867].objective = "Warosh'un Parşömeni'ni oku. Warosh's Mojo'yu Warosh'a getir." end
	if Q[4903] then Q[4903].note = "Command eşyasını almak için Goretooth ile konuş ve görevi başlatmak için ona tıkla. Important Blackrock Documents üç generalin yakınında çıkar." end
	if Q[4903] then Q[4903].objective = "Highlord Omokk'u, War Master Voone'u ve Overlord Wyrmthalak'ı öldür. Important Blackrock Documents'i ele geçir. Görev tamamlandığında Kargath'taki Savaş Beyi Goretooth'a dön." end
	if Q[4003] then Q[4003].objective = "Emperor Dagran Thaurissan'ı öldür ve Princess Moira Bronzebeard'ü onun kötü büyüsünden kurtar.$B" end
	if Q[2991] then Q[2991].objective = "Nekrum's Medallion'u Blasted Lands'teki Thadius Grimshade'e getir." end
	if Q[7029] then Q[7029].objective = "Coated Cerulean Vial'ı Maraudon'daki turuncu kristal havuzda doldur.$B$BDolu Gök Mavisi Şişe'yi Vylestem Sarmaşıkları üzerinde kullanarak yozlaşmış Noxxious Filizi'nin ortaya çıkmasını sağla.$B$BBu Noxxious Filizleri'ni öldürerek 8 bitkiyi iyileştir, ardından Shadowprey Village'daki Vark Battlescar'a dön." end
	if Q[2948] then Q[2948].objective = "Brilliant Gold Ring'i, bir Silver Bar'ı, bir Yosun Akik'i ve 30 gümüş sikkeyi Ironforge'daki Talvash del Kissel'e getir." end
	if Q[7041] then Q[7041].objective = "Coated Cerulean Vial'ı Maraudon'daki turuncu kristal havuzda doldur.$B$BDolu Gök Mavisi Şişe'yi Vylestem Sarmaşıkları üzerinde kullanarak yozlaşmış Noxxious Filizi'nin ortaya çıkmasını sağla.$B$BBu Noxxious Filizleri'ni öldürerek 8 bitkiyi iyileştir, ardından Nijel's Point'teki Talendria'ya dön." end
	if Q[6022] then Q[6022].objective = "Doğudaki Corin's Crossing'e git ve kasabada yaşayan Scourge'u katlet. 10 dakikadan kısa sürede 7 parça Living Rot topla. Canlı Çürüğü Pıhtılaşmış Çürüğe öğütmek için Havan ve Tokmak'ı kullan." end
	if Q[2930003] then Q[2930003].objective = "Blue Punch Card almak için Yellow Punch Card ile Matrix Punchograph 3005-B'yi kullan." end
	if Q[2930003] then Q[2930003].turnin = "Bir Blue Punch Card alırsın" end
	if Q[2930001] then Q[2930001].objective = "White Punch Card düşene kadar dış Gnomeregan bölgesindeki yaratıkları öldür." end
	if Q[2846] then Q[2846].objective = "Tiara of the Deep'i Dustwallow Marsh'taki Tabetha'ya getir." end
	if Q[2198] then Q[2198].pickup = "Shattered Necklace (Uldaman'da düşer)" end
	if Q[2198] then Q[2198].objective = "Shattered Necklace'ın olası değerini öğrenmek için asıl yapımcısını ara." end
	if Q[153] then Q[153].objective = "15 Red Leather Bandana'yı Sentinel Hill'deki Scout Galiaan'a getir." end
	if Q[132] then Q[132].objective = "Wiley's Note'u Westfall'daki Gryan Stoutmantle'a götür." end
	if Q[4082] then Q[4082].objective = "Blackrock Depths'e git ve alçak saldırganları yok et!$B$BWarlord Goretooth, 10 Anvilrage Hekimi, 10 Anvilrage Askeri ve 10 Anvilrage Subayı öldürmeni istiyor. Görev tamamlanınca ona dön." end
	if Q[4132] then Q[4132].objective = "Blackrock Depths'e git ve General Angerforge'u öldür! Görev tamamlanınca Warlord Goretooth'a dön." end
	if Q[1048] then Q[1048].objective = "High Inquisitor Whitemane'i, Scarlet Commander Mograine'i, Herod, the Scarlet Champion'u ve Houndmaster Loksey'i öldür, ardından Undercity'deki Varimathras'a rapor ver." end
	if Q[1053] then Q[1053].objective = "High Inquisitor Whitemane'i, Scarlet Commander Mograine'i, Herod, the Scarlet Champion'u ve Houndmaster Loksey'i öldür, ardından Southshore'daki Dindar Raleigh'e rapor ver." end
	if Q[5251] then Q[5251].objective = "Stratholme'e git ve Scarlet Crusade'den Archivist Galford'u bul. Onu yok et ve Scarlet Arşivi'ni yakıp kül et." end
	if Q[5263] then Q[5263].objective = "Stratholme'e git ve Baron Rivendare'i yok et. Kafasını al ve Duke Nicholas Zverenhoff'a dön.$B" end
	if Q[1098] then Q[1098].objective = "Deathstalker Adamant ile Deathstalker Vincent'ı bul." end
	if Q[7481] then Q[7481].objective = "Dire Maul'da Kariel Winthalus'u ara. Bulabildiğin her bilgiyle Camp Mojache'deki Sage Korolusk'a rapor ver." end
	if Q[1113] then Q[1113].objective = "Undercity'deki Master Apothecary Faranell 20 Bağnazlık Yüreği istiyor." end
	if Q[2240] then Q[2240].objective = "Baelog'un Günlüğü'nü oku, gizli odayı keşfet, sonra Prospector Stormpike'a rapor ver." end
	if Q[1200] then Q[1200].objective = "Twilight Lord Kelris'in başını Darnassus'taki Şafak Gözcüsü Selgorm'a götür." end
	if Q[7070] then Q[7070].objective = "Maraudon'dan 10 Gölge Kırığı Parçası topla ve Dustwallow Marsh kıyısındaki Theramore'da bulunan Archmage Tervosh'a götür." end
	if Q[8250] then Q[8250].objective = "Sanath Lim-yo'yu bul ve Archmage Xylem'i görmek için geçiş izni al." end
	if Q[4133] then Q[4133].objective = "Kargath'taki Shadowmage Vivian Lagrave ile konuş." end
	if Q[167] then Q[167].objective = "Foreman Thistlenettle'ın Explorers' League Rozeti'ni Stormwind'deki Wilder Thistlenettle'a getir." end
	if Q[704] then Q[704].objective = "Loch Modan'daki Prospector Ironband'e 4 Oyma Taş Kavanoz getir." end
	if Q[2922] then Q[2922].objective = "Techbot'un Hafıza Çekirdeği'ni Ironforge'daki Tinkmaster Overspark'a götür." end
	if Q[377] then Q[377].objective = "Darkshire'dan Councilman Millstipe, Dextren Ward'ın elini kendisine getirmeni istiyor." end
	if Q[4063] then Q[4063].objective = "Golem Lord Argelmach'ı bul ve öldür. Kafasını Lotwil'e getir. Ayrıca Argelmach'ı koruyan Ragereaver Golemleri ile Warbringer Yapılarından 10 Sağlam Element Çekirdeği toplaman gerekecek. Bunu biliyorsun, çünkü medyumsun." end
	if Q[5081] then Q[5081].objective = "Blackrock Spire'a git ve War Master Voone'u, Highlord Omokk'u ve Overlord Wyrmthalak'ı yok et. İş bittiğinde Marshal Maxwell'e dön." end
	if Q[4081] then Q[4081].objective = "Blackrock Depths'e git ve alçak saldırganları yok et!$B$BWarlord Goretooth senden 15 Anvilrage Muhafızı, 10 Anvilrage Gardiyanı ve 5 Anvilrage Piyadesi öldürmeni istiyor. Görevin bittiğinde ona geri dön.$B$B" end
	if Q[4322] then Q[4322].objective = "Marshal Windsor'ın teçhizatını geri almasına ve dostlarını serbest bırakmasına yardım et. Marshal Maxwell'e dön." end
	if Q[7703] then Q[7703].objective = "Gordok Kudreti Demir Eldiveni'ni bul ve Dire Maul'daki Captain Kromcrush'a geri getir.$B$BKromcrush'a göre \"eski zaman hikâyesi\", kendine prens diyen \"ürkütücü\" bir elf olan Tortheldrin'in onu Gordok krallarından birinden çaldığını söylüyor." end
	if Q[8253] then Q[8253].objective = "Morphaz'dan Gizemli Kristal Parçası'nı al ve Archmage Xylem'e dön." end
	if Q[4974] then Q[4974].objective = "Blackrock Spire'a git ve Warchief Rend Blackhand'i öldür. Kellesini al ve Orgrimmar'a dön." end
	if Q[5102] then Q[5102].objective = "Blackrock Spire'a git ve General Drakkisath'ı yok et. İş bittiğinde Marshal Maxwell'e dön.$B" end
	if Q[92457] then Q[92457].objective = "Dalaran'ın dışındaki Archmage Modera için City of Dalaran'ın içinde 8 Seeking Remnant, 8 Saturated Remnant ve 8 Mana Echo yen." end
	if Q[7046] then Q[7046].objective = "Assist Celebras, Celebras Asası'nı yaratırken ona yardım et.$B$BRitüel tamamlandığında onunla konuş." end
	if Q[6561] then Q[6561].objective = "Twilight Lord Kelris'in başını Thunder Bluff'taki Bashana Runetotem'e götür." end
	if Q[8415] then Q[8415].objective = "Chillwind Camp'teki Commander Ashlam Valorfist ile konuş." end
	if Q[2929] then Q[2929].objective = "Gnomeregan'a git ve Mekgineer Thermaplugg'ı öldür. Görev tamamlanınca High Tinker Mekkatorque'a dön." end
	if Q[4769] then Q[4769].objective = "Shadowmage Vivian Lagrave ile konuş." end
	if Q[2936] then Q[2936].objective = "Witherbark örümcek tanrısının adını öğrenmek için Theka'nın Tableti'ni oku, ardından Master Gadrin'e dön." end
	if Q[1013] then Q[1013].objective = "Ur'un Kitabı'nı Undercity'deki Apothecarium'da bulunan Keeper Bel'dugur'a getir." end
end
