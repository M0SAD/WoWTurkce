-- Yasaklı (forbidden) çerçeveler: Topluluk Ekle/Oluştur iletişim kutusu gibi pencerelere addon dokunamaz.
-- Bu pencereler metni oyunun global metin değişkenlerinden okuduğu için, değişkenleri doğrudan Türkçeleştiriyoruz.
local T = {
	COMMUNITIES_ADD_DIALOG_BATTLE_NET_LABEL = "Battle.net Grubu Oluştur",
	COMMUNITIES_ADD_DIALOG_CREATE_BNET_DESCRIPTION = "- Oyunlar arası arkadaşlar için ideal|n- Herhangi bir oyuncuyu davet et (üyeler BattleTag'leriyle katılır)",
	COMMUNITIES_ADD_DIALOG_CREATE_BNET_LABEL = "Battle.net Grubu Oluştur",
	COMMUNITIES_ADD_DIALOG_CREATE_WOW_DESCRIPTION = "- Oyun içi arkadaşlar için ideal|n- Herhangi bir realm'den karakterleri davet et|n- Takvim ve Hızlı Katılım desteği",
	COMMUNITIES_ADD_DIALOG_CREATE_WOW_DESCRIPTION_NO_FACTION = "- Oyun içi arkadaşlar için ideal|n- Herhangi bir realm'den karakterleri davet et|n- Takvim ve Hızlı Katılım desteği",
	COMMUNITIES_ADD_DIALOG_CREATE_WOW_LABEL = "World of Warcraft Topluluğu Oluştur (%s veya Hizipler Arası)",
	COMMUNITIES_ADD_DIALOG_CREATE_WOW_LABEL_NO_FACTION = "World of Warcraft Topluluğu Oluştur",
	COMMUNITIES_ADD_DIALOG_INVITE_LINK_DESCRIPTION = "Bir topluluğun davet bağlantısını veya kodunu gir:",
	COMMUNITIES_ADD_DIALOG_INVITE_LINK_JOIN = "Katıl",
	COMMUNITIES_ADD_DIALOG_INVITE_LINK_LABEL = "Topluluğa Katıl",
	COMMUNITIES_ADD_DIALOG_LABEL = "Topluluk Ekle",
	COMMUNITIES_ADD_DIALOG_WOW_LABEL = "%s Topluluğu Oluştur",
	COMMUNITIES_CREATE_COMMUNITY = "Topluluk Oluştur",
	COMMUNITIES_CREATE_GROUP = "Grup Oluştur",
	COMMUNITIES_CREATE_DIALOG_AVATAR_PICKER_INSTRUCTIONS = "Bir Simge Seç",
	COMMUNITIES_CREATE_DIALOG_BATTLE_NET_LABEL = "Battle.net Grubu Oluştur",
	COMMUNITIES_CREATE_DIALOG_DESCRIPTION_INSTRUCTIONS = "Topluluğunun isteğe bağlı açıklaması",
	COMMUNITIES_CREATE_DIALOG_DESCRIPTION_INSTRUCTIONS_BATTLE_NET = "Grubunun isteğe bağlı açıklaması",
	COMMUNITIES_CREATE_DIALOG_DESCRIPTION_LABEL = "Topluluk Açıklaması",
	COMMUNITIES_CREATE_DIALOG_DESCRIPTION_LABEL_BATTLE_NET = "Grup Açıklaması",
	COMMUNITIES_CREATE_DIALOG_ICON_LABEL = "Topluluk Simge Numarası",
	COMMUNITIES_CREATE_DIALOG_ICON_SELECTION_BUTTON = "Değiştir",
	COMMUNITIES_CREATE_DIALOG_NAME_AND_SHORT_NAME_ERROR = "Ad|n%s|n|nKısa Ad|n%s",
	COMMUNITIES_CREATE_DIALOG_NAME_ERROR = "Ad|n%s",
	COMMUNITIES_CREATE_DIALOG_NAME_INSTRUCTIONS = "Topluluğunun adı",
	COMMUNITIES_CREATE_DIALOG_NAME_INSTRUCTIONS_BATTLE_NET = "Grubunun adı",
	COMMUNITIES_CREATE_DIALOG_NAME_LABEL = "Topluluk Adı",
	COMMUNITIES_CREATE_DIALOG_NAME_LABEL_BATTLE_NET = "Grup Adı",
	COMMUNITIES_CREATE_DIALOG_SHORT_NAME_ERROR = "Kısa Ad|n%s",
	COMMUNITIES_CREATE_DIALOG_SHORT_NAME_INSTRUCTIONS = "Grup adının kısa hali",
	COMMUNITIES_CREATE_DIALOG_SHORT_NAME_INSTRUCTIONS_CHARACTER = "Topluluk adının kısa hali",
	COMMUNITIES_CREATE_DIALOG_SHORT_NAME_INSTRUCTIONS_TOOLTIP = "Sohbet pencerelerinde kanal adlarının kısa kalması için kullanılır.",
	COMMUNITIES_CREATE_DIALOG_SHORT_NAME_LABEL = "Kısa Ad",
	COMMUNITIES_CREATE_DIALOG_TYPE_LABEL = "Karakter Topluluğu",
	COMMUNITIES_CREATE_DIALOG_WOW_LABEL = "World of Warcraft Topluluğu Oluştur",
	COMMUNITIES_JOIN_COMMUNITY = "Topluluğa Katıl veya Oluştur",
	COMMUNITIES_INVITE_MANAGER_LABEL = "%s Topluluğuna Davet",
	COMMUNITIES_INVITE_MANAGER_COPY = "Bağlantıyı Kopyala",
	COMMUNITIES_INVITE_MANAGER_COPY_LINK_BUTTON = "Bağlantıyı Kopyala",
	COMMUNITIES_INVITE_MANAGER_CREATE_NEW_LINK = "Yeni Bağlantı Oluştur",
	COMMUNITIES_INVITE_MANAGER_GENERATE = "Yeni Bağlantı Üret",
	COMMUNITIES_INVITE_MANAGER_LINK_TO_CHAT = "Sohbete Bağla",
	COMMUNITIES_INVITE_MEMBERS = "Üye Davet Et",
}
for k, v in pairs(T) do
	if type(_G[k]) == "string" then
		v = v:gsub("|n", "\n")
		-- orijinalde |n gerçek satır sonu değilse (kaçış dizisi) olduğu gibi bırak
		if not _G[k]:find("\n") and _G[k]:find("|n", 1, true) then v = v:gsub("\n", "|n") end
		_G[k] = v
	end
end
