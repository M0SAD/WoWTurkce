if not WoWTurkce.RETAIL then return end -- yalnızca Retail
-- Görev ipucu etiketleri (Campaign, Dungeon...) ve genel görev kelimeleri
local A = WoWTurkce.Arayuz
local function o(en, tr) if A[en] == nil then A[en] = tr end end
A["Campaign"] = "Kampanya"; A["Dungeon"] = "Zindan"; A["Raid"] = "Baskın" o("Dungeon", "Zindan"); o("Raid", "Baskın"); o("Group", "Grup")
o("Legendary", "Efsanevi"); o("Heroic", "Kahramanlık"); o("Mythic", "Mitik"); o("Scenario", "Senaryo")
o("Account", "Hesap"); o("Threat", "Tehdit"); o("Calling", "Çağrı"); o("Meta", "Meta")
o("Weekly", "Haftalık"); o("Daily", "Günlük"); o("World Quest", "Dünya Görevi")
o("Emissary", "Elçi"); o("Pet Battle", "Evcil Hayvan Savaşı"); o("Profession", "Meslek")
o("Invasion", "İstila"); o("Elite", "Elit"); o("Rare", "Nadir"); o("Bonus Objective", "Bonus Hedef")
o("Artifact", "Eser"); o("Island Quest", "Ada Görevi"); o("Warfront", "Savaş Cephesi")
o("Faction Assault", "Hizip Saldırısı"); o("Dragonriding Race", "Ejderha Sürüşü Yarışı")
o("Racing", "Yarış"); o("Epic", "Epik"); o("Escort", "Refakat"); o("Important", "Önemli")
o("Ready for Turn-in", "Teslime hazır"); o("Complete", "Tamamlandı"); o("Failed", "Başarısız")
o("Warband Transferable", "Savaş Grubuna Aktarılabilir"); o("Warbound", "Savaş Grubuna Bağlı")
o("Warbound until equipped", "Kuşanılana kadar Savaş Grubuna Bağlı"); o("Warband Bound", "Savaş Grubuna Bağlı")
o("Account Bound", "Hesaba Bağlı"); o("Binds to Blizzard account", "Blizzard hesabına bağlanır")
o("Binds to Warband", "Savaş Grubuna bağlanır"); o("Binds to Warband until equipped", "Kuşanılana kadar Savaş Grubuna bağlanır")
