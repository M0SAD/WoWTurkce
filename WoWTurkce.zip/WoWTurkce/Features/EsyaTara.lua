-- /wowturkce esyatara [hepsi]: (hepsi = silah/zırh dahil tüm eşyalar)
-- /wowturkce esyatara: oyundaki tüketilebilir eşyaları, malzemeleri ve tarifleri tek tek açıp
-- (görünmez ipucuyla) çevirisi olmayan satırları kayda alır. Sonra /reload ve "eksikleri çevir".
local G = WoWTurkce
local calisiyor = false
local SINIFLAR = { [0] = true, [7] = true, [9] = true } -- Tüketilebilir, Üretim malzemesi, Tarif

function G.esyaTaraBaslat(hepsi)
	if calisiyor then G.yaz("Eşya taraması zaten çalışıyor."); return end
	if not (C_Item and C_Item.GetItemInfoInstant and GameTooltip) then G.yaz("Bu istemcide eşya taraması desteklenmiyor."); return end
	calisiyor = true
	local ENFAZLA = G.RETAIL and 300000 or 70000
	local kuyruk, sonId = {}, 0
	local taranan, toplam = 0, 0
	local asama = "liste"
	local grup, bekle = nil, 0
	local f = CreateFrame("Frame")
	G.yaz("Eşya taraması başladı; birkaç dakika sürer. Bitince haber vereceğim (savaşta duraklar).")
	local eskiAlfa = GameTooltip:GetAlpha()
	local function bitir()
		f:SetScript("OnUpdate", nil)
		GameTooltip:SetAlpha(eskiAlfa or 1); GameTooltip:Hide()
		calisiyor = false
		G.yaz(("Eşya taraması bitti: %d eşya açıldı. Şimdi /reload yaz, sonra bana \"eksikleri çevir\" de."):format(taranan))
	end
	f:SetScript("OnUpdate", function(_, gecen)
		if InCombatLockdown and InCombatLockdown() then return end
		if asama == "liste" then
			-- Kimlik aralığını parça parça tara, uygun sınıftakileri sıraya al
			for _ = 1, 4000 do
				sonId = sonId + 1
				if sonId > ENFAZLA then asama = "yukle"; toplam = #kuyruk; break end
				local ok, _, _, _, _, _, sinif = pcall(C_Item.GetItemInfoInstant, sonId)
				if ok and sinif ~= nil and (hepsi or SINIFLAR[sinif]) then kuyruk[#kuyruk + 1] = sonId end
			end
			return
		end
		bekle = bekle + gecen
		if asama == "yukle" then
			if #kuyruk == 0 then bitir(); return end
			grup = {}
			for _ = 1, 40 do
				local id = table.remove(kuyruk)
				if not id then break end
				grup[#grup + 1] = id
				if C_Item.RequestLoadItemDataByID then C_Item.RequestLoadItemDataByID(id) end
			end
			bekle = 0; asama = "oku"
		elseif asama == "oku" and bekle > 0.4 then
			GameTooltip:SetAlpha(0)
			for _, id in ipairs(grup) do
				GameTooltip:SetOwner(UIParent, "ANCHOR_NONE")
				pcall(GameTooltip.SetItemByID, GameTooltip, id)
				if GameTooltip.Show then GameTooltip:Show() end
				taranan = taranan + 1
			end
			GameTooltip:Hide(); GameTooltip:SetAlpha(eskiAlfa or 1)
			if taranan % 2000 < 40 then G.yaz(("Eşya taraması: %d / %d"):format(taranan, toplam)) end
			asama = "yukle"
		end
	end)
end
