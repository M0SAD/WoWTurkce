local mod	= DBM:NewMod(2498, "DBM-Party-Dragonflight", 3, 1198)
local L		= mod:GetLocalizedStrings()

mod:SetRevision("20260523021914")
mod:DisableHardcodedOptions()
mod:SetCreatureID(186616)
mod:SetEncounterID(2637)
mod:SetUsedIcons(8)
mod:SetHotfixNoticeRev(20221029000000)
--mod:SetMinSyncRevision(20211203000000)
--mod.respawnTime = 29
mod.sendMainBossGUID = true

mod:RegisterCombat("combat")

mod:RegisterEventsInCombat(
	"SPELL_CAST_START 388283 388817 385916 386921",
	"SPELL_SUMMON 386747 386748 386320",
	"SPELL_AURA_APPLIED 387155",
	"SPELL_AURA_REMOVED 387155",
	"UNIT_DIED"
)

--TODO, fix spear creatureid?
--TODO, timers with longer logs that suck at lances
--TODO, announce 386490?
--[[
(ability.id = 388283 or ability.id = 388817 or ability.id = 385916 or ability.id = 386921 or ability.id = 386530 or ability.id = 385657) and type = "begincast"
 or ability.id = 386747 or ability.id = 386748 or ability.id = 386320
 or ability.id = 387155 and (type = "applydebuff" or type =  "removedebuff")
 or target.id = 194367 and type = "death"
 or type = "dungeonencounterstart" or type = "dungeonencounterend"
--]]
local warnShardsofStone							= mod:NewCountAnnounce(388817, 3)
local warnLanced								= mod:NewTargetNoFilterAnnounce(387155, 1)
local warnReload								= mod:NewCastAnnounce(386921, 2)
local warnAdd									= mod:NewCountAnnounce(386320, 3)

local specWarnEruption							= mod:NewSpecialWarningCount(388283, nil, nil, nil, 1, 2, nil, nil, "interruptsoon")
local specWarnTectonicStomp						= mod:NewSpecialWarningRun(385916, "Melee", nil, nil, 4, 2, nil, nil, "justrun")

local timerEruptionCD							= mod:NewCDTimer(35, 388283, nil, nil, nil, 2)
local timerShardsofStoneCD						= mod:NewCDTimer(13.3, 388817, nil, nil, nil, 2)
local timerTectonicStompCD						= mod:NewCDTimer(35, 385916, nil, nil, nil, 3)--Technically also aoe, but limited aoe range, so targeted aoe
local timerSummonSaboteurCD						= mod:NewNextCountTimer(14.9, 386320, nil, nil, nil, 1, nil, DBM_COMMON_L.MYTHIC_ICON)
local timerReload								= mod:NewCastTimer(25, 386921, nil, nil, nil, 5)

mod:AddSetIconOption("SetIconOnAdd", 386320, true, 5, {8})

mod.vb.eruptionCount = 0
mod.vb.shardsCount = 0
mod.vb.addCount = 0
local addsTimers = {6, 32.7, 40}

function mod:OnCombatStart(delay)
	self.vb.eruptionCount = 0
	self.vb.shardsCount = 0
	self.vb.addCount = 0
	timerShardsofStoneCD:Start(10.6-delay)
	timerTectonicStompCD:Start(15.5-delay)
	timerEruptionCD:Start(28.8-delay)
	if self:IsMythic() then
		timerSummonSaboteurCD:Start(5.6-delay, 1)
	end
end

function mod:SPELL_CAST_START(args)
	local spellId = args.spellId
	if spellId == 388283 then
		self.vb.eruptionCount = self.vb.eruptionCount + 1
		specWarnEruption:Show(self.vb.eruptionCount)
		specWarnEruption:Play("interruptsoon")
--		timerEruptionCD:Start()--In between times not known yet since doing fight correctly shouldn't see in betweens
	elseif spellId == 388817 then--388817 confirmed on mythic/heroic/normal, 385657 unused?
		self.vb.shardsCount = self.vb.shardsCount + 1
		warnShardsofStone:Show(self.vb.shardsCount)
		timerShardsofStoneCD:Start()
	elseif spellId == 385916 then
		specWarnTectonicStomp:Show()
		specWarnTectonicStomp:Play("justrun")
--		timerTectonicStompCD:Start()--In between times not known yet since doing fight correctly shouldn't see in betweens
	elseif spellId == 386921 then
		warnReload:Show()
		timerReload:Start()
	end
end

function mod:SPELL_SUMMON(args)
	local spellId = args.spellId
	if spellId == 386747 or spellId == 386748 or spellId == 386320 then--386747 Lance 1, 386748 Lance 2, 386320 Lance 3
		self.vb.addCount = self.vb.addCount + 1
		warnAdd:Show(self.vb.addCount)
		if self.Options.SetIconOnAdd then--195821, 195820, 195580
			self:ScanForMobs(args.destGUID, 2, 8, 1, nil, 12, "SetIconOnAdd")
		end
	end
end

function mod:SPELL_AURA_APPLIED(args)
	local spellId = args.spellId
	if spellId == 387155 then
		warnLanced:Show(args.destName)
		timerEruptionCD:Stop()
		timerShardsofStoneCD:Stop()
		timerTectonicStompCD:Stop()
	end
end

function mod:SPELL_AURA_REMOVED(args)
	local spellId = args.spellId
	if spellId == 387155 then--Lanced!
		--Resets these timers
		if self:IsMythic() then
			timerSummonSaboteurCD:Start(5.6, self.vb.addCount+1)
		end
		timerShardsofStoneCD:Start(10)
		timerTectonicStompCD:Start(15.3)
		timerEruptionCD:Start(28.6)
	end
end

function mod:UNIT_DIED(args)
	local cid = self:GetCIDFromGUID(args.destGUID)
	if cid == 194367 then--Dragonkiller Lance (CID may be wrong)
		timerReload:Stop()
	end
end
