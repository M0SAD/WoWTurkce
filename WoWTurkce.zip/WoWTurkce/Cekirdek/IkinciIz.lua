-- İkinci parmak izi (iz2)
-- Bazı çeviri tabloları metni birinci parmak izi (G.konusmaIz, djb2) yerine ikinci bir 32 bitlik
-- parmak iziyle saklar: Konusma2, Soz2, Ipucu2, Egitim2, Altyazi2 ve kitap sayfaları.
-- Arama sırası her zaman aynıdır: önce birinci parmak izi ve ana tablolar, bulunamazsa ikinci parmak izi.
local G = WoWTurkce
G.Konusma2 = G.Konusma2 or {}  -- NPC selamlamaları ve konuşma seçenekleri: [iz2] = "Türkçe"
G.Soz2 = G.Soz2 or {}          -- NPC sözleri ve duygu mesajları: [iz2] = "Türkçe"
G.Ipucu2 = G.Ipucu2 or {}      -- ipucu satırları ($1 $2 ... sayı yer tutucularıyla): [iz2] = "Türkçe"
G.Egitim2 = G.Egitim2 or {}    -- oyun ipucu pencereleri: [iz2] = "Türkçe"
G.Altyazi2 = G.Altyazi2 or {}  -- sinematik ve film altyazıları: [iz2] = "Türkçe"

---------------------------------------------------------------------------
-- İkinci parmak izi: metin üçer bayt üçer bayt iki büyük asal sayıya göre katlanır
---------------------------------------------------------------------------
local fmod, byte, len = math.fmod, string.byte, string.len
local function iz2(metin)
	if not metin or #metin == 0 then return 0 end
	local h = 1
	local n = len(metin)
	for i = 1, n, 3 do
		h = fmod(h * 8161, 4294967279)
		h = h + (byte(metin, i) * 16776193)
		h = h + ((byte(metin, i + 1) or (n - i + 256)) * 8372226)
		h = h + ((byte(metin, i + 2) or (n - i + 256)) * 3932164)
	end
	return fmod(h, 4294967291)
end
G.iz2 = iz2

---------------------------------------------------------------------------
-- Metni ikinci parmak izi için hazırla: oyuncu adı, ırkı, sınıfı ve satır sonları çıkarılır
---------------------------------------------------------------------------
local SONRA = { ["."] = true, [","] = true, ["?"] = true, ["!"] = true, [" "] = true, [";"] = true, [":"] = true, [">"] = true, ["-"] = true }
local function tamKelime(metin, aranan, yeni)
	if type(aranan) ~= "string" or aranan == "" then return metin end
	local s, son = metin, 1
	local a, b = s:find(aranan, son)
	while a and a > 0 do
		if a == 1 or s:sub(a - 1, a - 1) == " " or (a > 2 and s:sub(a - 2, a - 1) == "$B") then
			if SONRA[s:sub(b + 1, b + 1)] then
				s = s:sub(1, a - 1) .. yeni .. s:sub(b + 1)
				son = a + #yeni
			else
				son = b + 1
			end
		else
			son = a + #aranan
		end
		a, b = s:find(aranan, son)
	end
	return s
end

local function kacir(s) return (s:gsub("(%W)", "%%%1")) end

local oyuncu = {}
local function oyuncuBilgisi()
	if oyuncu.ad then return oyuncu end
	local ad = UnitName and UnitName("player")
	if not ad or ad == "" or ad == UNKNOWNOBJECT then return oyuncu end
	oyuncu.ad = ad
	oyuncu.anaAd = ad:match("^(%S+)") or ad
	oyuncu.irk = UnitRace and UnitRace("player") or ""
	oyuncu.sinif = UnitClass and UnitClass("player") or ""
	return oyuncu
end

-- yalnizAd: true ise yalnızca oyuncu adı yer tutucuya çevrilir (konuşma seçenekleri, kitaplar)
local function yerTutucu(metin, hedef, yalnizAd)
	local o = oyuncuBilgisi()
	local t = metin:gsub("\r", "")
	if not yalnizAd then t = t:gsub("\n", "$B") end
	if o.ad then
		t = t:gsub(kacir(o.ad), "$N"):gsub(kacir(o.ad:upper()), "$N")
		if o.anaAd ~= o.ad then
			t = t:gsub("%f[%a]" .. kacir(o.anaAd) .. "%f[%A]", "$N"):gsub("%f[%a]" .. kacir(o.anaAd:upper()) .. "%f[%A]", "$N")
		end
	end
	if not yalnizAd and o.irk and o.irk ~= "" then
		t = tamKelime(t, o.irk, "$R"); t = tamKelime(t, o.irk:lower(), "$R"); t = tamKelime(t, o.irk:upper(), "$R$")
		t = tamKelime(t, o.sinif, "$C"); t = tamKelime(t, o.sinif:lower(), "$C"); t = tamKelime(t, o.sinif:upper(), "$C$")
	end
	if hedef and hedef ~= "" then t = tamKelime(t, hedef, "$N") end
	return t
end

local function kodSil(metin, yalnizAd)
	local t = metin
	if not yalnizAd then t = t:gsub("%$B", "") end
	t = t:gsub("%$N%$", ""):gsub("%$N", ""):gsub("%$MN", ""):gsub("%$FN", ""):gsub("%$SN", "")
	if not yalnizAd then
		t = t:gsub("%$R%$", ""):gsub("%$R", ""):gsub("%$C%$", ""):gsub("%$C", "")
		t = t:gsub("%$G", ""):gsub("%$P", ""):gsub("%$O", ""):gsub("%$TARGET", "")
	end
	t = t:gsub("\n", ""):gsub("\r", "")
	return t
end

local function kirp(s) return (s:gsub("^%s+", ""):gsub("%s+$", "")) end

local function konusmaIzleri(metin, hedef)
	local liste, gor = {}, {}
	local function ekle(s)
		local h = iz2(kodSil(yerTutucu(s, hedef)))
		if h ~= 0 and not gor[h] then gor[h] = true; liste[#liste + 1] = h end
	end
	ekle(kirp(metin))
	ekle(metin)
	local lv = metin:gsub(" %(low level%)", "")
	if lv ~= metin then ekle(kirp(lv)) end
	return liste
end

---------------------------------------------------------------------------
-- Çeviriyi göstermeye hazırla (G.doldur'dan önce)
---------------------------------------------------------------------------
-- $G(erkek;kadın) ve NPC için $P(erkek;kadın)
local function cinsiyetSec(s, kod, birim)
	return (s:gsub("%$" .. kod .. "%s*(%b())", function(p)
		local e, k = p:sub(2, -2):match("^(.-);(.*)$")
		if not e then return nil end
		local c = UnitSex and UnitSex(birim)
		return (c == 3) and k or e
	end))
end

local function sayilar(en)
	local t = {}
	if not en then return t end
	en = en:gsub("(%d),(%d)", "%1%2")
	for w in en:gmatch("%d+") do t[#t + 1] = w end
	return t
end

local function hazirla(tr, en, renk)
	if type(tr) ~= "string" or tr == "" then return nil end
	local s = tr
	-- Görev seçeneklerindeki renkli önek: "RENK:(Görev)|r ..." -> oyundaki renk kodu
	if s:find("^RENK:") then s = s:gsub("^RENK:", renk or "|cff0000ff") end
	s = cinsiyetSec(s, "[Gg]", "player")
	s = cinsiyetSec(s, "[Pp]", "npc")
	s = s:gsub("%$[Oo]%f[%A]", "")
	if s:find("%$L") then
		local ev = (GetBindLocation and GetBindLocation()) or ""
		s = s:gsub("%$L%f[%A]", (ev:gsub("%%", "%%%%")))
	end
	-- Sayılar: $1 $2 ... ve {01} {02} ... İngilizce metindeki sırayla
	if s:find("%$%d") or s:find("{%d%d}") then
		local n = sayilar(en)
		s = s:gsub("{(%d%d)}", function(i) return n[tonumber(i)] end)
		s = s:gsub("%$(%d+)", function(i)
			local k = tonumber(i)
			if k and k >= 1 and k <= 40 and n[k] then return n[k] end
		end)
	end
	return s
end
G.iz2Hazirla = hazirla

local function ilkBul(izler, ...)
	local tablolar = { ... }
	for _, h in ipairs(izler) do
		for i = 1, #tablolar do
			local t = tablolar[i]
			local v = t and t[h]
			if type(v) == "string" and v ~= "" then return v end
		end
	end
end

-- Ana tabloya göre ikinci parmak izi tabloları
local function ekTablolar(tablo)
	if tablo == nil then return nil end
	if tablo == G.Konusma then return G.Konusma2, G.Soz2 end
	if tablo == G.Soz then return G.Soz2, G.Altyazi2 end
	if tablo == G.Altyazi then return G.Altyazi2, G.Soz2 end
end

function G.izBul2(tablo, metin, hedef)
	if type(metin) ~= "string" or metin == "" then return nil end
	local t1, t2 = ekTablolar(tablo)
	if not t1 then return nil end
	local v = ilkBul(konusmaIzleri(metin, hedef), t1, t2)
	if v then return hazirla(v, metin) end
end

-- Renkli görev seçenekleri ("|cff0000ff(Quest)|r ..."): renk kodu yerine 9 baytlık sabit bir önekle
-- izlenir. Önekin ize katkısı tam üç adım olduğu için başlangıç değeri önceden hesaplanmıştır.
local RENK_IZ, RENK_UZUNLUK = 3484037373, 9
local function renkliIz2(metin)
	local h = RENK_IZ
	local n = RENK_UZUNLUK + len(metin)
	for i = 1, len(metin), 3 do
		local g = i + RENK_UZUNLUK
		h = fmod(h * 8161, 4294967279)
		h = h + (byte(metin, i) * 16776193)
		h = h + ((byte(metin, i + 1) or (n - g + 256)) * 8372226)
		h = h + ((byte(metin, i + 2) or (n - g + 256)) * 3932164)
	end
	return fmod(h, 4294967291)
end

-- NPC konuşma seçeneği ("Train me.", görev adları ...)
function G.secenek2(metin)
	if type(metin) ~= "string" or metin == "" or G.turkceMi(metin) then return nil end
	local renk, ic = metin:match("^(|c%x%x%x%x%x%x%x%x)(.*)$")
	local function bul(a, renkli)
		local f = renkli and renkliIz2 or iz2
		return G.Konusma2[f(kodSil(yerTutucu(a, nil, true), true))] or G.Konusma2[f(kodSil(yerTutucu(kirp(a), nil, true), true))]
	end
	local v = bul(metin) or (renk and bul(ic, true))
	if type(v) == "string" and v ~= "" then return G.doldur(hazirla(v, metin, renk)) end
	v = G.Konusma2[renkliIz2(kodSil("(Quest) " .. yerTutucu(metin, nil, true), true))]
	if type(v) == "string" and v ~= "" then
		return G.doldur(hazirla((v:gsub("^RENK:%(.-%)|r ", "")), metin))
	end
end

-- İpucu satırı (eşya/büyü açıklaması, "Use: ...", hikâye yazısı ...)
local function ipucuHazirla(metin)
	local t = kirp(metin):gsub("|cFFFFFFFF", ""):gsub("|r", ""):gsub("\r", ""):gsub("\n", "")
	local o = oyuncuBilgisi()
	if o.ad then
		t = t:gsub("%f[%a]" .. kacir(o.ad) .. "%f[%A]", "$N")
		if o.ad:upper() ~= o.ad then t = t:gsub("%f[%a]" .. kacir(o.ad:upper()) .. "%f[%A]", "$N") end
		if o.anaAd ~= o.ad then t = t:gsub("%f[%a]" .. kacir(o.anaAd) .. "%f[%A]", "$N") end
	end
	t = t:gsub("(%d),(%d)", "%1%2"):gsub("%d", "")
	return t
end
local ipucuOnbellek, ipucuSay = {}, 0
function G.ipucu2(metin)
	if type(metin) ~= "string" or #metin < 3 or not metin:find("%a%a") or G.turkceMi(metin) then return nil end
	local c = ipucuOnbellek[metin]
	if c == nil then
		local v = G.Ipucu2[iz2(ipucuHazirla(metin))]
		c = (type(v) == "string" and v ~= "") and v or false
		if ipucuSay > 3000 then ipucuOnbellek, ipucuSay = {}, 0 end
		ipucuOnbellek[metin] = c; ipucuSay = ipucuSay + 1
	end
	if c then return G.doldur(hazirla(c, metin)) end
end

-- Oyun ipucu (tutorial) metinleri
function G.egitim2(metin)
	if type(metin) ~= "string" or metin == "" or G.turkceMi(metin) then return nil end
	local v = G.Egitim2[iz2((metin:gsub("\r", "")))]
	if type(v) ~= "string" or v == "" then v = G.Ipucu2[iz2(ipucuHazirla(metin))] end
	if type(v) == "string" and v ~= "" then
		return G.doldur(hazirla((v:gsub("%$[Bb]", "|n")), metin))
	end
end

-- Kitap sayfası: "İngilizce başlık#sayfa#metnin ilk 15 harfi", eşya no ya da ikinci parmak izi
function G.kitap2(baslik, metin, sayfa)
	if type(baslik) ~= "string" or type(metin) ~= "string" or not G.KitapSayfa then return nil end
	local nr = tostring(sayfa or 1); if nr == "0" then nr = "1" end
	local en = yerTutucu(metin, nil, true)
	local adaylar = {}
	if C_Item and C_Item.GetItemInfo then
		local ok, _, link = pcall(C_Item.GetItemInfo, baslik)
		local no = ok and type(link) == "string" and link:match("|Hitem:(%d+):")
		if no then adaylar[#adaylar + 1] = no end
	end
	local no = G.KitapNo and G.KitapNo[baslik .. "#" .. nr .. "#" .. (en:gsub("\n", "")):sub(1, 15)]
	if no and baslik ~= "Plain Letter" and baslik ~= "Order of Night Propaganda" then adaylar[#adaylar + 1] = no end
	adaylar[#adaylar + 1] = tostring(iz2(en))
	for _, id in ipairs(adaylar) do
		local k = G.KitapSayfa[id]
		local s = k and k[nr]
		if type(s) == "string" and s ~= "" then
			return hazirla(s, metin), (type(k.Title) == "string" and k.Title ~= "") and k.Title or nil
		end
	end
end

---------------------------------------------------------------------------
-- G.izBul: birinci parmak izi bulamazsa ikinci parmak iziyle dene
---------------------------------------------------------------------------
local izBul1 = G.izBul
function G.izBul(tablo, metin, ...)
	local tr, iz = izBul1(tablo, metin, ...)
	if tr ~= nil then return tr, iz end
	local tr2 = G.izBul2(tablo, metin)
	if tr2 then return tr2, iz end
	return nil, iz
end
