-- Otomatik toplama ile eklenen çeviriler (zamanlanmış görev bu dosyanın sonuna ekler).
-- Bu dosya eklenti güncellemelerinde üzerine yazılmaz.
local G = WoWTurkce
local A, V, E = G.Arayuz, G.Veri, G.VeriEk
local function ek(t, k, v) if t and k ~= nil and t[k] == nil then t[k] = v end end
-- Örnek biçimler:
-- ek(A, "English text", "Türkçe")            arayüz / ipucu / hata (G.Esya, G.Buyu, G.Hata, G.Egitim, G.Secenek de olur)
-- ek(G.EsyaAdi, "Item Name", "Eşya Adı")      eşya adı (G.BuyuAdi büyü adı, G.KitapAdi kitap adı)
-- ek(G.Soz, 123456789, "Türkçe söz")          parmak izli metinler (G.Soz, G.Konusma, G.Kitap, G.Altyazi)
-- V[12345] = { b = "Başlık", a = "Açıklama", h = "Hedef", i = "İlerleme", t = "Tamamlama" }   görev (eskisinin yerine geçer)
