-- Veritabanında henüz olmayan yeni görevler (ekran görüntülerinden çevrildi).
-- Görev kimliği bilinmediği için metnin kendisiyle eşleşir; oyuncu adı $N, sınıf $C, ırk $R olarak yazılır.
local G = WoWTurkce
local function gorev(baslik, baslikTr, metinler)
	if baslik and baslikTr then G.GorevAdi[baslik] = baslikTr end
	for _, m in ipairs(metinler or {}) do
		local iz = G.konusmaIz(m[1], 2)
		if iz then G.GorevMetni[iz] = m[2] end
	end
end
G.yeniGorev = gorev
-- Örnek kullanım:
-- gorev("Quest Title", "Görev Başlığı", {
--     { "English description with $N.", "Türkçe açıklama $N." },
--     { "Objective text.", "Hedef metni." },
-- })
