-- Z-Perl çerçevelerindeki durum yazıları (Dead, Ghost, Offline, Fishing...) için Türkçe düzeltme.
local G = WoWTurkce

local METIN = {
	["Dead"] = "Ölü", ["Ghost"] = "Hayalet", ["Offline"] = "Çevrimdışı", ["Feign Death"] = "Ölü Taklidi",
	["Fishing"] = "Balıkçılık", ["FD"] = "ÖT", ["Resurrected"] = "Diriltildi", ["Ressed"] = "Diriltildi",
}

local cerceveler = {}
local function topla()
	wipe(cerceveler)
	for ad, f in pairs(_G) do
		if type(ad) == "string" and ad:find("^XPerl_") and type(f) == "table" and f.GetObjectType and f.GetRegions
			and (ad:find("^XPerl_Player$") or ad:find("^XPerl_Target$") or ad:find("^XPerl_Focus$") or ad:find("^XPerl_TargetTarget$")
			or ad:find("^XPerl_party%d$") or ad:find("^XPerl_Party") or ad:find("^XPerl_Raid") or ad:find("^XPerl_Pet")) then
			cerceveler[#cerceveler + 1] = f
		end
	end
end

local function yazilar(f, d)
	if d > 6 then return end
	if f.IsShown and not f:IsShown() then return end
	if f.GetRegions then
		for _, r in ipairs({ f:GetRegions() }) do
			if r.GetObjectType and r:GetObjectType() == "FontString" and r.GetText then
				local t = r:GetText()
				if type(t) == "string" and not G.gizli(t) then
					local tr = METIN[t]
					if tr then r:SetText(tr) end
				end
			end
		end
	end
	if f.GetChildren then
		for _, c in ipairs({ f:GetChildren() }) do yazilar(c, d + 1) end
	end
end

local function tara()
	if not G.ayar("acik") then return end
	for _, f in ipairs(cerceveler) do pcall(yazilar, f, 0) end
end

G.basla(function()
	-- Z-Perl genel yazıları (durum metinleri çalışma anında bu değişkenlerden okunuyorsa yeter)
	C_Timer.After(2, function()
		if not _G.XPerl_Player and not _G.XPERL_LOC_DEAD then return end
		if _G.XPERL_LOC_DEAD then _G.XPERL_LOC_DEAD = "Ölü" end
		if _G.XPERL_LOC_GHOST then _G.XPERL_LOC_GHOST = "Hayalet" end
		if _G.XPERL_LOC_OFFLINE then _G.XPERL_LOC_OFFLINE = "Çevrimdışı" end
		if _G.XPERL_LOC_FEIGNDEATH then _G.XPERL_LOC_FEIGNDEATH = "Ölü Taklidi" end
		-- RaidHelper (hedef/yardım penceresi ve ipucu): metinler çalışma anında bu değişkenlerden okunur;
		-- doğrudan Türkçeleştirince ipucu gecikmeden Türkçe açılır ve kutu doğru boyutlanır
		local RH = {
			XPERL_TOOLTIP_ASSISTING = "Yardım Eden Oyuncular:", XPERL_TOOLTIP_HEALERS = "Beni Hedefleyen Şifacılar:",
			XPERL_TOOLTIP_ALLONME = "Beni Hedefleyen Herkes:", XPERL_TOOLTIP_ENEMYONME = "Beni Hedefleyen Düşmanlar:",
			XPERL_TOOLTIP_HELP = "Gerçek zamanlı görünümü açmak için tıkla", XPERL_TOOLTIP_PET = "%s adlı oyuncunun evcil hayvanı",
			XPERL_BUTTON_TOGGLE_LABELS = "Hedef Etiketlerini Aç/Kapat", XPERL_BUTTON_TOGGLE_MTTARGETS = "Ana Tankın hedeflerinin hedefini göster/gizle",
			XPERL_BUTTON_TOGGLE_SHOWMT = "Ana Tankı göster/gizle", XPERL_BUTTON_HELPER_PIN = "Pencereyi Sabitle",
			XPERL_XS_TARGET = "%s adlı oyuncunun hedefi", XPERL_NO_TARGET = "hedef yok",
			XPERL_TITLE_MT_LONG = "Ana Tank Hedefleri", XPERL_TITLE_MT_SHORT = "AT", XPERL_TITLE_WARRIOR_LONG = "Savaşçı Hedefleri", XPERL_TITLE_WARRIOR_SHORT = "Tanklar",
			XPERL_HELPER_NEEDPROMOTE = "Ana Yardımcıyı belirlemek için yetki verilmiş olmalısın", XPERL_HELPER_MASET = "Ana Yardımcı: %s",
			XPERL_HELPER_MACLEAR = "Ana Yardımcı |c00FF0000temizlendi!", XPERL_HELPER_MAREMOVED = "Ana Yardımcı %s tank listesinde bulunamadı - kaldırıldı!",
			XPERL_HELPER_MAREMOTESET = "%s, Ana Yardımcı olarak %s adlı oyuncuyu atadı",
			XPERL_AGGRO_PLAYER = "- TEHDİT -", XPERL_AGGRO_PET = "- EVCİL HAYVAN TEHDİDİ -", XPERL_AGGRO_DRAGTIP = "Tehdit uyarısının yerini taşı",
		}
		for k, v in pairs(RH) do if _G[k] ~= nil then _G[k] = v end end
		local pin = _G.XPerl_Assists_FramePin or _G.XPerl_AssistsFramePin
		if pin and pin.SetText then pcall(pin.SetText, pin, "Pencereyi Sabitle") end
		topla()
		G.olcTicker(2.0, tara)
		-- Tüm global tabloyu dolaşmak pahalı (~30 ms takılma): 10 sn'de bir değil, yalnızca grup değişince ve savaş dışında
		local f, bekliyor = CreateFrame("Frame"), false
		f:RegisterEvent("GROUP_ROSTER_UPDATE"); f:RegisterEvent("PLAYER_REGEN_ENABLED")
		local kirli = false
		f:SetScript("OnEvent", function(_, olay)
			if olay == "GROUP_ROSTER_UPDATE" then kirli = true end
			if not kirli or bekliyor then return end
			bekliyor = true
			C_Timer.After(3, function()
				bekliyor = false
				if InCombatLockdown and InCombatLockdown() then return end
				kirli = false
				topla()
			end)
		end)
	end)
end)
