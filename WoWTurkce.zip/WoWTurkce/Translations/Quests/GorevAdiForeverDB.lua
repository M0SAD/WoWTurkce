-- ForeverDB.net verisinden çıkarılan ad çevirileri. Data from ForeverDB.net (https://foreverdb.net)
if not WoWTurkce.FOREVER then return end
local A, Y = WoWTurkce.GorevAdi, WoWTurkce.Arayuz
local function a(k, v) if A[k] == nil then A[k] = v end; if Y[k] == nil then Y[k] = v end end
a("Blisters on the Land", "Topraktaki Yaralar")
a("Falaath Village", "Falaath Köyü")
a("In Search of the Excavation Team", "Kazı Ekibinin Peşinde")
a("Look to the Stars", "Yıldızlara Bak")
a("Oh Brother...", "Ah Kardeşim...")
a("Quell the Uprising", "İsyanı Bastır")
a("Reading the Ley Lines", "Ley Hatlarını Okumak")
a("Return to the Crossroads", "Crossroads'a Dönüş")
a("Your Place in the World", "Dünyadaki Yerin")
