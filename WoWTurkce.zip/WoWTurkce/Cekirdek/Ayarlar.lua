-- Ayarlar paneli (Oyun Menüsü > Ayarlar > AddOns > WoWTurkce) ve minimap düğmesi
local G = WoWTurkce

local SECENEKLER = {
	{ baslik = "Bölümler" },
	{ "acik", "Türkçe çeviriyi aç", "Kapatırsan addon hiçbir yeri çevirmez (kayıt devam edebilir)." },
	{ "gorev", "Görevler", "Görev penceresi ve görev günlüğündeki ad, hedef ve hikaye metinleri." },
	{ "konusma", "NPC konuşmaları", "NPC'ye tıklayınca çıkan selamlama metni ve 'Train me.' gibi seçenekler." },
	{ "arayuz", "Genel arayüz", "Oyun ayarları, karakter penceresi (istatistik, itibar, beceriler, onur), grup menüsü, ESC menüsü." },
	{ "yaratik", "Yaratık adları", "Mob adlarını her yerde (hedef, isim plakası, görevler) Türkçe gösterir. Kapalıyken orijinal adlar kalır, fareyle üzerine gelince ipucunda Türkçesi parantez içinde yazar." },
	{ "npc", "NPC adları", "NPC unvanlarını Türkçe gösterir (Deathguard Saltain -> Ölüm Muhafızı Saltain, Delgren the Purifier -> Arındırıcı Delgren). Kişisel adlar değişmez. Kapalıyken orijinal adlar kalır, fareyle üzerine gelince ipucunda Türkçesi parantez içinde yazar." },
	{ "kitap", "Kitaplar ve mektuplar", "Okunabilir eşyalar, mektuplar, notlar ve tabelalardaki sayfalar." },
	{ "altyazi", "Sinematik altyazıları", "Filmlerde ve ara sahnelerde altyazıyı Türkçe gösterir (filmlerde altyazıyı otomatik açar)." },
	{ "balon", "NPC sözleri ve konuşma balonları", "Yaratık ve NPC'lerin söyledikleri, bağırdıkları ve duygu mesajları; sohbet penceresinde ve başlarının üstündeki balonda." },
	{ "egitim", "Oyun ipuçları", "Yeni oyunculara çıkan ipucu pencereleri (Quest Log, Display Tips...)." },
	{ "buyu", "Büyü ve yetenek açıklamaları", "İpucundaki büyü ve yetenek açıklamaları." },
	{ "buyuadi", "Büyü adları (büyü kitabı)", "Büyü kitabında Türkçe ad; ipucunda Türkçe ad ve yanında İngilizcesi." },
	{ "ipucu", "Eşya ipuçları", "Binds when picked up, Durability, zırh türü, statlar gibi satırlar." },
	{ "hata", "Hata ve bilgi mesajları", "Ekranın ortasındaki 'Not enough mana', 'Out of range' gibi yazılar." },
	{ baslik = "Görünüm" },
	{ "font", "Görev ve konuşma metinlerinde Türkçe yazı tipi", "Görev penceresi için parşömene uygun bir yazı tipi kullanır." },
	{ "genelfont", "Tüm arayüzde Türkçe karakter desteği", "ğ, ş, ı, İ harfleri kare görünüyorsa açık tut. Diğer Türkçe addon'ları da düzeltir." },
	{ "partiBilgi", "Parti çerçevelerinde seviye ve sınıf", "Parti üyelerinin çerçevesinin üstünde seviyesini ve sınıfını gösterir." },
	{ "minimap", "Minimap düğmesini göster", "Sol tık: ayarlar, sağ tık: Türkçe/İngilizce, Shift+sol tık: çevrilmemişleri gönder, orta tık: çevrilmemişleri göster." },
	{ "shiftEn", "Alt basılıyken İngilizcesini göster", "Alt'ı basılı tuttuğun sürece her şey (görevler, ipuçları, butonlar) İngilizce görünür; bırakınca Türkçe geri gelir. Sohbete yazarken ve çatışmada çalışmaz." },
	{ baslik = "Kolaylıklar" },
	{ "tamir", "Satıcıda otomatik tamir", "Tamirci satıcı penceresi açılınca tüm eşyaları kendi paranla tamir eder." },
	{ "hurda", "Gri eşyaları otomatik sat", "Satıcı penceresi açılınca çantandaki gri (değersiz) eşyaları satar." },
	{ baslik = "Çeviri kaydı" },
	{ "kayit", "Çevirisi olmayan metinleri kaydet", "Kayıtlar /reload ya da çıkışta diske yazılır, sonra çevrilip addon'a eklenir." },
}

local panel = CreateFrame("Frame")
panel.name = "WoWTürkçe"
panel:Hide()

local kutular = {}
local durum

local IKON = "Interface\\AddOns\\" .. G.ADDON .. "\\Medya\\bayrak_tr"
local function cizgi(ic, y)
	local t = ic:CreateTexture(nil, "ARTWORK")
	t:SetColorTexture(1, 0.82, 0, 0.25)
	t:SetPoint("TOPLEFT", 16, y); t:SetPoint("TOPRIGHT", ic, "TOPRIGHT", -16, y)
	t:SetHeight(1)
	return t
end
local function dugme(ic, yazi, gen, fn, ipucu)
	local b = CreateFrame("Button", nil, ic, "UIPanelButtonTemplate")
	b:SetSize(gen, 24); b:SetText(yazi); b:SetScript("OnClick", fn)
	if ipucu then
		b:SetScript("OnEnter", function(self)
			GameTooltip:SetOwner(self, "ANCHOR_RIGHT"); GameTooltip:AddLine(yazi)
			GameTooltip:AddLine(ipucu, 1, 1, 1, true); GameTooltip:Show()
		end)
		b:SetScript("OnLeave", function() GameTooltip:Hide() end)
	end
	return b
end
local function kopyaKutusu(ic, metin, gen)
	local eb = CreateFrame("EditBox", nil, ic, "InputBoxTemplate")
	eb:SetSize(gen, 22); eb:SetAutoFocus(false); eb:SetText(metin); eb:SetCursorPosition(0)
	eb:SetScript("OnTextChanged", function(self, k) if k then self:SetText(metin); self:HighlightText() end end)
	eb:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
	eb:SetScript("OnMouseUp", function(self) self:SetFocus(); self:HighlightText() end)
	eb:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
	return eb
end

local function kur()
	if panel.kuruldu then return end
	panel.kuruldu = true
	local kap = CreateFrame("ScrollFrame", nil, panel, "UIPanelScrollFrameTemplate")
	kap:SetPoint("TOPLEFT", 0, -4)
	kap:SetPoint("BOTTOMRIGHT", -28, 4)
	local ic = CreateFrame("Frame", nil, kap)
	ic:SetSize(640, 1200)
	kap:SetScrollChild(ic)
	kap:SetScript("OnSizeChanged", function(self, w) if w and w > 50 then ic:SetWidth(w - 4) end end)

	-- Başlık
	local ikon = ic:CreateTexture(nil, "ARTWORK")
	ikon:SetTexture(IKON); ikon:SetSize(40, 40); ikon:SetPoint("TOPLEFT", 16, -12)
	local baslik = ic:CreateFontString(nil, "ARTWORK", "GameFontNormalHuge")
	baslik:SetPoint("TOPLEFT", ikon, "TOPRIGHT", 10, -2)
	baslik:SetText("WoWTürkçe")
	local alt = ic:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	alt:SetPoint("TOPLEFT", baslik, "BOTTOMLEFT", 0, -4)
	alt:SetText("Türkçe WoW oynamanın keyfi  |cff888888·  sürüm " .. G.SURUM .. "|r")
	cizgi(ic, -62)

	-- Durum ve düğmeler
	durum = ic:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
	durum:SetPoint("TOPLEFT", 16, -72); durum:SetPoint("RIGHT", ic, "RIGHT", -16, 0)
	durum:SetJustifyH("LEFT"); durum:SetWordWrap(true)
	local gonder = dugme(ic, "Çevrilmemişleri Gönder", 190, function() G.gonder() end,
		"Çevirisi olmayan metinleri ve düzeltilecek görevleri gönderir; bir sonraki sürümde Türkçe olarak eklenir.")
	gonder:SetPoint("TOPLEFT", 16, -106)
	local goster = dugme(ic, "Çevrilmemişleri Göster", 190, function() G.paylasAc() end)
	goster:SetPoint("LEFT", gonder, "RIGHT", 8, 0)
	local yenile = dugme(ic, "Arayüzü Yenile", 150, function() ReloadUI() end)
	yenile:SetPoint("LEFT", goster, "RIGHT", 8, 0)
	local sil = dugme(ic, "Kayıtları Temizle", 150, function()
		WoWTurkce_Kayit = {}
		G.yaz("Kayıtlı metinler silindi.")
		panel:GetScript("OnShow")(panel)
	end)
	sil:SetPoint("TOPLEFT", gonder, "BOTTOMLEFT", 0, -6)
	local pnc = dugme(ic, "Pencere Konumlarını Sıfırla", 190, function() if G.pencereSifirla then G.pencereSifirla() end end,
		"Shift ile taşıdığın görev, konuşma, satıcı vb. pencereleri varsayılan yerine döndürür.")
	pnc:SetPoint("LEFT", sil, "RIGHT", 8, 0)

	-- Seçenekler: başlıklı bölümler, iki sütun
	local y = -172
	local SUTUN = 290
	local function bolum(ad)
		local h = ic:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
		h:SetPoint("TOPLEFT", 16, y - 4); h:SetText(ad)
		cizgi(ic, y - 26)
		y = y - 36
	end
	-- Ad yazımı: açılır menüler
	local STILLER = { { "enTr", "English (Türkçe)" }, { "en", "English" }, { "trEn", "Türkçe (English)" }, { "tr", "Sadece Türkçe" } }
	local menu, perde
	local function menuKapat() if menu then menu:Hide() end; if perde then perde:Hide() end end
	local function menuAc(btn)
		if not menu then
			perde = CreateFrame("Button", nil, UIParent)
			perde:SetAllPoints(UIParent); perde:SetFrameStrata("FULLSCREEN"); perde:Hide()
			perde:SetScript("OnClick", menuKapat)
			menu = CreateFrame("Frame", nil, UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
			menu:SetFrameStrata("FULLSCREEN_DIALOG"); menu:SetSize(210, #STILLER * 24 + 10); menu:Hide()
			if menu.SetBackdrop then
				menu:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 14, insets = { left = 3, right = 3, top = 3, bottom = 3 } })
			end
			menu.sat = {}
			for i, st in ipairs(STILLER) do
				local sb = CreateFrame("Button", nil, menu)
				sb:SetSize(200, 22); sb:SetPoint("TOPLEFT", 5, -5 - (i - 1) * 24)
				local hl = sb:CreateTexture(nil, "HIGHLIGHT"); hl:SetAllPoints(); hl:SetColorTexture(1, 0.82, 0, 0.2)
				sb.t = sb:CreateFontString(nil, "ARTWORK", "GameFontHighlight"); sb.t:SetPoint("LEFT", 8, 0); sb.t:SetText(st[2])
				sb.tik = sb:CreateFontString(nil, "ARTWORK", "GameFontNormal"); sb.tik:SetPoint("RIGHT", -8, 0); sb.tik:SetText("|cffffd200•|r")
				sb:SetScript("OnClick", function(self)
					if menu.hedef then G.ayarla(menu.hedef.anahtar, st[1]); menu.hedef:Yaz() end
					menuKapat()
				end)
				menu.sat[i] = sb
			end
		end
		menu.hedef = btn
		for i, st in ipairs(STILLER) do menu.sat[i].tik:SetShown(G.ayar(btn.anahtar) == st[1]) end
		menu:ClearAllPoints(); menu:SetPoint("TOPLEFT", btn, "BOTTOMLEFT", 0, 2)
		perde:Show(); menu:Show()
	end
	local ddler = {}
	local function acilir(anahtar, etiket, ipucu, x, yy)
		local l = ic:CreateFontString(nil, "ARTWORK", "GameFontNormal")
		l:SetPoint("TOPLEFT", x, yy); l:SetText(etiket)
		local b = dugme(ic, "", 270, nil, ipucu)
		b:SetPoint("TOPLEFT", x, yy - 18)
		b.anahtar = anahtar
		function b:Yaz() self:SetText(G.stilAdi(anahtar) .. "  |cffffd200v|r") end
		b:SetScript("OnClick", function(self) if menu and menu:IsShown() and menu.hedef == self then menuKapat() else menuAc(self) end end)
		b:SetScript("OnShow", function(self) self:Yaz() end); b:Yaz()
		ddler[#ddler + 1] = b
	end
	bolum("Ad yazımı")
	local ok1 = "Seçenekler: English (Türkçe), English, Türkçe (English), Sadece Türkçe."
	acilir("stilYaratik", "NPC ve yaratık adları", "İpucu ve görev metinlerinde NPC/yaratık adı. " .. ok1, 16, y)
	acilir("stilEsya", "Eşya adları", "İpucu, sohbet ve görev metinlerinde eşya adı. " .. ok1, 16 + SUTUN + 16, y)
	y = y - 52
	acilir("stilBuyu", "Büyü ve yetenek adları", "Büyü ve yetenek adlarının yazımı. " .. ok1, 16, y)
	acilir("stilGorev", "Sohbette görev adları", "Sohbet mesajlarındaki görev adları. " .. ok1, 16 + SUTUN + 16, y)
	y = y - 56
	panel:HookScript("OnHide", menuKapat)
	local sira, satirY, satirH = 0, y, 0
	local function satirBitir() if sira == 1 then y = satirY - satirH - 6 end; sira = 0; satirH = 0 end
	for _, s in ipairs(SECENEKLER) do
		if s.baslik then
			satirBitir()
			bolum(s.baslik)
		else
			if sira == 0 then satirY = y end
			local x = 16 + sira * (SUTUN + 16)
			local cb = CreateFrame("CheckButton", nil, ic, "UICheckButtonTemplate")
			cb:SetPoint("TOPLEFT", x, satirY)
			cb:SetSize(26, 26)
			local et = cb:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
			et:SetPoint("LEFT", cb, "RIGHT", 4, 1)
			et:SetWidth(SUTUN - 34); et:SetJustifyH("LEFT")
			et:SetText(s[2])
			local ac = ic:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
			ac:SetPoint("TOPLEFT", cb, "BOTTOMLEFT", 30, 2)
			ac:SetWidth(SUTUN - 34); ac:SetJustifyH("LEFT"); ac:SetWordWrap(true)
			ac:SetText(s[3])
			cb.anahtar = s[1]
			cb:SetScript("OnClick", function(self) G.ayarla(self.anahtar, self:GetChecked() and true or false) end)
			kutular[#kutular + 1] = cb
			local h = 26 + (ac:GetStringHeight() or 12)
			if h > satirH then satirH = h end
			if sira == 1 then y = satirY - satirH - 6; sira = 0; satirH = 0 else sira = 1 end
		end
	end
	satirBitir()

	-- İletişim
	bolum("İletişim")
	local not1 = ic:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
	not1:SetPoint("TOPLEFT", 16, y); not1:SetPoint("RIGHT", ic, "RIGHT", -16, 0); not1:SetJustifyH("LEFT")
	not1:SetText("Öneri, hata bildirimi ya da çeviri düzeltmesi için bana ulaşabilirsin (kutuya tıklayıp Ctrl+C ile kopyala):")
	y = y - 24
	local ins = ic:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	ins:SetPoint("TOPLEFT", 16, y - 4); ins:SetText("Instagram")
	local insK = kopyaKutusu(ic, "https://www.instagram.com/erkinazcan", 300); insK:SetPoint("TOPLEFT", 100, y)
	y = y - 30
	local ep = ic:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	ep:SetPoint("TOPLEFT", 16, y - 4); ep:SetText("E-posta")
	local epK = kopyaKutusu(ic, "erkinazcan@gmail.com", 300); epK:SetPoint("TOPLEFT", 100, y)
	y = y - 40
	local yapan = ic:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
	yapan:SetPoint("TOPLEFT", 16, y); yapan:SetText("Hazırlayan: Erkin Azcan")
	y = y - 24
	local kaynak = ic:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
	kaynak:SetPoint("TOPLEFT", 16, y); kaynak:SetText("Veri kaynağı: Data from ForeverDB.net")
	local kaK = kopyaKutusu(ic, "https://foreverdb.net", 300); kaK:SetPoint("TOPLEFT", 200, y + 4)
	y = y - 20
	ic:SetHeight(-y + 30)
end

panel:SetScript("OnShow", function()
	kur()
	for _, cb in ipairs(kutular) do cb:SetChecked(G.ayar(cb.anahtar)) end
	if not panel.istatistik then
		local function say(...)
			local n, gorulen = 0, {}
			for _, t in ipairs({ ... }) do
				for k in pairs(t or {}) do if not gorulen[k] then gorulen[k] = true; n = n + 1 end end
			end
			return n
		end
		local function bin(n) local s = tostring(n); return (s:reverse():gsub("(%d%d%d)", "%1."):reverse():gsub("^%.", "")) end
		panel.istatistik = ("Türkçeye çevrilenler:  |cffffffff%s|r görev  ·  |cffffffff%s|r eşya  ·  |cffffffff%s|r büyü ve yetenek  ·  |cffffffff%s|r NPC konuşması\n|cffffffff%s|r arayüz yazısı  ·  |cffffffff%s|r kitap sayfası  ·  |cffffffff%s|r sinematik altyazısı"):format(
			bin(say(G.Veri, G.VeriEk)), bin(say(G.EsyaAdi)), bin(say(G.BuyuAdi) + say(G.Buyu)),
			bin(say(G.Soz, G.Konusma)), bin(say(G.Arayuz)), bin(say(G.Kitap)), bin(say(G.Altyazi)))
	end
	durum:SetText(panel.istatistik)
end)

local kategori
function G.ayarlariAc()
	if Settings and Settings.OpenToCategory and kategori then
		Settings.OpenToCategory(kategori:GetID())
	elseif InterfaceOptionsFrame_OpenToCategory then
		InterfaceOptionsFrame_OpenToCategory(panel)
		InterfaceOptionsFrame_OpenToCategory(panel)
	end
end

---------------------------------------------------------------------------
-- Minimap düğmesi
---------------------------------------------------------------------------
local dugme
local function konumla()
	local aci = math.rad((WoWTurkce_Ayar and WoWTurkce_Ayar.minimapAci) or 200)
	local r = ((Minimap:GetWidth() or 140) / 2) + 5
	dugme:SetPoint("CENTER", Minimap, "CENTER", math.cos(aci) * r, math.sin(aci) * r)
end

-- Minimap simgesi: Türkçe açıkken Türk bayrağı, kapalıyken İngiliz bayrağı
local BAYRAK = "Interface\\AddOns\\" .. G.ADDON .. "\\Medya\\"
function G.bayrakGuncelle()
	if dugme and dugme.ikon then
		dugme.ikon:SetTexture(BAYRAK .. (G.ayar("acik") and "bayrak_tr" or "bayrak_en"))
	end
end
G.dinle(function(k) if k == "acik" then G.bayrakGuncelle() end end)

local function minimapKur()
	if dugme or not Minimap then return end
	dugme = CreateFrame("Button", "WoWTurkce_MinimapDugmesi", Minimap)
	dugme:SetSize(31, 31)
	dugme:SetFrameStrata("MEDIUM")
	dugme:SetFrameLevel(8)
	dugme:RegisterForClicks("LeftButtonUp", "RightButtonUp", "MiddleButtonUp")
	dugme:RegisterForDrag("LeftButton")
	dugme:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
	local ikon = dugme:CreateTexture(nil, "BACKGROUND")
	ikon:SetSize(21, 21)
	ikon:SetPoint("TOPLEFT", 6, -5)
	dugme.ikon = ikon
	G.bayrakGuncelle()
	local kenar = dugme:CreateTexture(nil, "OVERLAY")
	kenar:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
	kenar:SetSize(53, 53)
	kenar:SetPoint("TOPLEFT")
	dugme:SetScript("OnClick", function(_, tus)
		if tus == "MiddleButton" then
			G.paylasAc()
		elseif tus == "LeftButton" and IsShiftKeyDown() then
			G.gonder()
		elseif tus == "RightButton" then
			G.ayarla("acik", not G.ayar("acik"))
			G.yaz(G.ayar("acik") and "Türkçe açık." or "Her şey İngilizce gösteriliyor.")
		else
			G.ayarlariAc()
		end
	end)
	dugme:SetScript("OnDragStart", function(self)
		self:SetScript("OnUpdate", function()
			local mx, my = Minimap:GetCenter()
			local x, y = GetCursorPosition()
			local s = Minimap:GetEffectiveScale()
			WoWTurkce_Ayar.minimapAci = math.deg(math.atan2(y / s - my, x / s - mx))
			self:ClearAllPoints(); konumla()
		end)
	end)
	dugme:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
	dugme:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_LEFT")
		GameTooltip:AddLine("WoWTürkçe")
		GameTooltip:AddLine(G.ayar("acik") and "|cff33ff99Türkçe açık|r" or "|cffff5555Kapalı|r")
		GameTooltip:AddLine("Sol tık: Ayarlar", 1, 1, 1)
		GameTooltip:AddLine("Sağ tık: Türkçe / İngilizce", 1, 1, 1)
		GameTooltip:AddLine("Shift+sol tık: Çevrilmemişleri gönder", 1, 1, 1)
		GameTooltip:AddLine("Orta tık: Çevrilmemişleri göster", 1, 1, 1)
		GameTooltip:AddLine("Sürükle: Yerini değiştir", 1, 1, 1)
		GameTooltip:Show()
	end)
	dugme:SetScript("OnLeave", function() GameTooltip:Hide() end)
	konumla()
end

local function minimapGuncelle()
	if G.ayar("minimap") then minimapKur(); if dugme then dugme:Show() end
	elseif dugme then dugme:Hide() end
end

G.dinle(function(k) if k == "minimap" then minimapGuncelle() end end)

G.basla(function()
	if Settings and Settings.RegisterCanvasLayoutCategory and Settings.RegisterAddOnCategory then
		kategori = Settings.RegisterCanvasLayoutCategory(panel, "WoWTürkçe")
		Settings.RegisterAddOnCategory(kategori)
	elseif InterfaceOptions_AddCategory then
		InterfaceOptions_AddCategory(panel)
	end
	minimapGuncelle()
	if AddonCompartmentFrame and AddonCompartmentFrame.RegisterAddon then
		AddonCompartmentFrame:RegisterAddon({
			text = "WoWTürkçe",
			icon = BAYRAK .. "bayrak_tr",
			notCheckable = true,
			func = function() G.ayarlariAc() end,
		})
	end
end)
