-- İpucu (tooltip) çevirisi: eşya satırları ve büyü/yetenek açıklamaları.
-- Sadece görünen ipuçlarına dokunur; diğer addon'ların gizli tarama ipuçlarına dokunmaz.
local G = WoWTurkce

local HEDEFLER = { "GameTooltip", "ItemRefTooltip", "ShoppingTooltip1", "ShoppingTooltip2", "ShoppingTooltip3", "ItemRefShoppingTooltip1", "ItemRefShoppingTooltip2", "ItemRefShoppingTooltip3" }
local hedef = {}

-- "Equip: ...", "Use: ..." gibi önekler; öneki çevirip kalanı ayrıca dener
local ONEKLER = {
	{ "Equip: ", "Kuşanınca: " },
	{ "Use: ", "Kullan: " },
	{ "Chance on hit: ", "Vuruşta şans: " },
	{ "Requires ", "Gerekli: " },
	{ "Classes: ", "Sınıflar: " },
	{ "Races: ", "Irklar: " },
	-- Öneki başka bir yerde (arayüz taraması) zaten çevrilmiş satırlar: kalanını yine çevir
	{ "Kuşanınca: ", "Kuşanınca: " },
	{ "Kullan: ", "Kullan: " },
	{ "Vuruşta şans: ", "Vuruşta şans: " },
}

-- Renk kodunu ayır: "|cff00ff00Equip: ...|r" -> "|cff00ff00", "Equip: ...", "|r"
local function renkAyir(s)
	local bas, govde, son = s:match("^(|c%x%x%x%x%x%x%x%x)(.-)(|r)$")
	if bas then return bas, govde, son end
	return "", s, ""
end

-- Yemek (Well Fed) açıklamaları: sayılar, süre birimi ve bonus çeşitli olsa da çevirir
local BIRIM = { sec = "sn", secs = "sn", second = "sn", seconds = "sn", min = "dk", mins = "dk", minute = "dk", minutes = "dk", hr = "saat", hrs = "saat", hour = "saat", hours = "saat" }
local STAT = { Haste = "Hız", Mastery = "Ustalık", Versatility = "Çok Yönlülük", ["Critical Strike"] = "Kritik Vuruş", Intellect = "Zeka", Strength = "Güç", Agility = "Çeviklik", Stamina = "Dayanıklılık", Speed = "Hız", Armor = "Zırh", Leech = "Can Çalma", Avoidance = "Sıyrılma" }
local function bonusCevir(b)
	local n, st, sure, br = b:match("^(%d+) ([%a ]+) for (%d+) (%a+)%.?$")
	if n and STAT[st] and BIRIM[br] then return ("%s %s %s boyunca %s %s kazanırsın."):format("tok olursun ve", sure, BIRIM[br], n, STAT[st]) end
	if b:match("^Speed for a short time after killing an enemy%.?$") then return "tok olursun ve bir düşmanı öldürdükten sonra kısa süreliğine Hız kazanırsın." end
	local ad, dmg, sure2, br2 = b:match("^a chance while attacking to unleash a volley of (.-) fireballs, each dealing (%d+) Fire damage%. This bonus lasts (%d+) (%a+)%.?$")
	if ad and BIRIM[br2] then
		local adtr = (G.buyuAdiCevir and G.buyuAdiCevir(ad)) or ad
		return ("tok olursun ve saldırırken her biri %s Ateş hasarı veren bir %s ateş topu yağmuru fırlatma şansı kazanırsın. Bu bonus %s %s sürer."):format(dmg, adtr, sure2, BIRIM[br2])
	end
end
local function yemekCevir(s)
	local ayir = "[%s|n]*"
	local yuzde, sure, br, ara, es, bonus = s:match("^Restores up to (%d+)%% of your maximum health and mana every second over (%d+) (%a+)%. Must remain seated while eating%.(" .. ayir .. ")If you spend at least (%d+) seconds eating you will become well fed and gain (.+)$")
	local bt
	if yuzde and BIRIM[br] then
		bt = bonusCevir(bonus)
		if bt then return ("%s %s boyunca her saniye maksimum canının ve mananın %%%s kadarını yeniler. Yerken oturmaya devam etmelisin.%sEn az %s saniye yemek yersen %s"):format(sure, BIRIM[br], yuzde, ara, es, bt) end
		return nil
	end
	local ara2, es2, bonus2 = s:match("^(" .. ayir .. ")If you spend at least (%d+) seconds eating you will become well fed and gain (.+)$")
	if es2 then
		bt = bonusCevir(bonus2)
		if bt then return ara2 .. ("En az %s saniye yemek yersen %s"):format(es2, bt) end
	end
end
local function buzCevir(s)
	local sure, br, dmg, yav, sure2, br2, kalan = s:match("^Sheathe your weapons in ice for (%d+) (%a+), giving your melee attacks a chance to cause (%d+) additional Frost damage and slow the target's movement speed by (%d+)%% for (%d+) (%a+)%.%s*(.*)$")
	if sure and BIRIM[br] and BIRIM[br2] then
		local bek = kalan:match("%((%d+) (%a+) Cooldown%)")
		local bn, bb = kalan:match("%((%d+) (%a+) Cooldown%)")
		local son = (bn and BIRIM[bb:lower()]) and ((" (%s %s Bekleme)"):format(bn, BIRIM[bb:lower()])) or ""
		return ("Silahlarını %s %s boyunca buzla kaplar; yakın dövüş saldırılarına %s ek Buz hasarı verme ve hedefin hareket hızını %%%s oranında %s %s yavaşlatma şansı verir.%s"):format(sure, BIRIM[br], dmg, yav, sure2, BIRIM[br2], son)
	end
end

local DESENLER = {
	{ "^(Restores up to %d+%% of your maximum health and mana every second over .+)$", function(a) return yemekCevir(a) end },
	{ "^([%s|n]*If you spend at least %d+ seconds eating you will become well fed and gain .+)$", function(a) return yemekCevir(a) end },
	{ "^(Sheathe your weapons in ice for .+)$", function(a) return buzCevir(a) end },
	{ "^(Gaining a level triggers Burst of Knowledge.+)$", function(a)
		local hasar, okul, oran, nitelik, dk, ek = a:match("dealing ([%d,%.]+) (%a+) damage to nearby enemies and granting you (%d+)%% (%a+) for (%d+) min%. Defeating enemies extends this effect, up to an additional (%d+) min%.$")
		if not hasar then return nil end
		local OKUL = { Holy = "Kutsal", Fire = "Ateş", Frost = "Buz", Nature = "Doğa", Shadow = "Gölge", Arcane = "Arkan", Physical = "Fiziksel" }
		local NIT = { Agility = "Çeviklik", Strength = "Güç", Intellect = "Zeka" }
		if not OKUL[okul] or not NIT[nitelik] then return nil end
		return "Seviye atlamak Burst of Knowledge'ı tetikler; yakındaki düşmanlara " .. hasar .. " " .. OKUL[okul] .. " hasarı verir ve " .. dk .. " dk boyunca sana %" .. oran .. " " .. NIT[nitelik] .. " kazandırır. Düşmanları yenmek bu etkiyi en fazla " .. ek .. " dk daha uzatır."
	end },
	{ "^Returns you to (.-)%.%s+Speak to an Innkeeper in a different place to change your home location%.%s*(.*)$", function(yer, ek)
		local n, b = ek:match("%((%d+) (%a+) Cooldown%)")
		local BR = { Sec = "sn", Secs = "sn", Min = "dk", Mins = "dk", Hr = "saat", Hrs = "saat", Hour = "saat", Hours = "saat", Day = "gün", Days = "gün" }
		local bek = (n and BR[b]) and (" (" .. n .. " " .. BR[b] .. " Bekleme)") or (ek ~= "" and (" " .. ek) or "")
		return "Seni " .. yer .. " konumuna geri götürür. Ev konumunu değiştirmek için başka bir yerdeki bir hancıyla konuş." .. bek
	end },
}

-- "Requires Level 4, Shadow Word: Pain" / "Requires Herbalism (75)" / "Requires Samuel's Remains"
local function parcaAd(x)
	local n = x:match("^Level (%d+)$")
	if n then return "Seviye " .. n end
	local ad, sv = x:match("^(.-) %((%d+)%)$")
	ad = ad or x
	do
		local a1, a2 = ad:match("^[Ll]evel (%d+) to (%d+)$")
		if a1 then return "Seviye " .. a1 .. " - " .. a2 .. (sv and (" (" .. sv .. ")") or "") end
	end
	local tr = G.Arayuz[ad] or (G.BuyuAdi and G.BuyuAdi[ad]) or (G.buyuAdiCevir and G.buyuAdiCevir(ad)) or (G.esyaAdiGoster and G.esyaAdiGoster(ad))
	if not tr then return nil end
	return sv and (tr .. " (" .. sv .. ")") or tr
end
local function gerekliCevir(kalan)
	local out, hepsi = {}, true
	for p in (kalan .. ", "):gmatch("(.-), ") do
		local tr = parcaAd(p)
		if not tr then hepsi = false end
		out[#out + 1] = tr or p
	end
	return table.concat(out, ", "), hepsi
end

-- Eşya kullanım satırının sonuna oyunun eklediği bekleme süresi: "(1 Sec Cooldown)", "(30 Min Cooldown)"
local BEKLEME_BIRIM = { Sec = "sn", Secs = "sn", Min = "dk", Mins = "dk", Hr = "saat", Hrs = "saat", Hour = "saat", Hours = "saat", Day = "gün", Days = "gün" }
local function beklemeAyir(m)
	local govde, n, b = m:match("^(.-)%s*%((%d+) (%a+) Cooldown%)$")
	if govde and BEKLEME_BIRIM[b] then return govde, " (" .. n .. " " .. BEKLEME_BIRIM[b] .. " Bekleme)" end
	return m, ""
end

local function satirCevir(metin, buyuMu)
	-- Bekleme ve süre satırları: sayı her saniye değişse de kalıp aynı kalır
	local sure = metin:match("^Cooldown remaining: (.+)$") or metin:match("^Kalan bekleme süresi: (.+)$")
	if sure and sure:find("%d+ %a") then return "Kalan bekleme süresi: " .. G.sureCevir(sure) end
	local kalan = metin:match("^(.-) remaining$")
	if kalan and kalan:find("^%d+ %a+") and not kalan:find("[^%w%s%.,]") then return G.sureCevir(kalan) .. " kaldı" end
	for _, d in ipairs(DESENLER) do
		local a, b = metin:match(d[1])
		if a then local r = d[2](a, b or ""); if r then return r end end
	end
	local tr
	if G.modul("ipucu") then tr = G.cevir(G.Esya, metin) end
	if not tr and G.modul("buyu") then tr = G.cevir(G.Buyu, metin) end
	if tr then return tr end
	if G.modul("ipucu") then
		for _, o in ipairs(ONEKLER) do
			if metin:sub(1, #o[1]) == o[1] then
				local kalan = metin:sub(#o[1] + 1)
				if o[1] == "Requires " then
					local g, hepsi = gerekliCevir(kalan)
					return o[2] .. g, hepsi, kalan
				end
				for _, d in ipairs(DESENLER) do
					local a, b = kalan:match(d[1])
					if a then local r = d[2](a, b or ""); if r then return o[2] .. r end end
				end
				local ktr = (G.modul("buyu") and G.cevir(G.Buyu, kalan)) or G.cevir(G.Esya, kalan) or G.buyuAdiCevir(kalan) or G.cevir(G.Arayuz, kalan)
				if not ktr then
					local govde, bek = beklemeAyir(kalan)
					if bek ~= "" then
						local g = (G.modul("buyu") and G.cevir(G.Buyu, govde)) or G.cevir(G.Esya, govde) or G.cevir(G.Arayuz, govde)
						if g then ktr = g .. bek end
					end
				end
				if ktr or not G.arayuzCevir then return o[2] .. (ktr or kalan), ktr ~= nil, kalan end
				local atr = G.arayuzCevir(metin)
				if atr and not atr:find(kalan, 1, true) then return atr end
				return o[2] .. kalan, false, kalan
			end
		end
	end
	-- En son genel arayüz çevirisi (yarım çeviri yapmasın: İngilizce gövdeyi aynen bırakan sonucu kullanma)
	if G.arayuzCevir then
		local atr = G.arayuzCevir(metin)
		if atr then return atr end
	end
end

local cikti = {} -- yazdığımız Türkçe satırlar (Türkçe harfi olmayanlar da tekrar işlenmesin)
local ciktiSay = 0
local function ciktiEkle(m) if ciktiSay < 5000 and not cikti[m] then cikti[m] = true; ciktiSay = ciktiSay + 1 end end
local calisiyor = false
local auraIpucu = {} -- buff/debuff ipucu açık olan ipuçları
local function ipucuCevir(tt)
	if calisiyor or not tt or not hedef[tt] or not G.ayar("acik") then return end
	if not (G.ayar("ipucu") or G.ayar("buyu") or G.ayar("buyuadi")) then return end
	calisiyor = true
	local ad = tt:GetName()
	local buyuAdi = tt.GetSpell and select(1, tt:GetSpell())
	if not buyuAdi and auraIpucu[tt] then
		-- Buff/debuff ipucu: 1. satır aura adıdır, büyü gibi işlenir
		local t1 = _G[ad .. "TextLeft1"] and _G[ad .. "TextLeft1"]:GetText()
		buyuAdi = t1 and (t1:match("%((.-)%)|r$") or t1)
	end
	local esyaMi = tt.GetItem and select(2, tt:GetItem()) ~= nil
	local degisti = false
	-- Büyü adı (1. satır) ve rütbe (sağ üst)
	if buyuAdi and G.modul("buyuadi") then
		local fs = _G[ad .. "TextLeft1"]
		local t = fs and fs:GetText()
		if t and not t:find("|c") then
			local tr = G.buyuAdiCevir(t)
			if tr then fs:SetText(G.adStil("stilBuyu", tr, t)); degisti = true
			elseif not G.turkceMi(t) then G.kaydetDiger("buyuadi", t)
			elseif not t:find("|cff888888(", 1, true) then
				-- Ad başka bir yoldan zaten Türkçeleşmiş: İngilizcesini oyundan alıp yanına yaz
				local sid = select(2, tt:GetSpell())
				if not sid and tt.GetPrimaryTooltipData then
					local ok, d = pcall(tt.GetPrimaryTooltipData, tt)
					sid = ok and type(d) == "table" and d.id or nil
				end
				local en = sid and ((C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(sid)) or (GetSpellInfo and GetSpellInfo(sid)))
				if type(en) == "string" and en ~= "" and en ~= t and not G.turkceMi(en) then fs:SetText(G.adStil("stilBuyu", t, en)); degisti = true end
			end
		end
		local sag = _G[ad .. "TextRight1"]
		local st = sag and sag:IsShown() and sag:GetText()
		local str = st and G.buyuAltCevir and G.buyuAltCevir(st)
		if str then sag:SetText(str); degisti = true end
	end
	-- Eşya adı (1. satır): "Türkçe (English)"
	local adFs
	if esyaMi and G.modul("ipucu") then
		local fs = _G[ad .. "TextLeft1"]
		local t = fs and fs:GetText()
		-- Karşılaştırma ipucunda 1. satır başlıktır ("Currently Equipped"); ad 2. satırdadır
		local baslikTr = t and G.cevir(G.Esya, t)
		if not baslikTr and t and t:find("^|c") then
			local r = G.cevir(G.Esya, G.renksiz(t))
			if r then baslikTr = t:sub(1, 10) .. r .. "|r" end
		end
		if baslikTr then fs:SetText(baslikTr); ciktiEkle(baslikTr); degisti = true; fs = _G[ad .. "TextLeft2"]; t = fs and fs:GetText() end
		adFs = fs
		if t and not G.turkceMi(t) and not cikti[t] and not t:find("|cff888888%(") then
			local _, ic = t:match("^(|c%x%x%x%x%x%x%x%x)(.-)|r$")
			local saf = ic or t
			local tr = G.EsyaAdi[saf] or G.esyaSonekli(saf)
			if tr then local y = (ic and t:sub(1, 10) or "") .. G.adStil("stilEsya", tr, saf); fs:SetText(y); ciktiEkle(y); degisti = true
			else G.kaydetDiger("esyaadi", saf) end
		end
	end
	for i = 2, tt:NumLines() do
		for _, taraf in ipairs({ "TextLeft", "TextRight" }) do
			local fs = _G[ad .. taraf .. i]
			local metin = fs and fs:IsShown() and fs:GetText()
			if G.gizli(metin) then metin = nil end
			local onekli = metin and (metin:find("Kuşanınca: ", 1, true) or metin:find("Vuruşta şans: ", 1, true)) and not G.turkceMi((metin:gsub("Kuşanınca: ", ""):gsub("Vuruşta şans: ", "")))
			if metin and not onekli and metin:find("Kalan bekleme süresi: ", 1, true) and metin:find("%d+ %u?%l+s?") and metin:find("[%a][%a]+") then
				onekli = metin:find("%d+ [MSHD]%l*") ~= nil or metin:find("%d+ [mshd]%l+") ~= nil
			end
			if metin and metin ~= "" and not metin:find("|T") and (onekli or not G.turkceMi(metin)) and not cikti[metin] then
				local bas, govde, son = renkAyir(metin)
				local tr, tam, kalan = satirCevir(govde, buyuAdi ~= nil)
				if tr then
					fs:SetText(bas .. tr .. son); ciktiEkle(bas .. tr .. son)
					degisti = true
				end
				-- Kayıt: çevrilemeyen anlamlı satırlar
				if (not tr or tam == false) and G.ayar("kayit") and fs ~= adFs then
					local kayitMetni = kalan or govde
					if #kayitMetni > 3 and not kayitMetni:find('^"') then
						local sab = G.sablon(kayitMetni)
						if buyuAdi and G.ayar("buyu") then
							G.kaydetDiger("buyu", sab, buyuAdi)
						elseif esyaMi and G.ayar("ipucu") then
							G.kaydetDiger("ipucu", sab)
						end
					end
				end
			end
		end
	end
	if degisti then if G.ipucuSigdir then G.ipucuSigdir(tt) else tt:Show() end end
	for i = 1, tt:NumLines() do
		for _, taraf in ipairs({ "TextLeft", "TextRight" }) do
			local fs = _G[ad .. taraf .. i]
			if fs then fs._gtrSon = fs:GetText() end
		end
	end
	calisiyor = false
end
G.ipucuCevir = function(tt) local ok = pcall(ipucuCevir, tt); if not ok then calisiyor = false end end

G.basla(function()
	for _, ad in ipairs(HEDEFLER) do
		local tt = _G[ad]
		if tt then hedef[tt] = true end
	end
	-- Gömülü eşya ipuçları (dünya görevi ödül eşyası vb.): GameTooltip.ItemTooltip.Tooltip
	for _, kok in ipairs({ "GameTooltip", "ItemRefTooltip", "WorldMapTooltip", "EmbeddedItemTooltip" }) do
		local r = _G[kok]
		local it = r and r.ItemTooltip
		local t2 = it and (it.Tooltip or (it.GetObjectType and it.GetObjectType(it) == "GameTooltip" and it))
		if t2 and t2.GetName and t2:GetName() then hedef[t2] = true end
	end
	if _G.EmbeddedItemTooltip and _G.EmbeddedItemTooltip.GetName and _G.EmbeddedItemTooltipTooltip then hedef[_G.EmbeddedItemTooltipTooltip] = true end
	local kuruldu = false
	if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
		local turler = { Enum.TooltipDataType.Item, Enum.TooltipDataType.Spell }
		if Enum.TooltipDataType.Macro then turler[#turler + 1] = Enum.TooltipDataType.Macro end
		for _, tur in ipairs(turler) do
			if tur then
				TooltipDataProcessor.AddTooltipPostCall(tur, function(tt) G.ipucuCevir(tt) end)
				kuruldu = true
			end
		end
	end
	if not kuruldu then
		for tt in pairs(hedef) do
			if tt.HasScript and tt:HasScript("OnTooltipSetItem") then tt:HookScript("OnTooltipSetItem", G.ipucuCevir) end
			if tt.HasScript and tt:HasScript("OnTooltipSetSpell") then tt:HookScript("OnTooltipSetSpell", G.ipucuCevir) end
		end
	end
	-- Sağ üstteki buff/debuff simgeleri: ipucu her saniye yeniden yazılır
	for _, yontem in ipairs({ "SetUnitAura", "SetUnitBuff", "SetUnitDebuff", "SetPlayerBuff" }) do
		if GameTooltip[yontem] then
			hooksecurefunc(GameTooltip, yontem, function(tt) auraIpucu[tt] = true; G.ipucuCevir(tt) end)
		end
	end
	GameTooltip:HookScript("OnTooltipCleared", function(tt) auraIpucu[tt] = nil end)
	-- İpucunu dolduran tüm yöntemlerden hemen sonra çevir: çanta ve eylem düğmeleri ipucunu her an
	-- (bekleme süresi sayarken her saniye) yeniden yazıyor; çeviri aynı karede gelince titreme olmaz.
	local YAZICILAR = { "SetBagItem", "SetInventoryItem", "SetHyperlink", "SetMerchantItem", "SetBuybackItem", "SetLootItem",
		"SetLootRollItem", "SetQuestItem", "SetQuestLogItem", "SetTradeSkillItem", "SetCraftItem", "SetCraftSpell", "SetAuctionItem",
		"SetAuctionSellItem", "SetAction", "SetSpell", "SetSpellBookItem", "SetSpellByID", "SetItemByID", "SetInboxItem",
		"SetSendMailItem", "SetTradePlayerItem", "SetTradeTargetItem", "SetPetAction", "SetShapeshift", "SetTrainerService",
		"SetQuestLogRewardSpell", "SetQuestRewardSpell", "SetBagItemChild", "SetInventoryItemByID", "RefreshData" }
	for tt in pairs(hedef) do
		for _, y in ipairs(YAZICILAR) do
			if tt[y] then hooksecurefunc(tt, y, function(self) G.ipucuCevir(self) end) end
		end
	end
	-- Karşılaştırma ipucu: "If you replace this item..." ve "+16 Armor" satırları oyun tarafından
	-- eşya olayından SONRA ekleniyor ve ipucu sürekli yenileniyor. Bir kare sonra çevirmek titreme
	-- yapıyordu; bu yüzden aynı karede (Show ve OnUpdate içinde, çizimden önce) çeviriyoruz.
	-- OnUpdate'te sadece bir satır son çevirimizden sonra değiştiyse çalışır (ucuz kontrol).
	local function degistiMi(tt)
		local ad = tt:GetName(); if not ad then return false end
		for i = 1, tt:NumLines() do
			for _, taraf in ipairs({ "TextLeft", "TextRight" }) do
				local fs = _G[ad .. taraf .. i]
				if fs and fs:IsShown() then
					-- Retail: gizli değerler karşılaştırılamaz; böyle satırlara dokunmayız
					local t, s = fs:GetText(), fs._gtrSon
					if G.gizli(t) or G.gizli(s) then return false end
					if t ~= s then return true end
				end
			end
		end
		return false
	end
	for tt in pairs(hedef) do
		hooksecurefunc(tt, "Show", function(self) G.ipucuCevir(self) end)
		if tt.HookScript then tt:HookScript("OnUpdate", function(self) local ok, d = pcall(degistiMi, self); if ok and d then G.ipucuCevir(self) end end) end
	end
	-- Yetenek ağacı ve bazı özel ipuçları yukarıdaki olayları tetiklemeyebilir
	if GameTooltip.SetTalent then hooksecurefunc(GameTooltip, "SetTalent", function(tt) G.ipucuCevir(tt) end) end
end)
