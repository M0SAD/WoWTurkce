if not WoWTurkce.FOREVER then return end -- yalnızca Classic Forever
-- Classic Forever'a özel görevler 3
-- b=başlık, a=açıklama, h=hedef, i=ilerleme, t=tamamlama
-- k = çevrilen İngilizce metnin parmak izi (metin değişirse çeviri gösterilmez, yeniden kaydedilir)
local V = WoWTurkce.Veri

V[78124] = { b="Nar'thalas Almanağı", k={b=3342026480} }
V[78127] = { b="Dalaran Derlemesi", k={b=3162227545} }
V[78132] = { b="Ejderha Avcısının Miğferi", k={b=1209169353} }
V[78133] = { b="Ejderha Avcısının Kalkanı", k={b=2959367068} }
V[78134] = { b="Ejderha Avcısının Mızrağı", k={b=1252484870} }
V[78142] = { b="Büyüler ve Göz Boyamalar", k={b=2588699215} }
V[78143] = { b="Düş Görenlerin Sırları", k={b=2059474599} }
V[78145] = { b="Arkan Sistemler Kılavuzu", k={b=1225457420} }
V[78146] = { b="Goaz Parşömenleri", k={b=2457307448} }
V[78147] = { b="Anatomiye Karşı İşlenen Suçlar", k={b=2763499816} }
V[78149] = { b="Toprağın Öfkesi", k={b=937854048} }
V[78150] = { b="Kütüphanenin Dostu", k={b=3014007496} }
V[78261] = { b="Xelthos'un Borusu", h="Shadowfang Keep'in içinde Xelthos'un Borusu'nu bul. Ardından onu Pyrewood Village yakınlarındaki C'nin gizli teslim noktasına götür. Bu işi tek başına tamamlamalısın.", k={b=1076459289, h=725412528} }
V[78270] = { b="Goblin Maymuncukları", k={b=3488057219} }
V[78307] = { b="Xelthos'un Borusu", k={b=1076459289} }
V[78823] = { b="Çöl Göklerinin Dehşeti", h="İlkel Çizim'i Stranglethorn Vale'deki Hemet Nesingwary'ye götür.", k={b=3832934079, h=1731122596} }
V[79007] = { b="... ve bulduğun o not", h="Notun kömürleşmiş kalıntıları tek rehberin.", k={b=4061571960, h=3219166097} }
V[79091] = { b="Başbüyücü Antonidas: Kısaltılmamış Otobiyografi", k={b=2727033874} }
V[79093] = { b="Gnomeregan'lı Rumi: Toplu Eserler", k={b=2488867840} }
V[79094] = { b="Ta'zo'nun Dersleri", k={b=633856096} }
V[79096] = { b="Ataeric: Arkan Tuhaflıklar Üzerine", k={b=2265427448} }
V[79097] = { b="Baxtan: Yıkıcı Büyüler Üzerine", k={b=3610759398} }
V[79229] = { b="Yol Kesen Soygun", h="Desolace'ta yağmalanmış kamp yeri hakkında bilgisi olan birini bul.", k={b=2361060011, h=593768583} }
V[79362] = { b="Grant'in Kalkanı", h="Raven Hill Cemetery'deki iskeletlerden birinin üzerinde Grant'in Topuzu'nu bul, ardından daha fazla bilgi için Darkshire'daki Sirra Von'Indie'ye dön.", k={b=3110329997, h=3082987093} }
V[79363] = { b="Silvia'nın Kılıcı", h="Addle's Stead'de 7 Defias Night Blade ve 7 Defias Enchanter'ı alt et, ardından daha fazla bilgi için Darkshire'daki Sirra Von'Indi'ye dön.", k={b=2504269615, h=181304810} }
V[79535] = { b="Basilisk'ler: Taşlaşmaktan Korkmalı mı?", k={b=3194798744} }
V[79947] = { b="Yer Büyüsü: Taş Gibi Soğuk Gerçek", k={b=712093211} }
V[79948] = { b="Savunma Büyülerine Giriş", k={b=3966344676} }
V[79949] = { b="Bir Yalanlar Ağı: Efsaneleri ve Mitleri Çürütmek", k={b=400072359} }
V[79950] = { b="Şeytanlar ve Sen", k={b=1387406011} }
V[79951] = { b="Mumyalar: Tatsız Ölümsüzler İçin Bir Rehber", k={b=3873674509} }
V[79952] = { b="RwlRwlRwlRwl!", k={b=364406425} }
V[79953] = { b="Teknoloji Düşmanları İçin Şeytani Evcil Hayvan Bakım Rehberi", k={b=1579389411} }
V[79976] = { b="Burası Olmalı", h="Burada her kim idiyse, onları kıl payı kaçırdın.", k={b=4170470195, h=1467359402} }
V[80001] = { b="Yeniden Alevlendir", k={b=285220851} }
V[81947] = { b="Kanlı Büyücülük", k={b=2970926662} }
V[81949] = { b="Gelgit Bilgelerinin Efsaneleri", k={b=1684319894} }
V[81951] = { b="Eşik ve Arkan", k={b=475699242} }
V[81952] = { b="Gündelik Görgü Kuralları", k={b=2402921544} }
V[81953] = { b="Taş İşçiliği Tasarımı", k={b=3117821688} }
V[81954] = { b="Zehirli Yolculuklar", k={b=3452869696} }
V[81955] = { b="Metalden Bir Zihin", k={b=53732150} }
V[81956] = { b="Büyücünün Kodeksi", k={b=3935080179} }
V[84395] = { b="Ölümsüz Patatesler", k={b=3554161093} }
V[84396] = { b="Magma mı, Lav mı?", k={b=3892739789} }
V[84397] = { b="Kuzey Kalimdor: Kapsamlı Bir Rehber", k={b=1372928879} }
V[84398] = { b="Işık Üzerine Bir İnceleme", k={b=1871613773} }
V[84399] = { b="Ka-Bum!", k={b=143256830} }
V[84400] = { b="Şövalye ve Leydi", k={b=2321942889} }
V[84401] = { b="Scourge: Ölümsüz Tehdit mi, Yanlış Anlaşılan mı?", k={b=2187304264} }
V[84402] = { b="Nekromansiye Giriş", k={b=2215363270} }
V[87318] = { b="Kayıpların Kalpleri", h="Corma'nın yol arkadaşı Essene'i ara.", k={b=3962612964, h=466971398} }
V[87491] = { b="Özgürlük Kıvılcımı", h="Tutsak ateş elementaline Dun Modr'dan çıkıp özgürlüğüne kavuşana dek eşlik et.", k={b=1693100541, h=1868480973} }
V[88756] = { b="Patlamayı Geri Getir", h="Dark Iron Dwarf kamplarından 3 Çalınmış Patlayıcı'yı geri al.", k={b=4147834529, h=1962963996} }
V[88757] = { b="Kayıpların Eşyaları", h="Essene'in Kolyesi'ni, Essene'in Büyü Kitabı'nı ve Essene'in Su Matarası'nı geri getir.", k={b=1198728465, h=3792805430} }
V[88758] = { b="Kayıpların Duyguları", h="Essene'in notunu Corma Villard'a götür.", k={b=2149642055, h=1178328151} }
V[91723] = { b="Hassas Aletler", h="Jasperlode Mine'da 8 Kobold Geomancer öldür, ardından Tower of Azora'daki Hamish Bergwort'a dön.", k={b=1039324588, h=1469002148} }
V[91724] = { b="Hassas Aletler", h="Stone Cairn Lake'te 6 Defias Rogue Wizard öldür, ardından Tower of Azora'daki Hamish Bergwort'a dön.", k={b=1039324588, h=857708500} }
V[91725] = { b="Çalınan Efsun Malzemeleri", h="Stone Cairn Lake çevresindeki gnoll kamplarından 5 Çalınmış Efsun Malzemesi topla, ardından Tower of Azora yakınlarındaki Blixie Fitzwink'e dön.", k={b=4148916398, h=4193582744} }
V[91732] = { b="Sağlam Çelik", h="Jasperlode Mine'dan 4 Madencilik Aleti topla, ardından Eastvale Logging Camp'teki Hagar Lowe'a dön.", k={b=2464145195, h=278643448} }
V[91733] = { b="Akıntı Yönünde", h="Eastvale Logging Camp'ten akıntıyla sürüklenen Islanmış Balta'yı, Islanmış Testere'yi ve Islanmış Alet Kutusu'nu topla, ardından Ormin Pelford'a dön.", k={b=1184380841, h=2182394039} }
V[91736] = { b="Elma Rakısı İmbiği", k={b=105440408} }
V[91738] = { b="Bir Elma İkramı", k={b=2072811974} }
V[91740] = { b="Croaky'nin Kafası", h="Croaky'nin Kafası'nı Ridgepoint Tower'daki Merell Ross'a teslim et.", k={b=2702345747, h=3338118084} }
V[91741] = { b="Kemirilmiş Kitap", h="Kitabı Rahip Paxton'a geri götür.", k={b=2890847933, h=65999684} }
V[91899] = { b="Mühürlü Bir Sandık", k={b=2211706083} }
V[91900] = { b="Mühürlü Bir Sandık", k={b=2211706083} }
V[91901] = { b="Mühürlü Bir Sandık", k={b=2211706083} }
V[91904] = { b="Mühürlü Bir Sandık", k={b=2211706083} }
V[91905] = { b="Mühürlü Bir Sandık", k={b=2211706083} }
V[93862] = { b="Sandık İadesi", k={b=3959365524} }
V[95041] = { b="Veri İstifçileri", h="Gnomeregan'ın dört bir yanından 7 Gnomeregan Arşiv Verisi kartı topla, ardından onları Ironforge'daki Jemma Quikswitch'e teslim et.", k={b=1032795287, h=2920836537} }
V[95212] = { b="Kaliteden Ödün Yok", h="6 Kusursuz Leopar Postu topla ve onları Amberstill Ranch'e teslim et.", k={b=591248088, h=2256767496} }
V[95213] = { b="Çalınan Patlayıcı Barut", h="Boş Barut Fıçısı'nı Gol'Bolar Quarry'deki Ocak Ustası Thesten'e götür.", k={b=1832790271, h=2631959560} }
V[95214] = { b="Çalınan Patlayıcı Barut", h="Gol'Bolar Quarry'nin doğusundaki trogg'lardan 16 Çalınmış Patlayıcı Barut'u geri al, ardından Ocak Ustası Thesten'e dön.", k={b=1832790271, h=3921893532} }
V[95217] = { b="Taş Ocağının Demircisi", h="12 Bakır Külçe ve 4 Sertleşmiş Yaban Domuzu Postu topla ve onları Frast Dokner'e teslim et.", k={b=2592525986, h=1617222892} }
V[95775] = { b="Batık Şehir", h="Batık Şehir'de bulunan tabletlerin izlerini çıkarmak için postu ve kömürü kullan.", k={b=3020093682, h=769766869} }
V[95776] = { b="Tek İyi Brinescale...", h="Batık Şehir'de Var'Taka'yı öldür.", k={b=1687225065, h=1321923916} }
V[96136] = { b="Havanın Çağrısı", h="Thousand Needles'ta Prate Cloudseer'ı bul.", k={b=12510674, h=1492734213} }
V[96137] = { b="Ira'nın Hançeri", h="10 Young Black Ravager ve 7 Black Ravager'ı alt et, ardından daha fazla bilgi için Darkshire'daki Sirra Von'Indi'ye dön.", k={b=3340898974, h=3578693465} }
V[96138] = { b="Merrick'in Yayı", h="8 Splint Fist Warrior ve 4 Splint Fist Taskmaster'ı alt et, ardından daha fazla bilgi için Darkshire'daki Sirra Von'Indi'ye dön.", k={b=3794531277, h=2358671158} }
V[96139] = { b="Valor Ailesi", h="Raven Hill'de ilgi çekici herhangi bir şey ara ve Darkshire'daki Sirra Von'Indi'ye dön.", k={b=1180526380, h=386140750} }
V[96243] = { b="Toprağın Çağrısı", h="Dun Morogh'da Teo Hammerstorm'u bul.", k={b=743682218, h=3759788391} }
V[96264] = { b="Elementlerin Yardımı", h="Razorfen Kraul'da Charlga Razorflank'i alt et ve quilboar'ların planları hakkında bilgi topla.", k={b=2081955754, h=3018474884} }
V[96390] = { b="Daha Filizlenmeden", h="Dun Morogh'da 10 Dark Iron Spy öldür.", k={b=906575473, h=1908208167} }
V[96391] = { b="Yeraltı Haritası", h="Dark Iron Haritası'nı Dun Morogh'daki Toprak Kâhini Farsen'e teslim et.", k={b=1371302352, h=3711601592} }
V[96392] = { b="Farsen'in Gözcülüğü", h="Toprak Kâhini Farsen ile konuş ve Dark Iron tehdidini gözlemlemek için uzak görüşünü sana ödünç vermesini iste.", k={b=3770085966, h=1229586293} }
V[96395] = { b="Kadim Bir Kin", h="Faldrim Anvilmar'ın ruhunu huzura kavuştur, ardından Hall of Thanes'teki Hayalet Hizmetkâr'a dön.", k={b=2532088596, h=3196016973} }
V[96408] = { b="Dun Morogh'a Bir Ziyaretçi", h="Gol'Bolar Quarry'ye tepeden bakan kamp yerini araştır.", k={b=1995034860, h=889825061} }
V[96774] = { b="Kadim Gurubashi Putu", h="Batık Şehir'den Kadim bir Gurubashi Putu'nu geri getir.", k={b=1426044121, h=192672319} }
V[97243] = { b="Ateşin Çağrısı", h="Uyuyan Alev Meşalesi'ni Gustberry Lowlands'teki Shrine of Flames'te bulunan Olariaan Swiftburn'e götür.", k={b=413032028, h=76297188} }
V[97244] = { b="Ateşin Çağrısı", h="Gustberry Lowlands'te Gök Rahibi Faladiel'i öldür ve Faladiel'in Kalbi'ni topla.", k={b=413032028, h=740687123} }
V[97245] = { b="Ateşin Çağrısı", h="Shen'dar Highlands'te Kuramaa'nın yuvasını bul ve ruhu dövüşte yen. Zafer kazandığında Kuramaa'nın Maskesi'ni Gustberry Lowlands'teki Olariaan Swiftburn'e götür.", k={b=413032028, h=2079549575} }
V[97257] = { b="Ateşin Çağrısı", h="Olariaan'ın Adak Mangalı'nda ayini başlatmasını bekle ve talimatlarına uy.$BSüre dolmadan Ebedi Alev'i Valanaar'a ulaştırmalısın.", k={b=413032028, h=3271374635} }
V[98072] = { b="Göklerin Timsahları", h="8 Kusursuz Kızıl Pul topla ve onları Menethil Harbor'daki James Halloran'a götür.", k={b=3568585516, h=3350471529} }
V[98189] = { b="Heykelciği Geri Ver", h="Menethil Heykelciği'ni Menethil Keep'teki Kaptan Stoutfist'e götür.", k={b=2438934921, h=2179984027} }
V[98197] = { b="Savaş Ganimetleri", h="Valstag Ironjaw için Menethil Harbor'dan 6 Khaz Modan Kerestesi ve 30 Khaz Modan Demiri geri al.", k={b=2408151486, h=3417334199} }
V[98208] = { b="Göklerin Çiçeği", h="Menethil Harbor'daki Sylessa Duskwhisper için Nord'el'i geri getir.", k={b=259935038, h=3367290734} }
V[98209] = { b="Göklerin Çiçeği", h="Nord'el'i Darkshore'daki Auberdine'de bulunan Thundris Windweaver'a götür.$BSylessa'nın, Menethil Harbor'daki bir geminin seni oraya götürebileceğinden bahsettiğini hatırlıyorsun.", k={b=259935038, h=870429327} }
V[98216] = { b="Bugünümüzü Anlamak", h="Goaz Taşı'nı Goaz Warder'ın yakınında kullan ve onun Titan Kilit Taşı'nı Maden Arayıcısı Whelgar'a getir.", k={b=2325958226, h=1167643468} }
V[98221] = { b="Küllerden", h="Menethil Keep'teki Kaptan Stoutfist, Angerfang Encampment'taki 4 takım Saldırı Planı'nı yok etmeni istiyor.", k={b=3701868302, h=3319439179} }
V[98223] = { b="Eski Alışkanlıklar", h="Yıpranmış Büyü Kitabı'nı Menethil Harbor'daki Kaptan Stoutfist'e götür.", k={b=725772767, h=1803695843} }
V[98230] = { b="Bu Topraklar Onlarındı", h="Menethil Harbor'un doğusunda, yol boyunca Howin Kindfeather'ı bul.", k={b=1401356194, h=2623891230} }
V[98240] = { b="Kızıl Sandık Teslimatı", h="Kızıl Sandık'ı Menethil Harbor'un doğusunda, yolun biraz dışındaki Howin Kindfeather'a götür.", k={b=3249574995, h=3428120683} }
V[98245] = { b="Razormaw Sataşması", h="Howin Kindfeather için 10 Razormaw Kesici Dişi topla.", k={b=3405045950, h=3196931354} }
V[98246] = { b="Zor Zamanlar", h="Howin Kindfeather için 12 Kusursuz Razormaw Yumurtası topla.", k={b=673858276, h=2709929462} }
V[98282] = { b="Simyasal Tehlikeler", h="Menethil Harbor'daki Caitlin Grassman için Thelgen Rock'tan Patlamamış bir Sinsi Bezi topla.", k={b=3822540245, h=3267278640} }
V[98283] = { b="Carnage", h="Carnage'ın Kafası'nı The Green Belt'teki Yeşil Muhafız Rethiel'e götür.", k={b=3004589686, h=2530624736} }
V[98291] = { b="Dragonmaw'a Ölüm", h="Howin Kindfeather için Dragonmaw Retreat'te 8 Dragonmaw Reclaimer, 5 Dragonmaw Soulbinder ve 3 Dragonmaw Infiltrator öldür.", k={b=3385341199, h=688141269} }
V[98293] = { b="Zorla Silahsızlandırma", h="Dragonmaw Retreat'te 30 Dragonmaw Silahı topla, ardından onları Menethil Keep'teki Kaptan Stoutfist'e götür.", k={b=981082413, h=1925649405} }
V[98297] = { b="Döngüyü Durdurmak", h="Howin Kindfeather için Dragonmaw Gates'teki Subdued Dragonspawn'ı öldür.", k={b=2666208394, h=3941472893} }
V[98310] = { b="Geleceğimizi Derlemek", h="Goaz Taşı'nı Ados, Modr, Golm ve Neru'nun yakınında kullan ve onların kalplerini Maden Arayıcısı Whelgar'a getir.", k={b=1753377947, h=2842224863} }
V[98319] = { b="Dağı Güvenceye Al", h="Dağcı Gretchen için Grizzled Den'de Dağcı Cornelius'u bul.", k={b=977582616, h=3127403033} }
V[98321] = { b="Flintfire'ın Sevkiyatı", h="Kharanos'taki Tongus Flintfire için Grizzled Den'den 8 Flintfire Sevkiyatı topla.", k={b=2589399843, h=1043369424} }
V[98322] = { b="Dağı Güvenceye Al", h="Kharanos'un batısındaki Dağcı Gretchen'ın durumunu kontrol et.", k={b=977582616, h=915207229} }
V[98323] = { b="Dağı Güvenceye Al", h="Dağcı Gretchen'ın Raporu'nu Kharanos'taki Senir Whitebeard'a teslim et.", k={b=977582616, h=421938328} }
V[98326] = { b="Frosthowl", h="Frosthowl'u öldür ve Brewnall Village'daki Gretta Ganter için Balık Çuvalı'nı topla.", k={b=103939853, h=1285196034} }
V[98338] = { b="REUSE ME", k={b=1062056315} }
V[98372] = { b="Talihsiz Bir Son", k={b=2539590374} }
V[98423] = { b="Anlaşma Antlaşması", h="Anlaşma Antlaşması'nı Ironforge'daki Magni Bronzebeard'a teslim et.", k={b=3559284714, h=923115796} }
V[98459] = { b="Erdem Eksikliği", h="Tom'un Hediyesi'ni Wetlands'teki Menethil Harbor'da bulunan Bart Tidewater'a teslim et.", k={b=638592629, h=2742698391} }
V[98461] = { b="Karşılıksız Aşk", h="Hollee'nin Notu'nu Wetlands'te Menethil Harbor yakınlarındaki Tarrel Rockweaver'a teslim et.", k={b=1717486849, h=3986135372} }
V[98517] = { b="Ateşin Çağrısı", h="Shaman eğitimine devam etmek için Zephras Isle'daki Sessaria Skystride'a ya da Aarnor Galestrike'a rapor ver. Zephras'a, Mulgore'da Thunder Bluff'ın kuzeybatısındaki Skywatcher Plateau'ya yanaşan gök kesici nakliye aracıyla dönebilirsin.", k={b=413032028, h=3488780793} }
V[98581] = { b="Kadim Rün", h="Kadim Rün'ü oku ve Anvilmar'da Teo Hammerstorm ile konuş.", k={b=1847325066, h=1381372633} }
V[99158] = { b="Dağlarda Şafak", h="Mum sandığını Misty Pine Refuge'daki Peder Gavin'e götür.", k={b=1987099077, h=2618277661} }
V[99159] = { b="Sıcaklık Arayışı", h="14 parça yakacak odun topla.", k={b=1666502615, h=3786586077} }
V[99160] = { b="Kırağının Gazabı", h="10 küçük buz elementalini yok et.", k={b=3575204043, h=3633136144} }
V[99161] = { b="Kırağının Gazabı", h="Avala'yı öldür ve çekirdeğini geri getir.", k={b=3575204043, h=301637736} }
V[99162] = { b="Hain Soğuk", h="Düşmüş dağcıların tüfeklerini topla.", k={b=2955232140, h=1550937714} }
V[99267] = { b="Talihsiz Bir Son", k={b=2539590374} }
