-- Oyunda yakalanan yeni arayüz metinlerinin çevirileri ("çevir" akışı bu dosyanın sonuna ekler).
-- ekle() mevcut çeviriyi ezmez; düzeltmek için en alttaki "Düzeltmeler" bölümünde doğrudan ata.
-- Biçim: ekle(A, "English text", "Türkçe")  (sayılar # ve {1} {2})   A = arayüz, H = hata/bilgi mesajı
local G = WoWTurkce
local function ekle(t, k, v) if t and k ~= nil and t[k] == nil then t[k] = v end end
local A, H, EG = G.Arayuz, G.Hata, G.Egitim

-- Düzeltmeler
