local _, addonTbl = ...
local L = addonTbl.API:NewLocale("BigWigs", "enUS")

L.tempRenameFeat = "Artık her boss yeteneğini gelişmiş ayarlarını (>>) açıp yeniden adlandırma sekmesine tıklayarak |cFF436EEEyeniden adlandırabilirsiniz|r."

-- API.lua
L.showAddonBar = "'|cFF436EEE%s|r' eklentisi '%s' çubuğunu oluşturdu."
L.requestAddonProfile = "'|cFF436EEE%s|r' eklentisi, |cFF33FF99'%s'|r adlı profilinizin dışa aktarma metninin bir kopyasını aldı."
L.shortMinutesAndSeconds = "%d Dk %d Sn" -- 1 Minute 2 Seconds
L.shortSecondsOnly = "%d Sn" -- 28 Seconds
L.shortSubTenSeconds = "%.1f Sn" -- 3.2 Seconds
L.accept = "Kabul Et"
L.cancel = "İptal"
L.confirm_profile_swap = "|cFF436EEE\"%s\"|r eklentisi BigWigs profilinizi otomatik olarak şu profile değiştirmek istiyor:\n\n|cFF33FF99\"%s\"|r\n\nBunu yapmak istediğinize emin misiniz?"

-- Core.lua
L.berserk = "Öfkelenme"
L.berserk_desc = "Bossun ne zaman öfkeleneceği için bir çubuk ve zamanlı uyarılar göster."
L.altpower = "Alternatif güç göstergesi"
L.altpower_desc = "Grup üyelerinizin alternatif güç miktarını gösteren alternatif güç penceresini göster."
L.infobox = "Bilgi Kutusu"
L.infobox_desc = "Savaşla ilgili bilgileri içeren bir kutu göster."
L.stages = "Aşamalar"
L.stages_desc = "Aşama değişim uyarıları, aşama süresi çubukları gibi boss savaşının aşamalarıyla ilgili işlevleri etkinleştir."
L.warmup = "Isınma"
L.warmup_desc = "Boss savaşının başlamasına kalan süre."
L.proximity = "Yakınlık göstergesi"
L.proximity_desc = "Bu savaşta gerektiğinde, size çok yakın duran oyuncuları listeleyen yakınlık penceresini göster."
L.adds = "Ek Düşmanlar"
L.adds_desc = "Boss savaşında doğacak ek düşmanlarla ilgili işlevleri etkinleştir."
L.health = "Can"
L.health_desc = "Boss savaşında çeşitli can bilgilerini gösteren işlevleri etkinleştir."
L.energy = "Enerji"
L.energy_desc = "Boss savaşında çeşitli enerji seviyeleri hakkında bilgi gösteren işlevleri etkinleştir."

L.already_registered = "|cffff0000UYARI:|r |cff00ff00%s|r (|cffffff00%s|r) BigWigs'te zaten bir modül olarak var, ama bir şey onu tekrar kaydetmeye çalışıyor. Bu genelde bir eklenti güncelleyici hatası nedeniyle eklentiler klasörünüzde bu modülün iki kopyası olduğu anlamına gelir. Tüm BigWigs klasörlerini silip baştan kurmanız önerilir."

-- Loader / Options.lua
L.okay = "Tamam"
L.officialRelease = "BigWigs %s (%s) resmi sürümünü kullanıyorsunuz."
L.alphaRelease = "BigWigs %s (%s) ALFA SÜRÜMÜNÜ kullanıyorsunuz."
L.sourceCheckout = "BigWigs %s sürümünü doğrudan depodan kaynak olarak kullanıyorsunuz."
L.littlewigsOfficialRelease = "LittleWigs (%s) resmi sürümünü kullanıyorsunuz."
L.littlewigsAlphaRelease = "LittleWigs (%s) ALFA SÜRÜMÜNÜ kullanıyorsunuz."
L.littlewigsSourceCheckout = "LittleWigs'i doğrudan depodan kaynak olarak kullanıyorsunuz."
L.guildRelease = "Loncanız için yapılmış BigWigs %d sürümünü kullanıyorsunuz (resmi eklentinin %d sürümüne dayalı)."
L.getNewRelease = "BigWigs'iniz eski (/bwv) ama CurseForge İstemcisi ile kolayca güncelleyebilirsiniz. Ya da curseforge.com veya addons.wago.io üzerinden elle güncelleyebilirsiniz."
L.warnTwoReleases = "BigWigs'iniz 2 sürüm geride! Sürümünüzde hatalar, eksik özellikler veya tamamen yanlış zamanlayıcılar olabilir. Güncellemeniz şiddetle önerilir."
L.warnSeveralReleases = "|cffff0000BigWigs'iniz %d sürüm geride!! Diğer oyuncularla eşitleme sorunlarını önlemek için güncellemenizi ŞİDDETLE öneririz!|r"
L.warnOldBase = "BigWigs'in lonca sürümünü (%d) kullanıyorsunuz, ama temel sürümünüz (%d) %d sürüm geride. Bu sorunlara yol açabilir."

L.tooltipHint = "Seçenekler için |cffeda55fSağ Tık|r."
L.activeBossModules = "Etkin boss modülleri:"

L.oldVersionsInGroup = "Grubunuzda BigWigs'in |cffff0000eski sürümlerini|r kullananlar var. /bwv ile daha fazla ayrıntı alabilirsiniz."
L.upToDate = "Güncel:"
L.outOfDate = "Eski:"
L.dbmUsers = "DBM kullanıcıları:"
L.noBossMod = "Boss modu yok:"
L.offline = "Çevrimdışı"

L.missingAddOnPopup = "|cFF436EEE%s|r eklentisi eksik!"
L.missingAddOnRaidWarning = "|cFF436EEE%s|r eklentisi eksik! Bu bölgede zamanlayıcı gösterilmeyecek!"
L.outOfDateAddOnPopup = "|cFF436EEE%s|r eklentisi eski!"
L.outOfDateAddOnRaidWarning = "|cFF436EEE%s|r eklentisi eski! Sizde v%d.%d.%d var ama en yenisi v%d.%d.%d!"
L.disabledAddOn = "|cFF436EEE%s|r eklentisi kapalı, zamanlayıcılar gösterilmeyecek."
L.removeAddOn = "Lütfen '|cFF436EEE%s|r' eklentisini kaldırın, yerini '|cFF436EEE%s|r' aldı."
L.outOfDateContentPopup = "UYARI!\n|cFF436EEE%s|r güncellediniz ama ana |cFF436EEEBigWigs|r eklentisini de güncellemeniz gerekiyor.\nBunu yok saymak işlevlerin bozulmasına yol açar."
L.outOfDateContentRaidWarning = "|cFF436EEE%s|r doğru çalışmak için ana |cFF436EEEBigWigs|r eklentisinin %d sürümünü gerektiriyor, ama sizde %d sürümü var."
L.addOnLoadFailedWithReason = "BigWigs |cFF436EEE%s|r eklentisini %q nedeniyle yükleyemedi. BigWigs geliştiricilerine bildirin!"
L.addOnLoadFailedUnknownError = "BigWigs |cFF436EEE%s|r eklentisini yüklerken hatayla karşılaştı. BigWigs geliştiricilerine bildirin!"
L.newFeatures = "Yeni BigWigs özellikleri:"
L.parentheses = "%s (%s)"

L.expansionNames = {
	"Classic", -- Classic
	"The Burning Crusade", -- The Burning Crusade
	"Wrath of the Lich King", -- Wrath of the Lich King
	"Cataclysm", -- Cataclysm
	"Mists of Pandaria", -- Mists of Pandaria
	"Warlords of Draenor", -- Warlords of Draenor
	"Legion", -- Legion
	"Battle for Azeroth", -- Battle for Azeroth
	"Shadowlands", -- Shadowlands
	"Dragonflight", -- Dragonflight
	"The War Within", -- The War Within
	"Midnight", -- Midnight
}
L.littleWigsExtras = {
	["LittleWigs_Delves"] = "Delves",
	["LittleWigs_CurrentSeason"] = "Güncel Sezon",
}
L.dayNamesShort = {
	"SUN", -- Sunday
	"MON", -- Monday
	"TUE", -- Tuesday
	"WED", -- Wednesday
	"THU", -- Thursday
	"FRI", -- Friday
	"SAT", -- Saturday
}
L.dayNames = {
	"Sunday",
	"Monday",
	"Tuesday",
	"Wednesday",
	"Thursday",
	"Friday",
	"Saturday",
}
L.monthNames = {
	"January",
	"February",
	"March",
	"April",
	"May",
	"June",
	"July",
	"August",
	"September",
	"October",
	"November",
	"December",
}
L.dateFormat = "%s %d %s %d" -- Date format: "Monday 1 January 2025"

-- Media.lua (These are the names of the sounds in the dropdown list in the "sounds" section)
L.Beware = "Beware (Algalon)"
L.FlagTaken = "Flag Taken (PvP)"
L.Destruction = "Destruction (Kil'jaeden)"
L.RunAway = "Run Away Little Girl (Big Bad Wolf)"
L.spell_on_you = "BigWigs: Büyü sende"
L.spell_under_you = "BigWigs: Büyü altında"
L.simple_no_voice = "Basit (Sessiz)"

-- Options.lua
L.options = "Seçenekler"
L.optionsKey = "ID: %s" -- The ID that messages/bars/options use
L.raidBosses = "Raid Boss'ları"
L.dungeonBosses = "Zindan Boss'ları"
L.introduction = "Boss savaşlarının dolaştığı BigWigs'e hoş geldiniz. Lütfen kemerlerinizi bağlayın, fıstıklarınızı yiyin ve yolculuğun tadını çıkarın. Çocuklarınızı yemez, ama yeni boss savaşını Raid grubunuz için 7 çeşit bir akşam yemeği gibi hazırlamanıza yardım eder."
L.sound = "Ses"
L.minimapIcon = "Minimap simgesi"
L.minimapToggle = "Minimap simgesini göster/gizle."
L.compartmentMenu = "Bölme simgesi yok"
L.compartmentMenu_desc = "Bu seçeneği kapatmak BigWigs'in eklenti bölmesi menüsünde görünmesini sağlar. Bu seçeneği açık bırakmanızı öneririz."
L.configure = "Ayarla"
L.resetPositions = "Konumları sıfırla"
L.selectEncounter = "Savaş seç"
L.primary_aura_spellId = "Birincil büyü kimliği: %d"
L.secondary_aura_spellIds = "İkincil büyü kimlik(ler)i: %s"
L.auraDispelType = "Arındırma türü: %s"
L.auraDispel_magic = "Büyü"
L.auraDispel_curse = "Lanet"
L.auraDispel_disease = "Hastalık"
L.auraDispel_poison = "Zehir"
L.auraDispel_bleed = "Kanama"
L.auraMechanic = "Mekanik: %s"
L.auraMechanic_charmed = "Büyülenmiş"
L.auraMechanic_disoriented = "Yönünü Şaşırmış"
L.auraMechanic_disarmed = "Silahsızlanmış"
L.auraMechanic_distracted = "Dikkati Dağılmış"
L.auraMechanic_fleeing = "Kaçıyor"
L.auraMechanic_knockbacked = "Geri İtilmiş"
L.auraMechanic_rooted = "Kökleşmiş"
L.auraMechanic_slowed = "Yavaşlamış"
L.auraMechanic_silenced = "Susturulmuş"
L.auraMechanic_asleep = "Uyuyor"
L.auraMechanic_snared = "Tuzağa Düşmüş"
L.auraMechanic_stunned = "Sersemlemiş"
L.auraMechanic_frozen = "Donmuş"
L.auraMechanic_incapacitated = "Etkisiz"
L.auraMechanic_bleeding = "Kanıyor"
L.auraMechanic_healing = "İyileşiyor"
L.auraMechanic_polymorphed = "Dönüştürülmüş"
L.auraMechanic_banished = "Sürgün Edilmiş"
L.auraMechanic_shielded = "Kalkanlı"
L.auraMechanic_shackled = "Zincirlenmiş"
L.auraMechanic_mounted = "Binekte"
L.auraMechanic_infected = "Enfekte"
L.auraMechanic_turned = "Döndürülmüş"
L.auraMechanic_horrified = "Dehşete Düşmüş"
L.auraMechanic_invulnerable = "Hasar Almaz"
L.auraMechanic_interrupted = "Kesildi"
L.auraMechanic_dazed = "Sersem"
L.auraMechanic_discovery = "Keşif"
L.auraMechanic_sapped = "Bayıltılmış"
L.auraMechanic_enraged = "Öfkeli"
L.auraMechanic_wounded = "Yaralı"
L.auraMechanic_taunted = "Kışkırtılmış"
L.onApplied = "Uygulanınca"
L.onDose = "Yığınlanınca"
L.onRemoved = "Kalkınca"
L.listAbilities = "Yetenekleri grup sohbetinde listele"
L.parenthesesID = "%s |cffA5A5A5(ID: %s)|r"

L.dbmFaker = "DBM kullanıyormuşum gibi göster"
L.dbmFakerDesc = "Bir DBM kullanıcısı kimin DBM kullandığını görmek için sürüm kontrolü yaparsa sizi listede görür. DBM kullanımını zorunlu tutan loncalar için kullanışlıdır."
L.zoneMessages = "Bölge mesajlarını göster"
L.zoneMessagesDesc = "Bunu kapatmak, BigWigs'in zamanlayıcısı olan ama kurmadığınız bir bölgeye girdiğinizde mesaj göstermeyi durdurur. Açık bırakmanızı öneririz; yararlı bulacağınız yeni bir bölge için zamanlayıcı eklediğimizde alacağınız tek bildirim budur."
L.englishSayMessages = "Yalnızca İngilizce söyleme mesajları"
L.englishSayMessagesDesc = "Boss savaşında sohbete gönderdiğiniz tüm 'söyleme' ve 'bağırma' mesajları her zaman İngilizce olur. Karışık dilli bir oyuncu grubundaysanız işe yarar."

L.slashDescTitle = "|cFFFED000Eğik Çizgi Komutları:|r"
L.slashDescPull = "|cFFFED000/pull:|r Raidinize çekme geri sayımı gönderir."
L.slashDescBreak = "|cFFFED000/break:|r Raidinize mola zamanlayıcısı gönderir."
L.slashDescRaidBar = "|cFFFED000/raidbar:|r Raidinize özel bir çubuk gönderir."
L.slashDescLocalBar = "|cFFFED000/localbar:|r Yalnızca sizin görebileceğiniz özel bir çubuk oluşturur."
L.slashDescRange = "|cFFFED000/range:|r Menzil göstergesini açar."
L.slashDescVersion = "|cFFFED000/bwv:|r BigWigs sürüm kontrolü yapar."
L.slashDescConfig = "|cFFFED000/bw:|r BigWigs ayarlarını açar."

L.gitHubDesc = "|cFF33FF99BigWigs, GitHub'da barındırılan açık kaynaklı bir yazılımdır. Bize yardım edecek yeni insanlar arıyoruz; herkes kodumuzu incelemeye, katkı yapmaya ve hata bildirmeye davetlidir. BigWigs'in bugünkü hâli büyük ölçüde bize yardım eden harika WoW topluluğu sayesindedir.|r"

L.BAR = "Çubuklar"
L.MESSAGE = "Mesajlar"
L.ICON = "Simge"
L.SAY = "Söyle"
L.FLASH = "Yanıp Sönme"
L.EMPHASIZE = "Vurgula"
L.ME_ONLY = "Yalnızca bende olunca"
L.ME_ONLY_desc = "Bu seçeneği açarsanız bu yeteneğin mesajları yalnızca sizi etkilediğinde gösterilir. Örneğin 'Bomba: Oyuncu' yalnızca sizdeyse gösterilir."
L.PULSE = "Nabız"
L.PULSE_desc = "Ekranı yanıp söndürmenin yanında, dikkatinizi çekmek için bu yetenekle ilgili bir simgeyi ekranın ortasında kısa süre gösterebilirsiniz."
L.MESSAGE_desc = "Çoğu savaş yeteneğinin BigWigs'in ekranda gösterdiği bir veya daha fazla mesajı vardır. Bu seçeneği kapatırsanız bu seçeneğe bağlı mesajların hiçbiri gösterilmez."
L.BAR_desc = "Bazı savaş yetenekleri için uygun olduğunda çubuklar gösterilir. Bu yeteneğin gizlemek istediğiniz bir çubuğu varsa bu seçeneği kapatın."
L.FLASH_desc = "Bazı yetenekler diğerlerinden daha önemli olabilir. Bu yetenek yaklaşırken veya kullanıldığında ekranın yanıp sönmesini istiyorsanız bu seçeneği işaretleyin."
L.ICON_desc = "BigWigs yeteneklerden etkilenen karakterleri bir simgeyle işaretleyebilir. Böylece daha kolay fark edilirler."
L.SAY_desc = "Sohbet balonları kolay fark edilir. BigWigs sizdeki bir etkiyi yakındakilere duyurmak için söyleme mesajı kullanır."
L.EMPHASIZE_desc = "Bunu açmak bu yetenekle ilgili tüm mesajları vurgular; daha büyük ve görünür yapar. Vurgulu mesajların boyutunu ve yazı tipini ana seçeneklerde \"Mesajlar\" altında ayarlayabilirsiniz."
L.PROXIMITY = "Yakınlık göstergesi"
L.PROXIMITY_desc = "Yetenekler bazen dağılmanızı gerektirir. Yakınlık göstergesi bu yetenek için özel ayarlanır; böylece güvende olup olmadığınızı bir bakışta anlayabilirsiniz."
L.ALTPOWER = "Alternatif güç göstergesi"
L.ALTPOWER_desc = "Bazı savaşlar grubunuzdaki oyuncularda alternatif güç mekaniği kullanır. Alternatif güç göstergesi kimin en az/en çok alternatif güce sahip olduğunu hızlıca gösterir; belirli taktikler veya görevler için yararlıdır."
L.TANK = "Yalnızca Tank"
L.TANK_desc = "Bazı yetenekler yalnızca tanklar için önemlidir. Rolünüzden bağımsız olarak bu yeteneğin uyarılarını görmek istiyorsanız bu seçeneği kapatın."
L.HEALER = "Yalnızca Şifacı"
L.HEALER_desc = "Bazı yetenekler yalnızca şifacılar için önemlidir. Rolünüzden bağımsız olarak bu yeteneğin uyarılarını görmek istiyorsanız bu seçeneği kapatın."
L.TANK_HEALER = "Yalnızca Tank ve Şifacı"
L.TANK_HEALER_desc = "Bazı yetenekler yalnızca tanklar ve şifacılar için önemlidir. Rolünüzden bağımsız olarak bu yeteneğin uyarılarını görmek istiyorsanız bu seçeneği kapatın."
L.DISPEL = "Yalnızca Arındıran"
L.DISPEL_desc = "Bu yeteneği arındıramadığınızda bile uyarılarını görmek istiyorsanız bu seçeneği kapatın."
L.VOICE = "Ses Paketi"
L.VOICE_desc = "Bir ses eklentisi kuruluysa bu seçenek, uyarıyı sesli okuyan bir ses dosyası çalmasını sağlar."
L.COUNTDOWN = "Geri Sayım"
L.COUNTDOWN_desc = "Açıksa son 5 saniye için sesli ve görsel bir geri sayım eklenir. Ekranın ortasında büyük bir sayıyla birinin \"5... 4... 3... 2... 1...\" diye saydığını düşünün."
L.CASTBAR_COUNTDOWN = "Geri Sayım (yalnızca büyü çubukları)"
L.CASTBAR_COUNTDOWN_desc = "Açıksa büyü çubuklarının son 5 saniyesi için sesli ve görsel bir geri sayım eklenir."
L.INFOBOX = L.infobox
L.INFOBOX_desc = L.infobox_desc
L.SOUND = L.sound
L.SOUND_desc = "Boss yetenekleri genellikle fark etmeniz için ses çalar. Bu seçeneği kapatırsanız ona bağlı seslerin hiçbiri çalmaz."
L.CASTBAR = "Büyü Çubukları"
L.CASTBAR_desc = "Bazı bosslarda, genelde gelen kritik bir yeteneğe dikkat çekmek için büyü çubukları gösterilir. Bu yeteneğin gizlemek istediğiniz bir büyü çubuğu varsa bu seçeneği kapatın."
L.SAY_COUNTDOWN = "Söyleme Geri Sayımı"
L.SAY_COUNTDOWN_desc = "Sohbet balonları kolay fark edilir. BigWigs sizdeki bir yeteneğin bitmek üzere olduğunu yakındakilere bildirmek için geri sayan birden çok söyleme mesajı kullanır."
L.ME_ONLY_EMPHASIZE = "Vurgula (yalnızca ben)"
L.ME_ONLY_EMPHASIZE_desc = "Bunu açmak bu yetenekle ilgili mesajları YALNIZCA size yapıldığında vurgular; daha büyük ve görünür yapar."
L.NAMEPLATE = "İsim Plakaları"
L.NAMEPLATE_desc = "Açıksa bu yetenekle ilgili simge ve yazı gibi özellikler isim plakalarınızda görünür. Böylece birden çok NPC aynı yeteneği yaptığında hangisinin yaptığını görmek kolaylaşır."
L.PRIVATE = "Özel Aura"
L.PRIVATE_desc = "Bu ayarlar yalnızca genel büyü uyarıları ve çubukları içindir!\n\nBu yetenek sizi hedef aldığında çalacak sesi, sağ üstteki \"Savaş seç\" menüsünden \"Özel Aura Sesleri\" seçerek değiştirebilirsiniz."

L.advanced_options = "Gelişmiş seçenekler"
L.back = "<< Geri"

L.tank = "|cFFFF0000Yalnızca tank uyarıları.|r "
L.healer = "|cFFFF0000Yalnızca şifacı uyarıları.|r "
L.tankhealer = "|cFFFF0000Yalnızca tank ve şifacı uyarıları.|r "
L.dispeller = "|cFFFF0000Yalnızca arındıran uyarıları.|r "

L.renames = "Yeniden Adlar"
L.noteLabel = "%s (|cFFFFFF99%s|r)"
L.renameLabel = "%s (|cFF3366FF%s|r)"
L.renameHeader = "Yetenek için özel bir ad belirleyin. Bu metin tüm mesajlarda ve çubuklarda büyü adı yerine kullanılır.\n\n"
L.spellName = "Büyü Adı"
L.spellNameResetDesc = "Bu yeteneğin varsayılan olarak özel bir adı var; asıl adı (genelde büyü adı) kullanmak için bu düğmeye tıklayın."

-- Sharing.lua
L.import = "İçe Aktar"
L.import_info = "Bir metin girdikten sonra hangi ayarları içe aktarmak istediğinizi seçebilirsiniz.\nİçe aktarma metninde olmayan ayarlar seçilemez."
L.import_info_active = "İçe aktarmak istediğiniz bölümleri seçip içe aktar düğmesine tıklayın."
L.import_info_none = "|cFFFF0000İçe aktarma metni uyumsuz veya eski.|r"
L.export = "Dışa Aktar"
L.export_core = "Çekirdeği Dışa Aktar"
L.export_info = "Dışa aktarıp başkalarıyla paylaşmak istediğiniz ayarları seçin.\n\n|cffff4411Yalnızca genel ayarlar paylaşılabilir ve bunların bossa özel ayarlara etkisi yoktur.|r"
L.export_string = "Dışa Aktarma Metni"
L.export_string_desc = "Ayarlarınızı paylaşmak istiyorsanız bu BigWigs metnini kopyalayın."
L.import_string = "İçe Aktarma Metni"
L.import_string_desc = "İçe aktarmak istediğiniz BigWigs metnini buraya yapıştırın."
L.position = "Konum"
L.settings = "Ayarlar"
L.other_settings = "Diğer Ayarlar"
L.nameplate_settings_import_desc = "Tüm isim plakası ayarlarını içe aktar."
L.nameplate_settings_export_desc = "Tüm isim plakası ayarlarını dışa aktar."
L.position_import_bars_desc = "Çubukların konumunu (bağlantı noktalarını) içe aktar."
L.position_import_messages_desc = "Mesajların konumunu (bağlantı noktalarını) içe aktar."
L.position_import_countdown_desc = "Geri sayımın konumunu (bağlantı noktalarını) içe aktar."
L.position_export_bars_desc = "Çubukların konumunu (bağlantı noktalarını) dışa aktar."
L.position_export_messages_desc = "Mesajların konumunu (bağlantı noktalarını) dışa aktar."
L.position_export_countdown_desc = "Geri sayımın konumunu (bağlantı noktalarını) dışa aktar."
L.settings_import_bars_desc = "Boyut, yazı tipi gibi genel çubuk ayarlarını içe aktar."
L.settings_import_messages_desc = "Boyut, yazı tipi gibi genel mesaj ayarlarını içe aktar."
L.settings_import_countdown_desc = "Ses, boyut, yazı tipi gibi genel geri sayım ayarlarını içe aktar."
L.settings_export_bars_desc = "Boyut, yazı tipi gibi genel çubuk ayarlarını dışa aktar."
L.settings_export_messages_desc = "Boyut, yazı tipi gibi genel mesaj ayarlarını dışa aktar."
L.settings_export_countdown_desc = "Ses, boyut, yazı tipi gibi genel geri sayım ayarlarını dışa aktar."
L.colors_import_bars_desc = "Çubukların renklerini içe aktar."
L.colors_import_messages_desc = "Mesajların renklerini içe aktar."
L.color_import_countdown_desc = "Geri sayımın rengini içe aktar."
L.colors_export_bars_desc = "Çubukların renklerini dışa aktar."
L.colors_export_messages_desc = "Mesajların renklerini dışa aktar."
L.color_export_countdown_desc = "Geri sayımın rengini dışa aktar."
L.confirm_import = "İçe aktarmak üzere olduğunuz seçili ayarlar, şu an seçili profilinizdeki ayarların üzerine yazacak:\n\n|cFF33FF99\"%s\"|r\n\nBunu yapmak istediğinize emin misiniz?"
L.confirm_import_addon = "|cFF436EEE\"%s\"|r eklentisi, şu an seçili BigWigs profilinizin üzerine yazacak yeni BigWigs ayarlarını otomatik olarak içe aktarmak istiyor:\n\n|cFF33FF99\"%s\"|r\n\nBunu yapmak istediğinize emin misiniz?"
L.confirm_import_addon_new_profile = "|cFF436EEE\"%s\"|r eklentisi otomatik olarak şu adda yeni bir BigWigs profili oluşturmak istiyor:\n\n|cFF33FF99\"%s\"|r\n\nBu yeni profili kabul etmek ona geçiş de yapar."
L.confirm_import_addon_edit_profile = "|cFF436EEE\"%s\"|r eklentisi BigWigs profillerinizden birini otomatik olarak düzenlemek istiyor:\n\n|cFF33FF99\"%s\"|r\n\nBu değişiklikleri kabul etmek ona geçiş de yapar."
L.no_string_available = "İçe aktarılacak kayıtlı metin yok. Önce bir metin içe aktarın."
L.no_import_message = "Hiçbir ayar içe aktarılmadı."
L.import_success = "İçe aktarıldı: %s" -- Imported: Bar Anchors, Message Colors
L.imported_bar_positions = "Çubuk Konumları"
L.imported_bar_settings = "Çubuk Ayarları"
L.imported_bar_colors = "Çubuk Renkleri"
L.imported_message_positions = "Mesaj Konumları"
L.imported_message_settings = "Mesaj Ayarları"
L.imported_message_colors = "Mesaj Renkleri"
L.imported_countdown_position = "Geri Sayım Konumu"
L.imported_countdown_settings = "Geri Sayım Ayarları"
L.imported_countdown_color = "Geri Sayım Rengi"
L.imported_nameplate_settings = "İsim Plakası Ayarları"
L.imported_mythicplus_settings = "Mythic+ Ayarları"
L.mythicplus_settings_import_desc = "Tüm Mythic+ ayarlarını içe aktar."
L.mythicplus_settings_export_desc = "Tüm Mythic+ ayarlarını dışa aktar."
L.imported_battleres_settings = "Savaş Diriltmesi Ayarları"
L.battleres_settings_import_desc = "Tüm Savaş Diriltmesi ayarlarını içe aktar."
L.battleres_settings_export_desc = "Tüm Savaş Diriltmesi ayarlarını dışa aktar."
L.imported_combattimer_settings = "Savaş Zamanlayıcısı Ayarları"
L.combattimer_settings_import_desc = "Tüm Savaş Zamanlayıcısı ayarlarını içe aktar."
L.combattimer_settings_export_desc = "Tüm Savaş Zamanlayıcısı ayarlarını dışa aktar."
L.confirm_export_disabled_plugin = "|cFF33FF99\"%s\"|r sizde kapalı.\n\nDışa aktarmak, bu metni içe aktaran herkes için bu özelliği |cffff8000kullanmak istese bile|r zorla kapatır.\n\nBunu yapmak istediğinize emin misiniz?"
L.confirm_import_disabled_plugin = "İçe aktarmak üzere olduğunuz ayarlarda |cFF33FF99\"%s\"|r kapalı.\n\nİçe aktarmak bunu sizin için de kapatır.\n\nBunu yapmak istediğinize emin misiniz?"
L.export_bosses = "Bossları Dışa Aktar"
L.export_bosses_info = "Aşağıda seçilen bölgelerdeki tüm bossların yapılandırması dışa aktarılacak."
L.raids_section = "Raidler"
L.expansion_dungeons_section = "Genişleme Zindanları"
L.seasonal_dungeons_section = "Sezonluk Zindanlar"
L.confirm_import_addon_boss_settings = "|cFF436EEE\"%s\"|r eklentisi şu bölgelerdeki tüm bosslar için BigWigs boss ayarlarınızı otomatik olarak değiştirmek istiyor:\n\n|cFFFFFF99%s|r\n\nBu, şu profile uygulanacak:\n\n|cFF33FF99\"%s\"|r\n\nBunu yapmak istediğinize emin misiniz?"

-- InstanceSharing.lua
L.sharing_window_title = "Boss Ayarlarını Paylaş"
L.sharing_flags = "Genel Ayarlar"
L.sharing_flags_desc = "'Çubuk göster', 'ses çal', 'mesaj göster' gibi şeyleri denetleyen ayarları içe aktar.\nBunlar bir yeteneğin ayarlarındaki çoğu onay kutusunu kapsar."
L.sharing_export_flags_desc = "'Çubuk göster', 'ses çal', 'mesaj göster' gibi şeyleri denetleyen ayarları dışa aktar.\nBunlar bir yeteneğin ayarlarındaki çoğu onay kutusunu kapsar."
L.sharing_renames_desc = "Ayarlanmış özel yeniden adları içe aktar."
L.sharing_export_renames_desc = "Ayarlanmış özel yeniden adları dışa aktar."
L.sharing_sounds_desc = "Yetenekler için çalınacak sesleri içe aktar."
L.sharing_export_sounds_desc = "Yetenekler için çalınacak sesleri dışa aktar."
L.sharing_auras_desc = "Ayarlanmış aura seslerini içe aktar."
L.sharing_export_private_auras_desc = "Ayarlanmış Özel Aura seslerini dışa aktar."
L.sharing_colors_desc = "Çubuklar ve mesajlar için renk ayarlarını içe aktar."
L.sharing_export_colors_desc = "Çubuklar ve mesajlar için renk ayarlarını dışa aktar."
L.confirm_instance_import = "İçe aktarmak üzere olduğunuz seçili ayarlar, şu an seçili profilinizdeki ayarların üzerine yazacak:\n\n|cFF33FF99\"%s\"|r\n\nZindan:\n|cFFBB66FF\"%s\"|r\n\nBunu yapmak istediğinize emin misiniz?"
L.status_text_paste_import = "Geçerli bir içe aktarma metni yapıştırın"
L.exporting_instance = "|cFFBB66FF%s|r dışa aktarılıyor" -- Exporting Molten Core
L.importing_instance = "|cFFBB66FF%s|r içe aktarılıyor" -- Importing Molten Core
L.share = "Paylaş"

-- Statistics
L.statistics = "İstatistikler"
L.defeat = "Yenilgi"
L.defeat_desc = "Bu boss savaşında toplam yenilgi sayınız."
L.victory = "Zafer"
L.victory_desc = "Bu boss savaşında toplam zafer sayınız."
L.fastest = "En Hızlı"
L.fastest_desc = "En hızlı zafer ve tarihi. (Yıl/Ay/Gün)"
L.first = "İlk"
L.first_desc = "Bu boss savaşındaki ilk zaferiniz, şu biçimde:\n[İlk zaferden önceki yenilgi sayısı] - [Savaş süresi] - [Zaferin Yıl/Ay/Günü]"

-- Difficulty levels for statistics display on bosses
L.unknown = "Bilinmiyor"
L.LFR = "LFR"
L.normal = "Normal"
L.heroic = "Kahramanlık"
L.mythic = "Mythic"
L.LFR_timerun = "|A:timerunning-glues-icon:14:14|aLFR"
L.normal_timerun = "|A:timerunning-glues-icon:14:14|aNormal"
L.heroic_timerun = "|A:timerunning-glues-icon:14:14|aHeroic"
L.mythic_timerun = "|A:timerunning-glues-icon:14:14|aMythic"
L.timewalk = "Timewalking"
L.solotier8 = "Solo Tier 8"
L.solotier11 = "Solo Tier 11"
L.story = "Hikâye"
L.mplus = "Mythic+ %d"
L.SOD = "Season of Discovery"
L.hardcore = "Hardcore"
L.level1 = "Seviye 1"
L.level2 = "Seviye 2"
L.level3 = "Seviye 3"
L.N10 = "Normal 10"
L.N25 = "Normal 25"
L.H10 = "Heroic 10"
L.H25 = "Heroic 25"
L.titan = "Titan" -- Chinese-only "Titan Reforged" servers
L.mythic_flex = "Mythic (Flex)" -- Mythic (Flexible 15-25 player raids)
L.world = "Dünya" -- World (The first difficulty for Lairs in Retail WoW, essentially the same as LFR since its World -> Normal -> Heroic -> Mythic)

-----------------------------------------------------------------------
-- TOOLS
-----------------------------------------------------------------------

L.tools = "Araçlar"
L.toolsDesc = "BigWigs, boss savaşlarını hızlandırmak ve kolaylaştırmak için çeşitli araçlar veya \"kolaylık\" özellikleri sunar."

L.reloadUIWarning = "Bu özelliği değiştirmek arayüzünüzü yeniler ve kısa süre yükleme ekranı gösterir. Emin misiniz?"
L.qualityOfLife = "Kolaylıklar"
L.notYetImplemented = "Henüz Eklenmedi" -- When a feature hasn't been implemented yet

-----------------------------------------------------------------------
-- AutoInvite.lua
--

L.autoInviteTitle = "Otomatik Davet"
L.autoInviteDesc = "Aşağıdaki listeden belirli bir anahtar kelimeyi size fısıldayan oyuncuları otomatik olarak grubunuza davet et."
L.yes = "Evet"
L.no = "Hayır"
L.addWords = "Kelime Ekle"
L.removeWords = "Kelime Kaldır (Silmek İçin Tıkla)"
L.invalidWordWarning = "Kelime küçük harfle yazılmalı ve listede olmamalı."
L.groupIsFullConvertToRaid = "Grup dolu. Raide çevrilsin mi?"
L.whisperToPlayerMyGroupIsFull = "[BigWigs] My group is now full."
L.keywordDetectedInvitingPlayer = "Anahtar kelime algılandı, %s davet ediliyor."

-----------------------------------------------------------------------
-- AutoRole.lua
--

L.autoRoleTitle = "Otomatik Rol"
L.autoRoleExplainer = "Bir gruba katıldığınızda veya gruptayken yetenek uzmanlığınızı değiştirdiğinizde BigWigs grup rolünüzü (Tank, Şifacı, Hasar) otomatik olarak buna göre ayarlar.\n\n"

-----------------------------------------------------------------------
-- BattleRes.lua
--

L.battleResTitle = "Savaş Diriltmesi"
L.battleResDesc = "Kaç savaş diriltmesi hakkı olduğunu ve yeni hakka kalan süreyi gösteren bir simge."
L.battleResDesc2 = "\nSimgenin üzerine gelince ipucunda |cFF33FF99Savaş Diriltmesi Geçmişinizi|r görebilirsiniz.\nNot: İpucu yalnızca savaş dışındayken görünür.\n\n"
L.battleResHistory = "Savaş Diriltmesi Geçmişi:"
L.battleResResetAll = "Tüm Savaş Diriltmesi ayarlarını varsayılanlarına döndür."
L.battleResDurationText = "Süre Yazısı"
L.battleResChargesText = "Hak Yazısı"
L.battleResNoCharges = "0 hak var"
L.battleResHasCharges = "1 veya daha fazla hak var"
L.battleResPlaySound = "Yeni hak kazanıldığında ses çal"
L.iconTextureSpellID = "|T%d:0:0:0:0:64:64:4:60:4:60|t Simge Dokusu (Büyü Kimliği)"
L.iconTextureSpellIDError = "Simge dokusu olarak kullanmak için geçerli bir büyü kimliği yazmalısınız."
L.battleResModeIcon = "Mod: Simge"
L.battleResModeText = "Mod: Yalnızca Yazı"
L.battleResModeTextTooltip = "Savaş Diriltmesi özelliğini taşımanıza ve fare alanını görmenize yardım için geçici bir arka plan gösteriliyor."

-----------------------------------------------------------------------
-- CombatTimer.lua
--

L.combatTimerTitle = "Savaş Zamanlayıcısı"
L.anyCombatTimer = "Genel Savaş Zamanlayıcısı"
L.anyCombatTimerDesc = "Ne kadar süredir savaşta olduğunuzu gösteren, savaş geçmişi için ipucu olan bir zamanlayıcı."
L.anyCombatTimerTooltip = "|TInterface\\\\AddOns\\\\BigWigs\\\\Media\\\\Icons\\\\minimap_raid:0:0|tSavaş Geçmişi"
L.bossCombatTimer = "Boss Savaş Zamanlayıcısı"
L.bossCombatTimerDesc = "Bir boss savaşında ne kadar süredir olduğunuzu gösteren, boss savaş geçmişi için ipucu olan bir zamanlayıcı."
L.bossCombatTimerTooltip = "|TInterface\\\\AddOns\\\\BigWigs\\\\Media\\\\Icons\\\\minimap_raid:0:0|tBoss Savaş Geçmişi"
L.bossStagesTimer = "Boss Aşama Zamanlayıcısı"
L.bossStagesTimerDesc = "Boss savaşı her aşama değiştirdiğinde sıfırlanan, aşama geçmişi için ipucu olan bir zamanlayıcı. Yalnızca çok aşamalı bosslarda etkindir."
L.bossStagesTimerTooltip = "|TInterface\\\\AddOns\\\\BigWigs\\\\Media\\\\Icons\\\\minimap_raid:0:0|tBoss Aşama Geçmişi"
L.instanceTimer = "Zindan Zamanlayıcısı"
L.instanceTimerDesc = "Bir zindanda (zindan/Raid vb.) ne kadar süredir olduğunuzu gösteren, zindan geçmişi için ipucu olan bir zamanlayıcı."
L.instanceTimerTooltip = "|TInterface\\\\AddOns\\\\BigWigs\\\\Media\\\\Icons\\\\minimap_raid:0:0|tZindan Geçmişi"

L.backgroundColor = "Arka Plan Rengi"
L.inactive = "Etkin Değil"
L.whenInactive = "Etkin Değilken"
L.doNothing = "Hiçbir Şey Yapma"
L.hide = "Gizle"
L.colorFade = "Renk/Soldur"
L.inProgress = "Sürüyor"
L.textFormat = "Yazı Biçimi"
L.tooltipHistoryMaxLines = "Geçmiş: En Fazla Satır"
L.tooltipHistoryMaxLinesDesc = "İpucunun kaç satır geçmiş göstereceğini seçin."
L.tooltipHistoryResetConditions = "Geçmiş: Sıfırlama Koşulları"
L.tooltipHistoryResetConditionsDesc = "İpucu geçmişinin ne zaman sıfırlanacağına dair koşulları seçin."
L.enteringRaid = "Raide girerken"
L.enteringDungeon = "Zindana girerken"
L.startingMythicKeystone = "Mythic+ başlarken"
L.historyTimeFormat = "Geçmiş: Saat Biçimi"
L.twelveHour = "12 Saat"
L.twentyFourHour = "24 Saat"
L.hideTooltipInCombat = "Savaşta İpucunu Gizle"
L.customText = "Özel Yazı (%s içermeli)"

-----------------------------------------------------------------------
-- Keystones.lua
--

L.keys = "Anahtarlar"

L.keystoneTitle = "BigWigs Keystones"
L.keystoneHeaderParty = "Grup"
L.keystoneRefreshParty = "Grubu Yenile"
L.keystoneHeaderGuild = "Lonca"
L.keystoneRefreshGuild = "Loncayı Yenile"
L.keystoneLevelTooltip = "Keystone seviyesi: |cFFFFFFFF%s|r"
L.keystoneMapTooltip = "Zindan: |cFFFFFFFF%s|r"
L.keystoneRatingTooltip = "Mythic+ puanı: |cFFFFFFFF%d|r"
L.keystoneHiddenTooltip = "Oyuncu bu bilgiyi gizlemeyi seçti."
L.keystoneTabOnline = "Çevrimiçi"
L.keystoneTabAlts = "Diğer Karakterler"
L.keystoneTabTeleports = "Işınlanmalar"
L.keystoneHeaderMyCharacters = "Karakterlerim"
L.keystoneTeleportNotLearned = "'|cFFFFFFFF%s|r' ışınlanma büyüsü henüz |cFFFF4411öğrenilmedi|r."
L.keystoneTeleportOnCooldown = "'|cFFFFFFFF%s|r' ışınlanma büyüsü %d saat %d dakika daha |cFFFF4411bekleme süresinde|r."
L.keystoneTeleportReady = "'|cFFFFFFFF%s|r' ışınlanma büyüsü |cFF33FF99hazır|r, yapmak için tıklayın."
L.keystoneTeleportInCombat = "Savaştayken buraya ışınlanamazsınız."
L.keystoneTabHistory = "Geçmiş"
L.keystoneHeaderThisWeek = "Bu Hafta"
L.keystoneHeaderOlder = "Daha Eski"
L.keystoneScoreGainedTooltip = "Kazanılan Puan: |cFFFFFFFF+%d|r\nZindan Puanı: |cFFFFFFFF%d|r"
L.keystoneCompletedTooltip = "Zamanında tamamlandı: |cFFFFFFFF%d dk %d sn|r\nSüre Sınırı: |cFFFFFFFF%d dk %d sn|r"
L.keystoneFailedTooltip = "Zamanında tamamlanamadı: |cFFFFFFFF%d dk %d sn|r\nSüre Sınırı: |cFFFFFFFF%d dk %d sn|r"
L.keystoneExplainer = "Mythic+ deneyimini iyileştirmek için çeşitli araçlar."
L.keystoneAutoSlot = "Keystone'u otomatik yerleştir"
L.keystoneAutoSlotDesc = "Keystone yuvasını açtığınızda keystone'unuzu otomatik olarak yuvaya yerleştir."
L.keystoneAutoSlotMessage = "%s otomatik olarak keystone yuvasına yerleştirildi."
L.keystoneAutoSlotFrame = "|TInterface\\\\AddOns\\\\BigWigs\\\\Media\\\\Icons\\\\minimap_raid:14:14|t Keystone Otomatik Yerleştirildi"
L.keystoneModuleName = "Mythic+"
L.keystoneStartBar = "%s +%d" -- Format is SHORT_DUNGEON_NAME +KEYSTONE_LEVEL e.g. "ROOK +12"
L.keystoneStartMessage = "%s +%d şimdi başlıyor!" -- Format is LONG_DUNGEON_NAME +KEYSTONE_LEVEL e.g. "The Rookery +12 begins now!"
L.keystoneCountdownExplainer = "Bir Mythic+ zindanı başlattığınızda geri sayım çalar. Hangi sesi duymak istediğinizi ve geri sayımın ne zaman başlayacağını seçin.\n\n"
L.keystoneCountdownBeginsDesc = "Geri sayım çalmaya başladığında Mythic+ başlangıç zamanlayıcısında ne kadar süre kalması gerektiğini seçin."
L.keystoneCountdownBeginsSound = "Mythic+ geri sayımı başlarken ses çal"
L.keystoneCountdownEndsSound = "Mythic+ geri sayımı biterken ses çal"
L.keystoneViewerTitle = "Keystone Görüntüleyici"
L.keystoneHideGuildTitle = "Keystone'umu lonca üyelerimden gizle"
L.keystoneHideGuildDesc = "|cffff4411Önerilmez.|r Bu özellik lonca üyelerinizin hangi keystone'a sahip olduğunuzu görmesini engeller. Grubunuzdaki herkes yine görebilir."
L.keystoneHideGuildWarning = "Lonca üyelerinizin keystone'unuzu görmesini kapatmak |cffff4411önerilmez|r.\n\nBunu yapmak istediğinize emin misiniz?"
L.keystoneAutoShowEndOfRun = "Mythic+ bitince göster"
L.keystoneAutoShowEndOfRunDesc = "Mythic+ zindanı bitince keystone görüntüleyiciyi otomatik göster.\n\n|cFF33FF99Grubunuzun hangi yeni keystone'ları aldığını görmenize yardım eder.|r"
L.keystoneViewerExplainer = "Keystone görüntüleyiciyi |cFF33FF99/key|r komutuyla veya aşağıdaki düğmeye tıklayarak açabilirsiniz.\n\n"
L.keystoneViewerOpen = "Keystone görüntüleyiciyi aç"
L.keystoneViewerKeybindingExplainer = "\n\nKeystone görüntüleyiciyi açmak için bir tuş ataması da yapabilirsiniz:\n\n"
L.keystoneViewerKeybindingDesc = "Keystone görüntüleyiciyi açmak için bir tuş ataması seçin."
L.keystoneClickToWhisper = "Fısıltı penceresi açmak için tıklayın"
L.keystoneClickToTeleportNow = "\nBuraya ışınlanmak için tıklayın"
L.keystoneClickToTeleportCooldown = "\nIşınlanılamaz, büyü bekleme süresinde"
L.keystoneClickToTeleportNotLearned = "\nIşınlanılamaz, büyü öğrenilmedi"
L.keystoneHistoryRuns = "%d Toplam"
L.keystoneHistoryRunsThisWeekTooltip = "Bu haftaki toplam zindan sayısı: |cFFFFFFFF%d|r"
L.keystoneHistoryRunsOlderTooltip = "Bu haftadan önceki toplam zindan sayısı: |cFFFFFFFF%d|r"
L.keystoneHistoryScore = "+%d Puan"
L.keystoneHistoryScoreThisWeekTooltip = "Bu hafta kazanılan toplam puan: |cFFFFFFFF+%d|r"
L.keystoneHistoryScoreOlderTooltip = "Bu haftadan önce kazanılan toplam puan: |cFFFFFFFF+%d|r"
L.keystoneTimeUnder = "|cFF33FF99-%02d:%02d|r"
L.keystoneTimeOver = "|cFFFF4411+%02d:%02d|r"
L.keystoneTeleportTip = "Doğrudan zindan girişine |cFF33FF99IŞINLANMAK|r için aşağıdaki zindan adına tıklayın."
L.keystoneTimerunner = "|A:timerunning-glues-icon:14:14|aBu bir timerunning karakteri." -- Note: Timerunning is a mode like "Legion Remix", it is NOT the same as Timewalking
L.keystoneSlashKeys = "|cFF33FF99/keys|r eğik çizgi komutunu da kaydet"
L.keystoneSlashKeystone = "|cFF33FF99/keystone|r eğik çizgi komutunu da kaydet"
L.unavailableWhilstInCombat = "Savaştayken kullanılamaz"

-- It doesn't really matter what you call it as long as it's recognizable and limited to ~6 characters
L.keystoneShortName_TheRookery = "ROOK"
L.keystoneShortName_DarkflameCleft = "DFC"
L.keystoneShortName_PrioryOfTheSacredFlame = "PRIORY"
L.keystoneShortName_CinderbrewMeadery = "BREW"
L.keystoneShortName_OperationFloodgate = "FLOOD"
L.keystoneShortName_TheaterOfPain = "TOP"
L.keystoneShortName_TheMotherlode = "ML"
L.keystoneShortName_OperationMechagonWorkshop = "WORK"
L.keystoneShortName_EcoDomeAldani = "ECODOME"
L.keystoneShortName_HallsOfAtonement = "HOA"
L.keystoneShortName_AraKaraCityOfEchoes = "ARAK"
L.keystoneShortName_TazaveshSoleahsGambit = "GAMBIT"
L.keystoneShortName_TazaveshStreetsOfWonder = "STREET"
L.keystoneShortName_TheDawnbreaker = "DAWN"
L.keystoneShortName_BlackRookHold = "BRH"
L.keystoneShortName_CourtOfStars = "COS"
L.keystoneShortName_DarkheartThicket = "DHT"
L.keystoneShortName_EyeOfAzshara = "EOA"
L.keystoneShortName_HallsOfValor = "HOV"
L.keystoneShortName_MawOfSouls = "MOS"
L.keystoneShortName_NeltharionsLair = "NL"
L.keystoneShortName_TheArcway = "ARCWAY"
L.keystoneShortName_VaultOfTheWardens = "VOTW"
L.keystoneShortName_ReturnToKarazhanLower = "LKARA"
L.keystoneShortName_ReturnToKarazhanUpper = "UKARA"
L.keystoneShortName_CathedralOfEternalNight = "COEN"
L.keystoneShortName_SeatOfTheTriumvirate = "SEAT"
L.keystoneShortName_WindrunnerSpire = "SPIRE"
L.keystoneShortName_MagistersTerrace = "MT"
L.keystoneShortName_MaisaraCaverns = "CAVERN"
L.keystoneShortName_NexusPointXenas = "XENAS"
L.keystoneShortName_AlgetharAcademy = "AA"
L.keystoneShortName_Skyreach = "SKY"
L.keystoneShortName_PitOfSaron = "PIT"
L.keystoneShortName_KingsRest = "KINGS"
L.keystoneShortName_TempleOfSethraliss = "TEMPLE"
L.keystoneShortName_RubyLifePools = "POOLS"
L.keystoneShortName_TheBlindingVale = "VALE"
L.keystoneShortName_VoidscarArena = "ARENA"
L.keystoneShortName_DenOfNalorakk = "DEN"
L.keystoneShortName_MurderRow = "MURDER"
L.keystoneShortName_AltarOfFangs = "ALTAR"

-- These short names are for the bar that shows during the Mythic+ countdown
-- Use the real dungeon names but make them shorter to fit on the bar better
L.keystoneShortName_TheRookery_Bar = "Rookery"
L.keystoneShortName_DarkflameCleft_Bar = "Darkflame"
L.keystoneShortName_PrioryOfTheSacredFlame_Bar = "Priory"
L.keystoneShortName_CinderbrewMeadery_Bar = "Cinderbrew"
L.keystoneShortName_OperationFloodgate_Bar = "Floodgate"
L.keystoneShortName_TheaterOfPain_Bar = "Theater"
L.keystoneShortName_TheMotherlode_Bar = "Motherlode"
L.keystoneShortName_OperationMechagonWorkshop_Bar = "Workshop"
L.keystoneShortName_EcoDomeAldani_Bar = "Eco-Dome"
L.keystoneShortName_HallsOfAtonement_Bar = "Halls"
L.keystoneShortName_AraKaraCityOfEchoes_Bar = "Ara-Kara"
L.keystoneShortName_TazaveshSoleahsGambit_Bar = "Gambit"
L.keystoneShortName_TazaveshStreetsOfWonder_Bar = "Streets"
L.keystoneShortName_TheDawnbreaker_Bar = "Dawnbreaker"
L.keystoneShortName_BlackRookHold_Bar = "Black Rook"
L.keystoneShortName_CourtOfStars_Bar = "Court"
L.keystoneShortName_DarkheartThicket_Bar = "Darkheart"
L.keystoneShortName_EyeOfAzshara_Bar = "Eye"
L.keystoneShortName_HallsOfValor_Bar = "Halls"
L.keystoneShortName_MawOfSouls_Bar = "Maw"
L.keystoneShortName_NeltharionsLair_Bar = "Lair"
L.keystoneShortName_TheArcway_Bar = "Arcway"
L.keystoneShortName_VaultOfTheWardens_Bar = "Vault"
L.keystoneShortName_ReturnToKarazhanLower_Bar = "Lower Kara"
L.keystoneShortName_ReturnToKarazhanUpper_Bar = "Upper Kara"
L.keystoneShortName_CathedralOfEternalNight_Bar = "Cathedral"
L.keystoneShortName_SeatOfTheTriumvirate_Bar = "Seat"
L.keystoneShortName_WindrunnerSpire_Bar = "Spire"
L.keystoneShortName_MagistersTerrace_Bar = "Terrace"
L.keystoneShortName_MaisaraCaverns_Bar = "Caverns"
L.keystoneShortName_NexusPointXenas_Bar = "Xenas"
L.keystoneShortName_AlgetharAcademy_Bar = "Academy"
L.keystoneShortName_Skyreach_Bar = "Skyreach"
L.keystoneShortName_PitOfSaron_Bar = "Çukur"
L.keystoneShortName_KingsRest_Bar = "Kings"
L.keystoneShortName_TempleOfSethraliss_Bar = "Temple"
L.keystoneShortName_RubyLifePools_Bar = "Pools"
L.keystoneShortName_TheBlindingVale_Bar = "Vale"
L.keystoneShortName_VoidscarArena_Bar = "Arena"
L.keystoneShortName_DenOfNalorakk_Bar = "Den"
L.keystoneShortName_MurderRow_Bar = "Murder"
L.keystoneShortName_AltarOfFangs_Bar = "Altar"

-- Instance Keys "Who has a key?"
L.instanceKeysTitle = "Kimde anahtar var?"
L.instanceKeysDesc = "Bir Mythic zindana girdiğinizde o zindan için keystone'u olan oyuncular liste olarak gösterilir.\n\n"
L.instanceKeysTest8 = "|cFF00FF98Monk:|r +8"
L.instanceKeysTest10 = "|cFFFF7C0ADruid:|r +10"
L.instanceKeysDisplay = "|c%s%s:|r +%d" -- "PLAYER_NAME: +DUNGEON_LEVEL"
L.instanceKeysDisplayWithDungeon = "|c%s%s:|r +%d (%s)" -- "PLAYER_NAME: +DUNGEON_LEVEL (DUNGEON_NAME)"
L.instanceKeysShowAll = "Her zaman tüm oyuncuları göster"
L.instanceKeysShowAllDesc = "Bu seçeneği açmak, keystone'ları bulunduğunuz zindana ait olmasa bile tüm oyuncuları listede gösterir."
L.instanceKeysOtherDungeonColor = "Diğer zindan rengi"
L.instanceKeysOtherDungeonColorDesc = "Bulunduğunuz zindana ait olmayan keystone'ları olan oyuncular için yazı rengini seçin."
L.instanceKeysEndOfRunDesc = "Varsayılan olarak liste yalnızca Mythic zindana girdiğinizde görünür. Bu seçeneği açmak listeyi Mythic+ bittiğinde de gösterir."
L.instanceKeysHideTitle = "Başlığı gizle"
L.instanceKeysHideTitleDesc = "\"Kimde anahtar var?\" başlığını gizle."

-- Challenges UI Decoration
L.partyRatingHeader = "|TInterface\\\\AddOns\\\\BigWigs\\\\Media\\\\Icons\\\\minimap_raid:0:0|tGrup Puanı"
L.dungeonScoreString = "|c%s%03d|r |cFFFFFFFF+%02d|r |cFF%s%02d:%02d|r |c%s(%s)|r"
L.dungeonScoreNoDataString = "|cFFFFFFFFVeri yok|r |c%s(%s)|r"
L.dungeonTeleportHeader = "|TInterface\\\\AddOns\\\\BigWigs\\\\Media\\\\Icons\\\\minimap_raid:0:0|tIşınlanma"

-- Progress %
L.progressPercent = "İlerleme %"
L.progressPercentDesc = "Öldürdüğünüz her NPC'den ne kadar Mythic+ ilerlemesi kazanacağınızı hesaplamaya yardım eden araçlar."
L.progressPercentTooltip = "Düşman NPC'lerin üzerine gelince ipuçlarında ilerleme % göster"
L.progressPercentTooltipText = {
	"|TInterface\\AddOns\\BigWigs\\Media\\Icons\\minimap_raid:0:0|tProgress: %s%%",
	"|TInterface\\AddOns\\BigWigs\\Media\\Icons\\minimap_raid:0:0|tProgress: %s%% (%d)",
	"|TInterface\\AddOns\\BigWigs\\Media\\Icons\\minimap_raid:0:0|tProgress: %s%% (%d/%d)",
}
L.progressPercentNameplate = "Düşman NPC'lerin isim plakalarında ilerleme % göster"
L.progressCurrentPull = "Mevcut Çekiş"
L.progressCurrentPullDesc = "Savaştığınız mevcut NPC grubundan kazanacağınız toplam ilerlemeyi göster.\n\nHENÜZ ÇALIŞMIYOR!"
L.settingsForCurrentTarget = "Mevcut hedefiniz için ayarlar"
L.settingsForOtherTargets = "Diğer tüm hedefler için ayarlar"

-----------------------------------------------------------------------
-- LFGTimer.lua
--

L.lfgTimerTitle = "LFG Zamanlayıcısı"
L.lfgTimerExplainer = "LFG sıra penceresi her açıldığında BigWigs, sırayı kabul etmek için ne kadar süreniz olduğunu gösteren bir zamanlayıcı çubuğu oluşturur.\n\n"
L.lfgUseMaster = "LFG hazır sesini 'Ana' ses kanalında çal"
L.lfgUseMasterDesc = "Bu seçenek açıkken LFG hazır sesi 'Ana' ses kanalından çalar. Kapatırsanız onun yerine '%s' ses kanalından çalar."

-----------------------------------------------------------------------
-- PLUGINS
-----------------------------------------------------------------------

L.general = "Genel"
L.advanced = "Gelişmiş"
L.comma = ", "
L.reset = "Sıfırla"
L.resetDesc = "Yukarıdaki ayarları varsayılanlarına döndür."
L.resetAll = "Hepsini sıfırla"
L.startTest = "Testi Başlat"
L.stopTest = "Testi Durdur"
L.always = "Her zaman"
L.never = "Asla"

L.positionX = "X Konumu"
L.positionY = "Y Konumu"
L.positionExact = "Tam Konumlandırma"
L.positionDesc = "Bağlantı noktasından tam konumlandırma gerekiyorsa kutuya yazın veya kaydırıcıyı oynatın."
L.copyCustomAnchorWidth = "Özel Bağlantı Genişliğini Kopyala"
L.copyCustomAnchorWidthDesc = "Genişlik ayarınızı özel bağlantı noktasının genişliğiyle değiştir."
L.width = "Genişlik"
L.height = "Yükseklik"
L.size = "Boyut"
L.sizeDesc = "Boyutu normalde bağlantı noktasını sürükleyerek ayarlarsınız. Tam boyut gerekiyorsa bu kaydırıcıyı kullanabilir veya değeri kutuya yazabilirsiniz."
L.fontSizeDesc = "Yazı boyutunu kaydırıcıyla ayarlayın veya en fazla 200'e kadar çıkan kutuya değeri yazın."
L.disabled = "Devre Dışı"
L.disableDesc = "|cffff4411Önerilmeyen|r '%s' özelliğini kapatmak üzeresiniz.\n\nBunu yapmak istediğinize emin misiniz?"
L.keybinding = "Tuş Ataması"
L.dragToResize = "Boyutlandırmak için sürükleyin"
L.cannotMoveInCombat = "Savaştayken bunu taşıyamazsınız."

-- Anchor Points / Grow Directions
L.UP = "Yukarı"
L.DOWN = "Aşağı"
L.TOP = "Üst"
L.RIGHT = "Sağ"
L.BOTTOM = "Alt"
L.LEFT = "Sol"
L.TOPRIGHT = "Sağ Üst"
L.TOPLEFT = "Sol Üst"
L.BOTTOMRIGHT = "Sağ Alt"
L.BOTTOMLEFT = "Sol Alt"
L.CENTER = "Orta"
L.CENTER_HORIZONTAL = "Yatay Orta"
L.CENTER_VERTICAL = "Dikey Orta"
L.customAnchorPoint = "Gelişmiş: Özel bağlantı noktası"
L.sourcePoint = "Kaynak Noktası"
L.destinationPoint = "Hedef Noktası"
L.drawStrata = "Katman"
L.medium = "Orta"
L.low = "Düşük"

-----------------------------------------------------------------------
-- AltPower.lua
--

L.altPowerTitle = "Alternatif Güç"
L.altPowerDesc = "Alternatif Güç göstergesi yalnızca oyunculara Alternatif Güç uygulayan bosslarda görünür; bu son derece nadirdir. Gösterge sizin ve grubunuzun 'Alternatif Güç' miktarını ölçüp bir listede gösterir. Göstergeyi taşımak için lütfen aşağıdaki test düğmesini kullanın."
L.toggleDisplayPrint = "Gösterge bir dahaki sefere görünecek. Bu savaş için tamamen kapatmak istiyorsanız savaş seçeneklerinden kapatmanız gerekir."
L.disabledDisplayDesc = "Göstergeyi kullanan tüm modüller için kapat."
L.resetAltPowerDesc = "Alternatif Güç bağlantı noktasının konumu dahil, Alternatif Güçle ilgili tüm seçenekleri sıfırla."
L.test = "Test"
L.altPowerTestDesc = "'Alternatif Güç' göstergesini göster; taşımanıza izin verir ve bir boss savaşında göreceğiniz güç değişimlerini taklit eder."
L.yourPowerBar = "Güç Çubuğunuz"
L.barColor = "Çubuk rengi"
L.barTextColor = "Çubuk yazı rengi"
L.additionalWidth = "Ek Genişlik"
L.additionalHeight = "Ek Yükseklik"
L.additionalSizeDesc = "Bu kaydırıcıyla standart göstergenin boyutuna ekleme yapın veya en fazla 100'e kadar çıkan kutuya değeri yazın."
L.yourPowerTest = "Gücünüz: %d" -- Your Power: 42
L.yourAltPower = "%s değeriniz: %d" -- e.g. Your Corruption: 42
L.player = "Oyuncu %d" -- Player 7
L.disableAltPowerDesc = "Alternatif Güç göstergesini genel olarak kapat; hiçbir boss savaşında görünmez."

-----------------------------------------------------------------------
-- Auras.lua
--

L.auras = "Auralar" -- Buffs/Debuffs
L.aurasDesc = "BigWigs, size uygulanan boss zayıflatmalarını simge olarak göstererek takip etmenize yardım edebilir.\n|cFF33FF99Kritik zayıflatmaları normal zayıflatmalarınızdan ayrı göstererek yardımcı olur.|r\n\n"
L.disabledDuringTrash = "Çöp Düşmanlarda Kapalı"

L.createTestAura = "Test Aurası Oluştur"
L.showDispelType = "Arındırma Türü Göstergesini Göster"
L.showDispelTypeDesc = "Auranın arındırma türü varsa üzerinde bir simge göster."
L.dispelType = "Arındırma Türü Göstergesi"
L.iconSize = "Simge Boyutu"
L.iconSpacing = "Simge Aralığı"
L.showCooldown = "Bekleme Spiralini Göster"
L.showCooldownText = "Bekleme Yazısını Göster"
L.cooldownDecimalsThreshold = "Ondalık Eşiği"
L.cooldownDecimalsThresholdDesc = "Kaç saniyenin altında ondalıkların gösterileceği."
L.cooldownTextScale = "Bekleme Yazısı Ölçeği"
L.growthDirection = "Simge Büyüme Yönü"
L.aurasOnYou = "Sizdeki Auralar"
L.aurasOnYouDesc = "Size uygulanan auraların simgelerini özelleştirin.\n\n"
L.aurasOnAnother = "Başkasındaki Auralar"
L.aurasOnAnotherDesc = "Belirli bir oyuncu seçin ve ona uygulanan auraların simgelerini özelleştirin.\n\n"
L.chooseAPlayer = "Bir oyuncu seçin"
L.theOtherTank = "Otomatik olarak bir tank bul"
L.theOtherTankDesc = "Boss zayıflatmalarını grubunuzda siz olmayan ilk tankta göster. (Şu an: %s)"
L.onlyWhenYouAreTank = "Yalnızca siz de tankken göster"
L.playerInYourGroup = "Grubunuzdaki bir oyuncu"
L.tankIndicator = "Tank Göstergesi"
L.maxIcons = "En Fazla Simge"
L.maxIconsDesc = "Gösterilecek en fazla simge sayısı."
L.aurasHelpTip = "|TInterface\\\\AddOns\\\\BigWigs\\\\Media\\\\Icons\\\\minimap_raid:0:0|tBigWigs: Artık boss zayıflatmalarınızı, hatta başka bir oyuncunun (örn. bir tankın) boss zayıflatmalarını simge olarak görebilirsiniz."

L.aurasTestAnchorText = "Oyuncu\nAuraları"
L.aurasTestTankAnchorText = "Tank\nAuraları"

L.auraSounds = "Aura Sesleri"
L.addAuraSpell = "Büyü Ekle"
L.addAuraSpellDesc = "Şu an bildiğiniz büyüleri adıyla ekleyebilirsiniz, ama kayıtlardan büyü kimliğini kullanmak her zaman en iyisidir."
L.invalidSpell = "Geçersiz büyü"
L.bossDebuffsOnYou = "Sizdeki Boss Zayıflatmaları"
L.bossDebuffsOnTank = "Tanktaki Boss Zayıflatmaları"
L.showCountText = "Yığınları Göster"
L.cooldownText = "Bekleme Süresi"
L.countText = "Uygulamalar"
L.selectPlayer = "Oyuncu Seç"
L.myself = "Kendim"
L.trigger = "Tetikleyici"
L.remove = "Kaldır"
L.currentUnit = "(Şu an: %s)"
L.throttle = "Sınırlama"
L.throttleDesc = "Aura her tetiklendiğinde bu sesin en sık ne aralıkla (saniye) çalabileceği. 0 ise aura her tetiklendiğinde ses çalar."

-----------------------------------------------------------------------
-- AutoReply.lua
--

L.autoReply = "Otomatik Yanıt"
L.autoReplyDesc = "Boss savaşındayken fısıltılara otomatik yanıt ver."
L.responseType = "Yanıt Türü"
L.autoReplyFinalReply = "Savaştan çıkarken de fısılda"
L.guildAndFriends = "Lonca ve Arkadaşlar"
L.everyoneElse = "Diğer herkes"

L.autoReplyBasic = "I'm busy in combat with a boss encounter."
L.autoReplyNormal = "I'm busy in combat with '%s'."
L.autoReplyAdvanced = "I'm busy in combat with '%s' (%s) and %d/%d people are alive."
L.autoReplyExtreme = "I'm busy in combat with '%s' (%s) and %d/%d people are alive: %s"

L.autoReplyLeftCombatBasic = "I am no longer in combat with a boss encounter."
L.autoReplyLeftCombatNormalWin = "I won against '%s'."
L.autoReplyLeftCombatNormalWipe = "I lost against '%s'."
L.autoReplyLeftCombatAdvancedWin = "I won against '%s' with %d/%d people alive."
L.autoReplyLeftCombatAdvancedWipe = "I lost against '%s' at: %s"

-----------------------------------------------------------------------
-- Bars.lua
--

L.bars = "Çubuklar"
L.style = "Stil"
L.bigWigsBarStyleName_Default = "Varsayılan"
L.bigWigsBarStyleName_Blizzard = "Blizzard"
L.resetBarsDesc = "Çubuk bağlantı noktalarının konumu dahil, çubuklarla ilgili tüm seçenekleri sıfırla."
L.testBarsBtn = "Test Çubuğu Oluştur"
L.testBarsBtn_desc = "Mevcut görünüm ayarlarınızı test etmeniz için bir çubuk oluşturur."

L.toggleAnchorsBtnShow = "Taşıma Noktalarını Göster"
L.toggleAnchorsBtnHide = "Taşıma Noktalarını Gizle"
L.toggleAnchorsBtnHide_desc = "Tüm taşıma noktalarını gizleyerek her şeyi yerine kilitle."
L.toggleBarsAnchorsBtnShow_desc = "Çubukları taşıyabilmeniz için tüm taşıma noktalarını göster."

L.emphasizeAt = "Şu sürede vurgula... (saniye)"
L.growingUpwards = "Yukarı doğru büyü"
L.growingUpwardsDesc = "Bağlantı noktasından yukarı veya aşağı doğru büyümeyi değiştir."
L.texture = "Doku"
L.emphasize = L.EMPHASIZE
L.emphasizeMultiplier = "Boyut Çarpanı"
L.emphasizeMultiplierDesc = "Çubukların vurgu bağlantı noktasına taşınmasını kapatırsanız, bu seçenek normal çubukların boyutunu çarparak vurgulu çubukların boyutunu belirler."

L.enable = "Etkinleştir"
L.move = "Taşı"
L.moveDesc = "Vurgulu çubukları Vurgu bağlantı noktasına taşır. Bu seçenek kapalıysa vurgulu çubuklar yalnızca boyut ve renk değiştirir."
L.emphasizedBars = "Vurgulu çubuklar"
L.align = "Hizala"
L.alignText = "Yazıyı Hizala"
L.alignTime = "Süreyi Hizala"
L.time = "Süre"
L.timeDesc = "Çubuklarda kalan sürenin gösterilip gösterilmeyeceği."
L.textDesc = "Çubuklardaki yazının gösterilip gösterilmeyeceği."
L.icon = "Simge"
L.iconDesc = "Çubuk simgelerini gösterir veya gizler."
L.iconPosition = "Simge Konumu"
L.iconPositionDesc = "Simgenin çubukta nerede duracağını seçin."
L.iconTooltip = "Simge İpucu"
L.iconTooltipDesc = "Simgenin üzerine gelince boss yeteneği hakkında bilgi içeren bir ipucu göster."
L.font = "Yazı Tipi"
L.restart = "Yeniden Başlat"
L.restartDesc = "Vurgulu çubukları baştan başlatır ve 10'dan sayar."
L.fill = "Doldur"
L.fillDesc = "Çubukları boşaltmak yerine doldurur."
L.spacing = "Boşluk"
L.spacingDesc = "Çubuklar arasındaki boşluğu değiştir."
L.visibleBarLimit = "Görünür çubuk sınırı"
L.visibleBarLimitDesc = "Aynı anda görünebilecek en fazla çubuk sayısını ayarla."

L.localTimer = "Yerel"
L.timerFinished = "%s: [%s] zamanlayıcısı bitti."
L.customBarStarted = "'%s' özel çubuğu %s kullanıcısı %s tarafından başlatıldı."
L.sendCustomBar = "'%s' özel çubuğu BigWigs ve DBM kullanıcılarına gönderiliyor."

L.requiresLeadOrAssist = "Bu işlev Raid lideri veya Raid yardımcısı olmayı gerektirir."
L.encounterRestricted = "Bu işlev savaş sırasında kullanılamaz."
L.wrongCustomBarFormat = "Yanlış biçim. Doğru örnek: /raidbar 20 yazı"
L.wrongTime = "Geçersiz süre. <süre> saniye cinsinden bir sayı, D:S çifti veya Dm olabilir. Örneğin 5, 1:20 veya 2m."

L.wrongBreakFormat = "1 ile 60 dakika arasında olmalı. Doğru örnek: /break 5"
L.sendBreak = "BigWigs ve DBM kullanıcılarına mola zamanlayıcısı gönderiliyor."
L.breakStarted = "Mola zamanlayıcısı %s kullanıcısı %s tarafından başlatıldı."
L.breakStopped = "Mola zamanlayıcısı %s tarafından iptal edildi."
L.breakBar = "Mola zamanı"
L.breakMinutes = "Mola %d dakika sonra bitiyor!"
L.breakSeconds = "Mola %d saniye sonra bitiyor!"
L.breakFinished = "Mola zamanı bitti!"

L.indicatorTitle = "Büyü Göstergeleri"
L.indicatorType_Deadly = "Ölümcül"
L.indicatorType_Bleed = "Kanama"
L.indicatorType_Magic = "Büyü"
L.indicatorType_Dispels = "Arındırmalar"
L.indicatorType_Tank = "Tank"
L.indicatorType_Healer = "Şifacı"
L.indicatorType_Damager = "Hasar"

L.spellIndicatorsPosition = "Büyü Göstergeleri Konumu"
L.spellIndicatorsPositionDesc = "Büyü göstergelerinin çubukta nerede duracağını seçin."
L.spellIndicatorsOffset = "Büyü Göstergeleri Kayması"
L.spellIndicatorSize = "Büyü Göstergesi Boyutu"
L.spellIndicatorSizeDropdown_Large1 = "Büyük (1 gösterge)"
L.spellIndicatorSizeDropdown_Large2 = "Büyük (2 gösterge)"
L.spellIndicatorSizeDropdown_Large3 = "Büyük (3 gösterge)"
L.spellIndicatorSizeDropdown_Small4 = "Küçük (4 gösterge)"
L.spellIndicatorSizeDropdown_Small2 = "Küçük (2 gösterge)"

-----------------------------------------------------------------------
-- BossBlock.lua
--

L.bossBlock = "Boss Engelleme"
L.bossBlockDesc = "Boss savaşında engelleyebileceğiniz çeşitli şeyleri ayarlayın.\n\n"
L.bossBlockAudioDesc = "Boss savaşında hangi seslerin kısılacağını ayarlayın.\n\nBuradaki |cff808080gri|r seçenekler WoW ses ayarlarında kapatılmıştır.\n\n"
L.movieBlocked = "Bu videoyu daha önce izlediniz, atlanıyor."
L.blockEmotes = "Ekran ortası duygu mesajlarını engelle"
L.blockEmotesDesc = "Bazı bosslar belirli yetenekler için duygu mesajları gösterir; bu mesajlar hem çok uzun hem çok betimleyicidir. Oynanışı bozmayan, size tam olarak ne yapacağınızı söylemeyen daha kısa ve uygun mesajlar üretmeye çalışırız.\n\nNot: Okumak isterseniz boss duygu mesajları sohbette yine görünür."
L.blockMovies = "Tekrarlanan videoları engelle"
L.blockMoviesDesc = "Boss savaşı videolarının yalnızca bir kez oynatılmasına izin verilir (her birini izleyebilmeniz için), sonra engellenir."
L.blockFollowerMission = "Takipçi görevi açılır pencerelerini engelle"
L.blockFollowerMissionDesc = "Takipçi görevi açılır pencereleri birkaç şey için, ama çoğunlukla bir takipçi görevi tamamlandığında görünür.\n\nBu pencereler boss savaşında arayüzünüzün kritik kısımlarını kapatabilir, bu yüzden engellemenizi öneririz."
L.blockGuildChallenge = "Lonca meydan okuması açılır pencerelerini engelle"
L.blockGuildChallengeDesc = "Lonca meydan okuması açılır pencereleri birkaç şey için, çoğunlukla loncanızdan bir grup heroic zindan veya challenge mode zindanı tamamladığında görünür.\n\nBu pencereler boss savaşında arayüzünüzün kritik kısımlarını kapatabilir, bu yüzden engellemenizi öneririz."
L.blockSpellErrors = "Büyü başarısız mesajlarını engelle"
L.blockSpellErrorsDesc = "Genelde ekranın üstünde görünen \"Büyü henüz hazır değil\" gibi mesajlar engellenir."
L.blockZoneChanges = "Bölge değişti mesajlarını engelle"
L.blockZoneChangesDesc = "'|cFF33FF99Stormwind|r' veya '|cFF33FF99Orgrimmar|r' gibi yeni bir bölgeye geçtiğinizde ekranın üst ortasında görünen mesajlar engellenir."
L.audio = "Ses"
L.music = "Müzik"
L.ambience = "Ortam Sesleri"
L.sfx = "Ses Efektleri"
L.errorSpeech = "Hata Konuşması"
L.disableMusic = "Müziği kıs (önerilir)"
L.disableAmbience = "Ortam seslerini kıs (önerilir)"
L.disableSfx = "Ses efektlerini kıs (önerilmez)"
L.disableErrorSpeech = "Hata konuşmasını kıs (önerilir)"
L.disableAudioDesc = "WoW ses ayarlarındaki '%s' seçeneği kapatılır, boss savaşı bitince tekrar açılır. BigWigs uyarı seslerine odaklanmanıza yardım eder."
L.blockTooltipQuests = "İpucundaki görev hedeflerini engelle"
L.blockTooltipQuestsDesc = "Bir görev için boss öldürmeniz gerektiğinde, farenizi bossun üzerine getirince ipucunda genelde '0/1 tamamlandı' görünür. İpucunun çok büyümesini önlemek için o bossla savaşırken bu gizlenir."
L.blockObjectiveTracker = "Görev takipçisini gizle"
L.blockObjectiveTrackerDesc = "Ekranda yer açmak için boss savaşında görev hedefi takipçisi gizlenir.\n\nMythic+ içindeyseniz veya bir başarım takip ediyorsanız bu OLMAZ."

L.blockTalkingHead = "'Konuşan Kafa' NPC diyalog penceresini gizle"
L.blockTalkingHeadDesc = "'Konuşan Kafa', bir NPC konuşurken ekranınızın alt ortasında |cffff4411bazen|r görünen, NPC başı ve NPC sohbet metni içeren bir açılır diyalog kutusudur.\n\nBunun hangi zindan türlerinde gösterilmesinin engelleneceğini seçebilirsiniz.\n\n|cFF33FF99Lütfen Dikkat:|r\n 1) Bu özellik NPC sesinin çalmaya devam etmesine izin verir, böylece yine duyabilirsiniz.\n 2) Güvenlik için yalnızca belirli konuşan kafalar engellenir. Tek seferlik bir görev gibi özel veya benzersiz olanlar engellenmez."
L.blockTalkingHeadDungeons = "Normal ve Heroic Zindanlar"
L.blockTalkingHeadMythics = "Mythic ve Mythic+ Zindanlar"
L.blockTalkingHeadRaids = "Raidler"
L.blockTalkingHeadTimewalking = "Timewalking (Zindanlar ve Raidler)"
L.blockTalkingHeadScenarios = "Senaryolar"
L.blockTalkingHeadDelves = "Delves"

L.redirectPopups = "Açılır afişleri BigWigs mesajlarına yönlendir"
L.redirectPopupsDesc = "Ekranın ortasındaki '|cFF33FF99kasa yuvası açıldı|r' gibi açılır afişler bunun yerine BigWigs mesajı olarak gösterilir. Bu afişler oldukça büyük olabilir, uzun sürebilir ve arkalarına tıklamanızı engelleyebilir."
L.redirectPopupsColor = "Yönlendirilen mesajın rengi"
L.blockDungeonPopups = "Zindan açılır afişlerini engelle"
L.blockDungeonPopupsDesc = "Zindana girerken görünen açılır afişler bazen çok uzun metin içerebilir. Bu özelliği açmak onları tamamen engeller."
L.itemLevel = "Eşya Seviyesi %d"
L.newRespawnPoint = "Yeni Doğma Noktası"
L.playerLevel = "Seviye %d"

L.userNotifySfx = "Ses Efektleri BossBlock tarafından kapatılmıştı, tekrar açılıyor."
L.userNotifyMusic = "Müzik BossBlock tarafından kapatılmıştı, tekrar açılıyor."
L.userNotifyAmbience = "Ortam sesi BossBlock tarafından kapatılmıştı, tekrar açılıyor."
L.userNotifyErrorSpeech = "Hata konuşması BossBlock tarafından kapatılmıştı, tekrar açılıyor."

L.subzone_grand_bazaar = "Grand Bazaar" -- Battle of Dazar'alor raid (Battle for Azeroth)
L.subzone_port_of_zandalar = "Port of Zandalar" -- Battle of Dazar'alor raid (Battle for Azeroth)
L.subzone_eastern_transept = "Eastern Transept" -- Auchindoun dungeon (Warlords of Draenor)

-----------------------------------------------------------------------
-- Colors.lua
--

L.colors = "Renkler"

L.text = "Yazı"
L.textShadow = "Yazı Gölgesi"
L.expiring_normal = "Normal"
L.emphasized = "Vurgulu"

L.resetColorsDesc = "Yukarıdaki renkleri varsayılanlarına döndürür."
L.resetAllColorsDesc = "Herhangi bir boss savaşı ayarı için renkleri özelleştirdiyseniz, bu düğme HEPSİNİ sıfırlar ve burada belirlenen renkler kullanılır."

L.red = "Kırmızı"
L.redDesc = "Genel savaş uyarıları."
L.blue = "Mavi"
L.blueDesc = "Size uygulanan bir zayıflatma gibi sizi doğrudan etkileyen şeyler için uyarılar."
L.orange = "Turuncu"
L.yellow = "Sarı"
L.green = "Yeşil"
L.greenDesc = "Sizden bir zayıflatmanın kalkması gibi iyi şeyler için uyarılar."
L.cyan = "Camgöbeği"
L.cyanDesc = "Sonraki aşamaya geçmek gibi savaş durumu değişiklikleri için uyarılar."
L.purple = "Mor"
L.purpleDesc = "Tank zayıflatması yığınları gibi tanka özel yetenekler için uyarılar."

-----------------------------------------------------------------------
-- Countdown.lua
--

L.textCountdown = "Yazılı geri sayım"
L.textCountdownDesc = "Geri sayım sırasında görsel bir sayaç göster."
L.countdownColor = "Geri sayım rengi"
L.countdownVoice = "Geri sayım sesi"
L.countdownTest = "Geri sayımı test et"
L.countdownAt = "Şu sürede geri say... (saniye)"
L.countdownAt_desc = "Geri sayım başladığında bir boss yeteneğinde ne kadar süre (saniye) kalması gerektiğini seçin."
L.countdown = "Geri Sayım"
L.countdownDesc = "Geri sayım özelliği sesli bir geri sayım ve görsel bir yazılı geri sayım içerir. Varsayılan olarak nadiren açıktır, ama belirli boss savaşı ayarlarında herhangi bir boss yeteneği için açabilirsiniz."
L.countdownAudioHeader = "Sesli Geri Sayım"
L.countdownTextHeader = "Görsel Yazılı Geri Sayım"
L.resetCountdownDesc = "Yukarıdaki tüm geri sayım ayarlarını varsayılanlarına döndürür."
L.resetAllCountdownDesc = "Herhangi bir boss savaşı ayarı için özel geri sayım sesleri seçtiyseniz, bu düğme HEPSİNİ sıfırlar ve yukarıdaki tüm geri sayım ayarlarını varsayılanlarına döndürür."

-----------------------------------------------------------------------
-- InfoBox.lua
--

L.infobox_short = "Bilgi Kutusu"

-----------------------------------------------------------------------
-- Messages.lua
--

L.sinkDescription = "Bu eklentinin çıktısını BigWigs mesaj göstergesi üzerinden gönder. Bu gösterge simgeleri ve renkleri destekler, ekranda aynı anda 4 mesaja kadar gösterebilir. Yeni eklenen mesajlar kullanıcıyı uyarmak için büyür ve hızla tekrar küçülür."
L.emphasizedSinkDescription = "Bu eklentinin çıktısını BigWigs Vurgulu mesaj göstergesi üzerinden gönder. Bu gösterge yazı ve renkleri destekler, aynı anda yalnızca bir mesaj gösterebilir."
L.resetMessagesDesc = "Mesaj bağlantı noktalarının konumu dahil, mesajlarla ilgili tüm seçenekleri sıfırla."
L.toggleMessagesAnchorsBtnShow_desc = "Mesajları taşıyabilmeniz için tüm taşıma noktalarını göster."

L.testMessagesBtn = "Test Mesajı Oluştur"
L.testMessagesBtn_desc = "Mevcut görünüm ayarlarınızı test etmeniz için bir mesaj oluşturur."

L.bwEmphasized = "BigWigs Vurgulu"
L.messages = "Mesajlar"
L.emphasizedMessages = "Vurgulu mesajlar"
L.emphasizedDesc = "Vurgulu mesajın amacı ekranın ortasında büyük bir mesaj olarak dikkatinizi çekmektir. Varsayılan olarak nadiren açıktır, ama belirli boss savaşı ayarlarında herhangi bir boss yeteneği için açabilirsiniz."
L.uppercase = "BÜYÜK HARF"
L.uppercaseDesc = "Tüm vurgulu mesajlar BÜYÜK HARFE çevrilir."

L.useIcons = "Simgeleri kullan"
L.useIconsDesc = "Mesajların yanında simge göster."
L.classColors = "Sınıf renkleri"
L.classColorsDesc = "Mesajlar bazen oyuncu adları içerir. Bu seçeneği açmak o adları sınıf renkleriyle renklendirir."
L.chatFrameMessages = "Sohbet penceresi mesajları"
L.chatFrameMessagesDesc = "Tüm BigWigs mesajlarını gösterge ayarına ek olarak varsayılan sohbet penceresine de yazar."
L.chatFrameChoice = "Sohbet Penceresi Seç"
L.chatFrame = "Sohbet Penceresi %d: %s" -- "Chat Frame 1: General" or "Chat Frame 2: Combat Log" etc.

L.fontSize = "Yazı boyutu"
L.none = "Yok"
L.thin = "İnce"
L.thick = "Kalın"
L.outline = "Anahat"
L.monochrome = "Tek Renk"
L.monochromeDesc = "Tek renk bayrağını açıp kapatır; yazı kenarlarındaki yumuşatmayı kaldırır."
L.fontColor = "Yazı tipi rengi"
L.slugRendering = "Slug Çizimi"
L.slugRenderingDesc = "Yazı tipleri slug kitaplığıyla çizilir. Bu bazen büyük boyutlarda yazıları daha keskin gösterebilir, ama anahat boyutunu değiştirebilir. |cFF33FF99Daha fazla bilgi için sluglibrary.com.|r"

L.displayTime = "Gösterim süresi"
L.displayTimeDesc = "Bir mesajın kaç saniye gösterileceği"
L.fadeTime = "Solma süresi"
L.fadeTimeDesc = "Bir mesajın kaç saniyede solacağı"

L.messagesOptInHeaderOff = "Boss modu mesajları 'katılım' modu: Bu seçeneği açmak TÜM boss modüllerinizde mesajları kapatır.\n\nHer birine girip istediğiniz mesajları elle açmanız gerekir.\n\n"
L.messagesOptInHeaderOn = "Boss modu mesajları 'katılım' modu |cFF33FF99ETKİN|r. Boss modu mesajlarını görmek için belirli bir boss yeteneğinin ayarlarına girip '|cFF33FF99Mesajlar|r' seçeneğini açın.\n\n"
L.messagesOptInTitle = "Boss modu mesajları 'katılım' modu"
L.messagesOptInWarning = "|cffff4411UYARI!|r\n\n'Katılım' modunu açmak TÜM boss modüllerinizde mesajları kapatır. Her birine girip istediğiniz mesajları elle açmanız gerekir.\n\nArayüzünüz şimdi yenilenecek, emin misiniz?"

-----------------------------------------------------------------------
-- Nameplates.lua
--

L.nameplates = "İsim Plakaları"
L.testNameplateIconBtn = "Test Simgesi Göster"
L.testNameplateIconBtn_desc = "Hedeflediğiniz isim plakasında mevcut görünüm ayarlarınızı test etmeniz için bir test simgesi oluşturur."
L.testNameplateTextBtn = "Yazı Testi Göster"
L.testNameplateTextBtn_desc = "Hedeflediğiniz isim plakasında mevcut yazı ayarlarınızı test etmeniz için bir test yazısı oluşturur."
L.stopTestNameplateBtn = "Testleri Durdur"
L.stopTestNameplateBtn_desc = "İsim plakalarınızdaki simge ve yazı testlerini durdurur."
L.noNameplateTestTarget = "İsim plakası işlevini test etmek için saldırılabilir düşman bir hedef seçmiş olmanız gerekir."
L.anchoring = "Bağlantı"
L.growStartPosition = "Büyüme Başlangıç Konumu"
L.growStartPositionDesc = "İlk simgenin başlangıç konumu."
L.growDirection = "Büyüme Yönü"
L.growDirectionDesc = "Simgelerin başlangıç konumundan hangi yöne büyüyeceği."
L.iconSpacingDesc = "Simgeler arasındaki boşluğu değiştir."
L.nameplateIconSettings = "Simge Ayarları"
L.keepAspectRatio = "En-Boy Oranını Koru"
L.keepAspectRatioDesc = "Simgeyi pencere boyutuna uydurmak için germek yerine en-boy oranını 1:1 tut."
L.iconColor = "Simge Rengi"
L.iconColorDesc = "Simge dokusunun rengini değiştir."
L.desaturate = "Rengi Soldur"
L.desaturateDesc = "Simge dokusunun rengini soldur."
L.zoom = "Yakınlaştırma"
L.zoomDesc = "Simge dokusunu yakınlaştır."
L.showBorder = "Kenarlığı\nGöster"
L.showBorderDesc = "Simgenin etrafında kenarlık göster."
L.border = "Kenarlık"
L.borderColor = "Kenarlık Rengi"
L.borderSize = "Kenarlık Boyutu"
L.borderOffset = "Kenarlık Kayması"
L.borderName = "Kenarlık Adı"
L.borderDispelColor = "Kenarlığı arındırma türüne göre renklendir"
L.showNumbers = "Sayıları Göster"
L.showNumbersDesc = "Simgede sayıları göster."
L.cooldown = "Bekleme"
L.cooldownEmphasizeHeader = "Varsayılan olarak Vurgu kapalıdır (0 saniye). 1 saniye veya üstüne ayarlamak Vurguyu açar. Böylece o sayılar için farklı yazı rengi ve boyutu ayarlayabilirsiniz."
L.showCooldownSwipe = "Taramayı Göster"
L.showCooldownSwipeDesc = "Bekleme süresi etkinken simgede tarama göster."
L.showCooldownEdge = "Kenarı Göster"
L.showCooldownEdgeDesc = "Bekleme süresi etkinken beklemede kenar göster."
L.inverse = "Ters"
L.inverseSwipeDesc = "Bekleme animasyonlarını ters çevir."
L.glow = "Parlama"
L.enableExpireGlow = "Bitiş Parlamasını Etkinleştir"
L.enableExpireGlowDesc = "Bekleme süresi bitince simgenin etrafında parlama göster."
L.glowColor = "Parlama Rengi"
L.glowType = "Parlama Türü"
L.glowTypeDesc = "Simgenin etrafında gösterilen parlama türünü değiştir."
L.resetNameplateIconsDesc = "İsim plakası simgeleriyle ilgili tüm seçenekleri sıfırla."
L.nameplateTextSettings = "Metin Ayarları"
L.fixate_test = "Odaklanma Testi" -- Text that displays to test on the frame
L.resetNameplateTextDesc = "İsim plakası yazısıyla ilgili tüm seçenekleri sıfırla."
L.glowAt = "Parlamayı Başlat (saniye)"
L.glowAt_desc = "Parlama başladığında beklemede kaç saniye kalması gerektiğini seçin."
L.offsetX = "X Kayması"
L.offsetY = "Y Kayması"
L.headerIconSizeTarget = "Mevcut hedefinizin simge boyutu"
L.headerIconSizeOthers = "Diğer tüm hedeflerin simge boyutu"
L.headerIconPositionTarget = "Mevcut hedefinizin simge konumu"
L.headerIconPositionOthers = "Diğer tüm hedeflerin simge konumu"

-- Glow types as part of LibCustomGlow
L.pixelGlow = "Piksel Parlama"
L.autocastGlow = "Otomatik Yapma Parlaması"
L.buttonGlow = "Düğme Parlaması"
L.procGlow = "Tetik Parlaması"
L.speed = "Hız"
L.animation_speed_desc = "Parlama animasyonunun oynatılma hızı."
L.lines = "Satırlar"
L.lines_glow_desc = "Parlama animasyonundaki çizgi sayısı."
L.intensity = "Yoğunluk"
L.intensity_glow_desc = "Parlama etkisinin yoğunluğu; yüksek değer daha çok kıvılcım demektir."
L.length = "Uzunluk"
L.length_glow_desc = "Parlama animasyonundaki çizgilerin uzunluğu."
L.thickness = "Kalınlık"
L.thickness_glow_desc = "Parlama animasyonundaki çizgilerin kalınlığı."
L.scale = "Ölçek"
L.scale_glow_desc = "Animasyondaki kıvılcımların ölçeği."
L.startAnimation = "Başlangıç Animasyonu"
L.startAnimation_glow_desc = "Bu parlamanın bir başlangıç animasyonu var; bu seçenek o animasyonu açar/kapatır."

L.nameplateOptInHeaderOff = "\n\n\n\nBoss modu isim plakaları 'katılım' modu: Bu seçeneği açmak TÜM boss modüllerinizde isim plakalarını kapatır.\n\nHer birine girip istediğiniz isim plakalarını elle açmanız gerekir.\n\n"
L.nameplateOptInHeaderOn = "\n\n\n\nBoss modu isim plakaları 'katılım' modu |cFF33FF99ETKİN|r. Boss modu isim plakalarını görmek için belirli bir boss yeteneğinin ayarlarına girip '|cFF33FF99İsim Plakaları|r' seçeneğini açın.\n\n"
L.nameplateOptInTitle = "Boss modu isim plakaları 'katılım' modu"
L.nameplateOptInWarning = "|cffff4411UYARI!|r\n\n'Katılım' modunu açmak TÜM boss modüllerinizde isim plakalarını kapatır. Her birine girip istediğiniz isim plakalarını elle açmanız gerekir.\n\nArayüzünüz şimdi yenilenecek, emin misiniz?"

-----------------------------------------------------------------------
-- Proximity.lua
--

L.customRange = "Özel menzil göstergesi"
L.proximityTitle = "%d m / %d oyuncu" -- yd = yards (short)
L.proximity_name = "Yakınlık"
L.soundDelay = "Ses gecikmesi"
L.soundDelayDesc = "Biri size çok yakınken BigWigs'in belirtilen sesi tekrarlamadan önce ne kadar bekleyeceğini belirtin."

L.resetProximityDesc = "Yakınlık bağlantı noktasının konumu dahil, yakınlıkla ilgili tüm seçenekleri sıfırla."

L.close = "Kapat"
L.closeProximityDesc = "Yakınlık göstergesini kapatır.\n\nHerhangi bir savaş için tamamen kapatmak istiyorsanız ilgili boss modülünün seçeneklerine girip 'Yakınlık' seçeneğini kapatmanız gerekir."
L.lock = "Kilitle"
L.lockDesc = "Göstergeyi yerine kilitler; taşımayı ve boyutlandırmayı engeller."
L.title = "Başlık"
L.titleDesc = "Başlığı gösterir veya gizler."
L.background = "Arka Plan"
L.backgroundDesc = "Arka planı gösterir veya gizler."
L.toggleSound = "Sesi aç/kapat"
L.toggleSoundDesc = "Başka bir oyuncuya çok yakınken yakınlık penceresinin bip sesi çıkarıp çıkarmayacağını değiştir."
L.soundButton = "Ses düğmesi"
L.soundButtonDesc = "Ses düğmesini gösterir veya gizler."
L.closeButton = "Kapat düğmesi"
L.closeButtonDesc = "Kapat düğmesini gösterir veya gizler."
L.showHide = "Göster/gizle"
L.abilityName = "Yetenek adı"
L.abilityNameDesc = "Pencerenin üstündeki yetenek adını gösterir veya gizler."
L.tooltip = "İpucu"
L.tooltipDesc = "Yakınlık göstergesi doğrudan bir boss yeteneğine bağlıysa büyü ipucunu gösterir veya gizler."

-----------------------------------------------------------------------
-- Pull.lua
--

L.countdownType = "Geri Sayım Türü"
L.combatLog = "Otomatik Savaş Kaydı"
L.combatLogDesc = "Çekme zamanlayıcısı başladığında savaş kaydını otomatik başlat, savaş bitince durdur."

L.pull = "Çekme"
L.engageSoundTitle = "Boss savaşı başladığında ses çal"
L.pullStartedSoundTitle = "Çekme zamanlayıcısı başladığında ses çal"
L.pullStartedMessageTitle = "Çekme zamanlayıcısı başladığında mesaj göster"
L.pullFinishedSoundTitle = "Çekme zamanlayıcısı bittiğinde ses çal"
L.pullStartedBy = "Çekme zamanlayıcısı %s tarafından başlatıldı."
L.pullStopped = "Çekme zamanlayıcısı %s tarafından iptal edildi."
L.pullStoppedCombat = "Savaşa girdiğiniz için çekme zamanlayıcısı iptal edildi."
L.pullIn = "%d sn sonra çekiliyor"
L.sendPull = "Grubunuza çekme zamanlayıcısı gönderiliyor."
L.wrongPullFormat = "Geçersiz çekme zamanlayıcısı. Doğru örnek: /pull 5"
L.countdownBegins = "Geri Sayımı Başlat"
L.countdownBegins_desc = "Geri sayım başladığında çekme zamanlayıcısında ne kadar süre (saniye) kalması gerektiğini seçin."
L.pullExplainer = "\n|cFF33FF99/pull|r normal bir çekme zamanlayıcısı başlatır.\n|cFF33FF99/pull 7|r 7 saniyelik bir çekme zamanlayıcısı başlatır; istediğiniz sayıyı kullanabilirsiniz.\nAyrıca aşağıdan bir tuş ataması da yapabilirsiniz.\n\n"
L.pullKeybindingDesc = "Çekme zamanlayıcısı başlatmak için bir tuş ataması seçin."

-----------------------------------------------------------------------
-- RaidIcon.lua
--

L.icons = "Simgeler"
L.raidIconsDescription = "Bazı savaşlarda belirli bir oyuncuyu hedef alan bomba türü yetenekler, kovalanan bir oyuncu veya başka şekillerde ilgi çeken bir oyuncu olabilir. Burada bu oyuncuları işaretlemek için hangi Raid simgelerinin kullanılacağını özelleştirebilirsiniz.\n\nBir savaşta işaretlemeye değer tek bir yetenek varsa yalnızca ilk simge kullanılır. Aynı savaşta bir simge asla iki farklı yetenek için kullanılmaz ve bir yetenek bir dahaki sefere her zaman aynı simgeyi kullanır.\n\n|cffff4411Bir oyuncu zaten elle işaretlenmişse BigWigs onun simgesini asla değiştirmez.|r"
L.primary = "Birincil"
L.primaryDesc = "Bir savaş betiğinin kullanacağı ilk Raid hedef simgesi."
L.secondary = "İkincil"
L.secondaryDesc = "Bir savaş betiğinin kullanacağı ikinci Raid hedef simgesi."

-----------------------------------------------------------------------
-- Sound.lua
--

L.Sounds = "Sesler"
L.soundsDesc = "BigWigs tüm seslerini 'Ana' ses kanalından çalar. Sesler çok kısık veya çok yüksekse WoW ses ayarlarını açıp 'Ana Ses' kaydırıcısını istediğiniz seviyeye getirin.\n\nAşağıda belirli eylemler için çalan sesleri genel olarak ayarlayabilir veya kapatmak için 'Yok' seçebilirsiniz. Yalnızca belirli bir boss yeteneğinin sesini değiştirmek istiyorsanız bunu boss savaşı ayarlarından yapabilirsiniz.\n\n"
L.oldSounds = "Eski Sesler"

L.Alarm = "Alarm"
L.Info = "Bilgi"
L.Alert = "Uyarı"
L.Long = "Uzun"
L.Warning = "İkaz"
L.onyou = "Sizde bir büyü, güçlendirme veya zayıflatma var"
L.underyou = "Altınızdaki bir büyüden çıkmanız gerekiyor"
L.privateaura = "Sizde bir 'Özel Aura' olduğunda"

L.customSoundDesc = "Modülün sağladığı ses yerine seçilen özel sesi çal."
L.resetSoundDesc = "Yukarıdaki sesleri varsayılanlarına döndürür."
L.resetAllCustomSound = "Herhangi bir boss savaşı ayarı için sesleri özelleştirdiyseniz, bu düğme HEPSİNİ sıfırlar ve burada belirlenen sesler kullanılır."
L.soundResetPrint = "'|cFF436EEE%s|r' modülü artık var olmayan '|cFF436EEE%s|r' adlı özel bir ses kullanıyor. Varsayılana döndürülüyor."

-----------------------------------------------------------------------
-- Statistics.lua
--

L.bossStatistics = "Boss İstatistikleri"
L.bossStatsDescription = "Zafer sayınız, yenilgi sayınız, ilk zafer tarihi ve en hızlı zafer gibi bossla ilgili çeşitli istatistiklerin kaydı. Bu istatistikler her bossun ayar ekranında görülebilir, ama istatistiği kaydedilmemiş bosslarda gizlenir."
L.createTimeBar = "'En İyi Süre' çubuğunu göster"
L.bestTimeBar = "En İyi Süre"
L.healthPrint = "Can: %s."
L.healthFormat = "%s (%.1f%%)"
L.chatMessages = "Sohbet Mesajları"
L.newFastestVictoryOption = "Yeni en hızlı zafer"
L.victoryOption = "Zafer kazandınız"
L.defeatOption = "Yenildiniz"
L.bossHealthOption = "Boss canı"
L.bossVictoryPrint = "'%s' karşısında %s sonra zafer kazandınız." -- You were victorious against 'BOSS_NAME' after COMBAT_DURATION.
L.bossDefeatPrint = "'%s' tarafından %s sonra yenildiniz." -- You were defeated by 'BOSS_NAME' after COMBAT_DURATION.
L.newFastestVictoryPrint = "Yeni en hızlı zafer: (-%s)" -- New fastest victory: (-COMBAT_DURATION)

-----------------------------------------------------------------------
-- Timeline.lua
--

L.timeline = "Zaman Çizelgesi"
L.blizzTimelineSettings = "Blizzard Zaman Çizelgesi Ayarları"
L.blizzTimelineSettingsNote = "|cffff4411Bu seçenekler yalnızca Blizzard ayarlarını denetler ve kolaylık olsun diye buradadır.|r"
L.enableBlizzTimeline = "Blizzard zaman çizelgesini etkinleştir"
L.enableBlizzTimelineDesc = "Tüm boss savaşı zamanlayıcılarını Blizzard zaman çizelgesinde gösterir."
L.show_bars = "Çubukları Şuradan Göster"
L.bigwigsEnhancedTimers = "BigWigs çubukları olarak gösterilen BigWigs gelişmiş zamanlayıcıları |cFF33FF99(önerilir)|r"
L.blizzBasicAsBars = "BigWigs çubukları olarak gösterilen Blizzard temel zamanlayıcıları"
L.blizzBasicAsBlizzTimeline = "Blizzard zaman çizelgesinde gösterilen Blizzard temel zamanlayıcıları"
L.developerMode = "Geliştirici Modu"
L.enhancedModeWarning = "UYARI!\n\nGelişmiş modu kapatmak birçok BigWigs özelliğini kapatır, bunlar arasında:\n\nÇubuk renkleri, büyü yeniden adları, sayaçlar, özel ses/seslendirme, geri sayımlar, çubukları açma/kapatma, ek mesajlar vb."
L.blizzTimelineEnhancedWarning = "UYARI!\n\nBlizzard zaman çizelgesi BigWigs gelişmiş özelliklerini desteklemez. Yeniden adlandırılmış büyüleri GÖRMEZSİNİZ ve hatalı zamanlayıcılar görürsünüz.\n\nEtkinleştirmek istediğinize emin misiniz?"

-----------------------------------------------------------------------
-- Victory.lua
--

L.Victory = "Zafer"
L.victoryHeader = "Bir boss savaşını kazandıktan sonra yapılacak eylemleri ayarlayın."
L.victorySound = "Zafer sesi çal"
L.victoryMessages = "Boss yenilgi mesajlarını göster"
L.victoryMessageBigWigs = "BigWigs mesajını göster"
L.victoryMessageBigWigsDesc = "BigWigs mesajı basit bir \"boss yenildi\" mesajıdır."
L.victoryMessageBlizzard = "Blizzard mesajını göster"
L.victoryMessageBlizzardDesc = "Blizzard mesajı ekranın ortasında çok büyük bir \"boss yenildi\" animasyonudur."
L.defeated = "%s yenildi"

-----------------------------------------------------------------------
-- Wipe.lua
--

L.wipe = "Yenilgi"
L.wipeSoundTitle = "Yenildiğinizde ses çal"
L.respawn = "Yeniden Doğma"
L.showRespawnBar = "Yeniden doğma çubuğunu göster"
L.showRespawnBarDesc = "Bir bossta yenildikten sonra bossun yeniden doğmasına kalan süreyi gösteren bir çubuk göster."
