local ChatEdit_ChooseBoxForSend = _G.ChatEdit_ChooseBoxForSend or _G.ChatFrameUtil.ChooseBoxForSend
local ChatEdit_DeactivateChat = _G.ChatEdit_DeactivateChat or _G.ChatFrameUtil.DeactivateChat

Prat:AddModuleToLoad(function()
	local module = Prat:NewModule("Editbox", "AceHook-3.0")
	local PL = module.PL

	local Media = Prat.Media
	local backgrounds, borders, fonts = {}, {}, {}

	local VALID_ATTACH_POINTS = {
		TOP = PL["Top"],
		BOTTOM = PL["Bottom"],
		FREE = PL["Free-floating"],
		LOCK = PL["Free-floating, Locked"]
	}

	local function updateEditBox(method, ...)
		for i = 1, #CHAT_FRAMES do
			local f = _G["ChatFrame" .. i .. "EditBox"]
			f[method](f, ...)
		end
	end

	Prat:SetModuleOptions(module, {
		name = PL["Editbox"],
		desc = PL["Editbox options."],
		type = "group",
		args = {
			background = {
				type = "select",
				name = PL["Background texture"],
				desc = PL["Background texture"],
				values = backgrounds,
				get = function()
					return module.db.profile.background
				end,
				set = function(_, v)
					module.db.profile.background = v
					module:SetBackdrop()
				end
			},
			border = {
				type = "select",
				name = PL["Border texture"],
				desc = PL["Border texture"],
				values = borders,
				get = function()
					return module.db.profile.border
				end,
				set = function(_, v)
					module.db.profile.border = v
					module:SetBackdrop()
				end
			},
			backgroundColor = {
				type = "color",
				name = PL["Background color"],
				desc = PL["Background color"],
				hasAlpha = true,
				get = function()
					local c = module.db.profile.backgroundColor
					return c.r, c.g, c.b, c.a
				end,
				set = function(_, r, g, b, a)
					local c = module.db.profile.backgroundColor
					c.r, c.g, c.b, c.a = r, g, b, a
					module:SetBackdrop()
				end
			},
			borderColor = {
				type = "color",
				name = PL["Border color"],
				desc = PL["Border color"],
				hasAlpha = true,
				get = function()
					local c = module.db.profile.borderColor
					return c.r, c.g, c.b, c.a
				end,
				set = function(_, r, g, b, a)
					local c = module.db.profile.borderColor
					c.r, c.g, c.b, c.a = r, g, b, a
					module:SetBackdrop()
				end
			},
			inset = {
				type = "range",
				name = PL["Background Inset"],
				desc = PL["Background Inset"],
				min = 1,
				max = 64,
				step = 1,
				bigStep = 1,
				get = function()
					return module.db.profile.inset
				end,
				set = function(_, v)
					module.db.profile.inset = v
					module:SetBackdrop()
				end
			},
			tileSize = {
				type = "range",
				name = PL["Tile Size"],
				desc = PL["Tile Size"],
				min = 1,
				max = 64,
				step = 1,
				bigStep = 1,
				get = function()
					return module.db.profile.tileSize
				end,
				set = function(_, v)
					module.db.profile.tileSize = v
					module:SetBackdrop()
				end
			},
			edgeSize = {
				type = "range",
				name = PL["Edge Size"],
				desc = PL["Edge Size"],
				min = 1,
				max = 64,
				step = 1,
				bigStep = 1,
				get = function()
					return module.db.profile.edgeSize
				end,
				set = function(_, v)
					module.db.profile.edgeSize = v
					module:SetBackdrop()
				end
			},
			attach = {
				type = "select",
				name = PL["Attach to..."],
				desc = PL["Attach edit box to..."],
				get = function()
					return module.db.profile.attach
				end,
				values = VALID_ATTACH_POINTS,
				set = function(_, v)
					module.db.profile.attach = v
					module:SetAttach()
				end
			},
			colorByChannel = {
				type = "toggle",
				name = PL["Color border by channel"],
				desc = PL["Sets the frame's border color to the color of your currently active channel"],
				get = function()
					return module.db.profile.colorByChannel
				end,
				set = function(_, v)
					module.db.profile.colorByChannel = v
					if v then
						module:SecureHook("ChatEdit_UpdateHeader", "SetBorderByChannel", true)
					else
						if module:IsHooked("ChatEdit_UpdateHeader") then
							module:Unhook("ChatEdit_UpdateHeader")
							local c = module.db.profile.borderColor
							for _, frame in ipairs(module.frames) do
								frame:SetBackdropBorderColor(c.r, c.g, c.b, c.a)
							end
						end
					end
				end
			},
			useAltKey = {
				type = "toggle",
				name = PL["Use Alt key for cursor movement"],
				desc = PL["Requires the Alt key to be held down to move the cursor in chat"],
				get = function()
					return module.db.profile.useAltKey
				end,
				set = function(_, v)
					module.db.profile.useAltKey = v
					updateEditBox("SetAltArrowKeyMode", v)
				end,
			},
			font = {
				type = "select",
				name = PL["Font"],
				desc = PL["Select the font to use for the edit box"],
				values = fonts,
				get = function()
					return module.db.profile.font
				end,
				set = function(_, v)
					module.db.profile.font = v
					for i = 1, #CHAT_FRAMES do
						local ff = _G["ChatFrame" .. i .. "EditBox"]
						local header = _G[ff:GetName() .. "Header"]
						local _, s, m = ff:GetFont()
						local font = Media:Fetch("font", v)
						ff:SetFont(font, s, m)
						header:SetFont(font, s, m)
					end
				end
			},
		},
	})

	Prat:SetModuleDefaults(module.name, {
		profile = {
			on = true,
			background = "Blizzard Tooltip",
			border = "Blizzard Tooltip",
			backgroundColor = { r = 0, g = 0, b = 0, a = 1 },
			borderColor = { r = 1, g = 1, b = 1, a = 1 },
			inset = 3,
			edgeSize = 12,
			tileSize = 16,
			height = 22,
			attach = "BOTTOM",
			colorByChannel = true,
			useAltKey = false,
			font = (function()
				for i = 1, #CHAT_FRAMES do
					local ff = _G["ChatFrame" .. i .. "EditBox"]
					local f = ff:GetFont()
					for k, v in pairs(Media:HashTable("font")) do
						if v == f then
							return k
						end
					end
				end
			end)()
		}
	})

	function module:LibSharedMedia_Registered()
		for _, v in pairs(Media:List("background")) do
			backgrounds[v] = v
		end
		for _, v in pairs(Media:List("border")) do
			borders[v] = v
		end
		for _, v in pairs(Media:List("font")) do
			fonts[v] = v
		end
	end

	local function MakePratEditbox(self, i)
		if not self.frames[i] then
			local parent = _G["ChatFrame" .. i .. "EditBox"]

			local frame = CreateFrame("Frame", nil, parent, BackdropTemplateMixin and "BackdropTemplate")
			frame:SetFrameStrata("DIALOG")
			frame:SetFrameLevel(parent:GetFrameLevel() - 1)
			frame:SetAllPoints(parent)
			frame:Hide()
			parent.pratFrame = frame
			self.frames[i] = frame

			parent.lDrag = CreateFrame("Frame", nil, parent)
			parent.lDrag:SetWidth(15)
			parent.lDrag:SetPoint("TOPLEFT", parent, "TOPLEFT")
			parent.lDrag:SetPoint("BOTTOMLEFT", parent, "BOTTOMLEFT")
			parent.lDrag.left = true

			parent.rDrag = CreateFrame("Frame", nil, parent)
			parent.rDrag:SetWidth(15)
			parent.rDrag:SetPoint("TOPRIGHT", parent, "TOPRIGHT")
			parent.rDrag:SetPoint("BOTTOMRIGHT", parent, "BOTTOMRIGHT")

			-- Backdrop hack
			if frame.SetupTextureCoordinates and issecretvalue then
				local setupTextureCoordinates = frame.SetupTextureCoordinates
				frame.SetupTextureCoordinates = function(f)
					if issecretvalue(f:GetWidth()) or issecretvalue(f:GetHeight()) or issecretvalue(f:GetEffectiveScale()) then
						return
					end
					return setupTextureCoordinates(f)
				end
			end
		end
	end

	local function ChatFrameTab_OnClick(i)
		if GetCVar("chatStyle") ~= "classic" then
			local chatFrame = _G["ChatFrame" .. i];
			ChatEdit_DeactivateChat(chatFrame.editBox)
			chatFrame.editBox:Hide()
		end
	end

	Prat:SetModuleInit(module, function(self)
		Media.RegisterCallback(module, "LibSharedMedia_Registered")
		self.frames = {}

		self:LibSharedMedia_Registered()

		for i = 1, #CHAT_FRAMES do
			MakePratEditbox(self, i)
		end
	end)

	local function OnArrowPressed(self, key)
		-- We cannot call SetText while in lockdown
		if C_ChatInfo and C_ChatInfo.InChatMessagingLockdown and C_ChatInfo.InChatMessagingLockdown() then
			return
		end
		if #self.history_lines == 0 then
			return
		end
		if key ~= "DOWN" and key ~= "UP" then
			return
		end

		if key == "DOWN" then
			self.history_index = self.history_index - 1

			if self.history_index < 1 then
				self.history_index = #self.history_lines
			end
		elseif key == "UP" then
			self.history_index = self.history_index + 1

			if self.history_index > #self.history_lines then
				self.history_index = 1
			end
		end

		self:SetText(self.history_lines[self.history_index])
	end

	local function enableArrowKeys(e)
		e.history_lines = e.history_lines or {}
		e.history_index = e.history_index or 0
		e:HookScript("OnArrowPressed", OnArrowPressed)
	end

	function module:Prat_FramesUpdated(_, _, chatFrame)
		local i = chatFrame:GetID()
		local f = _G["ChatFrame" .. i .. "EditBox"]
		_G["ChatFrame" .. i .. "EditBoxLeft"]:Hide()
		_G["ChatFrame" .. i .. "EditBoxRight"]:Hide()
		_G["ChatFrame" .. i .. "EditBoxMid"]:Hide()
		if f.focusLeft then
			f.focusLeft:SetAlpha(0)
		end
		if f.focusRight then
			f.focusRight:SetAlpha(0)
		end
		if f.focusMid then
			f.focusMid:SetAlpha(0)
		end
		f:Hide()
		f:SetAlpha(0)
		f:EnableMouse(false)

		MakePratEditbox(self, i)
		self.frames[i]:Show()

		local _, s, m = f:GetFont()
		f:SetFont(Media:Fetch("font", self.db.profile.font), s, m)

		local header = _G[f:GetName() .. "Header"]
		local _, s2, m2 = header:GetFont()
		header:SetFont(Media:Fetch("font", self.db.profile.font), s2, m2)

		f:SetAltArrowKeyMode(module.db.profile.useAltKey and 1 or nil)
		if not module.db.profile.useAltKey then
			enableArrowKeys(f)
		end
		self:SetBackdrop()
		self:UpdateHeight()
		self:SetAttach(nil, self.db.profile.editX, self.db.profile.editY, self.db.profile.editW)
	end

	function module:OnModuleEnable()
		self:LibSharedMedia_Registered()

		for i = 1, #CHAT_FRAMES do
			local f = _G["ChatFrame" .. i .. "EditBox"]
			_G["ChatFrame" .. i .. "EditBoxLeft"]:Hide()
			_G["ChatFrame" .. i .. "EditBoxRight"]:Hide()
			_G["ChatFrame" .. i .. "EditBoxMid"]:Hide()
			if f.focusLeft then
				f.focusLeft:SetAlpha(0)
			end
			if f.focusRight then
				f.focusRight:SetAlpha(0)
			end
			if f.focusMid then
				f.focusMid:SetAlpha(0)
			end
			f:Hide()
			f:SetAlpha(0)
			f:EnableMouse(false)

			MakePratEditbox(self, i) -- For new temporary chat frames created between init and now
			self.frames[i]:Show()
			local _, s, m = f:GetFont()
			f:SetFont(Media:Fetch("font", self.db.profile.font), s, m)

			local header = _G[f:GetName() .. "Header"]
			local _, s2, m2 = header:GetFont()
			header:SetFont(Media:Fetch("font", self.db.profile.font), s2, m2)

			f:SetAltArrowKeyMode(module.db.profile.useAltKey and 1 or nil)
			if not module.db.profile.useAltKey then
				enableArrowKeys(f)
			end

			local tab = _G["ChatFrame" .. i .. "Tab"]
			tab:HookScript("OnClick", function()
				ChatFrameTab_OnClick(i)
			end)
		end

		self:SetAttach(nil, self.db.profile.editX, self.db.profile.editY, self.db.profile.editW)

		if _G.ChatFrameUtil then
			if _G.ChatFrameUtil.DeactivateChat then
				self:SecureHook(_G.ChatFrameUtil, "DeactivateChat", "ChatEdit_DeactivateChat")
			end
			if _G.ChatFrameUtil.SetLastActiveWindow then
				self:SecureHook(_G.ChatFrameUtil, "ActivateChat", "ChatEdit_ActivateChat")
			end
			if _G.ChatFrameUtil.OpenChat then
				self:SecureHook(_G.ChatFrameUtil, "OpenChat", "ChatFrame_OpenChat")
			end
		else
			self:SecureHook("ChatFrame_OpenChat")
		end
		if self.db.profile.colorByChannel then
			if _G.ChatFrameEditBoxBaseMixin and _G.ChatFrameEditBoxBaseMixin.UpdateHeader then
				self:SecureHook(_G.ChatFrameEditBoxBaseMixin, "UpdateHeader", "SetBorderByChannel")
			else
				self:SecureHook("ChatEdit_UpdateHeader", "SetBorderByChannel", true)
			end
		end

		self:SetBackdrop()
		self:UpdateHeight()

		Prat.RegisterChatEvent(self, Prat.Events.FRAMES_UPDATED)
	end

	function module:ChatFrame_OpenChat(_, chatFrame)
		if not self.db.profile.useAltKey then
			local frame = ChatEdit_ChooseBoxForSend(chatFrame)

			frame.history_index = 0
		end
	end


	function module:OnModuleDisable()
		self:SetAttach("BOTTOM") -- clear move/resize handlers
		for i = 1, #CHAT_FRAMES do
			local f = _G["ChatFrame" .. i .. "EditBox"]
			_G["ChatFrame" .. i .. "EditBoxLeft"]:Show()
			_G["ChatFrame" .. i .. "EditBoxRight"]:Show()
			_G["ChatFrame" .. i .. "EditBoxMid"]:Show()
			if f.focusLeft then
				f.focusLeft:SetAlpha(1)
			end
			if f.focusRight then
				f.focusRight:SetAlpha(1)
			end
			if f.focusMid then
				f.focusMid:SetAlpha(1)
			end
			f:SetAltArrowKeyMode(true)
			f:EnableMouse(true)
			f.pratFrame:Hide()
			-- restore Blizz size/position
			f:ClearAllPoints()
			f:SetHeight(32)
			f:SetPoint("TOPLEFT", f.chatFrame, "BOTTOMLEFT", -5, -2)
			if Prat.IsClassic then
				f:SetPoint("TOPRIGHT", f.chatFrame, "BOTTOMRIGHT", 5, -2)
			else
				f:SetPoint("RIGHT", f.chatFrame.ScrollBar, "RIGHT", 5, 0)
			end
		end
	end

	function module:GetDescription()
		return PL["Editbox options."]
	end

	function module:ChatEdit_ActivateChat(frame)
		frame:SetAlpha(1)
		frame:EnableMouse(true)
	end

	function module:ChatEdit_DeactivateChat(frame)
		frame:SetAlpha(0)
		frame:EnableMouse(false)
	end

	function module:SetBackdrop()
		for _, frame in ipairs(self.frames) do
			frame:SetBackdrop({
				bgFile = Media:Fetch("background", self.db.profile.background),
				edgeFile = Media:Fetch("border", self.db.profile.border),
				tile = true,
				tileSize = self.db.profile.tileSize,
				edgeSize = self.db.profile.edgeSize,
				insets = {
					left = self.db.profile.inset,
					right = self.db.profile.inset,
					top = self.db.profile.inset,
					bottom = self.db.profile.inset
				}
			})
			local c = self.db.profile.backgroundColor
			frame:SetBackdropColor(c.r, c.g, c.b, c.a)

			local c2 = self.db.profile.borderColor
			frame:SetBackdropBorderColor(c2.r, c2.g, c2.b, c2.a)
		end
	end

	function module:SetBorderByChannel()
		for index, frame in ipairs(self.frames) do
			local f = _G["ChatFrame" .. index .. "EditBox"]
			local attr = f:GetAttribute("chatType")
			if attr == "CHANNEL" then
				local chan = f:GetAttribute("channelTarget")
				if chan == 0 then
					local c = self.db.profile.borderColor
					frame:SetBackdropBorderColor(c.r, c.g, c.b, c.a)
				elseif chan and ChatTypeInfo["CHANNEL" .. chan] then
					local r, g, b = GetMessageTypeColor("CHANNEL" .. chan)
					frame:SetBackdropBorderColor(r, g, b, 1)
				end
			else
				local r, g, b = GetMessageTypeColor(attr)
				frame:SetBackdropBorderColor(r, g, b, 1)
			end
		end
	end

	do
		local function startMoving(self)
			self:StartMoving()
		end

		local function stopMoving(self)
			self:StopMovingOrSizing()
			module.db.profile.editX = self:GetLeft()
			module.db.profile.editY = self:GetTop()
			module.db.profile.editW = self:GetRight() - self:GetLeft()
		end

		local cfHeight
		local function constrainHeight(self)
			self:GetParent():SetHeight(cfHeight)
		end

		local function startDragging(self)
			cfHeight = self:GetParent():GetHeight()
			self:GetParent():StartSizing(not self.left and "TOPRIGHT" or "TOPLEFT")
			self:SetScript("OnUpdate", constrainHeight)
		end

		local function stopDragging(self)
			local parent = self:GetParent()
			parent:StopMovingOrSizing()
			self:SetScript("OnUpdate", nil)
			module.db.profile.editX = parent:GetLeft()
			module.db.profile.editY = parent:GetTop()
			module.db.profile.editW = parent:GetWidth()
		end

		function module:SetAttach(val, x, y, w)
			for i = 1, #CHAT_FRAMES do
				local frame = _G["ChatFrame" .. i .. "EditBox"]
				val = val or self.db.profile.attach
				if not x and val == "FREE" then
					if self.db.profile.editX and self.db.profile.editY then
						x, y, w = self.db.profile.editX, self.db.profile.editY, self.db.profile.editW
					else
						x, y, w = frame:GetLeft(), frame:GetTop(), math.max(frame:GetWidth(), (frame:GetRight() or 0) - (frame:GetLeft() or 0))
					end
				end
				if not w or w < 10 then
					w = 100
				end
				frame:ClearAllPoints()
				if val ~= "FREE" then
					frame:SetMovable(false)
					frame.lDrag:EnableMouse(false)
					frame.rDrag:EnableMouse(false)
					frame:SetScript("OnMouseDown", nil)
					frame:SetScript("OnMouseUp", nil)
					frame.lDrag:EnableMouse(false)
					frame.rDrag:EnableMouse(false)
					frame.lDrag:SetScript("OnMouseDown", nil)
					frame.rDrag:SetScript("OnMouseDown", nil)
					frame.lDrag:SetScript("OnMouseUp", nil)
					frame.rDrag:SetScript("OnMouseUp", nil)
				end

				local scrollbarWidth = frame.chatFrame.ScrollBar and frame.chatFrame.ScrollBar:GetWidth() or 0
				if val == "TOP" then
					frame:SetPoint("BOTTOMLEFT", frame.chatFrame, "TOPLEFT", 0, 3)
					frame:SetPoint("BOTTOMRIGHT", frame.chatFrame, "TOPRIGHT", scrollbarWidth, 3)
				elseif val == "BOTTOM" then
					frame:SetPoint("TOPLEFT", frame.chatFrame, "BOTTOMLEFT", 0, -8)
					frame:SetPoint("TOPRIGHT", frame.chatFrame, "BOTTOMRIGHT", scrollbarWidth, -8)
				elseif val == "FREE" then
					frame:EnableMouse(true)
					frame:SetMovable(true)
					frame:SetResizable(true)
					frame:SetScript("OnMouseDown", startMoving)
					frame:SetScript("OnMouseUp", stopMoving)
					frame:SetWidth(w)
					frame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", x, y)
					local minWidth, minHeight = 40, 1
					if frame.SetResizeBounds then
						frame:SetResizeBounds(minWidth, minHeight)
					else
						frame:SetMinResize(minWidth, minHeight)
					end

					frame.lDrag:EnableMouse(true)
					frame.rDrag:EnableMouse(true)

					frame.lDrag:SetScript("OnMouseDown", startDragging)
					frame.rDrag:SetScript("OnMouseDown", startDragging)

					frame.lDrag:SetScript("OnMouseUp", stopDragging)
					frame.rDrag:SetScript("OnMouseUp", stopDragging)
				elseif val == "LOCK" then
					frame:SetWidth(self.db.profile.editW or w)
					frame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", self.db.profile.editX or x, self.db.profile.editY or y)
				end
			end
		end
	end

	function module:UpdateHeight()
		for i, _ in ipairs(self.frames) do
			local ff = _G["ChatFrame" .. i .. "EditBox"]
			ff:SetHeight(module.db.profile.height)
		end
	end

	return
end)
