-- Eşya sınıfları ve alt sınıfları (müzayede kategorileri, eşya ipuçları)
local A = WoWTurkce.Arayuz
local function ek(en, tr) if A[en] == nil then A[en] = tr end end
for en, tr in pairs({
	["Weapon"] = "Silah", ["Weapons"] = "Silahlar", ["Armor"] = "Zırh", ["Container"] = "Kap", ["Consumable"] = "Tüketilebilir",
	["Trade Goods"] = "Ticaret Malları", ["Projectile"] = "Mermi", ["Quiver"] = "Ok Kılıfı", ["Recipe"] = "Tarif",
	["Reagent"] = "Malzeme", ["Miscellaneous"] = "Çeşitli", ["Quest"] = "Görev", ["Key"] = "Anahtar", ["Gem"] = "Mücevher",
	-- Mermi ve ok kılıfı
	["Arrow"] = "Ok", ["Bullet"] = "Kurşun", ["Ammo Pouch"] = "Mermi Kesesi",
	-- Silahlar
	["One-Handed Axes"] = "Tek Elli Balta", ["Two-Handed Axes"] = "İki Elli Balta", ["Bows"] = "Yay", ["Guns"] = "Tüfek",
	["One-Handed Maces"] = "Tek Elli Gürz", ["Two-Handed Maces"] = "İki Elli Gürz", ["Polearms"] = "Mızrak",
	["One-Handed Swords"] = "Tek Elli Kılıç", ["Two-Handed Swords"] = "İki Elli Kılıç", ["Staves"] = "Asa",
	["Fist Weapons"] = "Yumruk Silahı", ["Daggers"] = "Hançer", ["Thrown"] = "Fırlatma", ["Crossbows"] = "Arbalet",
	["Wands"] = "Değnek", ["Fishing Poles"] = "Olta", ["Fishing Pole"] = "Olta",
	-- Zırh
	["Cloth"] = "Kumaş", ["Leather"] = "Deri", ["Mail"] = "Zincir", ["Plate"] = "Plaka", ["Shields"] = "Kalkan",
	["Librams"] = "Kutsal Kitap", ["Idols"] = "Put", ["Totems"] = "Totem", ["Shield"] = "Kalkan",
	-- Kuşanma yuvaları
	["Head"] = "Baş", ["Neck"] = "Boyun", ["Shoulder"] = "Omuz", ["Back"] = "Sırt", ["Chest"] = "Göğüs", ["Shirt"] = "Gömlek",
	["Tabard"] = "Tabar", ["Wrist"] = "Bilek", ["Hands"] = "Eller", ["Waist"] = "Bel", ["Legs"] = "Bacaklar", ["Feet"] = "Ayaklar",
	["Finger"] = "Parmak", ["Trinket"] = "Tılsım", ["Held In Off-hand"] = "Yan Elde Tutulur", ["Off Hand"] = "Yan El",
	["Main Hand"] = "Ana El", ["One-Hand"] = "Tek El", ["Two-Hand"] = "İki El", ["Ranged"] = "Menzilli", ["Relic"] = "Kalıntı",
	-- Kaplar
	["Bag"] = "Çanta", ["Soul Bag"] = "Ruh Çantası", ["Herb Bag"] = "Bitki Çantası", ["Enchanting Bag"] = "Efsun Çantası",
	["Engineering Bag"] = "Mühendislik Çantası", ["Mining Bag"] = "Madencilik Çantası",
	-- Tüketilebilir / ticaret malları
	["Food & Drink"] = "Yiyecek ve İçecek", ["Potion"] = "İksir", ["Elixir"] = "Karışım", ["Flask"] = "Şişe", ["Bandage"] = "Sargı",
	["Item Enhancement"] = "Eşya Geliştirme", ["Scroll"] = "Parşömen", ["Other"] = "Diğer", ["Parts"] = "Parçalar",
	["Explosives"] = "Patlayıcılar", ["Devices"] = "Cihazlar", ["Jewelcrafting"] = "Kuyumculuk", ["Metal & Stone"] = "Metal ve Taş",
	["Meat"] = "Et", ["Herb"] = "Bitki", ["Elemental"] = "Element", ["Enchanting"] = "Efsunculuk", ["Trade Good"] = "Ticaret Malı",
	-- Tarifler
	["Book"] = "Kitap", ["Leatherworking"] = "Dericilik", ["Tailoring"] = "Terzilik", ["Engineering"] = "Mühendislik",
	["Blacksmithing"] = "Demircilik", ["Cooking"] = "Aşçılık", ["Alchemy"] = "Simya", ["First Aid"] = "İlk Yardım",
	["Fishing"] = "Balıkçılık", ["Herbalism"] = "Bitkicilik", ["Mining"] = "Madencilik", ["Skinning"] = "Deri Yüzme",
	-- Çeşitli
	["Junk"] = "Hurda", ["Pet"] = "Evcil Hayvan", ["Holiday"] = "Bayram", ["Mount"] = "Binek",
	-- Nadirlik
	["Poor"] = "Kalitesiz", ["Common"] = "Sıradan", ["Uncommon"] = "Sıra Dışı", ["Rare"] = "Nadir", ["Epic"] = "Destansı",
	["Legendary"] = "Efsanevi", ["Artifact"] = "Eser", ["All"] = "Tümü",
}) do ek(en, tr) end
