local mod	= DBM:NewMod("Nargurk", "DBM-Party-Forever", 6)

mod:SetRevision("20261109015934")
mod:EnableGenericTrash()
mod:SetEncounterID(3449)
mod:SetModelID(141215)
mod:SetZone(3039)

mod:RegisterCombat("combat")
