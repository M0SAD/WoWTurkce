local _, addon = ...;

local floor = _G.floor;
local strjoin = _G.strjoin;

local Utils = addon.import('Core/Utils');
local Main = addon.import('Logic/Main');
local options = addon.import('Logic/Options').getAll();
local Enhancements = addon.import('Features/Enhancements');
local Layout = addon.import('Layouts/Main');

local module = addon.export('Settings/Settings', {});
local handlers = {};
local unavailableHandlers = {}

handlers.direction = {
  set = function (value)
    if (not Layout.applyLayout(value)) then
      return false;
    end

    options.direction = value;
    return true;
  end,
  help = strjoin('\n',
      'Bu ayar, toplanan düğmelerin çerçeveye hangi yönde ekleneceğini belirlemeni sağlar. Kullanılabilir değerler:',
      'leftdown leftup', 'rightup rightdown', 'upleft upright', 'downleft downright'
  )
};

handlers.buttonsperrow = {
  set = function (value)
    local numberValue = tonumber(value);

    if (numberValue == nil or numberValue <= 0) then
      return false;
    end

    numberValue = floor(numberValue);
    options.buttonsPerRow = numberValue;
    Layout.updateLayout();
    return true;
  end,
  get = function ()
    return options.buttonsPerRow;
  end,
  help = "Bu ayar, bir satıra en fazla kaç düğme yerleştirileceğini belirler."
};

handlers.scale = {
  set = function (value)
    local numberValue = tonumber(value);

    if (numberValue == nil or numberValue <= 0) then
      return false;
    end

    options.scale = numberValue;
    Main.applyScale();
    return true;
  end,
  help = "Bu ayar, eklenti düğmesinin ölçeğini belirler."
};

handlers.buttonscale = {
  set = function (value)
    local numberValue = tonumber(value);

    if (numberValue == nil or numberValue <= 0) then
      return false;
    end

    options.buttonScale = numberValue;
    Main.applyButtonScale();
    return true;
  end,
  get = function ()
    return options.buttonScale;
  end,
  help = "Bu ayar, toplanan düğmelerin ölçeğini belirler."
};

handlers.autoclose = {
  set = function (value)
    if (value == 'true') then
      options.autoClose = true;
      Main.hideButtons();
    elseif (value == 'false') then
      options.autoClose = false;
    else
      return false;
    end

    return true;
  end,
  get = function ()
    return options.autoClose;
  end,
  help = "Bu ayar, fare üzerinden çekildiğinde düğme kabının otomatik kapanmasını sağlar."
};

if (Enhancements.compartment) then
  handlers.hidecompartment = {
    set = function (value)
      if (value == 'true') then
        options.hidecompartment = true;
        Enhancements.hideCompartmentFrame();
      elseif (value == 'false') then
        options.hidecompartment = false;
        Enhancements.showCompartmentFrame();
      else
        return false;
      end

      return true;
    end,
    help = "Bu ayar, Blizzard eklenti bölmesi düğmesinin gizlenip gizlenmeyeceğini belirler."
  };
else
  unavailableHandlers.hidecompartment = function ()
      return 'Bu ayar kullanılamıyor çünkü eklenti bölmesi yalnızca Retail\'de var.';
  end
end

function module.printAvailableSettings ()
  Utils.printTableKeys(handlers);
end

function module.doesSettingExist (setting)
  return (handlers[setting] ~= nil);
end

function module.isSettingUnavailable (setting)
  return (unavailableHandlers[setting] ~= nil);
end

function module.getSettingUnavailableReason (setting)
  return unavailableHandlers[setting]()
end

function module.getSetting (setting)
  local handler = handlers[setting];

  if (handler.get ~= nil) then
    return handler.get();
  else
    return options[setting];
  end
end

function module.setSetting (setting, value)
  return handlers[setting].set(value);
end

function module.getHelp (setting)
  return handlers[setting] and handlers[setting].help;
end
