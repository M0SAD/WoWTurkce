-- Yetenek/büyü kitabı penceresindeki başlık sekmeleri (Primary, Secondary...) için Türkçe düzeltme.
local G = WoWTurkce

local METIN = { ["Primary"] = "Birincil", ["Secondary"] = "İkincil" }
local KOKLER = { "PlayerSpellsFrame", "ProfessionsBookFrame", "SpellBookFrame", "SpellBookProfessionFrame" }

local function yazilar(f, d)
	if d > 10 then return end
	if f.IsShown and not f:IsShown() then return end
	if f.GetRegions then
		for _, r in ipairs({ f:GetRegions() }) do
			if r.GetObjectType and r:GetObjectType() == "FontString" and r.GetText then
				local t = r:GetText()
				if type(t) == "string" and not G.gizli(t) and METIN[t] then r:SetText(METIN[t]) end
			end
		end
	end
	if f.GetChildren then
		for _, c in ipairs({ f:GetChildren() }) do yazilar(c, d + 1) end
	end
end

G.basla(function()
	C_Timer.NewTicker(0.5, function()
		if not G.ayar("acik") then return end
		for _, ad in ipairs(KOKLER) do
			local f = _G[ad]
			if f and f.IsShown and f:IsShown() then pcall(yazilar, f, 0) end
		end
	end)
end)

-- "Beceri" penceresi: meslek ve beceri adlarının yanına İngilizcesini ekle (Türkçe (English) stili; ayar: stilBuyu)
local BECERI = {
	["Meslekler"] = "Professions", ["İkincil Beceriler"] = "Secondary Skills", ["Silah Becerisi"] = "Weapon Skills",
	["Zırh Becerisi"] = "Armor Proficiencies", ["Diller"] = "Languages", ["Zırh Eğitimi"] = "Armor Proficiencies",
	["Madencilik"] = "Mining", ["Deri Yüzme"] = "Skinning", ["Aşçılık"] = "Cooking", ["İlk Yardım"] = "First Aid",
	["Balıkçılık"] = "Fishing", ["Simya"] = "Alchemy", ["Demircilik"] = "Blacksmithing", ["Mühendislik"] = "Engineering",
	["Efsunculuk"] = "Enchanting", ["Bitkicilik"] = "Herbalism", ["Dericilik"] = "Leatherworking", ["Terzilik"] = "Tailoring",
	["Çilingirlik"] = "Lockpicking", ["Binicilik"] = "Riding", ["Zehirler"] = "Poisons", ["Arkeoloji"] = "Archaeology",
}
local beceriKok
local function baslikVar(f, d)
	if d > 5 or (f.IsShown and not f:IsShown()) then return false end
	if f.GetRegions then
		for _, r in ipairs({ f:GetRegions() }) do
			if r.GetObjectType and r:GetObjectType() == "FontString" and r.GetText then
				local t = r:GetText()
				if type(t) == "string" and not G.gizli(t) and (t == "Beceri" or t == "Skills") then return true end
			end
		end
	end
	if f.GetChildren then
		for _, c in ipairs({ f:GetChildren() }) do if baslikVar(c, d + 1) then return true end end
	end
	return false
end
local function beceriYaz(f, d)
	if d > 14 or (f.IsShown and not f:IsShown()) then return end
	if f.GetRegions then
		for _, r in ipairs({ f:GetRegions() }) do
			if r.GetObjectType and r:GetObjectType() == "FontString" and r.GetText then
				local t = r:GetText()
				if type(t) == "string" and not G.gizli(t) then
					local en = BECERI[t]
					if en then
						local yeni = G.adStil("stilBuyu", t, en, "|cffaaaaaa")
						if yeni and yeni ~= t then r:SetText(yeni) end
					end
				end
			end
		end
	end
	if f.GetChildren then
		for _, c in ipairs({ f:GetChildren() }) do beceriYaz(c, d + 1) end
	end
end
local BECERI_ADAY = { "SkillFrame", "ClassicSkillsFrame", "CharacterFrame", "SkillsFrame" }
G.basla(function()
	C_Timer.NewTicker(0.7, function()
		pcall(function()
			if not G.ayar("acik") then return end
			if not (beceriKok and beceriKok:IsShown()) then
				beceriKok = nil
				for _, ad in ipairs(BECERI_ADAY) do
					local c = _G[ad]
					if c and c.IsShown and c:IsShown() and not (c.IsForbidden and c:IsForbidden()) and baslikVar(c, 0) then beceriKok = c; break end
				end
			end
			if beceriKok then beceriYaz(beceriKok, 0) end
		end)
	end)
end)

-- Görev pencerelerinde (başlık, açıklama, hedef, takip listesi) İngilizce kalan "Mining" -> "Madencilik"
local function miningDuzelt(tr)
	if type(tr) ~= "string" or not tr:find("Mining", 1, true) then return tr end
	return (tr:gsub("()%f[%a]Mining%f[%A]", function(pos)
		local once = tr:sub(math.max(1, pos - 12), pos - 1)
		local sonra = tr:sub(pos + 6, pos + 11)
		if once:find("Canyon $") or once:find("Deepmountain $") or once:find("Deep Mountain $") or sonra:find("^ Guild") or sonra:find("^ and ") or sonra:find("^ Co") then return nil end
		return "Madencilik"
	end))
end
local GOREV_KOKLER = { "QuestFrame", "QuestLogFrame", "QuestMapFrame", "QuestLogDetailFrame", "QuestLogPopupDetailFrame", "ObjectiveTrackerFrame", "QuestWatchFrame" }
local function gorevYaz(f, d)
	if d > 14 or (f.IsForbidden and f:IsForbidden()) or (f.IsShown and not f:IsShown()) then return end
	if f.GetRegions then
		for _, r in ipairs({ f:GetRegions() }) do
			if r.GetObjectType and r:GetObjectType() == "FontString" and r.GetText then
				local t = r:GetText()
				if type(t) == "string" and not G.gizli(t) and t:find("Mining", 1, true) then
					local y = miningDuzelt(t)
					if y ~= t then r:SetText(y) end
				end
			end
		end
	end
	if f.GetChildren then
		for _, c in ipairs({ f:GetChildren() }) do gorevYaz(c, d + 1) end
	end
end
G.basla(function()
	C_Timer.NewTicker(0.8, function()
		if not G.ayar("acik") then return end
		for _, ad in ipairs(GOREV_KOKLER) do
			local f = _G[ad]
			if f and f.IsShown and f:IsShown() then pcall(gorevYaz, f, 0) end
		end
	end)
end)

-- İngilizce görev adı -> Türkçe (görev verisindeki başlık parmak izinden; yoksa eşya adı)
local baslikIz
local ONEK = { ["Turn in"] = "Teslim et", ["Complete"] = "Tamamla", ["Pick up"] = "Al", ["Accept"] = "Al", ["Objective"] = "Hedef", ["Available"] = "Alınabilir" }
function G.gorevBaslikTr(en)
	if type(en) ~= "string" or en == "" then return nil end
	local tr = G.GorevAdi and G.GorevAdi[en]
	if tr and tr ~= en then return tr end
	if not baslikIz then
		baslikIz = {}
		for _, tablo in ipairs({ G.Veri or {}, G.VeriEk or {} }) do
			for _, v in pairs(tablo) do
				if type(v) == "table" and type(v.b) == "string" and type(v.k) == "table" and v.k.b and not baslikIz[v.k.b] then
					baslikIz[v.k.b] = v.b
				end
			end
		end
	end
	local iz = G.konusmaIz(en, 2)
	tr = iz and baslikIz[iz]
	if tr and tr ~= en then return tr end
	tr = G.Esya and G.Esya[en]
	if type(tr) == "string" and tr ~= en then return tr end
end
function G.gorevSatirTr(s)
	local tr = G.gorevBaslikTr(s)
	if tr then return tr end
	local on, ad = s:match("^([%a ]+): (.+)$")
	if on and ONEK[on] then return ONEK[on] .. ": " .. (G.gorevBaslikTr(ad) or ad) end
end

-- Questie/harita görev ipuçları: "[13] Görev adı" satırından sonra gelen İngilizce görev açıklamasını
-- görev verisindeki Türkçe hedef metniyle değiştir; "(Available)" gibi durumları ve "+100 X" itibar satırını çevir.
local hedefIndeks
local function indeksKur()
	hedefIndeks = {}
	for _, tablo in ipairs({ G.Veri or {}, G.VeriEk or {} }) do
		for _, v in pairs(tablo) do
			if type(v) == "table" and type(v.b) == "string" and type(v.h) == "string" and v.h ~= "" and not hedefIndeks[v.b] then hedefIndeks[v.b] = v.h end
		end
	end
end
local DURUM_TR = { ["Available"] = "Alınabilir", ["Completed"] = "Tamamlandı", ["In Progress"] = "Devam ediyor", ["Failed"] = "Başarısız", ["Complete"] = "Tamamlandı" }
local function sade(t) return (t:gsub("|T.-|t", ""):gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", ""):gsub("^%s+", ""):gsub("%s+$", "")) end
local function ipucuGorevAciklama(tt)
	local ad = tt.GetName and tt:GetName()
	if not ad then return end
	local n = tt:NumLines() or 0
	if n < 2 then return end
	local sonBaslik
	for i = 1, math.min(n, 40) do
		local L = _G[ad .. "TextLeft" .. i]
		local R = _G[ad .. "TextRight" .. i]
		local t = L and L:GetText()
		if type(t) == "string" and not G.gizli(t) then
			local s = sade(t)
			local b = s:match("^%[%d+[%a%+%-]*%]%s*(.+)$")
			if b then
				sonBaslik = b
				if not G.turkceMi(b) then
					local btr = G.gorevBaslikTr(b)
					if btr then
						local yeni = t:gsub(b:gsub("(%W)", "%%%1"), (btr:gsub("%%", "%%%%")), 1)
						L:SetText(yeni)
						if not hedefIndeks then indeksKur() end
						if hedefIndeks[btr] then sonBaslik = btr end
					end
				end
			elseif sonBaslik and #s > 15 and not G.turkceMi(s) and s:find("%a") then
				if not hedefIndeks then indeksKur() end
				local h = hedefIndeks[sonBaslik]
				if h then local hh = (G.gorevAdCevir and G.gorevAdCevir(h)) or h; L:SetText(G.doldur and G.doldur(hh) or hh); tt:Show() end
				sonBaslik = nil
			else
				local fk, ad2 = s:match("^%+(%d+) (.+)$")
				if fk and not G.turkceMi(s) and L:IsShown() then L:SetText("+" .. fk .. " " .. ad2 .. " itibarı") end
			end
		end
		local rt = R and R.GetText and R:GetText()
		if type(rt) == "string" and not G.gizli(rt) and rt:find("%(%a[%a ]*%)") then
			local y = rt:gsub("%((%a[%a ]*)%)", function(d) return DURUM_TR[d] and ("(" .. DURUM_TR[d] .. ")") or nil end)
			if y ~= rt then R:SetText(y) end
		end
	end
end
G.basla(function()
	C_Timer.NewTicker(0.4, function()
		pcall(function()
			if not G.ayar("acik") then return end
			for _, ad in ipairs({ "GameTooltip", "ItemRefTooltip", "WorldMapTooltip", "QuestieTooltip" }) do
				local tt = _G[ad]
				if tt and tt.IsShown and tt:IsShown() and tt.NumLines then pcall(ipucuGorevAciklama, tt) end
			end
		end)
	end)
end)

-- TomTom yol noktası ipucu (harita/mini harita): görev adı Türkçe, "From:" -> "Kaynak:"
local function tomtomIpucu(tt)
	local ad = tt.GetName and tt:GetName()
	if not ad then return end
	local var = false
	for i = 2, math.min(tt:NumLines() or 0, 8) do
		local L = _G[ad .. "TextLeft" .. i]
		local t = L and L:GetText()
		if type(t) == "string" and not G.gizli(t) and t:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):find("^From: ") then var = true end
	end
	if not var then return end
	for i = 1, math.min(tt:NumLines() or 0, 8) do
		local L = _G[ad .. "TextLeft" .. i]
		local t = L and L:GetText()
		if type(t) == "string" and not G.gizli(t) then
			local s = t:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", "")
			if i == 1 and not G.turkceMi(s) then
				local tr = G.gorevSatirTr(s) or (G.Arayuz and G.Arayuz[s])
				if tr and tr ~= s then L:SetText(tr) end
			elseif s:find("^From: ") then
				L:SetText((t:gsub("From: ", "Kaynak: ", 1)))
			end
		end
	end
end
G.basla(function()
	C_Timer.NewTicker(0.3, function()
		pcall(function()
			if not G.ayar("acik") then return end
			for _, ad in ipairs({ "TomTomTooltip", "GameTooltip" }) do
				local tt = _G[ad]
				if tt and tt.IsShown and tt:IsShown() and tt.NumLines then pcall(tomtomIpucu, tt) end
			end
		end)
	end)
end)
