-- Alterac Valley görevleri (2)
-- b=başlık, a=açıklama, h=hedef, i=ilerleme, t=tamamlama
-- k = çevrilen İngilizce metnin parmak izi (metin değişirse çeviri gösterilmez, yeniden kaydedilir)
local V = WoWTurkce.Veri

V[7401] = { b="Aranıyor: DWARF'LAR!", a="Çavuş Yazra Bloodsnarl'ın emriyle, savaş meydanındaki tüm Dwarf'lar görüldükleri yerde öldürülecek.$B$BÇarpışmada bir Dwarf'ı öldürürsen omurgasını sök; geride kalan omurgasız, kokuşmuş leş yığını, Frostwolf'un gücüne karşı çıkmaya cüret eden herkese ibret olsun.$B$BKahramanlığının kanıtıyla Çavuş Yazra Bloodsnarl'a dön.", h="Alterac Valley'de karşı taraftaki Dwarf oyuncularını öldürmekle görevlendirildin.$B$BBir Dwarf öldür ve omurgasını sök. Dwarf Omurgası'nı Frostwolf Keep'teki Çavuş Yazra Bloodsnarl'a götür.", i="Ben toptan ironi satarım, asker.", t="Artık Dwarf'ları düzinelerce biçme ruhsatın var, $C!$B$B<Yazra bir an uzaklara dalar.>$B$Bİlk omurga sökümünü insan asla unutmaz...", k={b=1849684420, a=2776551982, h=3237570386, i=142757890, t=3530797623} }
V[7402] = { b="Aranıyor: ORC'LAR!", a="Onbaşı Noreg Stormpike'ın emriyle, Stormpike'ın tüm sağlam askerlerinin savaş meydanında karşılaştıkları düşman Orc'ları öldürmeleri gerekmektedir.$B$BAskerlerin düşmanın ağzından bir azı ya da diş sökmeleri ve söz konusu dişi başarılarının kanıtı olarak sunmaları gerekmektedir.$B$BKoruyucu eldiven giyin.", h="Alterac Valley'de karşı taraftaki Orc oyuncularını öldürmekle görevlendirildin.$B$BBir Orc öldür ve Orc Dişi'ni Dun Baldar'daki Onbaşı Noreg Stormpike'a götür.", k={b=2455015743, a=2135227785, h=2003915835} }
V[7421] = { b="Darkspear Savunması", k={b=993947132} }
V[7422] = { b="Tutamları Topla", k={b=1989032029} }
V[7423] = { b="Kemik Parçalarına Doyamıyorum", k={b=2277027073} }
V[7424] = { b="Bu Ne Toynak?", i="Topallat onları, $N. Gnome halkının zorbalığa boyun eğmeyeceğini öğrenmeleri gerek!", t="*Dirk toynağı arkasındaki yığına fırlatır.*", k={b=2585978854, i=1994940316, t=3711790701} }
V[7425] = { b="Staghelm'in Mojo Şenliği", k={b=839558983} }
V[7426] = { b="Bir Adamın Sevgisi", k={b=1007522156} }
V[7427] = { b="Aranıyor: DAHA FAZLA DWARF!", k={b=2565086967} }
V[7428] = { b="Aranıyor: DAHA FAZLA ORC!", k={b=1131778898} }
V[8271] = { b="Stormpike Kahramanı", k={b=1546394247} }
V[8272] = { b="Frostwolf Kahramanı", k={b=2620291119} }
V[8369] = { b="Alterac Valley İşgalcileri", a="Beni iyi dinle, $N. Alterac Valley'de kopan savaş hakkında ne duymuş olursan ol, bir gerçek değişmez: Stormpike Seferi, Frostwolf topraklarını işgal etti. İttifak'ın Horde topraklarını işgal etmesine sert bir karşılık vermediğimiz gün, baltamı duvara asar ve ömrümün geri kalanını utanç içinde geçiririm. Git ve işgalcileri kov!", h="3 Alterac Valley Onur Nişanı'nı savaş alanlarının dışındaki bir Horde Savaş Habercisi'ne getir.", i="Frostwolf topraklarından ne haber getirdin? Alterac Valley muharebesi ne durumda?", t="Alterac Valley'deki topraklarımızı korurken büyük cesaret gösterdin! Yaptıklarını üstlerime anlatacağım.", k={b=2617347903, a=2853129161, h=3042529041, i=2186329411, t=3807447608} }
