---------------------------------------------------------------------------------
--
-- Prat - A framework for World of Warcraft chat mods
--
-- Copyright (C) 2006-2018  Prat Development Team
--
-- This program is free software; you can redistribute it and/or
-- modify it under the terms of the GNU General Public License
-- as published by the Free Software Foundation; either version 2
-- of the License, or (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program; if not, write to:
--
-- Free Software Foundation, Inc.,
-- 51 Franklin Street, Fifth Floor,
-- Boston, MA  02110-1301, USA.
--
--
-------------------------------------------------------------------------------

Prat:AddModuleToLoad(function()
	local module = Prat:NewModule("Highlight")
	local PL = module.PL

	Prat:SetModuleDefaults(module.name, {
		profile = {
			on = true,
			player = true,
			guild = true
		}
	})

	local toggleOption = {
		name = function(info)
			return PL[info[#info] .. "_name"]
		end,
		desc = function(info)
			return PL[info[#info] .. "_desc"]
		end,
		type = "toggle",
	}

	Prat:SetModuleOptions(module.name, {
		name = PL.module_name,
		desc = PL.module_desc,
		type = "group",
		args = {
			player = toggleOption,
			guild = toggleOption
		}
	})

	local CLR = Prat.CLR
	local function guildBracket(text)
		return CLR:Colorize("ffffff", text)
	end

	local function guildText(text)
		return CLR:Colorize("00ff00", text)
	end

	local function highlightPlayer(text)
		if module.db.profile.player then
			return Prat:RegisterMatch(CLR:Colorize("00ff00", text))
		end
	end

	local function highlightGuild(text)
		if module.db.profile.guild then
			return Prat:RegisterMatch(guildBracket("<") .. guildText(text) .. guildBracket(">"))
		end
	end

	Prat:SetModulePatterns(module, {
		{ pattern = Prat.GetNamePattern(UnitName("player")), matchfunc = highlightPlayer, priority = 47 },
		{ pattern = "<(..-)>", matchfunc = highlightGuild, priority = 49 },
	})
end)
