local mod	= DBM:NewMod("UnboundSpirit", "DBM-Party-Forever", 8)

mod:SetRevision("20261109015934")
mod:EnableGenericTrash()
mod:SetEncounterID(3336)
mod:SetModelID(131644)
mod:SetZone(2974)

mod:RegisterCombat("combat")
