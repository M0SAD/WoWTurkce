-- Sohbet penceresindeki sistem mesajlarının (sarı, kırmızı, ganimet, tecrübe, itibar...) çevirisi.
-- Oyuncuların kendi yazdıkları mesajlara dokunulmaz.
local G = WoWTurkce

local PARA = { Gold = "Altın", Silver = "Gümüş", Copper = "Bakır" }
local function para(s)
	return (s:gsub("(%d+) (%a+)", function(n, b) return n .. " " .. (PARA[b] or b) end))
end
-- Beceri adı: Türkçesi (gri İngilizcesi). Önce arayüz tablosu, yoksa genel ad çevirisi.
local function beceriAd(a)
	local tr = (G.Arayuz and G.Arayuz[a]) or (G.isimCevir and G.isimCevir(a))
	if type(tr) == "string" and tr ~= a and not tr:find("(", 1, true) then return tr .. " |cffaaaaaa(" .. a .. ")|r" end
	return G.isimCiftDil(a)
end
local SURE = { day = "gün", days = "gün", hour = "saat", hours = "saat", minute = "dakika", minutes = "dakika", second = "saniye", seconds = "saniye" }
local function sure(s)
	return (s:gsub("(%d+) (%a+)", function(n, b) return n .. " " .. (SURE[b] or b) end))
end
-- Bağlantı içindeki eşya ve görev adlarını çevir: |h[Linen Cloth]|h
-- Bağlantılar orijinal adıyla kalır, arkasına Türkçesi gri olarak eklenir:
-- [Linen Cloth] (Keten Kumaş)
local function baglanti(s)
	local parcalar, bas = {}, 1
	while true do
		local i, j, ad = s:find("|h%[(.-)%]|h", bas)
		if not i then break end
		local son = j
		if s:sub(j + 1, j + 2) == "|r" then son = j + 2 end
		local parca = s:sub(bas, son)
		local tr = G.EsyaAdi[ad] or G.esyaSonekli(ad) or G.GorevAdi[ad] or (G.buyuAdiCevir and G.buyuAdiCevir(ad))
		local gorevMi, g = false, nil
		if tr and not G.EsyaAdi[ad] and G.GorevAdi[ad] == tr then gorevMi = true end
		if not tr and s:sub(bas, i + 2):find("|Hachievement:[^|]*|h%[$") then
			local c = G.Arayuz[ad] or (G.cevir and G.cevir(G.Arayuz, ad))
			if type(c) == "string" then tr = c end
		end
		if not tr then
			-- Questie görev bağlantısı: "[8] The Mills Overrun (426)" ya da "[8+] ..."
			g = ad:match("^%[[%d%?%+%s%a]*%]%s*(.-)%s*%(%d+%)$") or ad:match("^%[[%d%?%+%s%a]*%]%s*(.-)$") or ad:match("^(.-)%s*%(%d+%)$")
			tr = g and G.GorevAdi[g]
			if tr then gorevMi = true end
		end
		local onek = s:sub(bas, i + 2)
		local buyuBag = onek:find("|Hspell:[^|]*|h%[$") or onek:find("|Henchant:[^|]*|h%[$") or onek:find("|Htalent:[^|]*|h%[$")
		if tr and tr ~= ad and buyuBag and G.ayar("stilBuyu") == "trEn" then
			-- Büyü bağlantısı: bağlantı metni Türkçe, İngilizcesi yanında gri parantezde
			parca = s:sub(bas, i + 2) .. tr .. "]|h" .. (son > j and "|r" or "")
			parcalar[#parcalar + 1] = parca
			parcalar[#parcalar + 1] = " |cffaaaaaa(" .. ad .. ")|r"
		elseif gorevMi and tr and tr ~= ad and G.ayar("stilGorev") ~= "enTr" then
			-- Görev adı: sohbet için ayrı yazım tercihi (stilGorev)
			local d = G.ayar("stilGorev")
			local trAd = g and (ad:gsub((g:gsub("(%W)", "%%%1")), (tr:gsub("%%", "%%%%")), 1)) or tr
			if d == "en" then
				parcalar[#parcalar + 1] = parca
			else
				parcalar[#parcalar + 1] = s:sub(bas, i + 2) .. trAd .. "]|h" .. (son > j and "|r" or "")
				if d == "trEn" then parcalar[#parcalar + 1] = " |cffaaaaaa(" .. ad .. ")|r" end
			end
		else
			parcalar[#parcalar + 1] = parca
			if tr and tr ~= ad and (gorevMi or G.ayar("stilEsya") ~= "en") then parcalar[#parcalar + 1] = " |cffaaaaaa(" .. tr .. ")|r" end
		end
		bas = son + 1
	end
	parcalar[#parcalar + 1] = s:sub(bas)
	return table.concat(parcalar)
end
local function ad(x) return G.isimCevir(x) or x end
local function rest(e)
	e = e:gsub("%(%+(%d+) exp Rested bonus%)", "(+%1 dinlenmiş bonusu)")
	e = e:gsub("%(%+(%d+) exp group bonus%)", "(+%1 grup bonusu)")
	e = e:gsub("%(%-(%d+) exp Rested penalty%)", "(-%1 dinlenmiş cezası)")
	e = e:gsub("%(%-(%d+) exp group penalty%)", "(-%1 grup cezası)")
	return e
end

-- { desen, Türkçe ya da fonksiyon }  (%1, %2 yakalananlar)
local D = {
	{ "^Your share of the loot is (.+)%.$", function(a) return "Ganimetten payın: " .. para(a) .. "." end },
	{ "^You loot (.+)$", function(a) return "Ganimet: " .. para(a) end },
	{ "^(.+) started a countdown timer%.$", "%1 geri sayım başlattı." },
	{ "^You receive loot: (.+)%.$", "Ganimet aldın: %1." },
	{ "^You receive loot: (.+)$", "Ganimet aldın: %1" },
	{ "^You receive item: (.+)%.$", "Eşya aldın: %1." },
	{ "^You receive item: (.+)$", "Eşya aldın: %1" },
	{ "^You create: (.+)%.$", "Ürettin: %1." },
	{ "^You create: (.+)$", "Ürettin: %1" },
	{ "^(.+) receives item: (.+)%.$", "%1 eşya aldı: %2." },
	{ "^(.+) creates: (.+)%.$", "%1 üretti: %2." },
	{ "^(%S+) creates (.+)%.$", function(k, e) return k .. " üretti: " .. ((WoWTurkce.esyaAdiGoster and WoWTurkce.esyaAdiGoster(e)) or e) .. "." end },
	{ "^You are now passing on random loot%.$", "Artık rastgele ganimetten pas geçiyorsun." },
	{ "^You are now eligible for random loot%.$", "Artık rastgele ganimete katılabilirsin." },
	{ "^(.+) dies, you gain (%d+) experience%.(.*)$", function(a, n, e) return a .. " öldü, " .. n .. " tecrübe kazandın." .. rest(e) end },
	{ "^You gain (%d+) experience%.(.*)$", function(n, e) return n .. " tecrübe kazandın." .. rest(e) end },
	{ "^Experience gained: (%d+)%.$", "Kazanılan tecrübe: %1." },
	{ "^Received (.+)%.$", function(a) return "Alındı: " .. para(a) .. "." end },
	{ "^Received (.+)$", function(a) return "Alındı: " .. para(a) end },
	{ "^Your skill in (.+) has increased to (%d+)%.$", function(a, n) return beceriAd(a) .. " becerin " .. n .. " oldu." end },
	{ "^Your (.+) skill has increased to (%d+)%.$", function(a, n) return beceriAd(a) .. " becerin " .. n .. " oldu." end },
	{ "^Reputation with (.+) increased by (%d+)%.$", "%1 ile itibarın %2 arttı." },
	{ "^Reputation with (.+) decreased by (%d+)%.$", "%1 ile itibarın %2 azaldı." },
	{ "^Your reputation with (.+) has very slightly increased%.$", "%1 ile itibarın çok az arttı." },
	{ "^Your reputation with (.+) has slightly increased%.$", "%1 ile itibarın biraz arttı." },
	{ "^Your reputation with (.+) has increased%.$", "%1 ile itibarın arttı." },
	{ "^Your reputation with (.+) has greatly increased%.$", "%1 ile itibarın çok arttı." },
	{ "^Your reputation with (.+) has decreased%.$", "%1 ile itibarın azaldı." },
	{ "^You are now (.+) with (.+)%.$", "%2 ile artık %1 durumundasın." },
	{ "^Congratulations, you have reached level (%d+)!$", "Tebrikler, %1. seviyeye ulaştın!" },
	{ "^You have gained (%d+) talent points?%.$", "%1 yetenek puanı kazandın." },
	{ "^Your (%a+) increases by (%d+)%.$", function(a, n) return ad(a) .. " " .. n .. " arttı." end },
	{ "^You have learned a new spell: (.+)%.$", function(a) return "Yeni bir büyü öğrendin: " .. G.isimCiftDil(a) .. "." end },
	{ "^You have learned a new ability: (.+)%.$", function(a) return "Yeni bir yetenek öğrendin: " .. G.isimCiftDil(a) .. "." end },
	{ "^You have gained the (.+) skill%.$", function(a) return "Yeni bir beceri kazandın: " .. beceriAd(a) .. "." end },
	{ "^You have unlearned (.+)%.$", function(a) return "Unuttun: " .. G.isimCiftDil(a) .. "." end },
	{ "^You have learned how to create a new item: (.+)%.$", "Yeni bir eşya yapmayı öğrendin: %1." },
	{ "^You have unlearned (.+)%.$", "Unuttun: %1." },
	{ "^Discovered (.+): (%d+) experience gained$", "Keşfedildi: %1 (%2 tecrübe)" },
	{ "^Discovered: (.+)$", "Keşfedildi: %1" },
	{ "^(.+) is now your home%.$", "%1 artık evin." },
	{ "^You feel rested%.$", "Dinlenmiş hissediyorsun." },
	-- İfadeler (/dance, /wave ...)
	{ "^You dance with (.+)%.$", "%1 ile dans ediyorsun." },
	{ "^You burst into dance%.$", "Dans etmeye başlıyorsun." },
	{ "^You greet (.+) with a hearty hello!$", "%1 hedefini içten bir merhabayla selamlıyorsun!" },
	{ "^You greet everyone with a hearty hello!$", "Herkesi içten bir merhabayla selamlıyorsun!" },
	{ "^You wave at (.+)%.$", "%1 hedefine el sallıyorsun." },
	{ "^You wave%.$", "El sallıyorsun." },
	{ "^You laugh at (.+)%.$", "%1 hedefine gülüyorsun." },
	{ "^You laugh%.$", "Gülüyorsun." },
	{ "^You bow before (.+)%.$", "%1 önünde eğiliyorsun." },
	{ "^You bow down graciously%.$", "Zarifçe eğiliyorsun." },
	{ "^You thank (.+)%.$", "%1 hedefine teşekkür ediyorsun." },
	{ "^You thank everyone around you%.$", "Etrafındaki herkese teşekkür ediyorsun." },
	{ "^You cheer at (.+)%.$", "%1 için tezahürat yapıyorsun." },
	{ "^You cheer!$", "Tezahürat yapıyorsun!" },
	{ "^You sit down%.$", "Oturuyorsun." },
	{ "^You salute (.+) with respect%.$", "%1 hedefini saygıyla selamlıyorsun." },
	{ "^You kneel down%.$", "Diz çöküyorsun." },
	{ "^You nod at (.+)%.$", "%1 hedefine başını sallıyorsun." },
	{ "^You nod%.$", "Başını sallıyorsun." },
	{ "^You cry on (.+)'s shoulder%.$", "%1 omzunda ağlıyorsun." },
	{ "^You cry%.$", "Ağlıyorsun." },
	{ "^(.+) waves at you%.$", "%1 sana el sallıyor." },
	{ "^(.+) greets you warmly%.$", "%1 seni sıcak bir şekilde selamlıyor." },
	{ "^(.+) dances with you%.$", "%1 seninle dans ediyor." },
	{ "^(.+) bows before you%.$", "%1 önünde eğiliyor." },
	{ "^(.+) thanks you%.$", "%1 sana teşekkür ediyor." },
	{ "^(.+) laughs at you%.$", "%1 sana gülüyor." },
	{ "^Friend request has been sent%.?$", "Arkadaşlık isteği gönderildi." },
	{ "^You no longer feel rested%.$", "Artık dinlenmiş hissetmiyorsun." },
	{ "^(.+) has joined the party%.$", "%1 gruba katıldı." },
	{ "^(.+) joins the party%.$", "%1 gruba katıldı." },
	{ "^(.+) has joined the raid group%.$", "%1 raid grubuna katıldı." },
	{ "^(.+) leaves the party%.$", "%1 gruptan ayrıldı." },
	{ "^(.+) has left the raid group%.$", "%1 raid grubundan ayrıldı." },
	{ "^(.+) is now the group leader%.$", "%1 artık grup lideri." },
	{ "^(.+) is now the loot master%.$", "%1 artık ganimet sorumlusu." },
	{ "^You are now the group leader%.$", "Artık grup liderisin." },
	{ "^You leave the group%.$", "Gruptan ayrıldın." },
	{ "^You have left the raid group$", "Raid grubundan ayrıldın" },
	{ "^Your group has been disbanded%.$", "Grubun dağıtıldı." },
	{ "^You have been removed from the group%.$", "Gruptan çıkarıldın." },
	{ "^You have invited (.+) to join your group%.$", "%1 adlı oyuncuyu gruba davet ettin." },
	{ "^You gained: (.+)$", "Kazandın: %1" },
	{ "^(.+) declines your group invitation%.$", "%1 grup davetini reddetti." },
	{ "^(.+) is already in a group%.$", "%1 zaten bir grupta." },
	{ "^You have converted to a raid group$", "Raid grubuna dönüştürüldü" },
	{ "^Looting changed to (.+)%.$", function(a) return "Ganimet yöntemi: " .. ad(a) .. "." end },
	{ "^Loot threshold set to:? (.-)%.?$", function(a) local k = a:gsub("%.$", ""); return "Ganimet eşiği ayarlandı: " .. (G.Arayuz[k] or G.isimCevir(k) or k) .. "." end },
	{ "^(.+) has gone offline%.$", "%1 çevrimdışı oldu." },
	{ "^(.+) has come online%.$", "%1 çevrimiçi oldu." },
	{ "^(.+) is Away from Keyboard: (.+)$", "%1 klavyeden uzakta: %2" },
	{ "^You are now Away: (.+)$", "Artık uzaktasın: %1" },
	{ "^You are now Away%.?$", "Artık uzaktasın." },
	{ "^You are no longer Away%.?$", "Artık uzakta değilsin." },
	{ "^(.+) is Away:%s*(.*)$", "%1 uzakta: %2" },
	{ "^You are now Busy: (.+)$", "Artık meşgulsün: %1" },
	{ "^You are no longer marked Busy%.?$", "Artık meşgul değilsin." },
	{ "^(.+) does not wish to be disturbed:%s*(.*)$", "%1 rahatsız edilmek istemiyor: %2" },
	{ "^You are now AFK: (.+)$", "Artık AFK'sın: %1" },
	{ "^You are no longer AFK%.$", "Artık AFK değilsin." },
	{ "^You are now DND: (.+)$", "Artık rahatsız etme modundasın: %1" },
	{ "^You are no longer marked DND%.$", "Artık rahatsız etme modunda değilsin." },
	{ "^(.+) rolls (%d+) %((%d+)%-(%d+)%)$", "%1 zar attı: %2 (%3-%4)" },
	{ "^(.+) has selected (.+) for: (.+)$", function(a, b, c) return a .. " seçimi: " .. (b == "Need" and "İhtiyaç" or b == "Greed" and "Açgözlülük" or b) .. " - " .. c end },
	{ "^You have selected (.+) for: (.+)$", function(b, c) return "Seçimin: " .. (b == "Need" and "İhtiyaç" or b == "Greed" and "Açgözlülük" or b) .. " - " .. c end },
	{ "^Need Roll %- (%d+) for (.+) by (.+)$", "İhtiyaç zarı - %1: %2 (%3)" },
	{ "^Greed Roll %- (%d+) for (.+) by (.+)$", "Açgözlülük zarı - %1: %2 (%3)" },
	{ "^(.+) won: (.+)$", "%1 kazandı: %2" },
	{ "^You won: (.+)$", "Kazandın: %1" },
	{ "^(.+) passed on: (.+)$", "%1 pas geçti: %2" },
	{ "^You passed on: (.+)$", "Pas geçtin: %1" },
	{ "^Everyone passed on: (.+)$", "Herkes pas geçti: %1" },
	{ "^Duel starting: (%d+)$", "Düello başlıyor: %1" },
	{ "^(.+) has defeated (.+) in a duel$", "%1, düelloda %2 adlı oyuncuyu yendi" },
	{ "^(.+) has fled from (.+) in a duel$", "%1, düelloda %2 karşısından kaçtı" },
	{ "^(.+) has challenged you to a duel%.$", "%1 seni düelloya davet etti." },
	{ "^Total time played: (.+)$", function(a) return "Toplam oynama süresi: " .. sure(a) end },
	{ "^Time played this level: (.+)$", function(a) return "Bu seviyede oynama süresi: " .. sure(a) end },
	{ "^(.+) has invited you to join a group%.$", "%1 seni bir gruba davet etti." },
	{ "^(.+) is ignoring you%.$", "%1 seni yoksayıyor." },
	{ "^No player named '(.+)' is currently playing%.$", "'%1' adında şu an oynayan bir oyuncu yok." },
	{ "^(.+) is not playing%.$", "%1 oynamıyor." },
	{ "^(.+) has been added to your friends list%.$", "%1 arkadaş listene eklendi." },
	{ "^(.+) has been removed from your friends list%.$", "%1 arkadaş listenden çıkarıldı." },
	{ "^(.+) is now being ignored%.$", "%1 artık yoksayılıyor." },
	{ "^(.+) is no longer being ignored%.$", "%1 artık yoksayılmıyor." },
	{ "^(.+) has requested to trade%.?.*$", "%1 takas istiyor." },
	{ "^Interface action failed because of an AddOn%.?$", "Bir eklenti nedeniyle arayüz işlemi başarısız oldu." },
	{ "^Speech to text allows you to add closed captioning in a voice channel%.?$", "Yazıya çevirme, sesli kanala altyazı eklemeni sağlar." },
	{ "^Type ['\"]?/help['\"]? for a listing of a few commands%.?$", "Birkaç komutun listesi için '/help' yaz." },
	{ "^Trade complete%.$", "Takas tamamlandı." },
	{ "^Trade cancelled%.$", "Takas iptal edildi." },
	{ "^You are now in (.+)%.$", "Artık %1 bölgesindesin." },
	{ "^Changed Channel: (.+)$", "Kanal değişti: %1" },
	{ "^Joined Channel: (.+)$", "Kanala katıldın: %1" },
	{ "^Left Channel: (.+)$", "Kanaldan ayrıldın: %1" },
	{ "^(%d+) players? total$", "Toplam %1 oyuncu" },
	{ "^(.+) has earned the achievement (.+)!$", "%1 başarım kazandı: %2!" },
	-- Oyuncunun kayıtlarından eklenenler
	{ "^(.+) receives loot: (.+)%.$", "%1 ganimet aldı: %2." },
	{ "^You feel normal%.$", "Normal hissediyorsun." },
	{ "^Dungeon difficulty set to Normal$", "Zindan zorluğu Normal olarak ayarlandı" },
	{ "^Dungeon difficulty set to Heroic$", "Zindan zorluğu Kahramanlık olarak ayarlandı" },
	{ "^You are now passing on random loot%.$", "Artık rastgele ganimetlerde pas geçiyorsun." },
	{ "^You are now eligible for random loot%.$", "Artık rastgele ganimetlere katılabilirsin." },
	{ "^Everyone is Ready$", "Herkes hazır" },
	{ "^Starting ready check%.%.%.$", "Hazır kontrolü başlatılıyor..." },
	{ "^(.+) is not ready$", "%1 hazır değil" },
	{ "^The following players are Away: (.+)$", "Klavyeden uzakta olan oyuncular: %1" },
	{ "^You have requested to trade with (.+)%.$", "%1 ile takas isteği gönderdin." },
	{ "^Your equipped items suffer a (%d+)%% durability loss%.$", "Kuşandığın eşyalar %%%1 dayanıklılık kaybetti." },
	{ "^Duel cancelled%.$", "Düello iptal edildi." },
	{ "^You have been Tricked or Treated recently%.?$", "Yakın zamanda zaten şeker ya da şaka yapıldın." },
	{ "^(.+) attempts to run away in fear!$", "%1 korku içinde kaçmaya çalışıyor!" },
	{ "^(.+) has invited you to a duel%.$", "%1 seni düelloya davet etti." },
	{ "^You are already in a group%.$", "Zaten bir gruptasın." },
	{ "^You are not in a party%.$", "Bir grupta değilsin." },
	{ "^You have learned a new passive effect: (.+)%.$", function(a) return "Yeni bir pasif etki öğrendin: " .. G.isimCiftDil(a) .. "." end },
}

local sohbetCevirAsil
local function sohbetCevir(msg)
	G._sohbetModu = true
	local ok, tr = pcall(sohbetCevirAsil, msg)
	G._sohbetModu = nil
	if ok then return tr end
end
sohbetCevirAsil = function(msg)
	if type(msg) ~= "string" or msg == "" or G.turkceMi(msg) then return nil end
	-- Tüm satırı saran renk kodu: içini çevir, rengi geri koy
	do
		local c1, core, c2 = msg:match("^(|[cC]%x%x%x%x%x%x%x%x)(.*)(|[rR])$")
		if c1 and not core:find("|[rR]") then
			local t = sohbetCevirAsil(core)
			if t then return c1 .. t .. c2 end
		end
		-- Satır başındaki "You:" / "Sen:" önekli biçimler ("You: have invited ...")
		local k = msg:match("^You: (.+)$")
		if k then
			local t = sohbetCevirAsil("You " .. k)
			if t then return t end
		end
	end
	-- Beceri yükselmesi: tablodaki hazır çeviri yerine adı "Türkçe (English)" göster
	do
		local b, sy = msg:match("^Your skill in (.+) has increased to (%d+)%.$")
		if not b then b, sy = msg:match("^Your (.+) skill has increased to (%d+)%.$") end
		if b then return beceriAd(b) .. " becerin " .. sy .. " oldu." end
	end
	local tr = (G.hataCevir and G.hataCevir(msg))
	if not tr then
		for _, d in ipairs(D) do
			local a, b, c, e = msg:match(d[1])
			if a then
				if type(d[2]) == "function" then tr = d[2](a, b, c, e)
				else tr = (msg:gsub(d[1], d[2])) end
				break
			end
		end
	end
	if not tr and G.arayuzCevir and not msg:find("|H") then tr = G.arayuzCevir(msg) end
	if tr then return baglanti(tr) end
	if msg:find("|h%[") then
		local b = baglanti(msg)
		if b ~= msg then return b end
	end
end
G.sohbetCevir = sohbetCevir

local OLAYLAR = {
	"CHAT_MSG_SYSTEM", "CHAT_MSG_LOOT", "CHAT_MSG_MONEY", "CHAT_MSG_COMBAT_XP_GAIN",
	"CHAT_MSG_COMBAT_FACTION_CHANGE", "CHAT_MSG_SKILL", "CHAT_MSG_TRADESKILLS", "CHAT_MSG_OPENING",
	"CHAT_MSG_COMBAT_HONOR_GAIN", "CHAT_MSG_RESTRICTED", "CHAT_MSG_FILTERED", "CHAT_MSG_IGNORED",
	"CHAT_MSG_BG_SYSTEM_NEUTRAL", "CHAT_MSG_BG_SYSTEM_ALLIANCE", "CHAT_MSG_BG_SYSTEM_HORDE",
	"CHAT_MSG_RAID_BOSS_EMOTE", "CHAT_MSG_PET_INFO", "CHAT_MSG_COMBAT_MISC_INFO", "CHAT_MSG_ACHIEVEMENT", "CHAT_MSG_GUILD_ACHIEVEMENT",
	"CHAT_MSG_CHANNEL_NOTICE", "CHAT_MSG_CHANNEL_NOTICE_USER", "CHAT_MSG_TEXT_EMOTE",
}

local function filtre(_, olay, msg, ...)
	if not G.modul("arayuz") or G.gizli(msg) or type(msg) ~= "string" then return false end
	local ok, tr = pcall(sohbetCevir, msg)
	-- Para birimleri her sistem satırında Türkçe olsun ("Alındı: 1 Silver, 75 Copper." -> "1 Gümüş, 75 Bakır")
	local function paraDuzelt(x)
		if type(x) ~= "string" or not x:find("%d+ [GSC][oiu][lp]") then return x end
		for en, trp in pairs(PARA) do x = x:gsub("(%d+) " .. en .. "%f[%A]", "%1 " .. trp) end
		return x
	end
	if ok and tr then return false, paraDuzelt(tr), ... end
	do
		local pd = paraDuzelt(msg)
		if pd ~= msg then return false, pd, ... end
	end
	if ok and olay ~= "CHAT_MSG_TEXT_EMOTE" and type(msg) == "string" and msg ~= "" and not G.turkceMi(msg) then
		-- Çevrilmeyenleri kaydet: bağlantılar [X], sayılar # olur
		local s = msg:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", ""):gsub("|H.-|h(.-)|h", "%1")
		s = s:gsub("%[.-%]", "[X]"):gsub("%d+", "#")
		if #s >= 4 and #s < 300 then G.kaydetDiger("sohbet", s) end
	end
	if ok and olay ~= "CHAT_MSG_TEXT_EMOTE" and msg:find("^[|%w]") and (msg:find("You", 1, true) or msg:find("Sen", 1, true)) then
		G.tani = G.tani or {}
		G.tani.sysSon = olay:gsub("CHAT_MSG_", "") .. ": " .. (msg:sub(1, 160):gsub("|", "||"))
	end
	return false
end

-- Oyuncuların yazdığı mesajlar: yazının kendisine dokunmayız, sadece içindeki eşya/görev/büyü
-- bağlantılarının arkasına Türkçesini gri olarak ekleriz.
local OYUNCU = {
	"CHAT_MSG_SAY", "CHAT_MSG_YELL", "CHAT_MSG_PARTY", "CHAT_MSG_PARTY_LEADER", "CHAT_MSG_RAID", "CHAT_MSG_RAID_LEADER",
	"CHAT_MSG_RAID_WARNING", "CHAT_MSG_GUILD", "CHAT_MSG_OFFICER", "CHAT_MSG_WHISPER", "CHAT_MSG_WHISPER_INFORM",
	"CHAT_MSG_CHANNEL", "CHAT_MSG_INSTANCE_CHAT", "CHAT_MSG_INSTANCE_CHAT_LEADER", "CHAT_MSG_BN_WHISPER",
	"CHAT_MSG_BN_WHISPER_INFORM", "CHAT_MSG_EMOTE",
}
-- Questie görev duyuruları (grup/say mesajı): "|T..|t 6/6 Duskbat Wing for [[2] The Damned]!" ve "Quest Completed: ..."
local function questieDuyuru(msg)
	local on, sy, gv, son = msg:match("^(.-)(%d+/%d+) (.-) for (|[cH].+)$")
	if on and (on == "" or on:find("^Questie: ") or (on:gsub("|T.-|t", ""):gsub("|A.-|a", ""):gsub("%s+", "") == "")) then
		local yad = gv:match("^(.-) slain$")
		local ad
		if yad then
			local g = G.yaratikCevir and G.yaratikCevir(yad)
			ad = (g or yad) .. " öldürüldü" -- sözlükte yoksa İngilizce ad kalır, cümle yine Türkçe
		else
			ad = G.Arayuz[gv] or (G.esyaAdiGoster and G.esyaAdiGoster(gv)) or (G.modul("yaratik") and G.Yaratik[gv])
		end
		ad = ad or gv -- sözlükte yoksa (ya da zaten Türkçeyse) olduğu gibi bırak, "for" yine çevrilsin
		son = son:gsub("%(Complete%)", "(Tamamlandı)"):gsub("%(Failed%)", "(Başarısız)")
		return on .. sy .. " " .. ad .. " – " .. son
	end
	local on2, rest = msg:match("^(.-)Quest Completed: (|[cH].+)$")
	if on2 and (on2 == "" or on2:find("^Questie: ") or (on2:gsub("|T.-|t", ""):gsub("|A.-|a", ""):gsub("%s+", "") == "")) then return on2 .. "Görev tamamlandı: " .. rest end
end
local function oyuncuFiltre(_, olay, msg, ...)
	do
		local ta = G.tani
		if ta then
			ta.oyuncuCagri = (ta.oyuncuCagri or 0) + 1
			if type(msg) == "string" and (G.gizli(msg) or msg:find("%d+/%d+ ")) then
				local gz = G.gizli(msg)
				local eslesme = false
				if not gz then local okq, qq = pcall(questieDuyuru, msg); eslesme = okq and qq ~= nil end
				ta.oyuncuSon = ("%s | gizli=%s | eslesme=%s | %s"):format(tostring(olay), tostring(gz), tostring(eslesme), gz and "<gizli>" or (msg:sub(1, 200):gsub("|", "||")))
			end
		end
	end
	if G.modul("arayuz") and type(msg) == "string" and not G.gizli(msg) and msg:find("^Questie: ") and G.hedefCevir then
		local q = G.hedefCevir(msg)
		if q then return false, q, ... end
	end
	if not G.modul("arayuz") or type(msg) ~= "string" or G.gizli(msg) or not msg:find("|h%[") then return false end
	local orijinal = msg
	do local ok0, q0 = pcall(questieDuyuru, msg); if ok0 and q0 then msg = q0 end end
	local m2 = msg:gsub("(|h%[)Join: ", "%1Katıl: ")
	local ok, b = pcall(baglanti, m2)
	if ok and b and b ~= orijinal then return false, b, ... end
	-- Bağlantı eklemesi yoksa bile duyuru çevrildiyse çevrilmiş metni göster
	if m2 ~= orijinal then return false, m2, ... end
	return false
end

G.basla(function()
	local filtreEkle = ChatFrame_AddMessageEventFilter or (ChatFrameUtil and ChatFrameUtil.AddMessageEventFilter)
	if not filtreEkle then return end
	for _, e in ipairs(OLAYLAR) do
		pcall(filtreEkle, e, filtre)
	end
	for _, e in ipairs(OYUNCU) do
		pcall(filtreEkle, e, oyuncuFiltre)
	end
end)

-- Girişte sohbete doğrudan yazılan güvenlik uyarısı (olay değil, doğrudan AddMessage ile yazılıyor):
-- metni yazılmadan önce Türkçesiyle değiştir. Bağlantı aynen korunur.
do
	local function guvenlikNotu()
		if type(ONLINE_SAFETY_NOTICE) ~= "string" or G.turkceMi(ONLINE_SAFETY_NOTICE) then return end
		if WoWTurkce_Ayar and WoWTurkce_Ayar.acik == false then return end
		local tr = G.cevir(G.Arayuz, ONLINE_SAFETY_NOTICE)
		if tr then ONLINE_SAFETY_NOTICE = tr end
	end
	local f = CreateFrame("Frame")
	f:RegisterEvent("ADDON_LOADED")
	f:SetScript("OnEvent", function(self, _, ad)
		if ad == "WoWTurkce" then pcall(guvenlikNotu); self:UnregisterAllEvents() end
	end)
end

-- Eklentilerin sohbete doğrudan yazdığı bilgi satırları (olay değil, AddMessage ile): bilinen kalıpları çevir.
-- Oyuncu mesajlarına dokunmamak için yalnızca aşağıdaki özel kalıplar eşleşirse değiştirilir.
do
	G.tani = G.tani or {}
	local EKLENTI = {
		{ "%[HealBot%]%s+(%S+)%s+loaded%.%s*For options use:%s*(%S+)", function(v, k) return "[HealBot] " .. v .. " yüklendi. Seçenekler için: " .. k end },
		{ "Sende invited (.-) to join your group%. var", function(a) return a .. " adlı oyuncuyu gruba davet ettin." end },
		{ "GatherMate2?Data has been imported%.?", function() return "GatherMate2Data içe aktarıldı." end },
		{ "GatherMate data has been imported%.?", function() return "GatherMate verisi içe aktarıldı." end },
		{ "You have invited (.-) to join your group%.", function(a) return a .. " adlı oyuncuyu gruba davet ettin." end },
		{ "You have an outdated version of Questie!", function() return "Questie sürümün güncel değil!" end },
		{ "Please consider updating!", function() return "Lütfen güncellemeyi düşün!" end },
		{ "[Pp]lease wait a moment for Questie to finish loading", function() return "Lütfen Questie'nin yüklenmesini bitirmesi için biraz bekle" end },
		{ "L\195\188tfen bekleyin a moment for Questie to finish loading", function() return "Lütfen Questie'nin yüklenmesini bitirmesi için biraz bekle" end },
		{ "Thank you for helping improve Questie!?%s*Your gameplay data is being collected locally on this device%.?",
			function() return "Questie'nin gelişmesine yardım ettiğin için teşekkürler! Oynanış verilerin yalnızca bu cihazda yerel olarak toplanıyor." end },
	}
	local function eklentiSatiri(msg)
		if type(msg) ~= "string" or #msg > 600 then return nil end
		-- Questie görev duyuruları (geçmişteki eski satırlar dahil)
		if msg:find("|H", 1, true) and msg:find("%d+/%d+ ") then
			local q = questieDuyuru(msg)
			if q and q ~= msg then return q end
		end
		-- Simgeli para satırı ("You gained: 24 [bakır simgesi]"): simgeyi koruyarak yalnızca başlığı çevir
		do
			local m2, k = msg:gsub("^(.-)You gained:", "%1Kazandın:", 1)
			if k > 0 then return m2 end
		end
		-- QuestieTrace: renk ve bağlantılar korunur, yalnızca cümleler çevrilir
		if msg:find("QuestieTrace", 1, true) then
			local y = msg
			y = y:gsub("It is time to share your trace data again%. Each submission only covers what happened so far, so please keep submitting regularly%.",
				"İzleme verilerini paylaşma zamanı yine geldi. Her gönderim yalnızca o ana kadar olanları kapsar, bu yüzden lütfen düzenli olarak göndermeye devam et.")
			y = y:gsub("Click here to open the export window", "Dışa aktarma penceresini açmak için buraya tıkla")
			if y ~= msg then return y end
		end
		local sade = msg:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", ""):gsub("|T.-|t", "")
		for _, d in ipairs(EKLENTI) do
			local bas, son, a, b = sade:find(d[1])
			if bas then
				return sade:sub(1, bas - 1) .. d[2](a, b) .. sade:sub(son + 1)
			end
		end
	end
	local function gecmisDuzelt(cf)
		local hb = cf and cf.historyBuffer
		if not (hb and hb.GetNumElements and hb.GetEntryAtIndex) then return false end
		local degisti = false
		for k = 1, hb:GetNumElements() do
			local e = hb:GetEntryAtIndex(k)
			if type(e) == "table" and type(e.message) == "string" then
				local ok, tr = pcall(eklentiSatiri, e.message)
				if ok and tr then e.message = tr; degisti = true end
			end
		end
		if degisti and cf.RefreshDisplay then pcall(cf.RefreshDisplay, cf) end
		return degisti
	end
	G.SohbetKaliplari = {
		{ "I raise my brew %S+ hope to be rid of the likes of you!%s+Cheers, you no good scoundrel, ([^|!]-)!", "Kadehimi kaldırıyorum ve senin gibilerden kurtulmayı umuyorum! Şerefe, seni işe yaramaz hergele, %1!" },
		{ "Thank you, ([^|%.]-)%.%s+You have tempered the cold rage in my heart%.", "Teşekkürler, %1. Yüreğimdeki soğuk öfkeyi yatıştırdın." },
	}
	local function kur()
		local say = 0
		for i = 1, (NUM_CHAT_WINDOWS or 10) do
			local cf = _G["ChatFrame" .. i]
			if cf and cf.AddMessage and not cf._gtrEklenti then
				cf._gtrEklenti = true
				say = say + 1
				local orijinal = cf.AddMessage
				cf.AddMessage = function(self, msg, ...)
					G.tani.ekCagri = (G.tani.ekCagri or 0) + 1
					if type(msg) == "string" and (msg:find("HealBot", 1, true) or msg:find("Questie", 1, true)) then G.tani.ekSon = msg:sub(1, 160) end
					-- NPC konuşmaları: "X says: " -> "X: " (der yazılmaz), "X yells: " -> "X bağırır: ", "X whispers: " -> "X fısıldar: "
					-- ve NPC adı Türkçe: "Esir Dağcı (Captured Mountaineer): ..."
					if type(msg) == "string" and G.modul("balon") and not msg:find("|Hplayer:", 1, true) then
						local ad, fiil, govde
						for _, k in ipairs({ { "says", "" }, { "der", "" }, { "yells", " bağırır" }, { "bağırır", " bağırır" }, { "whispers", " fısıldar" }, { "fısıldar", " fısıldar" } }) do
							local a, g = msg:match("^(.-) " .. k[1] .. ": (.*)$")
							if a and a ~= "" and #a < 60 and not a:find("|", 1, true) then ad, fiil, govde = a, k[2], g; break end
						end
						if ad then
							local yazi = ad
							if not ad:find("(", 1, true) then
								local okT, tr = pcall(G.adTr, ad)
								if okT and type(tr) == "string" and tr ~= "" and tr ~= ad then
									local okS, y = pcall(G.adStil, "stilSohbetNpc", tr, ad)
									if okS and type(y) == "string" then yazi = y end
								end
							end
							msg = yazi .. fiil .. ": " .. govde
						end
					end
					-- Oyuncu adı içeren NPC cümleleri (ad değiştiği için kalıp ile)
					if type(msg) == "string" and G.modul("arayuz") then
						for _, k in ipairs(G.SohbetKaliplari) do
							local n2, c = msg:gsub(k[1], k[2], 1)
							if c > 0 then msg = n2 break end
						end
					end
					if G.modul("arayuz") then
						local ok, tr = pcall(eklentiSatiri, msg)
						if ok and tr then msg = tr; G.tani.ekCevrilen = (G.tani.ekCevrilen or 0) + 1 end
					end
					return orijinal(self, msg, ...)
				end
			end
		end
		G.tani.ekKurulu = say
	end
	local function gecmis()
		if not G.modul("arayuz") then return end
		for i = 1, (NUM_CHAT_WINDOWS or 10) do
			local cf = _G["ChatFrame" .. i]
			if cf and gecmisDuzelt(cf) then G.tani.ekGecmis = (G.tani.ekGecmis or 0) + 1 end
		end
	end
	G.basla(function()
		kur()
		local f = CreateFrame("Frame")
		f:RegisterEvent("PLAYER_ENTERING_WORLD")
		f:SetScript("OnEvent", function()
			kur()
			for _, t in ipairs({ 0.5, 1, 2, 4, 8, 15 }) do C_Timer.After(t, gecmis) end
		end)
		for _, t in ipairs({ 0.5, 1, 2, 4, 8, 15 }) do C_Timer.After(t, gecmis) end
	end)
end
