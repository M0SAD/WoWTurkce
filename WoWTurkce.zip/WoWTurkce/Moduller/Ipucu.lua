-- İpucu (tooltip) çevirisi: eşya satırları ve büyü/yetenek açıklamaları.
-- Sadece görünen ipuçlarına dokunur; diğer addon'ların gizli tarama ipuçlarına dokunmaz.
local G = WoWTurkce

local HEDEFLER = { "GameTooltip", "ItemRefTooltip", "ShoppingTooltip1", "ShoppingTooltip2", "ShoppingTooltip3", "ItemRefShoppingTooltip1", "ItemRefShoppingTooltip2", "ItemRefShoppingTooltip3" }
local hedef = {}

-- "Equip: ...", "Use: ..." gibi önekler; öneki çevirip kalanı ayrıca dener
local ONEKLER = {
	{ "Equip: ", "Kuşanınca: " },
	{ "Use: ", "Kullan: " },
	{ "Chance on hit: ", "Vuruşta şans: " },
	{ "Requires ", "Gerekli: " },
	{ "Classes: ", "Sınıflar: " },
	{ "Races: ", "Irklar: " },
	-- Öneki başka bir yerde (arayüz taraması) zaten çevrilmiş satırlar: kalanını yine çevir
	{ "Kuşanınca: ", "Kuşanınca: " },
	{ "Kullan: ", "Kullan: " },
	{ "Vuruşta şans: ", "Vuruşta şans: " },
}

-- Renk kodunu ayır: "|cff00ff00Equip: ...|r" -> "|cff00ff00", "Equip: ...", "|r"
local function renkAyir(s)
	local bas, govde, son = s:match("^(|c%x%x%x%x%x%x%x%x)(.-)(|r)$")
	if bas then return bas, govde, son end
	return "", s, ""
end

-- Yemek (Well Fed) açıklamaları: sayılar, süre birimi ve bonus çeşitli olsa da çevirir
local BIRIM = { sec = "sn", secs = "sn", second = "sn", seconds = "sn", min = "dk", mins = "dk", minute = "dk", minutes = "dk", hr = "saat", hrs = "saat", hour = "saat", hours = "saat" }
local STAT = { Haste = "Hız", Mastery = "Ustalık", Versatility = "Çok Yönlülük", ["Critical Strike"] = "Kritik Vuruş", Intellect = "Zeka", Strength = "Güç", Agility = "Çeviklik", Stamina = "Dayanıklılık", Speed = "Hız", Armor = "Zırh", Leech = "Can Çalma", Avoidance = "Sıyrılma" }
local function bonusCevir(b)
	local n, st, sure, br = b:match("^(%d+) ([%a ]+) for (%d+) (%a+)%.?$")
	if n and STAT[st] and BIRIM[br] then return ("%s %s %s boyunca %s %s kazanırsın."):format("tok olursun ve", sure, BIRIM[br], n, STAT[st]) end
	if b:match("^Speed for a short time after killing an enemy%.?$") then return "tok olursun ve bir düşmanı öldürdükten sonra kısa süreliğine Hız kazanırsın." end
	local ad, dmg, sure2, br2 = b:match("^a chance while attacking to unleash a volley of (.-) fireballs, each dealing (%d+) Fire damage%. This bonus lasts (%d+) (%a+)%.?$")
	if ad and BIRIM[br2] then
		local adtr = (G.buyuAdiCevir and G.buyuAdiCevir(ad)) or ad
		return ("tok olursun ve saldırırken her biri %s Ateş hasarı veren bir %s ateş topu yağmuru fırlatma şansı kazanırsın. Bu bonus %s %s sürer."):format(dmg, adtr, sure2, BIRIM[br2])
	end
end
local function yemekCevir(s)
	local ayir = "[%s|n]*"
	local yuzde, sure, br, ara, es, bonus = s:match("^Restores up to (%d+)%% of your maximum health and mana every second over (%d+) (%a+)%. Must remain seated while eating%.(" .. ayir .. ")If you spend at least (%d+) seconds eating you will become well fed and gain (.+)$")
	local bt
	if yuzde and BIRIM[br] then
		bt = bonusCevir(bonus)
		if bt then return ("%s %s boyunca her saniye maksimum canının ve mananın %%%s kadarını yeniler. Yerken oturmaya devam etmelisin.%sEn az %s saniye yemek yersen %s"):format(sure, BIRIM[br], yuzde, ara, es, bt) end
		return nil
	end
	local ara2, es2, bonus2 = s:match("^(" .. ayir .. ")If you spend at least (%d+) seconds eating you will become well fed and gain (.+)$")
	if es2 then
		bt = bonusCevir(bonus2)
		if bt then return ara2 .. ("En az %s saniye yemek yersen %s"):format(es2, bt) end
	end
end
local function buzCevir(s)
	local sure, br, dmg, yav, sure2, br2, kalan = s:match("^Sheathe your weapons in ice for (%d+) (%a+), giving your melee attacks a chance to cause (%d+) additional Frost damage and slow the target's movement speed by (%d+)%% for (%d+) (%a+)%.%s*(.*)$")
	if sure and BIRIM[br] and BIRIM[br2] then
		local bek = kalan:match("%((%d+) (%a+) Cooldown%)")
		local bn, bb = kalan:match("%((%d+) (%a+) Cooldown%)")
		local son = (bn and BIRIM[bb:lower()]) and ((" (%s %s Bekleme)"):format(bn, BIRIM[bb:lower()])) or ""
		return ("Silahlarını %s %s boyunca buzla kaplar; yakın dövüş saldırılarına %s ek Buz hasarı verme ve hedefin hareket hızını %%%s oranında %s %s yavaşlatma şansı verir.%s"):format(sure, BIRIM[br], dmg, yav, sure2, BIRIM[br2], son)
	end
end

-- Tarif öğretme satırları: "Teaches you how to craft X." -> "X yapmayı öğretir."
local TARIF_FIIL = { craft = "yapmayı", make = "yapmayı", cook = "pişirmeyi", brew = "demlemeyi", sew = "dikmeyi", forge = "dövmeyi", create = "yaratmayı" }
local function tarifCevir(a)
	local tirnak, fiil, ad = a:match('^("?)Teaches you how to (%a+) (.-)%."?$')
	if not fiil then
		local t2, yer = a:match('^("?)Teaches you how to place an? (.-) at a campsite%."?$')
		if not yer then return nil end
		local tr = G.EsyaAdi and G.EsyaAdi[yer]
		local gos = tr and G.adStil("stilEsya", tr, yer) or yer
		return t2 .. "Bir kamp alanına " .. gos .. " kurmayı öğretir." .. t2
	end
	if fiil == "place" or fiil == "permanently" or fiil == "enchant" or fiil == "transmute" then return nil end
	local f = TARIF_FIIL[fiil]; if not f then return nil end
	local tr = G.EsyaAdi and (G.EsyaAdi[ad] or (G.esyaSonekli and G.esyaSonekli(ad)))
	local gos = tr and G.adStil("stilEsya", tr, ad) or ad
	return tirnak .. gos .. " " .. f .. " öğretir." .. tirnak
end

local DESENLER = {
	{ '^("?Teaches you how to %a+ .-%."?)$', function(a) return tarifCevir(a) end },
	{ "^(Restores up to %d+%% of your maximum health and mana every second over .+)$", function(a) return yemekCevir(a) end },
	{ "^([%s|n]*If you spend at least %d+ seconds eating you will become well fed and gain .+)$", function(a) return yemekCevir(a) end },
	{ "^(Sheathe your weapons in ice for .+)$", function(a) return buzCevir(a) end },
	{ "^(Gaining a level triggers Burst of Knowledge.+)$", function(a)
		local hasar, okul, oran, nitelik, dk, ek = a:match("dealing ([%d,%.]+) (%a+) damage to nearby enemies and granting you (%d+)%% (%a+) for (%d+) min%. Defeating enemies extends this effect, up to an additional (%d+) min%.$")
		if not hasar then return nil end
		local OKUL = { Holy = "Kutsal", Fire = "Ateş", Frost = "Buz", Nature = "Doğa", Shadow = "Gölge", Arcane = "Arkan", Physical = "Fiziksel" }
		local NIT = { Agility = "Çeviklik", Strength = "Güç", Intellect = "Zeka" }
		if not OKUL[okul] or not NIT[nitelik] then return nil end
		return "Seviye atlamak Burst of Knowledge'ı tetikler; yakındaki düşmanlara " .. hasar .. " " .. OKUL[okul] .. " hasarı verir ve " .. dk .. " dk boyunca sana %" .. oran .. " " .. NIT[nitelik] .. " kazandırır. Düşmanları yenmek bu etkiyi en fazla " .. ek .. " dk daha uzatır."
	end },
	{ "^Returns you to (.-)%.%s+Speak to an Innkeeper in a different place to change your home location%.%s*(.*)$", function(yer, ek)
		local n, b = ek:match("%((%d+) (%a+) Cooldown%)")
		local BR = { Sec = "sn", Secs = "sn", Min = "dk", Mins = "dk", Hr = "saat", Hrs = "saat", Hour = "saat", Hours = "saat", Day = "gün", Days = "gün" }
		local bek = (n and BR[b]) and (" (" .. n .. " " .. BR[b] .. " Bekleme)") or (ek ~= "" and (" " .. ek) or "")
		return "Seni " .. yer .. " konumuna geri götürür. Ev konumunu değiştirmek için başka bir yerdeki bir hancıyla konuş." .. bek
	end },
}

-- "Requires Level 4, Shadow Word: Pain" / "Requires Herbalism (75)" / "Requires Samuel's Remains"
local function parcaAd(x)
	local n = x:match("^Level (%d+)$")
	if n then return "Seviye " .. n end
	local ad, sv = x:match("^(.-) %((%d+)%)$")
	ad = ad or x
	do
		local a1, a2 = ad:match("^[Ll]evel (%d+) to (%d+)$")
		if a1 then return "Seviye " .. a1 .. " - " .. a2 .. (sv and (" (" .. sv .. ")") or "") end
	end
	local tr = G.Arayuz[ad] or (G.BuyuAdi and G.BuyuAdi[ad]) or (G.buyuAdiCevir and G.buyuAdiCevir(ad)) or (G.esyaAdiGoster and G.esyaAdiGoster(ad))
	if not tr then return nil end
	return sv and (tr .. " (" .. sv .. ")") or tr
end
local function gerekliCevir(kalan)
	local out, hepsi = {}, true
	for p in (kalan .. ", "):gmatch("(.-), ") do
		local tr = parcaAd(p)
		if not tr then hepsi = false end
		out[#out + 1] = tr or p
	end
	return table.concat(out, ", "), hepsi
end

-- Eşya kullanım satırının sonuna oyunun eklediği bekleme süresi: "(1 Sec Cooldown)", "(30 Min Cooldown)"
local BEKLEME_BIRIM = { Sec = "sn", Secs = "sn", Min = "dk", Mins = "dk", Hr = "saat", Hrs = "saat", Hour = "saat", Hours = "saat", Day = "gün", Days = "gün" }
local function beklemeAyir(m)
	local govde, n, b = m:match("^(.-)%s*%((%d+) (%a+) Cooldown%)$")
	if govde and BEKLEME_BIRIM[b] then return govde, " (" .. n .. " " .. BEKLEME_BIRIM[b] .. " Bekleme)" end
	return m, ""
end

local function satirCevir(metin, buyuMu)
	-- Bekleme ve süre satırları: sayı her saniye değişse de kalıp aynı kalır
	local sure = metin:match("^Cooldown remaining: (.+)$") or metin:match("^Kalan bekleme süresi: (.+)$")
	if sure and sure:find("%d+ %a") then return "Kalan bekleme süresi: " .. G.sureCevir(sure) end
	local kalan = metin:match("^(.-) remaining$")
	if kalan and kalan:find("^%d+ %a+") and not kalan:find("[^%w%s%.,]") then return G.sureCevir(kalan) .. " kaldı" end
	for _, d in ipairs(DESENLER) do
		local a, b = metin:match(d[1])
		if a then local r = d[2](a, b or ""); if r then return r end end
	end
	local tr
	if G.modul("ipucu") then tr = G.cevir(G.Esya, metin) end
	if not tr and G.modul("buyu") then tr = G.cevir(G.Buyu, metin) end
	if tr then return tr end
	if G.modul("ipucu") then
		for _, o in ipairs(ONEKLER) do
			if metin:sub(1, #o[1]) == o[1] then
				local kalan = metin:sub(#o[1] + 1)
				if o[1] == "Requires " then
					local g, hepsi = gerekliCevir(kalan)
					return o[2] .. g, hepsi, kalan
				end
				for _, d in ipairs(DESENLER) do
					local a, b = kalan:match(d[1])
					if a then local r = d[2](a, b or ""); if r then return o[2] .. r end end
				end
				local ktr = (G.modul("buyu") and G.cevir(G.Buyu, kalan)) or G.cevir(G.Esya, kalan) or G.buyuAdiCevir(kalan) or G.cevir(G.Arayuz, kalan)
				if not ktr then
					local govde, bek = beklemeAyir(kalan)
					if bek ~= "" then
						local g = (G.modul("buyu") and G.cevir(G.Buyu, govde)) or G.cevir(G.Esya, govde) or G.cevir(G.Arayuz, govde)
						if g then ktr = g .. bek end
					end
				end
				if not ktr and G.ipucu2 then
					local tam2 = G.ipucu2(metin)
					if tam2 then return tam2 end
				end
				if ktr or not G.arayuzCevir then return o[2] .. (ktr or kalan), ktr ~= nil, kalan end
				local atr = G.arayuzCevir(metin)
				if atr and not atr:find(kalan, 1, true) then return atr end
				return o[2] .. kalan, false, kalan
			end
		end
	end
	-- En son genel arayüz çevirisi (yarım çeviri yapmasın: İngilizce gövdeyi aynen bırakan sonucu kullanma)
	if G.arayuzCevir then
		local atr = G.arayuzCevir(metin)
		if atr then return atr end
	end
	if G.ipucu2 and (G.modul("ipucu") or G.modul("buyu")) then return G.ipucu2(metin) end
end

local cikti = {} -- yazdığımız Türkçe satırlar (Türkçe harfi olmayanlar da tekrar işlenmesin)
local ciktiSay = 0
local function ciktiEkle(m) if ciktiSay < 5000 and not cikti[m] then cikti[m] = true; ciktiSay = ciktiSay + 1 end end
local BASLIK = { ["Equipped"] = "Kuşanılan", ["Currently Equipped"] = "Şu An Kuşanılan" }
-- Karşılaştırma ipucunun üstündeki "Equipped" sekmesi satır değil ayrı bir yazı olabilir: ipucunun altındaki yazılarda ara
local function ustBaslik(tt, derin)
	local function bak(o)
		if not (o and o.GetRegions) then return end
		for _, r in ipairs({ o:GetRegions() }) do
			if r.GetText then
				local ok, t = pcall(r.GetText, r)
				if ok and type(t) == "string" and BASLIK[t] then r:SetText(BASLIK[t]) end
			end
		end
	end
	bak(tt)
	if tt.GetChildren then
		for _, c in ipairs({ tt:GetChildren() }) do
			bak(c)
			if derin and c.GetChildren then for _, c2 in ipairs({ c:GetChildren() }) do bak(c2) end end
		end
	end
	local p = tt.GetParent and tt:GetParent()
	if p and p ~= UIParent then bak(p) end
end
local calisiyor = false
-- Bilinmeyen ama görünen, adlı ipucu çerçevelerini hedef listesine al ve Show/OnUpdate kancalarını tak
local benimsenen = setmetatable({}, { __mode = "k" })
function G.adopt(tt)
	if benimsenen[tt] or hedef[tt] then return end
	if type(tt) ~= "table" or not tt.GetObjectType or not tt.GetName or not tt.IsShown then return end
	if tt.IsForbidden and tt:IsForbidden() then return end
	if tt:GetObjectType() ~= "GameTooltip" or not tt:GetName() or not tt:IsShown() then return end
	benimsenen[tt] = true
	hedef[tt] = true
	pcall(hooksecurefunc, tt, "Show", function(self) G.ipucuCevir(self) end)
	if tt.HookScript then pcall(tt.HookScript, tt, "OnUpdate", function(self, dt) self._gtrAdp = (self._gtrAdp or 0) + (dt or 0); if self._gtrAdp > 0.25 then self._gtrAdp = 0; G.ipucuCevir(self) end end) end
end
local auraIpucu = {} -- buff/debuff ipucu açık olan ipuçları
function G.auraIpucuIsaretle(tt) auraIpucu[tt] = true end
-- Gizli (secret) değerli aura ipucu: düşman birimin büff/debuff satırları okunamaz; büyü numarasından
-- adı ve açıklamayı kendimiz üretip satırlara yazarız (okuma yok, sadece yazma).
-- Savaşta aura ipuçlarının tüm yazıları ve büyü numarası gizlenir; simge numarası açık kalır.
-- Savaş dışında görülen aura ipuçlarının Türkçe satırları simge numarasıyla saklanır, savaşta oradan yazılır.
local function sahipIkon(sahip)
	if not sahip then return nil end
	-- Dikkat: boş (nil) değerli liste ipairs ile yarıda kesilir; adayları tek tek ekle
	local adaylar = {}
	local function ekle(v) if v ~= nil then adaylar[#adaylar + 1] = v end end
	pcall(function() ekle(sahip.icon); ekle(sahip.Icon); ekle(sahip.IconTexture); ekle(sahip.iconTexture) end)
	local sn = sahip.GetName and sahip:GetName()
	if sn then ekle(_G[sn .. "Icon"]); ekle(_G[sn .. "IconTexture"]) end
	-- Düğmenin belirli bir simge dokusu varsa yalnızca ona bak. Savaşta bu doku "gizli" döner; o zaman
	-- çerçeve/kenarlık gibi bütün bufflarda ortak olan başka bir dokuya düşmek tüm açıklamaları aynı yapıyordu.
	local belirli = false
	for _, ik in ipairs(adaylar) do
		if type(ik) == "table" and ik.GetObjectType and ik:GetObjectType() == "Texture" then belirli = true; break end
	end
	if belirli then
		for _, ik in ipairs(adaylar) do
			if type(ik) == "table" and ik.GetObjectType and ik:GetObjectType() == "Texture" and ik.GetTexture then
				local ok, d = pcall(ik.GetTexture, ik)
				if ok and type(d) == "number" and not G.gizli(d) then return d end
			end
		end
		return nil
	end
	pcall(function() for _, r in ipairs({ sahip:GetRegions() }) do ekle(r) end end)
	-- Simge bir alt çerçevede olabilir (IceHUD vb.): bir seviye alt çerçevelerin bölgelerine de bak
	pcall(function()
		for _, c in ipairs({ sahip:GetChildren() }) do
			for _, r in ipairs({ c:GetRegions() }) do ekle(r) end
		end
	end)
	for _, ik in ipairs(adaylar) do
		if type(ik) == "table" and ik.GetObjectType and ik:GetObjectType() == "Texture" and ik.GetTexture then
			local ok, d = pcall(ik.GetTexture, ik)
			if ok and type(d) == "number" and not G.gizli(d) then return d end
		end
	end
	-- Eklenti düğmeleri (IceHUD): düğmede aura sırası (id) ve türü var; simgeyi aura verisinden al
	local okI, bulunan = pcall(function()
		local idx = sahip.id or sahip.auraIndex or (sahip.GetID and sahip:GetID())
		if type(idx) ~= "number" or idx <= 0 or not (C_UnitAuras and C_UnitAuras.GetAuraDataByIndex) then return end
		local tur = sahip.type or sahip.auraType or sahip.filter
		local filtreler = (tur == "debuff" or tur == "HARMFUL" or tur == "Debuff") and { "HARMFUL" } or (tur == "buff" or tur == "HELPFUL" or tur == "Buff") and { "HELPFUL" } or { "HELPFUL", "HARMFUL" }
		local birim = sahip.unit or sahip.unitToken
		local p = sahip.GetParent and sahip:GetParent()
		for _ = 1, 4 do
			if birim or not p then break end
			birim = p.unit or p.unitToken
			p = p.GetParent and p:GetParent()
		end
		for _, b in ipairs(birim and { birim } or { "target", "player", "focus", "targettarget" }) do
			for _, f in ipairs(filtreler) do
				local ok, a = pcall(C_UnitAuras.GetAuraDataByIndex, b, idx, f)
				if ok and type(a) == "table" and type(a.icon) == "number" and not G.gizli(a.icon) then return a.icon end
			end
		end
	end)
	if okI and type(bulunan) == "number" then return bulunan end
end
G.sahipIkon = sahipIkon
local function auraIkonTablo()
	if type(WoWTurkce_Ayar) ~= "table" then return nil end
	-- Eski önbellekte ortak çerçeve dokusuna yanlış bağlanmış kayıtlar olabilir: bir kez temizle
	if WoWTurkce_Ayar.auraIkonV ~= 2 then WoWTurkce_Ayar.auraIkon = {}; WoWTurkce_Ayar.auraIkonV = 2 end
	WoWTurkce_Ayar.auraIkon = WoWTurkce_Ayar.auraIkon or {}
	return WoWTurkce_Ayar.auraIkon
end
local function auraKaydet(tt, sahip)
	local ad = tt:GetName(); if not ad then return end
	local l1 = _G[ad .. "TextLeft1"]; local t1 = l1 and l1:GetText()
	if type(t1) ~= "string" or G.gizli(t1) or not G.turkceMi(t1) then return end
	local ikon = sahipIkon(sahip)
	local tb = ikon and auraIkonTablo()
	if not tb then return end
	local n = tt:NumLines() or 0
	local l2 = n >= 3 and _G[ad .. "TextLeft2"]; local t2 = l2 and l2:GetText()
	if type(t2) ~= "string" or G.gizli(t2) or not G.turkceMi(t2) then t2 = nil end
	local r1 = _G[ad .. "TextRight1"]; local tr1 = r1 and r1:IsShown() and r1:GetText()
	if type(tr1) ~= "string" or G.gizli(tr1) then tr1 = nil end
	tb[ikon] = { t1, t2, tr1 }
end
G.auraKaydet = auraKaydet
local function gizliAuraIkon(tt, ad)
	local okS, sahip = pcall(tt.GetOwner, tt)
	local ikon = okS and sahipIkon(sahip)
	local tb = ikon and auraIkonTablo()
	local k = tb and tb[ikon]
	if not k then return false end
	local n = tt:NumLines() or 0
	local l1 = _G[ad .. "TextLeft1"]
	if l1 and k[1] then pcall(l1.SetText, l1, k[1]) end
	local l2 = _G[ad .. "TextLeft2"]
	if l2 and k[2] and n >= 3 then pcall(l2.SetText, l2, k[2]) end
	local r1 = _G[ad .. "TextRight1"]
	if r1 and k[3] then pcall(r1.SetText, r1, k[3]) end
	return true
end

local function gizliAuraCevir(tt, ad)
	local kayit = {}
	if gizliAuraIkon(tt, ad) then
		-- Kalan süre satırı gizli; satırı olduğu gibi bırak (oyun saniye saniye güncelliyor)
		G.tani.gizliAura = "GIZLI AURA simgeden çevrildi"
		if G.ipucuSigdir then G.ipucuSigdir(tt) end
		return
	end
	local ok, d = pcall(tt.GetPrimaryTooltipData, tt)
	if not ok or type(d) ~= "table" then d = nil end
	local sid, aid, birim
	if d then
		sid = d.id
		for _, a in ipairs(d.args or {}) do
			if type(a) == "table" then
				if a.field == "spellID" then sid = sid or a.intVal end
				if a.field == "auraInstanceID" then aid = a.intVal end
				if a.field == "unit" or a.field == "unitToken" then birim = a.stringVal end
			end
		end
	end
	local sahip = tt.GetOwner and tt:GetOwner()
	if sahip then
		aid = aid or sahip.auraInstanceID or sahip.auraInstanceId
		sid = sid or sahip.spellID or sahip.spellId
		birim = birim or sahip.unit or sahip.unitToken
		local ebeveyn = sahip.GetParent and sahip:GetParent()
		birim = birim or (ebeveyn and (ebeveyn.unit or ebeveyn.unitToken))
	end
	birim = birim or "target"
	local veri
	if aid and C_UnitAuras and C_UnitAuras.GetAuraDataByAuraInstanceID then
		local ok2, v = pcall(C_UnitAuras.GetAuraDataByAuraInstanceID, birim, aid)
		if ok2 and type(v) == "table" then veri = v; sid = sid or v.spellId end
	end
	kayit[#kayit + 1] = ("sid=%s aid=%s birim=%s veri=%s"):format(tostring(G.gizli(sid) and "<gizli>" or sid), tostring(G.gizli(aid) and "<gizli>" or aid), tostring(birim), tostring(veri ~= nil))
	if sid == nil then G.tani.gizliAura = "GIZLI AURA: " .. table.concat(kayit, " | ") .. " | sahip=" .. tostring(sahip and sahip.GetName and sahip:GetName()); return end
	-- Gizli sayı Blizzard işlevlerine verilebilir; sonuç düz yazı döner
	local oku, en = pcall(function() return C_Spell.GetSpellName(sid) end)
	if oku and type(en) == "string" and not G.gizli(en) and en ~= "" then
		local tr = (G.buyuAdiCevir and G.buyuAdiCevir(en)) or (G.Arayuz and type(G.Arayuz[en]) == "string" and G.Arayuz[en]) or nil
		local l1 = _G[ad .. "TextLeft1"]
		if tr and l1 then pcall(l1.SetText, l1, G.adStil("stilBuyu", tr, en)) end
		kayit[#kayit + 1] = "ad=" .. en
	end
	local okd, desc = pcall(function() return C_Spell.GetSpellDescription(sid) end)
	if okd and type(desc) == "string" and not G.gizli(desc) and desc ~= "" then
		local l2 = _G[ad .. "TextLeft2"]
		local sat = tt.NumLines and tt:NumLines() or 0
		if l2 and sat >= 3 then
			local bas, govde, son = renkAyir(desc)
			local tr = satirCevir(govde, true)
			if tr then pcall(l2.SetText, l2, bas .. tr .. son) end
		end
		kayit[#kayit + 1] = "aciklama=" .. #desc
	end
	-- Sağ üst tür ("Magic")
	local tur = veri and veri.dispelName
	if tur ~= nil then
		local r1 = _G[ad .. "TextRight1"]
		local okt, trt = pcall(function() return G.buyuAltCevir and G.buyuAltCevir(tur) end)
		if r1 and okt and trt then pcall(r1.SetText, r1, trt) end
	end
	-- Kalan süre satırı
	local bitis = veri and veri.expirationTime
	if bitis then
		local okk, kalan = pcall(function() return bitis - GetTime() end)
		local son = _G[ad .. "TextLeft" .. (tt:NumLines() or 0)]
		if okk and type(kalan) == "number" and not G.gizli(kalan) and kalan > 0 and son then
			local y = kalan >= 3600 and ("%d saat kaldı"):format(math.ceil(kalan / 3600)) or kalan >= 60 and ("%d dakika kaldı"):format(math.ceil(kalan / 60)) or ("%d saniye kaldı"):format(math.ceil(kalan))
			pcall(son.SetText, son, y)
		end
	end
	G.tani.gizliAura = "GIZLI AURA islendi: " .. table.concat(kayit, " | ")
	if G.ipucuSigdir then G.ipucuSigdir(tt) end
end
local function ipucuCevir(tt)
	-- Başka eklentilerin/özel arayüzün kendi ipucu çerçeveleri (birim çerçevesi aura ipuçları vb.): görününce benimse
	if tt and not hedef[tt] and not calisiyor and G.adopt then pcall(G.adopt, tt) end
	if calisiyor or not tt or not hedef[tt] or not G.ayar("acik") then
		if G.tani then G.tani.ipucuIlk = ("erken: calisiyor=%s hedef=%s acik=%s"):format(tostring(calisiyor), tostring(tt and hedef[tt]), tostring(G.ayar("acik"))) end
		return
	end
	if not (G.ayar("ipucu") or G.ayar("buyu") or G.ayar("buyuadi")) then return end
	calisiyor = true
	local ad = tt:GetName()
	do
		local l1 = ad and _G[ad .. "TextLeft1"]
		local t1g = l1 and l1:GetText()
		if t1g ~= nil and G.gizli(t1g) then
			pcall(gizliAuraCevir, tt, ad)
			calisiyor = false
			return
		end
	end
	-- Yazı tipi atanmamış satırlar SetText'te "Font not set" hatası verip çeviriyi yarıda kesiyordu (buff ipuçları)
	if ad then
		for li = 1, math.min(tt:NumLines() or 0, 40) do
			for _, taraf in ipairs({ "TextLeft", "TextRight" }) do
				local lfs = _G[ad .. taraf .. li]
				if lfs and lfs.GetFont and lfs.SetFontObject then
					local okf, df = pcall(lfs.GetFont, lfs)
					if okf and not df then pcall(lfs.SetFontObject, lfs, taraf == "TextLeft" and (GameTooltipText or GameFontNormal) or (GameTooltipText or GameFontNormal)) end
				end
			end
		end
	end
	local buyuAdi = tt.GetSpell and select(1, tt:GetSpell())
	local auraMi = auraIpucu[tt]
	if not auraMi and not buyuAdi and tt.GetOwner then
		-- Forever: buff simgeleri ipucunu farklı yoldan açıyor; sahibin adından anla (BuffButton1, AuraButton2, TemporaryEnchantFrame...)
		local okS, sahip = pcall(tt.GetOwner, tt)
		local sad = okS and sahip and sahip.GetName and sahip:GetName()
		local par = okS and sahip and sahip.GetParent and sahip:GetParent()
		local pad = par and par.GetName and par:GetName()
		if (sad and (sad:find("Buff") or sad:find("Aura") or sad:find("TempEnchant"))) or (pad and (pad:find("Buff") or pad:find("Aura"))) then auraMi = true end
	end
	if not buyuAdi and not auraMi and G.BuyuAdi then
		-- Birim çerçevesi buffları (Forever/özel arayüz): sahibin adından anlaşılmıyorsa içerikten anla (ilk satır bilinen büyü + "remaining"/okul satırı)
		local f1 = _G[tt:GetName() and (tt:GetName() .. "TextLeft1") or "x"]
		local t1 = f1 and f1:GetText()
		local tmz = t1 and (G.renksiz and G.renksiz(t1) or t1)
		if tmz and G.BuyuAdi[tmz] and not (tt.GetItem and select(2, tt:GetItem())) and not (tt.GetUnit and select(2, tt:GetUnit())) then auraMi = true end
	end
	if not buyuAdi and auraMi then
		-- Buff/debuff ipucu: 1. satır aura adıdır, büyü gibi işlenir
		local t1 = _G[ad .. "TextLeft1"] and _G[ad .. "TextLeft1"]:GetText()
		buyuAdi = t1 and (t1:match("%((.-)%)|r$") or t1)
	end
	local esyaMi = (tt.GetItem and select(2, tt:GetItem()) ~= nil) or (G.esyaIpucuMu and G.esyaIpucuMu(tt)) or false
	local degisti = false
	local serbest = not esyaMi and not buyuAdi and not auraMi
	if serbest and tt.GetUnit then local okU, bu = pcall(function() return select(2, tt:GetUnit()) end); if okU and bu then serbest = false end end
	if esyaMi then pcall(ustBaslik, tt, true) end
	-- Karşılaştırma ipucunda sekme başka bir çerçevede olabilir: görünen tüm çerçevelerde "Equipped" yazısını ara
	-- Karşılaştırma ipucundaki "Equipped" başlığı: yalnızca bu ipucunun kendi bölgelerine bak (tüm çerçeveleri dolaşmak takılma yapıyordu)
	if esyaMi and ad and ad:find("Shopping") then
		pcall(function()
			local function bak(f)
				if not (f and f.GetRegions) then return end
				for _, r in ipairs({ f:GetRegions() }) do
					if r.GetText then
						local t = r:GetText()
						if type(t) == "string" and not G.gizli(t) and BASLIK[t] then r:SetText(BASLIK[t]) end
					end
				end
			end
			bak(tt)
			if tt.GetChildren then for _, c in ipairs({ tt:GetChildren() }) do bak(c) end end
		end)
	end
	-- Yetenek ağacı ipucu (2. satır "Rütbe 0/5"): ad "Türkçe (English)" olarak yazılsın
	if not buyuAdi and not esyaMi and G.modul("buyuadi") and ad then
		local l2 = _G[ad .. "TextLeft2"]
		local m2 = l2 and l2.GetText and l2:GetText()
		if type(m2) == "string" and not G.gizli(m2) and (m2:match("^Rütbe %d+/%d+$") or m2:match("^Rank %d+/%d+$")) then
			local fs = _G[ad .. "TextLeft1"]
			local t = fs and fs:GetText()
			if type(t) == "string" and not G.gizli(t) and not t:find("|cff888888(", 1, true) and not t:find("|cffaaaaaa(", 1, true) then
				local on, ic = t:match("^(|c%x%x%x%x%x%x%x%x)(.-)|r$")
				local saf = ic or t
				if not saf:find("%(") then
					local y
					if G.turkceMi(saf) then
						y = G.adStil("stilBuyu", saf, saf)
						if y == saf and tt.GetPrimaryTooltipData then
							local okd, dd = pcall(tt.GetPrimaryTooltipData, tt)
							local sid = okd and type(dd) == "table" and (dd.id or dd.spellID) or nil
							local en = sid and C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(sid)
							if type(en) == "string" and en ~= "" and en ~= saf and not G.turkceMi(en) then y = G.adStil("stilBuyu", saf, en) end
						end
					else
						local tr = G.buyuAdiCevir and G.buyuAdiCevir(saf)
						if tr then y = G.adStil("stilBuyu", tr, saf) else G.kaydetDiger("buyuadi", saf) end
					end
					if y and y ~= saf then fs:SetText((on and (on .. y .. "|r")) or y); degisti = true end
				end
			end
		end
	end
	-- Büyü adı (1. satır) ve rütbe (sağ üst)
	if buyuAdi and G.modul("buyuadi") then
		local fs = _G[ad .. "TextLeft1"]
		local t = fs and fs:GetText()
		if t and not t:find("|c") then
			-- Büyü adı sözlüğünde yoksa (NPC büyüleri: "Disease Cloud") genel sözlükteki birebir karşılığı kullan
			local tr = G.buyuAdiCevir(t) or (G.Arayuz and type(G.Arayuz[t]) == "string" and G.Arayuz[t]) or nil
			if tr then fs:SetText(G.adStil("stilBuyu", tr, t)); degisti = true
			elseif not G.turkceMi(t) then G.kaydetDiger("buyuadi", t)
			elseif not t:find("|cff888888(", 1, true) then
				-- Ad başka bir yoldan zaten Türkçeleşmiş: İngilizcesini oyundan alıp yanına yaz
				local sid = select(2, tt:GetSpell())
				if not sid and tt.GetPrimaryTooltipData then
					local ok, d = pcall(tt.GetPrimaryTooltipData, tt)
					sid = ok and type(d) == "table" and d.id or nil
				end
				local en = sid and ((C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(sid)) or (GetSpellInfo and GetSpellInfo(sid)))
				if type(en) == "string" and en ~= "" and en ~= t and not G.turkceMi(en) then fs:SetText(G.adStil("stilBuyu", t, en)); degisti = true end
				if not en and G.adStil then
					-- Büff/debuff ipucunda büyü numarası yok: ad sözlüğünden tersine bul ("Güç Kutsaması" -> Blessing of Might)
					local y = G.adStil("stilBuyu", t, t)
					if y and y ~= t then fs:SetText(y); degisti = true end
				end
			end
		end
		local sag = _G[ad .. "TextRight1"]
		local st = sag and sag:IsShown() and sag:GetText()
		local str = st and G.buyuAltCevir and G.buyuAltCevir(st)
		if str then sag:SetText(str); degisti = true end
	end
	-- Etkileşimli nesne adı (1. satır): "Olta Şamandırası (Fishing Bobber)"
	if not esyaMi and not buyuAdi and not auraMi and G.modul("arayuz") and G.Nesne then
		local okU, bu = pcall(function() return tt.GetUnit and select(2, tt:GetUnit()) end)
		if not (okU and bu) then
			local fs = _G[ad .. "TextLeft1"]
			local t = fs and fs:GetText()
			if type(t) == "string" and not G.gizli(t) and not t:find("|c") then
				local tr = G.Nesne[t]
				if tr and tr ~= t then fs:SetText(tr); degisti = true end
			end
		end
	end
	-- Eşya adı (1. satır): "Türkçe (English)"
	local adFs
	if esyaMi and G.modul("ipucu") then
		local fs = _G[ad .. "TextLeft1"]
		local t = fs and fs:GetText()
		-- Karşılaştırma ipucunda 1. satır başlıktır ("Currently Equipped"); ad 2. satırdadır
		local baslikTr = t and G.cevir(G.Esya, t)
		if not baslikTr and t and t:find("^|c") then
			local r = G.cevir(G.Esya, G.renksiz(t))
			if r then baslikTr = t:sub(1, 10) .. r .. "|r" end
		end
		if baslikTr then fs:SetText(baslikTr); ciktiEkle(baslikTr); degisti = true; fs = _G[ad .. "TextLeft2"]; t = fs and fs:GetText() end
		adFs = fs
		if t and not G.turkceMi(t) and not cikti[t] and not t:find("|cff888888%(") then
			local _, ic = t:match("^(|c%x%x%x%x%x%x%x%x)(.-)|r$")
			local saf = ic or t
			local tr = G.EsyaAdi[saf] or G.esyaSonekli(saf)
			if tr then local y = (ic and t:sub(1, 10) or "") .. G.adStil("stilEsya", tr, saf); fs:SetText(y); ciktiEkle(y); degisti = true
			else G.kaydetDiger("esyaadi", saf) end
		end
	end
	for i = 2, tt:NumLines() do
		for _, taraf in ipairs({ "TextLeft", "TextRight" }) do
			local fs = _G[ad .. taraf .. i]
			local metin = fs and fs:IsShown() and fs:GetText()
			if G.gizli(metin) then metin = nil end
			local onekli = metin and (metin:find("Kuşanınca: ", 1, true) or metin:find("Vuruşta şans: ", 1, true)) and not G.turkceMi((metin:gsub("Kuşanınca: ", ""):gsub("Vuruşta şans: ", "")))
			if metin and not onekli and metin:find("Kalan bekleme süresi: ", 1, true) and metin:find("%d+ %u?%l+s?") and metin:find("[%a][%a]+") then
				onekli = metin:find("%d+ [MSHD]%l*") ~= nil or metin:find("%d+ [mshd]%l+") ~= nil
			end
			-- Çok satırlı yazıda bir satır zaten Türkçe olabilir ("...armor types:\nKumaş"): satır satır çevir ve kaydet
			if metin and not onekli and not cikti[metin] and not metin:find("|T") and metin:find("\n") and G.turkceMi(metin) then
				local parcalar, degisen = {}, false
				for satir in (metin .. "\n"):gmatch("(.-)\n") do
					if satir:find("%a%a") and not G.turkceMi(satir) then
						local bas, govde, son = renkAyir(satir)
						local tr = satirCevir(govde, buyuAdi ~= nil)
						if tr then satir = bas .. tr .. son; degisen = true
						elseif G.ayar("kayit") and #govde > 3 then
							local sab = G.sablon(govde)
							if buyuAdi and G.ayar("buyu") then G.kaydetDiger("buyu", sab, buyuAdi)
							elseif esyaMi and G.ayar("ipucu") then G.kaydetDiger("ipucu", sab)
							elseif G.ayar("ipucu") then G.kaydetDiger("ipucu", sab) end
						end
					end
					parcalar[#parcalar + 1] = satir
				end
				if degisen then local y = table.concat(parcalar, "\n"); fs:SetText(y); ciktiEkle(y); degisti = true end
				metin = nil
			end
			if metin and G.YerAdi and (G.YerAdi[metin] or G.YerAdi[(G.renksiz(metin))]) then metin = nil end -- yer adları İngilizce kalır
			-- "Sell Price: 4 [gümüş] 4 [bakır]" (para simgeli satır): önek her zaman Türkçe
			if metin and metin:find("Sell Price:", 1, true) then
				local y = metin:gsub("Sell Price:", "Satış Fiyatı:", 1)
				fs:SetText(y); ciktiEkle(y); degisti = true; metin = nil
			end
			if metin and metin ~= "" and not metin:find("|T") and (onekli or not G.turkceMi(metin) or G.ingilizceBaskin(metin)) and not cikti[metin] then
				local bas, govde, son = renkAyir(metin)
				local tr, tam, kalan = satirCevir(govde, buyuAdi ~= nil)
				-- "Sell Price: 2 [gümüş] 26 [bakır]": önek her zaman Türkçe
				if not tr and govde:find("^Sell Price:") then tr = "Satış Fiyatı:" .. govde:sub(12) end
				-- İç renk kodlu satır ("|cff00ff00+3.5|r damage per second"): renkleri çıkar, çevir, sayıların rengini geri koy
				if not tr and metin:find("|c", 1, true) and not metin:find("|T", 1, true) then
					local renkler = {}
					local duz = metin:gsub("|c(%x%x%x%x%x%x%x%x)([^|]*)|r", function(c, ic) renkler[#renkler + 1] = { c, ic }; return ic end)
					duz = duz:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", "")
					if duz ~= metin and duz:find("%a%a") then
						local t2 = satirCevir(duz, buyuAdi ~= nil) or (serbest and G.cevir(G.Arayuz, duz))
						if t2 and not G.ingilizceBaskin(t2) then
							for _, r in ipairs(renkler) do
								if r[2]:find("%d") then
									local a, b = t2:find(r[2], 1, true)
									if a then t2 = t2:sub(1, a - 1) .. "|c" .. r[1] .. r[2] .. "|r" .. t2:sub(b + 1) end
								end
							end
							bas, son, tr = "", "", t2
						end
					end
				end
				-- Eklenti simge ipuçları (Questie, AtlasLoot, HealBot...): arayüz sözlüğü ve iç renk kodlu satırlar
				if not tr and serbest then
					tr = G.cevir(G.Arayuz, govde)
					if not tr and metin:find("|c", 1, true) then
						local duz = G.renksiz(metin):gsub("^%s+", ""):gsub("%s+$", "")
						local t2 = (duz ~= "" and (G.cevir(G.Esya, duz) or G.cevir(G.Arayuz, duz)))
						if t2 then bas, son, tr = "", "", t2
						else
							-- Parça parça: "Left Click: |cffffd200Open AtlasLoot|r" -> "Sol Tık: |cffffd200AtlasLoot'u aç|r"
							local degisen = false
							local parcalar, ilk = {}, true
							for parca in (metin .. "|"):gmatch("(.-)|") do
								local kod = ""
								if not ilk then kod = parca:match("^c%x%x%x%x%x%x%x%x") or parca:match("^[rTtnA]") or "" end
								ilk = false
								local ic = parca:sub(#kod + 1)
								local sade = ic:gsub("^%s+", ""):gsub("%s+$", "")
								if kod ~= "T" and kod ~= "t" and kod ~= "A" and sade:find("%a%a") then
									local pt = G.cevir(G.Esya, sade) or G.cevir(G.Arayuz, sade)
									if not pt and sade:find(":$") then local k = G.cevir(G.Arayuz, (sade:gsub(":$", ""))); if k then pt = k .. ":" end end
									if pt and pt ~= sade then
										local b1 = ic:match("^%s*") or ""
										local b2 = ic:match("%s*$") or ""
										ic = b1 .. pt .. b2; degisen = true
									end
								end
								parcalar[#parcalar + 1] = kod .. ic
							end
							local y = table.concat(parcalar, "|")
							if degisen then bas, son, tr = "", "", y end
						end
					end
				end
				-- Yarım çeviri (hâlâ İngilizce ağırlıklı, araya Türkçe parça girmiş): ekrana koyma, özgün satırı kaydet
				if tr and G.ingilizceBaskin(tr) then tr = nil; tam = nil; kalan = nil end
				if tr then
					if G.birimDuzelt then tr = G.birimDuzelt(tr) end
					fs:SetText(bas .. tr .. son); ciktiEkle(bas .. tr .. son)
					degisti = true
				end
				-- Kayıt: çevrilemeyen anlamlı satırlar
				if (not tr or tam == false) and G.ayar("kayit") and fs ~= adFs then
					local kayitMetni = kalan or govde
					if #kayitMetni > 3 and not kayitMetni:find('^"') then
						local sab = G.sablon(kayitMetni)
						if buyuAdi and G.ayar("buyu") then
							G.kaydetDiger("buyu", sab, buyuAdi)
						elseif esyaMi and G.ayar("ipucu") then
							G.kaydetDiger("ipucu", sab)
						elseif G.ayar("ipucu") and sab:find("%a%a%a") and not G.turkceMi(sab) then
							-- Ne büyü ne eşya diye ayrılamayan her İngilizce ipucu satırı da kaydedilsin
							G.kaydetDiger("ipucu", sab)
						end
					end
				end
			end
		end
	end
	-- Para çerçevesi öneki ("Sell Price:" -> "Satış Fiyatı:")
	for mi = 1, 4 do
		local pf = _G[ad .. "MoneyFrame" .. mi .. "PrefixText"]
		local pt = pf and pf.GetText and pf:GetText()
		if type(pt) == "string" and not G.gizli(pt) and pt:find("Sell Price", 1, true) then pf:SetText((pt:gsub("Sell Price", "Satış Fiyatı"))) end
	end
	if degisti then if G.ipucuSigdir then G.ipucuSigdir(tt) else tt:Show() end end
	for i = 1, tt:NumLines() do
		for _, taraf in ipairs({ "TextLeft", "TextRight" }) do
			local fs = _G[ad .. taraf .. i]
			if fs then fs._gtrSon = fs:GetText() end
		end
	end
	calisiyor = false
end
local gorevSatiriCalisiyor = false
local ipucuCevirOlc = G.olcSar("ipucu çevirisi", ipucuCevir)
local onbellek, onbellekSay = {}, 0
local function satirlariAl(tt, ad)
	local n = tt:NumLines() or 0
	local l = {}
	for i = 1, n do
		local a, b = _G[ad .. "TextLeft" .. i], _G[ad .. "TextRight" .. i]
		l[#l + 1] = a and a:GetText() or false
		l[#l + 1] = b and b:GetText() or false
	end
	return l
end
local function satirlariUygula(tt, ad, l)
	local n = tt:NumLines() or 0
	if #l ~= n * 2 then return false end
	calisiyor = true
	for i = 1, n do
		local a, b = _G[ad .. "TextLeft" .. i], _G[ad .. "TextRight" .. i]
		local ta, tb = l[i * 2 - 1], l[i * 2]
		if a and ta and a:GetText() ~= ta then a:SetText(ta) end
		if b and tb and b:GetText() ~= tb then b:SetText(tb) end
		if a then a._gtrSon = a:GetText() end
		if b then b._gtrSon = b:GetText() end
	end
	calisiyor = false
	return true
end
local function sonKaydet(tt)
	local ad = tt and tt.GetName and tt:GetName(); if not ad then return end
	for i = 1, tt:NumLines() or 0 do
		local a, b = _G[ad .. "TextLeft" .. i], _G[ad .. "TextRight" .. i]
		if a then a._gtrSon = a:GetText() end
		if b then b._gtrSon = b:GetText() end
	end
end
local ipucuCevirAsil
-- Çevrilmiş satırlarda İngilizce kalan adları (büyü, meslek, eşya) ayara göre Türkçeleştir
local function adlariUygula(tt)
	if not G.metinAdlari then return end
	local ad = tt:GetName(); if not ad then return end
	for i = 1, tt:NumLines() or 0 do
		local fs = _G[ad .. "TextLeft" .. i]
		local t = fs and fs:IsShown() and fs:GetText()
		if type(t) == "string" and not G.gizli(t) then
			local y = G.metinAdlari(t)
			if y ~= t then fs:SetText(y) end
		end
	end
end
G.ipucuCevir = function(tt)
	ipucuCevirAsil(tt)
	-- Görev satırları (Questie "[16] Görev adı (Tamamlandı)"): eşya çevirisi kapalı olsa da görev ayarına göre her yolda çevir
	if tt and not G.ipucuKapali and G.ayar("acik") and G.ipucuGorevAciklama and hedef[tt] and not gorevSatiriCalisiyor then
		gorevSatiriCalisiyor = true
		G.ipucuGorevAciklama(tt)
		gorevSatiriCalisiyor = false
	end
	-- Hangi yoldan çıkılırsa çıkılsın son hâli kaydet: yoksa her karede "değişti" sanılıp baştan çevriliyordu
	if tt and not G.ipucuKapali and not G.esyaAtla(tt) then pcall(sonKaydet, tt) end
end
ipucuCevirAsil = function(tt)
	if G.ipucuKapali then return end
	if G.esyaAtla(tt) then return end
	-- İngilizce modda (Alt basılı ya da /wtr en) önbellekten Türkçe basma: oyunla sürekli yer değiştirip titriyordu
	if not G.ayar("acik") then return end
	if tt and tt.GetName and tt:GetName() == "WTR_DokTip" then return end
	-- Aynı içerik zaten çevrildiyse tekrar okuma
	local ad = tt and tt.GetName and tt:GetName()
	local imza = ad and G.ipucuImza and G.ipucuImza(tt, ad)
	G.sayIC = (G.sayIC or 0) + 1
	if imza and tt._gtrImza2 == imza then return end
	-- Bu İngilizce içerik daha önce çevrildiyse sonucu doğrudan uygula (eşya ipucu yenilendikçe baştan çevirme)
	if imza and onbellek[imza] and not auraIpucu[tt] then
		G.sayOnb = (G.sayOnb or 0) + 1
		if satirlariUygula(tt, ad, onbellek[imza]) then
			tt._gtrImza2 = G.ipucuImza(tt, ad)
			if G.ipucuSigdir then pcall(G.ipucuSigdir, tt) end
			return
		end
	end
	local ok, e = true, nil
	G.sayTam = (G.sayTam or 0) + 1
	ipucuCevirOlc(tt)
	if ad and not G.esyaAtla(tt) then pcall(adlariUygula, tt) end
	-- Eşya ipucunda kendi çeviremediğimiz satırlar (ör. "The Dalaran Digest, Vol. 23"): genel çeviriyle aynı anda tamamla.
	-- Sonuç önbelleğe girer; sonradan başka bir tarama yazmadığı için titreme olmaz.
	if ad and G.genelCevir and G.esyaIpucuMu and G.esyaIpucuMu(tt) then
		pcall(function()
			for i = 1, tt:NumLines() or 0 do
				local fs = _G[ad .. "TextLeft" .. i]
				local t = fs and fs:IsShown() and fs:GetText()
				if type(t) == "string" and not G.gizli(t) and #t < 700 and t:find("%a%a%a") and not cikti[t] and not G.turkceMi(t) then
					local tr = G.genelCevir(t)
					if tr then fs:SetText(tr); ciktiEkle(tr) end
				end
			end
		end)
	end
	if ad and G.ipucuImza then tt._gtrImza2 = G.ipucuImza(tt, ad) end
	if imza and ad and not auraIpucu[tt] and tt._gtrImza2 ~= imza then
		if onbellekSay > 400 then onbellek, onbellekSay = {}, 0 end
		if not onbellek[imza] then onbellekSay = onbellekSay + 1 end
		onbellek[imza] = satirlariAl(tt, ad)
	end

	local ta = G.tani
	if not ok then calisiyor = false; if ta then ta.ipucuHata = tostring(e) end end
	-- Aura ipucunun Türkçe hâlini simge numarasıyla sakla (savaşta yazılar gizlenince kullanılır)
	if ok and tt and tt.GetOwner then
		pcall(function()
			local sahip = tt:GetOwner()
			if not sahip then return end
			local sn = sahip.GetName and sahip:GetName() or ""
			if auraIpucu[tt] or sahip.auraType or sahip.UpdateAuraType or sahip.auraInstanceID or sn:find("Buff") or sn:find("Debuff") or sn:find("Aura") then
				auraKaydet(tt, sahip)
			end
		end)
	end
	if ta then ta.ipucuCagri = (ta.ipucuCagri or 0) + 1 end
	-- Tanı: büyü/aura ipucuysa (ya da yazısı gizliyse) anlık durumu sakla; "/wowturkce ipucu" hemen gösterir
	if ta and tt and tt.GetName and tt:GetName() then
		local okk = pcall(function()
			local l1 = _G[tt:GetName() .. "TextLeft1"]
			local t1 = l1 and l1:GetText()
			local gz = G.gizli(t1)
			if gz or (type(t1) == "string" and G.BuyuAdi and G.BuyuAdi[t1]) or auraIpucu[tt] then
				local sh = tt.GetOwner and tt:GetOwner()
				local dd = tt.GetPrimaryTooltipData and tt:GetPrimaryTooltipData()
				ta.auraSon = ("sahip=%s | gizli=%s | satir1=%s | satir=%d | veriTuru=%s | auraBayrak=%s | hata=%s"):format(
					tostring(sh and sh.GetName and sh:GetName() or "?"), tostring(gz), gz and "<gizli>" or tostring(t1), tt:NumLines() or 0,
					tostring(type(dd) == "table" and dd.type or "?"), tostring(auraIpucu[tt]), tostring(ok and "yok" or e))
			end
		end)
	end
end

G.basla(function()
	for _, ad in ipairs(HEDEFLER) do
		local tt = _G[ad]
		if tt then hedef[tt] = true end
	end
	-- Gömülü eşya ipuçları (dünya görevi ödül eşyası vb.): GameTooltip.ItemTooltip.Tooltip
	for _, kok in ipairs({ "GameTooltip", "ItemRefTooltip", "WorldMapTooltip", "EmbeddedItemTooltip" }) do
		local r = _G[kok]
		local it = r and r.ItemTooltip
		local t2 = it and (it.Tooltip or (it.GetObjectType and it.GetObjectType(it) == "GameTooltip" and it))
		if t2 and t2.GetName and t2:GetName() then hedef[t2] = true end
	end
	if _G.EmbeddedItemTooltip and _G.EmbeddedItemTooltip.GetName and _G.EmbeddedItemTooltipTooltip then hedef[_G.EmbeddedItemTooltipTooltip] = true end
	local kuruldu = false
	if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
		local turler = { Enum.TooltipDataType.Item, Enum.TooltipDataType.Spell }
		if Enum.TooltipDataType.Macro then turler[#turler + 1] = Enum.TooltipDataType.Macro end
		for _, tur in ipairs(turler) do
			if tur and not TooltipDataProcessor.AllTypes then
				TooltipDataProcessor.AddTooltipPostCall(tur, function(tt) G.ipucuCevir(tt) end)
			end
			if tur then kuruldu = true end
		end
		-- Tüm ipucu türleri: oyun ipucunu her yenilediğinde (karşılaştırma satırları dahil) aynı anda Türkçeye çevir
		if TooltipDataProcessor.AllTypes then
			pcall(TooltipDataProcessor.AddTooltipPostCall, TooltipDataProcessor.AllTypes, function(tt) if tt and tt.GetName then pcall(G.adopt, tt); G.ipucuCevir(tt) end end)
		end
		-- Birim çerçevesindeki buff/debuff ipuçları (hedef/oyuncu çerçevesi): veri türü UnitAura; büyü gibi çevrilir
		local auraTur = Enum.TooltipDataType.UnitAura
		if auraTur then
			TooltipDataProcessor.AddTooltipPostCall(auraTur, function(tt) auraIpucu[tt] = true; G.ipucuCevir(tt) end)
		end
	end
	if not kuruldu then
		for tt in pairs(hedef) do
			if tt.HasScript and tt:HasScript("OnTooltipSetItem") then tt:HookScript("OnTooltipSetItem", G.ipucuCevir) end
			if tt.HasScript and tt:HasScript("OnTooltipSetSpell") then tt:HookScript("OnTooltipSetSpell", G.ipucuCevir) end
		end
	end
	-- Sağ üstteki buff/debuff simgeleri: ipucu her saniye yeniden yazılır
	for _, yontem in ipairs({ "SetUnitAura", "SetUnitBuff", "SetUnitDebuff", "SetPlayerBuff", "SetUnitAuraByAuraInstanceID", "SetUnitBuffByAuraInstanceID", "SetUnitDebuffByAuraInstanceID" }) do
		if GameTooltip[yontem] then
			hooksecurefunc(GameTooltip, yontem, function(tt) auraIpucu[tt] = true; G.ipucuCevir(tt) end)
		end
	end
	GameTooltip:HookScript("OnTooltipCleared", function(tt) auraIpucu[tt] = nil end)
	-- İpucunu dolduran tüm yöntemlerden hemen sonra çevir: çanta ve eylem düğmeleri ipucunu her an
	-- (bekleme süresi sayarken her saniye) yeniden yazıyor; çeviri aynı karede gelince titreme olmaz.
	local YAZICILAR = { "SetBagItem", "SetInventoryItem", "SetHyperlink", "SetMerchantItem", "SetBuybackItem", "SetLootItem",
		"SetLootRollItem", "SetQuestItem", "SetQuestLogItem", "SetTradeSkillItem", "SetCraftItem", "SetCraftSpell", "SetAuctionItem",
		"SetAuctionSellItem", "SetAction", "SetSpell", "SetSpellBookItem", "SetSpellByID", "SetItemByID", "SetInboxItem",
		"SetSendMailItem", "SetTradePlayerItem", "SetTradeTargetItem", "SetPetAction", "SetShapeshift", "SetTrainerService",
		"SetQuestLogRewardSpell", "SetQuestRewardSpell", "SetBagItemChild", "SetInventoryItemByID", "RefreshData" }
	for tt in pairs(hedef) do
		for _, y in ipairs(YAZICILAR) do
			if tt[y] then hooksecurefunc(tt, y, function(self) G.ipucuCevir(self) end) end
		end
	end
	-- Karşılaştırma ipucu: "If you replace this item..." ve "+16 Armor" satırları oyun tarafından
	-- eşya olayından SONRA ekleniyor ve ipucu sürekli yenileniyor. Bir kare sonra çevirmek titreme
	-- yapıyordu; bu yüzden aynı karede (Show ve OnUpdate içinde, çizimden önce) çeviriyoruz.
	-- OnUpdate'te sadece bir satır son çevirimizden sonra değiştiyse çalışır (ucuz kontrol).
	-- Her karede çalışır: tablo/kapanış oluşturmaz (çöp üretmek bellek temizliğini tetikleyip oyunu kasıyordu)
	local fsL, fsR = {}, {}
	local function satirFS(tt, ad, i)
		local L, R = fsL[tt], fsR[tt]
		if not L then L, R = {}, {}; fsL[tt], fsR[tt] = L, R end
		local a = L[i]
		if a == nil then a = _G[ad .. "TextLeft" .. i] or false; L[i] = a; R[i] = _G[ad .. "TextRight" .. i] or false end
		return a, R[i]
	end
	local gizli = G.gizli
	local function degistiMi(tt)
		local ad = tt:GetName(); if not ad then return false end
		for i = 1, tt:NumLines() do
			local a, b = satirFS(tt, ad, i)
			if a and a:IsShown() then
				local t, s = a:GetText(), a._gtrSon
				if gizli(t) or gizli(s) then return false end
				if t ~= s then return true end
			end
			if b and b:IsShown() then
				local t, s = b:GetText(), b._gtrSon
				if gizli(t) or gizli(s) then return false end
				if t ~= s then return true end
			end
		end
		return false
	end
	-- Biri (başka kanca/eklenti) her karede satırı değiştiriyorsa sonsuz çeviri döngüsüne girme: kısa süre bekle
	local function kontrol(tt)
		local simdi = GetTime()
		if (tt._gtrBekle or 0) > simdi then return end
		local ok, d = pcall(degistiMi, tt)
		if ok and d then
			tt._gtrArd = ((tt._gtrSonDeg or 0) > simdi - 0.05) and ((tt._gtrArd or 0) + 1) or 1
			tt._gtrSonDeg = simdi
			if tt._gtrArd > 4 then tt._gtrArd = 0; tt._gtrBekle = simdi + 0.3; pcall(sonKaydet, tt); return end
			G.ipucuCevir(tt)
		end
	end
	do
		local mt = getmetatable(GameTooltip)
		local idx = mt and mt.__index
		if type(idx) == "table" and idx.Show then
			hooksecurefunc(idx, "Show", function(self) if not G._sigdirde and not hedef[self] then pcall(G.adopt, self); if hedef[self] then G.ipucuCevir(self) end end end)
		end
	end
	local alisverisTT = {}
	for _, n in ipairs({ "ShoppingTooltip1", "ShoppingTooltip2", "ItemRefShoppingTooltip1", "ItemRefShoppingTooltip2" }) do if _G[n] then alisverisTT[#alisverisTT + 1] = _G[n] end end
	for tt in pairs(hedef) do
		hooksecurefunc(tt, "Show", function(self) if not G._sigdirde then G.ipucuCevir(self) end end)
		if tt.HookScript then tt:HookScript("OnUpdate", function(self)
			if G.ipucuKapali or not G.ayar("acik") or G.esyaAtla(self) then return end
			-- Her karede, çizimden önce: oyun eşya ipucunu saniyede 5 kez baştan yazıyor; geç kalırsak İngilizce bir kare görünür (titreme)
			kontrol(self)
			-- Karşılaştırma ipuçları ana ipucunun yenilenmesiyle aynı karede yeniden yazılır: hemen düzelt
			if self == GameTooltip then
				for i = 1, #alisverisTT do
					local st = alisverisTT[i]
					if st:IsShown() then kontrol(st) end
				end
			end
		end) end
	end
	-- Yetenek ağacı ve bazı özel ipuçları yukarıdaki olayları tetiklemeyebilir
	if GameTooltip.SetTalent then hooksecurefunc(GameTooltip, "SetTalent", function(tt) G.ipucuCevir(tt) end) end
end)

-- Karşılaştırma ipucunun üstündeki "Equipped" sekmesi: ipucu açıkken görünen tüm yazılarda ara (hangi çerçevede olduğu bilinmiyor)
do
	local function ipucuAcik()
		for _, ad in ipairs({ "GameTooltip", "ShoppingTooltip1", "ShoppingTooltip2", "ItemRefShoppingTooltip1", "ItemRefShoppingTooltip2", "ItemRefTooltip" }) do
			local t = _G[ad]
			if t and t.IsShown and t:IsShown() then return true end
		end
		return false
	end
	local baglandi = setmetatable({}, { __mode = "k" })
	local function duzelt(r, t)
		if type(t) ~= "string" or #t > 40 then return end
		local sade = t:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", "")
		local tr = BASLIK[sade]
		if tr then
			local renk = t:match("^(|c%x%x%x%x%x%x%x%x)")
			r:SetText(renk and (renk .. tr .. "|r") or tr)
			return true
		end
	end
	local function cevirYazi(r)
		local ok, t = pcall(r.GetText, r)
		if not ok then return end
		if duzelt(r, t) and not baglandi[r] then
			-- Oyun bu yazıyı sürekli yeniden İngilizce yazıyor: yazıldığı anda tekrar çevir (titremesin)
			baglandi[r] = true
			pcall(hooksecurefunc, r, "SetText", function(self, yeni)
				if G.ayar("acik") and G.modul("ipucu") then duzelt(self, yeni) end
			end)
		end
	end
	local bolgeOn = setmetatable({}, { __mode = "k" })
	local tSay = 0
	local imlec
	local function tara()
		if not G.ayar("acik") or not G.modul("ipucu") or not ipucuAcik() then return end
		-- Eşya ipucu açıkken (çanta/karakter penceresinde gezinirken) tüm çerçeveleri dolaşma
		if GameTooltip and GameTooltip.GetItem then
			local okI, _, lnk = pcall(GameTooltip.GetItem, GameTooltip)
			if okI and lnk then return end
		end
		-- Savaşta tüm çerçeveleri dolaşma (takılma yapmasın)
		if InCombatLockdown and InCombatLockdown() then return end
		G.tani = G.tani or {}
		local t0 = debugprofilestop and debugprofilestop() or 0
		local f
		if imlec then f = EnumerateFrames(imlec) else
			tSay = tSay + 1
			if tSay % 60 == 0 then bolgeOn = setmetatable({}, { __mode = "k" }) end
			f = EnumerateFrames()
		end
		imlec = nil
		local n = 0
		while f and n < 40000 do
			n = n + 1
			if t0 and n % 32 == 0 and debugprofilestop() - t0 > 0.8 then imlec = f; return end
			local fad = f.GetName and f:GetName()
			local canta = fad and (fad:find("^Baganator") or fad:find("^Bagnon") or fad:find("^ContainerFrame") or fad:find("^BankFrame") or fad:find("^Syndicator") or fad:find("^LootFrame") or fad:find("^GroupLoot") or fad:find("^LootHistory") or fad:find("^BonusRoll"))
			if not canta and f.IsShown and f:IsShown() then
				if f.GetRegions then
					local c = bolgeOn[f]
					if not c then
						c = {}
						for _, r in ipairs({ f:GetRegions() }) do if r.GetText then c[#c + 1] = r end end
						bolgeOn[f] = c
					end
					for _, r in ipairs(c) do if r.IsShown and r:IsShown() then cevirYazi(r) end end
				end
				if f.GetFontString and f.GetText and f.IsObjectType and f:IsObjectType("Button") then cevirYazi(f) end
			end
			f = EnumerateFrames(f)
		end
		if debugprofilestop then
			local ms = debugprofilestop() - t0
			G.tani.ipMs = ms
			if ms > (G.tani.ipMax or 0) then G.tani.ipMax = ms end
		end
	end
	G.basla(function()
		if EnumerateFrames and C_Timer and C_Timer.NewTicker then
			G.olcTicker(0.5, function() pcall(tara) end)
		end
	end)
end


-- Tanı: /wowturkce ipucu yazıp 5 saniye içinde fareyi çeviri sorunu olan ipucuna (buff vb.) getir
function G.ipucuTani()
	G.yaz("5 saniye içinde fareyi ipucuna getir...")
	C_Timer.After(5, function()
		local tt = GameTooltip
		if not tt or not tt:IsShown() then G.yaz("İpucu açık değil"); return end
		local ad = tt:GetName()
		local sahip = tt:GetOwner()
		G.yaz(("Sahip: %s | satır: %d | hedef: %s | aura: %s"):format(sahip and (sahip:GetName() or tostring(sahip.GetObjectType and sahip:GetObjectType())) or "?", tt:NumLines() or 0, tostring(hedef[tt]), tostring(auraIpucu[tt])))
		for i = 1, math.min(tt:NumLines() or 0, 8) do
			local l, r = _G[ad .. "TextLeft" .. i], _G[ad .. "TextRight" .. i]
			local lt = l and l:GetText()
			local font = l and l.GetFont and l:GetFont()
			local tr = type(lt) == "string" and not G.gizli(lt) and (G.cevir(G.Arayuz, lt) or G.cevir(G.Buyu, lt) or G.buyuAdiCevir(lt))
			G.yaz(("%d: %s | font:%s | tr:%s"):format(i, tostring(lt and (G.gizli(lt) and "<gizli>" or lt:sub(1, 50))), tostring(font ~= nil), tostring(tr and tr:sub(1, 30))))
		end
		G.yaz("Son hata: " .. tostring((G.tani or {}).hata or "yok"))
		local t = G.tani or {}
		G.yaz("Son büyü/aura ipucu: " .. tostring((G.tani or {}).auraSon or "yok"))
		G.yaz("Gizli aura çevirisi: " .. tostring((G.tani or {}).gizliAura or "yok"))
		G.yaz(("İpucu çevirici: %d çağrı | son hata: %s | son erken çıkış: %s"):format(t.ipucuCagri or 0, tostring(t.ipucuHata or "yok"), tostring(t.ipucuIlk or "yok")))
		local d = tt.GetPrimaryTooltipData and tt:GetPrimaryTooltipData()
		G.yaz("Veri türü: " .. tostring(type(d) == "table" and d.type or "?") .. " | modül buyu=" .. tostring(G.modul("buyu")) .. " buyuadi=" .. tostring(G.modul("buyuadi")) .. " | UnitAura türü=" .. tostring(Enum and Enum.TooltipDataType and Enum.TooltipDataType.UnitAura))
	end)
end

-- İpucu penceresinin konumu (/wowturkce konum ...)
local tasiyici
local function nokta()
	local n = G.ayar("ipucuNokta")
	if type(n) ~= "table" or not n[1] then n = { "BOTTOMRIGHT", "BOTTOMRIGHT", -90, 130 } end
	return n
end
local function tasiyiciYap()
	if tasiyici then return tasiyici end
	local f = CreateFrame("Frame", "WoWTurkceIpucuTasi", UIParent)
	f:SetSize(230, 80)
	f:SetFrameStrata("FULLSCREEN_DIALOG")
	f:SetClampedToScreen(true)
	f:SetMovable(true)
	f:EnableMouse(true)
	local bg = f:CreateTexture(nil, "BACKGROUND")
	bg:SetAllPoints()
	bg:SetColorTexture(0.1, 0.5, 0.9, 0.55)
	local fs = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	fs:SetPoint("CENTER")
	fs:SetWidth(210)
	fs:SetText("İpucu penceresi yeri\nShift basılı tutup sürükle\nBitince: /wowturkce konum kilitle")
	local tasiniyor = false
	f:SetScript("OnMouseDown", function(self, btn)
		if btn == "LeftButton" and IsShiftKeyDown() then
			tasiniyor = true
			self:StartMoving()
		end
	 end)
	local function birak(self)
		if not tasiniyor then return end
		tasiniyor = false
		self:StopMovingOrSizing()
		local p, _, rp, x, y = self:GetPoint()
		if p then G.ayarla("ipucuNokta", { p, rp, math.floor(x + 0.5), math.floor(y + 0.5) }) end
	end
	f:SetScript("OnMouseUp", birak)
	f:SetScript("OnHide", birak)
	local n = nokta()
	f:SetPoint(n[1], UIParent, n[2], n[3], n[4])
	f:Hide()
	tasiyici = f
	return f
end
function G.ipucuTasiyiciAc(goster)
	local f = tasiyiciYap()
	if goster then
		G.ayarla("ipucuKonum", "ozel")
		f:Show()
	else
		f:Hide()
	end
end
G.basla(function()
	if not GameTooltip_SetDefaultAnchor then return end
	hooksecurefunc("GameTooltip_SetDefaultAnchor", function(tt, parent)
		local k = G.ayar("ipucuKonum")
		if not k or k == "varsayilan" or tt ~= GameTooltip then return end
		if k == "fare" then
			tt:SetOwner(parent or UIParent, "ANCHOR_CURSOR")
			return
		end
		tt:ClearAllPoints()
		if k == "ozel" then tt:SetPoint("BOTTOMRIGHT", tasiyiciYap(), "BOTTOMRIGHT", 0, 0)
		elseif k == "ortaalt" then tt:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, 190)
		elseif k == "sagust" then tt:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -30, -300)
		elseif k == "solalt" then tt:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", 30, 190) end
	end)
end)

-- Tanı: imleç bir ipucunun üzerindeyken /wtrtani yaz; ipucu ve sahibi hakkında bilgi sohbete yazılır
SLASH_WTRTANI1 = "/wtrtani"
local taniAsil
SlashCmdList["WTRTANI"] = function()
	print("|cff33ff99WTR tanı:|r başlıyor...")
	local ok, e = pcall(taniAsil)
	if not ok then print("|cffff4444WTR tanı hatası:|r " .. tostring(e)) end
end
taniAsil = function()
	local kayit = {}
	local function p(...)
		local parca = {}
		for i = 1, select("#", ...) do parca[#parca + 1] = tostring((select(i, ...))) end
		kayit[#kayit + 1] = table.concat(parca, " ")
		print("|cff33ff99WTR tanı:|r", ...)
	end
	local function yaz(v) if G.gizli(v) then return "<gizli>" end return tostring(v) end
	local function anahtarlar(o)
		local l = {}
		pcall(function()
			for k, v in pairs(o) do
				if type(k) == "string" and (k:lower():find("aura") or k:lower():find("spell") or k:lower():find("unit") or k == "id" or k == "type") then l[#l + 1] = k .. "=" .. yaz(type(v) == "table" and "tablo" or v) end
			end
		end)
		pcall(function()
			local mt = getmetatable(o); local ix = mt and mt.__index
			if type(ix) == "table" then
				for k in pairs(ix) do
					if type(k) == "string" and (k:find("Aura") or k:find("Spell") or k:find("Tooltip")) then l[#l + 1] = k .. "()" end
				end
			end
		end)
		return table.concat(l, " ")
	end
	p("gizliAura=" .. yaz(G.tani and G.tani.gizliAura))
	p("healiumAura=" .. yaz(G._healiumAuraSon))
	do local n = 0; for _ in pairs(type(WoWTurkce_Ayar) == "table" and WoWTurkce_Ayar.auraIkon or {}) do n = n + 1 end; p("simge önbelleği=" .. n) end
	p("RETAIL=" .. tostring(G.RETAIL) .. " FOREVER=" .. tostring(G.FOREVER) .. " savaş=" .. tostring(InCombatLockdown and InCombatLockdown()) .. " proje=" .. tostring(WOW_PROJECT_ID) .. " sürüm=" .. tostring(select(4, GetBuildInfo())))
	local f = EnumerateFrames(); local n = 0
	while f and n < 50000 do
		n = n + 1
		local ok, gor = pcall(function()
			if not (f:IsVisible() and f:GetObjectType() == "GameTooltip") then return false end
			local ad0 = f:GetName() or ""
			if ad0:find("Scan") or ad0:find("scan") then return false end
			local s0 = f:GetOwner()
			return s0 ~= nil and s0 ~= UIParent and s0 ~= WorldFrame
		end)
		if ok and gor then
			local ad = f:GetName() or "<adsız>"
			local l1 = f.GetName and f:GetName() and _G[f:GetName() .. "TextLeft1"]
			local t1 = l1 and l1:GetText()
			p(ad, "satır=" .. yaz(f:NumLines()), "1=" .. yaz(t1))
			local okd, d = pcall(f.GetPrimaryTooltipData, f)
			if okd and type(d) == "table" then
				p("  veri tür=" .. yaz(d.type) .. " id=" .. yaz(d.id))
				local argl = {}
				for _, a in ipairs(d.args or {}) do if type(a) == "table" then argl[#argl + 1] = yaz(a.field) .. "=" .. yaz(a.intVal or a.stringVal or a.guidVal) end end
				if #argl > 0 then p("  args: " .. table.concat(argl, " ")) end
				for li = 1, 3 do local ln = d.lines and d.lines[li]; if ln then p("  satır" .. li .. ": " .. yaz(ln.leftText) .. " | tür=" .. yaz(ln.type)) end end
			end
			for li = 2, 3 do local lf = _G[(f:GetName() or "x") .. "TextLeft" .. li]; if lf then p("  ekran" .. li .. "=" .. yaz(lf:GetText())) end end
			local oks, sahip = pcall(f.GetOwner, f)
			if oks and sahip then
				local sn = sahip.GetName and sahip:GetName() or "<adsız>"
				local par = sahip.GetParent and sahip:GetParent()
				p("  sahip=" .. sn .. " (" .. yaz(sahip.GetObjectType and sahip:GetObjectType()) .. ") üst=" .. yaz(par and par.GetName and par:GetName()))
				p("  " .. anahtarlar(sahip))
				pcall(function()
					local birim = sahip.unit or (par and par.unit) or "target"
					local id = sahip.GetID and sahip:GetID()
					p("  birim=" .. yaz(birim) .. " id=" .. yaz(id))
					local ikon = sahip.icon or sahip.Icon or _G[sn .. "Icon"]
					if ikon and ikon.GetTexture then p("  ikon=" .. yaz(ikon:GetTexture())) end
					if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex and id and id > 0 then
						for _, filt in ipairs({ "HARMFUL", "HELPFUL" }) do
							local okA, a = pcall(C_UnitAuras.GetAuraDataByIndex, birim, id, filt)
							if okA and type(a) == "table" then p("  " .. filt .. ": ad=" .. yaz(a.name) .. " sid=" .. yaz(a.spellId) .. " aid=" .. yaz(a.auraInstanceID) .. " ikon=" .. yaz(a.icon)) end
						end
					end
				end)
			end
		end
		f = EnumerateFrames(f)
	end
	WoWTurkce_Ayar = WoWTurkce_Ayar or {}
	WoWTurkce_Ayar.sonTani = kayit
	p("Kaydedildi. /reload yapınca bilgisayardan okunabilir.")
end

-- Savaş dışında oyuncu ve hedef üzerindeki auraları kendiliğinden tara: Türkçe ad/açıklamayı simge numarasıyla sakla.
-- Böylece fareyle üzerine gelinmemiş büffler de savaşta (yazılar gizliyken) Türkçe görünür.
do
	local function buyuTr(en)
		if type(en) ~= "string" or en == "" then return nil end
		return (G.buyuAdiCevir and G.buyuAdiCevir(en)) or (type(G.Arayuz[en]) == "string" and G.Arayuz[en]) or nil
	end
	local function auraTara(birim)
		if InCombatLockdown and InCombatLockdown() then return end
		if not (C_UnitAuras and C_UnitAuras.GetAuraDataByIndex) or not UnitExists(birim) then return end
		if type(WoWTurkce_Ayar) ~= "table" then return end
		WoWTurkce_Ayar.auraIkon = WoWTurkce_Ayar.auraIkon or {}
		local tb = WoWTurkce_Ayar.auraIkon
		for _, filt in ipairs({ "HELPFUL", "HARMFUL" }) do
			for i = 1, 40 do
				local ok, a = pcall(C_UnitAuras.GetAuraDataByIndex, birim, i, filt)
				if not ok or type(a) ~= "table" then break end
				local ikon, en = a.icon, a.name
				if type(ikon) == "number" and not G.gizli(ikon) and tb[ikon] and tb[ikon][2] then
					-- zaten kayıtlı (ad + açıklama): tekrar çevirme (takılma yapmasın)
				elseif type(ikon) == "number" and not G.gizli(ikon) and type(en) == "string" and not G.gizli(en) then
					local tr = buyuTr(en)
					if tr then
						local k = tb[ikon] or {}
						k[1] = G.adStil("stilBuyu", tr, en)
						if C_TooltipInfo and C_TooltipInfo.GetUnitAura then
							local okd, d = pcall(C_TooltipInfo.GetUnitAura, birim, i, filt)
							local satirlar = okd and type(d) == "table" and d.lines
							if type(satirlar) == "table" and #satirlar >= 3 then
								local m = satirlar[2] and satirlar[2].leftText
								if type(m) == "string" and not G.gizli(m) then
									local bas, govde, son = renkAyir(m)
									local t2 = satirCevir(govde, true)
									if t2 then k[2] = bas .. t2 .. son end
								end
							end
						end
						if a.dispelName and not G.gizli(a.dispelName) and G.buyuAltCevir then k[3] = G.buyuAltCevir(a.dispelName) or k[3] end
						tb[ikon] = k
					end
				end
			end
		end
	end
	G.auraTara = auraTara
	-- Büyü kitabındaki büyüler: adları önceden kaydet (düşmana savaşta atılan debufflar için)
	local function kitapTara()
		if type(WoWTurkce_Ayar) ~= "table" or not GetSpellBookItemName then return end
		WoWTurkce_Ayar.auraIkon = WoWTurkce_Ayar.auraIkon or {}
		local tb = WoWTurkce_Ayar.auraIkon
		local tur = BOOKTYPE_SPELL or "spell"
		for i = 1, 500 do
			local ok, en = pcall(GetSpellBookItemName, i, tur)
			if not ok or not en then break end
			local okt, ikon = pcall(GetSpellBookItemTexture, i, tur)
			if okt and type(ikon) == "number" and not tb[ikon] then
				local tr = buyuTr(en)
				if tr then tb[ikon] = { G.adStil("stilBuyu", tr, en) } end
			end
		end
	end
	local f = CreateFrame("Frame")
	f:RegisterEvent("PLAYER_ENTERING_WORLD"); f:RegisterEvent("PLAYER_TARGET_CHANGED"); f:RegisterEvent("PLAYER_REGEN_ENABLED")
	pcall(f.RegisterUnitEvent, f, "UNIT_AURA", "player", "target")
	local bekleyen, kitapYapildi = false, false
	f:SetScript("OnEvent", function(_, olay)
		if olay == "PLAYER_ENTERING_WORLD" and not kitapYapildi then
			kitapYapildi = true
			C_Timer.After(5, function() pcall(kitapTara) end)
		end
		if bekleyen or (InCombatLockdown and InCombatLockdown()) then return end
		bekleyen = true
		C_Timer.After(2, function()
			bekleyen = false
			if InCombatLockdown and InCombatLockdown() then return end
			pcall(auraTara, "player"); pcall(auraTara, "target")
		end)
	end)
end
