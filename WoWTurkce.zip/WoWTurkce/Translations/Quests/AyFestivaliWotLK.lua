-- Ay Festivali görevleri (WotLK)
-- b=başlık, a=açıklama, h=hedef, i=ilerleme, t=tamamlama
-- k = çevrilen İngilizce metnin parmak izi (metin değişirse çeviri gösterilmez, yeniden kaydedilir)
local V = WoWTurkce.Veri

V[13012] = { b="Ata Sardis", t="Bu toprakların insanlarının kadim ırklara hâlâ saygı gösterdiğini bilmek güzel. Sana esenlik dilerim, $N; bu nişanı da sana sunuyorum...", k={b=3834374680, t=2506422786} }
V[13013] = { b="Ata Beldak", t="Bu toprakların insanlarının kadim ırklara hâlâ saygı gösterdiğini bilmek güzel. Sana esenlik dilerim, $N; bu nişanı da sana sunuyorum...", k={b=1222114069, t=2506422786} }
V[13014] = { b="Ata Morthie", t="Bu toprakların insanlarının kadim ırklara hâlâ saygı gösterdiğini bilmek güzel. Sana esenlik dilerim, $N; bu nişanı da sana sunuyorum...", k={b=1737423530, t=2506422786} }
V[13015] = { b="Ata Fargal", t="Bu toprakların insanlarının kadim ırklara hâlâ saygı gösterdiğini bilmek güzel. Sana esenlik dilerim, $N; bu nişanı da sana sunuyorum...", k={b=581139615, t=2506422786} }
V[13016] = { b="Ata Northal", t="Bu toprakların insanlarının kadim ırklara hâlâ saygı gösterdiğini bilmek güzel. Sana esenlik dilerim, $N; bu nişanı da sana sunuyorum...", k={b=434697834, t=2506422786} }
V[13017] = { b="Ata Jarten", k={b=3464281590} }
V[13018] = { b="Ata Sandrene", t="Bu toprakların insanlarının kadim ırklara hâlâ saygı gösterdiğini bilmek güzel. Sana esenlik dilerim, $N; bu nişanı da sana sunuyorum...", k={b=4035011266, t=2506422786} }
V[13019] = { b="Ata Thoim", t="Bu toprakların insanlarının kadim ırklara hâlâ saygı gösterdiğini bilmek güzel. Sana esenlik dilerim, $N; bu nişanı da sana sunuyorum...", k={b=2716112051, t=2506422786} }
V[13020] = { b="Ata Stonebeard", k={b=2142508921} }
V[13021] = { b="Ata Igasho", t="Bu toprakların insanlarının kadim ırklara hâlâ saygı gösterdiğini bilmek güzel. Sana esenlik dilerim, $N; bu nişanı da sana sunuyorum...", k={b=713881869, t=2506422786} }
V[13022] = { b="Ata Nurgen", t="Bu toprakların insanlarının kadim ırklara hâlâ saygı gösterdiğini bilmek güzel. Sana esenlik dilerim, $N; bu nişanı da sana sunuyorum...", k={b=691351105, t=2506422786} }
V[13023] = { b="Ata Kilias", t="Bu toprakların insanlarının kadim ırklara hâlâ saygı gösterdiğini bilmek güzel. Sana esenlik dilerim, $N; bu nişanı da sana sunuyorum...", k={b=3662232079, t=2506422786} }
V[13024] = { b="Ata Wanikaya", t="Ruhun yaşamla yanıp tutuşuyor, genç $c. Gösterdiğin saygıyı kabul ediyor, karşılığında sana bu nişanı sunuyorum...", k={b=2627288967, t=3111156332} }
V[13025] = { b="Ata Lunaro", t="Ruhun yaşamla yanıp tutuşuyor, genç $c. Gösterdiğin saygıyı kabul ediyor, karşılığında sana bu nişanı sunuyorum...", k={b=2009126307, t=3111156332} }
V[13026] = { b="Ata Bluewolf", t="Ruhun yaşamla yanıp tutuşuyor, genç $c. Gösterdiğin saygıyı kabul ediyor, karşılığında sana bu nişanı sunuyorum...", k={b=2851301682, t=3111156332} }
V[13027] = { b="Ata Tauros", t="Ruhun yaşamla yanıp tutuşuyor, genç $c. Gösterdiğin saygıyı kabul ediyor, karşılığında sana bu nişanı sunuyorum...", k={b=368544816, t=3111156332} }
V[13028] = { b="Ata Graymane", t="Ruhun yaşamla yanıp tutuşuyor, genç $c. Gösterdiğin saygıyı kabul ediyor, karşılığında sana bu nişanı sunuyorum...", k={b=2887194758, t=3111156332} }
V[13029] = { b="Ata Pamuya", k={b=689673119} }
V[13030] = { b="Ata Whurain", t="Ruhun yaşamla yanıp tutuşuyor, genç $c. Gösterdiğin saygıyı kabul ediyor, karşılığında sana bu nişanı sunuyorum...", k={b=681907920, t=3111156332} }
V[13031] = { b="Ata Skywarden", k={b=614725802} }
V[13032] = { b="Ata Muraco", k={b=976225241} }
V[13033] = { b="Ata Arp", t="Ruhun yaşamla yanıp tutuşuyor, genç $c. Gösterdiğin saygıyı kabul ediyor, karşılığında sana bu nişanı sunuyorum...", k={b=2099727669, t=3111156332} }
V[13065] = { b="Ata Ohanzee", t="Bu toprakların insanlarının kadim ırklara hâlâ saygı gösterdiğini bilmek güzel. Sana esenlik dilerim, $N; bu nişanı da sana sunuyorum...", k={b=4105366268, t=2506422786} }
V[13066] = { b="Ata Yurauk", t="Bu toprakların insanlarının kadim ırklara hâlâ saygı gösterdiğini bilmek güzel. Sana esenlik dilerim, $N; bu nişanı da sana sunuyorum...", k={b=2013210547, t=2506422786} }
V[13067] = { b="Ata Chogan'gada", t="Bu toprakların insanlarının kadim ırklara hâlâ saygı gösterdiğini bilmek güzel. Sana esenlik dilerim, $N; bu nişanı da sana sunuyorum...", k={b=3698876559, t=2506422786} }
