-- ForeverDB.net verisinden çıkarılan ad çevirileri. Data from ForeverDB.net (https://foreverdb.net)
local A, U = WoWTurkce.Arayuz, WoWTurkce.NpcAltBaslik
local function e(en, tr) if A[en] == nil then A[en] = tr end; if U[en] == nil then U[en] = tr end end
e("Brotherhood of the Light", "Işık Kardeşliği")
e("Enchanter", "Büyü Ustası")
e("Junior Skinning Trainer", "Çömez Derici Eğitmeni")
e("Leatherworker", "Deri İşçisi")
e("The Thorium Brotherhood", "Toryum Kardeşliği")
e("Traveling Ranged Weapon Salesman", "Gezgin Menzilli Silah Satıcısı")
