-- Ekran ortasındaki kırmızı hata ve sarı bilgi mesajlarının çevirisi.
-- Oyunun hata çerçevesi mesajı bizden alır; olayın kendisi diğer addon'lara değişmeden gider.
local G = WoWTurkce

-- Desenli mesajlar (isim içerenler): { Lua deseni, Türkçe }
G.HataDesen = G.HataDesen or {}

local function normal(s) return (s:gsub("[%.!]+$", "")) end

local function hataCevir(msg)
	if type(msg) ~= "string" or msg == "" then return nil end
	local tr = G.cevir(G.Hata, msg) or G.cevir(G.Hata, normal(msg))
	if tr then return tr end
	for _, d in ipairs(G.HataDesen) do
		if msg:find(d[1]) then return (msg:gsub(d[1], d[2])) end
	end
	-- Oyunun hazır hata metinleri (GlobalStrings ERR_...)
	tr = G.cevir(G.Arayuz, msg) or (G.globalDesenCevir and G.globalDesenCevir(msg))
	return tr
end
G.hataCevir = hataCevir

G.basla(function()
	-- Retail'de hata çerçevesinin olaylarını yönlendirmek Blizzard kodunu bozabilir; orada dokunmuyoruz
	if G.RETAIL then return end
	local cerceve = UIErrorsFrame
	if not cerceve or not cerceve.GetScript then return end
	local orijinal = cerceve:GetScript("OnEvent")
	if not orijinal then return end
	local olaylar = { "UI_ERROR_MESSAGE", "UI_INFO_MESSAGE" }
	local f = CreateFrame("Frame")
	for _, e in ipairs(olaylar) do
		if cerceve:IsEventRegistered(e) then
			cerceve:UnregisterEvent(e)
			f:RegisterEvent(e)
		end
	end
	f:SetScript("OnEvent", function(_, olay, a, b, ...)
		local ok = pcall(function()
			if G.modul("hata") and not G.gizli(a) and not G.gizli(b) then
				-- Yeni istemcilerde (mesajTürü, mesaj), eskilerde (mesaj, r, g, b)
				if type(a) == "string" then
					local tr = hataCevir(a)
					if tr then a = tr elseif olay == "UI_ERROR_MESSAGE" then G.kaydetDiger("hata", G.sablon(normal(a))) end
				elseif type(b) == "string" then
					local tr = hataCevir(b)
					if tr then b = tr elseif olay == "UI_ERROR_MESSAGE" then G.kaydetDiger("hata", G.sablon(normal(b))) end
				end
			end
		end)
		orijinal(cerceve, olay, a, b, ...)
	end)
end)

-- Doğrudan UIErrorsFrame:AddMessage ile yazılan mesajlar (ör. "Enemy Nameplates Turned On")
G.basla(function()
	if G.RETAIL then return end
	local c = UIErrorsFrame
	if not c or not c.AddMessage or c._gtrHata then return end
	c._gtrHata = true
	local orj = c.AddMessage
	c.AddMessage = function(self, msg, ...)
		if type(msg) == "string" and G.modul("hata") and not G.gizli(msg) then
			local ok, tr = pcall(hataCevir, msg)
			if ok and tr then msg = tr end
		end
		return orj(self, msg, ...)
	end
end)
