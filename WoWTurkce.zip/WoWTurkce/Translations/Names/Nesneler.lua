-- Etkileşime geçilen nesneler (sandık, kutu, maden damarı, bitki, kitap, sunak, ilan...): ipucundaki ad.
local A, N = WoWTurkce.Arayuz, WoWTurkce.Nesne
local function e(en, tr) if A[en] == nil then A[en] = tr end N[en] = tr end
e("A Conspicuous Gravestone", "Göze Çarpan Mezar Taşı")
e("A Dusty Tome", "Tozlu Bir Cilt")
e("A Dwarven Corpse", "Bir Cüce Cesedi")
e("A Small Pack", "Küçük Bir Çanta")
e("A Soggy Scroll", "Islak Bir Parşömen")
e("A Treatise on Military Ranks", "Askeri Rütbeler Üzerine Bir İnceleme")
e("A Weathered Grave", "Yıpranmış Bir Mezar")
e("A Wrecked Raft", "Parçalanmış Bir Sal")
e("A half-eaten body", "Yarısı yenmiş bir ceset")
e("Abercrombie's Crate", "Abercrombie'nin Sandığı")
e("Admiral Barean Westwind", "Amiral Barean Westwind")
e("Aegwynn and the Dragon Hunt", "Aegwynn ve Ejderha Avı")
e("Aftermath of the Second War", "İkinci Savaş'ın Ardından")
e("Agamand Weapon Rack", "Agamand Silah Rafı")
e("Alchemical Implements", "Simya Aletleri")
e("Alchemy Set", "Simya Takımı")
e("Alexston's Chest", "Alexston'ın Sandığı")
e("Alien Egg", "Yabancı Yumurta")
e("Alliance Banner", "Alliance Sancağı")
e("Alliance Chest", "Alliance Sandığı")
e("Alliance Military Ranks", "Alliance Askeri Rütbeleri")
e("Altar of Archaedas", "Archaedas Sunağı")
e("Altar of Elune", "Elune Sunağı")
e("Altar of Hakkar", "Hakkar Sunağı")
e("Altar of Suntara", "Suntara Sunağı")
e("Altar of The Keepers", "Bekçilerin Sunağı")
e("Altar of Zanza", "Zanza Sunağı")
e("Altar of the Deeps", "Derinliklerin Sunağı")
e("Altar of the Defiler", "Kirleticinin Sunağı")
e("Altar of the Tides", "Gelgitlerin Sunağı")
e("Alterac Granite", "Alterac Graniti")
e("Ambassador's Locker", "Elçinin Dolabı")
e("Ambercorn", "Kehribar Palamut")
e("Ambermill Strongbox", "Ambermill Kasası")
e("Ammo Crate", "Cephane Sandığı")
e("An Empty Jar", "Boş Bir Kavanoz")
e("Ancient Brazier", "Kadim Mangal")
e("Ancient Chest", "Kadim Sandık")
e("Ancient Egg", "Kadim Yumurta")
e("Ancient Flame", "Kadim Alev")
e("Ancient Inscription", "Kadim Yazıt")
e("Ancient Relic", "Kadim Kalıntı")
e("Ancient Statuette", "Kadim Heykelcik")
e("Ancient Treasure", "Kadim Hazine")
e("Andron's Bookshelf", "Andron'un Kitaplığı")
e("Anton's Letter of Commendation", "Anton'un Takdir Mektubu")
e("Apple Bob", "Elma Yakalama")
e("Arathor and the Troll Wars", "Arathor ve Trol Savaşları")
e("Arcane Focusing Crystal", "Arkan Odaklama Kristali")
e("Archbishop Alonsus Faol", "Başpiskopos Alonsus Faol")
e("Archimonde's Return and the Flight to Kalimdor", "Archimonde'un Dönüşü ve Kalimdor'a Kaçış")
e("Archmage Khadgar of the Kirin Tor", "Kirin Tor'dan Başbüyücü Khadgar")
e("Arena Spoils", "Arena Ganimeti")
e("Arko'niran's Chest", "Arko'niran'ın Sandığı")
e("Arthas' Tears", "Arthas'ın Gözyaşları")
e("Artificial Extrapolator", "Yapay Ekstrapolatör")
e("Arugal's Focus", "Arugal'ın Odağı")
e("Atal'ai Statue", "Atal'ai Heykeli")
e("Atal'ai Tablet", "Atal'ai Tableti")
e("Attack Plan: Orgrimmar", "Saldırı Planı: Orgrimmar")
e("Attack Plan: Sen'jin Village", "Saldırı Planı: Sen'jin Köyü")
e("Attack Plan: Valley of Trials", "Saldırı Planı: Valley of Trials")
e("Augustus' Receipt Book", "Augustus'un Makbuz Defteri")
e("Aurora's Book", "Aurora'nın Kitabı")
e("Azsharite Formation", "Azsharit Oluşumu")
e("Bael Modan Flying Machine", "Bael Modan Uçan Makinesi")
e("Baelog's Chest", "Baelog'un Sandığı")
e("Baelog's Journal", "Baelog'un Günlüğü")
e("Bailor's Ore", "Bailor'un Cevheri")
e("Balia'mah Trophy Skulls", "Balia'mah Ganimet Kafatasları")
e("Balnir Snapdragons", "Balnir Aslanağızları")
e("Barrow Cache", "Höyük Zulası")
e("Basin of Holy Water", "Kutsal Su Leğeni")
e("Basket of Bloodkelp", "Kan Yosunu Sepeti")
e("Bath'rah's Cauldron", "Bath'rah'ın Kazanı")
e("Battered Chest", "Hırpalanmış Sandık")
e("Battered Dwarven Skeleton", "Hırpalanmış Cüce İskeleti")
e("Battered Footlocker", "Hırpalanmış Eşya Sandığı")
e("Battered Tackle Box", "Hırpalanmış Olta Kutusu")
e("Bauble Container", "Süs Eşyası Kutusu")
e("Beached Sea Creature", "Karaya Vurmuş Deniz Yaratığı")
e("Beached Sea Turtle", "Karaya Vurmuş Deniz Kaplumbağası")
e("Beginnings of the Undead Threat", "Ölümsüz Tehdidinin Başlangıcı")
e("Bell of Dethmoora", "Dethmoora Çanı")
e("Belnistrasz's Brazier", "Belnistrasz'ın Mangalı")
e("Benedict's Chest", "Benedict'in Sandığı")
e("Berard's Bookshelf", "Berard'ın Kitaplığı")
e("Beware of Pterrordax", "Pterrordax'a Dikkat")
e("Beyond the Dark Portal", "Kara Geçit'in Ötesinde")
e("Bijou's Belongings", "Bijou'nun Eşyaları")
e("Bingles's Blastencapper", "Bingles'ın Patlatıcısı")
e("Bingles's Toolbucket", "Bingles'ın Alet Kovası")
e("Bink's Toolbox", "Bink'in Alet Kutusu")
e("Black Dragon Egg", "Kara Ejderha Yumurtası")
e("Black Lotus", "Kara Lotus")
e("Black Shield", "Kara Kalkan")
e("Blackrock Altar", "Blackrock Sunağı")
e("Blacksmith Banner", "Demirci Sancağı")
e("Blacksmithing Plans", "Demircilik Planları")
e("Blackwood Fruit Stores", "Blackwood Meyve Depoları")
e("Blackwood Grain Stores", "Blackwood Tahıl Depoları")
e("Blackwood Nut Stores", "Blackwood Kuruyemiş Depoları")
e("Blastenheimer 5000 Ultra Cannon", "Blastenheimer 5000 Ultra Top")
e("Blindweed", "Kör Otu")
e("Blood of Heroes", "Kahramanların Kanı")
e("Bloodpetal Sprout", "Kan Yaprağı Filizi")
e("Bloodsail Charts", "Bloodsail Haritaları")
e("Bloodsail Correspondence", "Bloodsail Yazışmaları")
e("Bloodsail Orders", "Bloodsail Emirleri")
e("Blue Power Crystal", "Mavi Güç Kristali")
e("Blue Raptor Nest", "Mavi Raptor Yuvası")
e("Blue Soulgem", "Mavi Ruh Taşı")
e("Blueleaf Tuber", "Mavi Yaprak Yumrusu")
e("Bonfire", "Şenlik Ateşi")
e("Book \"Soothsaying for Dummies\"", "\"Aptallar İçin Kâhinlik\" Kitabı")
e("Bookie Herod's Records", "Bahisçi Herod'un Kayıtları")
e("Bookie Herod's Strongbox", "Bahisçi Herod'un Kasası")
e("Booty Bay Alarm Bell", "Booty Bay Alarm Çanı")
e("Bottle of Disease", "Hastalık Şişesi")
e("Box of Assorted Parts", "Karışık Parça Kutusu")
e("Box of Incendiaries", "Yangın Bombası Kutusu")
e("Brazier of Everfount", "Everfount Mangalı")
e("Brazier of Hatred", "Nefret Mangalı")
e("Brazier of Madness", "Delilik Mangalı")
e("Brazier of Malice", "Kin Mangalı")
e("Brazier of Pain", "Acı Mangalı")
e("Brazier of Suffering", "Iztırap Mangalı")
e("Brazier of the Dormant Flame", "Uyuyan Alevin Mangalı")
e("Brazier of the Herald", "Habercinin Mangalı")
e("Briarthorn", "Böğürtlen Dikeni")
e("Brightly Colored Egg", "Rengârenk Yumurta")
e("Broken Barrel", "Kırık Fıçı")
e("Bruiseweed", "Bere Otu")
e("Bubbling Cauldron", "Fokurdayan Kazan")
e("Bubbling Fissure", "Fokurdayan Yarık")
e("Buccaneer's Strongbox", "Korsanın Kasası")
e("Bundle of Wood", "Odun Demeti")
e("Burning Blade Stash", "Burning Blade Zulası")
e("Button", "Düğme")
e("Cache of Explosives", "Patlayıcı Zulası")
e("Cache of the Firelord", "Ateş Lordu'nun Zulası")
e("Cactus Apple", "Kaktüs Elması")
e("Cage", "Kafes")
e("Calcified Elven Gem", "Kireçlenmiş Elf Mücevheri")
e("Call to Arms!", "Silah Başına!")
e("Cannon", "Top")
e("Cannonball Stack", "Gülle Yığını")
e("Cantation of Manifestation", "Tezahür Büyüsü")
e("Captain's Chest", "Kaptanın Sandığı")
e("Captain's Footlocker", "Kaptanın Eşya Sandığı")
e("Caravan Chest", "Kervan Sandığı")
e("Carefully Wrapped Present", "Özenle Paketlenmiş Hediye")
e("Carved Stone Urn", "Oyma Taş Vazo")
e("Cat Figurine", "Kedi Heykelciği")
e("Catalogue of the Wayward", "Yoldan Çıkmışların Kataloğu")
e("Chalice of Elune", "Elune Kadehi")
e("Challenge to Urok", "Urok'a Meydan Okuma")
e("Charge of the Dragonflights", "Ejderha Soylarının Hücumu")
e("Charred Bone Fragment", "Kömürleşmiş Kemik Parçası")
e("Cheer Speaker", "Tezahürat Hoparlörü")
e("Chen's Empty Keg", "Chen'in Boş Fıçısı")
e("Chest of Containment Coffers", "Muhafaza Kasaları Sandığı")
e("Chest of Nesting", "Yuvalama Sandığı")
e("Chest of The Seven", "Yedilerin Sandığı")
e("Chest of the Black Feather", "Kara Tüy Sandığı")
e("Chest of the Raven Claw", "Kuzgun Pençesi Sandığı")
e("Chest of the Sky", "Gökyüzü Sandığı")
e("Circle of Binding", "Bağlama Çemberi")
e("Circle of Imprisonment", "Hapsetme Çemberi")
e("Civil War in the Plaguelands", "Plaguelands'te İç Savaş")
e("Clara's Fresh Apples", "Clara'nın Taze Elmaları")
e("Cleansed Night Dragon", "Arındırılmış Gece Ejderhası")
e("Cleansed Songflower", "Arındırılmış Şarkı Çiçeği")
e("Cleansed Whipper Root", "Arındırılmış Kırbaç Kökü")
e("Cleansed Windblossom", "Arındırılmış Rüzgâr Çiçeği")
e("Coldtooth Supplies", "Coldtooth Erzakları")
e("Command Tent", "Komuta Çadırı")
e("Compendium of the Fallen", "Düşenlerin Derlemesi")
e("Conspicuous Urn", "Göze Çarpan Vazo")
e("Control Console", "Kontrol Konsolu")
e("Copper Vein", "Bakır Damarı")
e("Core Fragment", "Çekirdek Parçası")
e("Corpse Laden Boat", "Ceset Dolu Tekne")
e("Corrupted Night Dragon", "Yozlaşmış Gece Ejderhası")
e("Corrupted Songflower", "Yozlaşmış Şarkı Çiçeği")
e("Corrupted Whipper Root", "Yozlaşmış Kırbaç Kökü")
e("Corrupted Windblossom", "Yozlaşmış Rüzgâr Çiçeği")
e("Cortello's Riddle", "Cortello'nun Bilmecesi")
e("Cortello's Treasure", "Cortello'nun Hazinesi")
e("Cozzle's Footlocker", "Cozzle'ın Eşya Sandığı")
e("Crate of Candles", "Mum Sandığı")
e("Crate of Elunite", "Elunit Sandığı")
e("Crate of Foodstuffs", "Erzak Sandığı")
e("Crate with Holes", "Delikli Sandık")
e("Crossroads' Supply Crates", "Crossroads Erzak Sandıkları")
e("Crumpled Map", "Buruşuk Harita")
e("Crusaders' Square Postbox", "Crusaders' Square Posta Kutusu")
e("Crystalline Tear", "Kristal Gözyaşı")
e("Dalaran Crate", "Dalaran Sandığı")
e("Damaged Chest", "Hasarlı Sandık")
e("Damaged Crate", "Hasarlı Kasa")
e("Dangerous!", "Tehlikeli!")
e("Dark Cleric Salem's Chest", "Kara Rahip Salem'in Sandığı")
e("Dark Coffer", "Karanlık Kasa")
e("Dark Iron Ale Mug", "Dark Iron Bira Kupası")
e("Dark Iron Deposit", "Kara Demir Yatağı")
e("Dark Iron Dwarf Corpse", "Dark Iron Cücesi Cesedi")
e("Dark Iron Keg Shotgun", "Dark Iron Fıçı Tüfeği")
e("Dark Iron Pillow", "Dark Iron Yastığı")
e("Dark Keeper Nameplate", "Kara Bekçi İsim Levhası")
e("Dark Keeper Portrait", "Kara Bekçi Portresi")
e("Darkstone Tablet", "Kara Taş Tableti")
e("Davil's Libram", "Davil'in Libramı")
e("Dead-tooth's Strongbox", "Dead-tooth'un Kasası")
e("Deadwood Cauldron", "Deadwood Kazanı")
e("Death Cap", "Ölüm Mantarı")
e("Decorated Headstone", "Süslü Mezar Taşı")
e("Defias Cannon", "Defias Topu")
e("Defias Gunpowder", "Defias Barutu")
e("Defias Strongbox", "Defias Kasası")
e("Demon Portal", "İblis Geçidi")
e("Denalan's Planter", "Denalan'ın Saksısı")
e("Dented Footlocker", "Göçük Eşya Sandığı")
e("Dinosaur Bone", "Dinozor Kemiği")
e("Dirt-stained Map", "Toprak Lekeli Harita")
e("Doan's Strongbox", "Doan'ın Kasası")
e("Document Chest", "Belge Sandığı")
e("Doom Weed", "Kıyamet Otu")
e("Doomrigger's Coffer", "Doomrigger'ın Kasası")
e("Doomsday Candle", "Kıyamet Mumu")
e("Door Lever", "Kapı Kolu")
e("Draconic for Dummies", "Aptallar İçin Ejderce")
e("Draenethyst Crystals", "Draenethyst Kristalleri")
e("Dragonmaw Catapult", "Dragonmaw Mancınığı")
e("Drakkisath's Brand", "Drakkisath'ın Damgası")
e("Dreamfoil", "Rüya Yaprağı")
e("Dredan's Alchemy Tools", "Dredan'ın Simya Aletleri")
e("Dredan's Forge", "Dredan'ın Ocağı")
e("Drek'Thar's Scrolls", "Drek'Thar'ın Parşömenleri")
e("Drizzlik's Emporium", "Drizzlik'in Dükkânı")
e("Druids' Cache", "Druidlerin Zulası")
e("Duskwood Chest", "Duskwood Sandığı")
e("Dusty Reliquary", "Tozlu Emanet Sandığı")
e("Dusty Rug", "Tozlu Kilim")
e("Dusty Shelf", "Tozlu Raf")
e("Dusty Spellbooks", "Tozlu Büyü Kitapları")
e("Earthroot", "Toprak Kökü")
e("Eastern Crystal Pylon", "Doğu Kristal Pilonu")
e("Ebenezer Rustlocke's Corpse", "Ebenezer Rustlocke'un Cesedi")
e("Egg of Onyxia", "Onyxia'nın Yumurtası")
e("Egg-O-Matic", "Yumurta-O-Matik")
e("Elders' Square Postbox", "Elders' Square Posta Kutusu")
e("Eliza's Grave Dirt", "Eliza'nın Mezar Toprağı")
e("Eliza's Tombstone", "Eliza'nın Mezar Taşı")
e("Elune's Tear", "Elune'un Gözyaşı")
e("Empires' Fall", "İmparatorlukların Çöküşü")
e("Enchanted Scarlet Thread", "Efsunlu Kızıl İplik")
e("Equinex Monolith", "Equinex Monoliti")
e("Equipment Boxes", "Ekipman Kutuları")
e("Essence Font", "Öz Pınarı")
e("Etched Note", "Kazınmış Not")
e("Eternal Flame", "Ebedi Alev")
e("Evil God Summoning Circle", "Kötü Tanrı Çağırma Çemberi")
e("Evoroot", "Evo Kökü")
e("Excavation Supply Crate", "Kazı Erzak Sandığı")
e("Exile of the High Elves", "Yüce Elflerin Sürgünü")
e("Explosive Charge", "Patlayıcı Düzenek")
e("Fadeleaf", "Solgun Yaprak")
e("Fall of Gurubashi", "Gurubashi'nin Çöküşü")
e("Farm Banner", "Çiftlik Sancağı")
e("Father Flame", "Ata Alev")
e("Fathom Stone", "Kulaç Taşı")
e("Faustin's Alchemy Set", "Faustin'in Simya Takımı")
e("Feast Boar", "Ziyafet Domuzu")
e("Feast Fish", "Ziyafet Balığı")
e("Feast Fruit", "Ziyafet Meyvesi")
e("Feast Goblet", "Ziyafet Kadehi")
e("Featherbeard's Journal", "Featherbeard'ın Günlüğü")
e("Featherbeard's Remains", "Featherbeard'ın Kalıntıları")
e("Fel Cone", "Fel Kozalağı")
e("Felix's Box", "Felix'in Kutusu")
e("Felix's Bucket of Bolts", "Felix'in Cıvata Kovası")
e("Felix's Chest", "Felix'in Sandığı")
e("Felvine Shard", "Felvine Parçası")
e("Fengus's Chest", "Fengus'un Sandığı")
e("Feralas: A History", "Feralas: Bir Tarih")
e("Festival Lane Postbox", "Festival Lane Posta Kutusu")
e("Festive Gift", "Bayram Hediyesi")
e("Festive Keg", "Bayram Fıçısı")
e("Festive Mug", "Bayram Kupası")
e("Fifth Mosh'aru Tablet", "Beşinci Mosh'aru Tableti")
e("Fire of Aku'mai", "Aku'mai Ateşi")
e("Fire of Elune", "Elune Ateşi")
e("Firebloom", "Ateş Çiçeği")
e("Firecrackers", "Kestane Fişekleri")
e("Firework, Show, Type 1 Blue", "Havai Fişek, Gösteri, Tip 1 Mavi")
e("Firework, Show, Type 1 Blue BIG", "Havai Fişek, Gösteri, Tip 1 Mavi BÜYÜK")
e("Firework, Show, Type 1 Green", "Havai Fişek, Gösteri, Tip 1 Yeşil")
e("Firework, Show, Type 1 Green BIG", "Havai Fişek, Gösteri, Tip 1 Yeşil BÜYÜK")
e("Firework, Show, Type 1 Purple BIG", "Havai Fişek, Gösteri, Tip 1 Mor BÜYÜK")
e("Firework, Show, Type 1 Red", "Havai Fişek, Gösteri, Tip 1 Kırmızı")
e("Firework, Show, Type 1 White", "Havai Fişek, Gösteri, Tip 1 Beyaz")
e("Firework, Show, Type 1 White BIG", "Havai Fişek, Gösteri, Tip 1 Beyaz BÜYÜK")
e("Firework, Show, Type 1 Yellow", "Havai Fişek, Gösteri, Tip 1 Sarı")
e("Firework, Show, Type 1 Yellow BIG", "Havai Fişek, Gösteri, Tip 1 Sarı BÜYÜK")
e("Firework, Show, Type 1,  Red BIG", "Havai Fişek, Gösteri, Tip 1, Kırmızı BÜYÜK")
e("Firework, Show, Type 2 Blue", "Havai Fişek, Gösteri, Tip 2 Mavi")
e("Firework, Show, Type 2 Blue BIG", "Havai Fişek, Gösteri, Tip 2 Mavi BÜYÜK")
e("Firework, Show, Type 2 Green", "Havai Fişek, Gösteri, Tip 2 Yeşil")
e("Firework, Show, Type 2 Green BIG", "Havai Fişek, Gösteri, Tip 2 Yeşil BÜYÜK")
e("Firework, Show, Type 2 Purple", "Havai Fişek, Gösteri, Tip 2 Mor")
e("Firework, Show, Type 2 Purple BIG", "Havai Fişek, Gösteri, Tip 2 Mor BÜYÜK")
e("Firework, Show, Type 2 Red", "Havai Fişek, Gösteri, Tip 2 Kırmızı")
e("Firework, Show, Type 2 White", "Havai Fişek, Gösteri, Tip 2 Beyaz")
e("Firework, Show, Type 2 White BIG", "Havai Fişek, Gösteri, Tip 2 Beyaz BÜYÜK")
e("Firework, Show, Type 2 Yellow", "Havai Fişek, Gösteri, Tip 2 Sarı")
e("Firework, Show, Type 2 Yellow BIG", "Havai Fişek, Gösteri, Tip 2 Sarı BÜYÜK")
e("Firework, Show, Type 2,  Red BIG", "Havai Fişek, Gösteri, Tip 2, Kırmızı BÜYÜK")
e("First Witherbark Cage", "Birinci Witherbark Kafesi")
e("Fissure Plant", "Yarık Bitkisi")
e("Flagongut's Fossil", "Flagongut'ın Fosili")
e("Flame of Ashenvale", "Ashenvale Alevi")
e("Flame of Azel", "Azel Alevi")
e("Flame of Azshara", "Azshara Alevi")
e("Flame of Blackrock Spire", "Blackrock Spire Alevi")
e("Flame of Byltan", "Byltan Alevi")
e("Flame of Darkshore", "Darkshore Alevi")
e("Flame of Darnassus", "Darnassus Alevi")
e("Flame of Dire Maul", "Dire Maul Alevi")
e("Flame of Hillsbrad", "Hillsbrad Alevi")
e("Flame of Imbel", "Imbel Alevi")
e("Flame of Ironforge", "Ironforge Alevi")
e("Flame of Lahassa", "Lahassa Alevi")
e("Flame of Orgrimmar", "Orgrimmar Alevi")
e("Flame of Samha", "Samha Alevi")
e("Flame of Searing Gorge", "Searing Gorge Alevi")
e("Flame of Silithus", "Silithus Alevi")
e("Flame of Silverpine", "Silverpine Alevi")
e("Flame of Stonetalon", "Stonetalon Alevi")
e("Flame of Stormwind", "Stormwind Alevi")
e("Flame of Stratholme", "Stratholme Alevi")
e("Flame of Thunder Bluff", "Thunder Bluff Alevi")
e("Flame of Un'Goro", "Un'Goro Alevi")
e("Flame of Uzel", "Uzel Alevi")
e("Flame of Veraz", "Veraz Alevi")
e("Flame of Westfall", "Westfall Alevi")
e("Flame of Winterspring", "Winterspring Alevi")
e("Flame of the Barrens", "Barrens Alevi")
e("Flame of the Blasted Lands", "Blasted Lands Alevi")
e("Flame of the Hinterlands", "Hinterlands Alevi")
e("Flame of the Plaguelands", "Plaguelands Alevi")
e("Flame of the Scholomance", "Scholomance Alevi")
e("Flame of the Undercity", "Undercity Alevi")
e("Flame of the Wetlands", "Wetlands Alevi")
e("Flawed Power Stone", "Kusurlu Güç Taşı")
e("Flawed Power Stones", "Kusurlu Güç Taşları")
e("Food Crate", "Yiyecek Sandığı")
e("Forestlord and the first Druids", "Orman Lordu ve İlk Druidler")
e("Fossilized Egg", "Fosilleşmiş Yumurta")
e("Four Horsemen Chest", "Dört Atlı Sandığı")
e("Fourth Mosh'aru Tablet", "Dördüncü Mosh'aru Tableti")
e("Fragile - Do Not Drop", "Kırılır - Düşürmeyin")
e("Fragrant Cauldron", "Mis Kokulu Kazan")
e("Fras Siabi's Postbox", "Fras Siabi'nin Posta Kutusu")
e("Fresh Threshadon Carcass", "Taze Threshadon Leşi")
e("Freshly Dug Dirt", "Yeni Kazılmış Toprak")
e("Frostmaul Shards", "Frostmaul Parçaları")
e("Frostwhisper's Embalming Fluid", "Frostwhisper'ın Mumyalama Sıvısı")
e("Frostwolf Banner", "Frostwolf Sancağı")
e("Frozen Rune", "Donmuş Rün")
e("Fuel Control Valve", "Yakıt Kontrol Vanası")
e("Full Jug", "Dolu Testi")
e("Furlbrow's Wardrobe", "Furlbrow'un Gardırobu")
e("Gaea Dirt Mound", "Gaea Toprak Yığını")
e("Gaea Seed", "Gaea Tohumu")
e("Gaily Wrapped Present", "Neşeyle Paketlenmiş Hediye")
e("Galen's Strongbox", "Galen'in Kasası")
e("Gallywix's Lockbox", "Gallywix'in Kilitli Kutusu")
e("Garrett Family Chest", "Garrett Ailesi Sandığı")
e("Gatekeeper's Hold", "Kapı Bekçisinin Kalesi")
e("General Twinbraid's Strongbox", "General Twinbraid'in Kasası")
e("Gently Shaken Gift", "Hafifçe Sallanmış Hediye")
e("Ghost Mushroom", "Hayalet Mantarı")
e("Giant Clam", "Dev Midye")
e("Giant Softshell Clam", "Dev Yumuşak Kabuklu Midye")
e("Gizmorium Shipping Crate", "Gizmorium Nakliye Sandığı")
e("Glinting Mud", "Parıldayan Çamur")
e("Gloom Weed", "Kasvet Otu")
e("Glyphed Crystal Prism", "Glifli Kristal Prizma")
e("Gnome Face 01", "Gnom Yüzü 01")
e("Gnome Face 02", "Gnom Yüzü 02")
e("Gnome Face 03", "Gnom Yüzü 03")
e("Gnome Face 04", "Gnom Yüzü 04")
e("Gnome Face 05", "Gnom Yüzü 05")
e("Gnome Face 06", "Gnom Yüzü 06")
e("Gnomish Toolbox", "Gnom Alet Kutusu")
e("Gold Vein", "Altın Damarı")
e("Golden Sansam", "Altın Sansam")
e("Goldthorn", "Altın Diken")
e("Gong of Bethekk", "Bethekk Gongu")
e("Gong of Zul'Farrak", "Zul'Farrak Gongu")
e("Goodsteel Ledger", "Goodsteel Defteri")
e("Gordok Tribute", "Gordok Haracı")
e("Gordunni Scroll", "Gordunni Parşömeni")
e("Grand Admiral Daelin Proudmoore", "Büyük Amiral Daelin Proudmoore")
e("Grave Moss", "Mezar Yosunu")
e("Graznab's Machine", "Graznab'ın Makinesi")
e("Greater Wind Stone", "Büyük Rüzgâr Taşı")
e("Green Power Crystal", "Yeşil Güç Kristali")
e("Gri'lek the Wanderer", "Gezgin Gri'lek")
e("Gri'lek, with the Iron Blood", "Demir Kanlı Gri'lek")
e("Grim Guzzler Boar", "Grim Guzzler Domuzu")
e("Gromsblood", "Grom'un Kanı")
e("Gryphon Egg", "Grifon Yumurtası")
e("Guarded Thunder Ale Barrel", "Korunan Thunder Ale Fıçısı")
e("Gunther's Books", "Gunther'ın Kitapları")
e("Half-Buried Bottle", "Yarı Gömülü Şişe")
e("Half-buried Barrel", "Yarı Gömülü Fıçı")
e("Hand of Iruxos Crystal", "Iruxos'un Eli Kristali")
e("Hardpacked Snowdrift", "Sıkışmış Kar Yığını")
e("Harpy Foodstuffs", "Harpi Erzakı")
e("Harvest Boar", "Hasat Domuzu")
e("Harvest Fish", "Hasat Balığı")
e("Harvest Fruit", "Hasat Meyvesi")
e("Harvest Nectar", "Hasat Nektarı")
e("Hatred of the Centaur", "Sentorların Nefreti")
e("Hazza'rah, the Dreamweaver", "Rüya Dokuyucu Hazza'rah")
e("Heart of the Mountain", "Dağın Kalbi")
e("Heartswood", "Yürek Odunu")
e("Helcular's Grave", "Helcular'ın Mezarı")
e("Henrig Lonebrow's Journal", "Henrig Lonebrow'un Günlüğü")
e("Here Lies King Terenas Menethil II", "Burada Kral Terenas Menethil II Yatıyor")
e("Hidden Shrine", "Gizli Tapınak")
e("Hidden Strongbox", "Gizli Kasa")
e("Highborne Astrolabe", "Highborne Usturlabı")
e("Highborne Relic Fragment", "Highborne Kalıntı Parçası")
e("Highperch Wyvern Egg", "Highperch Wyvern Yumurtası")
e("Highvale Notes", "Highvale Notları")
e("Highvale Records", "Highvale Kayıtları")
e("Highvale Report", "Highvale Raporu")
e("Hillsbrad Proclamation", "Hillsbrad Bildirisi")
e("Hillsbrad Town Registry", "Hillsbrad Kasaba Kütüğü")
e("Hippogryph Egg", "Hipogrif Yumurtası")
e("Hive'Ashi Glyphed Crystal", "Hive'Ashi Glifli Kristali")
e("Hive'Ashi Pod", "Hive'Ashi Kozası")
e("Hive'Regal Glyphed Crystal", "Hive'Regal Glifli Kristali")
e("Hive'Zora Glyphed Crystal", "Hive'Zora Glifli Kristali")
e("Hoard of the Black Dragonflight", "Kara Ejderha Soyunun Hazinesi")
e("Holiday Snow", "Bayram Karı")
e("Holly Preserver", "Çobanpüskülü Koruyucu")
e("Horde Banner", "Horde Sancağı")
e("Horde Catapult", "Horde Mancınığı")
e("Horde Chest", "Horde Sandığı")
e("Horde Military Ranks", "Horde Askeri Rütbeleri")
e("Horde Supply Crate", "Horde Erzak Sandığı")
e("Horgus' Skull", "Horgus'un Kafatası")
e("Human Remains", "İnsan Kalıntıları")
e("Hyacinth Mushroom", "Sümbül Mantarı")
e("Hydraxis' Coffer", "Hydraxis'in Kasası")
e("Icebellow Furnace", "Icebellow Fırını")
e("Icecap", "Buz Başlığı")
e("Icecrown and the Frozen Throne", "Icecrown ve Donmuş Taht")
e("Idol of Hakkar", "Hakkar Putu")
e("Imprisoned Darkspear", "Hapsedilmiş Darkspear")
e("In Loving Memory", "Sevgiyle Anıyoruz")
e("Incantation of Celebras", "Celebras Efsunu")
e("Incendia Agave", "Incendia Agavı")
e("Inconspicuous Crate", "Göze Çarpmayan Sandık")
e("Inconspicuous Documents", "Göze Çarpmayan Belgeler")
e("Inconspicuous Landmark", "Göze Çarpmayan İşaret")
e("Indurium Mineral Vein", "İndurium Maden Damarı")
e("Intrepid's Locked Strongbox", "Intrepid'in Kilitli Kasası")
e("Iridescent Shards", "Yanardöner Parçalar")
e("Iron Coral", "Demir Mercan")
e("Iron Deposit", "Demir Yatağı")
e("Ironband's Strongbox", "Ironband'ın Kasası")
e("Irondeep Supplies", "Irondeep Erzakı")
e("Ironforge - the Awakening of the Dwarves", "Ironforge - Cücelerin Uyanışı")
e("Izzy's Holdings", "Izzy'nin Mülkleri")
e("James' Journal", "James'in Günlüğü")
e("Janice's Parcel", "Janice'in Paketi")
e("Jaron's Supplies", "Jaron'un Erzakı")
e("Jaron's Wagon", "Jaron'un Arabası")
e("Jordan's Hammer", "Jordan'ın Çekici")
e("Joseph Redpath's Monument", "Joseph Redpath'in Anıtı")
e("Joseph's Chest", "Joseph'in Sandığı")
e("Ju-Ju Heap", "Ju-Ju Yığını")
e("Kaldorei Tome of Summoning", "Kaldorei Çağırma Kitabı")
e("Karnitol's Chest", "Karnitol'un Sandığı")
e("Keepsake of Remembrance", "Anma Hatırası")
e("Keg", "Fıçı")
e("Keg of Shindigger Stout", "Shindigger Stout Fıçısı")
e("Kel'Thuzad Trigger", "Kel'Thuzad Tetikleyicisi")
e("Kel'Thuzad and the Forming of the Scourge", "Kel'Thuzad ve Scourge'un Oluşumu")
e("Kerlonian's Chest", "Kerlonian'ın Sandığı")
e("Keystone", "Kilit Taşı")
e("Khadgar's Whisker", "Khadgar'ın Bıyığı")
e("Kil'jaeden and the Shadow Pact", "Kil'jaeden ve Gölge Paktı")
e("Kim'jael's Equipment", "Kim'jael'in Ekipmanı")
e("King Llane I of the House of Wrynn", "Wrynn Hanedanı'ndan Kral Llane I")
e("King's Square Postbox", "King's Square Posta Kutusu")
e("Kingsblood", "Kral Kanı")
e("Knot Thimblejack's Cache", "Knot Thimblejack'in Zulası")
e("Kodo Bones", "Kodo Kemikleri")
e("Kolkar's Booty", "Kolkar Ganimeti")
e("Kolkars' Booty", "Kolkarların Ganimeti")
e("Krom Stoutarm's Chest", "Krom Stoutarm'ın Sandığı")
e("Kurzen Supplies", "Kurzen Erzakı")
e("Laden Mushroom", "Yüklü Mantar")
e("Lard's Picnic Basket", "Lard'ın Piknik Sepeti")
e("Large Battered Chest", "Büyük Hırpalanmış Sandık")
e("Large Leather Backpacks", "Büyük Deri Sırt Çantaları")
e("Large Mithril Bound Chest", "Büyük Mithril Kaplı Sandık")
e("Large Scarab Coffer", "Büyük Skarabe Sandığı")
e("Large Solid Chest", "Büyük Sağlam Sandık")
e("Large Termite Mound", "Büyük Termit Tümseği")
e("Legends of the Earth", "Toprağın Efsaneleri")
e("Lesser Wind Stone", "Küçük Rüzgâr Taşı")
e("Lethargy of the Orcs", "Orkların Uyuşukluğu")
e("Lever", "Kol")
e("Liferoot", "Hayat Kökü")
e("Lillith's Dinner Table", "Lillith'in Yemek Masası")
e("Locked Cabinet", "Kilitli Dolap")
e("Locked Chest", "Kilitli Sandık")
e("Locked ball and chain", "Kilitli Pranga")
e("Loose Dirt", "Gevşek Toprak")
e("Loose Dirt Mound", "Gevşek Toprak Yığını")
e("Loose Soil", "Yumuşak Toprak")
e("Lordaeron Shrine", "Lordaeron Tapınağı")
e("Lotharian Lotus", "Lotharian Lotusu")
e("Lucius's Lockbox", "Lucius'un Kilitli Kutusu")
e("Lumber Mill Banner", "Kereste Fabrikası Sancağı")
e("Lumber Pile", "Kereste Yığını")
e("Lunar Fungal Bloom", "Ay Mantarı Çiçeği")
e("MacGrann's Meat Locker", "MacGrann'ın Et Dolabı")
e("Mageroyal", "Büyücü Kraliyeti")
e("Maiden's Folly Charts", "Maiden's Folly Haritaları")
e("Maiden's Folly Log", "Maiden's Folly Seyir Defteri")
e("Main Control Valve", "Ana Kontrol Vanası")
e("Malem Chest", "Malem Sandığı")
e("Malor's Strongbox", "Malor'un Kasası")
e("Malyfous's Catalogue", "Malyfous'un Kataloğu")
e("Mangled Human Remains", "Parçalanmış İnsan Kalıntıları")
e("Market Row Postbox", "Market Row Posta Kutusu")
e("Marla's Grave", "Marla'nın Mezarı")
e("Marshal Haggard's Chest", "Marshal Haggard'ın Sandığı")
e("Marvon's Chest", "Marvon'un Sandığı")
e("Mathystra Relic", "Mathystra Kalıntısı")
e("Matrix Punchograph 3005-A", "Matris Delgigraf 3005-A")
e("Matrix Punchograph 3005-B", "Matris Delgigraf 3005-B")
e("Matrix Punchograph 3005-C", "Matris Delgigraf 3005-C")
e("Matrix Punchograph 3005-D", "Matris Delgigraf 3005-D")
e("Mausoleum Trigger", "Anıt Mezar Tetikleyicisi")
e("Meeting", "Toplantı")
e("Meeting Stone", "Buluşma Taşı")
e("Memorial to Sully Balloo", "Sully Balloo Anıtı")
e("Menethil's Gift", "Menethil'in Armağanı")
e("Military Ranks of the Horde & Alliance", "Horde ve Alliance'ın Askerî Rütbeleri")
e("Milly's Harvest", "Milly'nin Hasadı")
e("Mine Banner", "Maden Sancağı")
e("Miners' League Crates", "Madenciler Birliği Sandıkları")
e("Missing: Corporal Keeshan", "Kayıp: Onbaşı Keeshan")
e("Missing: Kyle", "Kayıp: Kyle")
e("Mist Veil's Lockbox", "Mist Veil'in Kilitli Kutusu")
e("Mists of Dawn", "Şafak Sisleri")
e("Mithril Deposit", "Mithril Yatağı")
e("Mok'Morokk's Grog", "Mok'Morokk'un Grogu")
e("Mok'Morokk's Snuff", "Mok'Morokk'un Enfiyesi")
e("Mok'Morokk's Strongbox", "Mok'Morokk'un Kasası")
e("Monument of Franclorn Forgewright", "Franclorn Forgewright Anıtı")
e("Monument to Grom Hellscream", "Grom Hellscream Anıtı")
e("Moon Over the Vale", "Vadinin Üzerindeki Ay")
e("Moonpetal Lily", "Ay Yapraklı Zambak")
e("Moontouched Feather", "Ay Dokunuşlu Tüy")
e("Mossy Footlocker", "Yosunlu Eşya Sandığı")
e("Mound of Dirt", "Toprak Yığını")
e("Mound of loose dirt", "Gevşek Toprak Yığını")
e("Mount Hyjal and Illidan's Gift", "Mount Hyjal ve Illidan'ın Armağanı")
e("Mountain Silversage", "Dağ Gümüş Adaçayı")
e("Mouthpiece Mount", "Ağızlık Yuvası")
e("Mrs. Dalson's Diary", "Bayan Dalson'ın Günlüğü")
e("Muddy Churning Waters", "Çalkantılı Çamurlu Sular")
e("Musquash Root", "Musquash Kökü")
e("Musty Scroll", "Küflü Parşömen")
e("Mysterious Deadmines Chest", "Gizemli Deadmines Sandığı")
e("Mysterious Eastvale Haystack", "Gizemli Eastvale Saman Yığını")
e("Mysterious Red Crystal", "Gizemli Kızıl Kristal")
e("Mysterious Tree Stump", "Gizemli Ağaç Kütüğü")
e("Mysterious Wailing Caverns Chest", "Gizemli Wailing Caverns Sandığı")
e("Mythology of the Titans", "Titanların Mitolojisi")
e("Naga Brazier", "Naga Mangalı")
e("Naxxramas Portal", "Naxxramas Geçidi")
e("Necropolis", "Nekropolis")
e("Necropolis (scale 1.5)", "Nekropolis (ölçek 1.5)")
e("Necropolis (scale 2.0)", "Nekropolis (ölçek 2.0)")
e("Necropolis (scale 2.5)", "Nekropolis (ölçek 2.5)")
e("Necropolis (scale 3.5)", "Nekropolis (ölçek 3.5)")
e("Noggle's Satchel", "Noggle'ın Heybesi")
e("Northern Crystal Pylon", "Kuzey Kristal Pilonu")
e("Northridge Lumber Mill Crate", "Northridge Kereste Fabrikası Sandığı")
e("Ogre Coup Summoning Circle", "Ogre Darbesi Çağırma Çemberi")
e("Ogre Tannin Basket", "Ogre Tanen Sepeti")
e("Old Footlocker", "Eski Eşya Sandığı")
e("Old Hatreds - The Colonization of Kalimdor", "Eski Nefretler - Kalimdor'un Kolonileştirilmesi")
e("Old Jug", "Eski Testi")
e("Old Lion Statue", "Eski Aslan Heykeli")
e("Old Treasure Chest", "Eski Hazine Sandığı")
e("Open To Pass Your Rite.", "Ayinini Geçmek İçin Aç.")
e("Orb of Command", "Komuta Küresi")
e("Orb of Domination", "Hükmetme Küresi")
e("Orman of Stromgarde", "Stromgardeli Orman")
e("Ornate Chest", "Süslü Sandık")
e("Outhouse", "Tuvalet Kulübesi")
e("Pamela's Doll's Head", "Pamela'nın Bebeğinin Kafası")
e("Pamela's Doll's Left Side", "Pamela'nın Bebeğinin Sol Yarısı")
e("Pamela's Doll's Right Side", "Pamela'nın Bebeğinin Sağ Yarısı")
e("Parts Crate", "Parça Sandığı")
e("Patch of Elemental Water", "Elementel Su Birikintisi")
e("Peacebloom", "Barış Çiçeği")
e("Perrine's Chest", "Perrine'in Sandığı")
e("Pile of Bones", "Kemik Yığını")
e("Pile of Skulls", "Kafatası Yığını")
e("Pillar of Amethyst", "Ametist Sütun")
e("Pillar of Diamond", "Elmas Sütun")
e("Pillar of Opal", "Opal Sütun")
e("Pitted Iron Chest", "Oyuklu Demir Sandık")
e("Plaguebloom", "Veba Çiçeği")
e("Plant Bundle", "Bitki Demeti")
e("Postbox Parcel", "Posta Kutusu Paketi")
e("Practice Lockbox", "Alıştırma Kilitli Kutusu")
e("Premium Siabi Tobacco", "Kaliteli Siabi Tütünü")
e("Pteradon Skeleton", "Pteradon İskeleti")
e("Pupellyverbos Port", "Pupellyverbos Porto Şarabı")
e("Purple Lotus", "Mor Lotus")
e("Quel'Thalas Registry", "Quel'Thalas Sicili")
e("Rackmore's Chest", "Rackmore'un Sandığı")
e("Rackmore's Log", "Rackmore'un Seyir Defteri")
e("Ranger Captain Alleria Windrunner", "Korucu Kaptan Alleria Windrunner")
e("Recombobulator", "Rekombobülatör")
e("Red Power Crystal", "Kırmızı Güç Kristali")
e("Red Raptor Nest", "Kırmızı Raptor Yuvası")
e("Red Rocket", "Kırmızı Roket")
e("Red Soulgem", "Kızıl Ruh Taşı")
e("Redpath's Shield", "Redpath'in Kalkanı")
e("Regulator Valve", "Düzenleyici Vana")
e("Relic Coffer", "Kalıntı Sandığı")
e("Remains of Eva Sarkhoff", "Eva Sarkhoff'un Kalıntıları")
e("Remains of Lucien Sarkhoff", "Lucien Sarkhoff'un Kalıntıları")
e("Renataki, of the Thousand Blades", "Bin Kılıçlı Renataki")
e("Research Equipment", "Araştırma Ekipmanı")
e("Resonite Cask", "Resonit Fıçısı")
e("Resonite Crystal", "Resonit Kristali")
e("Ribbon Pole", "Kurdele Direği")
e("Rich Thorium Vein", "Zengin Toryum Damarı")
e("Rin'ji's Secret", "Rin'ji'nin Sırrı")
e("Ripe Pumpkin", "Olgun Balkabağı")
e("Rise of the Blood Elves", "Kan Elflerinin Yükselişi")
e("Rise of the Horde", "Horde'un Yükselişi")
e("Ritual Candle", "Ayin Mumu")
e("Rituals of Power", "Güç Ayinleri")
e("Rizzle's Guarded Plans", "Rizzle'ın Korunan Planları")
e("Rizzle's Unguarded Plans", "Rizzle'ın Korumasız Planları")
e("Roc Talon", "Roc Pençesi")
e("Rock of Durotan", "Durotan'ın Kayası")
e("Roland's Mana Gem", "Roland'ın Mana Taşı")
e("Rolf's corpse", "Rolf'un Cesedi")
e("Room 1 Rune", "Oda 1 Rünü")
e("Room 2 Rune", "Oda 2 Rünü")
e("Room 3 Rune", "Oda 3 Rünü")
e("Room 4 Rune", "Oda 4 Rünü")
e("Room 5 Rune", "Oda 5 Rünü")
e("Room 6 Rune", "Oda 6 Rünü")
e("Room 7 Rune", "Oda 7 Rünü")
e("Roughshod Pike", "Roughshod Mızrağı")
e("Ruined Lifeboat", "Harap Cankurtaran Sandalı")
e("Rune of Beth'Amara", "Beth'Amara Rünü")
e("Rune of Blaz", "Blaz Rünü")
e("Rune of Jin'yael", "Jin'yael Rünü")
e("Rune of Koro", "Koro Rünü")
e("Rune of Kress", "Kress Rünü")
e("Rune of Markri", "Markri Rünü")
e("Rune of Mazj", "Mazj Rünü")
e("Rune of Mazthoril", "Mazthoril Rünü")
e("Rune of Mohn", "Mohn Rünü")
e("Rune of Sael'hai", "Sael'hai Rünü")
e("Rune of Theri", "Theri Rünü")
e("Rune of Zeth", "Zeth Rünü")
e("Runed Pedestal", "Rünlü Kaide")
e("Sack of Barley", "Arpa Çuvalı")
e("Sack of Corn", "Mısır Çuvalı")
e("Sack of Meat", "Et Çuvalı")
e("Sack of Oats", "Yulaf Çuvalı")
e("Sack of Rye", "Çavdar Çuvalı")
e("Sacred Fire of Life", "Kutsal Hayat Ateşi")
e("Sacred Highborne Writings", "Kutsal Highborne Yazıtları")
e("Sagefish School", "Adaçayı Balığı Sürüsü")
e("Sandy Cookbook", "Kumlu Yemek Kitabı")
e("Sapphire of Aku'Mai", "Aku'Mai Safiri")
e("Sargeras and the Betrayal", "Sargeras ve İhanet")
e("Saurial Egg", "Saurial Yumurtası")
e("Scaber Stalk", "Scaber Sapı")
e("Scarab Coffer", "Skarabe Sandığı")
e("Scarlet Archive", "Scarlet Arşivi")
e("Scarlet Cannon", "Scarlet Topu")
e("Scarlet Footlocker", "Scarlet Eşya Sandığı")
e("Scattered Crate", "Dağınık Sandık")
e("Schematic: Field Repair Bot 74A", "Şema: Saha Tamir Robotu 74A")
e("School of Deviate Fish", "Sapkın Balık Sürüsü")
e("School of Fish", "Balık Sürüsü")
e("School of Tastyfish", "Lezzetli Balık Sürüsü")
e("Scourge Cauldron", "Scourge Kazanı")
e("Scourge Data", "Scourge Verileri")
e("Scrimshank's Surveying Gear", "Scrimshank'ın Ölçüm Teçhizatı")
e("Seal of the Earth", "Toprağın Mührü")
e("Sealed Barrel", "Mühürlü Varil")
e("Sealed Crate", "Mühürlü Sandık")
e("Sealed Supply Crate", "Mühürlü Erzak Sandığı")
e("Second Witherbark Cage", "İkinci Witherbark Kafesi")
e("Secret Plans: Fiery Flux", "Gizli Planlar: Ateşli Eritken")
e("Secret Safe", "Gizli Kasa")
e("Sentry Brazier", "Nöbetçi Mangalı")
e("Serpent Statue", "Yılan Heykeli")
e("Serpentbloom", "Yılan Çiçeği")
e("Servant of the Hand Summoning Circle", "El'in Hizmetkârı Çağırma Çemberi")
e("Sha'ni Proudtusk's Remains", "Sha'ni Proudtusk'ın Kalıntıları")
e("Shadowforge Brazier", "Shadowforge Mangalı")
e("Shadowforge Cache", "Shadowforge Zulası")
e("Shallow Grave", "Sığ Mezar")
e("Shaman Shrine", "Şaman Tapınağı")
e("Shards of Myzrael", "Myzrael'in Parçaları")
e("Sharpbeak's Cage", "Sharpbeak'in Kafesi")
e("Shattered Sword of Marduk", "Marduk'un Parçalanmış Kılıcı")
e("Shay's Chest", "Shay'in Sandığı")
e("Shimmerweed Basket", "Parıltı Otu Sepeti")
e("Shipment of Iron", "Demir Sevkiyatı")
e("Shrine of Gelihast", "Gelihast Tapınağı")
e("Shrine of Sha'gri", "Sha'gri Tapınağı")
e("Signal Torch", "İşaret Meşalesi")
e("Silithid Mound", "Silithid Tümseği")
e("Silithyst Geyser", "Silithyst Gayzeri")
e("Silver Dawning's Lockbox", "Silver Dawning'in Kilitli Kutusu")
e("Silver Vein", "Gümüş Damarı")
e("Silverleaf", "Gümüş Yaprak")
e("Silverwing Flag", "Silverwing Bayrağı")
e("Singed Letter", "Kavrulmuş Mektup")
e("Sixth Mosh'aru Tablet", "Altıncı Mosh'aru Tableti")
e("Skeletal Remains of Kariel Winthalus", "Kariel Winthalus'un İskelet Kalıntıları")
e("Skeletal Sea Turtle", "İskelet Deniz Kaplumbağası")
e("Slagtree's Lost Tools", "Slagtree'nin Kayıp Aletleri")
e("Sleepers' Cache", "Uyuyanların Zulası")
e("Small Lockbox", "Küçük Kilitli Kutu")
e("Small Thorium Vein", "Küçük Toryum Damarı")
e("Snowfall Banner", "Snowfall Sancağı")
e("Snufflenose Command Sticks", "Snufflenose Komuta Çubukları")
e("Snufflenose Owner's Manual", "Snufflenose Kullanım Kılavuzu")
e("Soft Dirt Mound", "Yumuşak Toprak Yığını")
e("Solarsal Gazebo", "Solarsal Çardağı")
e("Solid Chest", "Sağlam Sandık")
e("Sorrow of the Earthmother", "Toprak Ana'nın Kederi")
e("Spectral Chalice", "Hayaletimsi Kadeh")
e("Spectral Lockbox", "Hayaletimsi Kilitli Kutu")
e("Spider Egg", "Örümcek Yumurtası")
e("Spirit of Silverpine Charts", "Spirit of Silverpine Haritaları")
e("Spirit of Silverpine Log", "Spirit of Silverpine Seyir Defteri")
e("Spool of Light Chartreuse Silk Thread", "Açık Fıstık Yeşili İpek İplik Makarası")
e("Sprouted Frond", "Filizlenmiş Yaprak")
e("Stable Banner", "Ahır Sancağı")
e("Stanley's Dish", "Stanley'nin Tabağı")
e("Stardust Covered Bush", "Yıldız Tozu Kaplı Çalı")
e("Stolen Books", "Çalıntı Kitaplar")
e("Stolen Cargo", "Çalıntı Kargo")
e("Stolen Chest", "Çalıntı Sandık")
e("Stolen Iron Chest", "Çalıntı Demir Sandık")
e("Stolen Silver", "Çalıntı Gümüş")
e("Stolen Supply Sack", "Çalıntı Erzak Çuvalı")
e("Stone of Binding", "Bağlama Taşı")
e("Stone of East Binding", "Doğu Bağlama Taşı")
e("Stone of Inner Binding", "İç Bağlama Taşı")
e("Stone of Outer Binding", "Dış Bağlama Taşı")
e("Stone of Remembrance", "Anma Taşı")
e("Stone of West Binding", "Batı Bağlama Taşı")
e("Storage Chest", "Depo Sandığı")
e("Stormpike Banner", "Stormpike Sancağı")
e("Strange Fronded Plant", "Tuhaf Yapraklı Bitki")
e("Strange Fruited Plant", "Tuhaf Meyveli Bitki")
e("Strange Lockbox", "Tuhaf Kilitli Kutu")
e("Stranglekelp", "Boğan Yosun")
e("Stratholme Supply Crate", "Stratholme Erzak Sandığı")
e("Sundried Driftwood", "Güneşte Kurumuş Dalga Odunu")
e("Sungrass", "Güneş Otu")
e("Sunken Chest", "Batık Sandık")
e("Sunscorched Shell", "Güneşte Kavrulmuş Kabuk")
e("Sunwell - The Fall of Quel'Thalas", "Sunwell - Quel'Thalas'ın Düşüşü")
e("Supply Crate", "Erzak Sandığı")
e("Suspicious Barrel", "Şüpheli Varil")
e("Suspicious Hoofprint", "Şüpheli Toynak İzi")
e("Sword of the Barbarian King", "Barbar Kralın Kılıcı")
e("Symbol of Lost Honor", "Kayıp Onurun Simgesi")
e("Syndicate Documents", "Syndicate Belgeleri")
e("Tablet of Beth'Amara", "Beth'Amara Tableti")
e("Tablet of Jin'yael", "Jin'yael Tableti")
e("Tablet of Madness", "Delilik Tableti")
e("Tablet of Markri", "Markri Tableti")
e("Tablet of Sael'hai", "Sael'hai Tableti")
e("Tablet of Theka", "Theka Tableti")
e("Tablet of Will", "İrade Tableti")
e("Tablet of the Seven", "Yedilerin Tableti")
e("Taillasher Eggs", "Taillasher Yumurtaları")
e("Tainted Wood", "Bozulmuş Odun")
e("Tallonkai's Dresser", "Tallonkai'nin Şifonyeri")
e("Talon Den Hoard", "Talon Den Hazinesi")
e("Tammra Gaea Sapling", "Tammra Gaea Fidanı")
e("Tear of Theradras", "Theradras'ın Gözyaşı")
e("Tear of Tilloa", "Tilloa'nın Gözyaşı")
e("Termite Barrel", "Termit Varili")
e("Thaurissan Relic", "Thaurissan Kalıntısı")
e("Thazz'ril's Pick", "Thazz'ril'in Kazması")
e("The Alliance of Lordaeron", "Lordaeron İttifakı")
e("The Altar of Fire", "Ateş Sunağı")
e("The Argent Hold", "Argent Hold")
e("The Armor of Mannoroth", "Mannoroth'un Zırhı")
e("The Battle of Grim Batol", "Grim Batol Savaşı")
e("The Betrayer Ascendant", "Yükselen Hain")
e("The Birth of the Lich King", "Lich King'in Doğuşu")
e("The Book of Ur", "Ur'un Kitabı")
e("The Charred Oak", "Kömürleşmiş Meşe")
e("The Dark Portal and the Fall of Stormwind", "Dark Portal ve Stormwind'in Düşüşü")
e("The Deed to Brill", "Brill Tapusu")
e("The Deed to Caer Darrow", "Caer Darrow Tapusu")
e("The Deed to Southshore", "Southshore Tapusu")
e("The Deed to Tarren Mill", "Tarren Mill Tapusu")
e("The Demon Seed", "İblis Tohumu")
e("The Discs of Norgannon", "Norgannon Diskleri")
e("The Emperor's Tomb", "İmparatorun Mezarı")
e("The Fall of Ameth'Aran", "Ameth'Aran'ın Düşüşü")
e("The Founding of Quel'Thalas", "Quel'Thalas'ın Kuruluşu")
e("The Guardians of Tirisfal", "Tirisfal Muhafızları")
e("The Holy Spring", "Kutsal Pınar")
e("The Invasion of Draenor", "Draenor İstilası")
e("The Jewel of the Southsea", "Southsea'nin Mücevheri")
e("The Kaldorei and the Well of Eternity", "Kaldorei ve Sonsuzluk Kuyusu")
e("The Last Guardian", "Son Muhafız")
e("The Lay of Ameth'Aran", "Ameth'Aran Destanı")
e("The Legacy of the Aspects", "Aspect'lerin Mirası")
e("The Lich King Triumphant", "Muzaffer Lich King")
e("The New Horde", "Yeni Horde")
e("The Old Gods and the Ordering of Azeroth", "Kadim Tanrılar ve Azeroth'un Düzenlenişi")
e("The Prince's Chest", "Prensin Sandığı")
e("The Scarab Gong", "Skarabe Gongu")
e("The Scourge of Lordaeron", "Lordaeron'daki Scourge")
e("The Sentinels and the Long Vigil", "Sentinel'ler ve Uzun Nöbet")
e("The Seven Kingdoms", "Yedi Krallık")
e("The Severed Head of Nefarian", "Nefarian'ın Kesik Başı")
e("The Severed Head of Onyxia", "Onyxia'nın Kesik Başı")
e("The Skull of Tyrannistrasz", "Tyrannistrasz'ın Kafatası")
e("The Sparklematic 5200", "Sparklematic 5200")
e("The Twin Empires", "İkiz İmparatorluklar")
e("The War of the Ancients", "Kadimler Savaşı")
e("The White Stag and the Moon", "Beyaz Geyik ve Ay")
e("The Wickerman", "Hasır Adam")
e("The World Tree and the Emerald Dream", "Dünya Ağacı ve Zümrüt Rüya")
e("Theatric Lightning", "Gösteri Şimşeği")
e("Theramore Guard Badge", "Theramore Muhafız Rozeti")
e("Thermaplugg's Safe", "Thermaplugg'ın Kasası")
e("Third Mosh'aru Tablet", "Üçüncü Mosh'aru Tableti")
e("Third Witherbark Cage", "Üçüncü Witherbark Kafesi")
e("Thunderbrew Lager Keg", "Thunderbrew Bira Fıçısı")
e("Ticking Present", "Tıkırdayan Hediye")
e("Timberling Sprout", "Timberling Filizi")
e("Tin Vein", "Kalay Damarı")
e("Tirisfal Pumpkin", "Tirisfal Balkabağı")
e("Toasting Goblet", "Kadeh Kaldırma Kupası")
e("Tome of Mel'Thandris", "Mel'Thandris'in Kitabı")
e("Tome of the Cabal", "Tarikatın Kitabı")
e("Tonk Control Console", "Tonk Kontrol Konsolu")
e("Tool Bucket", "Alet Kovası")
e("Toothgnasher's Skeleton", "Toothgnasher'ın İskeleti")
e("Torch", "Meşale")
e("Torch of Retribution", "İntikam Meşalesi")
e("Torn Scroll", "Yırtık Parşömen")
e("Tower Banner", "Kule Sancağı")
e("Treasure of the Shen'dralar", "Shen'dralar Hazinesi")
e("Trelane's Chest", "Trelane'in Sandığı")
e("Trelane's Footlocker", "Trelane'in Eşya Sandığı")
e("Trelane's Lockbox", "Trelane'in Kilitli Kutusu")
e("Troll Chest", "Trol Sandığı")
e("Troll Drum Sound Object", "Trol Davulu Ses Nesnesi")
e("Troll Hero Lightning", "Trol Kahraman Şimşeği")
e("Troll Hero Portal Sound", "Trol Kahraman Geçit Sesi")
e("Trollbane's Tomb", "Trollbane'in Mezarı")
e("Truesilver Deposit", "Gerçek Gümüş Yatağı")
e("Twilight Artifact", "Twilight Eseri")
e("Twilight Tablet Fragment", "Twilight Tablet Parçası")
e("Twilight Tome", "Twilight Kitabı")
e("Uldaman Relics", "Uldaman Kalıntıları")
e("Uldaman Reliefs", "Uldaman Kabartmaları")
e("Uldum Pedestal", "Uldum Kaidesi")
e("Un'Goro Dirt Pile", "Un'Goro Toprak Yığını")
e("Un'Goro Flat Rock", "Un'Goro Yassı Kayası")
e("Unadorned Stake", "Süssüz Kazık")
e("Undead Fire", "Ölümsüz Ateşi")
e("Unfinished Painting", "Bitmemiş Tablo")
e("Unfired Plate Gauntlets", "Tavlanmamış Plaka Eldivenler")
e("Unforged Runic Breastplate", "Dövülmemiş Rünlü Göğüslük")
e("Unguarded Thunder Ale Barrel", "Korumasız Thunder Ale Fıçısı")
e("Unopened Crate", "Açılmamış Sandık")
e("Ur's Treatise on Shadow Magic", "Ur'un Gölge Büyüsü Üzerine İncelemesi")
e("Uther Shrine Lightbeam", "Uther Tapınağı Işık Huzmesi")
e("Velinde's Locker", "Velinde'nin Dolabı")
e("Venom Bottle", "Zehir Şişesi")
e("Venture Co. Documents", "Venture Co. Belgeleri")
e("Venture Co. Engineering Plans", "Venture Co. Mühendislik Planları")
e("Venture Co. Strongbox", "Venture Co. Kasası")
e("Verigan's Fist", "Verigan'ın Yumruğu")
e("Vessel of Tainted Blood", "Bozulmuş Kan Kabı")
e("Violet Tragan", "Mor Tragan")
e("Volcanic Ash", "Volkanik Kül")
e("WANTED: Murkdeep!", "ARANIYOR: Murkdeep!")
e("Wanted Board", "Aranıyor Panosu")
e("Wanted Poster", "Aranıyor İlanı")
e("Wanted Poster - Arnak Grimtotem", "Aranıyor İlanı - Arnak Grimtotem")
e("Wanted Poster: Besseleth", "Aranıyor İlanı: Besseleth")
e("Wanted Poster: Deathclasp", "Aranıyor İlanı: Deathclasp")
e("Wanted!", "Aranıyor!")
e("Wanted/Missing/Lost & Found", "Aranıyor/Kayıp/Kayıp Eşya")
e("Wanted: DWARVES!", "Aranıyor: CÜCELER!")
e("Wanted: Gath'Ilzogg", "Aranıyor: Gath'Ilzogg")
e("Wanted: Lieutenant Fangore", "Aranıyor: Teğmen Fangore")
e("War of the Spider", "Örümcek Savaşı")
e("War of the Three Hammers", "Üç Çekiç Savaşı")
e("Warsong Axe Shipment", "Warsong Balta Sevkiyatı")
e("Warsong Flag", "Warsong Bayrağı")
e("Warsong Oil", "Warsong Yağı")
e("Water Pitcher", "Su Sürahisi")
e("Waterlogged Chest", "Su Almış Sandık")
e("Waterlogged Footlocker", "Su Almış Eşya Sandığı")
e("Waterlogged Letter", "Islanmış Mektup")
e("Weapon Crate", "Silah Sandığı")
e("Weapon Rack", "Silah Rafı")
e("Weathered Bookcase", "Yıpranmış Kitaplık")
e("Webwood Eggs", "Webwood Yumurtaları")
e("Well Stone", "Kuyu Taşı")
e("Western Crystal Pylon", "Batı Kristal Pilonu")
e("Wheel of the Black March", "Kara Yürüyüş Çarkı")
e("Whipweed", "Kamçı Otu")
e("Wickerman Ember", "Hasır Adam Közü")
e("Wild Steelbloom", "Yabani Çelik Çiçeği")
e("Wildkin Feather", "Wildkin Tüyü")
e("Wind Stone", "Rüzgâr Taşı")
e("Wintersbite", "Kış Isırığı")
e("Witch Doctor's Chest", "Cadı Doktorun Sandığı")
e("Wooden Outhouse", "Ahşap Tuvalet Kulübesi")
e("Woodpaw Battle Map", "Woodpaw Savaş Haritası")
e("Worn Chest", "Yıpranmış Sandık")
e("Worn Wooden Chest", "Yıpranmış Ahşap Sandık")
e("Wrath of Soulflayer", "Soulflayer'ın Gazabı")
e("Wrecked Row Boat", "Parçalanmış Kayık")
e("Wushoolay, the Storm Witch", "Fırtına Cadısı Wushoolay")
e("Yellow Power Crystal", "Sarı Güç Kristali")
e("Yellow Raptor Nest", "Sarı Raptor Yuvası")
e("Yuriv's Tombstone", "Yuriv'in Mezar Taşı")
e("Ziata'jai Trophy Skulls", "Ziata'jai Ganimet Kafatasları")
e("Zukk'ash Pod", "Zukk'ash Kozası")
e("Zul'Mamwe Trophy Skulls", "Zul'Mamwe Ganimet Kafatasları")
local I = WoWTurkce.NesneId
for _, i in ipairs({148504}) do I[i] = "A Conspicuous Gravestone" end
for _, i in ipairs({179547,179548}) do I[i] = "A Dusty Tome" end
for _, i in ipairs({2059}) do I[i] = "A Dwarven Corpse" end
for _, i in ipairs({161504}) do I[i] = "A Small Pack" end
for _, i in ipairs({2553}) do I[i] = "A Soggy Scroll" end
for _, i in ipairs({179706}) do I[i] = "A Treatise on Military Ranks" end
for _, i in ipairs({61}) do I[i] = "A Weathered Grave" end
for _, i in ipairs({161505}) do I[i] = "A Wrecked Raft" end
for _, i in ipairs({55}) do I[i] = "A half-eaten body" end
for _, i in ipairs({119,167}) do I[i] = "Abercrombie's Crate" end
for _, i in ipairs({175772}) do I[i] = "Admiral Barean Westwind" end
for _, i in ipairs({175738}) do I[i] = "Aegwynn and the Dragon Hunt" end
for _, i in ipairs({21581}) do I[i] = "Aftermath of the Second War" end
for _, i in ipairs({105169,105170,105171,105172}) do I[i] = "Agamand Weapon Rack" end
for _, i in ipairs({4166}) do I[i] = "Alchemical Implements" end
for _, i in ipairs({179782}) do I[i] = "Alchemy Set" end
for _, i in ipairs({1166}) do I[i] = "Alexston's Chest" end
for _, i in ipairs({175565,175567}) do I[i] = "Alien Egg" end
for _, i in ipairs({178365,178389,178394,178925,178929,178935,178936,179284,179465,179470,179481,180058,180064,180068,180072,180076}) do I[i] = "Alliance Banner" end
for _, i in ipairs({3715,4096,105579,105581,111095}) do I[i] = "Alliance Chest" end
for _, i in ipairs({179735}) do I[i] = "Alliance Military Ranks" end
for _, i in ipairs({133234}) do I[i] = "Altar of Archaedas" end
for _, i in ipairs({177404}) do I[i] = "Altar of Elune" end
for _, i in ipairs({148836}) do I[i] = "Altar of Hakkar" end
for _, i in ipairs({148498}) do I[i] = "Altar of Suntara" end
for _, i in ipairs({130511}) do I[i] = "Altar of The Keepers" end
for _, i in ipairs({180367}) do I[i] = "Altar of Zanza" end
for _, i in ipairs({94040,103016}) do I[i] = "Altar of the Deeps" end
for _, i in ipairs({153205}) do I[i] = "Altar of the Defiler" end
for _, i in ipairs({2576}) do I[i] = "Altar of the Tides" end
for _, i in ipairs({2714}) do I[i] = "Alterac Granite" end
for _, i in ipairs({41}) do I[i] = "Ambassador's Locker" end
for _, i in ipairs({2912}) do I[i] = "Ambercorn" end
for _, i in ipairs({103815}) do I[i] = "Ambermill Strongbox" end
for _, i in ipairs({176785}) do I[i] = "Ammo Crate" end
for _, i in ipairs({76}) do I[i] = "An Empty Jar" end
for _, i in ipairs({20807}) do I[i] = "Ancient Brazier" end
for _, i in ipairs({126260}) do I[i] = "Ancient Chest" end
for _, i in ipairs({175889}) do I[i] = "Ancient Egg" end
for _, i in ipairs({16393,16394}) do I[i] = "Ancient Flame" end
for _, i in ipairs({19025}) do I[i] = "Ancient Inscription" end
for _, i in ipairs({333,334,35252}) do I[i] = "Ancient Relic" end
for _, i in ipairs({17783,18603}) do I[i] = "Ancient Statuette" end
for _, i in ipairs({141979}) do I[i] = "Ancient Treasure" end
for _, i in ipairs({103600}) do I[i] = "Andron's Bookshelf" end
for _, i in ipairs({19534}) do I[i] = "Anton's Letter of Commendation" end
for _, i in ipairs({180523}) do I[i] = "Apple Bob" end
for _, i in ipairs({175734}) do I[i] = "Arathor and the Troll Wars" end
for _, i in ipairs({150140}) do I[i] = "Arkan Focusing Crystal" end
for _, i in ipairs({177199}) do I[i] = "Archbishop Alonsus Faol" end
for _, i in ipairs({175758}) do I[i] = "Archimonde's Return and the Flight to Kalimdor" end
for _, i in ipairs({25333}) do I[i] = "Archmage Khadgar of the Kirin Tor" end
for _, i in ipairs({181074}) do I[i] = "Arena Spoils" end
for _, i in ipairs({176225}) do I[i] = "Arko'niran's Chest" end
for _, i in ipairs({142141,176642}) do I[i] = "Arthas' Tears" end
for _, i in ipairs({142344}) do I[i] = "Artificial Extrapolator" end
for _, i in ipairs({18973}) do I[i] = "Arugal's Focus" end
for _, i in ipairs({148830,148831,148832,148833,148834,148835,148837,177484,177485}) do I[i] = "Atal'ai Statue" end
for _, i in ipairs({37099}) do I[i] = "Atal'ai Tablet" end
for _, i in ipairs({3192}) do I[i] = "Attack Plan: Orgrimmar" end
for _, i in ipairs({3190}) do I[i] = "Attack Plan: Sen'jin Village" end
for _, i in ipairs({3189}) do I[i] = "Attack Plan: Valley of Trials" end
for _, i in ipairs({177789}) do I[i] = "Augustus' Receipt Book" end
for _, i in ipairs({178229}) do I[i] = "Aurora's Book" end
for _, i in ipairs({152620,152621,152622,152631}) do I[i] = "Azsharite Formation" end
for _, i in ipairs({3644}) do I[i] = "Bael Modan Flying Machine" end
for _, i in ipairs({123329}) do I[i] = "Baelog's Chest" end
for _, i in ipairs({123463}) do I[i] = "Baelog's Journal" end
for _, i in ipairs({92420}) do I[i] = "Bailor's Ore" end
for _, i in ipairs({2891}) do I[i] = "Balia'mah Trophy Skulls" end
for _, i in ipairs({102985}) do I[i] = "Balnir Snapdragons" end
for _, i in ipairs({19598}) do I[i] = "Barrow Cache" end
for _, i in ipairs({182063}) do I[i] = "Basin of Holy Water" end
for _, i in ipairs({181053}) do I[i] = "Basket of Bloodkelp" end
for _, i in ipairs({89931}) do I[i] = "Bath'rah's Cauldron" end
for _, i in ipairs({2843,2844,2849,106318,106319}) do I[i] = "Battered Chest" end
for _, i in ipairs({2875}) do I[i] = "Battered Dwarven Skeleton" end
for _, i in ipairs({179486,179488,179490}) do I[i] = "Battered Footlocker" end
for _, i in ipairs({180366}) do I[i] = "Battered Tackle Box" end
for _, i in ipairs({177785}) do I[i] = "Bauble Container" end
for _, i in ipairs({175207,175226,175227,175230,175233}) do I[i] = "Beached Sea Creature" end
for _, i in ipairs({176190,176191,176196,176197,176198}) do I[i] = "Beached Sea Turtle" end
for _, i in ipairs({20726}) do I[i] = "Beginnings of the Undead Threat" end
for _, i in ipairs({179674}) do I[i] = "Bell of Dethmoora" end
for _, i in ipairs({152097}) do I[i] = "Belnistrasz's Brazier" end
for _, i in ipairs({3239}) do I[i] = "Benedict's Chest" end
for _, i in ipairs({1594}) do I[i] = "Berard's Bookshelf" end
for _, i in ipairs({174682}) do I[i] = "Beware of Pterrordax" end
for _, i in ipairs({21582}) do I[i] = "Beyond the Dark Portal" end
for _, i in ipairs({175334}) do I[i] = "Bijou's Belongings" end
for _, i in ipairs({104575}) do I[i] = "Bingles's Blastencapper" end
for _, i in ipairs({104564,104569,104574}) do I[i] = "Bingles's Toolbucket" end
for _, i in ipairs({102984}) do I[i] = "Bink's Toolbox" end
for _, i in ipairs({177807}) do I[i] = "Black Dragon Egg" end
for _, i in ipairs({176589}) do I[i] = "Black Lotus" end
for _, i in ipairs({20992}) do I[i] = "Black Shield" end
for _, i in ipairs({175706}) do I[i] = "Blackrock Altar" end
for _, i in ipairs({15004,180088}) do I[i] = "Blacksmith Banner" end
for _, i in ipairs({173232,173234,176325,176327}) do I[i] = "Blacksmithing Plans" end
for _, i in ipairs({175330}) do I[i] = "Blackwood Fruit Stores" end
for _, i in ipairs({175331}) do I[i] = "Blackwood Grain Stores" end
for _, i in ipairs({175329}) do I[i] = "Blackwood Nut Stores" end
for _, i in ipairs({180452,180515}) do I[i] = "Blastenheimer 5000 Ultra Cannon" end
for _, i in ipairs({142143,183046}) do I[i] = "Blindweed" end
for _, i in ipairs({176213,176214}) do I[i] = "Blood of Heroes" end
for _, i in ipairs({164958}) do I[i] = "Bloodpetal Sprout" end
for _, i in ipairs({2086}) do I[i] = "Bloodsail Charts" end
for _, i in ipairs({2083}) do I[i] = "Bloodsail Correspondence" end
for _, i in ipairs({2087}) do I[i] = "Bloodsail Orders" end
for _, i in ipairs({164658,164778}) do I[i] = "Blue Power Crystal" end
for _, i in ipairs({6907}) do I[i] = "Blue Raptor Nest" end
for _, i in ipairs({20351}) do I[i] = "Blue Soulgem" end
for _, i in ipairs({20920}) do I[i] = "Blueleaf Tuber" end
for _, i in ipairs({1831,1832,1883,1884,1885,1886,1887,1928,2335,2658,2665,2666,3308,3656,15069,18063,20849,23570,23571,23572,23573,23574,23575,23577,23879,23880,23881,24723,24724,24725,24726,24727,24728,24729,31408,31410,32110,32878,32883,35844,36645,50910,50986,50987,50988,50989,51950,55616,61927,61928,61929,63196,64849,64850,69422,69425,69426,69427,69428,69438,74146,74727,92066,92067,92098,92254,94183,94184,94185,94186,94187,94188,94189,94190,94191,103748,103749,103750,103751,103770,103771,110230,110231,110232,110233,110234,111839,125475,126312,126313,126314,126335,136922,136923,136954,136957,136959,136961,136962,136963,136964,136965,136966,138318,140931,141610,141611,141843,141852,141971,141972,142090,142091,142101,142965,142966,142967,142980,146087,146088,146089,146090,146091,147536,148840,148841,149026,153126,153723,161483,161484,161488,161519,161520,167284,167285,167286,167287,167288,167289,167290,167291,174729,174730,175335,175406,175594,175602,175671,176269,176279,176280,176281,176282,176283,176285,176286,176287,176288,176289,176291,176293,176294,176318,176425,176426,176436,176438,176439,176442,176444,176445,176447,176448,176449,176450,176451,176452,176505,176558,176560,176604,176617,176618,176619,176705,176784,176787,176805,176896,177002,177003,177004,177005,177006,177007,177008,177009,177010,177011,177012,177013,177014,177015,177016,177017,177018,177019,177020,177021,177022,177023,177024,177025,177026,177084,177225,177408,178571,179344,180434,180438,180439,180440,180441,180442,180443,180444,181134,181135,181311,181312,181316,181320,181321,181325,181326,181328,181329,181446,181480,181481,181483,181484,181485,181486,181487,181488,181489,181490,181491,181493,181494,181495,181633,181655,181656,181657,181658,181659,181660,181735,181767,181775,181789,181954,182216,182217,182218,182219,182220,182221,182561,182944,183124,183125,183126,183159,183160,183161,183197,183204,183265,183275,183277,183313,183393,183418,183419,183420,183421,183422,183423,183424,183425,183427,183428,183432,183433,183467,183824,183828,183882,183883,183894,183909,183946,183984,184009,184010,184011,184012,184015,184016,184017,184018,184021,184022,184023,184024,184025,184030,184032,184033,184034,184161,184314,184317,184339,184340,184341,184342,184346,184347,184357,184360,184377,184395,184396,184400,184448,184467,184470,184471,184474,184494,184644,184645,184646,184647,184648,184649,184650,184651,184683,184852,185111,185153,185154,185157,185158,185159,185160,185161,185162,185163,185164,185284,185286,185288,185290,186023,186035,186130,186131,186132,186177,186180,186745,188214}) do I[i] = "Bonfire" end
for _, i in ipairs({177226}) do I[i] = "Book \"Soothsaying for Dummies\"" end
for _, i in ipairs({287}) do I[i] = "Bookie Herod's Records" end
for _, i in ipairs({288}) do I[i] = "Bookie Herod's Strongbox" end
for _, i in ipairs({175948}) do I[i] = "Booty Bay Alarm Bell" end
for _, i in ipairs({18036}) do I[i] = "Bottle of Disease" end
for _, i in ipairs({19019,19020}) do I[i] = "Box of Assorted Parts" end
for _, i in ipairs({176092}) do I[i] = "Box of Incendiaries" end
for _, i in ipairs({113791}) do I[i] = "Brazier of Everfount" end
for _, i in ipairs({176161}) do I[i] = "Brazier of Hatred" end
for _, i in ipairs({180327}) do I[i] = "Brazier of Madness" end
for _, i in ipairs({176159}) do I[i] = "Brazier of Malice" end
for _, i in ipairs({176158}) do I[i] = "Brazier of Pain" end
for _, i in ipairs({176160}) do I[i] = "Brazier of Suffering" end
for _, i in ipairs({61934}) do I[i] = "Brazier of the Dormant Flame" end
for _, i in ipairs({175564}) do I[i] = "Brazier of the Herald" end
for _, i in ipairs({1621,3729}) do I[i] = "Briarthorn" end
for _, i in ipairs({113768,113769,113770,113771,113772}) do I[i] = "Brightly Colored Egg" end
for _, i in ipairs({36}) do I[i] = "Broken Barrel" end
for _, i in ipairs({1622,3730}) do I[i] = "Bruiseweed" end
for _, i in ipairs({2076,2719,18079,18083,18084,18341,18345,20970,31580,142118,142690,142693,176273,176275}) do I[i] = "Bubbling Cauldron" end
for _, i in ipairs({3737,3740}) do I[i] = "Bubbling Fissure" end
for _, i in ipairs({123330,123331,123332,123333}) do I[i] = "Buccaneer's Strongbox" end
for _, i in ipairs({176793}) do I[i] = "Bundle of Wood" end
for _, i in ipairs({58595}) do I[i] = "Burning Blade Stash" end
for _, i in ipairs({142214,142215,142216,142217,142218,142219}) do I[i] = "Button" end
for _, i in ipairs({2704}) do I[i] = "Cache of Explosives" end
for _, i in ipairs({179703}) do I[i] = "Cache of the Firelord" end
for _, i in ipairs({171938}) do I[i] = "Cactus Apple" end
for _, i in ipairs({176306,181152,181379,181663,182094,182794,182942,184702,185474,185952}) do I[i] = "Cage" end
for _, i in ipairs({2712}) do I[i] = "Calcified Elven Gem" end
for _, i in ipairs({179913}) do I[i] = "Call to Arms!" end
for _, i in ipairs({113531,141860,141861,141862,141863,193011}) do I[i] = "Cannon" end
for _, i in ipairs({176215}) do I[i] = "Cannonball Stack" end
for _, i in ipairs({105175}) do I[i] = "Cantation of Manifestation" end
for _, i in ipairs({142184}) do I[i] = "Captain's Chest" end
for _, i in ipairs({35,20925}) do I[i] = "Captain's Footlocker" end
for _, i in ipairs({28024}) do I[i] = "Caravan Chest" end
for _, i in ipairs({180743}) do I[i] = "Carefully Wrapped Present" end
for _, i in ipairs({2743}) do I[i] = "Carved Stone Urn" end
for _, i in ipairs({13359,13873}) do I[i] = "Cat Figurine" end
for _, i in ipairs({176192}) do I[i] = "Catalogue of the Wayward" end
for _, i in ipairs({181681,181913}) do I[i] = "Chalice of Elune" end
for _, i in ipairs({175584}) do I[i] = "Challenge to Urok" end
for _, i in ipairs({175726}) do I[i] = "Charge of the Dragonflights" end
for _, i in ipairs({181963}) do I[i] = "Charred Bone Fragment" end
for _, i in ipairs({180749}) do I[i] = "Cheer Speaker" end
for _, i in ipairs({3238}) do I[i] = "Chen's Empty Keg" end
for _, i in ipairs({105174}) do I[i] = "Chest of Containment Coffers" end
for _, i in ipairs({2742}) do I[i] = "Chest of Nesting" end
for _, i in ipairs({169243}) do I[i] = "Chest of The Seven" end
for _, i in ipairs({2739}) do I[i] = "Chest of the Black Feather" end
for _, i in ipairs({2740}) do I[i] = "Chest of the Raven Claw" end
for _, i in ipairs({2741}) do I[i] = "Chest of the Sky" end
for _, i in ipairs({180105}) do I[i] = "Circle of Binding" end
for _, i in ipairs({19901,20352}) do I[i] = "Circle of Imprisonment" end
for _, i in ipairs({175761}) do I[i] = "Civil War in the Plaguelands" end
for _, i in ipairs({142076}) do I[i] = "Clara's Fresh Apples" end
for _, i in ipairs({164881,173325,174609,174685}) do I[i] = "Cleansed Night Dragon" end
for _, i in ipairs({164882,171940,171943,174610,174612,174613,174614,174615,174714,174715}) do I[i] = "Cleansed Songflower" end
for _, i in ipairs({164883,174622,174623,174624,174625,174687}) do I[i] = "Cleansed Whipper Root" end
for _, i in ipairs({164884,173326,174616,174617,174618,174619,174620,174621,174710,174711}) do I[i] = "Cleansed Windblossom" end
for _, i in ipairs({178784}) do I[i] = "Coldtooth Supplies" end
for _, i in ipairs({176210}) do I[i] = "Command Tent" end
for _, i in ipairs({19283}) do I[i] = "Compendium of the Fallen" end
for _, i in ipairs({125477}) do I[i] = "Conspicuous Urn" end
for _, i in ipairs({4141}) do I[i] = "Control Console" end
for _, i in ipairs({1731,2055,3763,103713,181248}) do I[i] = "Copper Vein" end
for _, i in ipairs({179553}) do I[i] = "Core Fragment" end
for _, i in ipairs({1593}) do I[i] = "Corpse Laden Boat" end
for _, i in ipairs({164885,173324,174608,174684}) do I[i] = "Corrupted Night Dragon" end
for _, i in ipairs({164886,171939,171942,174594,174595,174596,174597,174598,174712,174713}) do I[i] = "Corrupted Songflower" end
for _, i in ipairs({164888,173284,174605,174606,174607,174686}) do I[i] = "Corrupted Whipper Root" end
for _, i in ipairs({164887,173327,174599,174600,174601,174602,174603,174604,174708,174709}) do I[i] = "Corrupted Windblossom" end
for _, i in ipairs({2554}) do I[i] = "Cortello's Riddle" end
for _, i in ipairs({2556}) do I[i] = "Cortello's Treasure" end
for _, i in ipairs({20691}) do I[i] = "Cozzle's Footlocker" end
for _, i in ipairs({1586}) do I[i] = "Crate of Candles" end
for _, i in ipairs({86492}) do I[i] = "Crate of Elunite" end
for _, i in ipairs({249,161526}) do I[i] = "Crate of Foodstuffs" end
for _, i in ipairs({21277}) do I[i] = "Crate with Holes" end
for _, i in ipairs({175708}) do I[i] = "Crossroads' Supply Crates" end
for _, i in ipairs({2868}) do I[i] = "Crumpled Map" end
for _, i in ipairs({176349}) do I[i] = "Crusaders' Square Postbox" end
for _, i in ipairs({180633}) do I[i] = "Crystalline Tear" end
for _, i in ipairs({1627}) do I[i] = "Dalaran Crate" end
for _, i in ipairs({92423}) do I[i] = "Damaged Chest" end
for _, i in ipairs({261,174728,175587}) do I[i] = "Damaged Crate" end
for _, i in ipairs({2008}) do I[i] = "Dangerous!" end
for _, i in ipairs({178464}) do I[i] = "Dark Cleric Salem's Chest" end
for _, i in ipairs({160845,174565}) do I[i] = "Dark Coffer" end
for _, i in ipairs({165738}) do I[i] = "Dark Iron Ale Mug" end
for _, i in ipairs({165658}) do I[i] = "Dark Iron Deposit" end
for _, i in ipairs({175607,175608,175609}) do I[i] = "Dark Iron Dwarf Corpse" end
for _, i in ipairs({170607}) do I[i] = "Dark Iron Keg Shotgun" end
for _, i in ipairs({179828}) do I[i] = "Dark Iron Pillow" end
for _, i in ipairs({164820,164821,164822,164823,164824,164825}) do I[i] = "Dark Keeper Nameplate" end
for _, i in ipairs({161456,161457,161458,161459,164818,164819}) do I[i] = "Dark Keeper Portrait" end
for _, i in ipairs({175385}) do I[i] = "Darkstone Tablet" end
for _, i in ipairs({176206}) do I[i] = "Davil's Libram" end
for _, i in ipairs({85563}) do I[i] = "Dead-tooth's Strongbox" end
for _, i in ipairs({176091}) do I[i] = "Deadwood Cauldron" end
for _, i in ipairs({11713}) do I[i] = "Death Cap" end
for _, i in ipairs({175933}) do I[i] = "Decorated Headstone" end
for _, i in ipairs({16398}) do I[i] = "Defias Cannon" end
for _, i in ipairs({17155}) do I[i] = "Defias Gunpowder" end
for _, i in ipairs({21052}) do I[i] = "Defias Strongbox" end
for _, i in ipairs({177243,177365,177366,177367,177368,177369,177397,177398,177399,177400}) do I[i] = "Demon Portal" end
for _, i in ipairs({7923}) do I[i] = "Denalan's Planter" end
for _, i in ipairs({179492,179494,179496}) do I[i] = "Dented Footlocker" end
for _, i in ipairs({161527}) do I[i] = "Dinosaur Bone" end
for _, i in ipairs({3076}) do I[i] = "Dirt-stained Map" end
for _, i in ipairs({103821}) do I[i] = "Doan's Strongbox" end
for _, i in ipairs({176344,190483,190484}) do I[i] = "Document Chest" end
for _, i in ipairs({176753}) do I[i] = "Doom Weed" end
for _, i in ipairs({175382}) do I[i] = "Doomrigger's Coffer" end
for _, i in ipairs({179673}) do I[i] = "Doomsday Candle" end
for _, i in ipairs({17156,17157,101831,101832,101833,101834}) do I[i] = "Door Lever" end
for _, i in ipairs({180665,180666,180667}) do I[i] = "Draconic for Dummies" end
for _, i in ipairs({22550}) do I[i] = "Draenethyst Crystals" end
for _, i in ipairs({1609}) do I[i] = "Dragonmaw Catapult" end
for _, i in ipairs({179880}) do I[i] = "Drakkisath's Brand" end
for _, i in ipairs({176584,176639,180168}) do I[i] = "Dreamfoil" end
for _, i in ipairs({177725}) do I[i] = "Dredan's Alchemy Tools" end
for _, i in ipairs({177727}) do I[i] = "Dredan's Forge" end
for _, i in ipairs({179004,179005}) do I[i] = "Drek'Thar's Scrolls" end
for _, i in ipairs({3767}) do I[i] = "Drizzlik's Emporium" end
for _, i in ipairs({19597}) do I[i] = "Druids' Cache" end
for _, i in ipairs({123214,124072}) do I[i] = "Duskwood Chest" end
for _, i in ipairs({179565}) do I[i] = "Dusty Reliquary" end
for _, i in ipairs({1728}) do I[i] = "Dusty Rug" end
for _, i in ipairs({112888}) do I[i] = "Dusty Shelf" end
for _, i in ipairs({1571}) do I[i] = "Dusty Spellbooks" end
for _, i in ipairs({1619,3726}) do I[i] = "Earthroot" end
for _, i in ipairs({164957}) do I[i] = "Eastern Crystal Pylon" end
for _, i in ipairs({2652}) do I[i] = "Ebenezer Rustlocke's Corpse" end
for _, i in ipairs({20359}) do I[i] = "Egg of Onyxia" end
for _, i in ipairs({142071}) do I[i] = "Egg-O-Matic" end
for _, i in ipairs({176351}) do I[i] = "Elders' Square Postbox" end
for _, i in ipairs({51708}) do I[i] = "Eliza's Grave Dirt" end
for _, i in ipairs({37}) do I[i] = "Eliza's Tombstone" end
for _, i in ipairs({19015}) do I[i] = "Elune's Tear" end
for _, i in ipairs({175855}) do I[i] = "Empires' Fall" end
for _, i in ipairs({175966}) do I[i] = "Enchanted Scarlet Thread" end
for _, i in ipairs({144063}) do I[i] = "Equinex Monolith" end
for _, i in ipairs({164662}) do I[i] = "Equipment Boxes" end
for _, i in ipairs({148512}) do I[i] = "Essence Font" end
for _, i in ipairs({174746}) do I[i] = "Etched Note" end
for _, i in ipairs({148418,148419,148420,148421}) do I[i] = "Eternal Flame" end
for _, i in ipairs({148998}) do I[i] = "Evil God Summoning Circle" end
for _, i in ipairs({164798}) do I[i] = "Evoroot" end
for _, i in ipairs({2867}) do I[i] = "Excavation Supply Crate" end
for _, i in ipairs({175731}) do I[i] = "Exile of the High Elves" end
for _, i in ipairs({1585,144065}) do I[i] = "Explosive Charge" end
for _, i in ipairs({2042}) do I[i] = "Fadeleaf" end
for _, i in ipairs({52}) do I[i] = "Fall of Gurubashi" end
for _, i in ipairs({15003,180089}) do I[i] = "Farm Banner" end
for _, i in ipairs({175245}) do I[i] = "Father Flame" end
for _, i in ipairs({177964}) do I[i] = "Fathom Stone" end
for _, i in ipairs({22706}) do I[i] = "Faustin's Alchemy Set" end
for _, i in ipairs({21145}) do I[i] = "Feast Boar" end
for _, i in ipairs({21146}) do I[i] = "Feast Fish" end
for _, i in ipairs({21147}) do I[i] = "Feast Fruit" end
for _, i in ipairs({21148}) do I[i] = "Feast Goblet" end
for _, i in ipairs({181649}) do I[i] = "Featherbeard's Journal" end
for _, i in ipairs({181643}) do I[i] = "Featherbeard's Remains" end
for _, i in ipairs({1673}) do I[i] = "Fel Cone" end
for _, i in ipairs({148499}) do I[i] = "Felix's Box" end
for _, i in ipairs({178085}) do I[i] = "Felix's Bucket of Bolts" end
for _, i in ipairs({178084}) do I[i] = "Felix's Chest" end
for _, i in ipairs({179559}) do I[i] = "Felvine Shard" end
for _, i in ipairs({179516}) do I[i] = "Fengus's Chest" end
for _, i in ipairs({142958}) do I[i] = "Feralas: A History" end
for _, i in ipairs({176350}) do I[i] = "Festival Lane Postbox" end
for _, i in ipairs({180793}) do I[i] = "Festive Gift" end
for _, i in ipairs({180699}) do I[i] = "Festive Keg" end
for _, i in ipairs({180905}) do I[i] = "Festive Mug" end
for _, i in ipairs({175949}) do I[i] = "Fifth Mosh'aru Tablet" end
for _, i in ipairs({21118,21119,21120,21121}) do I[i] = "Fire of Aku'mai" end
for _, i in ipairs({177417}) do I[i] = "Fire of Elune" end
for _, i in ipairs({2866}) do I[i] = "Firebloom" end
for _, i in ipairs({180763,180764,180870,180871,180872,180873}) do I[i] = "Firecrackers" end
for _, i in ipairs({180720}) do I[i] = "Firework, Show, Type 1 Blue" end
for _, i in ipairs({180722}) do I[i] = "Firework, Show, Type 1 Blue BIG" end
for _, i in ipairs({180724}) do I[i] = "Firework, Show, Type 1 Green" end
for _, i in ipairs({180726}) do I[i] = "Firework, Show, Type 1 Green BIG" end
for _, i in ipairs({180741}) do I[i] = "Firework, Show, Type 1 Purple BIG" end
for _, i in ipairs({180703}) do I[i] = "Firework, Show, Type 1 Red" end
for _, i in ipairs({180728}) do I[i] = "Firework, Show, Type 1 White" end
for _, i in ipairs({180729}) do I[i] = "Firework, Show, Type 1 White BIG" end
for _, i in ipairs({180736}) do I[i] = "Firework, Show, Type 1 Yellow" end
for _, i in ipairs({180737}) do I[i] = "Firework, Show, Type 1 Yellow BIG" end
for _, i in ipairs({180707}) do I[i] = "Firework, Show, Type 1,  Red BIG" end
for _, i in ipairs({180721}) do I[i] = "Firework, Show, Type 2 Blue" end
for _, i in ipairs({180723}) do I[i] = "Firework, Show, Type 2 Blue BIG" end
for _, i in ipairs({180727}) do I[i] = "Firework, Show, Type 2 Green" end
for _, i in ipairs({180725}) do I[i] = "Firework, Show, Type 2 Green BIG" end
for _, i in ipairs({180740}) do I[i] = "Firework, Show, Type 2 Purple" end
for _, i in ipairs({180733}) do I[i] = "Firework, Show, Type 2 Purple BIG" end
for _, i in ipairs({180704}) do I[i] = "Firework, Show, Type 2 Red" end
for _, i in ipairs({180730}) do I[i] = "Firework, Show, Type 2 White" end
for _, i in ipairs({180731}) do I[i] = "Firework, Show, Type 2 White BIG" end
for _, i in ipairs({180738}) do I[i] = "Firework, Show, Type 2 Yellow" end
for _, i in ipairs({180739}) do I[i] = "Firework, Show, Type 2 Yellow BIG" end
for _, i in ipairs({180708}) do I[i] = "Firework, Show, Type 2,  Red BIG" end
for _, i in ipairs({144066}) do I[i] = "First Witherbark Cage" end
for _, i in ipairs({3743}) do I[i] = "Fissure Plant" end
for _, i in ipairs({9630}) do I[i] = "Flagongut's Fossil" end
for _, i in ipairs({181561}) do I[i] = "Flame of Ashenvale" end
for _, i in ipairs({1768}) do I[i] = "Flame of Azel" end
for _, i in ipairs({181342}) do I[i] = "Flame of Azshara" end
for _, i in ipairs({181347}) do I[i] = "Flame of Blackrock Spire" end
for _, i in ipairs({142185}) do I[i] = "Flame of Byltan" end
for _, i in ipairs({181563}) do I[i] = "Flame of Darkshore" end
for _, i in ipairs({181334}) do I[i] = "Flame of Darnassus" end
for _, i in ipairs({181346}) do I[i] = "Flame of Dire Maul" end
for _, i in ipairs({181566}) do I[i] = "Flame of Hillsbrad" end
for _, i in ipairs({142187}) do I[i] = "Flame of Imbel" end
for _, i in ipairs({181333}) do I[i] = "Flame of Ironforge" end
for _, i in ipairs({142186}) do I[i] = "Flame of Lahassa" end
for _, i in ipairs({181336}) do I[i] = "Flame of Orgrimmar" end
for _, i in ipairs({142188}) do I[i] = "Flame of Samha" end
for _, i in ipairs({181341}) do I[i] = "Flame of Searing Gorge" end
for _, i in ipairs({181339}) do I[i] = "Flame of Silithus" end
for _, i in ipairs({181564}) do I[i] = "Flame of Silverpine" end
for _, i in ipairs({181562}) do I[i] = "Flame of Stonetalon" end
for _, i in ipairs({181332}) do I[i] = "Flame of Stormwind" end
for _, i in ipairs({181348}) do I[i] = "Flame of Stratholme" end
for _, i in ipairs({181337}) do I[i] = "Flame of Thunder Bluff" end
for _, i in ipairs({181343}) do I[i] = "Flame of Un'Goro" end
for _, i in ipairs({1770,19876}) do I[i] = "Flame of Uzel" end
for _, i in ipairs({1769}) do I[i] = "Flame of Veraz" end
for _, i in ipairs({181565}) do I[i] = "Flame of Westfall" end
for _, i in ipairs({181340}) do I[i] = "Flame of Winterspring" end
for _, i in ipairs({181560}) do I[i] = "Flame of the Barrens" end
for _, i in ipairs({181344}) do I[i] = "Flame of the Blasted Lands" end
for _, i in ipairs({181345}) do I[i] = "Flame of the Hinterlands" end
for _, i in ipairs({181338}) do I[i] = "Flame of the Plaguelands" end
for _, i in ipairs({181349}) do I[i] = "Flame of the Scholomance" end
for _, i in ipairs({181335}) do I[i] = "Flame of the Undercity" end
for _, i in ipairs({181567}) do I[i] = "Flame of the Wetlands" end
for _, i in ipairs({5619}) do I[i] = "Flawed Power Stone" end
for _, i in ipairs({5620,5621}) do I[i] = "Flawed Power Stones" end
for _, i in ipairs({3662,3690,3691,3693,3694,3695,3707,3710,3719,153470,153471,153472,153473}) do I[i] = "Food Crate" end
for _, i in ipairs({177205}) do I[i] = "Forestlord and the first Druids" end
for _, i in ipairs({175680}) do I[i] = "Fossilized Egg" end
for _, i in ipairs({181366}) do I[i] = "Four Horsemen Chest" end
for _, i in ipairs({175488}) do I[i] = "Fourth Mosh'aru Tablet" end
for _, i in ipairs({3768}) do I[i] = "Fragile - Do Not Drop" end
for _, i in ipairs({181073}) do I[i] = "Fragrant Cauldron" end
for _, i in ipairs({176353}) do I[i] = "Fras Siabi's Postbox" end
for _, i in ipairs({166863}) do I[i] = "Fresh Threshadon Carcass" end
for _, i in ipairs({180652}) do I[i] = "Freshly Dug Dirt" end
for _, i in ipairs({175324}) do I[i] = "Frostmaul Shards" end
for _, i in ipairs({175965}) do I[i] = "Frostwhisper's Embalming Fluid" end
for _, i in ipairs({179025}) do I[i] = "Frostwolf Banner" end
for _, i in ipairs({181287}) do I[i] = "Frozen Rune" end
for _, i in ipairs({61936}) do I[i] = "Fuel Control Valve" end
for _, i in ipairs({180392}) do I[i] = "Full Jug" end
for _, i in ipairs({290}) do I[i] = "Furlbrow's Wardrobe" end
for _, i in ipairs({177929}) do I[i] = "Gaea Dirt Mound" end
for _, i in ipairs({177926}) do I[i] = "Gaea Seed" end
for _, i in ipairs({180747}) do I[i] = "Gaily Wrapped Present" end
for _, i in ipairs({32569}) do I[i] = "Galen's Strongbox" end
for _, i in ipairs({129127,130126}) do I[i] = "Gallywix's Lockbox" end
for _, i in ipairs({124388}) do I[i] = "Garrett Family Chest" end
for _, i in ipairs({19595}) do I[i] = "Gatekeeper's Hold" end
for _, i in ipairs({3646}) do I[i] = "General Twinbraid's Strongbox" end
for _, i in ipairs({180746}) do I[i] = "Gently Shaken Gift" end
for _, i in ipairs({142144}) do I[i] = "Ghost Mushroom" end
for _, i in ipairs({2744,19017,19018,179264}) do I[i] = "Giant Clam" end
for _, i in ipairs({177784}) do I[i] = "Giant Softshell Clam" end
for _, i in ipairs({20727,23505}) do I[i] = "Gizmorium Shipping Crate" end
for _, i in ipairs({154357}) do I[i] = "Glinting Mud" end
for _, i in ipairs({175566}) do I[i] = "Gloom Weed" end
for _, i in ipairs({180514}) do I[i] = "Glyphed Crystal Prism" end
for _, i in ipairs({142211}) do I[i] = "Gnome Face 01" end
for _, i in ipairs({142210}) do I[i] = "Gnome Face 02" end
for _, i in ipairs({142209}) do I[i] = "Gnome Face 03" end
for _, i in ipairs({142208}) do I[i] = "Gnome Face 04" end
for _, i in ipairs({142213}) do I[i] = "Gnome Face 05" end
for _, i in ipairs({142212}) do I[i] = "Gnome Face 06" end
for _, i in ipairs({3236}) do I[i] = "Gnomish Toolbox" end
for _, i in ipairs({1734,150080,181109}) do I[i] = "Gold Vein" end
for _, i in ipairs({176583,176638,180167}) do I[i] = "Golden Sansam" end
for _, i in ipairs({2046}) do I[i] = "Goldthorn" end
for _, i in ipairs({180526}) do I[i] = "Gong of Bethekk" end
for _, i in ipairs({141832}) do I[i] = "Gong of Zul'Farrak" end
for _, i in ipairs({173266}) do I[i] = "Goodsteel Ledger" end
for _, i in ipairs({179564}) do I[i] = "Gordok Tribute" end
for _, i in ipairs({143980}) do I[i] = "Gordunni Scroll" end
for _, i in ipairs({177201}) do I[i] = "Grand Admiral Daelin Proudmoore" end
for _, i in ipairs({1628}) do I[i] = "Grave Moss" end
for _, i in ipairs({65407}) do I[i] = "Graznab's Machine" end
for _, i in ipairs({180466,180539,180559}) do I[i] = "Greater Wind Stone" end
for _, i in ipairs({164659,164779}) do I[i] = "Green Power Crystal" end
for _, i in ipairs({58,179426}) do I[i] = "Gri'lek the Wanderer" end
for _, i in ipairs({180358}) do I[i] = "Gri'lek, with the Iron Blood" end
for _, i in ipairs({165739}) do I[i] = "Grim Guzzler Boar" end
for _, i in ipairs({142145,176637}) do I[i] = "Gromsblood" end
for _, i in ipairs({181645}) do I[i] = "Gryphon Egg" end
for _, i in ipairs({269}) do I[i] = "Guarded Thunder Ale Barrel" end
for _, i in ipairs({1165}) do I[i] = "Gunther's Books" end
for _, i in ipairs({2560}) do I[i] = "Half-Buried Bottle" end
for _, i in ipairs({259}) do I[i] = "Half-buried Barrel" end
for _, i in ipairs({176581}) do I[i] = "Hand of Iruxos Crystal" end
for _, i in ipairs({180654}) do I[i] = "Hardpacked Snowdrift" end
for _, i in ipairs({20447}) do I[i] = "Harpy Foodstuffs" end
for _, i in ipairs({180372}) do I[i] = "Harvest Boar" end
for _, i in ipairs({180371}) do I[i] = "Harvest Fish" end
for _, i in ipairs({180370}) do I[i] = "Harvest Fruit" end
for _, i in ipairs({180373,180374}) do I[i] = "Harvest Nectar" end
for _, i in ipairs({177209}) do I[i] = "Hatred of the Centaur" end
for _, i in ipairs({180364}) do I[i] = "Hazza'rah, the Dreamweaver" end
for _, i in ipairs({165554}) do I[i] = "Heart of the Mountain" end
for _, i in ipairs({93192}) do I[i] = "Heartswood" end
for _, i in ipairs({1767}) do I[i] = "Helcular's Grave" end
for _, i in ipairs({19861}) do I[i] = "Henrig Lonebrow's Journal" end
for _, i in ipairs({175659}) do I[i] = "Here Lies King Terenas Menethil II" end
for _, i in ipairs({19024}) do I[i] = "Hidden Shrine" end
for _, i in ipairs({2039}) do I[i] = "Hidden Strongbox" end
for _, i in ipairs({175686}) do I[i] = "Highborne Astrolabe" end
for _, i in ipairs({175888,175891,175892,175893}) do I[i] = "Highborne Relic Fragment" end
for _, i in ipairs({175384}) do I[i] = "Highperch Wyvern Egg" end
for _, i in ipairs({144072}) do I[i] = "Highvale Notes" end
for _, i in ipairs({144071}) do I[i] = "Highvale Records" end
for _, i in ipairs({144073}) do I[i] = "Highvale Report" end
for _, i in ipairs({1761}) do I[i] = "Hillsbrad Proclamation" end
for _, i in ipairs({1759}) do I[i] = "Hillsbrad Town Registry" end
for _, i in ipairs({141931}) do I[i] = "Hippogryph Egg" end
for _, i in ipairs({180454}) do I[i] = "Hive'Ashi Glyphed Crystal" end
for _, i in ipairs({178553}) do I[i] = "Hive'Ashi Pod" end
for _, i in ipairs({180453}) do I[i] = "Hive'Regal Glyphed Crystal" end
for _, i in ipairs({180455}) do I[i] = "Hive'Zora Glyphed Crystal" end
for _, i in ipairs({149502}) do I[i] = "Hoard of the Black Dragonflight" end
for _, i in ipairs({178609}) do I[i] = "Holiday Snow" end
for _, i in ipairs({180715}) do I[i] = "Holly Preserver" end
for _, i in ipairs({178364,178388,178393,178943,178944,178945,178946,179285,179467,179472,179483,180060,180066,180070,180074,180078}) do I[i] = "Horde Banner" end
for _, i in ipairs({175688}) do I[i] = "Horde Catapult" end
for _, i in ipairs({105578}) do I[i] = "Horde Chest" end
for _, i in ipairs({179741}) do I[i] = "Horde Military Ranks" end
for _, i in ipairs({142191,178442}) do I[i] = "Horde Supply Crate" end
for _, i in ipairs({176208}) do I[i] = "Horgus' Skull" end
for _, i in ipairs({176090}) do I[i] = "Human Remains" end
for _, i in ipairs({152094}) do I[i] = "Hyacinth Mushroom" end
for _, i in ipairs({179551}) do I[i] = "Hydraxis' Coffer" end
for _, i in ipairs({181168,181169}) do I[i] = "Icebellow Furnace" end
for _, i in ipairs({176588}) do I[i] = "Icecap" end
for _, i in ipairs({175749}) do I[i] = "Icecrown and the Frozen Throne" end
for _, i in ipairs({148838}) do I[i] = "Idol of Hakkar" end
for _, i in ipairs({3237}) do I[i] = "Imprisoned Darkspear" end
for _, i in ipairs({181062}) do I[i] = "In Loving Memory" end
for _, i in ipairs({178965}) do I[i] = "Incantation of Celebras" end
for _, i in ipairs({175928}) do I[i] = "Incendia Agave" end
for _, i in ipairs({180642}) do I[i] = "Inconspicuous Crate" end
for _, i in ipairs({175785}) do I[i] = "Inconspicuous Documents" end
for _, i in ipairs({142189}) do I[i] = "Inconspicuous Landmark" end
for _, i in ipairs({19903}) do I[i] = "Indurium Mineral Vein" end
for _, i in ipairs({112948}) do I[i] = "Intrepid's Locked Strongbox" end
for _, i in ipairs({2701}) do I[i] = "Iridescent Shards" end
for _, i in ipairs({89634}) do I[i] = "Iron Coral" end
for _, i in ipairs({1735}) do I[i] = "Iron Deposit" end
for _, i in ipairs({85562}) do I[i] = "Ironband's Strongbox" end
for _, i in ipairs({178785}) do I[i] = "Irondeep Supplies" end
for _, i in ipairs({175736}) do I[i] = "Ironforge - the Awakening of the Dwarves" end
for _, i in ipairs({179125}) do I[i] = "Izzy's Holdings" end
for _, i in ipairs({178526}) do I[i] = "James' Journal" end
for _, i in ipairs({175894}) do I[i] = "Janice's Parcel" end
for _, i in ipairs({175628,175629}) do I[i] = "Jaron's Supplies" end
for _, i in ipairs({175586}) do I[i] = "Jaron's Wagon" end
for _, i in ipairs({91138}) do I[i] = "Jordan's Hammer" end
for _, i in ipairs({176145}) do I[i] = "Joseph Redpath's Monument" end
for _, i in ipairs({177544}) do I[i] = "Joseph's Chest" end
for _, i in ipairs({102986}) do I[i] = "Ju-Ju Heap" end
for _, i in ipairs({151286}) do I[i] = "Kaldorei Tome of Summoning" end
for _, i in ipairs({35251}) do I[i] = "Karnitol's Chest" end
for _, i in ipairs({176630}) do I[i] = "Keepsake of Remembrance" end
for _, i in ipairs({180570,180575}) do I[i] = "Keg" end
for _, i in ipairs({1727}) do I[i] = "Keg of Shindigger Stout" end
for _, i in ipairs({181444}) do I[i] = "Kel'Thuzad Trigger" end
for _, i in ipairs({175754}) do I[i] = "Kel'Thuzad and the Forming of the Scourge" end
for _, i in ipairs({176634}) do I[i] = "Kerlonian's Chest" end
for _, i in ipairs({2688,124371}) do I[i] = "Keystone" end
for _, i in ipairs({2043}) do I[i] = "Khadgar's Whisker" end
for _, i in ipairs({175741}) do I[i] = "Kil'jaeden and the Shadow Pact" end
for _, i in ipairs({153123}) do I[i] = "Kim'jael's Equipment" end
for _, i in ipairs({177200}) do I[i] = "King Llane I of the House of Wrynn" end
for _, i in ipairs({176352}) do I[i] = "King's Square Postbox" end
for _, i in ipairs({1624}) do I[i] = "Kingsblood" end
for _, i in ipairs({179501}) do I[i] = "Knot Thimblejack's Cache" end
for _, i in ipairs({176750,176751,176752}) do I[i] = "Kodo Bones" end
for _, i in ipairs({152608,152618}) do I[i] = "Kolkar's Booty" end
for _, i in ipairs({3642}) do I[i] = "Kolkars' Booty" end
for _, i in ipairs({124389}) do I[i] = "Krom Stoutarm's Chest" end
for _, i in ipairs({263,264}) do I[i] = "Kurzen Supplies" end
for _, i in ipairs({3640}) do I[i] = "Laden Mushroom" end
for _, i in ipairs({179910}) do I[i] = "Lard's Picnic Basket" end
for _, i in ipairs({75293}) do I[i] = "Large Battered Chest" end
for _, i in ipairs({164953}) do I[i] = "Large Leather Backpacks" end
for _, i in ipairs({131978,153468,153469}) do I[i] = "Large Mithril Bound Chest" end
for _, i in ipairs({180690}) do I[i] = "Large Scarab Coffer" end
for _, i in ipairs({74448,75298,75299,75300,153462,153463,153464}) do I[i] = "Large Solid Chest" end
for _, i in ipairs({177464}) do I[i] = "Large Termite Mound" end
for _, i in ipairs({2657}) do I[i] = "Legends of the Earth" end
for _, i in ipairs({180456,180518,180529,180544,180549,180564}) do I[i] = "Lesser Wind Stone" end
for _, i in ipairs({175751}) do I[i] = "Lethargy of the Orcs" end
for _, i in ipairs({18899,18900,18901,90567,101811,101812,101852,101853,101855,104589,179148,183517,183518,185123}) do I[i] = "Lever" end
for _, i in ipairs({2041}) do I[i] = "Liferoot" end
for _, i in ipairs({1557}) do I[i] = "Lillith's Dinner Table" end
for _, i in ipairs({175924}) do I[i] = "Locked Cabinet" end
for _, i in ipairs({33,184304}) do I[i] = "Locked Chest" end
for _, i in ipairs({1721,1722,1764}) do I[i] = "Locked ball and chain" end
for _, i in ipairs({20985}) do I[i] = "Loose Dirt" end
for _, i in ipairs({177240}) do I[i] = "Loose Dirt Mound" end
for _, i in ipairs({331}) do I[i] = "Loose Soil" end
for _, i in ipairs({181682,181955}) do I[i] = "Lordaeron Shrine" end
for _, i in ipairs({178125}) do I[i] = "Lotharian Lotus" end
for _, i in ipairs({121264}) do I[i] = "Lucius's Lockbox" end
for _, i in ipairs({15002,180090}) do I[i] = "Lumber Mill Banner" end
for _, i in ipairs({181686,181687}) do I[i] = "Lumber Pile" end
for _, i in ipairs({177750}) do I[i] = "Lunar Fungal Bloom" end
for _, i in ipairs({272}) do I[i] = "MacGrann's Meat Locker" end
for _, i in ipairs({1620,3727}) do I[i] = "Mageroyal" end
for _, i in ipairs({2707}) do I[i] = "Maiden's Folly Charts" end
for _, i in ipairs({2709}) do I[i] = "Maiden's Folly Log" end
for _, i in ipairs({4072}) do I[i] = "Main Control Valve" end
for _, i in ipairs({50961}) do I[i] = "Malem Chest" end
for _, i in ipairs({176112}) do I[i] = "Malor's Strongbox" end
for _, i in ipairs({175927}) do I[i] = "Malyfous's Catalogue" end
for _, i in ipairs({177804,177805,177806}) do I[i] = "Mangled Human Remains" end
for _, i in ipairs({176346}) do I[i] = "Market Row Postbox" end
for _, i in ipairs({178090}) do I[i] = "Marla's Grave" end
for _, i in ipairs({1562}) do I[i] = "Marshal Haggard's Chest" end
for _, i in ipairs({149036}) do I[i] = "Marvon's Chest" end
for _, i in ipairs({12654,13360,13872}) do I[i] = "Mathystra Relic" end
for _, i in ipairs({142345}) do I[i] = "Matrix Punchograph 3005-A" end
for _, i in ipairs({142475}) do I[i] = "Matrix Punchograph 3005-B" end
for _, i in ipairs({142476}) do I[i] = "Matrix Punchograph 3005-C" end
for _, i in ipairs({142696}) do I[i] = "Matrix Punchograph 3005-D" end
for _, i in ipairs({104593}) do I[i] = "Mausoleum Trigger" end
for _, i in ipairs({178827}) do I[i] = "Meeting" end
for _, i in ipairs({178824,178825,178826,178828,178829,178831,178832,178833,178834,178844,178845,178884,179554,179555,179584,179585,179586,179587,179595,179596,185321,185433,186251}) do I[i] = "Meeting Stone" end
for _, i in ipairs({139852}) do I[i] = "Memorial to Sully Balloo" end
for _, i in ipairs({176631}) do I[i] = "Menethil's Gift" end
for _, i in ipairs({179707}) do I[i] = "Military Ranks of the Horde & Alliance" end
for _, i in ipairs({161557}) do I[i] = "Milly's Harvest" end
for _, i in ipairs({15001,180091}) do I[i] = "Mine Banner" end
for _, i in ipairs({271}) do I[i] = "Miners' League Crates" end
for _, i in ipairs({1726}) do I[i] = "Missing: Corporal Keeshan" end
for _, i in ipairs({186264}) do I[i] = "Missing: Kyle" end
for _, i in ipairs({175166}) do I[i] = "Mist Veil's Lockbox" end
for _, i in ipairs({177207}) do I[i] = "Mists of Dawn" end
for _, i in ipairs({2040,150079,176645}) do I[i] = "Mithril Deposit" end
for _, i in ipairs({19905}) do I[i] = "Mok'Morokk's Grog" end
for _, i in ipairs({19904}) do I[i] = "Mok'Morokk's Snuff" end
for _, i in ipairs({19906}) do I[i] = "Mok'Morokk's Strongbox" end
for _, i in ipairs({164689}) do I[i] = "Monument of Franclorn Forgewright" end
for _, i in ipairs({21004}) do I[i] = "Monument to Grom Hellscream" end
for _, i in ipairs({57}) do I[i] = "Moon Over the Vale" end
for _, i in ipairs({152095}) do I[i] = "Moonpetal Lily" end
for _, i in ipairs({175407}) do I[i] = "Moontouched Feather" end
for _, i in ipairs({179493,179497}) do I[i] = "Mossy Footlocker" end
for _, i in ipairs({19030,177675,181758}) do I[i] = "Mound of Dirt" end
for _, i in ipairs({59}) do I[i] = "Mound of loose dirt" end
for _, i in ipairs({175729}) do I[i] = "Mount Hyjal and Illidan's Gift" end
for _, i in ipairs({176586,176640,180166}) do I[i] = "Mountain Silversage" end
for _, i in ipairs({138497}) do I[i] = "Mouthpiece Mount" end
for _, i in ipairs({175926}) do I[i] = "Mrs. Dalson's Diary" end
for _, i in ipairs({180369}) do I[i] = "Muddy Churning Waters" end
for _, i in ipairs({2084}) do I[i] = "Musquash Root" end
for _, i in ipairs({2555}) do I[i] = "Musty Scroll" end
for _, i in ipairs({180024}) do I[i] = "Mysterious Deadmines Chest" end
for _, i in ipairs({180025}) do I[i] = "Mysterious Eastvale Haystack" end
for _, i in ipairs({175524}) do I[i] = "Mysterious Red Crystal" end
for _, i in ipairs({180056,211051}) do I[i] = "Mysterious Tree Stump" end
for _, i in ipairs({180055}) do I[i] = "Mysterious Wailing Caverns Chest" end
for _, i in ipairs({19284}) do I[i] = "Mythology of the Titans" end
for _, i in ipairs({178247}) do I[i] = "Naga Brazier" end
for _, i in ipairs({181575,181576,181577,181578}) do I[i] = "Naxxramas Portal" end
for _, i in ipairs({181154}) do I[i] = "Necropolis" end
for _, i in ipairs({181373}) do I[i] = "Necropolis (scale 1.5)" end
for _, i in ipairs({181374}) do I[i] = "Necropolis (scale 2.0)" end
for _, i in ipairs({181215}) do I[i] = "Necropolis (scale 2.5)" end
for _, i in ipairs({181223}) do I[i] = "Necropolis (scale 3.5)" end
for _, i in ipairs({74731,180435}) do I[i] = "Noggle's Satchel" end
for _, i in ipairs({164955}) do I[i] = "Northern Crystal Pylon" end
for _, i in ipairs({177490,177492}) do I[i] = "Northridge Lumber Mill Crate" end
for _, i in ipairs({175571}) do I[i] = "Ogre Coup Summoning Circle" end
for _, i in ipairs({179499}) do I[i] = "Ogre Tannin Basket" end
for _, i in ipairs({3643}) do I[i] = "Old Footlocker" end
for _, i in ipairs({175763}) do I[i] = "Old Hatreds - The Colonization of Kalimdor" end
for _, i in ipairs({34}) do I[i] = "Old Jug" end
for _, i in ipairs({31}) do I[i] = "Old Lion Statue" end
for _, i in ipairs({176944}) do I[i] = "Old Treasure Chest" end
for _, i in ipairs({178325}) do I[i] = "Open To Pass Your Rite." end
for _, i in ipairs({179879}) do I[i] = "Orb of Command" end
for _, i in ipairs({177808}) do I[i] = "Orb of Domination" end
for _, i in ipairs({175779}) do I[i] = "Orman of Stromgarde" end
for _, i in ipairs({164910}) do I[i] = "Ornate Chest" end
for _, i in ipairs({175925,180006}) do I[i] = "Outhouse" end
for _, i in ipairs({176116}) do I[i] = "Pamela's Doll's Head" end
for _, i in ipairs({176142}) do I[i] = "Pamela's Doll's Left Side" end
for _, i in ipairs({176143}) do I[i] = "Pamela's Doll's Right Side" end
for _, i in ipairs({19878}) do I[i] = "Parts Crate" end
for _, i in ipairs({180753}) do I[i] = "Patch of Elemental Water" end
for _, i in ipairs({1618,3724}) do I[i] = "Peacebloom" end
for _, i in ipairs({37098}) do I[i] = "Perrine's Chest" end
for _, i in ipairs({177604,179914}) do I[i] = "Pile of Bones" end
for _, i in ipairs({179915}) do I[i] = "Pile of Skulls" end
for _, i in ipairs({2858}) do I[i] = "Pillar of Amethyst" end
for _, i in ipairs({2842}) do I[i] = "Pillar of Diamond" end
for _, i in ipairs({2848}) do I[i] = "Pillar of Opal" end
for _, i in ipairs({13949}) do I[i] = "Pitted Iron Chest" end
for _, i in ipairs({176587,176641}) do I[i] = "Plaguebloom" end
for _, i in ipairs({17282}) do I[i] = "Plant Bundle" end
for _, i in ipairs({176360}) do I[i] = "Postbox Parcel" end
for _, i in ipairs({178244,178245,178246}) do I[i] = "Practice Lockbox" end
for _, i in ipairs({176248}) do I[i] = "Premium Siabi Tobacco" end
for _, i in ipairs({175685,177222}) do I[i] = "Pteradon Skeleton" end
for _, i in ipairs({2068}) do I[i] = "Pupellyverbos Port" end
for _, i in ipairs({142140,180165}) do I[i] = "Purple Lotus" end
for _, i in ipairs({177747}) do I[i] = "Quel'Thalas Registry" end
for _, i in ipairs({177786}) do I[i] = "Rackmore's Chest" end
for _, i in ipairs({177787}) do I[i] = "Rackmore's Log" end
for _, i in ipairs({25331}) do I[i] = "Ranger Captain Alleria Windrunner" end
for _, i in ipairs({26449}) do I[i] = "Recombobulator" end
for _, i in ipairs({164660,164780}) do I[i] = "Red Power Crystal" end
for _, i in ipairs({6906}) do I[i] = "Red Raptor Nest" end
for _, i in ipairs({103820}) do I[i] = "Red Rocket" end
for _, i in ipairs({19879}) do I[i] = "Red Soulgem" end
for _, i in ipairs({176207}) do I[i] = "Redpath's Shield" end
for _, i in ipairs({61935}) do I[i] = "Regulator Valve" end
for _, i in ipairs({160836}) do I[i] = "Relic Coffer" end
for _, i in ipairs({176544}) do I[i] = "Remains of Eva Sarkhoff" end
for _, i in ipairs({176545}) do I[i] = "Remains of Lucien Sarkhoff" end
for _, i in ipairs({180365}) do I[i] = "Renataki, of the Thousand Blades" end
for _, i in ipairs({251,161521}) do I[i] = "Research Equipment" end
for _, i in ipairs({178145}) do I[i] = "Resonite Cask" end
for _, i in ipairs({178104,178105,178106}) do I[i] = "Resonite Crystal" end
for _, i in ipairs({181605}) do I[i] = "Ribbon Pole" end
for _, i in ipairs({175404}) do I[i] = "Rich Thorium Vein" end
for _, i in ipairs({142127}) do I[i] = "Rin'ji's Secret" end
for _, i in ipairs({2883}) do I[i] = "Ripe Pumpkin" end
for _, i in ipairs({175760}) do I[i] = "Rise of the Blood Elves" end
for _, i in ipairs({175742}) do I[i] = "Rise of the Horde" end
for _, i in ipairs({176188}) do I[i] = "Ritual Candle" end
for _, i in ipairs({103664,104592}) do I[i] = "Rituals of Power" end
for _, i in ipairs({179888}) do I[i] = "Rizzle's Guarded Plans" end
for _, i in ipairs({20805}) do I[i] = "Rizzle's Unguarded Plans" end
for _, i in ipairs({175681}) do I[i] = "Roc Talon" end
for _, i in ipairs({179909}) do I[i] = "Rock of Durotan" end
for _, i in ipairs({148842}) do I[i] = "Roland's Mana Gem" end
for _, i in ipairs({56}) do I[i] = "Rolf's corpse" end
for _, i in ipairs({175197}) do I[i] = "Room 1 Rune" end
for _, i in ipairs({175199}) do I[i] = "Room 2 Rune" end
for _, i in ipairs({175195}) do I[i] = "Room 3 Rune" end
for _, i in ipairs({175200}) do I[i] = "Room 4 Rune" end
for _, i in ipairs({175198}) do I[i] = "Room 5 Rune" end
for _, i in ipairs({175196}) do I[i] = "Room 6 Rune" end
for _, i in ipairs({175194}) do I[i] = "Room 7 Rune" end
for _, i in ipairs({175886}) do I[i] = "Roughshod Pike" end
for _, i in ipairs({2289}) do I[i] = "Ruined Lifeboat" end
for _, i in ipairs({149481}) do I[i] = "Rune of Beth'Amara" end
for _, i in ipairs({176955}) do I[i] = "Rune of Blaz" end
for _, i in ipairs({149480}) do I[i] = "Rune of Jin'yael" end
for _, i in ipairs({176951}) do I[i] = "Rune of Koro" end
for _, i in ipairs({176956}) do I[i] = "Rune of Kress" end
for _, i in ipairs({149482}) do I[i] = "Rune of Markri" end
for _, i in ipairs({176953}) do I[i] = "Rune of Mazj" end
for _, i in ipairs({176163,176166}) do I[i] = "Rune of Mazthoril" end
for _, i in ipairs({176957}) do I[i] = "Rune of Mohn" end
for _, i in ipairs({149483}) do I[i] = "Rune of Sael'hai" end
for _, i in ipairs({176954}) do I[i] = "Rune of Theri" end
for _, i in ipairs({176952}) do I[i] = "Rune of Zeth" end
for _, i in ipairs({2715}) do I[i] = "Runed Pedestal" end
for _, i in ipairs({50936}) do I[i] = "Sack of Barley" end
for _, i in ipairs({50935}) do I[i] = "Sack of Corn" end
for _, i in ipairs({22245}) do I[i] = "Sack of Meat" end
for _, i in ipairs({2724}) do I[i] = "Sack of Oats" end
for _, i in ipairs({50937}) do I[i] = "Sack of Rye" end
for _, i in ipairs({175944}) do I[i] = "Sacred Fire of Life" end
for _, i in ipairs({176356}) do I[i] = "Sacred Highborne Writings" end
for _, i in ipairs({180656,180663}) do I[i] = "Sagefish School" end
for _, i in ipairs({180503}) do I[i] = "Sandy Cookbook" end
for _, i in ipairs({178184,178185,178186}) do I[i] = "Sapphire of Aku'Mai" end
for _, i in ipairs({175724}) do I[i] = "Sargeras and the Betrayal" end
for _, i in ipairs({175684}) do I[i] = "Saurial Egg" end
for _, i in ipairs({11714}) do I[i] = "Scaber Stalk" end
for _, i in ipairs({180691}) do I[i] = "Scarab Coffer" end
for _, i in ipairs({176245}) do I[i] = "Scarlet Archive" end
for _, i in ipairs({176216,176217}) do I[i] = "Scarlet Cannon" end
for _, i in ipairs({179498}) do I[i] = "Scarlet Footlocker" end
for _, i in ipairs({28604}) do I[i] = "Scattered Crate" end
for _, i in ipairs({179552}) do I[i] = "Schematic: Field Repair Bot 74A" end
for _, i in ipairs({180658}) do I[i] = "School of Deviate Fish" end
for _, i in ipairs({180184}) do I[i] = "School of Fish" end
for _, i in ipairs({180248}) do I[i] = "School of Tastyfish" end
for _, i in ipairs({176361,176392,176393,177289}) do I[i] = "Scourge Cauldron" end
for _, i in ipairs({176249}) do I[i] = "Scourge Data" end
for _, i in ipairs({144053}) do I[i] = "Scrimshank's Surveying Gear" end
for _, i in ipairs({2933}) do I[i] = "Seal of the Earth" end
for _, i in ipairs({142151}) do I[i] = "Sealed Barrel" end
for _, i in ipairs({1561}) do I[i] = "Sealed Crate" end
for _, i in ipairs({2908}) do I[i] = "Sealed Supply Crate" end
for _, i in ipairs({144067}) do I[i] = "Second Witherbark Cage" end
for _, i in ipairs({179826}) do I[i] = "Secret Plans: Fiery Flux" end
for _, i in ipairs({161495}) do I[i] = "Secret Safe" end
for _, i in ipairs({149025,149030,149031,149032}) do I[i] = "Sentry Brazier" end
for _, i in ipairs({177673}) do I[i] = "Serpent Statue" end
for _, i in ipairs({13891,19535}) do I[i] = "Serpentbloom" end
for _, i in ipairs({180404}) do I[i] = "Servant of the Hand Summoning Circle" end
for _, i in ipairs({160445}) do I[i] = "Sha'ni Proudtusk's Remains" end
for _, i in ipairs({174744,174745}) do I[i] = "Shadowforge Brazier" end
for _, i in ipairs({113757}) do I[i] = "Shadowforge Cache" end
for _, i in ipairs({1599,128308,128403,177677}) do I[i] = "Shallow Grave" end
for _, i in ipairs({63674,100028,100035,101748,101749,101750,101751}) do I[i] = "Shaman Shrine" end
for _, i in ipairs({2705,138492}) do I[i] = "Shards of Myzrael" end
for _, i in ipairs({144070}) do I[i] = "Sharpbeak's Cage" end
for _, i in ipairs({176209}) do I[i] = "Shattered Sword of Marduk" end
for _, i in ipairs({144054}) do I[i] = "Shay's Chest" end
for _, i in ipairs({276}) do I[i] = "Shimmerweed Basket" end
for _, i in ipairs({1736}) do I[i] = "Shipment of Iron" end
for _, i in ipairs({94039,103015}) do I[i] = "Shrine of Gelihast" end
for _, i in ipairs({178444}) do I[i] = "Shrine of Sha'gri" end
for _, i in ipairs({22234}) do I[i] = "Signal Torch" end
for _, i in ipairs({3685}) do I[i] = "Silithid Mound" end
for _, i in ipairs({181598}) do I[i] = "Silithyst Geyser" end
for _, i in ipairs({175165}) do I[i] = "Silver Dawning's Lockbox" end
for _, i in ipairs({1733,105569}) do I[i] = "Silver Vein" end
for _, i in ipairs({1617,3725}) do I[i] = "Silverleaf" end
for _, i in ipairs({179785,179830}) do I[i] = "Silverwing Flag" end
for _, i in ipairs({175704}) do I[i] = "Singed Letter" end
for _, i in ipairs({175950}) do I[i] = "Sixth Mosh'aru Tablet" end
for _, i in ipairs({179544}) do I[i] = "Skeletal Remains of Kariel Winthalus" end
for _, i in ipairs({176189}) do I[i] = "Skeletal Sea Turtle" end
for _, i in ipairs({179908}) do I[i] = "Slagtree's Lost Tools" end
for _, i in ipairs({19596}) do I[i] = "Sleepers' Cache" end
for _, i in ipairs({175802}) do I[i] = "Small Lockbox" end
for _, i in ipairs({324,150082,176643}) do I[i] = "Small Thorium Vein" end
for _, i in ipairs({180418}) do I[i] = "Snowfall Banner" end
for _, i in ipairs({68865}) do I[i] = "Snufflenose Command Sticks" end
for _, i in ipairs({21530}) do I[i] = "Snufflenose Owner's Manual" end
for _, i in ipairs({160840}) do I[i] = "Soft Dirt Mound" end
for _, i in ipairs({142179}) do I[i] = "Solarsal Gazebo" end
for _, i in ipairs({2850,2852,2855,2857,4149,153451,153453,153454}) do I[i] = "Solid Chest" end
for _, i in ipairs({177204}) do I[i] = "Sorrow of the Earthmother" end
for _, i in ipairs({164869}) do I[i] = "Spectral Chalice" end
for _, i in ipairs({141980}) do I[i] = "Spectral Lockbox" end
for _, i in ipairs({179985}) do I[i] = "Spider Egg" end
for _, i in ipairs({2708}) do I[i] = "Spirit of Silverpine Charts" end
for _, i in ipairs({2710}) do I[i] = "Spirit of Silverpine Log" end
for _, i in ipairs({140911}) do I[i] = "Spool of Light Chartreuse Silk Thread" end
for _, i in ipairs({7510}) do I[i] = "Sprouted Frond" end
for _, i in ipairs({15005,180087}) do I[i] = "Stable Banner" end
for _, i in ipairs({1720}) do I[i] = "Stanley's Dish" end
for _, i in ipairs({19016}) do I[i] = "Stardust Covered Bush" end
for _, i in ipairs({83763}) do I[i] = "Stolen Books" end
for _, i in ipairs({142181,182485}) do I[i] = "Stolen Cargo" end
for _, i in ipairs({178504}) do I[i] = "Stolen Chest" end
for _, i in ipairs({58369}) do I[i] = "Stolen Iron Chest" end
for _, i in ipairs({147557}) do I[i] = "Stolen Silver" end
for _, i in ipairs({3290}) do I[i] = "Stolen Supply Sack" end
for _, i in ipairs({141812,141857,141858,141859}) do I[i] = "Stone of Binding" end
for _, i in ipairs({2691}) do I[i] = "Stone of East Binding" end
for _, i in ipairs({2702}) do I[i] = "Stone of Inner Binding" end
for _, i in ipairs({2690}) do I[i] = "Stone of Outer Binding" end
for _, i in ipairs({20923}) do I[i] = "Stone of Remembrance" end
for _, i in ipairs({2689}) do I[i] = "Stone of West Binding" end
for _, i in ipairs({1560}) do I[i] = "Storage Chest" end
for _, i in ipairs({179024}) do I[i] = "Stormpike Banner" end
for _, i in ipairs({6752}) do I[i] = "Strange Fronded Plant" end
for _, i in ipairs({6751}) do I[i] = "Strange Fruited Plant" end
for _, i in ipairs({177790,177792,177794,177844}) do I[i] = "Strange Lockbox" end
for _, i in ipairs({2045}) do I[i] = "Stranglekelp" end
for _, i in ipairs({181085}) do I[i] = "Stratholme Supply Crate" end
for _, i in ipairs({24798}) do I[i] = "Sundried Driftwood" end
for _, i in ipairs({142142,176636,180164}) do I[i] = "Sungrass" end
for _, i in ipairs({32}) do I[i] = "Sunken Chest" end
for _, i in ipairs({89635}) do I[i] = "Sunscorched Shell" end
for _, i in ipairs({175757}) do I[i] = "Sunwell - The Fall of Quel'Thalas" end
for _, i in ipairs({166872,175534,175535,175536,175537,176224,176304,176307,176308,176309}) do I[i] = "Supply Crate" end
for _, i in ipairs({257}) do I[i] = "Suspicious Barrel" end
for _, i in ipairs({187273}) do I[i] = "Suspicious Hoofprint" end
for _, i in ipairs({144181}) do I[i] = "Sword of the Barbarian King" end
for _, i in ipairs({177264}) do I[i] = "Symbol of Lost Honor" end
for _, i in ipairs({1738,1739,1740,186420}) do I[i] = "Syndicate Documents" end
for _, i in ipairs({148516}) do I[i] = "Tablet of Beth'Amara" end
for _, i in ipairs({148513}) do I[i] = "Tablet of Jin'yael" end
for _, i in ipairs({180368}) do I[i] = "Tablet of Madness" end
for _, i in ipairs({148514}) do I[i] = "Tablet of Markri" end
for _, i in ipairs({148515}) do I[i] = "Tablet of Sael'hai" end
for _, i in ipairs({142715}) do I[i] = "Tablet of Theka" end
for _, i in ipairs({142088}) do I[i] = "Tablet of Will" end
for _, i in ipairs({169294}) do I[i] = "Tablet of the Seven" end
for _, i in ipairs({3240}) do I[i] = "Taillasher Eggs" end
for _, i in ipairs({181916}) do I[i] = "Tainted Wood" end
for _, i in ipairs({126158}) do I[i] = "Tallonkai's Dresser" end
for _, i in ipairs({19599}) do I[i] = "Talon Den Hoard" end
for _, i in ipairs({177927}) do I[i] = "Tammra Gaea Sapling" end
for _, i in ipairs({22246}) do I[i] = "Tear of Theradras" end
for _, i in ipairs({321}) do I[i] = "Tear of Tilloa" end
for _, i in ipairs({177491}) do I[i] = "Termite Barrel" end
for _, i in ipairs({153556}) do I[i] = "Thaurissan Relic" end
for _, i in ipairs({178087}) do I[i] = "Thazz'ril's Pick" end
for _, i in ipairs({175746}) do I[i] = "The Alliance of Lordaeron" end
for _, i in ipairs({3525}) do I[i] = "The Altar of Fire" end
for _, i in ipairs({176317}) do I[i] = "The Argent Hold" end
for _, i in ipairs({175658}) do I[i] = "The Armor of Mannoroth" end
for _, i in ipairs({175750}) do I[i] = "The Battle of Grim Batol" end
for _, i in ipairs({175759}) do I[i] = "The Betrayer Ascendant" end
for _, i in ipairs({175748}) do I[i] = "The Birth of the Lich King" end
for _, i in ipairs({36738}) do I[i] = "The Book of Ur" end
for _, i in ipairs({50982}) do I[i] = "The Charred Oak" end
for _, i in ipairs({175745}) do I[i] = "The Dark Portal and the Fall of Stormwind" end
for _, i in ipairs({176484}) do I[i] = "The Deed to Brill" end
for _, i in ipairs({176485}) do I[i] = "The Deed to Caer Darrow" end
for _, i in ipairs({176486}) do I[i] = "The Deed to Southshore" end
for _, i in ipairs({176487}) do I[i] = "The Deed to Tarren Mill" end
for _, i in ipairs({3524}) do I[i] = "The Demon Seed" end
for _, i in ipairs({131474}) do I[i] = "The Discs of Norgannon" end
for _, i in ipairs({54}) do I[i] = "The Emperor's Tomb" end
for _, i in ipairs({17189}) do I[i] = "The Fall of Ameth'Aran" end
for _, i in ipairs({175733}) do I[i] = "The Founding of Quel'Thalas" end
for _, i in ipairs({175735}) do I[i] = "The Guardians of Tirisfal" end
for _, i in ipairs({759}) do I[i] = "The Holy Spring" end
for _, i in ipairs({175747}) do I[i] = "The Invasion of Draenor" end
for _, i in ipairs({123462}) do I[i] = "The Jewel of the Southsea" end
for _, i in ipairs({21583}) do I[i] = "The Kaldorei and the Well of Eternity" end
for _, i in ipairs({175740}) do I[i] = "The Last Guardian" end
for _, i in ipairs({17188}) do I[i] = "The Lay of Ameth'Aran" end
for _, i in ipairs({20725}) do I[i] = "The Legacy of the Aspects" end
for _, i in ipairs({175762}) do I[i] = "The Lich King Triumphant" end
for _, i in ipairs({175752}) do I[i] = "The New Horde" end
for _, i in ipairs({175725}) do I[i] = "The Old Gods and the Ordering of Azeroth" end
for _, i in ipairs({179545}) do I[i] = "The Prince's Chest" end
for _, i in ipairs({180717,180718}) do I[i] = "The Scarab Gong" end
for _, i in ipairs({175756}) do I[i] = "The Scourge of Lordaeron" end
for _, i in ipairs({175732}) do I[i] = "The Sentinels and the Long Vigil" end
for _, i in ipairs({175737}) do I[i] = "The Seven Kingdoms" end
for _, i in ipairs({179881,179882}) do I[i] = "The Severed Head of Nefarian" end
for _, i in ipairs({179556,179558}) do I[i] = "The Severed Head of Onyxia" end
for _, i in ipairs({175679}) do I[i] = "The Skull of Tyrannistrasz" end
for _, i in ipairs({142487,175084,175085,175087}) do I[i] = "The Sparklematic 5200" end
for _, i in ipairs({175854}) do I[i] = "The Twin Empires" end
for _, i in ipairs({175727}) do I[i] = "The War of the Ancients" end
for _, i in ipairs({177208}) do I[i] = "The White Stag and the Moon" end
for _, i in ipairs({180433}) do I[i] = "The Wickerman" end
for _, i in ipairs({175730}) do I[i] = "The World Tree and the Emerald Dream" end
for _, i in ipairs({183356}) do I[i] = "Theatric Lightning" end
for _, i in ipairs({21042}) do I[i] = "Theramore Guard Badge" end
for _, i in ipairs({142477}) do I[i] = "Thermaplugg's Safe" end
for _, i in ipairs({175487}) do I[i] = "Third Mosh'aru Tablet" end
for _, i in ipairs({144068}) do I[i] = "Third Witherbark Cage" end
for _, i in ipairs({164911}) do I[i] = "Thunderbrew Lager Keg" end
for _, i in ipairs({180748}) do I[i] = "Ticking Present" end
for _, i in ipairs({4608}) do I[i] = "Timberling Sprout" end
for _, i in ipairs({1732,2054,3764,103711,181249}) do I[i] = "Tin Vein" end
for _, i in ipairs({375}) do I[i] = "Tirisfal Pumpkin" end
for _, i in ipairs({180754}) do I[i] = "Toasting Goblet" end
for _, i in ipairs({19027}) do I[i] = "Tome of Mel'Thandris" end
for _, i in ipairs({92013}) do I[i] = "Tome of the Cabal" end
for _, i in ipairs({180524}) do I[i] = "Tonk Control Console" end
for _, i in ipairs({161752,177726}) do I[i] = "Tool Bucket" end
for _, i in ipairs({175683}) do I[i] = "Toothgnasher's Skeleton" end
for _, i in ipairs({97701,176767,177385,179507,179508,179509,179510,179513}) do I[i] = "Torch" end
for _, i in ipairs({149047}) do I[i] = "Torch of Retribution" end
for _, i in ipairs({177667}) do I[i] = "Torn Scroll" end
for _, i in ipairs({182106}) do I[i] = "Tower Banner" end
for _, i in ipairs({179517}) do I[i] = "Treasure of the Shen'dralar" end
for _, i in ipairs({2716}) do I[i] = "Trelane's Chest" end
for _, i in ipairs({2717}) do I[i] = "Trelane's Footlocker" end
for _, i in ipairs({2718}) do I[i] = "Trelane's Lockbox" end
for _, i in ipairs({178144}) do I[i] = "Troll Chest" end
for _, i in ipairs({177224}) do I[i] = "Troll Drum Sound Object" end
for _, i in ipairs({180252}) do I[i] = "Troll Hero Lightning" end
for _, i in ipairs({180385}) do I[i] = "Troll Hero Portal Sound" end
for _, i in ipairs({2703}) do I[i] = "Trollbane's Tomb" end
for _, i in ipairs({2047,150081,181108}) do I[i] = "Truesilver Deposit" end
for _, i in ipairs({148506}) do I[i] = "Twilight Artifact" end
for _, i in ipairs({180436,180501,180583}) do I[i] = "Twilight Tablet Fragment" end
for _, i in ipairs({12144,12666}) do I[i] = "Twilight Tome" end
for _, i in ipairs({175687}) do I[i] = "Uldaman Relics" end
for _, i in ipairs({175689}) do I[i] = "Uldaman Reliefs" end
for _, i in ipairs({142343}) do I[i] = "Uldum Pedestal" end
for _, i in ipairs({157936}) do I[i] = "Un'Goro Dirt Pile" end
for _, i in ipairs({169217,172619}) do I[i] = "Un'Goro Flat Rock" end
for _, i in ipairs({175787,175788}) do I[i] = "Unadorned Stake" end
for _, i in ipairs({181173}) do I[i] = "Undead Fire" end
for _, i in ipairs({177287}) do I[i] = "Unfinished Painting" end
for _, i in ipairs({176089}) do I[i] = "Unfired Plate Gauntlets" end
for _, i in ipairs({175970}) do I[i] = "Unforged Runic Breastplate" end
for _, i in ipairs({270}) do I[i] = "Unguarded Thunder Ale Barrel" end
for _, i in ipairs({181620}) do I[i] = "Unopened Crate" end
for _, i in ipairs({103628}) do I[i] = "Ur's Treatise on Shadow Magic" end
for _, i in ipairs({182483}) do I[i] = "Uther Shrine Lightbeam" end
for _, i in ipairs({19877}) do I[i] = "Velinde's Locker" end
for _, i in ipairs({142702,142703,142704,142705,142706,142707,142708,142709,142710,142711,142712,142713,142714}) do I[i] = "Venom Bottle" end
for _, i in ipairs({19603}) do I[i] = "Venture Co. Documents" end
for _, i in ipairs({19602}) do I[i] = "Venture Co. Engineering Plans" end
for _, i in ipairs({105176}) do I[i] = "Venture Co. Strongbox" end
for _, i in ipairs({102413}) do I[i] = "Verigan's Fist" end
for _, i in ipairs({179922}) do I[i] = "Vessel of Tainted Blood" end
for _, i in ipairs({141853}) do I[i] = "Violet Tragan" end
for _, i in ipairs({181098}) do I[i] = "Volcanic Ash" end
for _, i in ipairs({175320}) do I[i] = "WANTED: Murkdeep!" end
for _, i in ipairs({2713}) do I[i] = "Wanted Board" end
for _, i in ipairs({68,142122,150075,156561,182115,182165,182587,182588,183811,184660,184945,184946,185035,185166,186426}) do I[i] = "Wanted Poster" end
for _, i in ipairs({176115}) do I[i] = "Wanted Poster - Arnak Grimtotem" end
for _, i in ipairs({177904}) do I[i] = "Wanted Poster: Besseleth" end
for _, i in ipairs({180448}) do I[i] = "Wanted Poster: Deathclasp" end
for _, i in ipairs({711}) do I[i] = "Wanted!" end
for _, i in ipairs({179827}) do I[i] = "Wanted/Missing/Lost & Found" end
for _, i in ipairs({179438}) do I[i] = "Wanted: DWARVES!" end
for _, i in ipairs({60}) do I[i] = "Wanted: Gath'Ilzogg" end
for _, i in ipairs({47}) do I[i] = "Wanted: Lieutenant Fangore" end
for _, i in ipairs({175753}) do I[i] = "War of the Spider" end
for _, i in ipairs({175739}) do I[i] = "War of the Three Hammers" end
for _, i in ipairs({178204}) do I[i] = "Warsong Axe Shipment" end
for _, i in ipairs({179786,179831}) do I[i] = "Warsong Flag" end
for _, i in ipairs({178195}) do I[i] = "Warsong Oil" end
for _, i in ipairs({337,2907}) do I[i] = "Water Pitcher" end
for _, i in ipairs({2734}) do I[i] = "Waterlogged Chest" end
for _, i in ipairs({179487,179489,179491}) do I[i] = "Waterlogged Footlocker" end
for _, i in ipairs({2656}) do I[i] = "Waterlogged Letter" end
for _, i in ipairs({3661,3689,3704}) do I[i] = "Weapon Crate" end
for _, i in ipairs({181627,183269,183991}) do I[i] = "Weapon Rack" end
for _, i in ipairs({1760}) do I[i] = "Weathered Bookcase" end
for _, i in ipairs({4406}) do I[i] = "Webwood Eggs" end
for _, i in ipairs({2910}) do I[i] = "Well Stone" end
for _, i in ipairs({164956}) do I[i] = "Western Crystal Pylon" end
for _, i in ipairs({179672}) do I[i] = "Wheel of the Black March" end
for _, i in ipairs({180216}) do I[i] = "Whipweed" end
for _, i in ipairs({180437}) do I[i] = "Wickerman Ember" end
for _, i in ipairs({1623}) do I[i] = "Wild Steelbloom" end
for _, i in ipairs({153239}) do I[i] = "Wildkin Feather" end
for _, i in ipairs({180461,180502,180534,180554}) do I[i] = "Wind Stone" end
for _, i in ipairs({2044}) do I[i] = "Wintersbite" end
for _, i in ipairs({141596}) do I[i] = "Witch Doctor's Chest" end
for _, i in ipairs({173265}) do I[i] = "Wooden Outhouse" end
for _, i in ipairs({142195}) do I[i] = "Woodpaw Battle Map" end
for _, i in ipairs({19022,181239}) do I[i] = "Worn Chest" end
for _, i in ipairs({1765}) do I[i] = "Worn Wooden Chest" end
for _, i in ipairs({175856}) do I[i] = "Wrath of Soulflayer" end
for _, i in ipairs({164909,186419}) do I[i] = "Wrecked Row Boat" end
for _, i in ipairs({180393}) do I[i] = "Wushoolay, the Storm Witch" end
for _, i in ipairs({164661,164781}) do I[i] = "Yellow Power Crystal" end
for _, i in ipairs({6908}) do I[i] = "Yellow Raptor Nest" end
for _, i in ipairs({24776,24777}) do I[i] = "Yuriv's Tombstone" end
for _, i in ipairs({2892}) do I[i] = "Ziata'jai Trophy Skulls" end
for _, i in ipairs({164954}) do I[i] = "Zukk'ash Pod" end
for _, i in ipairs({2893}) do I[i] = "Zul'Mamwe Trophy Skulls" end
