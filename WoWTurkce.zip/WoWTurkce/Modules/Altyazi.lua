-- WoWTürkçe - sinematik ve film altyazıları
-- Altyazı penceresindeki (SubtitlesFrame) satırları Türkçesiyle değiştirir.
-- Çevirisi olmayan satırları "altyazi" kaydına yazar; "çevir" akışıyla eklenir.
local G = WoWTurkce
G.Altyazi = G.Altyazi or {}

local sonKayit = {}

-- "Konuşan: metin" biçimini ayır
local function bol(t)
	local kim, govde = t:match("^([^:\n]+): (.+)$")
	if kim and #kim <= 40 then return kim, govde end
	return nil, t
end

local function bul1(metin)
	local tr, iz = G.izBul(G.Altyazi, metin)
	if tr == nil and G.Soz then tr = G.izBul(G.Soz, metin) end
	if tr == nil and G.Konusma then tr = G.izBul(G.Konusma, metin) end
	return tr, iz
end

-- Önce bütün satır; olmazsa cümle cümle (birden çok cümle tek satırda gösterilebilir)
local function bul(metin)
	local tr, iz = bul1(metin)
	if tr ~= nil then return tr, iz end
	local parca, n = {}, 0
	for cumle, ara in metin:gmatch("(.-[%.!%?]+)(%s*)") do
		local t = bul1(cumle)
		if t == nil then return nil, iz end
		n = n + 1
		parca[#parca + 1] = t .. (ara ~= "" and " " or "")
	end
	if n > 1 then
		local son = table.concat(parca):gsub("%s+$", "")
		return son, iz
	end
	return nil, iz
end

local function satirCevir(fs)
	if not fs or not fs.GetText then return end
	local t = fs:GetText()
	if type(t) ~= "string" or t == "" or fs.wtSon == t then return end
	if G.turkceMi(t) then fs.wtSon = t; return end
	local kim, govde = bol(t)
	local tr, iz = bul(govde)
	if tr then
		local yeni = G.doldur(tr)
		if kim then
			local kimTr = (G.KisiAdi and G.KisiAdi[kim]) or kim
			yeni = kimTr .. ": " .. yeni
		end
		fs.wtSon = yeni
		fs:SetText(yeni)
	else
		fs.wtSon = t
		if iz and not sonKayit[iz] then
			sonKayit[iz] = true
			G.kaydetDiger("altyazi", iz, govde)
		end
	end
end

local function tara()
	if not G.modul("altyazi") then return end
	local f = _G.SubtitlesFrame
	if not f then return end
	for i = 1, 6 do
		local fs = f["Subtitle" .. i]
		if fs and fs.IsShown and fs:IsShown() then pcall(satirCevir, fs) end
	end
end

-- Altyazı gösterildiğinde (olay ya da mixin yöntemi) ve sinematik/film boyunca kısa aralıklarla tara
local izle = CreateFrame("Frame")
local gecen, aktif = 0, false
izle:SetScript("OnUpdate", function(self, dt)
	if not aktif then return end
	gecen = gecen + dt
	if gecen < 0.1 then return end
	gecen = 0
	tara()
end)

local olay = CreateFrame("Frame")
for _, e in ipairs({ "CINEMATIC_START", "CINEMATIC_STOP", "PLAY_MOVIE", "STOP_MOVIE", "SHOW_SUBTITLE", "HIDE_SUBTITLE" }) do
	pcall(olay.RegisterEvent, olay, e)
end
olay:SetScript("OnEvent", function(_, e)
	if e == "CINEMATIC_START" or e == "PLAY_MOVIE" then aktif = true
	elseif e == "CINEMATIC_STOP" or e == "STOP_MOVIE" then aktif = false; tara()
	elseif e == "SHOW_SUBTITLE" then
		aktif = true
		if C_Timer and C_Timer.After then C_Timer.After(0, tara) else tara() end
	end
end)

local function baglan()
	local f = _G.SubtitlesFrame
	if f and not f.wtBagli then
		f.wtBagli = true
		for _, yontem in ipairs({ "AddSubtitle", "ShowSubtitle", "SetSubtitle" }) do
			if type(f[yontem]) == "function" then
				hooksecurefunc(f, yontem, function() pcall(tara) end)
			end
		end
		if f.HookScript then f:HookScript("OnShow", function() aktif = true; tara() end) end
	end
end
baglan()
local yukle = CreateFrame("Frame")
yukle:RegisterEvent("PLAYER_LOGIN")
yukle:RegisterEvent("ADDON_LOADED")
yukle:SetScript("OnEvent", baglan)
