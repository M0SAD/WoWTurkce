-- Kitaplar: okunabilen kitaplar, mektuplar, notlar, levhalar (ItemTextFrame).
-- Başlık ve sayfa metni parmak iziyle G.Kitap tablosunda aranır ($B satır sonları izde yok sayılır).
local G = WoWTurkce
G.Kitap = G.Kitap or {}

local function baslikYazisi()
	return _G.ItemTextFrameTitleText or _G.ItemTextTitleText
		or (ItemTextFrame and ItemTextFrame.TitleText)
		or (ItemTextFrame and ItemTextFrame.TitleContainer and ItemTextFrame.TitleContainer.TitleText)
end

local function bul(metin)
	if type(metin) ~= "string" or metin == "" or G.turkceMi(metin) then return nil end
	local tr, iz = G.izBul(G.Kitap, metin)
	return tr, iz
end

local sonKayit
local function uygula()
	if not G.modul("kitap") then return end
	-- Başlık
	local ad = ItemTextGetItem and ItemTextGetItem()
	local tb = bul(ad)
	local fs = baslikYazisi()
	if tb and fs and fs.SetText then fs:SetText(G.doldur(tb)) end
	-- Sayfa
	local metin = ItemTextGetText and ItemTextGetText()
	local tr, iz = bul(metin)
	if tr and ItemTextPageText and ItemTextPageText.SetText then
		ItemTextPageText:SetText(G.doldur(tr))
	elseif iz and sonKayit ~= iz then
		sonKayit = iz
		G.kaydetDiger("kitap", iz, { baslik = ad, metin = metin })
	end
end

local f = CreateFrame("Frame")
f:RegisterEvent("ITEM_TEXT_READY")
f:SetScript("OnEvent", function()
	-- Blizzard kendi metnini yazdıktan sonra çalış
	if C_Timer and C_Timer.After then C_Timer.After(0, uygula) else uygula() end
end)
