-- Oyunda yakalanan metinlerin çevirileri ("çevir" akışı bu dosyanın sonuna ekler).
-- Veri klasöründeki ana dosyalardan sonra yüklenir. ekle() mevcut çeviriyi ezmez;
-- bir çeviriyi düzeltmek için "Düzeltmeler" bölümünde doğrudan atama yap.
local G = WoWTurkce
local function ekle(t, k, v) if t and k ~= nil and t[k] == nil then t[k] = v end end
local A, E, B, BA, EG, S, K, AY = G.Arayuz, G.Esya, G.Buyu, G.BuyuAdi, G.Egitim, G.Secenek, G.Konusma, G.Altyazi
local SZ, KT, EA, H = G.Soz, G.Kitap, G.EsyaAdi, G.Hata

-- Görev numarası bilinmeyen yeni görevler: metnin kendisiyle eşleşir (oyuncu adı $N, sınıf $C, ırk $R).
local function gorev(baslik, baslikTr, metinler)
	if baslik and baslikTr then G.GorevAdi[baslik] = baslikTr end
	for _, m in ipairs(metinler or {}) do
		local iz = G.konusmaIz(m[1], 2)
		if iz then G.GorevMetni[iz] = m[2] end
	end
end
G.yeniGorev = gorev

-- Biçimler:
-- ekle(A, "English text", "Türkçe")            arayüz satırı (sayılar # ve {1} {2})
-- ekle(E, "Equip: ...", "Kuşanınca: ...")       eşya ipucu satırı;  B: büyü açıklaması, BA: büyü adı, EA: eşya adı
-- ekle(EG, "...", "...")  eğitim penceresi;  S: konuşma seçeneği;  H: hata mesajı
-- ekle(K, 123456789, "...")  NPC selamlaması [parmak izi];  SZ: NPC sözü;  AY: altyazı;  KT: kitap sayfası
-- G.Veri[12345] = { b = "Başlık", a = "Açıklama", h = "Hedef", i = "İlerleme", t = "Tamamlama" }   görev
-- gorev("Quest Title", "Görev Başlığı", { { "English text", "Türkçe metin" } })

-- Düzeltmeler (mevcut çevirinin yerine geçer)

-- Disiplin (görev 99134): "motivate" = cesaretlendir; adlar English (Türkçe)
local H1 = "Executor Zygand (İnfazcı Zygand) için {1} Deathguard'ı (Ölüm Muhafızı) cesaretlendir."
A["Punish # Deathguard for Executor Zygand."] = H1
A["Punish # Deathguards for Executor Zygand."] = H1
A["Motivate # Deathguard for Executor Zygand."] = H1
A["Motivate # Deathguards for Executor Zygand."] = H1
local P1 = "{1}/{2} Deathguard (Ölüm Muhafızı) cesaretlendirildi"
for _, k in ipairs({ "#/# Deathguard motivated", "#/# Deathguards motivated", "#/# Deathguard punished", "#/# Deathguards punished" }) do A[k] = P1 end
A["Deathguard motivated"] = "Deathguard (Ölüm Muhafızı) cesaretlendirildi"
A["Deathguards motivated"] = "Deathguard (Ölüm Muhafızı) cesaretlendirildi"
if G.Veri and G.Veri[99134] then G.Veri[99134].h = "Executor Zygand (İnfazcı Zygand) için 5 Deathguard'ı (Ölüm Muhafızı) cesaretlendir." end

-- Kamp Faydaları (Camp Benefits) buff satırları
A["All stats increased by #%."] = "Tüm statlar %{1} arttı."
A["All stats increased by #."] = "Tüm statlar {1} arttı."
A["All stats increased by #%"] = "Tüm statlar %{1} arttı"
A["Bowl of Fish: All stats increased by #%."] = "Balık Kasesi: Tüm statlar %{1} arttı."
