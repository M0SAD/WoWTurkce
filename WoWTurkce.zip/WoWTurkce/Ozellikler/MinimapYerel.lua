-- Minimap üzerinde fareyle gezinince çıkan ipucu (yaratık, NPC, maden/bitki, görev noktası adları).
-- Oyun bu ipucunu her yenilemede İngilizce yeniden yazar; SetText'in hemen ardından, aynı karede çevrilir
-- (geç çeviri / titreme olmaz). Her satır ayrı ad; sonuçlar önbellekte tutulur.
local G = WoWTurkce
local onbellek, say = {}, 0
local function adTr(ad)
	local c = onbellek[ad]
	if c ~= nil then return c or nil end
	local tr = (G.Nesne and G.Nesne[ad]) or (G.Yaratik and G.Yaratik[ad]) or (G.yaratikCevir and G.yaratikCevir(ad)) or (G.adTr and G.adTr(ad))
		or (G.EsyaAdi and G.EsyaAdi[ad]) or (G.GorevAdi and G.GorevAdi[ad]) or (G.Arayuz and G.Arayuz[ad])
	if tr == ad then tr = nil end
	if say > 2000 then onbellek, say = {}, 0 end
	onbellek[ad] = tr or false; say = say + 1
	return tr
end
local function unvanTr(u)
	local tr = (G.NpcUnvan and G.NpcUnvan[u]) or (G.NpcAltBaslik and G.NpcAltBaslik[u]) or (G.Arayuz and G.Arayuz[u])
	if tr == u then return nil end
	return tr
end
local function satirCevir(s)
	-- "Ad (Unvan)" / "Ad |cffffd100(Unvan)|r": ad ve unvan ayrı çevrilir
	do
		local ad, r1, unvan, r2 = s:match("^(.-)%s+(|c%x%x%x%x%x%x%x%x)%((.-)%)(|r)%s*$")
		if not ad then ad, unvan = s:match("^(.-)%s+%((.-)%)%s*$"); r1, r2 = "", "" end
		if ad and unvan and ad ~= "" then
			local atr, utr = adTr(ad), unvanTr(unvan)
			if atr or utr then
				local agos = atr or ad
				return agos .. " " .. r1 .. "(" .. (utr or unvan) .. ")" .. r2
			end
			return nil
		end
	end
	-- "|Tdoku|t Ad" ya da "|cffrrggbbAd|r" biçimlerini koru, yalnızca adı değiştir
	local on, ad, son = s:match("^(.-|t%s*)(.-)(%s*)$")
	if not on then on, ad, son = "", s, "" end
	local r1, ic, r2 = ad:match("^(|c%x%x%x%x%x%x%x%x)(.-)(|r)$")
	if r1 then ad = ic end
	local tr = ad ~= "" and adTr(ad)
	if not tr then return nil end
	local gos = tr -- haritada sade Türkçe (kalabalık olmasın)
	return on .. (r1 or "") .. gos .. (r2 or "") .. son
end
local mesgul = false
-- İpucu sahibi minimap ya da büyük harita (veya bunlardaki eklenti noktaları: Leatrix Maps, Questie, GatherMate...) mi?
local function haritaSahibi(tt)
	-- Fare büyük haritanın ya da minimapin üzerindeyse (Questie/HBD noktaları gibi derin çerçeveler dahil)
	if WorldMapFrame and WorldMapFrame:IsShown() and WorldMapFrame.IsMouseOver and WorldMapFrame:IsMouseOver() then return true end
	if Minimap and Minimap:IsShown() and Minimap.IsMouseOver and Minimap:IsMouseOver() then return true end
	local ok, sahip = pcall(tt.GetOwner, tt)
	if not ok or not sahip then return false end
	local p, k = sahip, 0
	while p and k < 16 do
		if p == Minimap or p == MinimapCluster or p == WorldMapFrame then return true end
		local ad = p.GetName and p:GetName()
		if ad and (ad:find("Minimap") or ad:find("WorldMap")) then return true end
		p = p.GetParent and p:GetParent(); k = k + 1
	end
	return false
end
local function cevir(tt, metin, r, g, b, a, sar)
	if mesgul or not G.ayar("acik") or type(metin) ~= "string" or metin == "" or G.gizli(metin) then return end
	if not haritaSahibi(tt) then return end
	local degisti, parca = false, {}
	for satir in (metin .. "\n"):gmatch("(.-)\n") do
		local t = satirCevir(satir)
		if t then degisti = true; parca[#parca + 1] = t else parca[#parca + 1] = satir end
	end
	if not degisti then return end
	mesgul = true
	pcall(tt.SetText, tt, table.concat(parca, "\n"), r, g, b, a, sar)
	mesgul = false
end
-- AddLine ile eklenen satırlar: eklenen son satırı yerinde çevir
local function satirEkle(tt)
	if mesgul or not G.ayar("acik") or not haritaSahibi(tt) then return end
	local ad = tt:GetName(); if not ad then return end
	local fs = _G[ad .. "TextLeft" .. (tt:NumLines() or 0)]
	local t = fs and fs:GetText()
	if type(t) ~= "string" or t == "" or G.gizli(t) then return end
	local tr = satirCevir(t)
	if tr then mesgul = true; fs:SetText(tr); mesgul = false end
end
-- Tanı kaydı (geçici): son 30 olay WoWTurkce_Ayar.haritaTani içine yazılır
local function tani(...)
	if type(WoWTurkce_Ayar) ~= "table" then return end
	local L = WoWTurkce_Ayar.haritaTani or {}
	WoWTurkce_Ayar.haritaTani = L
	local p = {}
	for i = 1, select("#", ...) do p[#p + 1] = tostring((select(i, ...))) end
	table.insert(L, table.concat(p, " | "))
	while #L > 30 do table.remove(L, 1) end
end
G.haritaTani = function(...) tani(...) end
local function sar(fn, ad)
	return function(tt, ...)
		local ok, e = pcall(fn, tt, ...)
		local okS, sahip = pcall(tt.GetOwner, tt)
		local sad = okS and sahip and (sahip.GetName and sahip:GetName() or "?adsız") or "yok"
		local wm = WorldMapFrame and WorldMapFrame:IsShown() and (WorldMapFrame:IsMouseOver() and "haritaUstu" or "haritaAcik") or "-"
		if false then
			local l1 = _G[(tt:GetName() or "") .. "TextLeft1"]
			tani(ad, tt:GetName(), sad, wm, tostring((...)), "sonuc:" .. tostring(l1 and l1:GetText()), ok and "" or ("HATA " .. tostring(e)))
		end
	end
end
G.basla(function()
	for _, ad in ipairs({ "GameTooltip", "WorldMapTooltip" }) do
		local tt = _G[ad]
		if tt then
			hooksecurefunc(tt, "SetText", sar(cevir, "SetText"))
			hooksecurefunc(tt, "AddLine", sar(satirEkle, "AddLine"))
		end
	end
end)
