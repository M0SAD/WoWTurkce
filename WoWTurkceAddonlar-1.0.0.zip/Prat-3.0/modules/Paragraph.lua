﻿---------------------------------------------------------------------------------
--
-- Prat - A framework for World of Warcraft chat mods
--
-- Copyright (C) 2006-2018  Prat Development Team
--
-- This program is free software; you can redistribute it and/or
-- modify it under the terms of the GNU General Public License
-- as published by the Free Software Foundation; either version 2
-- of the License, or (at your option) any later version.
--
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with this program; if not, write to:
--
-- Free Software Foundation, Inc.,
-- 51 Franklin Street, Fifth Floor,
-- Boston, MA  02110-1301, USA.
--
--
-------------------------------------------------------------------------------

Prat:AddModuleToLoad(function()
	local module = Prat:NewModule("Paragraph")
	local PL = module.PL

	Prat:SetModuleDefaults(module, {
		profile = {
			on = false,
			justification = { ["*"] = "LEFT" },
			spacing = 0
		}
	})

	do
		local justifyoption = {
			name = function(info)
				return Prat.FrameList[info[#info]] or ""
			end,
			desc = PL["justification_name"],
			type = "select",
			get = function(info)
				return info.handler.db.profile.justification[info[#info]]
			end,
			set = function(info, v)
				info.handler.db.profile.justification[info[#info]] = v
				info.handler:OnValueChanged(info, v)
			end,
			values = { ["RIGHT"] = PL["Right"], ["CENTER"] = PL["Center"], ["LEFT"] = PL["Left"] },
			hidden = function(info)
				return Prat.FrameList[info[#info]] == nil
			end,
		}

		Prat:SetModuleOptions(module, {
			name = PL["Paragraph"],
			desc = PL["Chat window paragraph options."],
			type = "group",
			args = {
				justification = {
					name = PL["justification_name"],
					desc = PL["justification_desc"],
					type = "group",
					inline = true,
					args = {
						ChatFrame1 = justifyoption,
						ChatFrame2 = justifyoption,
						ChatFrame3 = justifyoption,
						ChatFrame4 = justifyoption,
						ChatFrame5 = justifyoption,
						ChatFrame6 = justifyoption,
						ChatFrame7 = justifyoption,
					},
				},
				spacing = {
					name = PL["Line Spacing"],
					desc = PL["Set the line spacing for all chat windows."],
					type = "range",
					min = 0,
					max = 20,
					step = 1,
					order = 109
				},
				info = {
					name = "Not: Hizalama 'Sol' dışında bir şeye ayarlandığında oyuncu bağlantıları, eşya bağlantıları ve diğer bağlantı türleri çalışmaz",
					type = "description",
					order = 110
				}
			}
		})
	end

	--[[------------------------------------------------
		Module Event Functions
	------------------------------------------------]] --

	function module:OnModuleEnable()
		self:ConfigureAllChatFrames(true)
		Prat.RegisterChatEvent(self, Prat.Events.FRAMES_UPDATED)
	end

	function module:OnModuleDisable()
		self:ConfigureAllChatFrames(false)
	end

	function module:OnValueChanged()
		self:ConfigureAllChatFrames(true)
	end

	function module:Prat_FramesUpdated()
		self:ConfigureAllChatFrames(true)
	end

	--[[------------------------------------------------
	  Core Functions
	------------------------------------------------]] --
	function module:GetDescription()
		return PL["Chat window paragraph options."]
	end

	function module:ConfigureAllChatFrames(enable)
		local prof = self.db.profile
		for k, v in pairs(Prat.Frames) do
			v:SetJustifyH(enable and prof.justification[k] or "LEFT")
			v:SetSpacing(prof.spacing)
		end
	end

	return
end) -- Prat:AddModuleToLoad
