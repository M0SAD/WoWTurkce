local _, addon = ...;

local strjoin = _G.strjoin;
local strlower = _G.strlower;
local format = _G.format;

local Utils = addon.import('Core/Utils');
local SlashCommands = addon.import('Core/SlashCommands');
local HelpCommands = addon.import('Core/HelpCommands');
local Main = addon.import('Logic/Main');
local Whitelist = addon.import('Logic/Whitelist');
local Blacklist = addon.import('Logic/Blacklist');
local Settings = addon.import('Settings/Settings');

SlashCommands.addCommand('set', function (setting, value)
  if (setting == nil) then
    Utils.printAddonMessage('Kullanılabilir ayarlar:');
    Settings.printAvailableSettings();
    return;
  end

  local lowerCaseSetting = strlower(setting);

  if (Settings.isSettingUnavailable(setting)) then
    Utils.printAddonMessage(Settings.getSettingUnavailableReason(setting));
    return;
  end

  if (not Settings.doesSettingExist(lowerCaseSetting)) then
    Utils.printAddonMessage('Bilinmeyen ayar: ', setting);
    return;
  end

  if (value == nil) then
    Utils.printAddonMessage(format('%s ayarının şu anki değeri: %s', setting, tostring(Settings.getSetting(lowerCaseSetting))));
  else
    local status = Settings.setSetting(lowerCaseSetting, value);

    if (status == true) then
      Utils.printAddonMessage(format('setting %s was set to %s', setting, value));
    elseif (status == false) then
      Utils.printAddonMessage(format('%s is not a valid value for setting %s', value, setting));
    else
      error('Invalid getter status: ' .. status);
    end
  end
end);

HelpCommands.addHelper('set', function (setting)
  if (setting == nil) then
    Utils.printAddonMessage(strjoin(' ',
        'Bu komut, ayarın adını ve ardından değerini yazarak bir ayarın değerini değiştirmeni sağlar.',
        'Bir değer belirtmezsen şu anki değer yazdırılır.',
        'Kullanılabilir ayarlar:'
    ));
    Settings.printAvailableSettings();
    return;
  end

  local help = Settings.getHelp(setting);

  if (help == nil) then
    Utils.printAddonMessage(format('Bilinmeyen ayar: %s.\nŞu ayarlar için yardım mevcut:', setting));
    Settings.printAvailableSettings();
    return;
  end

  Utils.printAddonMessage(help);
end);

local function findButton (buttonName)
  local matches, path, keys = Main.searchButtonByName(buttonName);

  if (#matches == 0) then
    Utils.printAddonMessage(format('"%s" adında bir çerçeve bulunamadı.', buttonName));
    return nil;
  end

  if (#matches > 1) then
    Utils.printAddonMessage(format('"%s" içeren birden fazla çerçeve bulundu:', buttonName));
    Utils.sortAndPrintList(Main.getFoundButtonPaths(path, keys));
    return nil;
  end

  return matches[1], path;
end

local function findAndValidateButton (buttonName)
  local button, path = findButton(buttonName);

  if (button == nil) then
    return nil;
  end

  if (not Main.isValidFrame(button)) then
    Utils.printAddonMessage(format('"%s" is not a valid frame.', path));
    return nil;
  end

  return button, path;
end

SlashCommands.addCommand({'include', 'unignore'}, function (...)
  if (... == nil) then
    Utils.printAddonMessage('Lütfen bir düğme adı ekle');
    return;
  end

  local buttonName = Utils.concatButtonName(...);
  local button, path = findAndValidateButton(buttonName);

  if (button ~= nil) then
    Blacklist.removeFromBlacklist(Utils.getFrameName(button));
    Whitelist.addToWhitelist(path);
  else
    Blacklist.removeFromBlackListCaseInsensitive(buttonName);
  end
end);

HelpCommands.addHelper({'include', 'unignore'}, strjoin(' ',
    'Bu komut, komuta verilen addaki düğmeyi elle toplanacaklar listesine ekler.',
    'Düğme önceden yok sayıldıysa yok sayma listesinden çıkarılır.'
));

SlashCommands.addCommand({'ignore', 'uninclude'}, function (...)
  if (... == nil) then
    Utils.printAddonMessage('Lütfen bir düğme adı ekle');
    return;
  end

  local buttonName = Utils.concatButtonName(...);
  local button, path = findButton(buttonName);

  if (button ~= nil) then
    Whitelist.removeFromWhitelist(path);
    Blacklist.addToBlacklist(Utils.getFrameName(button));
  else
    Whitelist.removeFromWhitelistCaseInsensitive(buttonName);
  end
end);

HelpCommands.addHelper({'ignore', 'uninclude'}, strjoin(' ',
  'Bu komut, komuta verilen addaki düğmenin toplanmasını durdurur.',
  'Bunun etkili olması için "/reload" gerekir.'
));

SlashCommands.addCommand({'includeall', 'unignoreall'}, Blacklist.clearBlacklist);
HelpCommands.addHelper({'includeall', 'unignoreall'}, 'Bu komut, yok sayılan tüm düğmelerin yeniden toplanmasını sağlar.');

SlashCommands.addCommand({'ignoreall', 'unincludeall'}, Whitelist.clearWhitelist);
HelpCommands.addHelper({'ignoreall', 'unincludeall'}, 'Bu komut, elle toplanmak üzere işaretlenmiş tüm düğmelerin artık toplanmamasını sağlar.');
