-- Oyunda yakalanan metinlerin çevirileri ("çevir" akışı bu dosyanın sonuna ekler).
-- Veri klasöründeki ana dosyalardan sonra yüklenir. ekle() mevcut çeviriyi ezmez;
-- bir çeviriyi düzeltmek için "Düzeltmeler" bölümünde doğrudan atama yap.
local G = WoWTurkce
local function ekle(t, k, v) if t and k ~= nil and t[k] == nil then t[k] = v end end
local A, E, B, BA, EG, S, K, AY = G.Arayuz, G.Esya, G.Buyu, G.BuyuAdi, G.Egitim, G.Secenek, G.Konusma, G.Altyazi
local SZ, KT, EA, H = G.Soz, G.Kitap, G.EsyaAdi, G.Hata

-- Görev numarası bilinmeyen yeni görevler: metnin kendisiyle eşleşir (oyuncu adı $N, sınıf $C, ırk $R).
local function gorev(baslik, baslikTr, metinler)
	if baslik and baslikTr then G.GorevAdi[baslik] = baslikTr end
	for _, m in ipairs(metinler or {}) do
		local iz = G.konusmaIz(m[1], 2)
		if iz then G.GorevMetni[iz] = m[2] end
	end
end
G.yeniGorev = gorev

-- Biçimler:
-- ekle(A, "English text", "Türkçe")            arayüz satırı (sayılar # ve {1} {2})
-- ekle(E, "Equip: ...", "Kuşanınca: ...")       eşya ipucu satırı;  B: büyü açıklaması, BA: büyü adı, EA: eşya adı
-- ekle(EG, "...", "...")  eğitim penceresi;  S: konuşma seçeneği;  H: hata mesajı
-- ekle(K, 123456789, "...")  NPC selamlaması [parmak izi];  SZ: NPC sözü;  AY: altyazı;  KT: kitap sayfası
-- G.Veri[12345] = { b = "Başlık", a = "Açıklama", h = "Hedef", i = "İlerleme", t = "Tamamlama" }   görev
-- gorev("Quest Title", "Görev Başlığı", { { "English text", "Türkçe metin" } })

-- Düzeltmeler (mevcut çevirinin yerine geçer)

-- Disiplin (görev 99134): "motivate" = cesaretlendir; adlar English (Türkçe)
local H1 = "Executor Zygand (İnfazcı Zygand) için {1} Deathguard'ı (Ölüm Muhafızı) cesaretlendir."
A["Punish # Deathguard for Executor Zygand."] = H1
A["Punish # Deathguards for Executor Zygand."] = H1
A["Motivate # Deathguard for Executor Zygand."] = H1
A["Motivate # Deathguards for Executor Zygand."] = H1
local P1 = "{1}/{2} Deathguard (Ölüm Muhafızı) cesaretlendirildi"
for _, k in ipairs({ "#/# Deathguard motivated", "#/# Deathguards motivated", "#/# Deathguard punished", "#/# Deathguards punished" }) do A[k] = P1 end
A["Deathguard motivated"] = "Deathguard (Ölüm Muhafızı) cesaretlendirildi"
A["Deathguards motivated"] = "Deathguard (Ölüm Muhafızı) cesaretlendirildi"
if G.Veri and G.Veri[99134] then G.Veri[99134].h = "Executor Zygand (İnfazcı Zygand) için 5 Deathguard'ı (Ölüm Muhafızı) cesaretlendir." end

-- Kamp Faydaları (Camp Benefits) buff satırları
A["All stats increased by #%."] = "Tüm statlar %{1} arttı."
A["All stats increased by #."] = "Tüm statlar {1} arttı."
A["All stats increased by #%"] = "Tüm statlar %{1} arttı"
A["Bowl of Fish: All stats increased by #%."] = "Balık Kasesi: Tüm statlar %{1} arttı."

-- 1.0.0 kayıtlarından (cihaz)
SZ[126135091] = SZ[126135091] or "Bir daha başarısız olmayacağım."
SZ[197375362] = SZ[197375362] or "Başka bir gün savaşmak için yaşıyorum!"
local KADEH = "Kadehimi kaldırıyorum ve sizin gibilerden kurtulmayı umuyorum! Şerefe, seni işe yaramaz hergele, %s!"
SZ[2345947321] = SZ[2345947321] or KADEH:format("Hachachacha")
SZ[1224074657] = SZ[1224074657] or KADEH:format("Hellig")
SZ[1346220996] = SZ[1346220996] or KADEH:format("Kilian")
ekle(A, "Just what I needed.", "Tam da ihtiyacım olan buydu.")
ekle(A, "How long can it take to pick a handful of weeds?", "Bir avuç ot toplamak ne kadar sürebilir ki?")
ekle(A, "I will not fail again.", "Bir daha başarısız olmayacağım.")
ekle(A, "I will double up my efforts.", "Çabalarımı ikiye katlayacağım.")
ekle(A, "If you want something done right, do it yourself!", "Bir işin düzgün yapılmasını istiyorsan, kendin yap!")
ekle(A, "Deliver the Nondescript Letter to Innkeeper Renee in Tirisfal Glades.", "Sıradan Mektup (Nondescript Letter) öğesini Tirisfal Glades'teki Innkeeper Renee'ye (Hancı Renee) ulaştır.")
ekle(A, "Oh? A letter? Wonderful news! I've been waiting on word from my dear old mother in Deathknell. Such a saint, she is. I wonder how she's holding up.", "Ha? Bir mektup mu? Harika haber! Deathknell'deki sevgili yaşlı annemden haber bekliyordum. Tam bir aziz, o. Nasıl idare ediyor, merak ediyorum.")
ekle(A, "A foul beast, even by Gnoll standards, Maggot Eye has been sentenced to death for his crimes against The Forsaken. This despicable villain has been stealing corpses for use by the Lich King's army. Maggot Eye was last seen pillaging the lands near Garren's Haunt to the north of Brill.", "Gnoll standartlarına göre bile iğrenç bir yaratık olan Maggot Eye, The Forsaken'a karşı işlediği suçlar yüzünden ölüme mahkûm edildi. Bu aşağılık alçak, Lich King'in ordusunun kullanması için cesetleri çalıyordu. Maggot Eye en son Brill'in kuzeyindeki Garren's Haunt yakınlarındaki toprakları yağmalarken görüldü.")
ekle(A, "Wanted: Maggot Eye!", "Aranıyor: Maggot Eye!")
ekle(A, "- Vile Fin Scale", "- Vile Fin Pulu")
ekle(A, "- Maggot Eye's Paw", "- Maggot Eye'ın Pençesi")
ekle(A, "- Riptear's Heart", "- Riptear'ın Kalbi")
ekle(A, "#/# Duskbat Wing [#%]", "{1}/{2} Duskbat Kanadı [{3}%]")
ekle(A, "#/# Scavenger Paw [#%]", "{1}/{2} Scavenger Pençesi [{3}%]")
ekle(A, "# - # Arcane Damage", "{1} - {2} Arcane Hasarı")
ekle(A, "Kullan: Restores # health over # sn. Must remain seated while eating.", "Kullan: {2} sn boyunca {1} can yeniler. Yemek yerken oturmalısın.")
if G.GorevAdi then
	for en, tr in pairs({ ["Discipline"] = "Disiplin", ["Patience"] = "Sabır", ["Wanted: Maggot Eye"] = "ARANIYOR: Maggot Eye" }) do if G.GorevAdi[en] == nil then G.GorevAdi[en] = tr end end
end
