if not WoWTurkce.FOREVER then return end -- yalnızca Classic Forever
-- Classic Forever'a özel görevler 7
-- b=başlık, a=açıklama, h=hedef, i=ilerleme, t=tamamlama
-- k = çevrilen İngilizce metnin parmak izi (metin değişirse çeviri gösterilmez, yeniden kaydedilir)
local V = WoWTurkce.Veri

V[76156] = { b="Toprak Ana ile Sinsi Av", h="Thunder Bluff'ın güneydoğusundaki Venture Company madenine gizlice gir ve patlayıcı malzeme arabalarından 5 Seaforium Madencilik Patlayıcısı topla, ardından bunları Thunder Bluff'taki Boarton Shadetotem'e götür.", k={b=1686538756, h=3017038659} }
V[76160] = { b="Toprak Ana ile Sinsi Av", h="Thunder Bluff'ın kuzeyinden 8 Windfury Kozalağı topla, bunları Havan ve Tokmak ile kullan, ardından elde ettiğin sonuçla Thunder Bluff'taki Boarton Shadetotem'e dön.", k={b=1686538756, h=1820828527} }
V[76240] = { b="Toprak Ana ile Sinsi Av", h="Bir Çiğ Parlak Küçük Balık satın al ya da yakala, ardından Bıçak Takımı'nı kullanarak onu Thunder Bluff'taki Boarton Shadetotem'in önünde fileto yap.", k={b=1686538756, h=3222677750} }
V[79008] = { b="... ve bulduğun o not", h="Notun yanmış kalıntıları tek rehberin.", k={b=4061571960, h=3219166097} }
V[79192] = { b="Basamak Taşları", h="Notu tahtadan koparıp üzerindeki karalanmış yazıyı okuyorsun.", k={b=1731734443, h=1506369241} }
V[86585] = { b="Düşmüşlerin Sancağı", h="Ironforge sancağını dik, trogg Headsplitter'ı meydan okuyarak çağır ve öldür, ardından Yüzbaşı Rugelfuss'a rapor ver.", k={b=2419727523, h=2763553782} }
V[86613] = { b="Kazı Aletleri", h="Magmar Fellhew'a 6 Kazı Aleti geri getir.", k={b=571427784, h=3216656541} }
V[86614] = { b="Dalgaların Gümüşü", h="Monogramlı Gümüş Saç Tokası'nı sahibine geri götür.", k={b=3960176278, h=687163323} }
V[86667] = { b="Kara Hapsolmuş", h="Bir Kavanoz Kar'ı, Loch'un kuzeybatı kıyısındaki evinde yaşayan Norric Lochthane'e teslim et.", k={b=1200570628, h=867262095} }
V[86757] = { b="Orc İlerleyişini Yavaşlatmak", h="Shandrina'ya 6 Tırtıklı Orc Kılıcı ve 4 Kavisli Orc Hançeri götür.", k={b=156877791, h=1527008737} }
V[86758] = { b="Bıçağı Çevirmek", h="Daggerfang adlı crocolisk'i bul, alt et ve Marek'in bıçağını geri getir.", k={b=3823802508, h=2201870616} }
V[86776] = { b="Ocak İçin Malzemeler", h="Morhan Coppertongue'a 10 Bronz Külçe götür.", k={b=1017000412, h=1650739315} }
V[92109] = { b="İlk Simya Takımım", h="5 Boş Şişe, 5 Silverleaf ve 5 Peacebloom'u Westfall'daki Moonbrook ambarının içindeki genç, hevesli simyacıya götür.", k={b=633643298, h=1760892588} }
V[92110] = { b="İlk Gerçek İksirim", h="Westfall'daki Moonbrook ambarının içindeki genç, hevesli simyacı için 3 Murloc Gözü topla.", k={b=2957016912, h=2028374160} }
V[92432] = { b="Endişe Verici Bir Talep", h="City of Dalaran yakınlarındaki Başbüyücü Modera'nın Sureti'ne rapor ver.", k={b=3744862632, h=2309168917} }
V[92434] = { b="Sokaklarda Kan", h="Lordamere Lake boyunca Dalaran'a girmenin bir yolunu bul.", k={b=3175136279, h=2839095855} }
V[92459] = { b="Kirin Tor'un Dostu", h="City of Dalaran'daki Başbüyücü Celindra ile konuş.", k={b=1625191685, h=4102469871} }
V[92706] = { b="ARANIYOR: Bruuz", h="Bruuz'un Sırt Yüzgeci'ni Ratchet'taki Gazlowe'a götür.", k={b=3690711008, h=3008960770} }
V[92742] = { b="Kuyuları Test Etmek", h="Kuyu Suyu Örnek Kiti'ni kullanarak Jansen Stead ve Molsen Farm'daki kuyulardan örnek al.", k={b=1630287467, h=1083656348} }
V[92744] = { b="Murloc Solungaçları", h="Alba Fairmoon, Westfall kıyı şeridi boyunca 7 Longshore Murloc Solungacı toplamanı istiyor.", k={b=1725546866, h=1367771818} }
V[92745] = { b="Madenlerin Durumu", h="Jangolode Mine'da 4 Kobold Digger ve Gold Coast Quarry'de 6 Riverpaw Miner öldür.", k={b=1013409849, h=1345482441} }
V[92747] = { b="Moonbrook Casusluğu", h="Moonbrook'tan 8 Şüpheli Endüstriyel Malzeme topla.", k={b=1669237046, h=289830360} }
V[92748] = { b="Patlayıcı Danışmanlık", h="Stormwind'deki Dwarven District'e git ve yardım edebilecek bir mühendis bul.", k={b=4172714087, h=695868491} }
V[92749] = { b="Dinamit Gibi Bir Plan", h="Üreterek, takas ederek ya da müzayede salonundan 10 Kaba Dinamit edin, ardından Stormwind'in Dwarven District'indeki Sprite Jumpsprocket'a dön.", k={b=3358926796, h=1853857504} }
V[92750] = { b="Uzaktan Patlatma", h="Uzaktan kumandalı bir patlatıcı edinmek için Stormwind İstihbaratı'ndan biriyle konuş.", k={b=3655911419, h=1821043766} }
V[92751] = { b="Uzaktan Patlatma", h="Uzaktan Patlatıcı Kiti'ni Stormwind'in Dwarven District'indeki Sprite Jumpsprocket'a götür.", k={b=3655911419, h=2069951886} }
V[92752] = { b="Patlayıcı Danışmanlık", h="Westfall'daki Alba Fairmoon'a dön.", k={b=4172714087, h=3378589260} }
V[92819] = { b="Deadmines'ta Yıkım", h="Patlatıcıyı kullan.", k={b=3350360826, h=3189845507} }
V[92909] = { b="Hasatçıları Hasat Etmek", h="Saldean's Farm'daki Ozwin Ironsprocket, kendisine 14 Golem İzoyayı ve 5 Hasatçı Jiroskop Dengeleyicisi getirmeni istiyor.", k={b=1442457736, h=671839573} }
V[92910] = { b="Hasatçıları Hasat Etmek", h="Presesif Otobiliş Düzeneği'ni Saldean's Farm'daki Ozwin Ironsprocket'a götür.", k={b=1442457736, h=3249242071} }
V[92911] = { b="Hasatçıları Hasat Etmek", h="Saldean's Farm'daki Ozwin Ironsprocket, kendisine 8 Golem İzoyayı, 4 Bakır Modülatör ve bir Kaba Dürbün getirmeni istiyor.", k={b=1442457736, h=1137372263} }
V[93680] = { b="Şehrin Anahtarı", h="Tarren Mill'deki Büyücü Wordeen Voidglare için Dalaran Lağım Anahtarı'nı edin.", k={b=1764963499, h=1150045784} }
V[94320] = { b="Zanaatkâr Yazısı: Arthas'ın Armağanı", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=1683745695, h=4033408505} }
V[94321] = { b="Zanaatkâr Yazısı: Kromatik Direnç Şişesi", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=441035598, h=4033408505} }
V[94322] = { b="Zanaatkâr Yazısı: Sınırlı Yenilmezlik İksiri", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=647355551, h=4033408505} }
V[94323] = { b="Zanaatkâr Yazısı: Büyük Yenilenme İksiri", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=1256750857, h=4033408505} }
V[94324] = { b="Zanaatkâr Yazısı: Damıtılmış Ateşsuyu", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=56698980, h=4033408505} }
V[94325] = { b="Zanaatkâr Yazısı: Işıltılı Taç", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=931335398, h=4033408505} }
V[94326] = { b="Zanaatkâr Yazısı: Işıltılı Kemer", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=383266183, h=4033408505} }
V[94327] = { b="Zanaatkâr Yazısı: Orc Savaş Tozlukları", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=1000556607, h=4033408505} }
V[94328] = { b="Zanaatkâr Yazısı: Mithril Mahmuzlar", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=305910771, h=4033408505} }
V[94329] = { b="Zanaatkâr Yazısı: İmparatorluk Plaka Göğüslüğü", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=327830397, h=4033408505} }
V[94330] = { b="Zanaatkâr Yazısı: Kara Rün Eldivenleri", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=1779118160, h=4033408505} }
V[94331] = { b="Zanaatkâr Yazısı: Devasa Thorium Savaş Baltası", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=3950326856, h=4033408505} }
V[94332] = { b="Zanaatkâr Yazısı: Arcanite Maymuncuk", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=585918418, h=4033408505} }
V[94333] = { b="Zanaatkâr Yazısı: Abanoz Hançer", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=3876944763, h=4033408505} }
V[94334] = { b="Zanaatkâr Yazısı: Usta İşi Hedef Mankeni", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=1356330911, h=4033408505} }
V[94335] = { b="Zanaatkâr Yazısı: Yeşil Mercek", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=1606284064, h=4033408505} }
V[94336] = { b="Zanaatkâr Yazısı: Gerçekçi Mekanik Kurbağa", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=81114543, h=4033408505} }
V[94337] = { b="Zanaatkâr Yazısı: Gnome Alarm-O-Bot", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=2252301299, h=4033408505} }
V[94338] = { b="Zanaatkâr Yazısı: Goblin Takviye Kabloları XL", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=3009092857, h=4033408505} }
V[94339] = { b="Zanaatkâr Yazısı: Saha Tamir Robotu 74A", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=403540437, h=4033408505} }
V[94340] = { b="Zanaatkâr Yazısı: Truesilver Dönüştürücü", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=483335397, h=4033408505} }
V[94341] = { b="Zanaatkâr Yazısı: Keskin Nişancı Dürbünü", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=3391454472, h=4033408505} }
V[94342] = { b="Zanaatkâr Yazısı: Sakin Mekanik Yeti", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=2512918189, h=4033408505} }
V[94343] = { b="Zanaatkâr Yazısı: Kötücül Deri Pantolon", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=1640178047, h=4033408505} }
V[94344] = { b="Zanaatkâr Yazısı: Gordok Ogre Kostümü", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=2605526133, h=4033408505} }
V[94345] = { b="Zanaatkâr Yazısı: Volkanik Göğüslük", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=2136604451, h=4033408505} }
V[94346] = { b="Zanaatkâr Yazısı: Rünlü Deri Saç Bandı", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=490010250, h=4033408505} }
V[94347] = { b="Zanaatkâr Yazısı: Kötücül Deri Bileklikler", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=3491045371, h=4033408505} }
V[94348] = { b="Zanaatkâr Yazısı: Kimerik Yelek", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=1789774147, h=4033408505} }
V[94349] = { b="Zanaatkâr Yazısı: Ağır Scorpid Miğferi", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=2988737364, h=4033408505} }
V[94350] = { b="Zanaatkâr Yazısı: Rünlü Deri Bileklikler", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=3056660389, h=4033408505} }
V[94351] = { b="Zanaatkâr Yazısı: Frostsaber Çizmeleri", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=4144315583, h=4033408505} }
V[94352] = { b="Zanaatkâr Yazısı: Büyücü Dokuması Sarık", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=3500067506, h=4033408505} }
V[94353] = { b="Zanaatkâr Yazısı: Rün Kumaşı Çanta", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=3888153979, h=4033408505} }
V[94354] = { b="Zanaatkâr Yazısı: Rün Kumaşı Çizmeler", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=3657412344, h=4033408505} }
V[94355] = { b="Zanaatkâr Yazısı: Smokin Ceketi", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=943538920, h=4033408505} }
V[94356] = { b="Zanaatkâr Yazısı: Fel Kumaşı Çizmeler", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=1191046005, h=4033408505} }
V[94357] = { b="Zanaatkâr Yazısı: Cenarion Bitki Çantası", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=1390891575, h=4033408505} }
V[94358] = { b="Zanaatkâr Yazısı: Gölge Dokuması Maske", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=1833172272, h=4033408505} }
V[94359] = { b="Zanaatkâr Yazısı: Hayalet Dokuması Yelek", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=943249884, h=4033408505} }
V[94360] = { b="Zanaatkâr Yazısı: Ruh Kesesi", h="Müşterinin istediği eşyaları edin ve haritanda işaretli konuma teslim et. İşlemi tamamlayabilmek için bu sipariş belgesi üzerinde olmalı.", k={b=4041982399, h=4033408505} }
V[95384] = { b="Yarım Kalmış Mistik Notlar", h="Yarım parşömeni Booty Bay'deki Dudd Fizzlescroll'a götür.", k={b=1752047841, h=1996443067} }
V[95494] = { b="Kırgın Gurur ve Aslan Postları", h="The Barrens'taki Savannah Matriarch ve Savannah Patriarch'lardan 6 Savan Aslanı Postu topla.", k={b=3678160761, h=1904404828} }
V[95495] = { b="Münzevi Tabakçı", h="Deri Bohçası'nı The Barrens'ta, Dry Hills'e bakan sırttaki münzeviye götür.", k={b=3159294967, h=2689553002} }
V[95507] = { b="Vrang'ın Avı", h="The Barrens'taki Sprung Traps'te bulunan tuzaklardan 8 Tuzağa Düşmüş Av topla.", k={b=2198690800, h=804368972} }
V[95508] = { b="İstenmeyen Misafirler", h="Walton'ın Terry Longdrink ve Kul Tiras deniz piyadeleriyle karşılaşmasından sağ çıkmasına yardım et.", k={b=675248687, h=1818512119} }
V[95534] = { b="Strahnbrad Gizemi", h="Strahnbrad'ın gizemini çöz ve bulgularını Hillsbrad'daki kasabaya bildir.", k={b=2546084843, h=2862493477} }
V[95621] = { b="Vadide Sorun Var", h="Harap olmuş kervana git ve Kul Tiraslıların burada neden bulunduğunu öğren.", k={b=3067961223, h=469137117} }
V[95748] = { b="Eski Gurubashi Efsaneleri", h="Postu ve kömürü kullanarak Üçüncü Trol Efsanesi tabletinin bir kopyasını çıkar.", k={b=2164123270, h=2508831687} }
V[95770] = { b="Kayıp Şehrin İzinde", h="Vile Reef'i keşfet ve mağara girişini bul.", k={b=3028408434, h=2838780923} }
V[95773] = { b="Sulardaki Düşmanlar", h="Brinescale Skirmisher'lardan 10 Brinescale Mızrağı topla.", k={b=263692614, h=2717832422} }
V[95774] = { b="Onun Adı Olgra", h="Quilboar'ları öldür ve Mankrik'in anıtı için Olgra'nın Süs Eşyaları'ndan 4 tane topla.", k={b=2267118454, h=1155875762} }
V[95805] = { b="An'she ve Mu'sha'nın Lütfu", h="Tüten Tütsü'yü, on dakika içinde yanıp küle dönmeden güneydoğu tepelerindeki An'she ve Mu'sha tapınağına ulaştır!", k={b=3947847900, h=1700431840} }
V[95819] = { b="Beni de Yazın!", h="Doldurulmuş formu The Barrens'taki Jornah'ya götür.", k={b=674248941, h=2498906963} }
V[96130] = { b="Chakuyak", h="Chakuyak'ı alt et ve postunu getir.", k={b=149431894, h=657166121} }
V[96241] = { b="Zehirlerden Konuşalım, Mon", h="Zehir Çıkarıcı'yı kullanarak Gloomrise'daki Kemirilmiş Cesetler'den 5 Gloomrise Zehir Örneği topla.", k={b=3090279345, h=3974481980} }
V[96259] = { b="Ölüleri Savunmak", h="10 Gloomrise Hatchling ve 5 Gloomrise Soldier öldür.", k={b=2587769560, h=2604897414} }
V[96260] = { b="Çelikten Güçlü", h="Gloomrise Spinner'lardan 3 tel Kristal İpek topla.", k={b=2345548481, h=996536859} }
V[96261] = { b="Kuluçka Anası", h="Gloomrise'daki Kuluçka Anası Valraxx'ı öldür.", k={b=1492002475, h=2205343490} }
V[96294] = { b="Daha Karanlık Bir Gerçek", h="Kuluçka Anası Valraxx'tan ele geçirdiğin mektubu Skywatcher Plateau'daki Muln Earthfury'ye götür.", k={b=2501438518, h=2398200098} }
V[96339] = { b="Miras Ödülü: Replika Ironforge Tüfeği", k={b=3136068120} }
V[96383] = { b="Miras Ödülü: Hayalet Ayı Yavrusu", k={b=2651707025} }
V[97003] = { b="Yağmacı Chol'aruk", h="Chol'aruk'un kafasını The Barrens'taki Gur'ak'a götür.", k={b=3206429842, h=982734170} }
V[97005] = { b="Yağmacı Chol'aruk", h="Chol'aruk'un Kafası'nı The Barrens'taki Bainham'a götür.", k={b=3206429842, h=2931467981} }
V[97047] = { b="Kafesteki Aşçı", h="Kurzen yerleşkesinde Wendel'in kafesinin anahtarını ve onun gizlice kaçabilmesi için bir kılık bul.", k={b=2429214586, h=835545584} }
V[97048] = { b="Limana Dönüş", h="Booty Bay'deki Kaptan Aransas ile konuş.", k={b=2149088299, h=333669093} }
V[97250] = { b="Haksız Suçlama, Haklı Düzeltme", h="Dustwallow Marsh sınırında The Barrens'a sızan İttifak askerlerini öldür, ardından Camp Taurajo'daki Grunt Logmar'a dön.", k={b=3985760226, h=3949775709} }
V[97253] = { b="Parçalar ve Aksamlar", h="Ratchet'ın güneyindeki üst korsan kampından 5 Avuç Karmaşık Parça topla, ardından Ratchet'taki Sefil Wrenix'e dön.", k={b=3703152699, h=2272958203} }
V[97287] = { b="Kurnaz Pazarlıklar", h="City of Dalaran'daki Başbüyücü Celindra ile konuş.", k={b=3044378182, h=1616148776} }
V[97328] = { b="Değeri Olan Ne Varsa", h="Stranglethorn Vale'deki Ruins of Zul'Kunda'dan 8 Çalıntı Sevkiyat geri al ve ganimetini Booty Bay'deki birine teslim et.", k={b=3891369593, h=3500931227} }
V[97329] = { b="Anahtar Nerede?", h="Stranglethorn Vale'deki Ruins of Zul'kunda'daki trollerden elde ettiğin İlkel Anahtar'ı Zimmix Sputterspark'a götür.", k={b=2676899645, h=1375913282} }
V[97331] = { b="Zimmix'in Büyük Kaçışı", h="Zimmix Sputterspark'a Ruins of Zul'Kunda'dan uzaklaşana dek eşlik et, ardından Booty Bay'deki Rıhtım Ustası Lozgil'e kurtarmanın başarıyla sonuçlandığını bildir.", k={b=204767962, h=49744326} }
V[97420] = { b="Azalt, Yeniden Kullan, Uzlaş", h="Lake Nazferiti'deki Venture Co. tesislerinden 5 Varil Ham Petrol edin, ardından Stranglethorn Vale'deki Knaz Blunderflame'e dön.", k={b=261544341, h=4128667496} }
V[98024] = { b="Crossroads'a Yolculuk", h="The Barrens'taki The Crossroads'da Thork'a rapor ver.", k={b=2928091032, h=368556266} }
V[98027] = { b="Parıldayan Hilal Kolye", h="Hilal Kolye'yi Astranaar'daki Maliynn'e teslim et.", k={b=938223062, h=538795661} }
V[98059] = { b="Hillsbrad'ın Hazinesi", h="Sana verilen Mühürlü Şirket Talebi'ni Hillsbrad belediye binasındaki muhasebe masasına bırak.", k={b=1558922139, h=488359738} }
V[98071] = { b="Biracının Ticareti", h="Fallrook Varietal şişelerini Hillsbrad Foothills'in güneydoğusundaki Dun Garok'a teslim et ve onlardan bir çuval Ev Yapımı Şerbetçiotu getir.", k={b=3375732399, h=2517483600} }
V[98093] = { b="Temizlenecek Alan", h="Güney Barrens'taki Sulhasa, ağaçtan güvenle inebilmesi için bölgedeki 7 Stormhide kertenkelesini ve 7 Hecklefang Stalker'ı temizlemeni istiyor.", k={b=2123299283, h=4076907999} }
V[98094] = { b="Keşif Desteği", h="Yüce Cellat Darthalia, güncellenmiş emirleri Tarren Mill'in güneyinde, Dun Garok'un dışındaki Ölüm Takipçisi Masoj'a ulaştırmanı istiyor.", k={b=2711076464, h=728556148} }
V[98095] = { b="Değerli Gözetleme Noktaları", h="Ölüm Takipçisi Masoj, üç Eczacı Şişesi'ni Hillsbrad Foothills çevresindeki zirvelere yerleştirip kendisine dönmeni istiyor.", k={b=3746525066, h=829538510} }
V[98417] = { b="İntikam İzi", h="Maseara Autumnmoon, Forest Song'un batısında, Satyrnaar iblisleri arasında arama yapmanı istiyor. Döndüğünde kocası Kurothel'e dair bulduğun her izi ona bildir.", k={b=2331339645, h=3617437388} }
V[98418] = { b="Ortak Öfke", h="5 Xavian Rogue, 5 Felsworn, 5 Betrayer ve 5 Hellcaller öldür.$BArdından Forest Song'daki Maseara Autumnmoon'a dön.", k={b=406862370, h=833570496} }
V[98424] = { b="Fizsprocket'ın Notları", h="The Venture Co. Mine içindeki Gözetmen Fizsprocket'ın kalan sayfalarını topla ve bunları Bloodhoof Village yakınlarındaki Morin Cloudstalker'a götür.", k={b=782171029, h=3651126832} }
V[98427] = { b="Faaliyetlere Son", h="Clearcutter Anahtarı'nı Bloodhoof Village dışındaki Morin Cloudstalker'a götür.", k={b=3965421187, h=1611515217} }
V[98430] = { b="Uzak Yolcular", h="Perith Stormhoof'un Palemane Rock'tan kaçmasına yardım et ve güvende olduğunu Thunder Bluff'taki Cairne Bloodhoof'a bildir.", k={b=1178322575, h=4101164878} }
V[98435] = { b="Thunderhorn'un Raporu", h="Thunderhorn'un Raporu'nu Thunder Bluff'taki Baş Druid Hamuul Runetotem'e götür.", k={b=3754796613, h=2710343999} }
V[98463] = { b="Kasabanın Dilinde", h="Stranglethorn'daki Booty Bay'de, Salty Sailor Tavern'deki Nixxrax Fillamug'u ziyaret et.", k={b=1666854479, h=129339480} }
V[99079] = { b="Uzak Yolcu Malah", h="Bloodhoof Village'ın doğusunda, Mulgore'un sınırına yakın bir yerde Uzak Yolcu Malah Longwind'i bul.", k={b=3549401374, h=3562691855} }
V[99080] = { b="Onları Kovun", h="6 Galak Centaur ve 4 Galak Outrunner öldür, Yağmacı Herak'ın kafasını da Baine Bloodhoof'a götür.", k={b=1174663141, h=2040925676} }
V[99081] = { b="Kara Haberler", h="Uzak Yolcu Malah'ın Raporu'nu Bloodhoof Village'daki Cesur Wildrunner'a götür.", k={b=2635828294, h=2975084531} }
V[99082] = { b="Yüce Reis", h="Thunder Bluff'taki Yüce Reis Cairne Bloodhoof'un huzuruna çık.", k={b=651309841, h=982391168} }
V[99101] = { b="Kadim Düşmanımız", h="Uzak Yolcu Malah'ın Raporu'nu Baine Bloodhoof'a götür.", k={b=1651396955, h=3046289725} }
V[99108] = { b="İdman Dövüşü", h="Tang Stonehoof için düelloda 3 başka oyuncuyu ya da 3 Novice Warrior'ı yen.", k={b=2786751384, h=3516599387} }
V[99191] = { b="Yün Bağışı", k={b=3246343608} }
V[99192] = { b="İpek Bağışı", k={b=3246193226} }
V[99196] = { b="Yün Bağışı", k={b=3246343608} }
V[99197] = { b="İpek Bağışı", k={b=3246193226} }
V[99411] = { b="Kyle Kayıplara Karıştı!", h="Mulgore'daki Bloodhoof Village'dan Ahab Wheathoof, gözünün bebeği köpeği Kyle the Frenzied'ı beslemeni istiyor.$BKyle'ı Yumuşak Strider Eti ile besle ve Ahab Wheathoof'a dön.", k={b=3252552528, h=1170649051} }
