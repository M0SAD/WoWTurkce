if not WoWTurkce.FOREVER then return end -- yalnızca Classic Forever
-- Classic Forever'a özel görevler 2
-- b=başlık, a=açıklama, h=hedef, i=ilerleme, t=tamamlama
-- k = çevrilen İngilizce metnin parmak izi (metin değişirse çeviri gösterilmez, yeniden kaydedilir)
local V = WoWTurkce.Veri

V[79358] = { b="Fırtına, Toprak ve Ateş", h="5 Bozulmuş Ateş Totemi, 5 Bozulmuş Toprak Totemi, 5 Bozulmuş Hava Totemi ve 5 Bozulmuş Su Totemi topla ve bunları Arathi Highlands'deki Veyric Thunderhame için getir.", k={b=2347301607, h=2386837499} }
V[79360] = { b="Elementlerin Yardımı", h="Razorfen Kraul'daki Charlga Razorflank'i alt et ve quilboar'ların planları hakkında bilgi topla.", k={b=2081955754, h=3018474884} }
V[79361] = { b="Fırtına, Toprak ve Ateş", h="5 Bozulmuş Ateş Totemi, 5 Bozulmuş Toprak Totemi, 5 Bozulmuş Hava Totemi ve 5 Bozulmuş Su Totemi topla ve bunları Thousand Needles'daki Prate Cloudseer için getir.", k={b=2347301607, h=3036416625} }
V[79364] = { b="Gözler Gökyüzünde", h="Thousand Needles'daki Prate Cloudseer ile konuş.", k={b=935685264, h=110259828} }
V[79366] = { b="Çağrıma Kulak Ver", h="Quilboar ayinine son vermek için Bozulmuş Totemleri kullan.", k={b=500299837, h=1036218409} }
V[79442] = { b="Fırtınanın Silahları", h="Fırtına Gözü'nü Alterac Mountains'teki Rüzgâr Gözcüsü Bath'rah'ya teslim et.", k={b=1612535064, h=2757714203} }
V[92479] = { b="Karalanmış Bir Mektup", h="Karalanmış Mektup'u oku ve Northshire Abbey'deki Tordrin Stemblade ile konuş.", k={b=370324544, h=4139501561} }
V[92484] = { b="Elementleri Kucaklamak", h="Uğuldayan Geri Çağırma Kristali'ni incele, ardından Thendal Grove'daki Rüzgâr Biçimci Boro ile konuş.", k={b=2433884523, h=1920625111} }
V[92532] = { b="Savaşçının Yolu", h="Sana verilen Buruşuk Not'u oku, ardından Thendal Village gözetleme kulesindeki Kılıç Ustası Ren'i bul.", k={b=1195767820, h=2115457312} }
V[94003] = { b="Skybreaker Siperliği", h="Shrine of Akir'deki Zaal Stormshield'dan Skybreaker Siperliği'ni geri al.", k={b=2019208113, h=3122205651} }
V[94373] = { b="Toprağın Çağrısı", h="Anvilmar'daki Teo Hammerstorm'a 2 Frostmane Ayı Kolyesi götür.", k={b=743682218, h=1120147578} }
V[94374] = { b="Toprağın Çağrısı", h="Ruh Taşı'nı bul ve Toprak Saptası'nı iç.", k={b=743682218, h=21411748} }
V[94375] = { b="Toprağın Çağrısı", h="Ham Kuvars'ı Anvilmar'daki Teo Hammerstorm'a götür.", k={b=743682218, h=1712679087} }
V[94449] = { b="Ateşin Çağrısı", h="Dun Morogh'daki Bruegs Kindleborn'u bul.", k={b=413032028, h=530172800} }
V[94465] = { b="Ateşin Çağrısı", h="Uyuyan Alev Meşalesi'ni Loch Modan'daki Braldir Ashmantle'a götür.", k={b=413032028, h=1292432148} }
V[94466] = { b="Ateşin Çağrısı", h="Loch Modan'daki Braldir Ashmantle'a 1 Ateş Katranı ve 1 Reaktif Kesesi götür.", k={b=413032028, h=2657384298} }
V[94467] = { b="Ateşin Çağrısı", h="Küçük Ateş Tezahürü'nü alt et ve Parlayan Kor'u Shrine of Eternal Flame'in tepesindeki mangala yerleştir.", k={b=413032028, h=832171494} }
V[94468] = { b="Ateşin Çağrısı", h="Ebedi Alev Meşalesi'ni Dun Morogh'daki Bruegs Kindleborn'a götür.", k={b=413032028, h=1206017146} }
V[94472] = { b="Toprak Saptası", h="Yeni bir Toprak Saptası almak için Teo Hammerstorm ile konuş.", k={b=44361266, h=2350469912} }
V[94473] = { b="Ateş Saptası", h="Yeni bir Ateş Saptası almak için Braldir Ashmantle ile konuş", k={b=2115114308, h=3059848464} }
V[94494] = { b="Suyun Çağrısı", h="Loch Modan'daki Norric Lochthane'i bul.", k={b=765030489, h=2034565397} }
V[94495] = { b="Suyun Çağrısı", h="Wetlands'teki Hervdana Saegrund'u bul.", k={b=765030489, h=4290689602} }
V[94497] = { b="Suyun Çağrısı", h="Boş Kahverengi Su Tulumu'nu Hervdana'nın mağarasının altındaki şelalelerin dibinde doldur ve Wetlands'te ona geri götür.", k={b=765030489, h=561151794} }
V[94499] = { b="Suyun Çağrısı", h="Boş Kırmızı Su Tulumu'nu Nightcrawler Murloc'ların yakınındaki Stonewatch Falls'ta doldur ve Wetlands'teki Hervdana Saegrund'a dön.", k={b=765030489, h=3621889694} }
V[94500] = { b="Suyun Çağrısı", h="Doldurulmamış Mavi Su Tulumu'nu Ashenvale'deki Astranaar sularında doldur ve Wetlands'teki Hervdana Saegrund'a dön.", k={b=765030489, h=3678482270} }
V[94501] = { b="Suyun Çağrısı", h="En Saf Su Şişesi'ni Loch Modan'daki Norric Lochthane'e götür.", k={b=765030489, h=683638545} }
V[94502] = { b="Suyun Çağrısı", h="Westfall'daki Stendel's Pond'da yozlaşmayı temizle.$BBitirdiğinde Loch Modan'daki Norric'e dön.", k={b=765030489, h=1524459031} }
V[94503] = { b="Suyun Çağrısı", h="Westfall'daki Küçük Su Tezahürü ile konuş.", k={b=765030489, h=1742019205} }
V[94505] = { b="Suyun Çağrısı", h="Su Parçası'nı Loch Modan'daki Norric Lochthane'e götür.", k={b=765030489, h=4188040308} }
V[94616] = { b="Su Saptası", k={b=3096496961} }
V[94789] = { b="Havanın Çağrısı", h="Arathi Highlands'deki Veyric Thundervein'i bul.", k={b=12510674, h=1854207174} }
V[96016] = { b="Fırtınanın Silahları", h="Fırtına Gözü'nü Alterac Mountains'teki Rüzgâr Gözcüsü Bath'rah'ya teslim et.", k={b=1612535064, h=2757714203} }
V[96047] = { b="Kampçılık 101: İlk Yardım", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Kharanos'taki Thamner Pol ile konuş.", k={b=762724076, h=2883576231} }
V[96050] = { b="Kampçılık 101: Balıkçılık", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Dun Morogh'da, Iceflow Lake yakınlarındaki Paxton Ganter ile konuş.", k={b=284192958, h=1661354864} }
V[96055] = { b="Kampçılık 101: Bitkicilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Ironforge'daki Reyna Stonebranch ile konuş.", k={b=3946197293, h=3598687639} }
V[96056] = { b="Kampçılık 101: Deri Yüzme", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Ironforge'daki Balthus Stoneflayer ile konuş.", k={b=2976282647, h=1009805984} }
V[96057] = { b="Kampçılık 101: Terzilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Ironforge'daki Uthrar Threx ile konuş.", k={b=327957983, h=1898178146} }
V[96058] = { b="Kampçılık 101: Mühendislik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Kharanos'taki Bronk Guzzlegear ile konuş.", k={b=1918642817, h=1975185417} }
V[96059] = { b="Kampçılık 101: Efsunculuk", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Ironforge'daki Thonys Pillarstone ile konuş.", k={b=1416142581, h=1199473747} }
V[96101] = { b="Açık Havanın Tadı", h="Sohbet penceresine /sit yazarak Raan'ın Basit Kamp Ateşi'nin yanına otur ve Güçlendirilmiş Dinlenme etkisini alana kadar bekle.", k={b=1503652632, h=2897974037} }
V[96102] = { b="Kampçılık 101: Terzilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Orgrimmar'daki Snang ile konuş.", k={b=327957983, h=517484285} }
V[96135] = { b="Çağrıma Kulak Ver", h="Quilboar ayinine son vermek için Bozulmuş Totemleri kullan.", k={b=500299837, h=1036218409} }
V[96604] = { b="Açık Havanın Tadı", h="Sohbet penceresine /sit yazarak Brakk'ın Basit Kamp Ateşi'nin yanına otur ve Güçlendirilmiş Dinlenme etkisini alana kadar bekle.", k={b=1503652632, h=322927390} }
V[96605] = { b="Açık Havanın Tadı", h="Sohbet penceresine /sit yazarak Kaga'nın Basit Kamp Ateşi'nin yanına otur ve Güçlendirilmiş Dinlenme etkisini alana kadar bekle.", k={b=1503652632, h=696594727} }
V[96606] = { b="Açık Havanın Tadı", h="Lyreena'nın Basit Kamp Ateşi'nin yanına otur ve Güçlendirilmiş Dinlenme etkisini alana kadar bekle.", k={b=1503652632, h=2725723437} }
V[96607] = { b="Açık Havanın Tadı", h="Sohbet penceresine /sit yazarak Eleanor'un Basit Kamp Ateşi'nin yanına otur ve Güçlendirilmiş Dinlenme etkisini alana kadar bekle.", k={b=1503652632, h=2959838937} }
V[96608] = { b="Açık Havanın Tadı", h="Sohbet penceresine /sit yazarak Eric'in Basit Kamp Ateşi'nin yanına otur ve Güçlendirilmiş Dinlenme etkisini alana kadar bekle.", k={b=1503652632, h=674620790} }
V[96626] = { b="Kampçılık 101: Aşçılık", h="Aşçı olmayı öğrenmek için Goldshire'daki Tomas ile konuş.", k={b=934932832, h=4211582529} }
V[96627] = { b="Maceracı", h="Goldshire yakınlarındaki Sam Sarsparilla ile konuş.", k={b=993589702, h=3374205474} }
V[96628] = { b="Maceracı", h="Erzak Bohçası'nı Kharanos yakınlarındaki Eric Brighthammer'a teslim et.", k={b=993589702, h=4201760309} }
V[96629] = { b="Kampçılık 101: Aşçılık", h="Aşçı olmayı öğrenmek için Kharanos'taki Gremlock Pilsnor ile konuş.", k={b=934932832, h=1483619950} }
V[96630] = { b="Maceracı", h="Günlüğü Dolanaar yakınlarındaki Lyreena Duskblade'e götür.", k={b=993589702, h=3851229693} }
V[96634] = { b="Kampçılık 101: Aşçılık", h="Aşçı olmayı öğrenmek için Dolanaar'daki Zarrin ile konuş.", k={b=934932832, h=3951065780} }
V[96638] = { b="Maceracı", h="Shen'dar Village yakınlarındaki Raan Wildwind ile konuş.", k={b=993589702, h=3750445231} }
V[96646] = { b="Kampçılık 101: Aşçılık", h="Aşçı olmayı öğrenmek için Shen'dar Village'daki Zerril Softbreeze ile konuş.", k={b=934932832, h=155999062} }
V[96652] = { b="Maceracı", h="Günlüğü Razor Hill yakınlarındaki Brakk'a götür.", k={b=993589702, h=4168226014} }
V[96655] = { b="Kampçılık 101: Aşçılık", h="Aşçı olmayı öğrenmek için Razor Hill'deki Aşçı Torka ile konuş.", k={b=934932832, h=2682668032} }
V[96656] = { b="Maceracı", h="Brill yakınlarındaki Eleanor Shackleton ile konuş.", k={b=993589702, h=2553162185} }
V[96658] = { b="Kampçılık 101: Aşçılık", h="Aşçı olmayı öğrenmek için Brill'deki William Pickman ile konuş.", k={b=934932832, h=3699521667} }
V[96659] = { b="Maceracı", h="Erzak Bohçası'nı Bloodhoof Village yakınlarındaki Kaga Wildhoof'a teslim et.", k={b=993589702, h=1360879217} }
V[96661] = { b="Kampçılık 101: Aşçılık", h="Aşçı olmayı öğrenmek için Bloodhoof Village'daki Pyall Silentstride ile konuş.", k={b=934932832, h=860983864} }
V[97899] = { b="Kampçılık 101: Simya", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Orgrimmar'daki Whuut ile konuş.", k={b=2515214777, h=2813227459} }
V[97900] = { b="Kampçılık 101: Demircilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Razor Hill'deki Dwukk ile konuş.", k={b=3546084662, h=3170461299} }
V[97901] = { b="Kampçılık 101: Efsunculuk", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Orgrimmar'daki Jhag ile konuş.", k={b=1416142581, h=978635648} }
V[97902] = { b="Kampçılık 101: Mühendislik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Razor Hill'deki Mukdrak ile konuş.", k={b=1918642817, h=378519868} }
V[97903] = { b="Kampçılık 101: İlk Yardım", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Razor Hill'deki Rawrk ile konuş.", k={b=762724076, h=1151900180} }
V[97904] = { b="Kampçılık 101: Balıkçılık", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Sen'jin Village yakınlarındaki Lau'Tiki ile konuş.", k={b=284192958, h=2990667715} }
V[97905] = { b="Kampçılık 101: Bitkicilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Orgrimmar'daki Jandi ile konuş.", k={b=3946197293, h=996928524} }
V[97906] = { b="Kampçılık 101: Dericilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Orgrimmar'daki Karolek ile konuş.", k={b=2619566908, h=1524519535} }
V[97907] = { b="Kampçılık 101: Madencilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Razor Hill'deki Krunn ile konuş.", k={b=2755241176, h=1259466875} }
V[97908] = { b="Kampçılık 101: Deri Yüzme", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Orgrimmar'daki Thuwd ile konuş.", k={b=2976282647, h=4177337586} }
V[97915] = { b="Kampçılık 101: Simya", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Stormwind yakınlarında, Elwynn Forest'taki Simyacı Mallory ile konuş.", k={b=2515214777, h=2998020045} }
V[97916] = { b="Kampçılık 101: Demircilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Goldshire'daki Demirci Argus ile konuş.", k={b=3546084662, h=1814500382} }
V[97917] = { b="Kampçılık 101: Efsunculuk", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Stormwind'deki Betty Quin ile konuş.", k={b=1416142581, h=2028092866} }
V[97918] = { b="Kampçılık 101: Mühendislik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Stormwind'deki Sprite Jumpsprocket ile konuş.", k={b=1918642817, h=3995248123} }
V[97919] = { b="Kampçılık 101: İlk Yardım", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Goldshire'daki Michelle Belle ile konuş.", k={b=762724076, h=191394494} }
V[97920] = { b="Kampçılık 101: Balıkçılık", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Goldshire yakınlarındaki Lee Brown ile konuş.", k={b=284192958, h=1373833252} }
V[97921] = { b="Kampçılık 101: Bitkicilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Elwynn Forest'taki Bitkici Pomeroy ile konuş.", k={b=3946197293, h=953710671} }
V[97922] = { b="Kampçılık 101: Dericilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Goldshire'daki Adele Fielder ile konuş.", k={b=2619566908, h=4137796525} }
V[97923] = { b="Kampçılık 101: Madencilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Stormwind'deki Gelman Stonehand ile konuş.", k={b=2755241176, h=2206484597} }
V[97924] = { b="Kampçılık 101: Deri Yüzme", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Goldshire'daki Helene Peltskinner ile konuş.", k={b=2976282647, h=2027613047} }
V[97925] = { b="Kampçılık 101: Terzilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Elwynn Forest'ta, Eastvale Logging Camp'teki Eldrin ile konuş.", k={b=327957983, h=928139833} }
V[97927] = { b="Kampçılık 101: Simya", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Thunder Bluff'taki Kray ile konuş.", k={b=2515214777, h=1075558550} }
V[97928] = { b="Kampçılık 101: Demircilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Thunder Bluff'taki Thrag Stonehoof ile konuş.", k={b=3546084662, h=2588174794} }
V[97929] = { b="Kampçılık 101: Efsunculuk", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Thunder Bluff'taki Mot Dawnstrider ile konuş.", k={b=1416142581, h=537537430} }
V[97930] = { b="Kampçılık 101: Mühendislik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Mulgore'da, Venture Co. Mine'daki Twizwick Sprocketgrind ile konuş.", k={b=1918642817, h=1201539114} }
V[97931] = { b="Kampçılık 101: İlk Yardım", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Bloodhoof Village'daki Vira Younghoof ile konuş.", k={b=762724076, h=3370568006} }
V[97932] = { b="Kampçılık 101: Balıkçılık", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Bloodhoof Village'daki Uthan Stillwater ile konuş.", k={b=284192958, h=1104352545} }
V[97933] = { b="Kampçılık 101: Bitkicilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Thunder Bluff'taki Komin Winterhoof ile konuş.", k={b=3946197293, h=2426355650} }
V[97934] = { b="Kampçılık 101: Dericilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Bloodhoof Village'daki Chaw Stronghide ile konuş.", k={b=2619566908, h=2069717392} }
V[97935] = { b="Kampçılık 101: Madencilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Thunder Bluff'taki Brek Stonehoof ile konuş.", k={b=2755241176, h=936727800} }
V[97936] = { b="Kampçılık 101: Deri Yüzme", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Bloodhoof Village'daki Yonn Deepcut ile konuş.", k={b=2976282647, h=3829030660} }
V[97937] = { b="Kampçılık 101: Terzilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Thunder Bluff'taki Vhan ile konuş.", k={b=327957983, h=2550317932} }
V[97938] = { b="Kampçılık 101: Simya", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Dolanaar'daki Cyndra Kindwhisper ile konuş.", k={b=2515214777, h=2146352481} }
V[97939] = { b="Kampçılık 101: Demircilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Darkshore'da, Auberdine'deki Elisa Steelhand ile konuş.", k={b=3546084662, h=380591109} }
V[97940] = { b="Kampçılık 101: Efsunculuk", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Teldrassil'de, Oracle Glade'deki Alanna Raveneye ile konuş.", k={b=1416142581, h=2812181026} }
V[97941] = { b="Kampçılık 101: Mühendislik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Darkshore'da, Auberdine'deki Jenna Lemkenilli ile konuş.", k={b=1918642817, h=2451796753} }
V[97942] = { b="Kampçılık 101: İlk Yardım", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Dolanaar'daki Byancie ile konuş.", k={b=762724076, h=2089372723} }
V[97943] = { b="Kampçılık 101: Balıkçılık", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Darnassus'taki Astaia ile konuş.", k={b=284192958, h=4155978973} }
V[97944] = { b="Kampçılık 101: Bitkicilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Dolanaar'daki Malorne Bladeleaf ile konuş.", k={b=3946197293, h=2760897782} }
V[97946] = { b="Kampçılık 101: Dericilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Dolanaar'dan Darnassus'a giden yoldaki Nadyia Maneweaver ile konuş.", k={b=2619566908, h=992294769} }
V[97948] = { b="Kampçılık 101: Madencilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Auberdine'deki Kurdram Stonehammer ile konuş.", k={b=2755241176, h=1653933918} }
V[97949] = { b="Kampçılık 101: Deri Yüzme", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Dolanaar'dan Darnassus'a giden yoldaki Radnaal Maneweaver ile konuş.", k={b=2976282647, h=2654985198} }
V[97950] = { b="Kampçılık 101: Terzilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Darnassus'taki Trianna ile konuş.", k={b=327957983, h=3696369751} }
V[97951] = { b="Kampçılık 101: Simya", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Brill'deki Carolai Anise ile konuş.", k={b=2515214777, h=3204061750} }
V[97952] = { b="Kampçılık 101: Demircilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Undercity'deki Basil Frye ile konuş.", k={b=3546084662, h=4130635054} }
V[97953] = { b="Kampçılık 101: Efsunculuk", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Brill'deki Vance Undergloom ile konuş.", k={b=1416142581, h=2511076052} }
V[97954] = { b="Kampçılık 101: Mühendislik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Undercity'deki Graham Van Talen ile konuş.", k={b=1918642817, h=2881385558} }
V[97955] = { b="Kampçılık 101: İlk Yardım", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Brill'deki Hemşire Neela ile konuş.", k={b=762724076, h=1441159901} }
V[97956] = { b="Kampçılık 101: Balıkçılık", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Brill'deki Clyde Kellen ile konuş.", k={b=284192958, h=3695093079} }
V[97957] = { b="Kampçılık 101: Bitkicilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Brill'deki Faruza ile konuş.", k={b=3946197293, h=2790215092} }
V[97958] = { b="Kampçılık 101: Dericilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Brill'den Undercity'ye giden yoldaki Shelene Rhobart ile konuş.", k={b=2619566908, h=4013832668} }
V[97959] = { b="Kampçılık 101: Madencilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Undercity'deki Brom Killian ile konuş.", k={b=2755241176, h=2666352385} }
V[97960] = { b="Kampçılık 101: Deri Yüzme", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Brill'den Undercity'ye giden yoldaki Rand Rhobart ile konuş.", k={b=2976282647, h=2887573213} }
V[97961] = { b="Kampçılık 101: Terzilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Deathknell'den Brill'e giden yoldaki Bowen Brisboise ile konuş.", k={b=327957983, h=860671528} }
V[97963] = { b="Kampçılık 101: Simya", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Shen'dar Village'daki Nyassa Swiftdraught ile konuş.", k={b=2515214777, h=3233625290} }
V[97964] = { b="Kampçılık 101: Demircilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Shen'dar Village'daki Aedi Thriceforged ile konuş.", k={b=3546084662, h=2525965608} }
V[97965] = { b="Kampçılık 101: İlk Yardım", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Shen'dar Village'daki Naleeia Tattermend ile konuş.", k={b=762724076, h=899182598} }
V[97967] = { b="Kampçılık 101: Balıkçılık", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Shen'dar Village'daki Fenn Fairweather ile konuş.", k={b=284192958, h=416074584} }
V[97968] = { b="Kampçılık 101: Bitkicilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Valanaar'daki Syriel Nightrain ile konuş.", k={b=3946197293, h=3077624920} }
V[97969] = { b="Kampçılık 101: Dericilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Shen'dar Village'daki Indari Sunseam ile konuş.", k={b=2619566908, h=871984370} }
V[97970] = { b="Kampçılık 101: Madencilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Shen'dar Village'daki Messana Crestwind ile konuş.", k={b=2755241176, h=1637617914} }
V[97971] = { b="Kampçılık 101: Deri Yüzme", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Shen'dar Village'daki Mendalass Tattermend ile konuş.", k={b=2976282647, h=2124223279} }
V[97972] = { b="Kampçılık 101: Terzilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Shen'dar Village'daki Taleen Shimmerthread ile konuş.", k={b=327957983, h=2388009669} }
V[97973] = { b="Kampçılık 101: Terzilik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Shen'dar Village'daki Taleen Shimmerthread ile konuş.", k={b=327957983, h=2388009669} }
V[97979] = { b="Tanrıça Esirgemez", h="Elune's Light (Elune'un Işığı) ve Shadowmeld büyülerini kullan.", k={b=2934292315, h=2480882095} }
V[98284] = { b="Kampçılık 101: Efsunculuk", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Shen'dar Village'daki Nasalanna Windsinger ile konuş.", k={b=1416142581, h=2406104518} }
V[98285] = { b="Kampçılık 101: Mühendislik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Shadowgale Forest'taki Tuhaf Münzevi ile konuş.", k={b=1918642817, h=1989056838} }
V[98286] = { b="Kampçılık 101: Efsunculuk", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Shen'dar Village'daki Nasalanna Windsinger ile konuş.", k={b=1416142581, h=2406104518} }
V[98287] = { b="Kampçılık 101: Mühendislik", h="Mesleğinde yeterli ustalığı gösterdikten sonra, mesleğine uygun bir kamp eşyası yapmayı öğrenmek için Stormwind'deki Sprite Jumpsprocket ile konuş.", k={b=1918642817, h=3995248123} }
