-- Ölüm Özeti (Death Recap): büyü ve saldıran adlarını çevir
local G = WoWTurkce
local OZEL = { Falling = "Düşme", Melee = "Yakın Dövüş", Drowning = "Boğulma", Fatigue = "Yorgunluk", Lava = "Lav", Slime = "Balçık", Fire = "Ateş" }

local function cevirAd(t)
	if type(t) ~= "string" or t == "" or G.gizli(t) or G.turkceMi(t) then return nil end
	return OZEL[t] or (G.buyuAdiCevir and G.buyuAdiCevir(t)) or (type(G.Arayuz[t]) == "string" and G.Arayuz[t]) or nil
end
local function cevirKim(t)
	if type(t) ~= "string" or t == "" or G.gizli(t) or G.turkceMi(t) then return nil end
	return G.yaratikCevir and G.yaratikCevir(t)
end

local function uygula()
	if not G.ayar("acik") then return end
	local f = DeathRecapFrame
	local L = f and f.DeathRecapEntry
	if type(L) ~= "table" then return end
	for _, e in ipairs(L) do
		local si = e.SpellInfo
		if si then
			if si.Name and si.Name.GetText then
				local tr = cevirAd(si.Name:GetText()); if tr then si.Name:SetText(tr) end
			end
			if si.Caster and si.Caster.GetText then
				local tr = cevirKim(si.Caster:GetText()); if tr then si.Caster:SetText(tr) end
			end
		end
	end
end

local bagli = false
local function bagla()
	if bagli or not DeathRecapFrame then return end
	bagli = true
	DeathRecapFrame:HookScript("OnShow", function() if C_Timer then C_Timer.After(0, function() pcall(uygula) end) end end)
	if DeathRecapFrame.OpenRecap then hooksecurefunc(DeathRecapFrame, "OpenRecap", function() if C_Timer then C_Timer.After(0, function() pcall(uygula) end) end end) end
end

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function() pcall(bagla) end)
