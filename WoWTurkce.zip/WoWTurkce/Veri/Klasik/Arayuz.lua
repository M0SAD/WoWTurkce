if WoWTurkce.RETAIL or WoWTurkce.FOREVER then return end -- yalnızca Classic Era
-- Arayüz metinleri, oyun ipucu pencereleri ve hazır metin desenleri
local G = WoWTurkce
do local function _()
local T = G.Arayuz
T["Between a Saurok and a Hard Place"] = "Saurok ile Zor Bir Durum Arasında"
T["Champion of the Horde"] = "Horde'un Şampiyonu"
T["Crazy Cat Lady"] = "Kedici Deli Kadın"
T["Fish Tales"] = "Balık Hikayeleri"
T["Flotsam"] = "Batık Eşya"
T["Lost and Found"] = "Kayıp ve Bulunan"
end _() end
