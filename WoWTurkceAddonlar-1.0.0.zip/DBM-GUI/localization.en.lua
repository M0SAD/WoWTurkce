---@class DBMGUILocalization
local L = {}

DBM_GUI_L = L

L.MainFrame							= "Deadly Boss Mods" -- OPTIONAL

L.TranslationByPrefix				= "Çeviri: "
L.TranslationBy 					= nil -- your name here, localizers!
L.Website							= "Haberler/güncellemeler için MysticalOS'u takip edin |cFF73C2FBhttps://allmylinks.com/mysticalos|r. Yıllardır destekleriniz için teşekkürler!"
L.WebsiteButton						= "Web Sitesi"

L.OTabRaids							= "Raidler"
L.OTabLairs							= "Inler"--Retail Only (tab won't be shown on non retail game versions)
L.OTabDungeons						= "Zindanlar"
L.OTabWorld							= "Dünya Bossları"--Legacy/Classic. Since there are so many world mods, enough to get their own tab
L.OTabScenarios						= "Senaryolar"--Future use, will be used for scenarios and delves, likely after there are more than 2 mods (so probably 12.x or later)
L.OTabPlugins						= "Diğer"--Scenarios, PVP, Delves (11.x), Solo/Challenge content (torghast, mage tower, etc)
L.OTabOptions						= "Temel Seçenekler"
L.OTabTools							= "Araçlar"--Such as break timer button, durability checks, latency checks, keystone checks (in future)
L.OTabAbout							= "Hakkında"
L.SearchMatch						= "%d eşleşme"
L.SearchMatches						= "%d eşleşme"

--Main Tab, Tools checks
L.Tools_LatencyCheck				= "Gecikme Kontrolü"
L.Tools_DurabilityCheck				= "Dayanıklılık Kontrolü"
L.Tools_KeystoneCheck				= "Keystone Kontrolü"
L.Tools_GearCheck					= "Ekipman Kontrolü"
L.Tools_ConsumablesCheck			= "Tüketilebilir Kontrolü"

L.Tools_BreakTimer					= "Mola Zamanlayıcısı Başlat"
L.Tools_PizzaTimer					= "Genel Zamanlayıcı Başlat"

L.Tools_BrezArea					= "Savaş Diriltmesi Zamanlayıcısı"
L.Tools_ShowBrezFrame				= "Boss savaşlarında ve Mythic+ zindanlarında Savaş Diriltmesi hakları penceresini göster"
L.Tools_KeystoneArea				= "Keystone'lar"
L.Tools_ShowKeystoneOnComplete		= "Mythic+ tamamlandığında Keystone penceresini otomatik göster"
L.Tools_AddChallengeTeleports		= "Challenges arayüzüne ışınlanmaları ekle"
L.Tools_OverrideKeystoneSlash		= "Keystone penceresi için eğik çizgi komutlarını devral (/keystone, /keys ve /key)\n(Not: Bu işaretli değilse DBM bunları diğer eklentiler için asla devralmamaya çalışır. Ancak kullanılmayan varsa DBM onları kaydeder)"
L.Tools_ConsumablesArea				= "Tüketilebilir Kontrolü"
L.Tools_ShowConsumablesOnReadyCheck	= "Hazır kontrolü başladığında Tüketilebilir Kontrolü penceresini otomatik göster"

L.Tools_Duration					= "Süre"
L.Tools_Message						= "Zamanlayıcı Mesajı"

L.TabCategory_CURRENT_SEASON		= "Güncel Sezon"
L.CurrentSeasonProfileInfo		= "Güncel Sezon, farklı genişleme kategorilerindeki zindanları gruplar; her birinin kendi profilleri vardır. Zindan ayarlarını içe/dışa aktarmak, kopyalamak, silmek veya sıfırlamak için %s altında ilgili genişleme kategorisini seçin. Bu işlemler yalnızca güncel sezon zindanlarını değil, o kategorinin tüm modülünü etkiler."
L.CurrentSeasonProfileCategories	= "Dahil edilen genişleme kategorileri:"
L.CurrentSeasonCoreProfileInfo	= "%s temel profilinizi kullanır; %s > %s altından yönetilir."
L.TabCategory_FOREVER				= "Sonsuza dek"

L.TabCategory_OTHER					= "Diğer Modlar"
L.TabCategory_AFFIXES				= "Ekler (Affix)"

L.BossModLoaded 					= "%s istatistikleri"
L.BossModLoad_now 					= [[Bu boss modu yüklü değil.
Zindana girdiğinde yüklenecek.
Modu elle yüklemek için düğmeye de tıklayabilirsin.]]

L.PosX								= "X Konumu"
L.PosY								= "Y Konumu"

L.MoveMe 							= "Taşı beni"
L.Button_OK 						= "Tamam"
L.Button_Cancel 					= "İptal"
L.Button_LoadMod 					= "Eklentiyi Yükle"
L.Mod_Enabled						= "Etkin: %s"
L.Mod_AutoRelease					= "Otomatik Ruh Bırakma: %s"
L.Mod_AutoReleaseWipeOnly			= "Yalnızca yenilgilerde"
L.Mod_Reset							= "Varsayılan seçenekleri yükle"
L.Reset 							= "Sıfırla"
L.Import							= "İçe Aktar"
L.ButtonExportMod					= "Modu dışa aktar"
L.ButtonImportMod					= "Modu içe aktar"
L.ModProfileImportFooter			= "Bu savaş veya tüm modül için profil içe aktarmayı destekler."
L.ModProfileExportFooter			= "Yalnızca bu savaşın seçeneklerini dışa aktarır."
L.AddonProfileImportFooter			= "Tüm modül veya tek bir savaş için profil içe aktarmayı destekler."
L.AddonProfileExportFooter			= "Tüm modülün seçeneklerini dışa aktarır."
L.ModImportSuccess					= "%s için ayarlar içe aktarıldı."
L.ModImportFailed				    = "%s için ayarlar içe aktarılamadı. Veri geçersiz/bozuk veya desteklenmeyen biçimde olabilir."
L.ImportProfileFailed				= "Profil metni içe aktarılamadı. Veri geçersiz/bozuk veya desteklenmeyen biçimde olabilir."
L.ImportProfileWrongType			= "Bu içe aktarma metni farklı bir profil türü için."
L.ImportProfileWrongTypeCore		= "Bu bir temel ayar profili. DBM Seçenekleri > %s > %s üzerinden içe aktarın."
L.ImportProfileWrongTypeInstance	= "Bu bir modül profili. %s altındaki o modülün İstatistikler sayfasından içe aktarın."
L.ImportProfileWrongTypeBoss		= "Bu bir boss modülü profili. O bossun modül seçenekleri panelinden içe aktarın."
L.ImportProfileUnsupportedVersion	= "Bu içe aktarma metni desteklenmeyen bir profil sürümü kullanıyor."
L.ImportInstanceProfilePrompt		= "Bu metin tüm modülün ayarlarını içeriyor. Tüm modül ayarlarını mı yoksa yalnızca %s ayarlarını mı içe aktarmak istersiniz?"
L.ImportInstanceProfileAll			= "Tüm modül ayarlarını içe aktar"
L.ImportInstanceProfileBoss			= "Yalnızca bu boss"
L.ProfileImported					= "Profil içe aktarıldı."
L.PartialProfileImported			= "Profil %d/%d modül için içe aktarıldı; eksik modüller değiştirilmedi."

L.Enable							= ENABLE
L.Disable							= DISABLE

L.NoSound							= "Ses yok"

L.IconsInUse						= "Bu modun kullandığı simgeler"

-- Tab: Boss Statistics
L.BossStatistics					= "Boss İstatistikleri"
L.Statistic_Kills					= "Zaferler:"
L.Statistic_Wipes					= "Yenilgiler:"
L.Statistic_Incompletes				= "Tamamlanmayanlar:"--For scenarios, TODO, figure out a clean way to replace any Statistic_Wipes with Statistic_Incompletes for scenario mods
L.Statistic_BestKill				= "En İyi Zafer:"
L.Statistic_BestClear			    = "En İyi Temizleme:"
L.Statistic_BestRank				= "En İyi Sıra:"--Maybe not get used, not sure yet, localize anyways

-- Tab: General Options
L.TabCategory_Options	 			= "Genel Ayarlar"
L.Area_BasicSetup					= "DBM İlk Kurulum İpuçları"
L.Area_ModulesForYou				= "Size hangi DBM modülleri uygun?"
L.Area_ProfilesSetup				= "DBM Profilleri kullanım kılavuzu"
-- Panel: Core & GUI
L.Core_GUI 							= "Çekirdek ve Arayüz"
L.General 							= "Genel DBM Çekirdek Seçenekleri"
L.EnableMiniMapIcon					= "Mini harita düğmesini göster"
L.EnableCompartmentIcon				= "Bölme düğmesini göster"
L.UseSoundChannel					= "DBM'nin uyarı seslerini çaldığı ses kanalını ayarla"
L.UseMasterChannel					= "Ana ses kanalı."
L.UseDialogChannel					= "Diyalog ses kanalı."
L.UseSFXChannel						= "Ses Efektleri (SFX) kanalı."
L.Latency_Text						= "En fazla gecikme eşitleme eşiğini ayarla"

L.Button_RangeFrame					= "Menzil penceresini göster/gizle"
L.Button_InfoFrame					= "Bilgi penceresini göster/gizle"
L.Button_TestBars					= "Test çubuklarını başlat"
L.Button_MoveBars					= "Çubukları taşı"
L.Button_ResetInfoRange				= "Bilgi/Menzil pencerelerini sıfırla"
L.Button_ShowMidnightWizard			= "Midnight Kurulum Sihirbazı"

L.ModelOptions						= "3B Model Görüntüleyici Seçenekleri"
L.EnableModels						= "Boss seçeneklerinde 3B modelleri etkinleştir"
L.ModelSoundOptions					= "Model görüntüleyici için ses seçeneğini ayarla"
L.ModelSoundShort					= SHORT
L.ModelSoundLong					= TOAST_DURATION_LONG

L.ResizeOptions			 			= "Boyut Seçenekleri"
L.ResizeInfo						= "Arayüzü sağ alt köşeye tıklayıp sürükleyerek yeniden boyutlandırabilirsiniz."
L.Button_ResetWindowSize			= "Arayüz pencere boyutunu sıfırla"
L.Editbox_WindowWidth				= "Arayüz pencere genişliği"
L.Editbox_WindowHeight				= "Arayüz pencere yüksekliği"

L.UIGroupingOptions					= "Arayüz Gruplama Seçenekleri (değiştirmek, yüklenmiş modlar için arayüz yenilemesi gerektirir)"
L.GroupOptionsExcludeIcon			= "'Simge Koy' seçeneklerini büyüye göre gruplamaya dahil etme (bunun yerine kendi 'Simgeler' kategorisinde toplanır)"
L.GroupOptionsExcludePrivateAura	= "'Aura' ses seçeneklerini büyüye göre gruplamaya dahil etme (bunun yerine kendi 'Auralar' kategorisinde toplanır)"
L.AutoExpandSpellGroups2			= "Büyüye göre gruplanan seçenekleri otomatik genişlet"
L.ShowWAKeys						= "Boss Mod tetikleyicileriyle WeakAuras yazmaya yardımcı olmak için büyü adlarının yanında büyü anahtarlarını göster."
L.RenameSpellButton					= "Yeniden Adlandır"
L.RenameSpellHeader					= "%s için özel ad belirle"
L.GTFOAbilityTitle					= "GTFO"
L.GTFOAbilityDescription			= "Uzaklaşmanız gereken, hasar veren her yetenek"
--L.ShowSpellDescWhenExpanded		= "Gruplar genişletildiğinde büyü açıklamasını göstermeye devam et"--Might not be used
L.NoDescription						= "Bu yeteneğin açıklaması yok"
L.CustomOptions						= "Bu kategori, kendine ait büyü veya günlük kimliği olmayan bir yetenek ya da olay için özel seçenekler içerir. WeakAuras oluşturmayı kolaylaştırmak için özel bir elle verilmiş kimlikle gruplanmıştır"

--

-- Panel: Common Trash
L.GenericTrashForeverDungeonDescription = "Genel büyü uyarıları; her seviyedeki zindan çöp düşmanları için varsayılan olarak açık. Boss uyarıları, genel uyarılara açıkça kayıtlı, etkin bir boss modülü gerektirir. Zindan ve Raid ayarları bağımsızdır ve temel profillerde saklanır. Normal uyarı sesini kullanır. Seçili hedefiniz sınırlamayı atlar."
L.GenericTrashForeverRaidDescription = "Genel büyü uyarıları; her seviyedeki Raid çöp düşmanları için varsayılan olarak açık. Boss uyarıları, genel uyarılara açıkça kayıtlı, etkin bir boss modülü gerektirir. Zindan ve Raid ayarları bağımsızdır ve temel profillerde saklanır. Normal uyarı sesini kullanır. Seçili hedefiniz sınırlamayı atlar."
L.GenericTrashForeverEnabled		= "Tüm zindanlarda etkinleştir"
L.GenericTrashForeverRaids			= "Tüm Raidlerde etkinleştir"
L.GenericTrashStandardCast			= "Standart düşman büyüleri"
L.GenericTrashElite					= "Elit düşman büyüleri"
L.GenericTrashEliteFilter			= "Elit düşmanlar"
L.GenericTrashStandardMobs			= "Standart düşmanlar"
L.GenericTrashTitle					= "Genel Çöp Düşmanlar"
L.GenericTrashDungeonDescription	= "Zindan çöp düşmanı uyarıları; boss uyarıları, genel uyarılara açıkça kayıtlı, etkin bir boss modülü gerektirir. Retail'de sizden 3 seviye aşağıdan 2 seviye yukarıya kadar düşmanlar veya boss seviyesi: Standart -3 ile 0 arası; Teğmenler +1/+2 veya boss seviyesi (-1). Zindan ayarları bağımsızdır ve temel profillerde saklanır. Normal uyarı sesini kullanır. Hedefiniz sınırlamayı atlar."
L.GenericTrashRaidDescription		= "Raid çöp düşmanı uyarıları; boss uyarıları, genel uyarılara açıkça kayıtlı, etkin bir boss modülü gerektirir. Retail'de sizden 3 seviye aşağıdan 2 seviye yukarıya kadar düşmanlar veya boss seviyesi; kabul edilen tüm düşmanlar Standart ayarları kullanır. Raid ayarları bağımsızdır ve temel profillerde saklanır. Normal uyarı sesini kullanır. Hedefiniz sınırlamayı atlar."
L.GenericTrashDelveDescription		= "Delve çöp düşmanı uyarıları; boss uyarıları, genel uyarılara açıkça kayıtlı, etkin bir boss modülü gerektirir. Sizden 3 seviye aşağıdan 2 seviye yukarıya kadar düşmanlar veya boss seviyesi: Standart -3 ile 0 arası; Teğmenler +1/+2 veya boss seviyesi (-1). Delve ayarları bağımsızdır ve temel profillerde saklanır. Normal uyarı sesini kullanır. Hedefiniz sınırlamayı atlar."
L.GenericTrashRaidCast				= "Düşman büyüleri"
L.GenericTrashRaidFilter			= "Düşmanlar"
L.GenericTrashEnabled				= "Genel çöp düşman uyarılarını etkinleştir"
L.GenericTrashAllDungeons			= "Tüm zindanlarda da etkinleştir (tüm zorluklar)"
L.GenericTrashDelves				= "Delve'lerde etkinleştir"
L.GenericTrashRaids					= "Tüm Raidlerde etkinleştir (tüm zorluklar)"
L.GenericTrashCast					= "Standart çöp düşman büyüleri"
L.GenericTrashLieutenant			= "Teğmen çöp düşman büyüleri"
L.GenericTrashChannel				= "Düşman kanalize büyüleri"
L.GenericTrashShowTargets			= "Büyü hedeflerini göster"
L.GenericTrashStandardFilter		= "Standart düşmanlar"
L.GenericTrashLieutenantFilter		= "Teğmenler"
L.GenericTrashNonEliteFilter		= "Elit olmayan düşmanlar"
L.GenericTrashFilterOff				= "Kapalı"
L.GenericTrashFilterTarget			= "Yalnızca hedefiniz"
L.GenericTrashFilterAll				= "Tüm birimler: mesajlar ve sesler"
L.GenericTrashFilterSoundsTarget	= "Tüm birimler: mesajlar; yalnızca hedefiniz: sesler"
L.GenericTrashThrottleType			= "Sınırlama"
L.GenericTrashThrottleBoth			= "Mesajlar ve sesler"
L.GenericTrashThrottleSounds		= "Yalnızca sesler"
L.GenericTrashThrottleDuration		= "Sınırlama süresi (saniye)"

-- Panel: Auto Logging
L.Panel_AutoLogging					= "Otomatik Kayıt"

--Auto Logging: Logging toggles/types
L.Area_AutoLogging					= "Otomatik Kayıt Anahtarları"
L.AutologBosses						= "Seçili içeriği Blizzard savaş kaydıyla otomatik kaydet"
L.AdvancedAutologBosses				= "Seçili içeriği Transcriptor ile otomatik kaydet"
--Auto Logging: Global filter Options
L.Area_AutoLoggingFilters			= "Otomatik Kayıt Süzgeçleri"
L.RecordOnlyBosses					= "Çöp düşmanları kaydetme (Yalnızca bossları kaydeder. Çekme öncesi iksirleri ve ENCOUNTER_START'ı yakalamak için bosslardan önce '/dbm pull' kullanın)"
L.DoNotLogLFG						= "LFG veya LFR (sıra ile girilen) içeriği kaydetme"
--Auto Logging: Recorded Content types
L.Area_AutoLoggingContent			= "Otomatik Kayıt İçeriği"
L.LogCurrentMythicRaids				= "Güncel seviye (veya remix) Mythic Raidler"--Retail Only
L.LogCurrentRaids					= "Güncel seviye (veya remix) Mythic olmayan Raidler (Heroic, Normal ve LFG/LFR süzgeci kapalıysa LFR)"
L.LogTWRaids						= "Timewalking veya Chromie Time Raidleri (remix DAHİL DEĞİL)"--Retail Only
L.LogTrivialRaids					= "Önemsiz (karakter seviyesinin altında) Raidler"
L.LogCurrentMPlus					= "Güncel seviye (veya remix) M+ zindanları"--Retail Only
L.LogCurrentMythicZero				= "Güncel seviye (veya remix) Mythic 0 zindanları"--Retail Only
L.LogTWDungeons						= "Timewalking veya Chromie Time zindanları (remix DAHİL DEĞİL)"--Retail Only
L.LogCurrentHeroic					= "Güncel seviye Heroic zindanlar (Not: Heroic'i sırayla yapıyor ve kaydedilmesini istiyorsanız LFG süzgecini kapatın)"
L.LogDelves							= "Güncel seviye Delve'ler"--Retail Only
L.LogChallenges						= "Güncel seviye özel meydan okumalar (Torghast, Visions ve Mage Tower gibi)"--Retail Only

-- Panel: Extra Features
L.Panel_ExtraFeatures				= "Ek Özellikler"

L.Area_SoundAlerts					= "Ses/Yanıp Sönme Uyarı Seçenekleri"
L.LFDEnhance						= "Rol kontrolleri ve BG/LFG teklifleri için hazır kontrolü sesini Ana veya Diyalog kanalında çal ve uygulama simgesini yanıp söndür (yani SFX kapalı olsa bile sesler çalar ve genelde daha yüksektir)"
L.WorldBossNearAlert				= "Yakınınızdaki ihtiyacınız olan dünya bossları çekildiğinde hazır kontrolü sesi çal ve uygulama simgesini yanıp söndür"
L.RLReadyCheckSound					= "Hazır kontrolü yapıldığında sesi Ana veya Diyalog kanalından çal ve uygulama simgesini yanıp söndür."
L.AutoReplySound					= "DBM otomatik yanıt fısıltısı alındığında uyarı sesi çal ve uygulama simgesini yanıp söndür"

L.Area_CombatAlerts					= "Savaş Uyarı Seçenekleri"
L.Area_CombatAlertsRetail			= "Savaş Uyarı Seçenekleri (yalnızca açık alanda)"
L.AFKHealthWarning					= "AFK durumundayken can kaybediyorsanız (herhangi bir oranda) uyarı sesi çal ve uygulama simgesini yanıp söndür"
L.HealthWarningLow					= "Can kaybediyorsanız (yüzde 35'in altındayken) uyarı sesi çal ve uygulama simgesini yanıp söndür"
L.EnteringCombatAlert				= "Savaşa girdiğinizde uyarı sesi çal ve uygulama simgesini yanıp söndür"
L.LeavingCombatAlert				= "Savaştan çıktığınızda uyarı sesi çal"
--
L.TimerGeneral 						= "Zamanlayıcı Seçenekleri"
L.SKT_Enabled						= "Varsa güncel savaş için zafer rekoru zamanlayıcısını göster"
L.ShowRespawn						= "Yenilgiden sonra boss yeniden doğma zamanlayıcısını göster"
L.ShowQueuePop						= "Sıra açıldığında (LFG, BG vb.) kabul için kalan süreyi göster"
L.ShowBerserkWarnings				= "$spell:26662 zamanlayıcısında 10/5/3/1 dakika ve 30/10 saniye kala duyuru göster"
--
L.Area_3rdParty						= "Üçüncü Taraf Eklenti Seçenekleri"
L.AnnounceConsumables				= "Savaş başlarken tüketilebilir kontrolünü duyur"
L.Area_Invite						= "Davet Seçenekleri"
L.AutoAcceptFriendInvite			= "Arkadaşlardan gelen grup davetlerini otomatik kabul et"
L.AutoAcceptGuildInvite				= "Lonca üyelerinden gelen grup davetlerini otomatik kabul et"
L.Area_Advanced						= "Gelişmiş Seçenekler"
L.FakeBW							= "Sürüm kontrollerinde DBM yerine BigWigs gibi görün (BigWigs kullanımını zorunlu tutan loncalar için)"
--
L.Area_Tooltip						= "İpucu entegrasyonu"



-- Panel: Profiles
L.Panel_Profile						= "Profiller"
L.Area_CreateProfile				= "DBM Çekirdek Seçenekleri için Profil Oluşturma"
L.EnterProfileName					= "Profil adı girin"
L.CreateProfile						= "Varsayılan ayarlarla yeni profil oluştur"
L.Area_ApplyProfile					= "DBM Çekirdek Seçenekleri için Etkin Profili Ayarla"
L.SelectProfileToApply				= "Uygulanacak profili seçin"
L.Area_CopyProfile					= "DBM Çekirdek Seçenekleri için profil kopyala"
L.SelectProfileToCopy				= "Kopyalanacak profili seçin"
L.Area_DeleteProfile				= "DBM Çekirdek Seçenekleri için Profil Sil"
L.SelectProfileToDelete				= "Silinecek profili seçin"
L.Area_DualProfile					= "Boss modu profil seçenekleri"
L.DualProfile						= "Uzmanlığa göre farklı boss modu seçenekleri desteğini etkinleştir. (Boss modu profilleri, yüklü boss modu istatistik ekranından yönetilir)"

L.Area_ModProfile					= "Mod ayarlarını başka karakter/uzmanlıktan kopyala veya mod ayarlarını sil"
L.ModAllReset						= "Tüm mod ayarlarını sıfırla"
L.ModAllStatReset					= "Tüm mod istatistiklerini sıfırla"
L.ModAllResetConfirm				= "%s için tüm ayarları sıfırlamak istediğinize emin misiniz?"
L.ModAllStatResetConfirm			= "%s için tüm istatistikleri sıfırlamak istediğinize emin misiniz?"
L.ModProfileDeleteConfirm			= "%s mod profilini silmek istediğinize emin misiniz?"
L.SelectModProfileCopy				= "Tüm ayarları şuradan kopyala"
L.SelectModProfileCopySound			= "Yalnızca ses ayarını şuradan kopyala"
L.SelectModProfileCopyNote			= "Yalnızca not ayarını şuradan kopyala"
L.SelectModProfileDelete			= "Şunun mod ayarlarını sil"

L.Area_ImportExportProfile			= "Profilleri İçe/Dışa Aktar"
L.ImportExportInfo					= "İçe aktarma mevcut profilinizin üzerine yazar, sorumluluk size ait."
L.ButtonImportProfile				= "Profili içe aktar"
L.ButtonExportProfile				= "Profili dışa aktar"
L.Area_ImportExportSpellRenames	= "Büyü yeniden adlarını İçe/Dışa Aktar"
L.ImportExportSpellRenamesInfo	= "İçe aktarma mevcut büyü yeniden adlarınızın üzerine yazar, sorumluluk size ait."
L.ButtonImportSpellRenames			= "Büyü yeniden adlarını içe aktar"
L.ButtonExportSpellRenames			= "Büyü yeniden adlarını dışa aktar"
L.ExportSpellRenamesFailed			= "Büyü yeniden ad metni dışa aktarılamadı. Veri geçersiz/bozuk veya desteklenmeyen biçimde olabilir."
L.ImportSpellRenamesFailed			= "Büyü yeniden ad metni içe aktarılamadı. Veri geçersiz/bozuk veya desteklenmeyen biçimde olabilir."
L.ImportSpellRenamesWrongType		= "Büyü yeniden ad metni içe aktarılamadı. Bu dışa aktarma türü büyü yeniden adları değil."
L.ImportSpellRenamesUnsupportedVersion	= "Büyü yeniden ad metni içe aktarılamadı. Bu dışa aktarma sürümü desteklenmiyor."
L.SpellRenamesImported				= "Büyü yeniden adları içe aktarıldı."

L.ImportErrorOn						= "Ayar için özel sesler eksik: %s"
L.ImportVoiceMissing				= "Eksik ses paketi: %s"
L.ImportLegacyProfileFailed		= "Bu profil eski dışa aktarma biçimini kullanıyor ve içe aktarılamaz. Güncel bir DBM sürümünden yeni bir dışa aktarma alın veya başka bir profil kullanın."
L.ImportProfileFreshExport		= "Bu eski bir profilse, güncel bir DBM sürümünden yeni bir dışa aktarma alın veya başka bir profil kullanın."

-- Tab: Alerts
L.TabCategory_Alerts	 			= "Uyarılar"
L.Area_SpecAnnounceConfig			= "Özel Uyarı görselleri ve ses kılavuzu"
L.Area_SpecAnnounceNotes			= "Özel Uyarı Notları kılavuzu"
L.Area_VoicePackInfo				= "DBM Ses Paketleri hakkında bilgi"

-- Panel: Raidwarning
L.Tab_RaidWarning 					= "Duyurular"
L.RaidWarning_Header				= "Duyuru Seçenekleri"
L.RaidWarnColors 					= "Duyuru Renkleri"
L.RaidWarnColor_1 					= "Renk 1"
L.RaidWarnColor_2 					= "Renk 2"
L.RaidWarnColor_3		 			= "Renk 3"
L.RaidWarnColor_4 					= "Renk 4"
L.RaidWarnColor 					= "Renk"--Only one used in midnight
L.InfoRaidWarning					= [[Raid uyarı penceresinin konumunu ve renklerini belirleyebilirsin.
Bu pencere "X oyuncusu Y'den etkilendi" gibi mesajlar için kullanılır.]]
L.ColorResetted 					= "Bu alanın renk ayarları sıfırlandı."
L.ShowWarningsInChat 				= "Duyuruları sohbet penceresinde göster"
L.WarningIconLeft 					= "Simgeyi sol tarafta göster"
L.WarningIconRight 					= "Simgeyi sağ tarafta göster"
L.WarningIconChat 					= "Simgeleri sohbet penceresinde göster"
L.WarningAlphabetical				= "Adları alfabetik sırala"
L.Warn_Duration						= "Duyuru süresi"
L.None								= "Yok"
L.Random							= "Rastgele"
L.Outline							= "Anahat"
L.ThickOutline						= "Kalın anahat"
L.Monochrome						= "Tek Renk"
L.Slug								= "Yavaş"
L.RaidWarnSound						= "Raid duyurusunda ses çal"
L.AnnouncementMidnightNotice		= "Bu paneldeki seçenekler Blizzard'ın 'küçük' olarak sınıflandırdığı uyarılar içindir"

-- Panel: Spec Warn Frame
L.Panel_SpecWarnFrame				= "Özel Duyurular"
L.Area_SpecWarn						= "Özel Duyuru Seçenekleri"
L.ShowSWarningsInChat 				= "Özel duyuruları sohbet penceresinde göster"
L.SWarnNameInNote					= "Özel duyuru notu adınızı içeriyorsa Tür 5 seçeneklerini kullan"
L.SpecialWarningIcon				= "Özel duyurularda simge göster"
L.ShortTextSpellname				= "Duyuru metninde büyü yeniden adlarını kullan"
L.SpecWarn_FlashFrameRepeat			= "Yanıp sönme tekrar sayısı"
L.SpecWarn_Flash					= "Ekranı yanıp söndür"
L.SpecWarn_Vibrate					= "Kumandayı titret"
L.SpecWarn_FlashRepeat				= "Yanıp Sönmeyi Tekrarla"
L.SpecWarn_FlashColor				= "Yanıp sönme rengi %d"
L.SpecWarn_FlashDur					= "Yanıp sönme süresi"
L.SpecWarn_FlashAlpha				= "Yanıp sönme saydamlığı"
L.SpecWarn_DemoButton				= "Örnek göster"
L.SpecWarn_ResetMe					= "Varsayılanlara sıfırla"
L.SpecialWarnSoundOption			= "Varsayılan sesi ayarla"
--PreMidnight
L.SpecialWarnHeader1				= "ÖD 1: Sizi veya eylemlerinizi etkileyen normal öncelikli duyuruların seçenekleri"
L.SpecialWarnHeader2				= "ÖD 2: Herkesi etkileyen normal öncelikli duyuruların seçenekleri"
L.SpecialWarnHeader3				= "ÖD 3: YÜKSEK öncelikli duyuruların seçenekleri"
L.SpecialWarnHeader4				= "ÖD 4: YÜKSEK öncelikli kaçma özel duyurularının seçenekleri"
L.SpecialWarnHeader5				= "ÖD 5: Notunda oyuncu adınız geçen duyuruların seçenekleri (yalnızca sabit kodlu modlar)"
--Post Midnight
L.SpecialWarnHeaderMedium			= "ÖD 1: Blizzard'ın 'orta' olarak sınıflandırdığı mekanikler için duyurular"
L.SpecialWarnHeaderCritical			= "ÖD 2: Blizzard'ın 'kritik' olarak sınıflandırdığı mekanikler için duyurular"

-- Panel: Debuff Auras Frame
--Note, SpamBlockNoPrivateAuraSound reused here
L.Panel_PrivateAuras				= "Zayıflatma Auraları"
L.Area_PersonalPrivateAuras			= "Kişisel Zayıflatma Aurası Seçenekleri"
L.EnablePersonalPrivateAuraIcons	= "Kişisel Zayıflatma Aurası simgelerini ekranda göster"--checkbox
L.AlwaysShowPlayerAuras				= "Aura pencerelerini zindan dışında da göster"--checkbox
L.AuraMaxDuration					= "En uzun izlenen aura süresi"
L.SetPAGrowDirection				= "Büyüme yönü"--Dropdown
L.SetPAIconScale					= "Simge ölçeği"--Slider, Reused for personal and tank
L.SetPAMaxIcons						= "En fazla simge"--Slider, Reused for personal and tank
L.SetPAIconSpacing					= "Simge aralığı"--Slider, Reused for personal and tank
L.HidePATooltip						= "Üzerine gelince büyü ipucunu kapat"--checkbox
L.HidePABorder						= "Kenarlığı kapat"--checkbox
L.OnlyBossOrRoleAuras				= "Yalnızca Boss/Rol Auralarını göster (Not: Blizzard seçer ve tüm önemli auraları göstermez)"
L.Area_TankPrivateAuras				= "Yardımcı Tank Zayıflatma Aurası Seçenekleri"
L.EnableTankPrivateAuraIcons		= "Siz olmayan ilk tank rolündeki oyuncu için aura simgelerini göster"--checkbox
L.CoTankVisibility					= "Yardımcı tankı şu durumda göster:"
L.CoTankVisibilityAuto				= "Tank uzmanlığındayken"
L.CoTankVisibilityAlways			= "Her zaman"
L.CoTankVisibilityNever				= "Asla"
L.ShowSecondCoTank					= "Siz olmayan ikinci tank rolündeki oyuncu için aura simgelerini göster"--checkbox
L.CoTankUseHealerInFiveMan			= "5 kişilik zindanlarda ikinci tank yerine şifacıyı otomatik izle"
L.CoTankShowPlayerName				= "İzlenen oyuncu adını göster"
L.CoTankNameFontSize				= "İzlenen oyuncu adı yazı boyutu"
L.CoTankNameXOffset					= "İzlenen oyuncu adı X kayması"
L.CoTankNameYOffset					= "İzlenen oyuncu adı Y kayması"
L.CoTankSlot1Player					= "Birinci yardımcı tank yuvası oyuncusu"
L.CoTankSlot2Player					= "İkinci yardımcı tank yuvası oyuncusu"
L.CoTankAutomatic					= "Otomatik"
L.RIGHT								= "Sağ"
L.LEFT								= "Sol"
L.UP								= "Yukarı"
L.DOWN								= "Aşağı"
L.CENTER_HORIZONTAL					= "Yatay Ortala"
L.CENTER_VERTICAL					= "Dikey Ortala"

-- Panel: Generalwarnings
L.Tab_GeneralMessages 				= "Sohbet Penceresi Mesajları"
L.SelectChatFrameArea				= "Sohbet Penceresi Seçenekleri"
L.SelectChatFrameButton				= "Sohbet penceresi seç"
L.SelectChatFrameInfoIdle			= "Mesajlar %s içinde gösteriliyor."
L.SelectChatFrameDefaultName		= "varsayılan sohbet penceresi"
L.SelectChatFrameInfoDone			= "Mesajlar bu sohbet penceresinde gösterilecek."
L.SelectChatFrameInfoSelect			= "Seçmek için bir sohbet penceresine tıklayın."
L.SelectChatFrameInfoSelectNow		= "%s seçmek için tıklayın."
L.CoreMessages						= "Çekirdek Mesaj Seçenekleri"
L.ShowPizzaMessage 					= "Zamanlayıcı yayın mesajlarını sohbet penceresinde göster"
L.ShowAllVersions	 				= "Sürüm kontrolünde tüm grup üyelerinin boss modu sürümlerini sohbet penceresinde göster. (Kapalıysa yine de eski/güncel özeti verir)"
L.ShowReminders						= "Eksik, devre dışı, düzeltme gelmiş veya eski alt modlar ve hâlâ açık sessiz mod için hatırlatma mesajları göster"

L.CombatMessages					= "Savaş Mesajı Seçenekleri"
L.ShowEngageMessage 				= "Savaş başlangıç mesajlarını sohbet penceresinde göster"
L.ShowDefeatMessage 				= "Öldürme/yenilgi mesajlarını sohbet penceresinde göster"
L.ShowGuildMessages 				= "Lonca Raidleri için başlangıç/öldürme/yenilgi mesajlarını sohbet penceresinde göster"
L.ShowGuildMessagesPlus				= "Lonca grupları için Mythic+ başlangıç/öldürme/yenilgi mesajlarını da göster (Raid seçeneği gerekir)"

L.Area_ChatAlerts					= "Ek Uyarı Seçenekleri"
L.RoleSpecAlert						= "Raide katılırken ganimet uzmanlığınız mevcut uzmanlığınızla uyuşmuyorsa uyarı göster"
L.CheckGear							= "Çekme sırasında ekipman uyarısı göster (kuşanılan eşya seviyeniz çantadakinden çok düşükse (40+) veya ana silah kuşanılmamışsa)"
L.WorldBossAlert					= "Sunucunuzda dünya bossları lonca üyeleri veya arkadaşlarca çekilmiş olabilirse uyarı göster (gönderen CRZ'deyse hatalı olabilir)"
L.WorldBuffAlert					= "Sunucunuzda dünya güçlendirmesi hikâyesi başladığında uyarı ve zamanlayıcı göster"
L.RaidDiffChangedAlert				= "Raid zorluğu değiştiğinde uyarı göster"
L.RaidDiffChangedRaidOnly			= "Raid zorluğu değişim uyarısını yalnızca Raid grubundayken göster (Not: grup henüz Raide çevrilmediyse katılımda zorluğu bildirmez)"
L.DungeonDiffChangedAlert			= "Zindan zorluğu değiştiğinde uyarı göster"

L.Area_BugAlerts					= "Hata Bildirme Uyarı Seçenekleri"
L.BadTimerAlert						= "DBM en az 1 saniye hatalı bir zamanlayıcı algıladığında sohbet mesajı göster"

-- Panel: Spoken Alerts Frame
L.Panel_SpokenAlerts				= "Geri Sayımlar ve Ses Paketleri"
L.Area_VoiceSelection				= "Ses Seçimleri"
L.CountdownVoice					= "Sayım sesleri için birincil sesi ayarla"
L.CountdownVoice2					= "Sayım sesleri için ikincil sesi ayarla"
L.CountdownVoice3					= "Sayım sesleri için üçüncül sesi ayarla"
L.PullVoice							= "Çekme zamanlayıcıları için sesi ayarla"
L.VoicePackChoice					= "Sesli uyarılar için ses paketini ayarla"
L.CountdownStartTime				= "Blizzard zamanlayıcıları için geri sayım başlangıç süresini ayarla"
L.CountStart						= "%d saniye kaldı"
L.MissingVoicePack					= "Eksik Ses Paketi (%s)"
L.Area_CountdownOptions				= "Geri Sayım Seçenekleri"
L.Area_VoicePackReplace				= "Ses Paketi Değiştirme Seçenekleri (ses paketleri açıkken hangi sesleri susturup yerine geçer)"
L.VPReplaceNote						= "Not: Ses paketleri uyarı seslerinizi asla değiştirmez veya silmez.\nSes paketi yerine geçtiğinde yalnızca susturulurlar."
L.ReplacesAnnounce					= "Duyuru seslerini değiştir (Not: Aşama değişiklikleri ve ek düşmanlar dışında çok azı ses paketi kullanır"
L.ReplacesSADefault					= "Varsayılan Özel Duyuru seslerini değiştir (Kullanıcının belirlediği özel sesler asla değiştirilmez)"
L.Area_VoicePackAdvOptions			= "Ses Paketi Gelişmiş Seçenekleri"
L.Area_VoiceOverrides				= "Ses Geçersiz Kılmaları"
L.GTFOOverrideEnabled				= "GTFO uyarıları için ses ve seslendirmeleri geçersiz kıl"
L.GTFOOverrideSound					= "GTFO geçersiz kılma sesi"
L.VoiceOverrideSounds				= "Sesler"
L.VoiceOverrideVoicePack				= "Ses Paketi"
L.VoiceOverrideNoVoicePack			= "Seçili veya etkin ses paketi yok"
L.VoiceOverrideUnavailable			= "%s (kullanılamaz)"
L.VoiceOverrideNote					= "Kişisel özel uyarı sesleri ve Yok önceliklidir. Kullanılamayan ses dosyaları normal uyarı sesini kullanır."
L.Area_VPLearnMore					= "Ses paketleri ve bu seçeneklerin kullanımı hakkında daha fazla bilgi"
L.VPLearnMore						= "|cFF73C2FBhttps://github.com/DeadlyBossMods/DBM-Retail/wiki/%5BGuide%5D-DBM-&-Voicepacks#2022-update|r" -- OPTIONAL
L.Area_BrowseOtherVP				= "Curse'te diğer ses paketlerine göz at"
L.BrowseOtherVPs					= "|cFF73C2FBhttps://www.curseforge.com/wow/addons/search?search=dbm+voice|r" -- OPTIONAL
L.Area_BrowseOtherCT				= "Curse'te geri sayım paketlerine göz at"
L.BrowseOtherCTs					= "|cFF73C2FBhttps://www.curseforge.com/wow/addons/search?search=dbm+count+pack|r" -- OPTIONAL

-- Panel: Event Sounds
L.Panel_EventSounds					= "Olay Sesleri (Zafer, Yenilgi vb.)"
L.Area_SoundSelection				= "Zafer, Yenilgi, Çekme ve arka plan müziği için ses seçimleri"
L.EventVictorySound					= "Savaş zaferinde çalınacak sesi ayarla"
L.EventWipeSound					= "Savaş yenilgisinde çalınacak sesi ayarla"
L.EventEngagePT						= "Çekme zamanlayıcısı başlarken çalınacak sesi ayarla"
L.EventEngageSound					= "Savaş başlarken çalınacak sesi ayarla"
L.EventDungeonMusic					= "Zindan/Raid içinde çalınacak müziği ayarla"
L.EventEngageMusic					= "Savaşlar sırasında çalınacak müziği ayarla"
L.Area_EventSoundsExtras			= "Olay Sesi Seçenekleri"
L.EventMusicCombined				= "Zindan ve savaş seçimlerinde tüm müzik seçeneklerine izin ver (değişikliğin görünmesi için arayüz yenilemesi gerekir)"
L.DisableBuiltInMusic				= "Yerleşik olay seslerini/müziğini kapat ve yalnızca üçüncü taraf müzik paketlerini yükle"
L.Area_EventSoundsFilters			= "Olay Sesi Süzgeç Koşulları"
L.EventFilterDungMythicMusic		= "Mythic/Mythic+ zorlukta zindan müziği çalma"
L.EventFilterMythicMusic			= "Mythic/Mythic+ zorlukta savaş müziği çalma"

-- Tab: Timers
L.TabCategory_Timers				= "Zamanlayıcı Çubukları"
L.Area_ColorBytype					= "Çubukları türe göre renklendirme kılavuzu"
-- Panel: Color by Type
L.Panel_ColorByType	 				= "Çubuk Renkleri"
L.AreaTitle_BarColors				= "Normal Çubuk Renkleri (Varsayılanlar yetenek türüne göre atanır)"
L.AreaTitle_ImpBarColors			= "Önemli Çubuk Renkleri (Kullanıcının önemli olarak işaretlediği çubuklar)"
L.BarTexture						= "Çubuk dokusu"
L.BarStyle							= "Çubuk davranışı"
L.BarDBM							= "Klasik (mevcut küçük çubuk Büyütülmüş bağlantı noktasına kayar)"
L.BarSimple							= "Basit (küçük çubuk kaybolur ve yeni büyük çubuk oluşur)"
L.BarStartColor						= "Başlangıç rengi"
L.BarEndColor 						= "Bitiş rengi"
L.Bar_Height						= "Çubuk yüksekliği"
L.Slider_BarOffSetX 				= "Yatay Aralık"
L.Slider_BarOffSetY 				= "Dikey Aralık"
L.Slider_BarWidth 					= "Çubuk genişliği"
L.Slider_BarScale 					= "Çubuk ölçeği"
L.BarSaturation						= "Küçük zamanlayıcılar için çubuk doygunluğu (Dev çubuklar kapalıyken)"
L.BarBackgroundColor				= "Arka plan rengi"
L.BarBackgroundOpacity				= "Arka plan saydamlığı"
L.EnableBarBorder					= "Çubuk kenarlığını etkinleştir"
L.BarBorderSize						= "Kenarlık boyutu"
L.BarBorderColor					= "Kenarlık rengi"
L.Slider_TextOffSetX				= "Yazı X kayması"
L.Slider_TextOffSetY				= "Yazı Y kayması"
L.MidnightNote						= "Not: Midnight'taki API kısıtlamaları nedeniyle DBM farklı başlangıç ve bitiş renklerini destekleyemiyor. Yalnızca başlangıç rengi kullanılacak."

--Types
L.BarStartColorAdd					= "Başlangıç rengi 1 (Ek Düşman)"
L.BarEndColorAdd					= "Bitiş rengi 1 (Ek Düşman)"
L.BarStartColorAOE					= "Başlangıç rengi 2 (Alan Hasarı)"
L.BarEndColorAOE					= "Bitiş rengi 2 (Alan Hasarı)"
L.BarStartColorDebuff				= "Başlangıç rengi 3 (Hedefli)"
L.BarEndColorDebuff					= "Bitiş rengi 3 (Hedefli)"
L.BarStartColorInterrupt			= "Başlangıç rengi 4 (Kesme)"
L.BarEndColorInterrupt				= "Bitiş rengi 4 (Kesme)"
L.BarStartColorRole					= "Başlangıç rengi 5 (Rol)"
L.BarEndColorRole					= "Bitiş rengi 5 (Rol)"
L.BarStartColorPhase				= "Başlangıç rengi 6 (Aşama)"
L.BarEndColorPhase					= "Bitiş rengi 6 (Aşama)"
L.BarStartColorUI					= "Başlangıç rengi 7 (Önemli)"
L.BarEndColorUI						= "Bitiş rengi 7 (Önemli)"
L.BarStartColorI2					= "Başlangıç rengi 8 (Önemli)"
L.BarEndColorI2						= "Bitiş rengi 8 (Önemli)"
--Type 7 options
L.Bar7Header						= "Önemli Çubuk Seçenekleri"
L.Bar7ForceLarge					= "Her zaman büyük çubuk kullan"
L.Bar7CustomInline					= "Özel '!' satır içi simgesi kullan"
--Timer Example Texts
L.CBTGeneric						= "Genel"
L.CBTAdd							= "Ek Düşmanlar Geliyor"
L.CBTAOE							= "Alan Hasarı Büyüsü"
L.CBTTargeted						= "Hedefli Büyü"
L.CBTInterrupt						= "Kesilebilir Büyü"
L.CBTRole							= "Belirli Rol Büyüsü"
L.CBTPhase							= "Aşama Değişimi"
L.CBTImportant						= "Kullanıcı İçin Önemli Büyü"
--Dropdown Options
--Special Announce Dropdowns
L.SAOne								= "Ses Paketi / ÖD 1 yedeği"
L.SATwo								= "Ses Paketi / ÖD 2 yedeği"
L.SAThree							= "Ses Paketi / ÖD 3 yedeği"
L.SAFour							= "Ses Paketi / ÖD 4 yedeği"
L.PrivateAuraSoundCombatLockdown	= "Özel aura sesleri savaşta değiştirilemez."
--Timer Dropdowns
L.ColorDropGeneric					= "Genel (Türsüz)"
L.ColorDrop1						= "Renk 1 (Ek Düşman)"
L.ColorDrop2						= "Renk 2 (Alan Hasarı)"
L.ColorDrop3						= "Renk 3 (Hedefli)"
L.ColorDrop4						= "Renk 4 (Kesme)"
L.ColorDrop5						= "Renk 5 (Rol)"
L.ColorDrop6						= "Renk 6 (Aşama)"
L.CDDImportant1						= "Önemli 1 (Vurgulu 1)"
L.CDDImportant2						= "Önemli 2 (Vurgulu 2)"
--Countdown Dropdowns
L.CVoiceOne							= "Genel Geri Sayım 1"
L.CVoiceTwo							= "Genel Geri Sayım 2"
L.CVoiceThree						= "Genel Geri Sayım 3"

-- Panel: Bar Appearance
L.Panel_Appearance	 				= "Çubuk Görünümü"
L.Panel_Behavior	 				= "Çubuk Davranışı"
L.Panel_TextTimers					= "Yazı Zamanlayıcılar"
L.Area_TextTimers					= "Yaklaşan zamanlayıcı yazısı (çubuklar görünmese bile DBM sabit kodlu çubuk verisi)"
L.TextTimersEnable					= "Süresi dolmak üzere olan yazı zamanlayıcılarını göster (varsayılan kapalı)"
L.TextTimersThreshold				= "Kalan saniye şu kadarken göster"
L.TextTimersMaxLines				= "En fazla satır"
L.TextTimersMaxNameLength			= "En fazla ad uzunluğu (0: sınırsız)"
L.TextTimersFontSize				= "Yazı boyutu"
L.TextTimersUrgentThreshold			= "Şu saniyenin altında acil (0: kapalı)"
L.TextTimersUrgentColor				= "Acil rengi"
L.TextTimersIcon					= "Yetenek simgesini göster"
L.TextTimersInheritBarColor			= "Çubuk başlangıç ve bitiş rengini devral"
L.TextTimersIconPosition			= "Simge konumu"
L.TextTimersIconBoth				= "Her iki yanda simge"
L.AreaTitle_BarSetup				= "Çubuk Görünüm Seçenekleri"
L.AreaTitle_Behavior				= "Çubuk Davranış Seçenekleri"
L.AreaTitle_BarSetupSmall 			= "Küçük Çubuk Seçenekleri"
L.AreaTitle_BarSetupHuge			= "Dev Çubuk Seçenekleri"
L.AreaTitle_BarSetupVariance		= "Sapma Çubuğu Seçenekleri"
L.EnableHugeBar 					= "Dev çubuğu etkinleştir (Çubuk 2)"
L.EnableVarianceBar 				= "Zamanlayıcı çubuklarını yeteneğin en uzun sıra süresini gösterecek şekilde uzat"
L.VarianceColor						= "Sapma rengi"
L.VarianceTransparency				= "Çubuk saydamlığı"
L.VarianceTimerTextBehavior			= "Sapma zamanlayıcısı yazı davranışını ayarla"
L.ZeroatWindowEnds					= "Yazı bekleme aralığının sonunda sıfıra ulaşır"
L.ZeroatWindowStartPause			= "Yazı bekleme aralığının başında sıfıra ulaşır ve durur"
L.ZeroatWindowStartRestart			= "Yazı bekleme aralığının başında sıfıra ulaşır, sonra yeniden başlar"
L.ZeroatWindowStartNeg				= "Yazı bekleme aralığının başında sıfıra ulaşır, sonra eksiye gider"--Default
L.BarIconLeft 						= "Sol simge"
L.BarIconRight 						= "Sağ simge"
L.BarIconPosition					= "Simge konumu"
L.ExpandUpwards						= "Yukarı doğru genişlet"
L.FillUpBars						= "Doldur"
L.ClickThrough						= "Fare olaylarını kapat (tıklama geçer)"
L.Bar_Decimal						= "Ondalık şu sürenin altında gösterilir"
L.Bar_Alpha							= "Saydamlık"
L.Bar_EnlargeTime					= "Çubuk şu sürenin altında büyür"
L.Bar_AppearTime					= "Çubuklar şu sürenin üstünde gizlenir"--Used for when hidden bars show on the small bar anchor
L.Bar_HideLongBars					= "Çubukları eşiğin altına inene kadar gizle"
L.BarSpark							= "Çubuk kıvılcımı"
L.BarFlash							= "Süresi dolmak üzere olan çubuğu yanıp söndür"
L.BarSort							= "Kalan süreye göre sırala"
L.BarColorByType					= "Türe göre renklendir"
L.Highest							= "En yüksek üstte"
L.Lowest							= "En düşük üstte"
L.NoBarFade							= "Kademeli renk değişimi yerine Başlangıç/Bitiş renklerini Küçük/Büyük renkleri olarak kullan"
L.BarInlineIcons					= "Günlük simgelerini göster"--Deprecated
L.DisableRightClickBar				= "Zamanlayıcıları sağ tıkla iptal etmeyi kapat"
L.ShortTimerText					= "Zamanlayıcı yazısında büyü yeniden adlarını kullan"
L.HardcodedTimer					= "Büyü yeniden adlandırma ve istemediğiniz zamanlayıcıları kapatma gibi kaybolan özellikleri geri getirmek için (varsa) sabit kodlu zamanlayıcıları kullan"
L.KeepBar							= "Zamanlayıcıyı yetenek yapılana kadar etkin tut"
L.KeepBar2							= "(mod destekliyorsa)"
L.FadeBar							= "Menzil dışındaki yeteneklerin zamanlayıcılarını soldur"
L.BarSkin							= "Çubuk görünümü"
L.InlineIconsDropdown				= "Günlük simgesi stili"
L.SingleLargeIcon					= "Tek büyük simge"
L.DoubleLargeIcons					= "Çift büyük simge"
L.DoubleInlineIcons					= "Tüm büyük simgeler"
L.StackedMiniIcons					= "Yığılmış küçük simgeler"

-- Panel: Pull, Break, Combat
L.Panel_PullBreakCombat				= "Çekme ve Mola"

L.Area_SoundOptions					= "Ses Seçenekleri"

-- Tab: Global Disables & Filters
L.TabCategory_Filters	 			= "Genel Kapatmalar ve Süzgeçler"
L.Area_DBMFiltersSetup				= "DBM Süzgeçleri kılavuzu"
L.Area_BlizzFiltersSetup			= "Blizzard Süzgeçleri kılavuzu"

-- Panel: Toggle DBM Features
L.Panel_SpamFilter					= "DBM Özelliklerini Kapat"

L.Area_Global_Toggles				= "Özellik Genel Anahtarları"
L.NoWarnings						= "DBM Duyurularını tamamen kapat"
L.NoTimers							= "DBM zamanlayıcı çubuklarını kapat (açıksa Yazı Zamanlayıcılar yine görünür)"

L.Area_SpamFilter_SpecFeatures		= "Belirli Duyuru Özellikleri (yalnızca yukarıda tamamen kapatılmadıysa geçerli)"
L.SpamBlockNoShowAnnounce			= "HİÇBİR genel (vurgusuz) duyuru için yazı gösterme veya ses çalma"
L.SpamBlockNoSpecWarnText			= "Özel duyuru yazısını gösterme"
L.SpamBlockNoSpecWarnFlash			= "Özel duyuruda ekranı yanıp söndürme"
L.SpamBlockNoSpecWarnVibrate		= "Özel duyuruda kumandayı titretme"
L.SpamBlockNoSpecWarnSound			= "Özel duyuru seslerini çalma (Geri Sayımlar ve Ses Paketleri panelinde açılan ses paketi sesleri yine çalar)"

L.Area_Private_Aura_Features		= "Aura Özellikleri"
L.SpamBlockNoPrivateAuraSound		= "Aura seslerini kaydetme"
L.SpamBlockNoPrivateAuraFrame		= "Aura pencerelerini gösterme"

L.Area_SpamFilter_Timers			= "Belirli Zamanlayıcı Özellikleri (yalnızca yukarıda tamamen kapatılmadıysa geçerli)"
L.SpamBlockNoShowBossTimers			= "Zindan/Raid bossları için zamanlayıcı gösterme"
L.SpamBlockNoShowTrashTimers		= "Zindan/Raid çöp düşmanları için zamanlayıcı gösterme (Not: bu isim plakası bekleme sürelerini de kapatır)"
L.SpamBlockNoShowEventTimers		= "Olaylar veya istemler için zamanlayıcı gösterme (Sıra açılması, boss yeniden doğması vb.)"
L.SpamBlockNoShowUTimers			= "Kullanıcıların gönderdiği zamanlayıcıları gösterme (Özel/Çekme/Mola)"
L.SpamBlockNoCountdowns				= "Geri sayım seslerini çalma"
L.SpamBlockNoTLColors				= "Blizzard Zaman Çizelgesi renklerini ayarlama (Not: DBM çubuk renklerini de kapatır)"

L.Area_SpamFilter_Nameplates		= "İsim Plakası Özellikleri"
L.SpamBlockNoNameplate				= "Özel boss mekanikleri için yalnızca isim plakası simgelerini gösterme (düşmanlardaki güçlendirme/zayıflatmalar gibi)"
L.SpamBlockNoNameplateCD			= "Yetenekler için yalnızca isim plakası bekleme zamanlayıcısı simgelerini gösterme"
L.SpamBlockNoNameplateCasts			= "Yetenekler için yalnızca isim plakası büyü zamanlayıcısı simgelerini gösterme"
L.SpamBlockNoBossGUIDs				= "Ayrıca zamanlayıcısı olan yetenekler için isim plakası bekleme simgelerini gösterme\n(Genelde zindan bosslarına uygulanır)"
L.AlwaysKeepNPs						= "Süresi dolan isim plakası bekleme simgelerini yetenek yeniden yapılana kadar görünür tut"

L.Area_SpamFilter_Misc				= "Diğer Özellikler"
L.SpamBlockNoSetIcon				= "Hedeflere otomatik simge koyma"
L.SpamBlockNoRangeFrame				= "Menzil penceresini otomatik gösterme"
L.SpamBlockNoInfoFrame				= "Bilgi penceresini otomatik gösterme"
L.SpamBlockNoYells					= "Sohbete bağırma gönderme"
L.SpamBlockNoNoteSync				= "Paylaşılan notları kabul etme"
L.SpamBlockAutoGossip				= "Konuşma pencerelerini otomatik yönetme"

L.Area_Restore						= "DBM Geri Yükleme Seçenekleri (modlar bitince DBM önceki kullanıcı durumunu geri yükler mi)"
L.SpamBlockNoIconRestore			= "Simge durumlarını kaydetme ve savaş sonunda geri yükleme"
L.SpamBlockNoRangeRestore			= "Modlar 'gizle' dediğinde menzil penceresini önceki durumuna geri yükleme"

L.Area_PullTimer					= "Çekme, Mola ve Özel Zamanlayıcı Süzgeç Seçenekleri"
L.DontShowPTNoID					= "Sizinle aynı bölgeden gönderilmeyen DBM Çekme Zamanlayıcılarını engelle"
L.DontShowPT						= "Çekme/Mola Zamanlayıcısı çubuğunu gösterme"
L.DontShowPTText					= "Çekme/Mola Zamanlayıcısı için duyuru yazısı gösterme"
L.DontPlayPTCountdown				= "Çekme/Mola/Özel Zamanlayıcı geri sayım sesini hiç çalma"
L.PT_Threshold						= "Çekme/Mola/Özel Zamanlayıcı geri sayım sesini şu sürenin üstünde çalma"

-- Panel: Reduce Information
L.Panel_ReducedInformation			= "Bilgiyi Azalt"

L.Area_SpamFilter_Anounces			= "Duyuru Süzgeçleri/Azaltma"
L.SpamBlockNoShowTgtAnnounce		= "Sizi etkilemeyen HEDEF genel duyuruları için yazı gösterme veya ses çalma; belirtilen uyarılar bu süzgeci yok sayar (DBM Özellikleri'ndeki genel kapatma bunun önüne geçer)"
L.SpamBlockNoTrivialSpecWarnSound	= "Seviyenize göre önemsiz içerikte özel duyuru sesi çalma veya ekranı yanıp söndürme (onun yerine kullanıcının seçtiği vurgusuz duyuru sesini çalar)"

L.Area_SpamFilter					= "İstenmeyen Mesaj Süzgeci Seçenekleri"
L.DontShowFarWarnings				= "Uzaktaki olaylar için duyuru/zamanlayıcı gösterme"
L.StripServerName					= "Duyurularda, zamanlayıcılarda, menzil kontrolünde ve bilgi penceresinde sunucu adını kaldır"
L.FilterVoidFormSay2				= "Void Form'dayken sohbete simge veya geri sayım bağırması gönderme (normal bağırmalar yine gönderilir)"

L.Area_SpecFilter					= "Rol Süzgeci Seçenekleri"
L.FilterDispels						= "Arındırma yeteneğiniz bekleme süresindeyse arındırılabilir büyüler için duyuru gösterme"
L.FilterCrowdControl				= "Kitle kontrolünüz bekleme süresindeyse kitle kontrolüyle kesme duyurularını gösterme"
L.FilterTrashWarnings				= "Yardımcı, normal ve önemsiz (seviyesi geçilmiş) zindanlarda hiçbir çöp düşman duyurusu gösterme"

L.Area_BInterruptFilter				= "Boss Kesme Süzgeci Seçenekleri"
L.FilterTargetFocus					= "Büyüyü yapan mevcut hedef/odak/yumuşak düşman değilse gösterme"
L.FilterInterruptCooldown			= "Kesme büyüsü bekleme süresindeyse gösterme"
L.FilterInterruptHealer				= "Şifacı uzmanlığındaysanız gösterme"
L.FilterInterruptNoteName			= "Uyarının sayımı varsa ama adınız özel notta yoksa gösterme"--Only used on bosses, trash mods don't assign counts
L.Area_BInterruptFilterFooter		= "Hiçbir süzgeç seçilmezse tüm kesmeler gösterilir (Çok fazla olabilir)\nBüyü kritik önemdeyse bazı modlar bu süzgeçleri tamamen yok sayabilir"
L.Area_TInterruptFilter				= "Çöp Düşman Kesme Süzgeci Seçenekleri"--Reuses above 3 strings

-- Panel: Blizzard Features
L.Panel_HideBlizzard				= "Blizzard Özelliklerini Engelle"
--Toast
L.Area_HideToast					= "Blizzard bildirimlerini (açılır pencereler) kapat"
L.HideGarrisonUpdates				= "Boss savaşlarında yardımcı bildirimlerini gizle"
L.HideGuildChallengeUpdates			= "Boss savaşlarında lonca meydan okuma bildirimlerini gizle"
--L.HideBossKill					= "Boss öldürme bildirimlerini gizle"--NYI
--L.HideVaultUnlock					= "Kasa kilidi açma bildirimlerini gizle"--NYI
--Cut Scenes
L.Area_Cinematics					= "Oyun içi sinematikleri engelle"
L.DuringFight						= "Boss savaşlarında savaş içi ara sahneleri engelle"--uses explicite IsEncounterInProgress check
L.InstanceAnywhere					= "Zindan veya Raid içinde savaş dışı ara sahneleri her yerde engelle"
L.NonInstanceAnywhere				= "TEHLİKE: Açık dünyada ara sahneleri engelle (önerilMEZ)"
L.OnlyAfterSeen						= "Ara sahneleri yukarıdaki seçimlere göre yalnızca en az bir kez izlendikten sonra engelle. (Hikâyeyi en az bir kez amaçlandığı gibi yaşamak için bu seçenek şiddetle önerilir)"
--Sound
L.Area_Sound						= "Oyun içi sesleri engelle"
L.DisableSFX						= "Boss savaşlarında ses efektleri kanalını kapat"
L.DisableAmbiance					= "Boss savaşlarında ortam sesi kanalını kapat"
L.DisableMusic						= "Boss savaşlarında müzik kanalını kapat (Not: Açıksa, olay seslerinde açık olan özel boss müziği çalmaz)"
--Other
L.Area_HideBlizzard					= "Diğer Blizzard Rahatsızlıklarını Kapat ve Gizle"
L.HideBossEmoteFrame				= "Boss savaşlarında Blizzard Raid Uyarılarını gizle"
L.HideWatchFrame					= "Başarım izlenmiyorsa ve Mythic+ içinde değilseniz boss savaşlarında görev takip (hedefler) penceresini gizle"
L.HideQuestTooltips					= "Boss savaşlarında ipuçlarındaki görev hedeflerini gizle"--Currently hidden (NYI)
L.HideBlizzardTimeline				= "Boss savaşlarında Blizzard Raid Zaman Çizelgesini gizle"

-- Panel: Raid Leader Controls
L.Tab_RLControls					= "Raid Lideri Kontrolleri"
L.Area_FeatureOverrides				= "Özellik Geçersiz Kılma Seçenekleri"
L.OverrideIcons 					= "Raiddeki tüm kullanıcılar için simge işaretlemeyi kapat (sizinki dahil)"-- (Use override instead of disable if you want DBM to do marking under your terms)
L.OverrideSay						= "Raiddeki tüm kullanıcılar için sohbet balonu/SAY mesajlarını kapat (sizinki dahil)"
L.DisableStatusWhisperShort			= "Tüm grup için durum/yanıt fısıltılarını kapat"--Duplicated from privacy but makes sense to include option in both panels
L.DisableGuildStatusShort			= "Tüm grup için ilerleme mesajlarının loncaya eşitlenmesini kapat"--Duplicated from privacy but makes sense to include option in both panels
--L.DisabledForDropdown				= "Kapatmanın gönderileceği boss mod(lar)ını seçin"--NYI
--L.DiabledForBoth					= "Yukarıdaki özellikleri hem DBM hem BW için kapat"--NYI
--L.DiabledForDBM					= "Yukarıdaki özellikleri yalnızca DBM kullanıcıları için kapat"--NYI
--L.DiabledForBW					= "Yukarıdaki özellikleri yalnızca BW kullanıcıları için kapat"--NYI

L.Area_ConfigOverrides				= "Yapılandırma Geçersiz Kılma Seçenekleri (henüz yok, ileride gelecek)"--NYI
L.OverrideBossAnnounceOptions		= "Tüm DBM kullanıcılarının boss modu duyuru yapılandırmasını benimkine ayarla"--NYI
L.OverrideBossTimerOptions			= "Tüm DBM kullanıcılarının boss modu zamanlayıcı yapılandırmasını benimkine ayarla"--NYI
L.OverrideBossIconOptions			= "Tüm DBM kullanıcılarının boss modu simge yapılandırmasını benimkine ayarla (yukarıda simge ayarı kapalıysa bu seçenek yok sayılır)"--NYI
L.OverrideBossSayOptions			= "Tüm DBM kullanıcılarının boss modu sohbet balonu yapılandırmasını benimkine ayarla (yukarıda sohbet balonu ayarı kapalıysa bu seçenek yok sayılır)"--NYI
L.ConfigAreaFooter					= "Bu alandaki seçenekler, kaydedilmiş yapılandırmayı değiştirmeden savaş başında kullanıcıların yapılandırmasını yalnızca geçici olarak geçersiz kılar."
L.ConfigAreaFooter2					= "Tüm rolleri düşünmeniz ve bir tankın vb. ihtiyaç duyabileceği zamanlayıcı/uyarıları dışarıda bırakmamanız önerilir"

L.Area_receivingOptions				= "Alma Seçenekleri (henüz yok, ileride gelecek)"--NYI
L.NoAnnounceOverride				= "Raid liderlerinden duyuru geçersiz kılmalarını kabul etme."--NYI
L.NoTimerOverridee					= "Raid liderlerinden zamanlayıcı geçersiz kılmalarını kabul etme."--NYI
L.ReplaceMyConfigOnOverride			= "UYARI: Geçersiz kılmada mod yapılandırmalarımı Raid liderininkiyle kalıcı olarak değiştir"--NYI
L.ReceivingFooter					= "Simge ve sohbet balonu geçersiz kılmalarından çıkılamaz çünkü bu ayarlar etrafınızdaki diğer oyuncuları etkiler"--NYI
L.ReceivingFooter2					= "Bu seçenekleri açarsanız, yapılandırmanız Raid liderinin niyetiyle çakışırsa bu sizinle lider arasındadır"--NYI
L.ReceivingFooter3					= "'Mod yapılandırmamı değiştir' seçeneğini açarsanız geçersiz kılmada asıl ayarlarınız kaybolur"--NYI


L.TabFooter							= "Bu paneldeki tüm seçenekler yalnızca zindan/LFR olmayan bir grupta grup lideriyseniz çalışır"

-- Panel: Privacy
L.Tab_Privacy 						= "Otomatik Yanıt ve Gizlilik"
L.Tab_PrivacyMidnight				= "Eklenti İletişimi Gizliliği"
L.Area_WhisperMessages				= "Fısıltı Mesajı Seçenekleri"
L.AutoRespond 						= "Savaşırken fısıltılara otomatik yanıt ver"
L.WhisperStats 						= "Fısıltı yanıtlarına öldürme/yenilgi istatistiklerini ekle"
L.DisableStatusWhisper 				= "Tüm grup için durum fısıltılarını kapat (Grup Lideri gerekir). Yalnızca normal/heroic/mythic Raidler ve mythic+ zindanlar için geçerli"
L.Area_SyncMessages					= "Eklenti Eşitleme Seçenekleri"
L.DisableGuildStatus 				= "İlerleme mesajlarının loncaya eşitlenmesini kapat. Grup lideriyseniz grubunuzdaki tüm DBM kullanıcıları için kapatır"
L.EnableWBSharing 					= "Bir dünya bossunu çektiğinizde/yendiğinizde loncanız ve aynı sunucudaki battle.net arkadaşlarınızla paylaş."

-- Tab: Frames & Integrations
L.TabCategory_Frames				= "Pencereler ve Entegrasyonlar"
L.Area_NamelateInfo					= "DBM İsim Plakası Auraları Bilgisi"
-- Panel: InfoFrame
L.Panel_InfoFrame					= "Bilgi Penceresi"

-- Panel: Range
L.Panel_Range						= "Menzil Penceresi"

-- Panel: Nameplate
L.Panel_Nameplates					= "İsim Plakaları"
L.Plater_Config						= "Plater Ayarlarını Aç"
L.ThreatPlates_Config				= "Threat Plates Ayarlarını Aç"
L.Area_NPStyle						= "Stil (Not: Yalnızca Plater kullanılmıyorken stili ayarlar.)"
L.NPAuraText						= "İsim plakası simgelerinde zamanlayıcı yazısını göster"
L.NPAuraSize						= "Simge piksel boyutu (kare)"
L.NPIcon_BarOffSetX 				= "Simge X Kayması"
L.NPIcon_BarOffSetY 				= "Simge Y Kayması"
L.NPIcon_GrowthDirection 			= "Simge Büyüme Yönü"
L.NPIcon_Spacing		 			= "Simge Aralığı"
L.NPIcon_MaxTextLen		 			= "En Fazla Yazı Uzunluğu"
L.NPIconAnchorPoint		 			= "Simge Bağlantı Noktası"
L.NPDemo							= "Test (İsim plakalarının yakınında olun)"
L.FontTypeTimer						= "Zamanlayıcı yazı tipini seç"
L.FontTypeText						= "Metin yazı tipini seç"
L.AuraDurationFontSize				= "Süre yazı boyutu"
L.AuraDurationFontColor				= "Süre yazı rengi"
L.AuraDurationEmphasizeAt			= "Süreyi şu değerin altında vurgula"
L.AuraDurationEmphasizeColor		= "Vurgulu süre rengi"
L.AuraIconZoom						= "Simge yakınlaştırma"
L.AuraShowDecimalSeconds			= "Ondalık saniyeleri göster"
L.AuraDecimalThreshold				= "Ondalıkları şu değerin altında göster"
L.AuraStackFontSize					= "Yığın yazı boyutu"
L.AuraStackFontColor				= "Yığın yazı rengi"
L.AuraShowStacks					= "Yığın yazısını göster"
L.AuraShowDispelBorder				= "Arındırma kenarlığını göster"
L.AuraShowCooldownSwipe				= "Bekleme süresi taramasını göster"
L.AuraShowGlow						= "Auralar etkinken simgeleri parlat"
L.AuraSortOrder					= "Aura sıralama düzeni"
L.AuraSortDefault					= "Varsayılan Blizzard sıralaması"
L.AuraSortShortDurationFirst		= "Önce kısa süreli"
L.AuraSortLongDurationFirst		= "Önce uzun süreli"

L.Area_NPGlow						= "Parlama (Not: Yalnızca Plater kullanılmıyorken parlamayı ayarlar.)"
L.NPIcon_GlowBehavior				= "Bekleme Simgesi Parlama Davranışı"
L.NPIcon_CastGlowBehavior			= "Büyü Simgesi Parlama Davranışı"
L.NPIcon_GlowNone					= "Simgeleri Asla Parlatma"
L.NPIcon_GlowImportant				= "Süresi dolan önemli Bekleme/Büyü simgelerini parlat"
L.NPIcon_GlowAll					= "Süresi dolan tüm Bekleme/Büyü simgelerini parlat"
L.NPIcon_GlowTypeCD					= "Bekleme Simgesi Parlama Türü"
L.NPIcon_GlowTypeCast				= "Büyü Simgesi Parlama Türü"
L.NPIcon_Pixel						= "Piksel"
L.NPIcon_Proc						= "Proc (İlk oturum görünümünde görsel hata)"
L.NPIcon_AutoCast					= "Otomatik Yapma"
L.NPIcon_Button						= "Düğme"

-- Misc
L.Area_General						= "Genel"
L.Area_Position						= "Konum"
L.Area_Style						= "Stil"

L.FontSize							= "Yazı boyutu"
L.FontStyle							= "Yazı tipi bayrakları"
L.FontColor							= "Yazı tipi rengi"
L.FontShadow						= "Yazı Tipi Gölgesi"
L.FontType							= "Yazı tipi seç"

L.FontHeight	= 16 -- OPTIONAL



-- Testing


L.Test								= "Test"


L.BossModTColor						= "Çubuk Rengi"
L.BossModColor						= "Yazı Rengi"
L.ColorCustom						= "Özel"
L.BossModCVoice						= "Geri Sayım Sesi"
L.BossModSWSound					= "Duyuru Sesi"
