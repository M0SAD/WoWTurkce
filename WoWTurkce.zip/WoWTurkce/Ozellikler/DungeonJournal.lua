-- DungeonJournal (ForeverDungeonJournal) Türkçe dil desteği.
local G = WoWTurkce

local L = {
    ARROW_ABOVE = "Yukarıda: çıkış yolunu bul",
    ARROW_BELOW = "Yerin altında: iniş yolunu bul",
    ARROW_BOAT = "%s gemisine bin",
    ARROW_DISTANCE = "%d m",
    ARROW_FLY = "Uçarak git: %s",
    ARROW_FLYING = "Uçuluyor: %s",
    ARROW_HEARTH = "Hearthstone: %s",
    ARROW_PORTAL = "%s portalını kullan",
    ARROW_TIP_HIDE = "Oku gizlemek için sağ tıkla.",
    ARROW_TIP_MAP = "Haritada göstermek için tıkla.",
    ARROW_TIP_MOVE = "Taşımak için sürükle.",
    ARROW_ZEPPELIN = "%s zeplinine bin",
    FAVOURITES = "Favoriler",
    FAVOURITES_EMPTY = "Favori olarak görmek istediğin eşyalara sağ tıkla.",
    FAV_ADD_ITEM = "Favorilere Ekle",
    FAV_REMOVE_HINT = "Kaynağı görmek için sol tıkla. Favorilerden çıkarmak için sağ tıkla",
    FAV_REMOVE_ITEM = "Favorilerden Çıkar",
    LF_CLOAK = "Pelerin",
    LF_NECK = "Boyun",
    LF_RING = "Yüzük",
    LF_TRINKET = "Tılsım",
    NO_FACTION_QUESTS_TBD = "Bu zindan için henüz bilinen %s görevi yok. Zindan yeni ve görevleri hâlâ keşfediliyor.",
    OPT_FOREVER_ONLY = "Yalnızca Forever Zindanları",
    OPT_FOREVER_ONLY_TIP = "Yalnızca WoW Forever'da yeni olan zindanları göster. Zindan listesinin sol üstündeki WoW Forever amblemine tıklamakla aynı şey: tüm zindanları yeniden görmek için işareti kaldır.",
    REQUIRES_QUEST = "Gerektirir: %s",
    RPG_PROOF_REVEALED = "Yaptığın görevlerle ortaya çıktı: %s",
    RPG_PROOF_UNLOCKED = "Yaptığın görevlerle açıldı: %s",
    SLEEPING_BAG = "Uyku Tulumu",
    SLEEPING_BAG_HIDE = "Gizle",
    SLEEPING_BAG_HIDE_TIP = "Gizlemek için sağ tıkla",
    SLEEPING_BAG_HOW = "Uyku Tulumu nasıl alınır",
    SLEEPING_BAG_TITLE = "Rahat Uyku Tulumu",
    TURN_IN_DUNGEON = "Teslim: Zindan",
    RANDOM_ENCHANT = "+Rastgele Büyü",
    ALSO_RECEIVE = "Ayrıca şunları alacaksın:",
    MAP_JUMP_LEVEL = "%d. kata atla",
    MAP_RFK_WALLJUMP = "Roogug'a ulaşmak için kapının üzerinden duvara tırmanarak zıpla",
    MAP_RFK_VINE = "Roogug'a ulaşmak için bu asmaya zıpla",
    MAP_OBJ_BFD_CHEST = "Lorgalis Elyazması'nı, havuzun bu girintisinde su altındaki Oyuk Demir Sandık'tan al.",
    MAP_OBJ_BFD_FATHOM = "Geçidin altında, su altındaki Fathom Taşı'na tıkla ve Fathom Çekirdeği'ni al. Bunu yapınca Baron Aquanis belirir.",
    MAP_OBJ_LOOT = "Burada ganimet al: %s",
    MAP_OBJ_USE = "Burada kullan",
    MAP_OBJ_EXPLORE = "Bu yeri keşfet",
    NOTICE_LV30_DATA = "30. seviyeye kadar olan zindanların yeni ganimet ve görevleri hâlâ keşfediliyor. Yeni veriler çıktıkça güncelleyeceğim. iyi şanslar, iyi eğlenceler",
    NOTICE_RESIZE = "Komutlar |cffff3030/fj|r yerine |cff33ff33/dj|r oldu.",
    MAP_SWIM_LEVEL = "%d. kat için su altında yüz",
    MAP_ENTRANCE = "Giriş",
    LOOT_COMPACT = "Kompakt görünüm",
    LOOT_DETAILED = "Ayrıntılı görünüm",
    LOOT_COMPACT_TIP = "Küçük satırlarla aynı anda daha fazla eşya göster",
    LOOT_DETAILED_TIP = "Tam eşya satırlarını göster",
    ATTUNE_ONYXIA = "Onyxia Uyumlanması",
    MAP_ENTRANCE_ORANGE = "Turuncu Giriş",
    MAP_ENTRANCE_PURPLE = "Mor Giriş",
    MAP_FLOOR = "%d. Kat",
    DUNGEON_JOURNAL = "Zindan Rehberi",
    SEARCH = "Zindan, eşya ara...",
    SEARCH_NO_RESULTS = "Sonuç yok",
    DUNGEONS = "Zindanlar",
    MAP = "Harita",
    BROWSE_DUNGEONS = "Zindanlara Göz At",
    HOME_SUBTITLE = "Patronları, ganimetleri ve görevleri görmek için bir zindan kapağı seç",
    FOREVER_BETA_DATA = "Forever beta verisi",
    BOSSES = "Patronlar",
    QUESTS = "Görevler",
    QUEST = "görev",
    QUESTS_LOWER = "görev",
    LOOT = "Ganimet",
    ITEM = "eşya",
    ITEMS = "eşya",
    RARE = "NADİR",
    YOU_HAVE_IT = "SENDE VAR",
    TURN_IN_LABEL = "Teslim et",
    AVAILABLE_FROM_LEVEL = "%s. seviyeden itibaren alınabilir",
    REQUIRED_PREREQUISITE = "Gerekli ön görev",
    OBJECTIVE = "Hedef",
    STARTS_AT = "Başlangıç yeri",
    TURN_IN = "Teslim yeri",
    NOTES = "Notlar",
    SHARE = "Paylaş",
    NOT_SHAREABLE = "Paylaşılamaz",
    SHAREABLE_QUEST = "Paylaşılabilir Görev",
    ACCEPT_TO_SHARE = "Grubunla paylaşmak için bu görevi kabul et.",
    SHAREABLE_SAME_STEP = "Aynı adımdaki oyuncularla paylaşılabilir.",
    REWARD = "Ödül",
    REWARDS = "Ödüller",
    CHOOSE_ONE_REWARD = "Bir ödül seç",
    SHOW_ON_MAP = "Haritada Göster",
    SHOW_TURN_IN = "Teslim Yerini Göster",
    ROUTE_FP_TARREN_MILL_TEXT = "Rota, uçuş noktasını alabilmen için burada sapıyor. Sonra yoldan geri dön ve doğuya, Arathi'ye doğru devam et.",
    ROUTE_FP_TARREN_MILL = "Tarren Mill Uçuş Noktası",
    ROUTE_REMOVE_HINT = "Rotayı kaldırmak için sağ tıkla",
    SHOW_LOCATION = "Konumu Göster",
    DUNGEON_ENTRANCE = "Zindan girişi",
    HOW_TO_GET_THERE = "Oraya nasıl gidilir",
    ROUTE = "Rota",
    BACK_TO_DUNGEON = "Zindana Dön",
    ALLIANCE_ROUTE = "İttifak rotası",
    SHOW_QUEST_CHAIN = "Görev Zincirini Göster",
    REQUIRED_QUESTS = "Gerekli Görevler",
    REQUIRED_ITEMS = "Gerekli Eşyalar",
    PROVIDED_ITEM = "Verilen Eşya",
    SHOW_WHOLE_CHAIN = "Tüm görev zincirini göstermek için tıkla",
    OPEN_REQUIRED_CHAIN = "Gerekli görev zincirini aç.",
    SHOW_GIVER_ON_MAP = "Görev vereni haritada göster",
    MAP_TOOLTIP = "Doğru bölgeyi açar ve kayıtlı görev başlangıç konumunu işaretler.",
    IN_DUNGEON = "Zindanda",
    NO_QUESTS = "Görev yok",
    NO_FACTION_QUESTS = "Bu zindan için kayıtlı %s görevi yok.",
    UNIQUE_TRASH = "Zindana özgü ufak yaratık ganimetleri",
    DROPS_FROM = "Düştüğü yer: %s",
    CLICK_DUNGEON = "Zindan ayrıntılarını açmak için tıkla",
    HIDE_DUNGEONS = "Zindanları Gizle",
    LOOT_FILTER = "Ganimet Filtresi",
    BUG_REPORT = "Hata Bildir",
    BUG_REPORT_SHORT = "Bildir",
    BUG_REPORT_TEXT = "Yanlış bilgi ya da eklenmesi gereken yeni keşifler mi buldun? Lütfen Discord'da bildir, ekran görüntüsü gerekli.",
    WM_WORLD_MAP = "Dünya Haritası",
    WM_DUNGEON_MAP = "Zindan Haritası",
    MINIMAP_HIDE_CONFIRM = "Zindan Rehberi mini harita düğmesi gizlensin mi?\n\nDüğmeyi /dj minimap yazarak geri getirebilirsin.",
    LF_SHOW_RECIPES = "Desen/tarif ganimetlerini her zaman göster",
    RESIZE_TIP_TITLE = "Yeniden Boyutlandır",
    RESIZE_TIP = "Pencereyi yeniden boyutlandırmak için sürükle. Sıfırlamak için sağ tıkla.",
    LF_ENABLE = "Etkinleştir",
    LF_DISABLE = "Devre dışı bırak",
    LF_MIN_LEVEL = "Gereken asgari seviye",
    OPT_UI = "Genel",
    OPT_DISCORD_TEXT = "Hata bildirmek, yeni keşifleri paylaşmak ve son haberleri almak için Zindan Rehberi Discord'una katıl.",
    OPT_DUNGEON_LIST = "Zindan listesi",
    OPT_HIDE_ITEM_LINE = "Eşya ipuçlarındaki rehber satırını gizle",
    OPT_HIDE_ITEM_LINE_TIP = "Bir eşyanın hangi patrondan ya da görevden geldiğini gösteren satırı kaldırır.",
    OPT_HIDE_MINIMAP = "Mini harita düğmesini gizle",
    OPT_HIDE_MINIMAP_TIP = "Düğmeyi geri getirmek için /dj minimap yaz.",
    OPT_BIND = "Rehberi Açma Tuşu",
    OPT_BIND_TIP = "Tıkla, sonra bir tuşa bas. Temizlemek için sağ tıkla.",
    OPT_NOT_BOUND = "Atanmamış",
    OPT_PRESS_KEY = "Bir tuşa bas...",
    OPT_KEY_TAKEN = "%s zaten atanmış. Kullanılmayan bir tuş seç.",
    OPT_NO_COMBAT = "Tuş atamaları çatışma sırasında değiştirilemez.",
    OPT_HIDE_OUTLEVELED = "Seviyesi geçilen zindanları otomatik gizle",
    OPT_HIDE_OUTLEVELED_TIP = "Seviyen bir zindanın seviye aralığını aştığında onu listeden gizler.",
    OPT_HIDE_QUESTS_DONE = "Tüm görevleri bitmiş zindanları otomatik gizle",
    OPT_HIDE_QUESTS_DONE_TIP = "Karakterinin orada yapabileceği tüm görevleri tamamladığında zindanı listeden gizler.",
    OPT_HIDE_DONE_TICK = "Bitmiş zindanlar için yeşil onay işaretini gizle",
    OPT_HIDE_DONE_TICK_TIP = "Tüm görevlerini tamamladığın bir zindanın görev sayısından önce ana sayfada görünen yeşil onay işaretini kaldırır.",
    OPT_SHOW_ALL_CLASS = "Tüm sınıf görevlerini göster",
    OPT_SHOW_ALL_CLASS_TIP = "Diğer sınıfların görevlerini de listeler (örneğin Warlock ya da Paladin görevleri). Kapalıyken yalnızca kendi sınıfının görevlerini görürsün.",
    OPT_HIDE_LFG = "Grup Bul Panelini Gizle",
    OPT_HIDE_LFG_TIP = "Zindan sayfalarında Konumu Göster'in yanındaki, o zindan için Grup Bul'u açan göz düğmesini gizler. Göze sağ tıklayıp Devre Dışı Bırak'ı da seçebilirsin.",
    OPT_HIDE_SLEEPING_BAG = "Uyku Tulumu görevini gizle",
    OPT_HIDE_SLEEPING_BAG_TIP = "Rehberin ana sayfasındaki Uyku Tulumu simgesini (WoW Forever ve Raid simgelerinin yanında) gizler. Simgeye sağ tıklayıp Gizle'yi de seçebilirsin. Takip edilen bir Uyku Tulumu zinciri okunu korur.",
    OPT_HIDE_DUNGEON_MAP = "Zindanın içindeyken Zindan Haritasını gizle",
    OPT_HIDE_DUNGEON_MAP_TIP = "İşaretliyse, zindanın içinde M tuşuna basmak rehberin zindan haritası yerine oyunun normal haritasını gösterir.",
    DESCRIPTION = "Açıklama",
    MINIMAP_OPTIONS = "Sağ tık: Seçenekler",
    LF_ARMOR_ALL = "Tümü",
    LF_ARMOR = "Zırh Filtresi",
    LF_WEAPON_ALL = "Tümü",
    LF_WEAPON = "Silah Filtresi",
    LF_WEAPONS = "Silahlar",
    LF_ARMOR_TIP = "Diğer türlerdeki zırh parçalarını gizler. Silahlar, kalkanlar, yüzükler, kolyeler, muskalar ve pelerinler her zaman kalır.",
    CHAIN_REQUIRED = "Önce bir görev zinciri gerekli.",
    CHAIN_STEP = "%d / %d. adımdasın.",
    SHOW_NEXT_STEP_MAP = "Sonraki Adımı Haritada Göster",
    LF_SHOW = "Sonuçları göster",
    LF_SHOW_TIP = "Yukarıdaki filtrelere uyan ganimet düşüren, tüm zindanlardaki her patronu listeleyen bir sayfa açar.",
    LF_RESULTS = "Uyan ganimetler",
    LF_NO_RESULTS = "Bu filtrelere uyan eşya yok.",
    LF_BACK = "Kapat",
    LF_CLASS_ONLY = "Yalnızca sınıfımın kullanabileceği ganimetleri göster",
    LF_STATS_HEADER = "Yalnızca bu özelliklere sahip eşyalar",
    LF_STATS_HINT = "Aradığın özellikleri işaretle. Hiçbiri işaretli değilse her şey gösterilir.",
    LF_MATCH_ALL = "Eşya işaretli tüm özelliklere sahip olmalı",
    LF_CLEAR = "Temizle",
    OPT_DISCORD_COPY = "Davet bağlantısını kopyalamak için Ctrl+C'ye bas.",
    OPT_CLOSE = "Kapat",
    RPG_LOCKED = "Kilitli",
    RPG_LOCKED_CARD = "Rehber Sayfasının kilidini açmak için bir zindanın son patronunu öldür",
    RPG_PROGRESS_BAR = "Yolculuk %d/%d (%%%d)",
    RPG_LOCKED_MSG = "Bu zindan kilitli. Kilidini açmak için son patronunu yen.",
    RPG_LOCKED_TIP2 = "Bu sayfanın kilidini açmak için zindanın son patronunu öldür.",
    RPG_LOCKED_TIP_TITLE = "Kilitli Rehber Sayfası",
    RPG_LOCKED_TIP = "Bu sayfanın kilidini açmak için %s zindanının son patronu %s'i yen.",
    RPG_LOCKED_TIP_POINTS = "Kilidi açmak +%d yolculuk puanı verir.",
    RPG_UNLOCKED_MSG = "%s artık rehberinde açık!",
    RPG_TOAST_TITLE = "Rehber Sayfasının Kilidi Açıldı",
    RPG_TOAST_HINT = "Rehberde açmak için tıkla",
    RPG_QUEST_TOAST_TITLE = "Zindan Görevinin Kilidi Açıldı",
    RPG_QUEST_UNLOCKED_MSG = "%s görevinin kilidi açıldı! %d/%d",
    RPG_QUEST_TOAST_HINT = "Rehberde açmak için tıkla",
    RPG_BOSS_HIDDEN = "Ortaya çıkarmak için bu patronu yen.",
    RPG_TRASH_HIDDEN = "Ortaya çıkarmak için zindandaki ufak yaratıkların yaklaşık %%20'sini temizle.",
    RPG_QUEST_HIDDEN = "Kilidini açmak için bu görevi al.",
    RPG_MAP_LOCKED_TITLE = "Harita Kilitli",
    RPG_MAP_LOCKED_TIP = "Kilidini açmak için zindandaki ufak yaratıkların yaklaşık %%20'sini temizle: %d/%d.",
    RPG_MAP_LOCKED_MSG = "Zindan haritası, ufak yaratıkların yaklaşık %%20'si temizlendikten sonra açılır (%d/%d).",
    RPG_MAP_TOAST_TITLE = "Zindan Haritasının Kilidi Açıldı",
    RPG_MAP_UNLOCKED_MSG = "%s haritasının kilidi açıldı!",
    RPG_MAP_TOAST_HINT = "Haritayı rehberde açmak için tıkla",
    RPG_MAP_TOAST_HINT_M = "Görmek için zindanda M'ye bas",
    RPG_BOSS_REVEALED_MSG = "%s rehberinde ortaya çıktı!",
    RPG_LOCKED_TIP_QUEST = "Görevlerinden birini almak bir kısmını açar.",
    RPG_PROGRESS = "Yolculuk %%%d",
    RPG_PROGRESS_TITLE = "Zindan Yolculuğu",
    RPG_PROGRESS_TIP = "Fraksiyonun ve sınıfın için %d zindan görevinden %d tanesi tamamlandı.",
    RPG_PROGRESS_PAGES = "%d rehber sayfasından %d tanesinin kilidi açıldı (son patronlar yenildi).",
    RPG_PROGRESS_POINTS = "Her görev %d puan, her rehber sayfası %d puan değerinde.",
    RPG_SUBTITLE = "Sayfalarının kilidini açmak için bir zindanın son patronunu yen",
    MODE_TITLE = "Rehberini seç",
    MODE_SUB = "Bunu istediğin zaman seçeneklerden (/dj options) ya da /dj mode ile değiştirebilirsin.",
    MODE_GAMER = "Oyuncu Modu",
    MODE_GAMER_DESC = "Tam rehber: her zindan, patron, ganimet tablosu ve görev baştan açık.",
    MODE_RPG = "RPG Modu",
    MODE_RPG_DESC = "Zindanlar kilitli başlar ve son patronları yenilince açılır. Bir ilerleme çubuğu tamamladığın her zindan görevini izler.",
    MODE_CHOOSE = "Seç",
    RPG_CONFIRM_TEXT = "Bu modda zindanlar, son patronu öldürene kadar kilitli kalır. Modu istediğin zaman seçenekler panelinden değiştirebilirsin.",
    RPG_CONFIRM_OK = "Tamam",
    RPG_CONFIRM_BACK = "Yeniden seç",
    RPG_INTRO_TEXT = "Zindanlar, son patronlarını öldürene kadar kilitli kalır.",
    RPG_INTRO_KEEP = "RPG Modunu Koru",
    RPG_INTRO_OPTIONS = "Seçeneklerden Kapat",
    MODE_RPG_ENABLE = "Seçeneklerden Etkinleştir",
    COMING_SOON = "Çok Yakında",
    PREVIEW_DATA_SOON = "Patron, ganimet ve görev verileri çok yakında.",
    PREVIEW_MAP_CLICK = "Haritayı görmek için tıkla.",
    ITEM_CLICK_MAP = "Haritada göstermek için tıkla.",
    REPEAT_SHOW = "Tekrarlanabilir Görevleri Göster (%d)",
    REPEAT_HIDE = "Tekrarlanabilir Görevleri Gizle (%d)",
    OPT_SHOW_ALL_PROF = "Tüm Meslek Görevlerini Göster",
    OPT_SHOW_ALL_PROF_TIP = "Bu karakterin sahip olmadığı mesleklerin görevlerini de (Demircilik, Madencilik...) listeler.",
    PROF_BLACKSMITHING = "Demircilik",
    PROF_MINING = "Madencilik",
    RAIDS_TITLE = "Raidler",
    ITEM_UNSEEN_TITLE = "Henüz görülmedi",
    ITEM_UNSEEN_TIP = "Bu eşya oyunda var ama sunucu henüz ayrıntılarını göndermedi. Biri onu gördüğünde (örneğin düştüğünde) görünecek.",
    FOREVER_FILTER_TITLE = "WoW Forever Zindanları",
    FOREVER_FILTER_TIP = "Yalnızca WoW Forever'da yeni olan zindanları göstermek için tıkla.",
    FOREVER_FILTER_ON = "Yalnızca WoW Forever zindanları gösteriliyor. Tüm zindanları yeniden göstermek için tıkla.",
    OPT_RPG_MODE = "RPG Modu",
    OPT_RPG_MODE_TIP = "Zindanlar, bu karakter son patronlarını yenene kadar kilitli kalır ve bir ilerleme çubuğu zindan görevlerini izler.",
    OPT_VERSION = "Sürüm: %s",
    OPT_ACCESS = "Seçeneklere %s ile eriş",
    OPT_OPEN_OPTIONS = "Seçenekleri Aç",
    OPT_COPY = "Kopyala",
    OPT_COPIED = "Kopyalandı!",
    OPT_TAB_OPTIONS = "Seçenekler",
    OPT_DISCORD = "Discord",
    LF_OK = "Tamam",
    LF_HIDDEN_NOTE = "Ganimet Filtresi tarafından %d tanesi gizlendi",
    RECIPES_SECTION = "Tarifler ve Desenler (%d)",
    SHARED_SHOW = "Ortak Ganimeti Göster (%d)",
    SHARED_HIDE = "Ortak Ganimeti Gizle (%d)",
    PROBABLE_LOOT = "Doğrulanmadı ama büyük olasılıkla düşüyor (%d)",
    SHARED_NOTE = "düşme şansı düşük, birçok patron",
    SHARED_LOOT = "Ortak Ganimet",
    SEVERAL_DUNGEONS = "birkaç zindan",
    LF_STAT_HEAL = "İyileştirme",
    LF_STAT_SPELL = "Büyü Hasarı",
    LF_STAT_AP = "Saldırı Gücü",
    LF_STAT_CRIT = "Kritik Vuruş",
    LF_STAT_SPELLCRIT = "Büyü Kritiği",
    LF_STAT_HIT = "İsabet",
    LF_STAT_SPELLHIT = "Büyü İsabeti",
    LF_STAT_MP5 = "MP5",
    LF_STAT_MP5_TIP = "5 saniyede yenilenen mana",
    LF_STAT_HP5 = "HP5",
    LF_STAT_HP5_TIP = "5 saniyede yenilenen can",
    LF_ARMOR_BTN = "Zırh",
    LF_WEAPON_BTN = "Silah",
    LF_RESIST = "Direnç Filtresi",
    LF_RESISTANCES = "Dirençler",
    LF_RES_FIRE = "Ateş",
    LF_RES_HOLY = "Kutsal",
    LF_SCHOOLS = "Büyü okulları",
    LF_RES_FROST = "Buz",
    LF_RES_NATURE = "Doğa",
    LF_RES_SHADOW = "Gölge",
    LF_RES_ARCANE = "Arkan",
    LF_STAT_DEF = "Savunma Derecesi",
    LF_STAT_STR = "Güç",
    LF_STAT_AGI = "Çeviklik",
    LF_STAT_STA = "Dayanıklılık",
    LF_STAT_INT = "Zeka",
    LF_STAT_SPI = "Ruh",
    DONE = "Bitti",
    HIDDEN = "Gizli",
    CLICK_HIDE_DUNGEON = "Bu zindanı gizlemek için tıkla.",
    CLICK_RESTORE_DUNGEON = "Bu zindanı geri getirmek için tıkla.",
    ALL_DUNGEONS_HIDDEN = "Tüm zindanlar gizli. Geri getirmek için Zindanları Gizle'ye tıkla.",
    FACTION_QUESTS = "%s görevleri",
    QUEST_IN_LOG = "Bu önceki görev görev günlüğünde.",
    QUEST_COMPLETED = "Bu önceki görev tamamlandı.",
    QUEST_NOT_CACHED = "Görev metni şu anda istemci tarafından önbelleğe alınmamış.",
    CLASS_ONLY = "YALNIZCA %s",
    MINIMAP_HIDDEN = "mini harita düğmesi gizlendi. /dj minimap kullan.",
    MINIMAP_LEFT = "Sol tık: Aç / kapat",
    MINIMAP_DRAG = "Sürükle: Taşı",
    MINIMAP_RIGHT = "Sağ tık: Gizle",
    LANGUAGE_CURRENT = "Dil: %s",
    LANGUAGE_SET = "Dil %s olarak ayarlandı.",
    LANGUAGE_AUTO = "Otomatik (%s)",
    LANGUAGE_HELP = "Dil testi: /dj lang tr, de, fr, es, ru, it, pt, ko, zh, zhtw, en, /dj lang auto",
    UPDATE_AVAILABLE = "%s sürümü mevcut (sende %s var). CurseForge'dan güncelle.",
    PREVIOUS_QUEST = "Önceki görev",
    NEXT_QUEST = "Sonraki görev",
    LEADS_TO = "Şuna götürür: %s",
    MAP_MARKER_REMOVED = "harita işareti kaldırıldı.",
    MAP_LEFT_TARGET = "Yakındaysa görev vereni hedeflemek ve işaretlemek için sol tıkla",
    MAP_RIGHT_REMOVE = "İşareti kaldırmak için sağ tıkla",
    MAP_MARKED = "%s haritada işaretlendi.",
    MAP_OPEN_FAILED = "kayıtlı harita konumu açılamadı.",
    MAP_COMBAT = "çatışma sırasında harita açılamaz. İşaretli noktayı görmek için %s tuşuna bas.",
    QUEST_GIVER = "Görev veren",
    QUEST_STARTS_HERE = "Görev burada başlıyor",
    TRACK = "Takip Et",
    TRACKING = "Takip Ediliyor",
    TRACK_TIP = "Bu zindanın görevlerini ilerlemenle birlikte ekranında gösterir. İstediğin yere sürükle.",
    TRACK_STOP = "Takibi bırak",
    TRACK_READY = "Teslime hazır",
    TRACK_DONE = "Tamamlandı",
    TRACK_IN_LOG = "Görev günlüğünde",
    TRACK_CLICK = "Rehberde açmak için tıkla",
    TURN_IN_HERE = "Burada teslim et",
    TRACK_ACCEPT = "Görevi kabul etmek için tıkla",
}


local SLOT = {
	Chest="Göğüs", Leather="Deri", Wrist="Bilek", Cloth="Kumaş", Back="Sırt", Waist="Bel", Mail="Zincir", Plate="Plaka",
	Hands="Eller", Feet="Ayaklar", Legs="Bacaklar", Head="Baş", Shoulder="Omuz", Neck="Boyun", Finger="Parmak",
	Trinket="Muska", Shield="Kalkan", Cloak="Pelerin", Dagger="Hançer", Staff="Asa", Wand="Değnek", Bow="Yay",
	Gun="Tüfek", Crossbow="Arbalet", Thrown="Fırlatma", Axe="Balta", Mace="Gürz", Sword="Kılıç", Polearm="Mızraklı Silah",
	Fist="Yumruk Silahı", ["One-Hand"]="Tek El", ["Two-Hand"]="Çift El", ["Main Hand"]="Ana El", ["Off Hand"]="Yan El",
	["Held In Off-hand"]="Yan Elde Tutulan", Ranged="Menzilli", Relic="Kalıntı", Shirt="Gömlek", Tabard="Tabard",
	Miscellaneous="Çeşitli", Idol="İdol", Libram="Libram", Totem="Totem",
}
local REP = { ["Argent Dawn"]="Argent Dawn", Stormwind="Stormwind", Ironforge="Ironforge" }

local function kur()
	local FDJ = _G.ForeverDungeonJournal_NS
	if not FDJ or FDJ.trKuruldu or not FDJ.Locales or not FDJ.GetLanguage then return false end
	FDJ.trKuruldu = true
	FDJ.Locales.trTR = L
	FDJ.ContentLocales = FDJ.ContentLocales or {}
	local ic = G.FDJIcerik or {}
	FDJ.ContentLocales.trTR = { dungeons = ic.dungeons or {}, bosses = {}, slotParts = SLOT, replacements = {}, places = ic.places or {}, quests = ic.quests or {} }

	-- Dil: seçim "en" değilse Türkçe
	local eskiDil = FDJ.GetLanguage
	function FDJ.GetLanguage()
		local ham = ForeverDungeonJournalDB and ForeverDungeonJournalDB.language
		local s = tostring(ham or "auto"):lower()
		if s == "tr" or s == "trtr" or s == "turkce" or s == "türkçe" or s == "auto" then return "trTR" end
		return eskiDil()
	end

	local function arayuz(s)
		if type(s) ~= "string" or s == "" then return nil end
		return (G.Arayuz and G.Arayuz[s]) or (G.ZindanAdi and G.ZindanAdi[s]) or (G.EsyaAdi and G.EsyaAdi[s])
	end

	-- Önce eklentinin kendi yöntemi (tüm metin, virgül/tire parçaları), sonra bizim sözlükler
	local eskiSerbest = FDJ.LocalizeFreeText
	local function serbest(v)
		if type(v) ~= "string" or v == "" then return v end
		local r = eskiSerbest(v)
		if r ~= v then return r end
		return arayuz(v) or v
	end
	function FDJ.LocalizeFreeText(v)
		if FDJ.GetLanguage() ~= "trTR" then return eskiSerbest(v) end
		return serbest(v)
	end
	local eskiAd = FDJ.LocalizeDungeonName
	function FDJ.LocalizeDungeonName(n)
		if FDJ.GetLanguage() ~= "trTR" then return eskiAd(n) end
		return (G.ZindanAdi and G.ZindanAdi[n]) or n
	end
	local eskiAlan = FDJ.LocalizeDungeonField
	function FDJ.LocalizeDungeonField(n, alan, fb)
		if FDJ.GetLanguage() ~= "trTR" then return eskiAlan(n, alan, fb) end
		local d = FDJ.ContentLocales.trTR.dungeons[n]
		if d and d[alan] and d[alan] ~= "" then return d[alan] end
		return serbest(fb)
	end
	local eskiGorev = FDJ.LocalizeQuestField
	function FDJ.LocalizeQuestField(id, alan, fb)
		if FDJ.GetLanguage() ~= "trTR" then return eskiGorev(id, alan, fb) end
		local q = FDJ.ContentLocales.trTR.quests[id]
		local t = q and q[alan]
		if t and t ~= "" then return t end
		local v = G.Veri and G.Veri[id]
		t = v and ((alan == "name" and v.b) or (alan == "objective" and v.h))
		if t and t ~= "" and t:sub(1, 1) ~= "<" then return t end
		return serbest(fb)
	end
	local eskiBoss = FDJ.LocalizeBossName
	function FDJ.LocalizeBossName(n)
		if FDJ.GetLanguage() ~= "trTR" then return eskiBoss(n) end
		if n == "Recipes & Patterns" then return (L.RECIPES_SECTION:gsub("%s*%(%%d%)%s*", "")) end
		if n == "Trash Drops" then return "Ufak Yaratık Ganimeti" end
		return serbest(n)
	end
	-- Görev ilerleme satırları ("5/7 Deviate Dreadfang slain"): Türkçeleştir
	if FDJ.LocalizeObjectives then
		local eskiHedef = FDJ.LocalizeObjectives
		local function satir(s)
			if type(s) ~= "string" then return s end
			local a, b, ad = s:match("^(%d+)/(%d+) (.+)$")
			if not a then return s end
			local yaratik = ad:match("^(.-) slain$")
			if yaratik then return a .. "/" .. b .. " " .. yaratik .. " öldürüldü" end
			return a .. "/" .. b .. " " .. ((G.EsyaAdi and G.EsyaAdi[ad]) or ad)
		end
		function FDJ.LocalizeObjectives(...)
			local out = eskiHedef(...)
			if type(out) == "table" and FDJ.GetLanguage() == "trTR" then
				for _, l in ipairs(out) do if type(l) == "table" then l[1] = satir(l[1]) end end
			end
			return out
		end
	end
	if FDJ.LocalizeReputationName then
		local eskiRep = FDJ.LocalizeReputationName
		function FDJ.LocalizeReputationName(n)
			if FDJ.GetLanguage() ~= "trTR" then return eskiRep(n) end
			return n
		end
	end
	return true
end

if not kur() then
	G.basla(kur)
	local f = CreateFrame("Frame")
	f:RegisterEvent("ADDON_LOADED")
	f:SetScript("OnEvent", function(self, _, ad)
		if ad == "ForeverDungeonJournal" then kur() self:UnregisterAllEvents() end
	end)
end
