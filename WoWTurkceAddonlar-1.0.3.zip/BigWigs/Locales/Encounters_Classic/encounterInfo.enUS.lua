local _, addonTbl = ...
local L = addonTbl.API:NewLocale("BigWigs: Encounter Info", "enUS")

L[2138] = { title = "Shield of the Perfidious", description = "Commander Springvale üç Unholy Power yüküne ulaşınca yükleri tüketir ve kalkanındaki gücü serbest bırakır. Shield of the Perfidious, 3 saniye boyunca Springvale'in önündeki dar 25 derecelik bir koni içinde her 0,5 saniyede 17 Shadow hasarı verir. Kahraman zorlukta koni 150 dereceye genişler.", abilityIcon = 132390 }
L[4906] = { title = "Ferra", description = "", abilityIcon = nil }
L[4921] = { title = "Satyr Form", description = "", abilityIcon = nil }
L[4925] = { title = "Dire Wolf Form", description = "", abilityIcon = nil }
L[4926] = { title = "Tree Form", description = "", abilityIcon = nil }
L[5019] = { title = "Nekrum Gutchewer", description = "", abilityIcon = nil }
L[5020] = { title = "Shadow Priest Sezz'ziz", description = "", abilityIcon = nil }
L[5041] = { title = "Focus Fire", description = "Shirrak the Dead Watcher bir oyuncunun konumunu hedef alır ve 12 metre içindeki tüm oyunculara Fire hasarı veren bir mermi yağmuru ateşler.", abilityIcon = 132212 }
L[5045] = { title = "Summon Avatar", description = "Exarch Maladaar'ın canı %25'e düşünce bir Avatar of the Martyred çağırır.", abilityIcon = 136187 }
L[5046] = { title = "Avatar of the Martyred", description = "", abilityIcon = nil }
L[5053] = { title = "Hellfire Watcher", description = "", abilityIcon = nil }
L[5072] = { title = "Nazan", description = "", abilityIcon = nil }
L[5085] = { title = "Pure Energy", description = "Vexallus'un canı her %15 azaldığında bir Pure Energy çağırır. Kahraman zorlukta Vexallus aynı anda iki Pure Energy çağırır.", abilityIcon = nil }
L[5099] = { title = "Ellrys Duskhallow", description = "", abilityIcon = nil }
L[5101] = { title = "Yazzai", description = "", abilityIcon = nil }
L[5104] = { title = "Apoko", description = "", abilityIcon = nil }
L[5167] = { title = "Flame Strike", description = "Kael'thas Sunstrider bir alev sütunu indirir; hedef alanın 6 metre yakınındaki tüm oyuncuları 8 saniye boyunca her saniye Fire hasarıyla yakar.", abilityIcon = 135826 }
L[5180] = { title = "Shock Barrier", description = "Kael'thas Sunstrider kendini bir bariyerle sarar; bariyer 10000 hasar emer ve onu kesme etkilerine karşı bağışık kılar.", abilityIcon = 136051 }
L[5235] = { title = "Summon Elementals", description = "Darkweaver Syth'in canı %90, %55 ve %15'e düşünce kendini korumak için 4 elemental çağırır.", abilityIcon = 136029 }
L[5252] = { title = "Cyclone of Feathers", description = "Anzu bir oyuncuyu kasırgaya hapseder; oyuncu 6 saniye boyunca hiçbir şey yapamaz ama hasar da almaz.", abilityIcon = 136018 }
L[5253] = { title = "Brood of Anzu", description = "Anzu'nun canı %75 ve %35'e düşünce kendini 1 dakikalığına sürgüne gönderir; bu sürede tüm hasara bağışıktır ve hareket edemez. Sürgündeyken yeteneklerini kullanmaya devam eder ve kendini korumak için Brood of Anzu çağırır. Tüm Brood of Anzu'yu yenersen Anzu sürgünü erken bitirir.", abilityIcon = 132926 }
L[5267] = { title = "Draw Shadows", description = "Grandmaster Vorpil platformuna ışınlanır ve tüm oyuncuları yanına çeker. Ardından bir Rain of Fire indirir; platformdaki tüm oyuncuları 6 saniye boyunca her saniye Fire hasarıyla yakar.", abilityIcon = 136221 }
L[5293] = { title = "Felfire", description = "Wrath-Scryer Soccothrates 10 metre içindeki tüm oyuncuları geri savurur. Ardından bir oyuncuya hücum eder ve arkasında bir Felfire duvarı bırakır. Felfire, içinde duran tüm oyunculara her saniye Fire hasarı verir.", abilityIcon = 135798 }
L[5335] = { title = "Harbinger's Illusion", description = "Harbinger Skyriss'in canı %66 ve %33'e düşünce kendinin bir yanılsamasını yaratır. Harbinger Skyriss'in yanılsaması oyunculara Mind Rend ile saldırır.", abilityIcon = 135752 }
L[5388] = { title = "Burning Nova", description = "Keli'dan the Breaker kendini sürgüne gönderip hasar almaz hâle gelir ve Fire Nova büyüsüne başlar. Büyü tamamlanınca Fire Nova, Keli'dan'ın 20 metre yakınındaki tüm oyunculara Fire hasarı verir.", abilityIcon = 136135 }
L[5411] = { title = "Summon Reinforcements", description = "Commander Sarannis her dakika 3 Bloodwarder Reservist ve 1 Bloodwarder Mender çağırır.", abilityIcon = 132333 }
L[5412] = { title = "Bloodwarder Mender", description = "", abilityIcon = nil }
L[5453] = { title = "White Seedling", description = "", abilityIcon = nil }
L[5478] = { title = "Summon Saplings", description = "Warp Splinter savaşta ona yardım etmesi için 6 Sapling canlandırır. 25 saniye sonra Sapling'ler kendilerini feda eder ve Warp Splinter'ı kalan canları kadar iyileştirir.", abilityIcon = 136044 }
L[5488] = { title = "Inferno", description = "Raging Flames 8 saniye boyunca kendini bir cehennem ateşiyle sarar ve 10 metre içindeki tüm oyunculara her saniye Fire hasarı verir. Alev alev yanarken Raging Flames hareket edemez ve yetenek kullanamaz. Ateş sönünce kovalayacağı yeni bir hedef seçer.", abilityIcon = 135818 }
L[5894] = { title = "Beatdown", description = "Warbringer O'mrogg rastgele bir oyuncu seçip onu döver; tüm tehdidi sıfırlar ve Beatdown hedefine büyük miktarda tehdit verir.", abilityIcon = 132345 }
L[5899] = { title = "Blade Dance", description = "Warchief Kargath Bladefist kılıç dansına başlar; rastgele birkaç oyuncuya hücum ederek onlara ve yakınlarındaki tüm oyunculara Physical hasar verir.", abilityIcon = 236303 }
L[5999] = { title = "Steamrigger Mechanics", description = "Mekgineer Steamrigger'ın canı %75, %50 ve %25'e düşünce kendini onarmaları için Steamrigger Mechanic'ler çağırır.", abilityIcon = nil }
L[6003] = { title = "Spell Reflection", description = "Warlord Kalithresh kendini büyüyle sarar ve 8 saniye boyunca büyüleri her seferinde (%100) yapana geri yansıtır.", abilityIcon = 132361 }
L[6006] = { title = "Underbog Mushroom", description = "Hungarfen rastgele bir yere Underbog Mushroom çağırır; mantarlar 20 saniye sonra bir spor bulutu hâlinde patlar.", abilityIcon = 132371 }
L[6008] = { title = "Foul Spores", description = "Hungarfen'in canı %20'ye düşünce pis sporlar salar; 11 saniye boyunca 15 metre içindeki tüm oyunculardan her saniye 400 can emer.", abilityIcon = 136100 }
L[6031] = { title = "Claw", description = "Swamplord Musel'ek, Claw'a rastgele oyunculara saldırmasını emreder.", abilityIcon = nil }
L[6042] = { title = "Ahn'kahar Guardian", description = "Elder Nadox savaşta kendini korumaları için Ahn'kahar Guardian'lar çağırır.", abilityIcon = 134969 }
L[6359] = { title = "Submerge", description = "Anub'arak'ın canı %75, %50 ve %25'e düşünce yerin altına dalar ve kendini korumaları için Nerubian'lar çağırır.", abilityIcon = 135773 }
L[6375] = { title = "Aşama 1: Army of the Dead", description = "Novos the Summoner bir Arcane Field içine girer ve kendini korumak için dalga dalga ölümsüz çağırır. Novos, 4 Crystal Handler yenilene kadar Arcane Field içinde kalır.", abilityIcon = nil }
L[6378] = { title = "Crystal Handler", description = "", abilityIcon = nil }
L[6418] = { title = "Aşama 1: The Colossus", description = "", abilityIcon = nil }
L[6421] = { title = "Aşama 2: The Elemental", description = "", abilityIcon = nil }
L[7395] = { title = "Mirror Images", description = "Grand Magus Telestra'nın canı %50'ye düşünce 3 ayna görüntüsüne bölünür.", abilityIcon = 132220 }
L[7442] = { title = "Call Azure Ring Captain", description = "Oyuncuları yerle bir etmesi için bir Azure Ring Captain çağırır.", abilityIcon = 134155 }
L[7443] = { title = "Azure Ring Captain", description = "", abilityIcon = nil }
L[7491] = { title = "Cauterizing Flames", description = "Lavanthor tüm oyunculara Fire hasarı verir ve 3 dakika boyunca aldıkları Fire hasarını %35 artırır.", abilityIcon = 135830 }
L[7534] = { title = "Poison Bottle", description = "Deathstalker Visceri rastgele bir oyuncunun konumuna bir şişe zehir fırlatır. Zehir 20 saniye yerde kalır ve 5 metre içindeki herkese Nature hasarı verir.", abilityIcon = 134711 }
L[7577] = { title = "Summon Memory", description = "Argent Confessor Paletress'in canı %50'ye düşünce geçmiş savaşlarından bir yaratık çağırır.", abilityIcon = 136200 }
L[7578] = { title = "Memory of the Past", description = "", abilityIcon = nil }
L[7598] = { title = "Ghoul Explode", description = "The Black Knight gulyabanilerinden birini patlatır ve 8 metre içindeki tüm oyunculara Shadow hasarı verir.", abilityIcon = 237521 }
L[15665] = { title = "Birinci Aşama: Essence of Suffering", description = "", abilityIcon = nil }
L[15673] = { title = "İkinci Aşama: Essence of Desire", description = "", abilityIcon = nil }
L[15681] = { title = "Üçüncü Aşama: Essence of Anger", description = "", abilityIcon = nil }
L[15704] = { title = "Gathios the Shatterer", description = "", abilityIcon = nil }
L[15716] = { title = "Veras Darkshadow", description = "", abilityIcon = nil }
L[15720] = { title = "High Nethermancer Zerevor", description = "", abilityIcon = nil }
L[15726] = { title = "Lady Malande", description = "", abilityIcon = nil }
L[15735] = { title = "Birinci Aşama: You Are Not Prepared", description = "", abilityIcon = nil }
L[15740] = { title = "İkinci Aşama: Flames of Azzinoth", description = "", abilityIcon = nil }
L[15751] = { title = "Üçüncü Aşama: The Demon Within", description = "", abilityIcon = nil }
L[15757] = { title = "Dördüncü Aşama: The Long Hunt", description = "", abilityIcon = nil }
