-- Kitaplar, mektuplar, notlar ve tabelalar (okunabilir eşyalar ve nesneler).
-- Sayfa metni parmak iziyle eşleşir: G.Kitap[iz] = "Türkçe sayfa". Başlık: G.KitapAdi["English"] = "Türkçe".
-- Çevirisi olmayan sayfalar kaydedilir ("kitap" kategorisi), sonra çevrilip Translations/Books'a eklenir.
local G = WoWTurkce
G.Kitap = G.Kitap or {}
G.KitapAdi = G.KitapAdi or {}

local orijinalFont

local function baslikKoy(metin)
	if ItemTextFrame and ItemTextFrame.SetTitle then
		pcall(ItemTextFrame.SetTitle, ItemTextFrame, metin)
	elseif ItemTextTitleText then
		ItemTextTitleText:SetText(metin)
	end
end

local function sayfaKoy(metin)
	local fs = ItemTextPageText
	if not fs or not fs.SetText then return end
	-- SimpleHTML: yazı tipi "P" (paragraf) için ayrıca verilir
	if G.ayar("font") and fs.SetFont then
		if not orijinalFont and fs.GetFont then
			local ok, f, b, s = pcall(fs.GetFont, fs, "P")
			if ok and f then orijinalFont = { f, b, s } end
		end
		local boyut = orijinalFont and orijinalFont[2] or 13
		pcall(fs.SetFont, fs, "P", G.FONT_METIN, boyut + 1, "")
	end
	fs:SetText(metin)
end

local function uygula()
	if not G.modul("kitap") then return end
	local baslik = ItemTextGetItem and ItemTextGetItem()
	local metin = ItemTextGetText and ItemTextGetText()
	local sayfa = ItemTextGetPage and ItemTextGetPage() or 1
	if baslik and G.KitapAdi[baslik] then baslikKoy(G.KitapAdi[baslik]) end
	if not metin or metin == "" or G.turkceMi(metin) then return end
	local tr, iz = G.izBul(G.Kitap, metin)
	if tr then
		sayfaKoy(G.doldur(tr))
	else
		G.kaydetDiger("kitap", iz, { ad = baslik, sayfa = sayfa, metin = metin })
		if baslik and not G.KitapAdi[baslik] then G.kaydetDiger("kitapadi", baslik) end
	end
end

local f = CreateFrame("Frame")
f:RegisterEvent("ITEM_TEXT_READY")
f:SetScript("OnEvent", function()
	-- Blizzard çerçevesi metni kendi koyduktan sonra üzerine yazalım
	if C_Timer then C_Timer.After(0, function() pcall(uygula) end) else pcall(uygula) end
end)
