-- Z-Perl çerçevelerindeki durum yazıları (Dead, Ghost, Offline, Fishing...) için Türkçe düzeltme.
local G = WoWTurkce

local METIN = {
	["Dead"] = "Ölü", ["Ghost"] = "Hayalet", ["Offline"] = "Çevrimdışı", ["Feign Death"] = "Ölü Taklidi",
	["Fishing"] = "Balıkçılık", ["FD"] = "ÖT", ["Resurrected"] = "Diriltildi", ["Ressed"] = "Diriltildi",
}

local cerceveler = {}
local function topla()
	wipe(cerceveler)
	for ad, f in pairs(_G) do
		if type(ad) == "string" and ad:find("^XPerl_") and type(f) == "table" and f.GetObjectType and f.GetRegions
			and (ad:find("^XPerl_Player$") or ad:find("^XPerl_Target$") or ad:find("^XPerl_Focus$") or ad:find("^XPerl_TargetTarget$")
			or ad:find("^XPerl_party%d$") or ad:find("^XPerl_Party") or ad:find("^XPerl_Raid") or ad:find("^XPerl_Pet")) then
			cerceveler[#cerceveler + 1] = f
		end
	end
end

local function yazilar(f, d)
	if d > 6 then return end
	if f.IsShown and not f:IsShown() then return end
	if f.GetRegions then
		for _, r in ipairs({ f:GetRegions() }) do
			if r.GetObjectType and r:GetObjectType() == "FontString" and r.GetText then
				local t = r:GetText()
				if type(t) == "string" and not G.gizli(t) then
					local tr = METIN[t]
					if tr then r:SetText(tr) end
				end
			end
		end
	end
	if f.GetChildren then
		for _, c in ipairs({ f:GetChildren() }) do yazilar(c, d + 1) end
	end
end

local function tara()
	if not G.ayar("acik") then return end
	for _, f in ipairs(cerceveler) do pcall(yazilar, f, 0) end
end

G.basla(function()
	-- Z-Perl genel yazıları (durum metinleri çalışma anında bu değişkenlerden okunuyorsa yeter)
	C_Timer.After(2, function()
		if not _G.XPerl_Player and not _G.XPERL_LOC_DEAD then return end
		if _G.XPERL_LOC_DEAD then _G.XPERL_LOC_DEAD = "Ölü" end
		if _G.XPERL_LOC_GHOST then _G.XPERL_LOC_GHOST = "Hayalet" end
		if _G.XPERL_LOC_OFFLINE then _G.XPERL_LOC_OFFLINE = "Çevrimdışı" end
		if _G.XPERL_LOC_FEIGNDEATH then _G.XPERL_LOC_FEIGNDEATH = "Ölü Taklidi" end
		topla()
		C_Timer.NewTicker(0.4, tara)
		C_Timer.NewTicker(10, topla)
	end)
end)
