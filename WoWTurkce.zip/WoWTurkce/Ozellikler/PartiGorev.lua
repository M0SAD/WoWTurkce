-- Parti görev sayacı: görev günlüğü ve Questie takip listesinde görevin yanına "[2/5]" yazar
-- (sen dahil, partide bu görevi alan / parti kişi sayısı). Ayar: "partiGorev".
local G = WoWTurkce
local RENK = "|cff66ccff"
local IZ = "|cff66ccff%[%d+/%d+%]|r"

local function acik() return G.ayar("partiGorev") end

local function birimGorevde(birim, qid)
	if not qid or not UnitExists(birim) then return false end
	if C_QuestLog and C_QuestLog.IsUnitOnQuest then
		local ok, v = pcall(C_QuestLog.IsUnitOnQuest, birim, qid)
		if ok and v ~= nil then return v and true or false end
	end
	if IsUnitOnQuest then
		local idx = GetQuestLogIndexByID and GetQuestLogIndexByID(qid)
		if (not idx or idx == 0) and C_QuestLog and C_QuestLog.GetLogIndexForQuestID then idx = C_QuestLog.GetLogIndexForQuestID(qid) end
		if idx and idx > 0 then
			local ok, v = pcall(IsUnitOnQuest, idx, birim)
			if ok and v ~= nil then return (v == true or v == 1) end
		end
		local ok2, v2 = pcall(IsUnitOnQuest, birim, qid)
		if ok2 and v2 ~= nil then return (v2 == true or v2 == 1) end
	end
	return false
end

local function birimler()
	local l = {}
	if IsInRaid and IsInRaid() then
		for i = 1, GetNumGroupMembers() do
			local u = "raid" .. i
			if not UnitIsUnit(u, "player") then l[#l + 1] = u end
		end
	else
		for i = 1, 4 do if UnitExists("party" .. i) then l[#l + 1] = "party" .. i end end
	end
	return l
end

function G.partiGorevEtiket(qid)
	if not acik() or not qid then return nil end
	local l = birimler()
	if #l == 0 then return nil end
	local n = 1
	for _, u in ipairs(l) do if birimGorevde(u, qid) then n = n + 1 end end
	return " " .. RENK .. "[" .. n .. "/" .. (#l + 1) .. "]|r"
end

-- Blizzard görev günlüğü (klasik)
local function gunlukGuncelle()
	if not QuestLogFrame or not QuestLogFrame:IsShown() then return end
	for i = 1, (QUESTS_DISPLAYED or 27) do
		local b = _G["QuestLogTitle" .. i]
		if b and b:IsShown() then
			local t = b:GetText()
			if t then
				local temiz = t:gsub(" " .. IZ, "")
				local _, _, _, isHeader, _, _, _, qid = GetQuestLogTitle(b:GetID())
				local e = (not isHeader) and G.partiGorevEtiket(qid) or nil
				local yeni = e and (temiz .. e) or temiz
				if yeni ~= t then
					b:SetText(yeni)
					local yazi = b.GetFontString and b:GetFontString()
					local tik = _G["QuestLogTitle" .. i .. "Check"]
					if tik and yazi then tik:ClearAllPoints(); tik:SetPoint("LEFT", yazi, "RIGHT", 2, 0) end
				end
			end
		end
	end
end

-- Questie takip listesi: başlık metnini üreten fonksiyonu sar
local questieTamam = false
local function questieBagla()
	if questieTamam or not QuestieLoader or not QuestieLoader.ImportModule then return end
	local ok, TD = pcall(QuestieLoader.ImportModule, QuestieLoader, "TrackerData")
	if not ok or type(TD) ~= "table" or type(TD.GetColoredQuestName) ~= "function" then return end
	local eski = TD.GetColoredQuestName
	TD.GetColoredQuestName = function(quest, ...)
		local s = eski(quest, ...)
		if type(s) == "string" and type(quest) == "table" then
			local ok2, e = pcall(G.partiGorevEtiket, quest.Id)
			if ok2 and e then s = s .. e end
		end
		return s
	end
	questieTamam = true
end

local function takipYenile()
	if not questieTamam or not QuestieLoader then return end
	local ok, QT = pcall(QuestieLoader.ImportModule, QuestieLoader, "QuestieTracker")
	if ok and QT and QT.Update then pcall(QT.Update, QT) end
end

local bekliyor = false
local function yenile()
	if bekliyor then return end
	bekliyor = true
	C_Timer.After(1, function()
		bekliyor = false
		pcall(gunlukGuncelle)
		takipYenile()
	end)
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("GROUP_ROSTER_UPDATE")
f:RegisterEvent("UNIT_QUEST_LOG_CHANGED")
f:SetScript("OnEvent", function(_, e, birim)
	if e == "PLAYER_LOGIN" then
		if QuestLog_Update then hooksecurefunc("QuestLog_Update", function() pcall(gunlukGuncelle) end) end
		C_Timer.After(3, function() questieBagla(); takipYenile() end)
		return
	end
	if e == "UNIT_QUEST_LOG_CHANGED" and birim == "player" then return end
	if acik() then yenile() end
end)

G.dinle(function(k)
	if k == "partiGorev" then
		if QuestLog_Update and QuestLogFrame and QuestLogFrame:IsShown() then pcall(QuestLog_Update) end
		pcall(gunlukGuncelle)
		takipYenile()
	end
end)
