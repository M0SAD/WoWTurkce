-- Oyun ipucu (tutorial) pencereleri: "Quest Log - You can open your quest log..." gibi.
-- Oyundaki tüm ipucu metinleri girişte bir kez kaydedilir, böylece hepsi topluca çevrilebilir.
local G = WoWTurkce

local SABIT = { ["Display Tips"] = "İpuçlarını Göster", ["Okay"] = "Tamam" }

local function cevir(s)
	if not s or s == "" then return nil end
	return G.cevir(G.Egitim, s) or (G.egitim2 and G.egitim2(s))
end

local function uygula()
	if not G.modul("egitim") then return end
	for _, ad in ipairs({ "TutorialFrameTitle", "TutorialFrameText" }) do
		local fs = _G[ad]
		local t = fs and fs.GetText and fs:GetText()
		local tr = cevir(t)
		if tr then fs:SetText(tr)
		elseif t and t ~= "" and not G.turkceMi(t) then G.kaydetDiger("egitim", (t:gsub("%s%s+", " "))) end
	end
	for _, ad in ipairs({ "TutorialFrameCheckButtonText", "TutorialFrameOkayButtonText" }) do
		local fs = _G[ad]
		local t = fs and fs.GetText and fs:GetText()
		if t and SABIT[t] then fs:SetText(SABIT[t]) end
	end
	local b = _G.TutorialFrameOkayButton
	if b and b.GetText and SABIT[b:GetText() or ""] then b:SetText(SABIT[b:GetText()]) end
end

G.basla(function()
	if TutorialFrame_Update then hooksecurefunc("TutorialFrame_Update", function() uygula() end) end
	if TutorialFrame then TutorialFrame:HookScript("OnShow", function() C_Timer.After(0, uygula) end) end
	-- Tüm ipucu metinlerini bir kez kaydet (TUTORIAL_TITLE1.., TUTORIAL1..)
	if G.ayar("kayit") then
		for i = 1, 80 do
			for _, s in ipairs({ _G["TUTORIAL_TITLE" .. i], _G["TUTORIAL" .. i] }) do
				if type(s) == "string" and s ~= "" and not cevir(s) and not G.turkceMi(s) then
					G.kaydetDiger("egitim", (s:gsub("%s%s+", " ")))
				end
			end
		end
	end
end)
