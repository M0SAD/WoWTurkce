-- NPC alt başlıkları (ipucunda adın altındaki satır): "Apprentice Weaponsmith" -> "Çırak Silah Ustası"
-- Meslek, satıcı ve eğitmen unvanları. Genel arayüz sözlüğüne eklenir, Questie haritası için NPC kimlikleri de tutulur.
local A, U = WoWTurkce.Arayuz, WoWTurkce.NpcAltBaslik
local function e(en, tr) if A[en] == nil then A[en] = tr end U[en] = tr end
e("Accessories Quartermaster", "Aksesuar Levazım Subayı")
e("Advisor to Thrall", "Thrall'ın Danışmanı")
e("Agent of Therazane", "Therazane'nin Ajanı")
e("Alchemy & Herbalism Supplies", "Simya ve Bitkicilik Malzemeleri")
e("Alchemy Supplies", "Simya Malzemeleri")
e("Ale and Wine", "Bira ve Şarap")
e("Alliance Ambassador", "Alliance Elçisi")
e("Alliance Cloth Quartermaster", "Alliance Kumaş Levazım Subayı")
e("Alliance Outrunner", "Alliance Öncü Koşucusu")
e("Alliance Peacekeeper", "Alliance Barış Muhafızı")
e("Altar Boy", "Sunak Çocuğu")
e("Alterac Valley Battlemaster", "Alterac Valley Savaş Ustası")
e("Ammunition Vendor", "Cephane Satıcısı")
e("Ancient Stone Watcher", "Kadim Taş Gözcü")
e("Ancient of Lore", "Bilgi Kadimi")
e("Angelas' Pet", "Angelas'ın Evcil Hayvanı")
e("Apprentice Armorer", "Çırak Zırh Ustası")
e("Apprentice Chef", "Çırak Aşçı")
e("Apprentice Clothier", "Çırak Kumaşçı")
e("Apprentice Herbalist", "Çırak Bitkici")
e("Apprentice Weaponsmith", "Çırak Silah Ustası")
e("Apprentice Witch Doctor", "Çırak Büyücü Hekim")
e("Apprentice of Cheese", "Peynir Çırağı")
e("Arathi Basin Battlemaster", "Arathi Basin Savaş Ustası")
e("Arcane Goods", "Arkan Mallar")
e("Arcane Goods Vendor", "Arkan Mal Satıcısı")
e("Arcane Trinkets Vendor", "Arkan Biblo Satıcısı")
e("Armor Crafter", "Zırh Zanaatkârı")
e("Armor Quartermaster", "Zırh Levazım Subayı")
e("Armorer", "Zırh Ustası")
e("Armorer & Shieldcrafter", "Zırh ve Kalkan Ustası")
e("Armorer & Shieldsmith", "Zırh ve Kalkan Ustası")
e("Armorer and Shieldcrafter", "Zırh ve Kalkan Ustası")
e("Armorsmith", "Zırh Demircisi")
e("Armorsmithing Trainer", "Zırh Demirciliği Eğitmeni")
e("Arrow Merchant", "Ok Tüccarı")
e("Arthas' Tears Collector", "Arthas' Tears Toplayıcısı")
e("Artisan Alchemist", "Usta Zanaatkâr Simyacı")
e("Artisan Blacksmith", "Usta Zanaatkâr Demirci")
e("Artisan Blacksmith of the Mithril Order", "Mithril Order'ın Usta Zanaatkâr Demircisi")
e("Artisan Enchanter", "Usta Zanaatkâr Efsuncu")
e("Artisan Engineer", "Usta Zanaatkâr Mühendis")
e("Artisan Leatherworker", "Usta Zanaatkâr Deri İşçisi")
e("Artisan Tailor", "Usta Zanaatkâr Terzi")
e("Assassin", "Suikastçı")
e("Assistant Innkeeper", "Hancı Yardımcısı")
e("Away Team", "Saha Ekibi")
e("Axe Merchant", "Balta Tüccarı")
e("Axe Trainer", "Balta Eğitmeni")
e("Axecrafter", "Balta Ustası")
e("Bael'dun Captain of the Guard", "Bael'dun Muhafız Kaptanı")
e("Bael'dun Chief Engineer", "Bael'dun Baş Mühendisi")
e("Bael'dun Morale Officer", "Bael'dun Moral Subayı")
e("Bag Merchant", "Çanta Tüccarı")
e("Bag Vendor", "Çanta Satıcısı")
e("Bags & Sacks", "Çantalar ve Torbalar")
e("Bait and Tackle Supplier", "Yem ve Olta Takımı Satıcısı")
e("Baked Salmon Collector", "Baked Salmon Toplayıcısı")
e("Baker", "Fırıncı")
e("Banshee Queen", "Banshee Kraliçesi")
e("Barmaid", "Garson Kız")
e("Bartender", "Barmen")
e("Basket Weaver", "Sepet Örücü")
e("Battle Master", "Savaş Ustası")
e("Bear Trainer", "Ayı Eğitmeni")
e("Beverage Merchant", "İçecek Tüccarı")
e("Binder of the Moro'gai", "Moro'gai Bağlayıcısı")
e("Bird Pet Trainer", "Kuş Evcil Hayvan Eğitmeni")
e("Bird Trainer", "Kuş Eğitmeni")
e("Blackhand Legion Armorsmith", "Blackhand Legion Zırh Demircisi")
e("Blacksmith", "Demirci")
e("Blacksmith Trainer", "Demircilik Eğitmeni")
e("Blacksmithing & Mining Supplies", "Demircilik ve Madencilik Malzemeleri")
e("Blacksmithing Supplier", "Demircilik Malzemeleri Satıcısı")
e("Blacksmithing Supplies", "Demircilik Malzemeleri")
e("Blade Merchant", "Kılıç Tüccarı")
e("Blade Trader", "Kılıç Tüccarı")
e("Bloodaxe Champion", "Bloodaxe Şampiyonu")
e("Bloodscalp Chief", "Bloodscalp Reisi")
e("Bloodscalp Clan Witchdoctor", "Bloodscalp Klanı Büyücü Hekimi")
e("Bloodscalp Troll Ambassador", "Bloodscalp Troll Elçisi")
e("Blue Moon Odds and Ends", "Blue Moon Ufak Tefek Eşyalar")
e("Blue Team Captain", "Mavi Takım Kaptanı")
e("Boar Pet Trainer", "Yaban Domuzu Evcil Hayvan Eğitmeni")
e("Boar Trainer", "Yaban Domuzu Eğitmeni")
e("Boat Operator", "Tekne Operatörü")
e("Boat Vendor", "Tekne Satıcısı")
e("Bodyguard", "Koruma")
e("Book Dealer", "Kitapçı")
e("Bounty Hunter", "Ödül Avcısı")
e("Bow & Arrow Merchant", "Yay ve Ok Tüccarı")
e("Bow & Gun Merchant", "Yay ve Tüfek Tüccarı")
e("Bow Merchant", "Yay Tüccarı")
e("Bow Trainer", "Yay Eğitmeni")
e("Bowyer & Fletching Goods", "Yay Ustası ve Okçuluk Malzemeleri")
e("Bowyer & Gunsmith", "Yay ve Tüfek Ustası")
e("Boy with kittens", "Kedi Yavrulu Çocuk")
e("Brann Bronzebeard's Pet Monkey", "Brann Bronzebeard'ın Evcil Maymunu")
e("Bread Merchant", "Ekmek Tüccarı")
e("Bread Vendor", "Ekmek Satıcısı")
e("Brewing Trainer", "Bira Yapımı Eğitmeni")
e("Bride of the Embalmer", "Mumyacının Gelini")
e("Brood of Alexstrasza", "Alexstrasza'nın Soyu")
e("Brood of Malygos", "Malygos'un Soyu")
e("Brood of Ysera", "Ysera'nın Soyu")
e("Butcher", "Kasap")
e("Camp Trader", "Kamp Tüccarı")
e("Captain of the Battleguard", "Savaş Muhafızları Kaptanı")
e("Captain of the Guard", "Muhafız Kaptanı")
e("Captain of the Maiden's Virtue", "Maiden's Virtue Kaptanı")
e("Cartography Supplier", "Haritacılık Malzemeleri Satıcısı")
e("Cartography Trainer", "Haritacılık Eğitmeni")
e("Cat Pet Trainer", "Kedi Evcil Hayvan Eğitmeni")
e("Cat Trainer", "Kedi Eğitmeni")
e("Celmoridan's Pet", "Celmoridan'ın Evcil Hayvanı")
e("Cenarion Lore Keeper", "Cenarion Bilgi Bekçisi")
e("Champion of Razelikh", "Razelikh'in Şampiyonu")
e("Champion of the Banshee Queen", "Banshee Kraliçesi'nin Şampiyonu")
e("Champion of the Horde", "Horde'un Şampiyonu")
e("Chef", "Şef")
e("Chief Architect", "Baş Mimar")
e("Chief Engineer", "Baş Mühendis")
e("City Architect", "Şehir Mimarı")
e("Cloth Armor and Accessories", "Kumaş Zırh ve Aksesuarlar")
e("Clothier", "Kumaşçı")
e("Cobbler", "Ayakkabıcı")
e("Cockroach Vendor", "Hamamböceği Satıcısı")
e("Coin of Ancestry Collector", "Coin of Ancestry Toplayıcısı")
e("Cook", "Aşçı")
e("Cooking Supplier", "Aşçılık Malzemeleri Satıcısı")
e("Cooking Supplies", "Aşçılık Malzemeleri")
e("Copper Bar Collector", "Copper Bar Toplayıcısı")
e("Council of Darkshire", "Darkshire Konseyi")
e("Crawler Pet Trainer", "Sürüngen Evcil Hayvan Eğitmeni")
e("Crawler Trainer", "Sürüngen Eğitmeni")
e("Crazy Cat Lady", "Kedici Deli Kadın")
e("Crocodile Pet Trainer", "Timsah Evcil Hayvan Eğitmeni")
e("Crossbow Trainer", "Arbalet Eğitmeni")
e("Cyrus's Minion", "Cyrus'un Kölesi")
e("Dagger Trainer", "Hançer Eğitmeni")
e("Dark Iron Captain", "Dark Iron Kaptanı")
e("Darkmoon Faire Barker", "Darkmoon Faire Çığırtkanı")
e("Darkmoon Faire Cannoneer", "Darkmoon Faire Topçusu")
e("Darkmoon Faire Cards & Exotic Goods", "Darkmoon Faire Kartları ve Egzotik Mallar")
e("Darkmoon Faire Drink Vendor", "Darkmoon Faire İçecek Satıcısı")
e("Darkmoon Faire Exotic Goods", "Darkmoon Faire Egzotik Mallar")
e("Darkmoon Faire Food Vendor", "Darkmoon Faire Yiyecek Satıcısı")
e("Darkmoon Faire Information", "Darkmoon Faire Danışma")
e("Darkmoon Faire Ticket Redemption", "Darkmoon Faire Bilet Takası")
e("Darkspear Commendations", "Darkspear Takdirnameleri")
e("Darkspear Hostage", "Darkspear Rehinesi")
e("Darnassus Commendations", "Darnassus Takdirnameleri")
e("Darnassus Flight Master", "Darnassus Uçuş Ustası")
e("Dawn Whisperer", "Şafak Fısıldayıcısı")
e("Death's Head Captain", "Death's Head Kaptanı")
e("Death's Head Prophet", "Death's Head Kâhini")
e("Deathstalker", "Ölüm Takipçisi")
e("Defias Kingpin", "Defias Elebaşı")
e("Defilers Supply Officer", "Defilers İkmal Subayı")
e("Demon Master", "İblis Ustası")
e("Deputy Mayor of Darkshire", "Darkshire Belediye Başkan Yardımcısı")
e("Designer Extraordinaire", "Olağanüstü Tasarımcı")
e("Disciple of Naralex", "Naralex'in Müridi")
e("Ditch Digger", "Hendek Kazıcı")
e("Dorion's Pet", "Dorion'un Evcil Hayvanı")
e("Dragonmaw Chieftain", "Dragonmaw Reisi")
e("Dragonmaw Warlord", "Dragonmaw Savaş Lordu")
e("Dragonscale Leatherworking Trainer", "Ejder Pulu Dericilik Eğitmeni")
e("Drink Vendor", "İçecek Satıcısı")
e("Droffers and Son Salvage", "Droffers ve Oğlu Hurdacılık")
e("Druid of the Claw", "Pençe Druidi")
e("Druid of the Fang", "Diş Druidi")
e("Drunk", "Sarhoş")
e("Dwarven Mortar Team", "Dwarf Havan Ekibi")
e("Dwarven Weaponsmith", "Dwarf Silah Ustası")
e("Elder Crone", "Yaşlı Kocakarı")
e("Elder Far Seer", "Kıdemli Kâhin")
e("Elemental Leatherworking Trainer", "Elementel Dericilik Eğitmeni")
e("Enchanting Supplier", "Efsunculuk Malzemeleri Satıcısı")
e("Enchanting Supplies", "Efsunculuk Malzemeleri")
e("Engineer", "Mühendis")
e("Engineering & General Goods Supplier", "Mühendislik ve Genel Mal Satıcısı")
e("Engineering Goods", "Mühendislik Malları")
e("Engineering Supplier", "Mühendislik Malzemeleri Satıcısı")
e("Engineering Supplies", "Mühendislik Malzemeleri")
e("Engineering and Mining Supplies", "Mühendislik ve Madencilik Malzemeleri")
e("Ex-Chef", "Eski Şef")
e("Excavation Specialist", "Kazı Uzmanı")
e("Exotic Item Vendor", "Egzotik Eşya Satıcısı")
e("Exotic Reagent Merchant", "Egzotik Reaktif Tüccarı")
e("Expert Alchemist", "Uzman Simyacı")
e("Expert Blacksmith", "Uzman Demirci")
e("Expert Enchanter", "Uzman Efsuncu")
e("Expert Engineer", "Uzman Mühendis")
e("Expert Leathercrafter", "Uzman Deri İşçisi")
e("Expert Leatherworker", "Uzman Deri İşçisi")
e("Expert Tailor", "Uzman Terzi")
e("Fanglord", "Diş Lordu")
e("Far Watch Sparrer", "Far Watch İdman Partneri")
e("Fashion Designer", "Moda Tasarımcısı")
e("Festival Supplies", "Festival Malzemeleri")
e("Firebloom Collector", "Firebloom Toplayıcısı")
e("Firebrand Legion Champion", "Firebrand Legion Şampiyonu")
e("Fireworks Merchant", "Havai Fişek Tüccarı")
e("Fireworks Vendor", "Havai Fişek Satıcısı")
e("Fish Merchant", "Balık Tüccarı")
e("Fish Merchant & Supplies", "Balık Tüccarı ve Malzemeleri")
e("Fish Vendor", "Balık Satıcısı")
e("Fisherman", "Balıkçı")
e("Fisherman Supplies", "Balıkçı Malzemeleri")
e("Fishing Promoter", "Balıkçılık Tanıtımcısı")
e("Fishing Supplier", "Balıkçılık Malzemeleri Satıcısı")
e("Fishing Supplies", "Balıkçılık Malzemeleri")
e("Fishing Trainer & Supplies", "Balıkçılık Eğitmeni ve Malzemeleri")
e("Fishmaster", "Balık Ustası")
e("Fishmaster Apprentice", "Balık Ustası Çırağı")
e("Fishmonger", "Balıkçı Esnafı")
e("Fist Weapons Trainer", "Yumruk Silahları Eğitmeni")
e("Fletcher", "Ok Ustası")
e("Fletching Supplier", "Okçuluk Malzemeleri Satıcısı")
e("Florist", "Çiçekçi")
e("Food & Drink Merchant", "Yiyecek ve İçecek Tüccarı")
e("Food Merchant", "Yiyecek Tüccarı")
e("Food and Drink", "Yiyecek ve İçecek")
e("Food and Drinks", "Yiyecek ve İçecekler")
e("Foraging Trainer", "Yiyecek Toplama Eğitmeni")
e("Free Wheeling Merchant", "Serbest Gezgin Tüccar")
e("Freewheeling Tradeswoman", "Serbest Gezgin Tüccar Kadın")
e("Frostwolf Captain", "Frostwolf Kaptanı")
e("Frostwolf General", "Frostwolf Generali")
e("Frostwolf Supply Officer", "Frostwolf İkmal Subayı")
e("Fruit Seller", "Meyveci")
e("Fruit Vendor", "Meyve Satıcısı")
e("Fungus Vendor", "Mantar Satıcısı")
e("Gadgetzan Water Co.", "Gadgetzan Su Şirketi")
e("General & Trade Supplies", "Genel ve Ticaret Malzemeleri")
e("General Goods Merchant", "Genel Mal Tüccarı")
e("General Supplies", "Genel Malzemeler")
e("General Trade Goods Merchant", "Genel Ticaret Malları Tüccarı")
e("General Trade Goods Vendor", "Genel Ticaret Malları Satıcısı")
e("General Trade Supplier", "Genel Ticaret Malzemeleri Satıcısı")
e("General of the Sentinel Army", "Sentinel Ordusu Generali")
e("Gerard's Mindslave", "Gerard'ın Zihin Kölesi")
e("Gift from the Embalmer", "Mumyacıdan Hediye")
e("Giver of the Beatings", "Dayak Atıcı")
e("Gnome Engineering Trainer", "Gnome Mühendisliği Eğitmeni")
e("Gnome Ticket Redeemer", "Gnome Bilet Takasçısı")
e("Gnomeregan Commendations", "Gnomeregan Takdirnameleri")
e("Goblin Engineering Trainer", "Goblin Mühendisliği Eğitmeni")
e("Goblin Ticket Redeemer", "Goblin Bilet Takasçısı")
e("Gorilla Pet Trainer", "Goril Evcil Hayvan Eğitmeni")
e("Grand Master Rogue", "Büyük Usta Haydut (Rogue)")
e("Grand Master of the Assassin's League", "Assassin's League Büyük Ustası")
e("Grash Thunderbrew's Pet", "Grash Thunderbrew'un Evcil Hayvanı")
e("Grocer", "Bakkal")
e("Guardian of the Idol", "Put Muhafızı")
e("Guild Tabard Designer", "Lonca Tabard Tasarımcısı")
e("Guild Tabard Vendor", "Lonca Tabard Satıcısı")
e("Gun Merchant", "Tüfek Tüccarı")
e("Gun Trainer", "Tüfek Eğitmeni")
e("Guns Merchant", "Tüfek Tüccarı")
e("Guns Vendor", "Tüfek Satıcısı")
e("Guns and Ammo Merchant", "Tüfek ve Cephane Tüccarı")
e("Gunsmith & Bowyer", "Tüfek ve Yay Ustası")
e("HOLDER OF THE GONG", "GONG SAHİBİ")
e("Hallow's End Treats", "Hallow's End İkramları")
e("Hand of Rastakhan", "Rastakhan'ın Eli")
e("Hand of Sargeras", "Sargeras'ın Eli")
e("Hatter", "Şapkacı")
e("He Who Never Forgets!", "Asla Unutmayan!")
e("Head Chef", "Baş Şef")
e("Heavy Armor Merchant", "Ağır Zırh Tüccarı")
e("Heavy Leather Collector", "Heavy Leather Toplayıcısı")
e("Herbalism & Alchemy Supplies", "Bitkicilik ve Simya Malzemeleri")
e("Herbalism Supplier", "Bitkicilik Malzemeleri Satıcısı")
e("Herbalist", "Bitkici")
e("High Chieftain", "Yüce Reis")
e("High Commander of Stormwind Defense", "Stormwind Savunması Yüce Komutanı")
e("High Priest", "Baş Rahip")
e("High Priestess of C'Thun", "C'Thun'un Baş Rahibesi")
e("High Priestess of Elune", "Elune'un Baş Rahibesi")
e("High Thane", "Yüce Thane")
e("Highlord of the Scarlet Crusade", "Scarlet Crusade'in Yüce Lordu")
e("Historian of Darkshire", "Darkshire Tarihçisi")
e("Hive'Ashi Overlord", "Hive'Ashi Hükümdarı")
e("Hive'Regal Overlord", "Hive'Regal Hükümdarı")
e("Hive'Zora Overlord", "Hive'Zora Hükümdarı")
e("Holiday Fireworks Vendor", "Bayram Havai Fişek Satıcısı")
e("Horde Ambassador", "Horde Elçisi")
e("Horde Cloth Quartermaster", "Horde Kumaş Levazım Subayı")
e("Horde Runner", "Horde Koşucusu")
e("Horse Breeder", "At Yetiştiricisi")
e("Horse Pet Trainer", "At Evcil Hayvan Eğitmeni")
e("Horse Riding Instructor", "At Binicilik Eğitmeni")
e("Horse Riding Trainer", "At Binicilik Eğitmeni")
e("Horse Vendor", "At Satıcısı")
e("House of Barov", "Barov Hanedanı")
e("House of Nobles", "Soylular Meclisi")
e("Hunter Beast Trainer", "Avcı (Hunter) Hayvan Eğitmeni")
e("Ice Cream Vendor", "Dondurma Satıcısı")
e("Innkeeper Assistant", "Hancı Yardımcısı")
e("Iron Bar Collector", "Iron Bar Toplayıcısı")
e("Ironforge Brigade Captain", "Ironforge Tugay Kaptanı")
e("Ironforge Commendations", "Ironforge Takdirnameleri")
e("Ironforge Siege Brigade", "Ironforge Kuşatma Tugayı")
e("Ironforge Surveyor", "Ironforge Kadastrocusu")
e("Jeen'ra's Pet", "Jeen'ra'nın Evcil Hayvanı")
e("Jessir's Pet", "Jessir'in Evcil Hayvanı")
e("Journeyman Alchemist", "Kalfa Simyacı")
e("Journeyman Alchemist Trainer", "Kalfa Simya Eğitmeni")
e("Journeyman Blacksmith", "Kalfa Demirci")
e("Journeyman Enchanter", "Kalfa Efsuncu")
e("Journeyman Engineer", "Kalfa Mühendis")
e("Journeyman Leatherworker", "Kalfa Deri İşçisi")
e("Journeyman Tailor", "Kalfa Terzi")
e("Kaerbrus' Pet", "Kaerbrus'un Evcil Hayvanı")
e("Kargath Expeditionary Force", "Kargath Sefer Kuvveti")
e("Keeper of Souls", "Ruhların Bekçisi")
e("Kel'Thuzad's Minion", "Kel'Thuzad'ın Kölesi")
e("Kennel Master", "Köpek Kulübesi Ustası")
e("King of Gnomes", "Gnome'ların Kralı")
e("King of Stormwind", "Stormwind Kralı")
e("Kira's Guard", "Kira'nın Muhafızı")
e("Kodo Mounts", "Kodo Binekleri")
e("Kodo Riding Instructor", "Kodo Binicilik Eğitmeni")
e("Kysandia's Pet", "Kysandia'nın Evcil Hayvanı")
e("Landscape Architect", "Peyzaj Mimarı")
e("Leader of SI:7", "SI:7 Lideri")
e("Leader of The Night Watch", "The Night Watch Lideri")
e("League of Arathor Supply Officer", "League of Arathor İkmal Subayı")
e("Lean Wolf Steak Collector", "Lean Wolf Steak Toplayıcısı")
e("Leather & Mail Armor Merchant", "Deri ve Zincir Zırh Tüccarı")
e("Leather Armor & Leatherworking Supplies", "Deri Zırh ve Dericilik Malzemeleri")
e("Leatherworking & Tailoring Supplies", "Dericilik ve Terzilik Malzemeleri")
e("Leatherworking Supplies", "Dericilik Malzemeleri")
e("Librarian", "Kütüphaneci")
e("Light Armor & Weapons Merchant", "Hafif Zırh ve Silah Tüccarı")
e("Light Armor Merchant", "Hafif Zırh Tüccarı")
e("Light Leather Collector", "Light Leather Toplayıcısı")
e("Linen Bandage Collector", "Linen Bandage Toplayıcısı")
e("Lizzarik's Bodyguard", "Lizzarik'in Koruması")
e("Lockpicking Trainer", "Kilit Açma Eğitmeni")
e("Long Distance Recovery Unit", "Uzun Mesafe Kurtarma Birimi")
e("Loramus's Guardian", "Loramus'un Muhafızı")
e("Lord of Blackrock", "Blackrock Lordu")
e("Lord of Ironforge", "Ironforge Lordu")
e("Lord of Terror", "Dehşet Lordu")
e("Lord of the Assassin's League", "Assassin's League Lordu")
e("Lorekeeper", "Bilgi Bekçisi")
e("Lumberjack", "Oduncu")
e("Lumbermaster", "Odun Ustası")
e("Mace & Staff Merchant", "Gürz ve Asa Tüccarı")
e("Mace & Staves Vendor", "Gürz ve Asa Satıcısı")
e("Mace Trainer", "Gürz Eğitmeni")
e("Macecrafter", "Gürz Ustası")
e("Maces & Staves", "Gürzlar ve Asalar")
e("Magatha's Servant", "Magatha'nın Hizmetkârı")
e("Mage of Tower Azora", "Azora Kulesi Büyücüsü")
e("Mageweave Bandage Collector", "Mageweave Sargı Toplayıcısı")
e("Magic Skills Trainer", "Büyü Becerileri Eğitmeni")
e("Mail & Plate Merchant", "Zincir ve Plaka Zırh Tüccarı")
e("Malgen Longspear's Pet", "Malgen Longspear'ın Evcil Hayvanı")
e("Master Alchemist", "Usta Simyacı")
e("Master Blacksmith", "Usta Demirci")
e("Master Dragonscale Leatherworker", "Usta Ejderha Pulu Deri İşçisi")
e("Master Elemental Leatherworker", "Usta Elementel Deri İşçisi")
e("Master Enchanter", "Usta Efsuncu")
e("Master Engineer", "Usta Mühendis")
e("Master Gnome Engineer", "Usta Gnome Mühendisi")
e("Master Goblin Engineer", "Usta Goblin Mühendisi")
e("Master Leatherworker", "Usta Deri İşçisi")
e("Master Leatherworking Trainer", "Usta Dericilik Eğitmeni")
e("Master Mage", "Usta Büyücü")
e("Master Paladin", "Usta Paladin")
e("Master Shadoweave Tailor", "Usta Shadoweave Terzisi")
e("Master Tailor", "Usta Terzi")
e("Master Tribal Leatherworker", "Usta Kabile Deri İşçisi")
e("Master Weaponsmith", "Usta Silahçı")
e("Master of Cheese", "Peynir Ustası")
e("Master of Cooking Recipes", "Yemek Tarifleri Ustası")
e("Mayor of Darkshire", "Darkshire Belediye Başkanı")
e("Meat Vendor", "Et Satıcısı")
e("Mechanostrider Merchant", "Mechanostrider Tüccarı")
e("Mechanostrider Pilot", "Mechanostrider Pilotu")
e("Mechastrider Riding Trainer", "Mechastrider Binicilik Eğitmeni")
e("Medium Leather Collector", "Orta Deri Toplayıcısı")
e("Merchant Supreme", "Tüccarların Tüccarı")
e("Merlot Connoisseur", "Merlot Uzmanı")
e("Metalsmith", "Metal Ustası")
e("Miner", "Madenci")
e("Miner <Temp>", "Madenci <Geçici>")
e("Miners' League", "Madenciler Birliği")
e("Mining Supplier", "Madencilik Malzemecisi")
e("Mining Supplies", "Madencilik Malzemeleri")
e("Mining and Smithing Supplies", "Madencilik ve Demircilik Malzemeleri")
e("Minion of Alex", "Alex'in Uşağı")
e("Mistress of Cheese", "Peynir Hanımı")
e("Mithril Bar Collector", "Mithril Külçe Toplayıcısı")
e("Model and Texture", "Model ve Doku")
e("Monster Slayer Trainer", "Canavar Avcısı Eğitmeni")
e("Morale Officer", "Moral Subayı")
e("Mount Quartermaster", "Binek Levazım Subayı")
e("Mount Vendor", "Binek Satıcısı")
e("Mushroom Farmer", "Mantar Çiftçisi")
e("Mushroom Merchant", "Mantar Tüccarı")
e("Mushroom Seller", "Mantar Satıcısı")
e("Mushroom Vendor", "Mantar Satıcısı")
e("Niby's Minion", "Niby'nin Uşağı")
e("Night Elf Armorer", "Night Elf Zırh Ustası")
e("Nightsaber Riding Instructor", "Nightsaber Binicilik Eğitmeni")
e("Nilith's Guardian", "Nilith'in Muhafızı")
e("No Clothes NPC", "Kıyafetsiz NPC")
e("Novice Priestess", "Acemi Rahibe")
e("Officer Accessories Quartermaster", "Subay Aksesuarları Levazım Subayı")
e("Orgrimmar Commendations", "Orgrimmar Takdirnameleri")
e("Orgrimmar Legion Captain", "Orgrimmar Lejyon Kaptanı")
e("Orphanage Matron", "Yetimhane Müdiresi")
e("Overfiend", "Baş İblis")
e("Overseer of Sul", "Sul Gözetmeni")
e("Owl Trainer", "Baykuş Eğitmeni")
e("Panda Cub Caretaker", "Panda Yavrusu Bakıcısı")
e("Peacebloom Collector", "Peacebloom Toplayıcısı")
e("Pet Trainer", "Evcil Hayvan Eğitmeni")
e("Physician", "Hekim")
e("Pie Vendor", "Turta Satıcısı")
e("Pirate Supplies", "Korsan Malzemeleri")
e("Pissed Vendor", "Sinirli Satıcı")
e("Poison Supplier", "Zehir Malzemecisi")
e("Poison Vendor", "Zehir Satıcısı")
e("Poisons & Reagents", "Zehirler ve Reaktifler")
e("Polearm Trainer", "Mızrak Eğitmeni")
e("Portal Trainer", "Geçit Eğitmeni")
e("Portal: Darnassus Trainer", "Geçit: Darnassus Eğitmeni")
e("Portal: Ironforge Trainer", "Geçit: Ironforge Eğitmeni")
e("Portal: Orgrimmar Trainer", "Geçit: Orgrimmar Eğitmeni")
e("Portal: Stormwind Trainer", "Geçit: Stormwind Eğitmeni")
e("Portal: Thunder Bluff Trainer", "Geçit: Thunder Bluff Eğitmeni")
e("Portal: Undercity Trainer", "Geçit: Undercity Eğitmeni")
e("Potions & Herbs", "İksirler ve Şifalı Bitkiler")
e("Potions, Scrolls and Reagents", "İksirler, Parşömenler ve Reaktifler")
e("Prairie Dog", "Çayır Köpeği")
e("Prairie Dog Vendor", "Çayır Köpeği Satıcısı")
e("Princess of Ironforge", "Ironforge Prensesi")
e("Protector", "Koruyucu")
e("Purple Lotus Collector", "Purple Lotus Toplayıcısı")
e("Pyrewood Council Leader", "Pyrewood Council Lideri")
e("Quartermaster", "Levazım Subayı")
e("Questgiver", "Görev Veren")
e("Race Announcer", "Yarış Spikeri")
e("Race Starter Girl", "Yarış Başlatıcı Kız")
e("Race Vendor", "Yarış Satıcısı")
e("Raene's Pet", "Raene'nin Evcil Hayvanı")
e("Ragefire Chieftain", "Ragefire Reisi")
e("Rainbow Fin Albacore Collector", "Rainbow Fin Albacore Toplayıcısı")
e("Ram Breeder", "Koç Yetiştiricisi")
e("Ram Riding Instructor", "Koç Binicilik Eğitmeni")
e("Ram Riding Trainer", "Koç Binicilik Eğitmeni")
e("Ranged Skills Trainer", "Menzilli Beceriler Eğitmeni")
e("Raptor Handler", "Raptor Bakıcısı")
e("Raptor Pet Trainer", "Raptor Evcil Hayvan Eğitmeni")
e("Raptor Riding Trainer", "Raptor Binicilik Eğitmeni")
e("Raptor Trainer", "Raptor Eğitmeni")
e("Rare Goods", "Nadir Mallar")
e("Rat Extermination Specialist", "Fare İmha Uzmanı")
e("Ravasaur Trainers", "Ravasaur Eğitmenleri")
e("Razormane Champion", "Razormane Şampiyonu")
e("Reagent Supplier", "Reaktif Malzemecisi")
e("Reagent Supplies", "Reaktif Malzemeleri")
e("Reagents & Poisons", "Reaktifler ve Zehirler")
e("Reagents Vendor", "Reaktif Satıcısı")
e("Reagents and Herbs", "Reaktifler ve Şifalı Bitkiler")
e("Reagents/Totems Vendor", "Reaktif/Totem Satıcısı")
e("Rebel Soldier", "Asi Asker")
e("Red Team Captain", "Kırmızı Takım Kaptanı")
e("Rend Blackhand's Mount", "Rend Blackhand'in Bineği")
e("Rivern's Guardian", "Rivern'in Muhafızı")
e("Roast Raptor Collector", "Kızarmış Raptor Toplayıcısı")
e("Robe Merchant", "Cübbe Tüccarı")
e("Robe Vendor", "Cübbe Satıcısı")
e("Royal Stonecutters Union", "Kraliyet Taşkesenler Birliği")
e("Rugged Leather Collector", "Rugged Leather Toplayıcısı")
e("Ruler of Theramore", "Theramore Hükümdarı")
e("Runecloth Bandage Collector", "Runecloth Sargı Toplayıcısı")
e("SI:7 Operative", "SI:7 Ajanı")
e("Saber Handler", "Saber Bakıcısı")
e("Sandfury Troll Ambassador", "Sandfury Troll Elçisi")
e("Scarlet Crusade Emissary", "Scarlet Crusade Elçisi")
e("School Mistress", "Okul Öğretmeni")
e("Scorpid Pet Trainer", "Scorpid Evcil Hayvan Eğitmeni")
e("Scrolls & Potions", "Parşömenler ve İksirler")
e("Sergeant", "Çavuş")
e("Servitor of Rastakhan", "Rastakhan'ın Hizmetkârı")
e("Servitor of Zanza", "Zanza'nın Hizmetkârı")
e("Shadow Council Warlock", "Shadow Council Kara Büyücüsü")
e("Shady Dealer", "Şüpheli Satıcı")
e("Shady Goods", "Şüpheli Mallar")
e("Shield Crafter", "Kalkan Ustası")
e("Shield Merchant", "Kalkan Tüccarı")
e("Shipmaster", "Gemi Kaptanı")
e("Silk Bandage Collector", "İpek Sargı Toplayıcısı")
e("Silverwing Supply Officer", "Silverwing İkmal Subayı")
e("Simone's Pet", "Simone'un Evcil Hayvanı")
e("Sire", "Efendi")
e("Skinner", "Deri Yüzücü")
e("Skullsplitter Chief", "Skullsplitter Reisi")
e("Skullsplitter Clan Witchdoctor", "Skullsplitter Klanı Cadı Doktoru")
e("Skullsplitter Troll Ambassador", "Skullsplitter Troll Elçisi")
e("Snake Vendor", "Yılan Satıcısı")
e("Special Goods Dealer", "Özel Mal Satıcısı")
e("Special Weapon Crafter", "Özel Silah Ustası")
e("Specialist Leatherworking Supplies", "Uzman Dericilik Malzemeleri")
e("Specialist Tailoring Supplies", "Uzman Terzilik Malzemeleri")
e("Speciality Dress Maker", "Özel Elbise Terzisi")
e("Speciality Engineer", "Uzman Mühendis")
e("Speciality Goods", "Özel Mallar")
e("Speciality Tailoring Supplies", "Özel Terzilik Malzemeleri")
e("Spectral Gryphon Master", "Hayalet Grifon Ustası")
e("Spider Pet Trainer", "Örümcek Evcil Hayvan Eğitmeni")
e("Spider Trainer", "Örümcek Eğitmeni")
e("Spotted Yellowtail Collector", "Spotted Yellowtail Toplayıcısı")
e("Stablehand", "Seyis")
e("Staff & Mace Merchant", "Asa ve Gürz Tüccarı")
e("Staff Merchant", "Asa Tüccarı")
e("Staves Merchant", "Asa Tüccarı")
e("Staves Trainer", "Asa Eğitmeni")
e("Stonesplinter Chieftain", "Stonesplinter Reisi")
e("Stonesplinter Tribal Shaman", "Stonesplinter Kabile Şamanı")
e("Stonevault Chieftain", "Stonevault Reisi")
e("Stormpike Captain", "Stormpike Kaptanı")
e("Stormpike General", "Stormpike Generali")
e("Stormpike Guard Recruitment Officer", "Stormpike Muhafız Alım Subayı")
e("Stormpike Supply Officer", "Stormpike İkmal Subayı")
e("Stormwind Census", "Stormwind Nüfus Sayımı")
e("Stormwind City Guard", "Stormwind Şehir Muhafızı")
e("Stormwind Commendations", "Stormwind Takdirnameleri")
e("Stormwind Recruiter", "Stormwind Asker Toplayıcısı")
e("Stranglekelp Collector", "Stranglekelp Toplayıcısı")
e("Strumner's Pet", "Strumner'in Evcil Hayvanı")
e("Stylish Clothier", "Şık Kumaşçı")
e("Superior Armor Crafter", "Üstün Zırh Ustası")
e("Superior Armorer", "Üstün Zırh Ustası")
e("Superior Armorsmith", "Üstün Zırh Demircisi")
e("Superior Axecrafter", "Üstün Balta Ustası")
e("Superior Bowyer", "Üstün Yay Ustası")
e("Superior Butcher", "Üstün Kasap")
e("Superior Cook", "Üstün Aşçı")
e("Superior Fisherman", "Üstün Balıkçı")
e("Superior Herbalist", "Üstün Bitkici")
e("Superior Leatherworker", "Üstün Deri İşçisi")
e("Superior Macecrafter", "Üstün Gürz Ustası")
e("Superior Miner", "Üstün Madenci")
e("Superior Tradesman", "Üstün Esnaf")
e("Superior Weaponsmith", "Üstün Silah Ustası")
e("Survival Trainer", "Hayatta Kalma Eğitmeni")
e("Sweet Treats", "Tatlı İkramlar")
e("Sword Trainer", "Kılıç Eğitmeni")
e("Sword and Dagger Merchant", "Kılıç ve Hançer Tüccarı")
e("Syndicate Leader", "Syndicate Lideri")
e("Tabard Designer", "Tabard Tasarımcısı")
e("Tackle and Bait", "Olta Takımı ve Yem")
e("Tailor Trainer", "Terzilik Eğitmeni")
e("Tailoring & Leatherworking Supplies", "Terzilik ve Dericilik Malzemeleri")
e("Tailoring Supplies", "Terzilik Malzemeleri")
e("Tailoring Supplies & Specialty Goods", "Terzilik Malzemeleri ve Özel Mallar")
e("Talar's Pet", "Talar'ın Evcil Hayvanı")
e("Talent Master", "Yetenek Ustası")
e("Tallstrider Pet Trainer", "Tallstrider Evcil Hayvan Eğitmeni")
e("Tallstrider Trainer", "Tallstrider Eğitmeni")
e("Tavernkeeper", "Meyhaneci")
e("The Announcer", "Spiker")
e("The Black Chicken of Death", "Ölümün Kara Tavuğu")
e("The Black Flame", "Kara Alev")
e("The Butcher", "Kasap")
e("The Cell Keeper", "Zindancı")
e("The Crone", "Kocakarı")
e("The Cursed", "Lanetli")
e("The Drunk", "Sarhoş")
e("The Fifth Kahn", "Beşinci Kahn")
e("The First Kahn", "Birinci Kahn")
e("The First Mate", "İkinci Kaptan")
e("The Foreman", "Ustabaşı")
e("The Fourth Kahn", "Dördüncü Kahn")
e("The Hand of Chaos", "Kaosun Eli")
e("The Hermit", "Münzevi")
e("The Islander", "Adalı")
e("The Keymaster", "Anahtar Ustası")
e("The Scarlet Champion", "Scarlet Şampiyonu")
e("The Scarlet Oracle", "Scarlet Kâhini")
e("The Second Kahn", "İkinci Kahn")
e("The Ship's Cook", "Gemi Aşçısı")
e("The Ship's First Mate", "Geminin İkinci Kaptanı")
e("The Smelter", "Eritici")
e("The Strongest Woman Alive!", "Yaşayan En Güçlü Kadın!")
e("The Surveyor", "Kâşif")
e("The Third Kahn", "Üçüncü Kahn")
e("The Undermarket", "Yeraltı Pazarı")
e("The Venom Queen", "Zehir Kraliçesi")
e("The Wind Seeker", "Rüzgâr Arayıcısı")
e("The Wolf", "Kurt")
e("Thick Leather Collector", "Thick Leather Toplayıcısı")
e("Thorium Bar Collector", "Thorium Külçe Toplayıcısı")
e("Thrown Weapon Trainer", "Fırlatma Silahı Eğitmeni")
e("Thrown Weapons Merchant", "Fırlatma Silahları Tüccarı")
e("Thrown Weapons Trainer", "Fırlatma Silahları Eğitmeni")
e("Thunder Bluff Commendations", "Thunder Bluff Takdirnameleri")
e("Thunder Bluff Flight Master", "Thunder Bluff Uçuş Ustası")
e("Tiger Riding Trainer", "Kaplan Binicilik Eğitmeni")
e("Tin Bar Collector", "Kalay Külçe Toplayıcısı")
e("Tinkers' Union", "Tamirciler Birliği")
e("Tools & Supplies", "Aletler ve Malzemeler")
e("Totem Merchent", "Totem Tüccarı")
e("Town Historian", "Kasaba Tarihçisi")
e("Tracking Trainer", "İz Sürme Eğitmeni")
e("Trade Goods", "Ticari Mallar")
e("Trade Goods Supplier", "Ticari Mal Malzemecisi")
e("Trade Goods Supplies", "Ticari Mal Malzemeleri")
e("Trade Supplier", "Ticari Malzemeci")
e("Tradesman", "Esnaf")
e("Tradeswoman", "Esnaf")
e("Trauma Surgeon", "Travma Cerrahı")
e("Traveling Baker", "Gezgin Fırıncı")
e("Traveling Merchant", "Gezgin Tüccar")
e("Traveling Salesman", "Gezgin Satıcı")
e("Tribal Leatherworking Trainer", "Kabile Dericilik Eğitmeni")
e("Troyas' Pet", "Troyas'ın Evcil Hayvanı")
e("Turtle Pet Trainer", "Kaplumbağa Evcil Hayvan Eğitmeni")
e("Turtle Trainer", "Kaplumbağa Eğitmeni")
e("Twilight's Hammer Interrogator", "Twilight's Hammer Sorgucusu")
e("Two Handed Weapon Merchant", "İki Elli Silah Tüccarı")
e("Two-Handed Weapons Merchant", "İki Elli Silahlar Tüccarı")
e("Unbalanced Engineer", "Dengesiz Mühendis")
e("Undead Horse Merchant", "Ölümsüz At Tüccarı")
e("Undead Horse Riding Instructor", "Ölümsüz At Binicilik Eğitmeni")
e("Undead Horse Riding Trainer", "Ölümsüz At Binicilik Eğitmeni")
e("Undercity Census", "Undercity Nüfus Sayımı")
e("Undercity Commendations", "Undercity Takdirnameleri")
e("Use Your Imagination", "Hayal Gücünü Kullan")
e("Valyen's Pet", "Valyen'in Evcil Hayvanı")
e("Vault Administrator", "Kasa Yöneticisi")
e("Vengeance", "İntikam")
e("Venture Armor Salesman", "Venture Zırh Satıcısı")
e("Venture Co. Merchant", "Venture Co. Tüccarı")
e("Vilebranch Troll Ambassador", "Vilebranch Troll Elçisi")
e("Vintner", "Şarapçı")
e("Waitress", "Garson")
e("Wand Merchant", "Değnek Tüccarı")
e("Wand Vendor", "Değnek Satıcısı")
e("Wandering Minstrel", "Gezgin Ozan")
e("Wands Merchant", "Değnek Tüccarı")
e("War Effort Commander", "Savaş Seferberliği Komutanı")
e("War Effort Recruiter", "Savaş Seferberliği Asker Toplayıcısı")
e("War Harness Maker", "Savaş Koşumu Ustası")
e("War Harness Vendor", "Savaş Koşumu Satıcısı")
e("Warband Leader", "Savaş Grubu Lideri")
e("Warchief", "Savaş Reisi")
e("Wargryphon Master", "Savaş Grifonu Ustası")
e("Warlord of the Blackrock Clan", "Blackrock Klanı Savaş Lordu")
e("Warsong Gulch Battlemaster", "Warsong Gulch Savaş Ustası")
e("Warsong Supply Officer", "Warsong İkmal Subayı")
e("Waste Management", "Atık Yönetimi")
e("Water Co. Security", "Su Şirketi Güvenliği")
e("Weapon Crafter", "Silah Ustası")
e("Weapon Dealer", "Silah Satıcısı")
e("Weapon Master", "Silah Ustası")
e("Weapon Peddler", "Seyyar Silah Satıcısı")
e("Weapon Vendor", "Silah Satıcısı")
e("Weapons Merchant", "Silah Tüccarı")
e("Weapons Quartermaster", "Silah Levazım Subayı")
e("Weaponsmith", "Silah Ustası")
e("Weaponsmith & Armorcrafter", "Silah ve Zırh Ustası")
e("Weaponsmith & Armorer", "Silah ve Zırh Ustası")
e("Weaponsmith & Gunsmith", "Silah ve Tüfek Ustası")
e("Weaponsmith <Temp>", "Silah Ustası <Geçici>")
e("Weaponsmith Trainer", "Silah Ustalığı Eğitmeni")
e("Wind Rider Apprentice", "Rüzgâr Binicisi Çırağı")
e("Wine Vendor", "Şarap Satıcısı")
e("Winterax Hero", "Winterax Kahramanı")
e("Wintersaber Trainers", "Wintersaber Eğitmenleri")
e("Witch Doctor in Training", "Cadı Doktoru Adayı")
e("Witherbark Troll Ambassador", "Witherbark Troll Elçisi")
e("Wolf Merchant", "Kurt Tüccarı")
e("Wolf Pet Trainer", "Kurt Evcil Hayvan Eğitmeni")
e("Wolf Riding Instructor", "Kurt Binicilik Eğitmeni")
e("Wolf Riding Trainer", "Kurt Binicilik Eğitmeni")
e("Wolf Trainer", "Kurt Eğitmeni")
e("Woodcrafter", "Ahşap Ustası")
e("Woodcrafting Supplier", "Ahşap İşçiliği Malzemecisi")
e("Wool Bandage Collector", "Yün Sargı Toplayıcısı")
e("Workshop Assistant", "Atölye Yardımcısı")
e("Xylem's Apprentice", "Xylem'in Çırağı")
e("Zandalar Supplies and Repair", "Zandalar Malzeme ve Tamir")
e("Zardeth's Minion", "Zardeth'in Uşağı")
e("Zeppelin Master", "Zeplin Ustası")
e("Zeppelin Operator", "Zeplin Operatörü")
e("iCoke Redemption Vendor", "iCoke Kupon Satıcısı")
local I = WoWTurkce.NpcAltBaslikId
for _, i in ipairs({12799,12805}) do I[i] = "Accessories Quartermaster" end
for _, i in ipairs({3230}) do I[i] = "Advisor to Thrall" end
for _, i in ipairs({14352}) do I[i] = "Agent of Therazane" end
for _, i in ipairs({3548}) do I[i] = "Alchemy & Herbalism Supplies" end
for _, i in ipairs({1313,1453,2380,2480,2481,2812,2848,3010,3348,3956,4226,4610,5178,5594,8157,8158,8177,8178,11188}) do I[i] = "Alchemy Supplies" end
for _, i in ipairs({1697}) do I[i] = "Ale and Wine" end
for _, i in ipairs({15458}) do I[i] = "Alliance Ambassador" end
for _, i in ipairs({14722,14723,14724,14725}) do I[i] = "Alliance Cloth Quartermaster" end
for _, i in ipairs({5797,5798,5799,5800}) do I[i] = "Alliance Outrunner" end
for _, i in ipairs({5793,5794,5795}) do I[i] = "Alliance Peacekeeper" end
for _, i in ipairs({4982}) do I[i] = "Altar Boy" end
for _, i in ipairs({347,5118,7410,7427,12197,14942}) do I[i] = "Alterac Valley Battlemaster" end
for _, i in ipairs({17598}) do I[i] = "Ammunition Vendor" end
for _, i in ipairs({2748}) do I[i] = "Ancient Stone Watcher" end
for _, i in ipairs({3616}) do I[i] = "Ancient of Lore" end
for _, i in ipairs({7904}) do I[i] = "Angelas' Pet" end
for _, i in ipairs({2116,2135}) do I[i] = "Apprentice Armorer" end
for _, i in ipairs({5081}) do I[i] = "Apprentice Chef" end
for _, i in ipairs({3522}) do I[i] = "Apprentice Clothier" end
for _, i in ipairs({2114,2133}) do I[i] = "Apprentice Herbalist" end
for _, i in ipairs({1698,2117,2136}) do I[i] = "Apprentice Weaponsmith" end
for _, i in ipairs({4083}) do I[i] = "Apprentice Witch Doctor" end
for _, i in ipairs({4981}) do I[i] = "Apprentice of Cheese" end
for _, i in ipairs({857,907,12198,15006,15007,15008}) do I[i] = "Arathi Basin Battlemaster" end
for _, i in ipairs({958}) do I[i] = "Arkan Goods" end
for _, i in ipairs({983,1257}) do I[i] = "Arkan Goods Vendor" end
for _, i in ipairs({1307}) do I[i] = "Arkan Trinkets Vendor" end
for _, i in ipairs({5164,5508,7230}) do I[i] = "Armor Crafter" end
for _, i in ipairs({12777,12792}) do I[i] = "Armor Quartermaster" end
for _, i in ipairs({226,956,1104,1240,1362,1450,1468,3553,4883}) do I[i] = "Armorer" end
for _, i in ipairs({1213,1249,2046,3161,3167,3493,3592,3613}) do I[i] = "Armorer & Shieldcrafter" end
for _, i in ipairs({4187,4886}) do I[i] = "Armorer & Shieldsmith" end
for _, i in ipairs({3075,3080}) do I[i] = "Armorer and Shieldcrafter" end
for _, i in ipairs({11177,12040}) do I[i] = "Armorsmith" end
for _, i in ipairs({7174}) do I[i] = "Armorsmithing Trainer" end
for _, i in ipairs({4174}) do I[i] = "Arrow Merchant" end
for _, i in ipairs({15445}) do I[i] = "Arthas' Tears Collector" end
for _, i in ipairs({4160,4611,12020}) do I[i] = "Artisan Alchemist" end
for _, i in ipairs({3355,4258}) do I[i] = "Artisan Blacksmith" end
for _, i in ipairs({7802}) do I[i] = "Artisan Blacksmith of the Mithril Order" end
for _, i in ipairs({11072,11074}) do I[i] = "Artisan Enchanter" end
for _, i in ipairs({5174,11017}) do I[i] = "Artisan Engineer" end
for _, i in ipairs({3007,4212}) do I[i] = "Artisan Leatherworker" end
for _, i in ipairs({1346,4576}) do I[i] = "Artisan Tailor" end
for _, i in ipairs({8309}) do I[i] = "Assassin" end
for _, i in ipairs({6778}) do I[i] = "Assistant Innkeeper" end
for _, i in ipairs({8320}) do I[i] = "Away Team" end
for _, i in ipairs({3019,4232,5119,5509}) do I[i] = "Axe Merchant" end
for _, i in ipairs({10453}) do I[i] = "Axe Trainer" end
for _, i in ipairs({12045}) do I[i] = "Axecrafter" end
for _, i in ipairs({5851}) do I[i] = "Bael'dun Captain of the Guard" end
for _, i in ipairs({5847}) do I[i] = "Bael'dun Chief Engineer" end
for _, i in ipairs({5848}) do I[i] = "Bael'dun Morale Officer" end
for _, i in ipairs({4230}) do I[i] = "Bag Merchant" end
for _, i in ipairs({1321,3369,4590,5132,8364}) do I[i] = "Bag Vendor" end
for _, i in ipairs({3487}) do I[i] = "Bags & Sacks" end
for _, i in ipairs({1678}) do I[i] = "Bait and Tackle Supplier" end
for _, i in ipairs({15535}) do I[i] = "Baked Salmon Collector" end
for _, i in ipairs({3480,3518,3883,3884,3948,3959,4190,8307}) do I[i] = "Baker" end
for _, i in ipairs({10181}) do I[i] = "Banshee Queen" end
for _, i in ipairs({1328,5112,5140}) do I[i] = "Barmaid" end
for _, i in ipairs({274,465,1305,1311,2366,4782,4893,4963,5570}) do I[i] = "Bartender" end
for _, i in ipairs({3016}) do I[i] = "Basket Weaver" end
for _, i in ipairs({7314}) do I[i] = "Battle Master" end
for _, i in ipairs({2881,2938,4206}) do I[i] = "Bear Trainer" end
for _, i in ipairs({5871}) do I[i] = "Beverage Merchant" end
for _, i in ipairs({14042}) do I[i] = "Binder of the Moro'gai" end
for _, i in ipairs({5001}) do I[i] = "Bird Pet Trainer" end
for _, i in ipairs({2940}) do I[i] = "Bird Trainer" end
for _, i in ipairs({10899,15796}) do I[i] = "Blackhand Legion Armorsmith" end
for _, i in ipairs({15176}) do I[i] = "Blacksmith" end
for _, i in ipairs({2220,5033}) do I[i] = "Blacksmith Trainer" end
for _, i in ipairs({12044}) do I[i] = "Blacksmithing & Mining Supplies" end
for _, i in ipairs({3356,3477,4597}) do I[i] = "Blacksmithing Supplier" end
for _, i in ipairs({1690,2844,2847,2999,3343,4257,4259,5411,5512,6300,8161,8176,9179,14737}) do I[i] = "Blacksmithing Supplies" end
for _, i in ipairs({1324,3331,4171,4569,5120,5170}) do I[i] = "Blade Merchant" end
for _, i in ipairs({2843}) do I[i] = "Blade Trader" end
for _, i in ipairs({9718}) do I[i] = "Bloodaxe Champion" end
for _, i in ipairs({1061}) do I[i] = "Bloodscalp Chief" end
for _, i in ipairs({1062}) do I[i] = "Bloodscalp Clan Witchdoctor" end
for _, i in ipairs({11389}) do I[i] = "Bloodscalp Troll Ambassador" end
for _, i in ipairs({7683}) do I[i] = "Blue Moon Odds and Ends" end
for _, i in ipairs({5096}) do I[i] = "Blue Team Captain" end
for _, i in ipairs({5002}) do I[i] = "Boar Pet Trainer" end
for _, i in ipairs({2880,2939,3697}) do I[i] = "Boar Trainer" end
for _, i in ipairs({3151,3152,3895,3896,4497}) do I[i] = "Boat Operator" end
for _, i in ipairs({2662}) do I[i] = "Boat Vendor" end
for _, i in ipairs({2599}) do I[i] = "Bodyguard" end
for _, i in ipairs({4581}) do I[i] = "Book Dealer" end
for _, i in ipairs({14185,14186,14187,14188}) do I[i] = "Bounty Hunter" end
for _, i in ipairs({1298}) do I[i] = "Bow & Arrow Merchant" end
for _, i in ipairs({1297}) do I[i] = "Bow & Gun Merchant" end
for _, i in ipairs({3410,4173,4604,5122}) do I[i] = "Bow Merchant" end
for _, i in ipairs({10297}) do I[i] = "Bow Trainer" end
for _, i in ipairs({3015}) do I[i] = "Bowyer & Fletching Goods" end
for _, i in ipairs({3488}) do I[i] = "Bowyer & Gunsmith" end
for _, i in ipairs({8666}) do I[i] = "Boy with kittens" end
for _, i in ipairs({15172}) do I[i] = "Brann Bronzebeard's Pet Monkey" end
for _, i in ipairs({1670}) do I[i] = "Bread Merchant" end
for _, i in ipairs({3003,5109,5131}) do I[i] = "Bread Vendor" end
for _, i in ipairs({5034}) do I[i] = "Brewing Trainer" end
for _, i in ipairs({314}) do I[i] = "Bride of the Embalmer" end
for _, i in ipairs({15503}) do I[i] = "Brood of Alexstrasza" end
for _, i in ipairs({15502}) do I[i] = "Brood of Malygos" end
for _, i in ipairs({15504}) do I[i] = "Brood of Ysera" end
for _, i in ipairs({2365,2814,3089,3411,3489,3705,3881,3882,3933,3935,3960,4875,4879,4954,5870,8125,12039}) do I[i] = "Butcher" end
for _, i in ipairs({734}) do I[i] = "Camp Trader" end
for _, i in ipairs({5824}) do I[i] = "Captain of the Battleguard" end
for _, i in ipairs({12480,15182}) do I[i] = "Captain of the Guard" end
for _, i in ipairs({1481}) do I[i] = "Captain of the Maiden's Virtue" end
for _, i in ipairs({4224}) do I[i] = "Cartography Supplier" end
for _, i in ipairs({4157,4579,5035}) do I[i] = "Cartography Trainer" end
for _, i in ipairs({5003}) do I[i] = "Cat Pet Trainer" end
for _, i in ipairs({3699,4153}) do I[i] = "Cat Trainer" end
for _, i in ipairs({5521}) do I[i] = "Celmoridan's Pet" end
for _, i in ipairs({7907}) do I[i] = "Cenarion Lore Keeper" end
for _, i in ipairs({7735}) do I[i] = "Champion of Razelikh" end
for _, i in ipairs({11878}) do I[i] = "Champion of the Banshee Queen" end
for _, i in ipairs({10182}) do I[i] = "Champion of the Horde" end
for _, i in ipairs({4891}) do I[i] = "Chef" end
for _, i in ipairs({9056}) do I[i] = "Chief Architect" end
for _, i in ipairs({7853}) do I[i] = "Chief Engineer" end
for _, i in ipairs({1646}) do I[i] = "City Architect" end
for _, i in ipairs({2849}) do I[i] = "Cloth Armor and Accessories" end
for _, i in ipairs({959,1214,1299,3486,3554,3590,3611,3952,4185}) do I[i] = "Clothier" end
for _, i in ipairs({1339}) do I[i] = "Cobbler" end
for _, i in ipairs({8403}) do I[i] = "Cockroach Vendor" end
for _, i in ipairs({15864,15909}) do I[i] = "Coin of Ancestry Collector" end
for _, i in ipairs({1430,1677,2397,2664,3067,3966,4894,6286,8306}) do I[i] = "Cook" end
for _, i in ipairs({3027,3400,4223,4553,5160,5483,14738}) do I[i] = "Cooking Supplier" end
for _, i in ipairs({3085,3957,4265,12033,12038}) do I[i] = "Cooking Supplies" end
for _, i in ipairs({15383,15459}) do I[i] = "Copper Bar Collector" end
for _, i in ipairs({270,271}) do I[i] = "Council of Darkshire" end
for _, i in ipairs({5004}) do I[i] = "Crawler Pet Trainer" end
for _, i in ipairs({3623}) do I[i] = "Crawler Trainer" end
for _, i in ipairs({6367}) do I[i] = "Crazy Cat Lady" end
for _, i in ipairs({5005}) do I[i] = "Crocodile Pet Trainer" end
for _, i in ipairs({10446,10450,10454}) do I[i] = "Crossbow Trainer" end
for _, i in ipairs({9461}) do I[i] = "Cyrus's Minion" end
for _, i in ipairs({10292}) do I[i] = "Dagger Trainer" end
for _, i in ipairs({6124}) do I[i] = "Dark Iron Captain" end
for _, i in ipairs({14842,14843}) do I[i] = "Darkmoon Faire Barker" end
for _, i in ipairs({15303}) do I[i] = "Darkmoon Faire Cannoneer" end
for _, i in ipairs({14847}) do I[i] = "Darkmoon Faire Cards & Exotic Goods" end
for _, i in ipairs({14844}) do I[i] = "Darkmoon Faire Drink Vendor" end
for _, i in ipairs({14846}) do I[i] = "Darkmoon Faire Exotic Goods" end
for _, i in ipairs({14845}) do I[i] = "Darkmoon Faire Food Vendor" end
for _, i in ipairs({10445}) do I[i] = "Darkmoon Faire Information" end
for _, i in ipairs({14828}) do I[i] = "Darkmoon Faire Ticket Redemption" end
for _, i in ipairs({15761}) do I[i] = "Darkspear Commendations" end
for _, i in ipairs({2530}) do I[i] = "Darkspear Hostage" end
for _, i in ipairs({15762}) do I[i] = "Darnassus Commendations" end
for _, i in ipairs({11800}) do I[i] = "Darnassus Flight Master" end
for _, i in ipairs({16891}) do I[i] = "Dawn Whisperer" end
for _, i in ipairs({4428}) do I[i] = "Death's Head Captain" end
for _, i in ipairs({4424}) do I[i] = "Death's Head Prophet" end
for _, i in ipairs({1950,1951}) do I[i] = "Deathstalker" end
for _, i in ipairs({639}) do I[i] = "Defias Kingpin" end
for _, i in ipairs({15126}) do I[i] = "Defilers Supply Officer" end
for _, i in ipairs({12807}) do I[i] = "Demon Master" end
for _, i in ipairs({269}) do I[i] = "Deputy Mayor of Darkshire" end
for _, i in ipairs({14885,15123}) do I[i] = "Designer Extraordinaire" end
for _, i in ipairs({5767,5768}) do I[i] = "Disciple of Naralex" end
for _, i in ipairs({9047}) do I[i] = "Ditch Digger" end
for _, i in ipairs({4244}) do I[i] = "Dorion's Pet" end
for _, i in ipairs({11980}) do I[i] = "Dragonmaw Chieftain" end
for _, i in ipairs({2090}) do I[i] = "Dragonmaw Warlord" end
for _, i in ipairs({7525}) do I[i] = "Dragonscale Leatherworking Trainer" end
for _, i in ipairs({4192,6495}) do I[i] = "Drink Vendor" end
for _, i in ipairs({6986,6987}) do I[i] = "Droffers and Son Salvage" end
for _, i in ipairs({11218}) do I[i] = "Druid of the Claw" end
for _, i in ipairs({3672,5791}) do I[i] = "Druid of the Fang" end
for _, i in ipairs({6090}) do I[i] = "Drunk" end
for _, i in ipairs({10610,10611}) do I[i] = "Dwarven Mortar Team" end
for _, i in ipairs({3177}) do I[i] = "Dwarven Weaponsmith" end
for _, i in ipairs({4046}) do I[i] = "Elder Crone" end
for _, i in ipairs({4047}) do I[i] = "Elder Far Seer" end
for _, i in ipairs({7526}) do I[i] = "Elemental Leatherworking Trainer" end
for _, i in ipairs({15419}) do I[i] = "Enchanting Supplier" end
for _, i in ipairs({1318,3012,3346,4228,4617,5158,5757,5758}) do I[i] = "Enchanting Supplies" end
for _, i in ipairs({14743}) do I[i] = "Engineer" end
for _, i in ipairs({1448}) do I[i] = "Engineering & General Goods Supplier" end
for _, i in ipairs({3495}) do I[i] = "Engineering Goods" end
for _, i in ipairs({4587,5519,8678}) do I[i] = "Engineering Supplier" end
for _, i in ipairs({1694,2682,2683,2684,2685,2687,2688,3413,5175,6730,8679,9676,11185}) do I[i] = "Engineering Supplies" end
for _, i in ipairs({3133}) do I[i] = "Engineering and Mining Supplies" end
for _, i in ipairs({2050}) do I[i] = "Ex-Chef" end
for _, i in ipairs({5849}) do I[i] = "Excavation Specialist" end
for _, i in ipairs({10466}) do I[i] = "Exotic Item Vendor" end
for _, i in ipairs({16015}) do I[i] = "Exotic Reagent Merchant" end
for _, i in ipairs({2391,2837,3009,3347,3964,4609,4900,5177,5499,11042}) do I[i] = "Expert Alchemist" end
for _, i in ipairs({1383,2998,3136,3478,4596,5511,10276}) do I[i] = "Expert Blacksmith" end
for _, i in ipairs({1317,3011,3345,4213,4616,5157,7949}) do I[i] = "Expert Enchanter" end
for _, i in ipairs({1676,3412,5518,11029,11031}) do I[i] = "Expert Engineer" end
for _, i in ipairs({8153}) do I[i] = "Expert Leathercrafter" end
for _, i in ipairs({1385,3365,3703,3967,4588,5127,5564,11081,11084}) do I[i] = "Expert Leatherworker" end
for _, i in ipairs({2627,3004,3363,3704,4159,5153,5567,11049}) do I[i] = "Expert Tailor" end
for _, i in ipairs({3669,3670,3671,3673}) do I[i] = "Fanglord" end
for _, i in ipairs({5876,5877}) do I[i] = "Far Watch Sparrer" end
for _, i in ipairs({15165}) do I[i] = "Fashion Designer" end
for _, i in ipairs({16979,16985,16986}) do I[i] = "Festival Supplies" end
for _, i in ipairs({15508}) do I[i] = "Firebloom Collector" end
for _, i in ipairs({9596}) do I[i] = "Firebrand Legion Champion" end
for _, i in ipairs({2838}) do I[i] = "Fireworks Merchant" end
for _, i in ipairs({1304,5569}) do I[i] = "Fireworks Vendor" end
for _, i in ipairs({3540}) do I[i] = "Fish Merchant" end
for _, i in ipairs({12962}) do I[i] = "Fish Merchant & Supplies" end
for _, i in ipairs({4200,4221,7943}) do I[i] = "Fish Vendor" end
for _, i in ipairs({1651,1683,1700,2367,2626,3178,3497,3572,3607,4305,4307,5690,5748,5938,5941,7946,8137,12032,12961}) do I[i] = "Fisherman" end
for _, i in ipairs({8508}) do I[i] = "Fisherman Supplies" end
for _, i in ipairs({15116,15119}) do I[i] = "Fishing Promoter" end
for _, i in ipairs({3029,4222,4574,5162,5494}) do I[i] = "Fishing Supplier" end
for _, i in ipairs({1684,3333,3550,5940,5942,7945,10118,12031}) do I[i] = "Fishing Supplies" end
for _, i in ipairs({14740}) do I[i] = "Fishing Trainer & Supplies" end
for _, i in ipairs({15077}) do I[i] = "Fishmaster" end
for _, i in ipairs({15078}) do I[i] = "Fishmaster Apprentice" end
for _, i in ipairs({383}) do I[i] = "Fishmonger" end
for _, i in ipairs({10294}) do I[i] = "Fist Weapons Trainer" end
for _, i in ipairs({789,1462}) do I[i] = "Fletcher" end
for _, i in ipairs({1455}) do I[i] = "Fletching Supplier" end
for _, i in ipairs({1302,1485}) do I[i] = "Florist" end
for _, i in ipairs({1237,12019,12026}) do I[i] = "Food & Drink Merchant" end
for _, i in ipairs({1235}) do I[i] = "Food Merchant" end
for _, i in ipairs({2832,4255,10367,12785,12794}) do I[i] = "Food and Drink" end
for _, i in ipairs({5620}) do I[i] = "Food and Drinks" end
for _, i in ipairs({4149}) do I[i] = "Foraging Trainer" end
for _, i in ipairs({1669}) do I[i] = "Free Wheeling Merchant" end
for _, i in ipairs({3536}) do I[i] = "Freewheeling Tradeswoman" end
for _, i in ipairs({11947}) do I[i] = "Frostwolf Captain" end
for _, i in ipairs({11946}) do I[i] = "Frostwolf General" end
for _, i in ipairs({13218,13219}) do I[i] = "Frostwolf Supply Officer" end
for _, i in ipairs({894,1671}) do I[i] = "Fruit Seller" end
for _, i in ipairs({3017,3342,7978}) do I[i] = "Fruit Vendor" end
for _, i in ipairs({4571}) do I[i] = "Fungus Vendor" end
for _, i in ipairs({7407,7408,7724}) do I[i] = "Gadgetzan Water Co." end
for _, i in ipairs({1250}) do I[i] = "General & Trade Supplies" end
for _, i in ipairs({3313}) do I[i] = "General Goods Merchant" end
for _, i in ipairs({151,152,791,829,1149,1452,1682,1685,1691,2115,2134,2140,3481,3498,3587,3608,4084,7942}) do I[i] = "General Supplies" end
for _, i in ipairs({3367,5817}) do I[i] = "General Trade Goods Merchant" end
for _, i in ipairs({4775,8934,15179}) do I[i] = "General Trade Goods Vendor" end
for _, i in ipairs({4229,4561,6301}) do I[i] = "General Trade Supplier" end
for _, i in ipairs({3936}) do I[i] = "General of the Sentinel Army" end
for _, i in ipairs({5697}) do I[i] = "Gerard's Mindslave" end
for _, i in ipairs({412}) do I[i] = "Gift from the Embalmer" end
for _, i in ipairs({13082}) do I[i] = "Giver of the Beatings" end
for _, i in ipairs({8676}) do I[i] = "Gnome Engineering Trainer" end
for _, i in ipairs({4449}) do I[i] = "Gnome Ticket Redeemer" end
for _, i in ipairs({15763}) do I[i] = "Gnomeregan Commendations" end
for _, i in ipairs({8677}) do I[i] = "Goblin Engineering Trainer" end
for _, i in ipairs({4450}) do I[i] = "Goblin Ticket Redeemer" end
for _, i in ipairs({5008}) do I[i] = "Gorilla Pet Trainer" end
for _, i in ipairs({6707}) do I[i] = "Grand Master Rogue" end
for _, i in ipairs({6767}) do I[i] = "Grand Master of the Assassin's League" end
for _, i in ipairs({5796}) do I[i] = "Grash Thunderbrew's Pet" end
for _, i in ipairs({67}) do I[i] = "Grocer" end
for _, i in ipairs({8580}) do I[i] = "Guardian of the Idol" end
for _, i in ipairs({4976,5050,5051,5052}) do I[i] = "Guild Tabard Designer" end
for _, i in ipairs({5049,5061}) do I[i] = "Guild Tabard Vendor" end
for _, i in ipairs({3053,4603,5123}) do I[i] = "Gun Merchant" end
for _, i in ipairs({5104}) do I[i] = "Gun Trainer" end
for _, i in ipairs({3018}) do I[i] = "Guns Merchant" end
for _, i in ipairs({5510}) do I[i] = "Guns Vendor" end
for _, i in ipairs({3322}) do I[i] = "Guns and Ammo Merchant" end
for _, i in ipairs({9548,9551}) do I[i] = "Gunsmith & Bowyer" end
for _, i in ipairs({15801}) do I[i] = "HOLDER OF THE GONG" end
for _, i in ipairs({15353,15354}) do I[i] = "Hallow's End Treats" end
for _, i in ipairs({14875,15080}) do I[i] = "Hand of Rastakhan" end
for _, i in ipairs({16387}) do I[i] = "Hand of Sargeras" end
for _, i in ipairs({1310}) do I[i] = "Hatter" end
for _, i in ipairs({14833}) do I[i] = "He Who Never Forgets!" end
for _, i in ipairs({1141}) do I[i] = "Head Chef" end
for _, i in ipairs({1323,3095,4559,4560,5106,5107,5126,5812,5819,6028,11182}) do I[i] = "Heavy Armor Merchant" end
for _, i in ipairs({15515}) do I[i] = "Heavy Leather Collector" end
for _, i in ipairs({4899}) do I[i] = "Herbalism & Alchemy Supplies" end
for _, i in ipairs({1303,3014,3405,4216,4615,5138,5503}) do I[i] = "Herbalism Supplier" end
for _, i in ipairs({1473,2390,3185,3604,3965,4898,12025}) do I[i] = "Herbalist" end
for _, i in ipairs({3057}) do I[i] = "High Chieftain" end
for _, i in ipairs({466}) do I[i] = "High Commander of Stormwind Defense" end
for _, i in ipairs({5994}) do I[i] = "High Priest" end
for _, i in ipairs({15215}) do I[i] = "High Priestess of C'Thun" end
for _, i in ipairs({7999,15633}) do I[i] = "High Priestess of Elune" end
for _, i in ipairs({5635}) do I[i] = "High Thane" end
for _, i in ipairs({1842}) do I[i] = "Highlord of the Scarlet Crusade" end
for _, i in ipairs({268}) do I[i] = "Historian of Darkshire" end
for _, i in ipairs({15288}) do I[i] = "Hive'Ashi Overlord" end
for _, i in ipairs({15286}) do I[i] = "Hive'Regal Overlord" end
for _, i in ipairs({15290}) do I[i] = "Hive'Zora Overlord" end
for _, i in ipairs({8116,8117,8118,8121,8122}) do I[i] = "Holiday Fireworks Vendor" end
for _, i in ipairs({15539}) do I[i] = "Horde Ambassador" end
for _, i in ipairs({14726,14727,14728,14729}) do I[i] = "Horde Cloth Quartermaster" end
for _, i in ipairs({2477,2478,7170}) do I[i] = "Horde Runner" end
for _, i in ipairs({384,1460,2357,4885}) do I[i] = "Horse Breeder" end
for _, i in ipairs({5009}) do I[i] = "Horse Pet Trainer" end
for _, i in ipairs({4732}) do I[i] = "Horse Riding Instructor" end
for _, i in ipairs({5026}) do I[i] = "Horse Riding Trainer" end
for _, i in ipairs({7748}) do I[i] = "Horse Vendor" end
for _, i in ipairs({11022,11023}) do I[i] = "House of Barov" end
for _, i in ipairs({1439,2285}) do I[i] = "House of Nobles" end
for _, i in ipairs({5000}) do I[i] = "Hunter Beast Trainer" end
for _, i in ipairs({6496}) do I[i] = "Ice Cream Vendor" end
for _, i in ipairs({6806}) do I[i] = "Innkeeper Assistant" end
for _, i in ipairs({15431}) do I[i] = "Iron Bar Collector" end
for _, i in ipairs({15440}) do I[i] = "Ironforge Brigade Captain" end
for _, i in ipairs({15764}) do I[i] = "Ironforge Commendations" end
for _, i in ipairs({2092}) do I[i] = "Ironforge Siege Brigade" end
for _, i in ipairs({5788,5789,5790}) do I[i] = "Ironforge Surveyor" end
for _, i in ipairs({4243}) do I[i] = "Jeen'ra's Pet" end
for _, i in ipairs({11024}) do I[i] = "Jessir's Pet" end
for _, i in ipairs({1215,1246,1470,2132,3184,3603,5500,11041,11046,11047}) do I[i] = "Journeyman Alchemist" end
for _, i in ipairs({11044}) do I[i] = "Journeyman Alchemist Trainer" end
for _, i in ipairs({514,957,1241,3174,3557,4605,6299,10266,10277,10278}) do I[i] = "Journeyman Blacksmith" end
for _, i in ipairs({3606,5695,11065,11066,11067,11068,11070,11071}) do I[i] = "Journeyman Enchanter" end
for _, i in ipairs({1702,2857,3290,3494,4586,10993,11025,11026,11028,11037}) do I[i] = "Journeyman Engineer" end
for _, i in ipairs({223,1466,1632,3008,3069,3549,3605,5784,5811,11083,11096}) do I[i] = "Journeyman Leatherworker" end
for _, i in ipairs({1103,1300,1703,2855,3484,3523,4193,11048,11050,11051}) do I[i] = "Journeyman Tailor" end
for _, i in ipairs({11181}) do I[i] = "Kaerbrus' Pet" end
for _, i in ipairs({9020,9077,9078,9079,9080,9081,9082,9083,9084,9085,9086,9538,9539}) do I[i] = "Kargath Expeditionary Force" end
for _, i in ipairs({7734}) do I[i] = "Keeper of Souls" end
for _, i in ipairs({14486}) do I[i] = "Kel'Thuzad's Minion" end
for _, i in ipairs({3362}) do I[i] = "Kennel Master" end
for _, i in ipairs({7937}) do I[i] = "King of Gnomes" end
for _, i in ipairs({1747,11699}) do I[i] = "King of Stormwind" end
for _, i in ipairs({3938}) do I[i] = "Kira's Guard" end
for _, i in ipairs({3685}) do I[i] = "Kodo Mounts" end
for _, i in ipairs({3690}) do I[i] = "Kodo Riding Instructor" end
for _, i in ipairs({4246}) do I[i] = "Kysandia's Pet" end
for _, i in ipairs({7324}) do I[i] = "Landscape Architect" end
for _, i in ipairs({332}) do I[i] = "Leader of SI:7" end
for _, i in ipairs({264}) do I[i] = "Leader of The Night Watch" end
for _, i in ipairs({15127}) do I[i] = "League of Arathor Supply Officer" end
for _, i in ipairs({15533}) do I[i] = "Lean Wolf Steak Collector" end
for _, i in ipairs({3483}) do I[i] = "Leather & Mail Armor Merchant" end
for _, i in ipairs({4186}) do I[i] = "Leather Armor & Leatherworking Supplies" end
for _, i in ipairs({3005}) do I[i] = "Leatherworking & Tailoring Supplies" end
for _, i in ipairs({2697,2698,2699,2816,2819,2846,3366,3958,4225,4589,5128,5565,6731,7852,7854,8160,12942,12943,12956}) do I[i] = "Leatherworking Supplies" end
for _, i in ipairs({951,1316,1440,2504}) do I[i] = "Librarian" end
for _, i in ipairs({1407}) do I[i] = "Light Armor & Weapons Merchant" end
for _, i in ipairs({1314,3317,4558,5105,5108,5129,5813,8159,11183,12023}) do I[i] = "Light Armor Merchant" end
for _, i in ipairs({15446}) do I[i] = "Light Leather Collector" end
for _, i in ipairs({15451}) do I[i] = "Linen Bandage Collector" end
for _, i in ipairs({3659}) do I[i] = "Lizzarik's Bodyguard" end
for _, i in ipairs({5027}) do I[i] = "Lockpicking Trainer" end
for _, i in ipairs({14224}) do I[i] = "Long Distance Recovery Unit" end
for _, i in ipairs({8756,8757,8758}) do I[i] = "Loramus's Guardian" end
for _, i in ipairs({10162}) do I[i] = "Lord of Blackrock" end
for _, i in ipairs({2784}) do I[i] = "Lord of Ironforge" end
for _, i in ipairs({11326}) do I[i] = "Lord of Terror" end
for _, i in ipairs({6768}) do I[i] = "Lord of the Assassin's League" end
for _, i in ipairs({4878}) do I[i] = "Lorekeeper" end
for _, i in ipairs({1650}) do I[i] = "Lumberjack" end
for _, i in ipairs({642,643}) do I[i] = "Lumbermaster" end
for _, i in ipairs({1288,3020,4233}) do I[i] = "Mace & Staff Merchant" end
for _, i in ipairs({3360}) do I[i] = "Mace & Staves Vendor" end
for _, i in ipairs({10452}) do I[i] = "Mace Trainer" end
for _, i in ipairs({222,2840}) do I[i] = "Macecrafter" end
for _, i in ipairs({5121}) do I[i] = "Maces & Staves" end
for _, i in ipairs({11833}) do I[i] = "Magatha's Servant" end
for _, i in ipairs({313}) do I[i] = "Mage of Tower Azora" end
for _, i in ipairs({15529}) do I[i] = "Mageweave Bandage Collector" end
for _, i in ipairs({2885}) do I[i] = "Magic Skills Trainer" end
for _, i in ipairs({980}) do I[i] = "Mail & Plate Merchant" end
for _, i in ipairs({16095}) do I[i] = "Malgen Longspear's Pet" end
for _, i in ipairs({1386,7948}) do I[i] = "Master Alchemist" end
for _, i in ipairs({2836}) do I[i] = "Master Blacksmith" end
for _, i in ipairs({7866,7867}) do I[i] = "Master Dragonscale Leatherworker" end
for _, i in ipairs({7868,7869}) do I[i] = "Master Elemental Leatherworker" end
for _, i in ipairs({11073}) do I[i] = "Master Enchanter" end
for _, i in ipairs({8736}) do I[i] = "Master Engineer" end
for _, i in ipairs({7406,7944}) do I[i] = "Master Gnome Engineer" end
for _, i in ipairs({8126,8738}) do I[i] = "Master Goblin Engineer" end
for _, i in ipairs({11098}) do I[i] = "Master Leatherworker" end
for _, i in ipairs({11097}) do I[i] = "Master Leatherworking Trainer" end
for _, i in ipairs({331}) do I[i] = "Master Mage" end
for _, i in ipairs({387,388,389}) do I[i] = "Master Paladin" end
for _, i in ipairs({4578,9584}) do I[i] = "Master Shadoweave Tailor" end
for _, i in ipairs({2399,11052}) do I[i] = "Master Tailor" end
for _, i in ipairs({7871}) do I[i] = "Master Tribal Leatherworker" end
for _, i in ipairs({1645}) do I[i] = "Master Weaponsmith" end
for _, i in ipairs({482}) do I[i] = "Master of Cheese" end
for _, i in ipairs({340}) do I[i] = "Master of Cooking Recipes" end
for _, i in ipairs({263}) do I[i] = "Mayor of Darkshire" end
for _, i in ipairs({3025,3312,3368,4169,5124}) do I[i] = "Meat Vendor" end
for _, i in ipairs({7955}) do I[i] = "Mechanostrider Merchant" end
for _, i in ipairs({7954}) do I[i] = "Mechanostrider Pilot" end
for _, i in ipairs({7746}) do I[i] = "Mechastrider Riding Trainer" end
for _, i in ipairs({15448}) do I[i] = "Medium Leather Collector" end
for _, i in ipairs({3537}) do I[i] = "Merchant Supreme" end
for _, i in ipairs({277}) do I[i] = "Merlot Connoisseur" end
for _, i in ipairs({167}) do I[i] = "Metalsmith" end
for _, i in ipairs({3175,3176,3555,8128,12035}) do I[i] = "Miner" end
for _, i in ipairs({1567}) do I[i] = "Miner <Temp>" end
for _, i in ipairs({1254,1256}) do I[i] = "Miners' League" end
for _, i in ipairs({3002,3358,4256,4599,5514,6298}) do I[i] = "Mining Supplier" end
for _, i in ipairs({372,11186}) do I[i] = "Mining Supplies" end
for _, i in ipairs({790}) do I[i] = "Mining and Smithing Supplies" end
for _, i in ipairs({16099}) do I[i] = "Minion of Alex" end
for _, i in ipairs({483}) do I[i] = "Mistress of Cheese" end
for _, i in ipairs({15469}) do I[i] = "Mithril Bar Collector" end
for _, i in ipairs({2051,2154}) do I[i] = "Model and Texture" end
for _, i in ipairs({2883}) do I[i] = "Monster Slayer Trainer" end
for _, i in ipairs({955}) do I[i] = "Morale Officer" end
for _, i in ipairs({12796}) do I[i] = "Mount Quartermaster" end
for _, i in ipairs({7747,12783}) do I[i] = "Mount Vendor" end
for _, i in ipairs({3547}) do I[i] = "Mushroom Farmer" end
for _, i in ipairs({5886}) do I[i] = "Mushroom Merchant" end
for _, i in ipairs({3138,3544}) do I[i] = "Mushroom Seller" end
for _, i in ipairs({3329,4554}) do I[i] = "Mushroom Vendor" end
for _, i in ipairs({14470}) do I[i] = "Niby's Minion" end
for _, i in ipairs({4164}) do I[i] = "Night Elf Armorer" end
for _, i in ipairs({4753}) do I[i] = "Nightsaber Riding Instructor" end
for _, i in ipairs({8441}) do I[i] = "Nilith's Guardian" end
for _, i in ipairs({4045}) do I[i] = "No Clothes NPC" end
for _, i in ipairs({7316}) do I[i] = "Novice Priestess" end
for _, i in ipairs({12781,12793}) do I[i] = "Officer Accessories Quartermaster" end
for _, i in ipairs({15765}) do I[i] = "Orgrimmar Commendations" end
for _, i in ipairs({15612}) do I[i] = "Orgrimmar Legion Captain" end
for _, i in ipairs({14497}) do I[i] = "Orphanage Matron" end
for _, i in ipairs({929}) do I[i] = "Overfiend" end
for _, i in ipairs({8127}) do I[i] = "Overseer of Sul" end
for _, i in ipairs({8665}) do I[i] = "Owl Trainer" end
for _, i in ipairs({16019,16023}) do I[i] = "Panda Cub Caretaker" end
for _, i in ipairs({15477}) do I[i] = "Peacebloom Collector" end
for _, i in ipairs({543,2878,2879,3306,3545,3620,3622,3624,3688,3698,4320,10086,10088,10089,10090}) do I[i] = "Pet Trainer" end
for _, i in ipairs({2326,2329}) do I[i] = "Physician" end
for _, i in ipairs({9099}) do I[i] = "Pie Vendor" end
for _, i in ipairs({2663}) do I[i] = "Pirate Supplies" end
for _, i in ipairs({1857,1858}) do I[i] = "Pissed Vendor" end
for _, i in ipairs({1326,3090,3135}) do I[i] = "Poison Supplier" end
for _, i in ipairs({3334,3558,3559,3561,4585,6779}) do I[i] = "Poison Vendor" end
for _, i in ipairs({3542}) do I[i] = "Poisons & Reagents" end
for _, i in ipairs({10444,10449}) do I[i] = "Polearm Trainer" end
for _, i in ipairs({2485,2489,2492,4165,5957,5958}) do I[i] = "Portal Trainer" end
for _, i in ipairs({5018}) do I[i] = "Portal: Darnassus Trainer" end
for _, i in ipairs({5019}) do I[i] = "Portal: Ironforge Trainer" end
for _, i in ipairs({5020}) do I[i] = "Portal: Orgrimmar Trainer" end
for _, i in ipairs({5021}) do I[i] = "Portal: Stormwind Trainer" end
for _, i in ipairs({5022}) do I[i] = "Portal: Thunder Bluff Trainer" end
for _, i in ipairs({5023}) do I[i] = "Portal: Undercity Trainer" end
for _, i in ipairs({8305}) do I[i] = "Potions & Herbs" end
for _, i in ipairs({13476}) do I[i] = "Potions, Scrolls and Reagents" end
for _, i in ipairs({12383}) do I[i] = "Prairie Dog" end
for _, i in ipairs({8401}) do I[i] = "Prairie Dog Vendor" end
for _, i in ipairs({8929}) do I[i] = "Princess of Ironforge" end
for _, i in ipairs({3538}) do I[i] = "Protector" end
for _, i in ipairs({15437,15512}) do I[i] = "Purple Lotus Collector" end
for _, i in ipairs({2068}) do I[i] = "Pyrewood Council Leader" end
for _, i in ipairs({491}) do I[i] = "Quartermaster" end
for _, i in ipairs({73}) do I[i] = "Questgiver" end
for _, i in ipairs({4620,4707}) do I[i] = "Race Announcer" end
for _, i in ipairs({4507}) do I[i] = "Race Starter Girl" end
for _, i in ipairs({4445,4446}) do I[i] = "Race Vendor" end
for _, i in ipairs({3915}) do I[i] = "Raene's Pet" end
for _, i in ipairs({11517}) do I[i] = "Ragefire Chieftain" end
for _, i in ipairs({15455}) do I[i] = "Rainbow Fin Albacore Collector" end
for _, i in ipairs({1261}) do I[i] = "Ram Breeder" end
for _, i in ipairs({4772}) do I[i] = "Ram Riding Instructor" end
for _, i in ipairs({5028}) do I[i] = "Ram Riding Trainer" end
for _, i in ipairs({2886}) do I[i] = "Ranged Skills Trainer" end
for _, i in ipairs({7952}) do I[i] = "Raptor Handler" end
for _, i in ipairs({5011}) do I[i] = "Raptor Pet Trainer" end
for _, i in ipairs({7745,7953}) do I[i] = "Raptor Riding Trainer" end
for _, i in ipairs({4621}) do I[i] = "Raptor Trainer" end
for _, i in ipairs({3134}) do I[i] = "Rare Goods" end
for _, i in ipairs({12997}) do I[i] = "Rat Extermination Specialist" end
for _, i in ipairs({11701,11702}) do I[i] = "Ravasaur Trainers" end
for _, i in ipairs({5859}) do I[i] = "Razormane Champion" end
for _, i in ipairs({4575}) do I[i] = "Reagent Supplier" end
for _, i in ipairs({3970}) do I[i] = "Reagent Supplies" end
for _, i in ipairs({5139,10364}) do I[i] = "Reagents & Poisons" end
for _, i in ipairs({3323,3335,3351}) do I[i] = "Reagents Vendor" end
for _, i in ipairs({3490}) do I[i] = "Reagents and Herbs" end
for _, i in ipairs({5062}) do I[i] = "Reagents/Totems Vendor" end
for _, i in ipairs({1421}) do I[i] = "Rebel Soldier" end
for _, i in ipairs({5095}) do I[i] = "Red Team Captain" end
for _, i in ipairs({10339}) do I[i] = "Rend Blackhand's Mount" end
for _, i in ipairs({10619}) do I[i] = "Rivern's Guardian" end
for _, i in ipairs({15456}) do I[i] = "Roast Raptor Collector" end
for _, i in ipairs({1309,5156}) do I[i] = "Robe Merchant" end
for _, i in ipairs({1350,4172,4580}) do I[i] = "Robe Vendor" end
for _, i in ipairs({2790}) do I[i] = "Royal Stonecutters Union" end
for _, i in ipairs({15525}) do I[i] = "Rugged Leather Collector" end
for _, i in ipairs({4968}) do I[i] = "Ruler of Theramore" end
for _, i in ipairs({15453,15532}) do I[i] = "Runecloth Bandage Collector" end
for _, i in ipairs({6946}) do I[i] = "SI:7 Operative" end
for _, i in ipairs({4730}) do I[i] = "Saber Handler" end
for _, i in ipairs({11387}) do I[i] = "Sandfury Troll Ambassador" end
for _, i in ipairs({1182,12336}) do I[i] = "Scarlet Crusade Emissary" end
for _, i in ipairs({3513}) do I[i] = "School Mistress" end
for _, i in ipairs({5012}) do I[i] = "Scorpid Pet Trainer" end
for _, i in ipairs({2805}) do I[i] = "Scrolls & Potions" end
for _, i in ipairs({5662,6395}) do I[i] = "Sergeant" end
for _, i in ipairs({14910}) do I[i] = "Servitor of Rastakhan" end
for _, i in ipairs({15070}) do I[i] = "Servitor of Zanza" end
for _, i in ipairs({2598}) do I[i] = "Shadow Council Warlock" end
for _, i in ipairs({1325,1457,5169}) do I[i] = "Shady Dealer" end
for _, i in ipairs({2622}) do I[i] = "Shady Goods" end
for _, i in ipairs({793}) do I[i] = "Shield Crafter" end
for _, i in ipairs({1319,4179,4240}) do I[i] = "Shield Merchant" end
for _, i in ipairs({9558,9559}) do I[i] = "Shipmaster" end
for _, i in ipairs({15452}) do I[i] = "Silk Bandage Collector" end
for _, i in ipairs({14753}) do I[i] = "Silverwing Supply Officer" end
for _, i in ipairs({14528,14538}) do I[i] = "Simone's Pet" end
for _, i in ipairs({10582}) do I[i] = "Sire" end
for _, i in ipairs({6287,6288,6289,6290,6306,6387}) do I[i] = "Skinner" end
for _, i in ipairs({1059}) do I[i] = "Skullsplitter Chief" end
for _, i in ipairs({1060}) do I[i] = "Skullsplitter Clan Witchdoctor" end
for _, i in ipairs({11390}) do I[i] = "Skullsplitter Troll Ambassador" end
for _, i in ipairs({8404}) do I[i] = "Snake Vendor" end
for _, i in ipairs({2679}) do I[i] = "Special Goods Dealer" end
for _, i in ipairs({11146}) do I[i] = "Special Weapon Crafter" end
for _, i in ipairs({5783}) do I[i] = "Specialist Leatherworking Supplies" end
for _, i in ipairs({3096}) do I[i] = "Specialist Tailoring Supplies" end
for _, i in ipairs({4184}) do I[i] = "Speciality Dress Maker" end
for _, i in ipairs({6777}) do I[i] = "Speciality Engineer" end
for _, i in ipairs({3180}) do I[i] = "Speciality Goods" end
for _, i in ipairs({8681}) do I[i] = "Speciality Tailoring Supplies" end
for _, i in ipairs({17209}) do I[i] = "Spectral Gryphon Master" end
for _, i in ipairs({5013}) do I[i] = "Spider Pet Trainer" end
for _, i in ipairs({2872,4882}) do I[i] = "Spider Trainer" end
for _, i in ipairs({15457,15534}) do I[i] = "Spotted Yellowtail Collector" end
for _, i in ipairs({2382}) do I[i] = "Stablehand" end
for _, i in ipairs({1348}) do I[i] = "Staff & Mace Merchant" end
for _, i in ipairs({3022,3330,3349,4234,4570}) do I[i] = "Staff Merchant" end
for _, i in ipairs({1315}) do I[i] = "Staves Merchant" end
for _, i in ipairs({10295,10368,10451}) do I[i] = "Staves Trainer" end
for _, i in ipairs({1398}) do I[i] = "Stonesplinter Chieftain" end
for _, i in ipairs({1399}) do I[i] = "Stonesplinter Tribal Shaman" end
for _, i in ipairs({4854}) do I[i] = "Stonevault Chieftain" end
for _, i in ipairs({11949}) do I[i] = "Stormpike Captain" end
for _, i in ipairs({11948}) do I[i] = "Stormpike General" end
for _, i in ipairs({13843}) do I[i] = "Stormpike Guard Recruitment Officer" end
for _, i in ipairs({13216,13217}) do I[i] = "Stormpike Supply Officer" end
for _, i in ipairs({10782}) do I[i] = "Stormwind Census" end
for _, i in ipairs({2439}) do I[i] = "Stormwind City Guard" end
for _, i in ipairs({15766}) do I[i] = "Stormwind Commendations" end
for _, i in ipairs({12481}) do I[i] = "Stormwind Recruiter" end
for _, i in ipairs({15434}) do I[i] = "Stranglekelp Collector" end
for _, i in ipairs({5522}) do I[i] = "Strumner's Pet" end
for _, i in ipairs({3683}) do I[i] = "Stylish Clothier" end
for _, i in ipairs({8129}) do I[i] = "Superior Armor Crafter" end
for _, i in ipairs({1381,2845}) do I[i] = "Superior Armorer" end
for _, i in ipairs({3543}) do I[i] = "Superior Armorsmith" end
for _, i in ipairs({2483}) do I[i] = "Superior Axecrafter" end
for _, i in ipairs({2839}) do I[i] = "Superior Bowyer" end
for _, i in ipairs({2818}) do I[i] = "Superior Butcher" end
for _, i in ipairs({1382}) do I[i] = "Superior Cook" end
for _, i in ipairs({2834,2842}) do I[i] = "Superior Fisherman" end
for _, i in ipairs({908,2856}) do I[i] = "Superior Herbalist" end
for _, i in ipairs({11874}) do I[i] = "Superior Leatherworker" end
for _, i in ipairs({1471,8878}) do I[i] = "Superior Macecrafter" end
for _, i in ipairs({1384}) do I[i] = "Superior Miner" end
for _, i in ipairs({2810}) do I[i] = "Superior Tradesman" end
for _, i in ipairs({1146,2482}) do I[i] = "Superior Weaponsmith" end
for _, i in ipairs({5029}) do I[i] = "Survival Trainer" end
for _, i in ipairs({14480,14481}) do I[i] = "Sweet Treats" end
for _, i in ipairs({10443,10448}) do I[i] = "Sword Trainer" end
for _, i in ipairs({3021}) do I[i] = "Sword and Dagger Merchant" end
for _, i in ipairs({2597}) do I[i] = "Syndicate Leader" end
for _, i in ipairs({5047}) do I[i] = "Tabard Designer" end
for _, i in ipairs({2383}) do I[i] = "Tackle and Bait" end
for _, i in ipairs({2221}) do I[i] = "Tailor Trainer" end
for _, i in ipairs({5944}) do I[i] = "Tailoring & Leatherworking Supplies" end
for _, i in ipairs({1347,1474,1672,2394,2668,2669,2670,2672,3091,3364,3485,4168,4189,4577,5154,6567,6568,6574,6576,7940}) do I[i] = "Tailoring Supplies" end
for _, i in ipairs({1454}) do I[i] = "Tailoring Supplies & Specialty Goods" end
for _, i in ipairs({4247}) do I[i] = "Talar's Pet" end
for _, i in ipairs({9576,9578,9579,9580,9581,9582}) do I[i] = "Talent Master" end
for _, i in ipairs({5015}) do I[i] = "Tallstrider Pet Trainer" end
for _, i in ipairs({5507}) do I[i] = "Tallstrider Trainer" end
for _, i in ipairs({1327}) do I[i] = "Tavernkeeper" end
for _, i in ipairs({6248}) do I[i] = "The Announcer" end
for _, i in ipairs({659}) do I[i] = "The Black Chicken of Death" end
for _, i in ipairs({17249}) do I[i] = "The Black Flame" end
for _, i in ipairs({11261}) do I[i] = "The Butcher" end
for _, i in ipairs({3914}) do I[i] = "The Cell Keeper" end
for _, i in ipairs({4421}) do I[i] = "The Crone" end
for _, i in ipairs({10799}) do I[i] = "The Cursed" end
for _, i in ipairs({14322}) do I[i] = "The Drunk" end
for _, i in ipairs({12243,13738}) do I[i] = "The Fifth Kahn" end
for _, i in ipairs({12240,13742}) do I[i] = "The First Kahn" end
for _, i in ipairs({6669}) do I[i] = "The First Mate" end
for _, i in ipairs({644}) do I[i] = "The Foreman" end
for _, i in ipairs({12242,13739}) do I[i] = "The Fourth Kahn" end
for _, i in ipairs({7009}) do I[i] = "The Hand of Chaos" end
for _, i in ipairs({289}) do I[i] = "The Hermit" end
for _, i in ipairs({6236}) do I[i] = "The Islander" end
for _, i in ipairs({3842}) do I[i] = "The Keymaster" end
for _, i in ipairs({3975}) do I[i] = "The Scarlet Champion" end
for _, i in ipairs({12339}) do I[i] = "The Scarlet Oracle" end
for _, i in ipairs({12239,13741}) do I[i] = "The Second Kahn" end
for _, i in ipairs({645}) do I[i] = "The Ship's Cook" end
for _, i in ipairs({646}) do I[i] = "The Ship's First Mate" end
for _, i in ipairs({1763}) do I[i] = "The Smelter" end
for _, i in ipairs({14832}) do I[i] = "The Strongest Woman Alive!" end
for _, i in ipairs({14492}) do I[i] = "The Surveyor" end
for _, i in ipairs({12241,13740}) do I[i] = "The Third Kahn" end
for _, i in ipairs({8442,8444,8447}) do I[i] = "The Undermarket" end
for _, i in ipairs({2707}) do I[i] = "The Venom Queen" end
for _, i in ipairs({14435}) do I[i] = "The Wind Seeker" end
for _, i in ipairs({7323}) do I[i] = "The Wolf" end
for _, i in ipairs({15450,15522}) do I[i] = "Thick Leather Collector" end
for _, i in ipairs({15432}) do I[i] = "Thorium Bar Collector" end
for _, i in ipairs({10362}) do I[i] = "Thrown Weapon Trainer" end
for _, i in ipairs({4235,4592}) do I[i] = "Thrown Weapons Merchant" end
for _, i in ipairs({10298}) do I[i] = "Thrown Weapons Trainer" end
for _, i in ipairs({15767}) do I[i] = "Thunder Bluff Commendations" end
for _, i in ipairs({11798}) do I[i] = "Thunder Bluff Flight Master" end
for _, i in ipairs({5030}) do I[i] = "Tiger Riding Trainer" end
for _, i in ipairs({15460}) do I[i] = "Tin Bar Collector" end
for _, i in ipairs({3293,3442}) do I[i] = "Tinkers' Union" end
for _, i in ipairs({3969}) do I[i] = "Tools & Supplies" end
for _, i in ipairs({4443}) do I[i] = "Totem Merchent" end
for _, i in ipairs({2378}) do I[i] = "Town Historian" end
for _, i in ipairs({5039}) do I[i] = "Tracking Trainer" end
for _, i in ipairs({989,1148,2225,2381,2821,3081,3556,3954,3955,5135,9636}) do I[i] = "Trade Goods" end
for _, i in ipairs({8363}) do I[i] = "Trade Goods Supplier" end
for _, i in ipairs({3779,11189}) do I[i] = "Trade Goods Supplies" end
for _, i in ipairs({1286,3299,5100,5163,12957}) do I[i] = "Trade Supplier" end
for _, i in ipairs({960,1456,1465,1692,2393}) do I[i] = "Tradesman" end
for _, i in ipairs({777}) do I[i] = "Tradeswoman" end
for _, i in ipairs({12920,12939}) do I[i] = "Trauma Surgeon" end
for _, i in ipairs({3937}) do I[i] = "Traveling Baker" end
for _, i in ipairs({3291}) do I[i] = "Traveling Merchant" end
for _, i in ipairs({844}) do I[i] = "Traveling Salesman" end
for _, i in ipairs({7528,7870}) do I[i] = "Tribal Leatherworking Trainer" end
for _, i in ipairs({7903}) do I[i] = "Troyas' Pet" end
for _, i in ipairs({5017}) do I[i] = "Turtle Pet Trainer" end
for _, i in ipairs({3525,4881}) do I[i] = "Turtle Trainer" end
for _, i in ipairs({9018}) do I[i] = "Twilight's Hammer Interrogator" end
for _, i in ipairs({1333,4180,8398}) do I[i] = "Two Handed Weapon Merchant" end
for _, i in ipairs({4043}) do I[i] = "Two-Handed Weapons Merchant" end
for _, i in ipairs({14742}) do I[i] = "Unbalanced Engineer" end
for _, i in ipairs({4731}) do I[i] = "Undead Horse Merchant" end
for _, i in ipairs({4773}) do I[i] = "Undead Horse Riding Instructor" end
for _, i in ipairs({7743}) do I[i] = "Undead Horse Riding Trainer" end
for _, i in ipairs({10781}) do I[i] = "Undercity Census" end
for _, i in ipairs({15768}) do I[i] = "Undercity Commendations" end
for _, i in ipairs({303}) do I[i] = "Use Your Imagination" end
for _, i in ipairs({4245}) do I[i] = "Valyen's Pet" end
for _, i in ipairs({7292}) do I[i] = "Vault Administrator" end
for _, i in ipairs({10882}) do I[i] = "Vengeance" end
for _, i in ipairs({4085}) do I[i] = "Venture Armor Salesman" end
for _, i in ipairs({4086}) do I[i] = "Venture Co. Merchant" end
for _, i in ipairs({11391}) do I[i] = "Vilebranch Troll Ambassador" end
for _, i in ipairs({258}) do I[i] = "Vintner" end
for _, i in ipairs({379,2364,3086}) do I[i] = "Waitress" end
for _, i in ipairs({1312,5816}) do I[i] = "Wand Merchant" end
for _, i in ipairs({5754}) do I[i] = "Wand Vendor" end
for _, i in ipairs({1451}) do I[i] = "Wandering Minstrel" end
for _, i in ipairs({5133}) do I[i] = "Wands Merchant" end
for _, i in ipairs({15700,15701}) do I[i] = "War Effort Commander" end
for _, i in ipairs({15702,15703,15704,15707,15708,15709}) do I[i] = "War Effort Recruiter" end
for _, i in ipairs({3359}) do I[i] = "War Harness Maker" end
for _, i in ipairs({3023}) do I[i] = "War Harness Vendor" end
for _, i in ipairs({2605,2606}) do I[i] = "Warband Leader" end
for _, i in ipairs({4949}) do I[i] = "Warchief" end
for _, i in ipairs({6326,6327}) do I[i] = "Wargryphon Master" end
for _, i in ipairs({334}) do I[i] = "Warlord of the Blackrock Clan" end
for _, i in ipairs({2302,2804,3890,10360,14981,14982}) do I[i] = "Warsong Gulch Battlemaster" end
for _, i in ipairs({14754}) do I[i] = "Warsong Supply Officer" end
for _, i in ipairs({11316}) do I[i] = "Waste Management" end
for _, i in ipairs({7882}) do I[i] = "Water Co. Security" end
for _, i in ipairs({7231,7232}) do I[i] = "Weapon Crafter" end
for _, i in ipairs({3658}) do I[i] = "Weapon Dealer" end
for _, i in ipairs({2704,10256,10365,11865,11866,11867,11868,11869,11870,13084}) do I[i] = "Weapon Master" end
for _, i in ipairs({224}) do I[i] = "Weapon Peddler" end
for _, i in ipairs({3361,3409}) do I[i] = "Weapon Vendor" end
for _, i in ipairs({1287,1289,2997,4556,4557}) do I[i] = "Weapons Merchant" end
for _, i in ipairs({12782,14581}) do I[i] = "Weapons Quartermaster" end
for _, i in ipairs({54,78,220,225,945,1273,1296,1441,3073,3077,3159,3163,3479,3491,3534,3539,3588,3609,4183,4884,4888,10361,11137,11178,12024}) do I[i] = "Weaponsmith" end
for _, i in ipairs({3682}) do I[i] = "Weaponsmith & Armorcrafter" end
for _, i in ipairs({4890}) do I[i] = "Weaponsmith & Armorer" end
for _, i in ipairs({11184}) do I[i] = "Weaponsmith & Gunsmith" end
for _, i in ipairs({1467}) do I[i] = "Weaponsmith <Temp>" end
for _, i in ipairs({7173}) do I[i] = "Weaponsmith Trainer" end
for _, i in ipairs({10377}) do I[i] = "Wind Rider Apprentice" end
for _, i in ipairs({1301}) do I[i] = "Wine Vendor" end
for _, i in ipairs({14018}) do I[i] = "Winterax Hero" end
for _, i in ipairs({10618,11696}) do I[i] = "Wintersaber Trainers" end
for _, i in ipairs({10578}) do I[i] = "Witch Doctor in Training" end
for _, i in ipairs({11388}) do I[i] = "Witherbark Troll Ambassador" end
for _, i in ipairs({386}) do I[i] = "Wolf Merchant" end
for _, i in ipairs({4994}) do I[i] = "Wolf Pet Trainer" end
for _, i in ipairs({4752}) do I[i] = "Wolf Riding Instructor" end
for _, i in ipairs({5031}) do I[i] = "Wolf Riding Trainer" end
for _, i in ipairs({2870,2942,4207}) do I[i] = "Wolf Trainer" end
for _, i in ipairs({230}) do I[i] = "Woodcrafter" end
for _, i in ipairs({841}) do I[i] = "Woodcrafting Supplier" end
for _, i in ipairs({15528}) do I[i] = "Wool Bandage Collector" end
for _, i in ipairs({8496}) do I[i] = "Workshop Assistant" end
for _, i in ipairs({8399}) do I[i] = "Xylem's Apprentice" end
for _, i in ipairs({14921}) do I[i] = "Zandalar Supplies and Repair" end
for _, i in ipairs({1733}) do I[i] = "Zardeth's Minion" end
for _, i in ipairs({3149,3150,9564,9566,12136,12137}) do I[i] = "Zeppelin Master" end
for _, i in ipairs({3148}) do I[i] = "Zeppelin Operator" end
for _, i in ipairs({153,353,1227,2797,2801,5903}) do I[i] = "iCoke Redemption Vendor" end
