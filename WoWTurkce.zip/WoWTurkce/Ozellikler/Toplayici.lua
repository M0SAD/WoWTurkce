-- Büyü toplayıcı: tüm sınıfların büyü açıklamalarını oyundan alır ve çevirisi
-- olmayanları kaydeder. Arka planda, oyunu yavaşlatmadan çalışır (her karede birkaç büyü).
-- Her sürümde bir kez otomatik çalışır; elle başlatmak için: /wowturkce topla
local G = WoWTurkce

local function ad(id)
	if C_Spell and C_Spell.GetSpellName then return C_Spell.GetSpellName(id) end
	return GetSpellInfo and (GetSpellInfo(id)) or nil
end
local function altBaslik(id)
	if C_Spell and C_Spell.GetSpellSubtext then return C_Spell.GetSpellSubtext(id) end
	return GetSpellSubtext and GetSpellSubtext(id)
end
local function aciklama(id)
	if C_Spell and C_Spell.GetSpellDescription then return C_Spell.GetSpellDescription(id) end
	return GetSpellDescription and GetSpellDescription(id)
end
local function yukluMu(id)
	if C_Spell and C_Spell.IsSpellDataCached then return C_Spell.IsSpellDataCached(id) end
	return true
end
local function yukle(id)
	if C_Spell and C_Spell.RequestLoadSpellData then C_Spell.RequestLoadSpellData(id) end
end

local kuyruk, deneme, toplam, biten, yeni = {}, {}, 0, 0, 0
local calisiyor = false
local cerceve = CreateFrame("Frame")

local function isle(id)
	local d = aciklama(id)
	if not d or d == "" then return false end
	local isim = ad(id) or tostring(id)
	local alt = altBaslik(id)
	local K = G.kayitAc()
	K.buyu = K.buyu or {}
	-- Açıklama satır satır (ipucunda her paragraf ayrı satır olabilir)
	local function dene(metin)
		metin = metin:gsub("^%s+", ""):gsub("%s+$", "")
		if metin == "" or G.cevir(G.Buyu, metin) then return end
		local sab = G.sablon(metin)
		if K.buyu[sab] == nil then
			K.buyu[sab] = isim .. ((alt and alt ~= "") and (" (" .. alt .. ")") or "")
			yeni = yeni + 1
		end
	end
	dene(d)
	-- Büyü adı da çevrilmemişse kaydet
	if isim and not G.buyuAdiCevir(isim) then
		K.buyuadi = K.buyuadi or {}
		if K.buyuadi[isim] == nil then K.buyuadi[isim] = true end
	end
	if d:find("\n") then for satir in d:gmatch("[^\n]+") do dene(satir) end end
	return true
end

local function bitir()
	calisiyor = false
	cerceve:SetScript("OnUpdate", nil)
	local K = G.kayitAc()
	K.toplayiciSurum = G.SURUM
	if yeni > 0 then G.yaz(("Büyü açıklamaları toplandı: %d büyü tarandı, çevirisi olmayan %d yeni açıklama kaydedildi."):format(biten, yeni)) end
end

local function adim()
	local n = 0
	while n < 8 and #kuyruk > 0 do
		local id = table.remove(kuyruk, 1)
		n = n + 1
		if yukluMu(id) and isle(id) then
			biten = biten + 1
		else
			deneme[id] = (deneme[id] or 0) + 1
			if deneme[id] <= 40 then
				yukle(id)
				kuyruk[#kuyruk + 1] = id
			else
				biten = biten + 1 -- bu istemcide olmayan büyü
			end
		end
	end
	if #kuyruk == 0 then bitir() end
end

-- Oyuncunun büyü kitabındaki tüm büyüler (ırk yetenekleri, pasifler, Forever'a özgü yetenekler dahil)
local function kitapIdleri(ekle)
	local SB = C_SpellBook
	if not (SB and SB.GetNumSpellBookSkillLines and SB.GetSpellBookSkillLineInfo and SB.GetSpellBookItemInfo) then return end
	local banka = (Enum and Enum.SpellBookSpellBank and Enum.SpellBookSpellBank.Player) or 0
	for i = 1, SB.GetNumSpellBookSkillLines() do
		local ok, bilgi = pcall(SB.GetSpellBookSkillLineInfo, i)
		if ok and bilgi then
			local bas, say = bilgi.itemIndexOffset or 0, bilgi.numSpellBookItems or 0
			for j = bas + 1, bas + say do
				local ok2, it = pcall(SB.GetSpellBookItemInfo, j, banka)
				if ok2 and it and it.spellID then ekle(it.spellID); if it.actionID then ekle(it.actionID) end end
			end
		end
	end
end

function G.toplayiciBaslat(sessiz)
	if calisiyor then return end
	kuyruk, deneme, toplam, biten, yeni = {}, {}, 0, 0, 0
	local gorulen = {}
	local function ekle(id)
		if type(id) == "number" and not gorulen[id] then gorulen[id] = true; kuyruk[#kuyruk + 1] = id; toplam = toplam + 1 end
	end
	if G.BuyuListesi then
		for _, liste in pairs(G.BuyuListesi) do
			for _, id in ipairs(liste) do ekle(id) end
		end
	end
	pcall(kitapIdleri, ekle)
	if toplam == 0 then return end
	calisiyor = true
	if not sessiz then G.yaz(("Tüm sınıfların büyü açıklamaları arka planda toplanıyor (%d büyü)..."):format(toplam)) end
	local bekle = 0
	cerceve:SetScript("OnUpdate", function(_, gecen)
		bekle = bekle + gecen
		if bekle < 0.05 then return end
		bekle = 0
		if InCombatLockdown and InCombatLockdown() then return end
		adim()
	end)
end

G.basla(function()
	local K = G.kayitAc()
	-- Toplayıcı Classic büyü listesini kullanır; Retail'de büyüler farklı olduğu için çalışmaz
	if G.KLASIK and G.ayar("kayit") and K.toplayiciSurum ~= G.SURUM then
		C_Timer.After(10, function() G.toplayiciBaslat(true) end)
	end
end)
