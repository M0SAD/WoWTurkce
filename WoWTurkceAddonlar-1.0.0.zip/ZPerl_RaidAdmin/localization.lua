XPERL_ADMIN_TITLE	= XPerl_ShortProductName.." Raid Admin"

XPERL_MSG_PREFIX	= "|c00C05050X-Perl|r "

-- Raid Admin
XPERL_BUTTON_ADMIN_PIN		= "Pencereyi Sabitle"
XPERL_BUTTON_ADMIN_LOCKOPEN	= "Pencereyi Açık Kilitle"
XPERL_BUTTON_ADMIN_SAVE1	= "Listeyi Kaydet"
XPERL_BUTTON_ADMIN_SAVE2	= "Mevcut liste düzenini belirtilen adla kaydeder. Ad verilmezse ad olarak şu anki saat kullanılır"
XPERL_BUTTON_ADMIN_LOAD1	= "Listeyi Yükle"
XPERL_BUTTON_ADMIN_LOAD2	= "Seçili listeyi yükle. Kayıtlı listedeki artık Raidde olmayan üyelerin yerine, listede kayıtlı olmayan aynı sınıftan üyeler konur"
XPERL_BUTTON_ADMIN_DELETE1	= "Listeyi Sil"
XPERL_BUTTON_ADMIN_DELETE2	= "Seçili listeyi sil"
XPERL_BUTTON_ADMIN_STOPLOAD1	= "Yüklemeyi Durdur"
XPERL_BUTTON_ADMIN_STOPLOAD2	= "Liste yükleme işlemini iptal eder"

XPERL_LOAD			= "Yükle"

XPERL_SAVED_ROSTER		= "'%s' adlı liste kaydedildi"
XPERL_ADMIN_DIFFERENCES		= "Mevcut listeyle %d fark"
XPERL_NO_ROSTER_NAME_GIVEN	= "Liste adı verilmedi"
XPERL_NO_ROSTER_CALLED		= "'%s' adlı kayıtlı liste yok"

-- Item Checker
XPERL_CHECK_TITLE		= XPerl_ShortProductName.." Item Check"

XPERL_CHECK_NAME		= "Ad"

XPERL_CHECK_DROPITEMTIP1	= "Eşya Bırak"
XPERL_CHECK_DROPITEMTIP2	= "Eşyalar bu pencereye bırakılıp sorgulanabilir eşya listesine eklenebilir.\\r/raitem komutunu da normal kullanabilirsiniz; eşyalar buraya da eklenir ve ileride kullanılır."
XPERL_CHECK_QUERY_DESC1		= "Sorgula"
XPERL_CHECK_QUERY_DESC2		= "İşaretli tüm eşyalar için eşya kontrolü (/raitem) yapar\\rSorgu her zaman güncel dayanıklılık, direnç ve reaktif bilgisini alır"
XPERL_CHECK_LAST_DESC1		= "Son"
XPERL_CHECK_LAST_DESC2		= "Son aranan eşyaları yeniden işaretle"
XPERL_CHECK_ALL_DESC1		= ALL
XPERL_CHECK_ALL_DESC2		= "Tüm eşyaları işaretle"
XPERL_CHECK_NONE_DESC1		= NONE
XPERL_CHECK_NONE_DESC2		= "Tüm eşyaların işaretini kaldır"
XPERL_CHECK_DELETE_DESC1	= DELETE
XPERL_CHECK_DELETE_DESC2	= "İşaretli tüm eşyaları listeden kalıcı olarak kaldır"
XPERL_CHECK_REPORT_DESC1	= "Bildir"
XPERL_CHECK_REPORT_DESC2	= "Seçili sonuçların raporunu Raid sohbetinde göster"
XPERL_CHECK_REPORT_WITH_DESC1	= "Olanlar"
XPERL_CHECK_REPORT_WITH_DESC2	= "Eşyası olanları (veya eşyayı kuşanmamış olanları) Raid sohbetine bildir. Ekipman taraması yapıldıysa onun sonuçları gösterilir."
XPERL_CHECK_REPORT_WITHOUT_DESC1= "Olmayanlar"
XPERL_CHECK_REPORT_WITHOUT_DESC2= "Eşyası olmayanları (veya eşyayı kuşanmış olanları) Raid sohbetine bildir"
XPERL_CHECK_SCAN_DESC1		= "Tara"
XPERL_CHECK_SCAN_DESC2		= "Raidde inceleme menzilindeki herkesi seçili eşyayı kuşanıp kuşanmadığına bakar ve oyuncu listesinde gösterir. Herkes kontrol edilene kadar Raiddeki kişilere yaklaşın (10 metre)."
XPERL_CHECK_SCANSTOP_DESC1	= "Taramayı Durdur"
XPERL_CHECK_SCANSTOP_DESC2	= "Oyuncuların ekipmanını seçili eşya için taramayı durdur"
XPERL_CHECK_REPORTPLAYER_DESC1	= "Oyuncuyu Bildir"
XPERL_CHECK_REPORTPLAYER_DESC2	= "Seçili oyuncunun bu eşya veya durum ayrıntılarını Raid sohbetine bildir"

XPERL_CHECK_BROKEN		= "Kırık"
XPERL_CHECK_REPORT_DURABILITY	= "Average Raid Durability: %d%% and %d people with a total of %d broken items"
XPERL_CHECK_REPORT_PDURABILITY	= "%s's Durability: %d%% with %d broken items"
XPERL_CHECK_REPORT_RESISTS	= "Average Raid resists: %d "..SPELL_SCHOOL2_CAP..", %d "..SPELL_SCHOOL3_CAP..", %d "..SPELL_SCHOOL4_CAP..", %d "..SPELL_SCHOOL5_CAP..", %d "..SPELL_SCHOOL6_CAP
XPERL_CHECK_REPORT_PRESISTS	= "%s's Resists: %d "..SPELL_SCHOOL2_CAP..", %d "..SPELL_SCHOOL3_CAP..", %d "..SPELL_SCHOOL4_CAP..", %d "..SPELL_SCHOOL5_CAP..", %d "..SPELL_SCHOOL6_CAP
XPERL_CHECK_REPORT_WITH		= " - with: "
XPERL_CHECK_REPORT_WITHOUT	= " - without: "
XPERL_CHECK_REPORT_WITH_EQ	= " - with (or not equipped): "
XPERL_CHECK_REPORT_WITHOUT_EQ	= " - without (or equipped): "
XPERL_CHECK_REPORT_EQUIPED	= " : equipped: "
XPERL_CHECK_REPORT_NOTEQUIPED	= " : NOT equipped: "
XPERL_CHECK_REPORT_ALLEQUIPED	= "Everyone has %s equipped"
XPERL_CHECK_REPORT_ALLEQUIPEDOFF= "Everyone has %s equipped, but %d member(s) offline"
XPERL_CHECK_REPORT_PITEM	= "%s has %d %s in inventory"
XPERL_CHECK_REPORT_PEQUIPED	= "%s has %s equipped"
XPERL_CHECK_REPORT_PNOTEQUIPED	= "%s DOES NOT have %s equipped"
XPERL_CHECK_REPORT_DROPDOWN	= "Çıkış Kanalı"
XPERL_CHECK_REPORT_DROPDOWN_DESC= "Eşya Kontrolü sonuçları için çıkış kanalını seçin"

XPERL_CHECK_REPORT_WITHSHORT	= " : %d with"
XPERL_CHECK_REPORT_WITHOUTSHORT	= " : %d without"
XPERL_CHECK_REPORT_EQUIPEDSHORT	= " : %d equipped"
XPERL_CHECK_REPORT_NOTEQUIPEDSHORT	= " : %d NOT equipped"
XPERL_CHECK_REPORT_OFFLINE	= " : %d offline"
XPERL_CHECK_REPORT_TOTAL	= " : %d Total Items"
XPERL_CHECK_REPORT_NOTSCANNED	= " : %d un-checked"

XPERL_CHECK_LASTINFO		= "Son veri %sönce alındı"

XPERL_CHECK_AVERAGE		= "Ortalama"
XPERL_CHECK_TOTALS		= "Toplam"
XPERL_CHECK_EQUIPED		= "Kuşanılmış"

XPERL_CHECK_SCAN_MISSING	= "İncelenebilir oyuncular eşya için taranıyor. (%d taranmadı)"

XPERL_REAGENTS			= {PRIEST = "Sacred Candle", MAGE = "Arcane Powder", DRUID = "Wild Thornroot",
					SHAMAN = "Ankh", WARLOCK = "Soul Shard", PALADIN = "Symbol of Divinity",
					ROGUE = "Flash Powder"}

XPERL_CHECK_REAGENTS		= "Reagents"

-- Roster Text
XPERL_ROSTERTEXT_TITLE		= XPerl_ShortProductName.." Roster Text"
XPERL_ROSTERTEXT_GROUP		= "Grup %d"
XPERL_ROSTERTEXT_GROUP_DESC	= "%d. gruptaki adları kullan"
XPERL_ROSTERTEXT_SAMEZONE	= "Yalnızca Aynı Bölge"
XPERL_ROSTERTEXT_SAMEZONE_DESC	= "Yalnızca sizinle aynı bölgedeki oyuncuların adlarını ekle"
XPERL_ROSTERTEXT_HELP		= "Metni panoya kopyalamak için Ctrl-C'ye basın"
XPERL_ROSTERTEXT_TOTAL		= "Toplam: %d"
XPERL_ROSTERTEXT_SETN		= "%d Kişi"
XPERL_ROSTERTEXT_SETN_DESC	= "%d kişilik Raid için grupları otomatik seç"
XPERL_ROSTERTEXT_TOGGLE		= "Değiştir"
XPERL_ROSTERTEXT_TOGGLE_DESC	= "Seçili grupları değiştir"
XPERL_ROSTERTEXT_SORT		= "Sırala"
XPERL_ROSTERTEXT_SORT_DESC	= "Grup+ad yerine ada göre sırala"
