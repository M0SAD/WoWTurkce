-- Kayıt paylaşma: başka oyuncuların topladığı çevirisiz metinleri addon sahibine ulaştırır.
-- Eklentiler internete bağlanamaz ve tarayıcı açamaz: kayıtlar sıkıştırılıp kısa bir koda çevrilir,
-- oyuncu form adresini ve kodu kopyalayıp tarayıcıda formdaki kutuya yapıştırır.
-- /wowturkce paylas (ya da "Çevrilmemişleri Gönder")
local G = WoWTurkce
local LD = WoWTurkce_LibDeflate or (LibStub and LibStub:GetLibrary("LibDeflate", true))

-- Addon sahibi (kayıtları toplayan kişi) ve gönderim formu
G.SAHIP = { "Mosad", "Erkin Azcan" }          -- karakter adları (Forever adları "Ad Soyad" olabilir)
G.FORM_URL = "https://docs.google.com/forms/d/e/1FAIpQLSePCix39XP9swwCMfOI5EhdEys5MArywejG_RoBicrevKsWCA/viewform"

function G.sahipMi()
	local ad = UnitName and UnitName("player")
	if WoWTurkce_Ayar and WoWTurkce_Ayar.sahip then return true end
	for _, s in ipairs(G.SAHIP) do if s == ad or (type(ad) == "string" and ad:sub(1, #s + 1) == s .. " ") then return true end end
	return false
end

-- Güvenli düz biçim: her kayıt  kat \31 anahtar \31 alan \31 değer, kayıtlar \30 ile ayrılır.
-- (Karşı taraf bunu kod çalıştırmadan, sadece bölerek okur.)
local AYRI, SATIR = "\31", "\30"
local ATLA = { sohbet = true, gonderim = true, gonderimSurum = true, toplayiciSurum = true, gelen = true, cevrilenSurum = true,
	esyaDok = true, esyaDokYok = true, gorevDok = true, tani = true } -- dökümler ve tanı verisi asla gönderilmez
local function temiz(v) return (tostring(v):gsub("[\30\31]", " ")) end
local function duzlestir(K)
	local out = {}
	local function ekle(kat, k, alan, v) out[#out + 1] = temiz(kat) .. AYRI .. temiz(k) .. AYRI .. alan .. AYRI .. temiz(v) end
	for kat, t in pairs(K) do
		if type(kat) == "number" and type(t) == "table" then
			for alan, v in pairs(t) do if type(v) == "string" then ekle("q", kat, alan, v) end end
		elseif type(t) == "table" and not ATLA[kat] then
			for k, v in pairs(t) do if not (kat == "arayuz" and type(k) == "string" and G.cop and G.cop(k)) then
				if type(v) == "table" then
					for a, d in pairs(v) do
						if type(d) == "table" then for a2, d2 in pairs(d) do if type(d2) ~= "table" then ekle(kat, k, a .. "." .. a2, d2) end end
						else ekle(kat, k, a, d) end
					end
				else ekle(kat, k, "", v) end
			end end
		end
	end
	return "WTR1" .. SATIR .. (G.SURUM or "") .. SATIR .. table.concat(out, SATIR)
end
local function coz(s)
	local parca = {}
	for p in (s .. SATIR):gmatch("(.-)" .. SATIR) do parca[#parca + 1] = p end
	if parca[1] ~= "WTR1" then return nil end
	local K = {}
	for i = 3, #parca do
		local kat, k, alan, v = parca[i]:match("^(.-)\31(.-)\31(.-)\31(.*)$")
		if kat then
			if kat == "q" then
				local id = tonumber(k)
				if id then K[id] = K[id] or {}; K[id][alan] = v end
			else
				K[kat] = K[kat] or {}
				local key = tonumber(k) or k
				if alan == "" then K[kat][key] = (v == "true") and true or v
				else
					local r = K[kat][key]; if type(r) ~= "table" then r = {}; K[kat][key] = r end
					local a1, a2 = alan:match("^(.-)%.(.+)$")
					if a1 then r[a1] = type(r[a1]) == "table" and r[a1] or {}; r[a1][a2] = v else r[alan] = v end
				end
			end
		end
	end
	return K, parca[2]
end
G._paylasCoz = coz

function G.paylasKodu()
	G.kayitTemizle()
	local duz = duzlestir(WoWTurkce_Kayit or {})
	if not LD then return "WTR0:" .. duz:gsub("[\30\31]", "|"), #duz end
	local sik = LD:CompressDeflate(duz, { level = 9 })
	return "WTR1:" .. LD:EncodeForPrint(sik), #duz
end

---------------------------------------------------------------------------
-- Paylaşım penceresi
---------------------------------------------------------------------------
local pencere
local function kutu(parent, tek)
	local eb = CreateFrame("EditBox", nil, parent, tek and "InputBoxTemplate" or nil)
	eb:SetAutoFocus(false)
	eb:SetFontObject(ChatFontNormal)
	eb:SetScript("OnEscapePressed", function() pencere:Hide() end)
	eb:SetScript("OnTextChanged", function(self, kullanici) if kullanici and self.sabit then self:SetText(self.sabit); self:HighlightText() end end)
	eb:SetScript("OnMouseUp", function(self) self:SetFocus(); self:HighlightText() end)
	eb:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
	return eb
end
function G.paylasAc()
	if not pencere then
		pencere = CreateFrame("Frame", "WoWTurkcePaylas", UIParent, "BasicFrameTemplateWithInset")
		pencere:SetSize(560, 400); pencere:SetPoint("CENTER"); pencere:SetFrameStrata("DIALOG")
		pencere:SetMovable(true); pencere:EnableMouse(true); pencere:RegisterForDrag("LeftButton")
		pencere:SetScript("OnDragStart", pencere.StartMoving); pencere:SetScript("OnDragStop", pencere.StopMovingOrSizing)
		tinsert(UISpecialFrames, "WoWTurkcePaylas")
		local bas = pencere:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
		bas:SetPoint("TOP", 0, -5); bas:SetText("WoWTurkce - Çevrilmemişleri Gönder")
		local adim1 = pencere:CreateFontString(nil, "OVERLAY", "GameFontNormal")
		adim1:SetPoint("TOPLEFT", 16, -34); adim1:SetPoint("TOPRIGHT", -16, -34); adim1:SetJustifyH("LEFT")
		adim1:SetText("1. Form adresini kopyala (Ctrl+C) ve tarayıcında aç:")
		local adres = kutu(pencere, true)
		adres:SetPoint("TOPLEFT", 22, -54); adres:SetPoint("TOPRIGHT", -18, -54); adres:SetHeight(24)
		pencere.adres = adres
		local adim2 = pencere:CreateFontString(nil, "OVERLAY", "GameFontNormal")
		adim2:SetPoint("TOPLEFT", 16, -90); adim2:SetPoint("TOPRIGHT", -16, -90); adim2:SetJustifyH("LEFT")
		pencere.adim2 = adim2
		local kay = CreateFrame("ScrollFrame", nil, pencere, "UIPanelScrollFrameTemplate")
		kay:SetPoint("TOPLEFT", 16, -128); kay:SetPoint("BOTTOMRIGHT", -34, 48)
		local eb = kutu(kay)
		eb:SetMultiLine(true); eb:SetWidth(500)
		kay:SetScrollChild(eb)
		pencere.eb = eb
		local alt = pencere:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
		alt:SetPoint("BOTTOMLEFT", 16, 18); alt:SetPoint("RIGHT", pencere, "RIGHT", -150, 0); alt:SetJustifyH("LEFT")
		alt:SetText("Kişisel bilgi içermez. Çeviriler bir sonraki sürümde eklenir.")
		local kapat = CreateFrame("Button", nil, pencere, "UIPanelButtonTemplate")
		kapat:SetSize(120, 24); kapat:SetPoint("BOTTOMRIGHT", -14, 12)
		kapat:SetText("Kapat"); kapat:SetScript("OnClick", function() pencere:Hide() end)
	end
	local kod = G.paylasKodu()
	local n, yanlis = G.bekleyenSayisi()
	pencere.adres.sabit = G.FORM_URL
	pencere.adres:SetText(G.FORM_URL)
	pencere.adim2:SetText(("2. Bu kodu kopyala ve formdaki kutuya yapıştır (%d metin, %d düzeltilecek görev):"):format(n, yanlis))
	pencere.eb.sabit = kod
	pencere.eb:SetText(kod)
	pencere:Show()
	pencere.adres:SetFocus(); pencere.adres:HighlightText()
end

-- Girişte, artık çevirisi olan eski kayıtları temizle (sayaç sadece gerçekten bekleyenleri göstersin)
local function renksiz(s) return (s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")) end
local DENETCI = {
	buyu = function(s) return G.cevir(G.Buyu, s) or G.cevir(G.Esya, s) end,
	buyuadi = function(s) return G.buyuAdiCevir(s) end,
	esyaadi = function(s) return G.EsyaAdi[s] end,
	egitim = function(s) return G.cevir(G.Egitim, s) end,
	arayuz = function(s)
		if G.cop and G.cop(s) then return true end
		if (G.arayuzCevir and G.arayuzCevir(s)) or s:find("WoWTurkce") or s:find("WoWTurkce") or s:find("^Level level") or s:find("^Seviye ") then return true end
		if s:find("%u%l+%-%u%l+") or s:find("^%u+#+$") then return true end -- oyuncu-sunucu adları
		if G.turkceMi(s) then return true end
		if G.cevirDegerleri and G.cevirDegerleri[s] then return true end
		local ic = s:match("^.+ %((.+)%)$"); if ic and (G.EsyaAdi[ic] or G.BuyuAdi[ic]) then return true end
		if #s > 160 and s:find("%. ") and not s:find("^%u%l+ %l") then return false end
	end,
	ipucu = function(s) return G.cevir(G.Esya, s) or G.cevir(G.Buyu, s) or s:find("^Returns you to ") end,
	hata = function(s) return G.cevir(G.Hata, s) end,
	secenek = function(s) s = renksiz(s); return G.cevir(G.Secenek, s) or G.GorevAdi[s] or G.GorevAdi[(s:gsub("%s*%(%d+%)$", ""))] end,
	kitap = function(k, v) return G.Kitap[k] end,
	altyazi = function(k, v) return G.Altyazi[k] end,
	kitapadi = function(s) return G.KitapAdi[s] end,
	soz = function(k, v) return G.Soz[k] or (type(v) == "table" and v.metin and G.Soz[G.konusmaIz(v.metin)]) end,
	konusma = function(k, v) return G.Konusma[k] or (type(v) == "table" and v.metin and G.Konusma[G.konusmaIz(v.metin)]) end,
}
function G.kayitTemizle()
	local K = WoWTurkce_Kayit
	if type(K) ~= "table" then return 0 end
	local silinen = 0
	for kat, f in pairs(DENETCI) do
		local t = K[kat]
		if type(t) == "table" then
			for k, v in pairs(t) do
				local ok, tr = pcall(f, k, v)
				if ok and tr then t[k] = nil; silinen = silinen + 1 end
			end
		end
	end
	for id, v in pairs(K) do
		if type(id) == "number" and not (type(v) == "table" and v.degisen) then
			-- Yalnızca kayıttaki TÜM alanların çevirisi artık varsa sil (başlığı çevrili ama açıklaması eksik görev kalsın)
			local x, y = G.Veri[id], G.VeriEk and G.VeriEk[id]
			local tam = (x or y) and true or false
			if tam and type(v) == "table" then
				local ad = { baslik = "b", aciklama = "a", hedef = "h", ilerleme = "i", tamamlama = "t" }
				for alan, k in pairs(ad) do
					if v[alan] and not ((x and x[k]) or (y and y[k])) then tam = false; break end
				end
			end
			if tam then K[id] = nil; silinen = silinen + 1 end
		end
	end
	return silinen
end
-- Her çeviri güncellemesinden (yeni sürüm) sonra kayıt sıfırlanır: bekleyen sayısı yeniden 0'dan başlar
local function surumAl()
	local fn = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
	local ok, v = pcall(fn, "WoWTurkce", "Version")
	return (ok and v) or G.SURUM
end
G.basla(function()
	local K = G.kayitAc()
	local v = surumAl()
	-- Yalnızca addon sahibinde: her çeviri sürümünden sonra kayıt sıfırlanır. Diğer oyuncuların
	-- kayıtları silinmez; uygulama onları forma gönderir.
	if K.cevrilenSurum ~= v then
		if G.sahipMi() then for k in pairs(K) do K[k] = nil end end
		K.cevrilenSurum = v
	end
	G.kayitTemizle()
end)

-- Bekleyen kayıt sayısı (görevler + diğer kategoriler + düzeltilecekler)
function G.bekleyenSayisi()
	local gorev, _, diger = G.kayitSayilari()
	local n = gorev
	-- Gönderilmeyen kategoriler (sohbet vb.) sayıya katılmaz
	for k, v in pairs(diger) do if k ~= "yanlis" and not ATLA[k] then n = n + v end end
	return n, diger.yanlis or 0
end

-- "Çevrilmemişleri gönder": kayıtları diske yazdırmak için arayüzü yeniden yükler.
-- Eklentiler internete bağlanamaz; kayıt dosyası (SavedVariables) yalnızca /reload ya da çıkışta yazılır.
function G.gonder()
	if not G.sahipMi() then G.paylasAc(); return end
	G.kayitTemizle()
	local n, yanlis = G.bekleyenSayisi()
	local K = G.kayitAc()
	K.gonderim = date and date("%Y-%m-%d %H:%M") or true
	K.gonderimSurum = G.SURUM
	G.yaz(("%d çevrilmemiş metin ve %d düzeltilecek görev kaydediliyor..."):format(n, yanlis))
	ReloadUI()
end

-- /wowturkce durum: bu oturumun istatistiği
local KAT_AD = { gorev = "görev", buyu = "büyü açıklaması", buyuadi = "büyü adı", arayuz = "arayüz yazısı", ipucu = "ipucu satırı",
	hata = "hata mesajı", konusma = "NPC konuşması", secenek = "konuşma seçeneği", egitim = "oyun ipucu", kitap = "kitap sayfası",
	kitapadi = "kitap adı", soz = "NPC sözü", altyazi = "altyazı", esyaadi = "eşya adı", sohbet = "sohbet mesajı", kelime = "tek kelime" }
function G.durumYaz()
	local ist = G.ist or { kaydedilen = 0 }
	local n = G.bekleyenSayisi()
	G.yaz(("Son çeviriden beri yakalanan: %d metin (bu oturumda %d)."):format(n, ist.kaydedilen or 0))
end

function G.sohbetDilAdi()
	local d = G.ayar("sohbetDil")
	if d == "tr" then return "sadece Türkçe" elseif d == "en" then return "sadece İngilizce" end
	return "Türkçe (İngilizce)"
end

---------------------------------------------------------------------------
-- Oyundan çıkış: paylaşım kodunu SavedVariables'a yaz. WoWTurkce Güncelleyici (izleme modu)
-- oyun kapanınca bu kodu okuyup bilgisayardaki rapora ekler (ve izin verildiyse forma gönderir).
-- Yalnızca bu oturumda yeni bir şey kaydedildiyse çalışır (/reload'ları yavaşlatmasın).
---------------------------------------------------------------------------
do
	local cf = CreateFrame("Frame")
	cf:RegisterEvent("PLAYER_LOGOUT")
	cf:SetScript("OnEvent", function()
		pcall(function()
			if not (G.ayar and G.ayar("kayit")) then return end
			if not (G.ist and G.ist.kaydedilen and G.ist.kaydedilen > 0) then return end
			if type(WoWTurkce_Ayar) ~= "table" then return end
			local kod = G.paylasKodu()
			if type(kod) == "string" and kod:match("^WTR1:") then
				WoWTurkce_Ayar.cikisKodu = kod
				WoWTurkce_Ayar.cikisZaman = time and time() or 0
			end
		end)
	end)
end
