-- NPC sözleri: yaratık ve NPC'lerin söylediği, bağırdığı ve fısıldadığı sözler ile duygu (emote) mesajları.
-- Hem sohbet penceresinde hem de kafalarının üstündeki konuşma balonunda Türkçe gösterilir.
-- Eşleşme parmak iziyle: G.Soz[iz] = "Türkçe söz" (oyuncu adı/sınıfı/ırkı $n $c $r olur).
-- Zindan ve baskınlarda oyun balonlara dokunmaya izin vermez; orada yalnızca sohbet penceresi çevrilir.
local G = WoWTurkce
G.Soz = G.Soz or {}

local OLAYLAR = {
	CHAT_MSG_MONSTER_SAY = "soyler", CHAT_MSG_MONSTER_YELL = "bagirir", CHAT_MSG_MONSTER_EMOTE = "duygu",
	CHAT_MSG_MONSTER_WHISPER = "fisildar", CHAT_MSG_MONSTER_PARTY = "grup",
	CHAT_MSG_RAID_BOSS_EMOTE = "duygu", CHAT_MSG_RAID_BOSS_WHISPER = "fisildar",
}

local function cevir(msg, yazan)
	if type(msg) ~= "string" or msg == "" or G.turkceMi(msg) then return nil end
	local tr, iz = G.izBul(G.Soz, msg)
	-- Duygu mesajında yaratık adı metnin içinde gelebilir: "Tirisfal Farmhand attempts to run away in fear!"
	if not tr and type(yazan) == "string" and yazan ~= "" and not G.gizli(yazan) then
		local bas, son = msg:find(yazan, 1, true)
		if bas then
			local t2 = G.izBul(G.Soz, msg:sub(1, bas - 1) .. "%s" .. msg:sub(son + 1))
			if t2 then tr = t2:gsub("%%s", function() return yazan end) end
		end
	end
	-- Sohbetteki kalıplı cümleler (şerefe, teşekkür vb.): balon ve pencere aynı çeviriyi kullanır
	if not tr and G.SohbetKaliplari and not G.gizli(msg) then
		for _, k in ipairs(G.SohbetKaliplari) do
			local y, n = msg:gsub(k[1], k[2])
			if n > 0 and y ~= msg then return y, iz end
		end
	end
	return tr and G.doldur(tr):gsub("\n", " "), iz
end

-- Sohbet penceresi: her sohbet çerçevesi için ayrı çağrılır, kaydı bir kez yapalım
local sonKayit
local function filtre(_, olay, msg, yazan, ...)
	if not G.modul("balon") or G.gizli(msg) or type(msg) ~= "string" then return false end
	local tr, iz = cevir(msg, yazan)
	-- NPC unvanı Türkçe gösterilsin: "Executor Zygand" -> "İnfazcı Zygand" (ayar: NPC adları)
	local yz = yazan
	if type(yazan) == "string" and not G.gizli(yazan) and G.npcAdTr and G.modul("npc") then
		local ok, t = pcall(G.npcAdTr, yazan)
		if ok and type(t) == "string" and t ~= "" then yz = t end
	end
	if tr then return false, tr, yz, ... end
	if iz and sonKayit ~= iz then
		sonKayit = iz
		G.kaydetDiger("soz", iz, { npc = (not G.gizli(yazan)) and yazan or nil, tur = OLAYLAR[olay], metin = msg })
	end
	if yz ~= yazan then return false, msg, yz, ... end
	return false
end
local filtreEkle = ChatFrame_AddMessageEventFilter or (ChatFrameUtil and ChatFrameUtil.AddMessageEventFilter)
if filtreEkle then for olay in pairs(OLAYLAR) do pcall(filtreEkle, olay, filtre) end end

-- Konuşma balonları
local function bolgeleriTara(cerceve, asil, tr)
	if not cerceve or not cerceve.GetRegions then return false end
	for _, r in ipairs({ cerceve:GetRegions() }) do
		if r.GetObjectType and r:GetObjectType() == "FontString" and r:GetText() == asil then
			r:SetText(tr)
			return true
		end
	end
	return false
end

local function balonlariCevir(asil, tr)
	if not C_ChatBubbles or not C_ChatBubbles.GetAllChatBubbles then return end
	for _, balon in pairs(C_ChatBubbles.GetAllChatBubbles(false) or {}) do
		if not (balon.IsForbidden and balon:IsForbidden()) then
			if not bolgeleriTara(balon, asil, tr) then
				for _, cocuk in ipairs({ balon:GetChildren() }) do
					if not (cocuk.IsForbidden and cocuk:IsForbidden()) then
						if cocuk.String and cocuk.String.GetText and cocuk.String:GetText() == asil then
							cocuk.String:SetText(tr)
							break
						end
						if bolgeleriTara(cocuk, asil, tr) then break end
					end
				end
			end
		end
	end
end

local f = CreateFrame("Frame")
f:RegisterEvent("CHAT_MSG_MONSTER_SAY")
f:RegisterEvent("CHAT_MSG_MONSTER_YELL")
f:RegisterEvent("CHAT_MSG_MONSTER_PARTY")
f:RegisterEvent("CHAT_MSG_SAY")
f:RegisterEvent("CHAT_MSG_PARTY")
f:RegisterEvent("CHAT_MSG_PARTY_LEADER")
f:SetScript("OnEvent", function(_, olay, msg)
	if not G.modul("balon") or G.gizli(msg) or type(msg) ~= "string" then return end
	local tr
	if olay == "CHAT_MSG_SAY" or olay == "CHAT_MSG_PARTY" or olay == "CHAT_MSG_PARTY_LEADER" then
		-- Oyuncu mesajı: yalnızca Questie duyurularını çevir
		if not msg:find("^Questie: ") then return end
		tr = G.hedefCevir and G.hedefCevir(msg)
	else
		tr = cevir(msg)
	end
	if not tr then return end
	-- Balon bir sonraki karede oluşur; iki kez deneyelim
	C_Timer.After(0, function() pcall(balonlariCevir, msg, tr) end)
	C_Timer.After(0.15, function() pcall(balonlariCevir, msg, tr) end)
end)
