-- WoWTürkçe - eşya ipucu satırları (Requires Level, +10 Stamina, Equip:/Use: ...)
-- Sayılar # ile kalıba indirilir, Türkçe kalıpta {1} {2} ... olarak geri konur.
local _, WT = ...

WT.SatirK   = WT.SatirK   or {}  -- ["Requires Level #"] = "Gerekli Seviye {1}"
WT.SatirG   = WT.SatirG   or {}  -- "Requires X" içindeki X: meslek, rütbe, fraksiyon, binicilik
WT.SatirS   = WT.SatirS   or {}  -- sınıf, ırk, itibar düzeyi
WT.SatirSet = WT.SatirSet or {}  -- set adları
WT.SatirSag = WT.SatirSag or {}  -- sağ sütun (Cloth, Sword, Speed #)

local K, G, S, SET, SAG = WT.SatirK, WT.SatirG, WT.SatirS, WT.SatirSet, WT.SatirSag
local onbellek = {}
local yok = {}

local function kalip(s)
  local sayilar = {}
  local k = s:gsub("%d[%d,%.]*", function(n)
    local son = n:sub(-1)
    if son == "," or son == "." then
      sayilar[#sayilar + 1] = n:sub(1, -2)
      return "#" .. son
    end
    sayilar[#sayilar + 1] = n
    return "#"
  end)
  return k, sayilar
end

local function doldur(tr, sayilar)
  return (tr:gsub("{(%d+)}", function(i) return sayilar[tonumber(i)] or "" end))
end

local function esyaAdi(ad)
  return WT.Esya and WT.Esya[ad]
end

local function liste(s, tablo)
  local parca = {}
  for p in (s .. ", "):gmatch("(.-), ") do
    local t = tablo[p]
    if not t then return nil end
    parca[#parca + 1] = t
  end
  return table.concat(parca, ", ")
end


local FIIL = { craft = "yapmayı", make = "yapmayı", create = "yaratmayı", build = "inşa etmeyi",
  forge = "dövmeyi", smelt = "eritmeyi", sew = "dikmeyi", brew = "demlemeyi", cook = "pişirmeyi",
  enchant = "efsunlamayı" }

local function cumle(c)
  local k, n = kalip(c)
  local t = K[k] or (WT.BuyuK and WT.BuyuK[k])
  if t then return doldur(t, n) end
  local fiil, ad = c:match("^Teaches you how to (%a+) (.+)%.$")
  if fiil and FIIL[fiil] then
    ad = ad:gsub("^an? ", "")
    local tr = esyaAdi(ad)
    if tr then return tr .. " " .. FIIL[fiil] .. " öğretir." end
  end
  return nil
end

local function govdeCevir(g)
  local t = cumle(g)
  if t then return t end
  local sonuc, i = {}, 1
  while i <= #g do
    local a1, b1 = g:find("[%.!]%s+", i)
    local a2, b2 = g:find("\n+", i)
    local kes, s1, s2
    if a1 and (not a2 or a1 < a2) then kes, s1, s2 = a1, a1 + 1, b1
    elseif a2 then kes, s1, s2 = a2 - 1, a2, b2 end
    local parca = kes and g:sub(i, kes) or g:sub(i)
    local tr = cumle(parca)
    if not tr then return nil end
    sonuc[#sonuc + 1] = tr
    if not kes then break end
    sonuc[#sonuc + 1] = g:sub(s1, s2)
    i = s2 + 1
  end
  return table.concat(sonuc)
end

local ONEK = { { "Equip: ", "Kuşanıldığında: " }, { "Use: ", "Kullan: " }, { "Chance on hit: ", "Vuruşta şans: " } }

local function cevir(s)
  local k, n = kalip(s)
  local t = K[k]
  if t then return doldur(t, n) end

  for _, o in ipairs(ONEK) do
    if s:sub(1, #o[1]) == o[1] then
      local g = govdeCevir(s:sub(#o[1] + 1))
      return g and (o[2] .. g)
    end
  end
  local setSayi, setGovde = s:match("^%((%d+)%) Set: (.+)$")
  if setSayi then
    local g = govdeCevir(setGovde)
    return g and ("(%s) Set: %s"):format(setSayi, g)
  end

  -- Set parçası ("  Feralheart Boots") ve üretilen eşya ("\nWestfall Stew")
  local bosluk, ad = s:match("^(%s+)(.+)$")
  if ad then
    local tr = esyaAdi(ad)
    return tr and (bosluk .. tr)
  end
  -- Set adı ("The Five Thunders (2/8)")
  local setAd, a, b = s:match("^(.+) %((%d+)/(%d+)%)$")
  if setAd then
    local tr = SET[setAd] or esyaAdi(setAd)
    return tr and ("%s (%s/%s)"):format(tr, a, b)
  end
  -- Requires ...
  local gerek = s:match("^Requires (.+)$")
  if gerek then
    local fr, itibar = gerek:match("^(.+) %- (%a+)$")
    if fr and G[fr] and S[itibar] then return ("Gerekli: %s - %s"):format(G[fr], S[itibar]) end
    local beceri, d = gerek:match("^(.+) %((%d+)%)$")
    if beceri and G[beceri] then return ("Gerekli: %s (%s)"):format(G[beceri], d) end
    if G[gerek] then return "Gerekli: " .. G[gerek] end
    return nil
  end
  local sinif = s:match("^Classes: (.+)$")
  if sinif then local t2 = liste(sinif, S); return t2 and ("Sınıflar: " .. t2) end
  local irk = s:match("^Races: (.+)$")
  if irk then local t2 = liste(irk, S); return t2 and ("Irklar: " .. t2) end
  local tur, eAd, adet = s:match("^(Unique%-?%a*): (.+) %((%d+)%)$")
  if tur then
    local tr = esyaAdi(eAd) or SET[eAd]
    local on = (tur == "Unique") and "Eşsiz" or "Kuşanmada Eşsiz"
    return ("%s: %s (%s)"):format(on, tr or eAd, adet)
  end
  -- Malzeme listesi: "Light Leather (4), Coarse Thread (2)"
  if s:find(", ", 1, true) or s:find(" %(%d+%)$") then
    local parca = {}
    for p in (s .. ", "):gmatch("(.-), ") do
      local ad2, sayi = p:match("^(.+) (%(%d+%))$")
      ad2 = ad2 or p
      local tr = esyaAdi(ad2)
      if not tr then return nil end
      parca[#parca + 1] = sayi and (tr .. " " .. sayi) or tr
    end
    return table.concat(parca, ", ")
  end
  return esyaAdi(s)
end

function WT.SatirCevir(s)
  if not s or s == "" then return nil end
  local o = onbellek[s]
  if o == nil then
    o = cevir(s) or yok
    onbellek[s] = o
  end
  if o == yok then return nil end
  return o
end

function WT.SagCevir(s)
  if not s or s == "" then return nil end
  local t = SAG[s]
  if t then return t end
  local k, n = kalip(s)
  t = SAG[k]
  return t and doldur(t, n)
end

WT.Kalip, WT.Doldur = kalip, doldur
