-- WoWTürkçe - eşya adları ve açıklamaları
-- İpucunda 1. satırdaki adı ve sarı tırnaklı açıklamayı çevirir; eksikleri kayda yazar.
-- /wt esyadokum ile oyundaki bütün eşyaların ipucu satırlarını WoWTurkce_Dokum'a döker.
local _, WT = ...

WT.Esya        = WT.Esya        or {}   -- ["English name"] = "Türkçe ad"
WT.EsyaID      = WT.EsyaID      or {}   -- [itemID] = "Türkçe ad" (aynı İngilizce adın farklı çevirisi gerekirse)
WT.EsyaAciklama = WT.EsyaAciklama or {} -- ["\"English description\""] = "\"Türkçe açıklama\""

local Esya, EsyaID, Aciklama = WT.Esya, WT.EsyaID, WT.EsyaAciklama

local function idBul(tt, data)
  if data and data.id then return data.id end
  local _, link = tt:GetItem()
  return link and tonumber(link:match("item:(%d+)"))
end

local function esyaIpucu(tt, data)
  if not WT.Acik("esya") then return end
  local ad = tt.GetName and tt:GetName()
  if not ad then return end
  local id = idBul(tt, data)
  local s1 = _G[ad .. "TextLeft1"]
  local yazi = s1 and s1:GetText()
  if yazi then
    local tr = (id and EsyaID[id]) or Esya[yazi]
    if tr then
      s1:SetText(tr)
    elseif id then
      WT.Kaydet("esya", id, yazi)
    end
  end
  -- Açıklama: tırnakla başlayan satır.
  for i = 2, tt:NumLines() do
    local s = _G[ad .. "TextLeft" .. i]
    local t = s and s:GetText()
    if t and t:sub(1, 1) == '"' then
      local tr = Aciklama[t]
      if tr then s:SetText(tr) else WT.Kaydet("aciklama", t, id or true) end
    elseif t and WT.SatirCevir then
      local tr = WT.SatirCevir(t)
      if tr then s:SetText(tr) end
    end
    local r = _G[ad .. "TextRight" .. i]
    local rt = r and r:IsShown() and r:GetText()
    if rt and WT.SagCevir then
      local tr = WT.SagCevir(rt)
      if tr then r:SetText(tr) end
    end
  end
end

if TooltipDataProcessor and Enum and Enum.TooltipDataType and Enum.TooltipDataType.Item then
  TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, esyaIpucu)
else
  for _, tt in ipairs({ GameTooltip, ItemRefTooltip, ShoppingTooltip1, ShoppingTooltip2 }) do
    if tt then tt:HookScript("OnTooltipSetItem", esyaIpucu) end
  end
end

------------------------------------------------------------------ döküm aracı
-- Oyunun bildiği her eşyanın ipucu satırlarını kaydeder (ad, açıklama, Kuşanıldığında/Kullan satırları).
-- Farklı istemci sürümlerinde API adları değişebildiği için her çağrı yedekli ve pcall korumalı.
local dokum = { aktif = false }
WT.Dokum = dokum

local Anlik  = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
local Bilgi  = (C_Item and C_Item.GetItemInfo) or GetItemInfo
local Hazir  = C_Item and C_Item.IsItemDataCachedByID
local Iste   = C_Item and C_Item.RequestLoadItemDataByID
local IpucuV = C_TooltipInfo and C_TooltipInfo.GetItemByID

local gizli = CreateFrame("GameTooltip", "WoWTurkceDokumIpucu", UIParent, "GameTooltipTemplate")

local function satirlar(id)
  local t = {}
  if IpucuV then
    local ok, d = pcall(IpucuV, id)
    if ok and d and d.lines then
      for _, l in ipairs(d.lines) do
        if l.leftText and l.leftText ~= "" then t[#t + 1] = l.leftText end
      end
      if t[1] then return t end
    end
  end
  gizli:SetOwner(UIParent, "ANCHOR_NONE")
  gizli:ClearLines()
  local ok = pcall(gizli.SetHyperlink, gizli, "item:" .. id .. ":0:0:0:0:0:0:0")
  if ok then
    for i = 1, gizli:NumLines() do
      local s = _G["WoWTurkceDokumIpucuTextLeft" .. i]
      local x = s and s:GetText()
      if x and x ~= "" then t[#t + 1] = x end
    end
  end
  gizli:Hide()
  return t
end

local function kaydet(id)
  local t = satirlar(id)
  if t[1] then
    WoWTurkce_Dokum.esya[id] = t
    dokum.bulunan = dokum.bulunan + 1
    return true
  end
end

local function var(id)
  if Anlik then
    local ok, r = pcall(Anlik, id)
    return ok and r
  end
  return true
end

local function hazir(id)
  if Hazir then
    local ok, r = pcall(Hazir, id)
    if ok then return r end
  end
  local ok, ad = pcall(Bilgi, id)   -- GetItemInfo: önbellekte yoksa nil döner ve yüklemeyi başlatır
  return ok and ad ~= nil
end

local function iste(id)
  if Iste then pcall(Iste, id) else pcall(Bilgi, id) end
end

local bekleyen, bekleyenSay = {}, 0
local olay = CreateFrame("Frame")
olay:SetScript("OnEvent", function(_, _, id, basarili)
  id = tonumber(id)
  if id and bekleyen[id] then
    bekleyen[id] = nil
    bekleyenSay = bekleyenSay - 1
    if basarili ~= false then pcall(kaydet, id) end
  end
end)

local function durdur(mesaj)
  dokum.aktif = false
  olay:UnregisterAllEvents()
  if mesaj then print("|cff33ff99WoWTürkçe:|r " .. mesaj) end
end

local cerceve = CreateFrame("Frame")
cerceve:Hide()

local function adim(self)
  local n = 0
  local simdi = GetTime()
  -- Yanıt gelmeyen istekleri 10 sn sonra bırak (yoksa döküm hiç bitmez).
  for id, t in pairs(bekleyen) do
    if simdi - t > 10 then
      bekleyen[id] = nil
      bekleyenSay = bekleyenSay - 1
      pcall(kaydet, id)
    end
  end
  while dokum.sira <= dokum.son and n < 200 and bekleyenSay < 40 do
    local id = dokum.sira
    dokum.sira = id + 1
    n = n + 1
    if var(id) and not WoWTurkce_Dokum.esya[id] then
      if hazir(id) then
        kaydet(id)
      else
        bekleyen[id] = simdi
        bekleyenSay = bekleyenSay + 1
        iste(id)
      end
    end
  end
  if dokum.sira > dokum.son and bekleyenSay <= 0 then
    self:Hide()
    durdur("Eşya dökümü bitti: " .. dokum.bulunan .. " eşya. /reload yap ya da oyundan çık; kayıt o zaman dosyaya yazılır.")
  elseif simdi - (dokum.sonBildirim or 0) > 10 then
    dokum.sonBildirim = simdi
    print(("|cff33ff99WoWTürkçe:|r Döküm: %d / %d, bulunan %d"):format(dokum.sira, dokum.son, dokum.bulunan))
  end
end

cerceve:SetScript("OnUpdate", function(self)
  local ok, hata = pcall(adim, self)
  if not ok then
    self:Hide()
    WoWTurkce_Dokum.hata = tostring(hata)
    durdur("Döküm hatası (kaydedildi, sıra " .. tostring(dokum.sira) .. "): " .. tostring(hata) ..
      " — /wt esyadokum " .. tostring(dokum.sira) .. " " .. tostring(dokum.son) .. " ile kaldığın yerden sürdürebilirsin.")
  end
end)

function WT.EsyaDokumBaslat(bas, son)
  WoWTurkce_Dokum = WoWTurkce_Dokum or {}
  WoWTurkce_Dokum.esya = WoWTurkce_Dokum.esya or {}
  WoWTurkce_Dokum.surum = (GetBuildInfo())
  WoWTurkce_Dokum.hata = nil
  wipe(bekleyen); bekleyenSay = 0
  dokum.sira, dokum.son, dokum.bulunan, dokum.aktif, dokum.sonBildirim = bas or 1, son or 300000, 0, true, 0
  pcall(olay.RegisterEvent, olay, "ITEM_DATA_LOAD_RESULT")
  pcall(olay.RegisterEvent, olay, "GET_ITEM_INFO_RECEIVED")
  cerceve:Show()
  print(("|cff33ff99WoWTürkçe:|r Eşya dökümü başladı (%d-%d). Birkaç dakika sürebilir; oyunu kapatmadan bekle."):format(dokum.sira, dokum.son))
end
