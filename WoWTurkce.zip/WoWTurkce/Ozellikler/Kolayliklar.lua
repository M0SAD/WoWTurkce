-- Kolaylıklar (isteğe bağlı, varsayılan kapalı): satıcıda otomatik tamir ve gri eşyaları otomatik satma.
local G = WoWTurkce

local function para(m) return GetCoinTextureString and GetCoinTextureString(m) or tostring(m) end

-- Eski ve yeni çanta işlevleri (Classic Era 1.15 C_Container kullanır)
local C = C_Container
local function slotSayisi(c) return C and C.GetContainerNumSlots and C.GetContainerNumSlots(c) or (GetContainerNumSlots and GetContainerNumSlots(c)) or 0 end
local function esyaBilgi(c, s)
	if C and C.GetContainerItemInfo then
		local i = C.GetContainerItemInfo(c, s)
		if i then return i.hyperlink, i.quality, i.stackCount, i.isLocked, i.hasNoValue end
		return nil
	end
	if GetContainerItemInfo then
		local _, adet, kilit, kalite, _, _, link, _, degersiz = GetContainerItemInfo(c, s)
		return link, kalite, adet, kilit, degersiz
	end
end
local function esyaKullan(c, s)
	if C and C.UseContainerItem then C.UseContainerItem(c, s) elseif UseContainerItem then UseContainerItem(c, s) end
end

local function tamir()
	if not G.ayar("tamir") or not CanMerchantRepair or not CanMerchantRepair() then return end
	local ucret, gerek = GetRepairAllCost()
	if not gerek or not ucret or ucret <= 0 then return end
	if GetMoney() < ucret then
		G.yaz("Tamir için yeterli paran yok (" .. para(ucret) .. ").")
		return
	end
	RepairAllItems()
	G.yaz("Eşyaların tamir edildi: " .. para(ucret))
end

local satilacak, toplam, sayac
local function hurdaSat()
	if not G.ayar("hurda") then return end
	satilacak, toplam = {}, 0
	for c = 0, 4 do
		for s = 1, slotSayisi(c) do
			local link, kalite, adet, kilit, degersiz = esyaBilgi(c, s)
			if link and kalite == 0 and not kilit and not degersiz then
				local fiyat = select(11, (C_Item and C_Item.GetItemInfo or GetItemInfo)(link)) or 0
				if fiyat > 0 then
					satilacak[#satilacak + 1] = { c, s }
					toplam = toplam + fiyat * (adet or 1)
				end
			end
		end
	end
	if #satilacak == 0 then return end
	local i = 0
	if sayac then sayac:Cancel() end
	-- Satıcı sunucuyu boğmasın diye eşyaları birer birer satalım
	sayac = G.olcTicker(0.2, function(t)
		i = i + 1
		local e = satilacak[i]
		if not e or not MerchantFrame or not MerchantFrame:IsShown() then
			t:Cancel(); sayac = nil
			if i > 1 then G.yaz(("Gri eşyalar satıldı (%d adet): %s"):format(i - 1, para(toplam))) end
			return
		end
		esyaKullan(e[1], e[2])
	end)
end

local f = CreateFrame("Frame")
f:RegisterEvent("MERCHANT_SHOW")
f:RegisterEvent("MERCHANT_CLOSED")
f:SetScript("OnEvent", function(_, olay)
	if olay == "MERCHANT_CLOSED" then
		if sayac then sayac:Cancel(); sayac = nil end
		return
	end
	pcall(hurdaSat)
	pcall(tamir)
end)

-- Alt basılı tutulunca her şeyi geçici olarak İngilizce göster; bırakınca Türkçe geri gelir.
-- Sohbete yazarken ya da çatışmada çalışmaz; kısa basışlar (Alt+tık) etkilemez.
local saklanan
local function gecis(ingilizce)
	if (G._shiftEn == true) == ingilizce then return end
	-- İngilizceye geçerken çevrilmiş yazıların listesini sakla: bazı eklentiler (Questie takipçisi gibi)
	-- yazılarını kendileri yenilemez; Alt bırakılınca bu yazılara Türkçeyi biz geri koyarız.
	if ingilizce then
		saklanan = {}
		for fs, k in pairs(G.metinAsil) do saklanan[#saklanan + 1] = { fs, k[1], k[2] } end
	end
	G._shiftEn = ingilizce or nil
	G._shiftGecis = true
	for _, fn in ipairs(G.dinleyiciler) do pcall(fn, "acik", not ingilizce) end
	G._shiftGecis = nil
	if not ingilizce and saklanan then
		for _, e in ipairs(saklanan) do
			pcall(function()
				local fs = e[1]
				if fs:GetText() == e[2] then G.sigdirKoy(fs, e[3]); if fs:GetText() ~= e[3] then fs:SetText(e[3]) end end
			end)
		end
		saklanan = nil
		-- Questie takipçisini yeniden çizdir (Alt basılıyken güncellendiyse İngilizce kalmasın)
		pcall(function()
			local QL = rawget(_G, "QuestieLoader")
			local T = QL and QL.ImportModule and QL:ImportModule("QuestieTracker")
			if T and T.Update then T:Update() end
		end)
	end
	-- Açık ipucunu yenile
	if GameTooltip and GameTooltip:IsShown() then
		local sahip = GameTooltip:GetOwner()
		local f = sahip and sahip.GetScript and sahip:GetScript("OnEnter")
		if f then pcall(f, sahip) end
	end
end
-- Alt durumu her karede yoklanır (olay bazı istemcilerde gelmeyebiliyor); 0.4 sn basılı kalınca geçer.
local basSure, gecen = 0, 0
local sk = CreateFrame("Frame")
sk:RegisterEvent("PLAYER_REGEN_DISABLED")
sk:SetScript("OnEvent", function() if G._shiftEn then gecis(false) end end)
sk:SetScript("OnUpdate", function(_, dt)
	gecen = gecen + dt
	if gecen < 0.05 then return end
	dt, gecen = gecen, 0
	local alt = IsAltKeyDown and IsAltKeyDown()
	if not alt then
		basSure = 0
		if G._shiftEn then gecis(false) end
		return
	end
	if G._shiftEn then return end
	basSure = basSure + dt
	if basSure < 0.4 then return end
	if not G.ayar("shiftEn") or not (WoWTurkce_Ayar == nil or WoWTurkce_Ayar.acik ~= false) then return end
	if InCombatLockdown and InCombatLockdown() then return end
	-- Yalnızca sohbete yazarken engelle (Müzayede arama kutusu gibi odakta kalan kutular Alt'ı kapatmasın)
	if GetCurrentKeyBoardFocus then
		local odak = GetCurrentKeyBoardFocus()
		local oad = odak and odak.GetName and odak:GetName() or ""
		if odak and odak.IsVisible and odak:IsVisible() and (oad:find("^ChatFrame") or oad:find("EditBox") and oad:find("Chat")) then return end
	end
	gecis(true)
end)

-- Türkçe arama: Müzayede Evi'nde Türkçe ad yazınca İngilizcesiyle aranır ("çanta" -> "Bag",
-- "keten kumaş" -> "Linen Cloth"). İngilizce yazılan aramalar olduğu gibi kalır.
local BUYUK = { ["Ç"] = "ç", ["Ş"] = "ş", ["Ğ"] = "ğ", ["Ö"] = "ö", ["Ü"] = "ü", ["İ"] = "i", ["I"] = "ı" }
local function kucuk(s)
	s = s:gsub("[\195\196\197][\128-\191]", function(c) return BUYUK[c] or c end):gsub("I", "ı")
	return (s:gsub("%u", string.lower))
end
local tamAd, kelime, yedek
local function sozlukKur()
	if tamAd then return end
	tamAd, kelime, yedek = {}, {}, {}
	local function ekle(en, tr)
		if type(en) ~= "string" or type(tr) ~= "string" then return end
		tr = tr:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("%s*%(.-%)$", "")
		local k = kucuk(tr)
		-- Aynı Türkçeye birden çok İngilizce düşerse kısa olanı seç ("Kılıç": "Sword", "Swords" değil)
		if tamAd[k] == nil or #en < #tamAd[k] then tamAd[k] = en end
		if not en:find(" ") and not tr:find(" ") then if kelime[k] == nil or #en < #kelime[k] then kelime[k] = en end; return end
		-- Aynı sayıda kelimeli adlarda kelimeleri sırayla eşle ("Heavy Linen Bandage" = "Ağır Keten Sargı")
		local e, t = {}, {}
		for w in en:gmatch("%S+") do e[#e + 1] = w end
		for w in k:gmatch("%S+") do t[#t + 1] = w end
		if #e == #t and #e <= 3 then
			for i = 1, #e do if not e[i]:find("'") and not t[i]:find("'") and yedek[t[i]] == nil then yedek[t[i]] = e[i] end end
		end
	end
	for en, tr in pairs(G.Esya) do if type(en) == "string" and not en:find("[#%%{]") and #en < 40 then ekle(en, tr) end end
	for en, tr in pairs(G.Arayuz) do if type(en) == "string" and not en:find("[#%%{]") and #en < 40 then ekle(en, tr) end end
	for en, tr in pairs(G.EsyaAdi) do ekle(en, tr) end
	for t, e in pairs(yedek) do if kelime[t] == nil then kelime[t] = e end end
	yedek = nil
end
function G.aramaCevir(s)
	if type(s) ~= "string" or s == "" or not G.ayar("acik") then return s end
	sozlukKur()
	local k = kucuk(s:gsub("^%s+", ""):gsub("%s+$", ""))
	if tamAd[k] then return tamAd[k] end
	-- Kelime kelime: hepsi biliniyorsa İngilizce kelimelerle ara
	local out, hepsi, turkce = {}, true, false
	for w in k:gmatch("%S+") do
		local en = kelime[w] or tamAd[w]
		if en then out[#out + 1] = en; turkce = true else out[#out + 1] = w; hepsi = false end
	end
	if turkce and hepsi then return table.concat(out, " ") end
	return s
end
if QueryAuctionItems then
	local asil = QueryAuctionItems
	QueryAuctionItems = function(ad, ...)
		local ok, yeni = pcall(G.aramaCevir, ad)
		return asil(ok and yeni or ad, ...)
	end
end
-- Retail Müzayede Evi: arama sorgusundaki Türkçe adı İngilizceye çevir
if C_AuctionHouse and C_AuctionHouse.SendBrowseQuery and not QueryAuctionItems then
	local asilSorgu = C_AuctionHouse.SendBrowseQuery
	C_AuctionHouse.SendBrowseQuery = function(sorgu, ...)
		if type(sorgu) == "table" and type(sorgu.searchString) == "string" and sorgu.searchString ~= "" then
			local ok, yeni = pcall(G.aramaCevir, sorgu.searchString)
			if ok and yeni and yeni ~= sorgu.searchString then
				local kopya = {}
				for k, v in pairs(sorgu) do kopya[k] = v end
				kopya.searchString = yeni
				return asilSorgu(kopya, ...)
			end
		end
		return asilSorgu(sorgu, ...)
	end
end

-- Diğer eklentilerin açılış mesajlarını gizle (varsayılan açık).
-- Girişte ve /reload sonrası ilk 30 saniyede eklentilerin sohbete doğrudan yazdığı satırlar gizlenir; yalnızca WoWTurkce mesajı kalır.
-- Oyunun olaylarından gelen satırlar (oyuncu, lonca, kanal, sistem) bilgi numarasıyla gelir; bunlara dokunulmaz.
do
	local bitis = 0
	local say = { engellenen = 0, silinen = 0 }
	G.tani = G.tani or {}
	G.tani.ekGizle = say
	local function eklentiMesaji(msg, id)
		if id ~= nil or type(msg) ~= "string" then return false end
		if msg:find("WoWTurkce", 1, true) or msg:find("|Hplayer:", 1, true) or msg:find("|HBNplayer:", 1, true) then return false end
		return true
	end
	local function kur()
		for i = 1, (NUM_CHAT_WINDOWS or 10) do
			local cf = _G["ChatFrame" .. i]
			if cf and cf.AddMessage and not cf._gtrGizle then
				cf._gtrGizle = true
				local asil = cf.AddMessage
				cf._gtrGizleAsil = asil
				cf.AddMessage = function(self, msg, r, g, b, id, ...)
					if GetTime() < bitis and G.ayar("ekGizle") and eklentiMesaji(msg, id) then
						say.engellenen = say.engellenen + 1
						return
					end
					return asil(self, msg, r, g, b, id, ...)
				end
			end
		end
	end
	-- Bizden önce yüklenen eklentilerin zaten yazdığı satırları temizle (yükleme ekranı uzun sürebildiği için zamana bakılmaz)
	local function sil(e, ...)
		local msg, id
		if type(e) == "table" then
			msg = e.message; id = e.extraData and e.extraData[1]
		else
			-- Yerleşik (C) sohbet çerçevesi: (metin, r, g, b, id, ...) gelir
			msg = e; id = select(4, ...)
		end
		if type(msg) ~= "string" then return false end
		if eklentiMesaji(msg, id) then say.silinen = say.silinen + 1; return true end
		return false
	end
	local function temizle()
		if not G.ayar("ekGizle") then return end
		for i = 1, (NUM_CHAT_WINDOWS or 10) do
			local cf = _G["ChatFrame" .. i]
			if cf and cf.RemoveMessagesByPredicate then
				pcall(cf.RemoveMessagesByPredicate, cf, sil)
			elseif cf and cf.historyBuffer and cf.historyBuffer.GetNumElements and cf.Clear then
				-- Eski istemci: kalacakları topla, pencereyi temizle, geri yaz
				local hb, kalan = cf.historyBuffer, {}
				for k = 1, hb:GetNumElements() do
					local e = hb:GetEntryAtIndex(k)
					if type(e) == "table" and not sil(e) then table.insert(kalan, 1, e) end
				end
				cf:Clear()
				local yaz = cf._gtrGizleAsil or cf.AddMessage
				for _, e in ipairs(kalan) do
					local x = e.extraData
					if x then yaz(cf, e.message, e.r, e.g, e.b, unpack(x, 1, x.n or #x)) else yaz(cf, e.message, e.r, e.g, e.b) end
				end
			end
		end
	end
	local f = CreateFrame("Frame")
	f:RegisterEvent("ADDON_LOADED")
	f:RegisterEvent("PLAYER_LOGIN")
	f:RegisterEvent("PLAYER_ENTERING_WORLD")
	f:SetScript("OnEvent", function(self, olay, ad)
		if olay == "ADDON_LOADED" then
			if ad ~= G.ADDON then return end
			bitis = GetTime() + 120
			kur(); temizle()
		elseif olay == "PLAYER_LOGIN" then
			kur(); temizle()
		else
			bitis = GetTime() + 30
			kur(); temizle()
			C_Timer.After(1, temizle); C_Timer.After(5, temizle); C_Timer.After(7.5, temizle); C_Timer.After(12, temizle)
			C_Timer.After(15, function() if WoWTurkce_Ayar then WoWTurkce_Ayar._gizleTani = nil end end)
		end
	end)
end
