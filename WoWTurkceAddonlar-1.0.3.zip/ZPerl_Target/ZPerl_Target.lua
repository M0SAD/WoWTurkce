-- X-Perl UnitFrames
-- Author: Resike
-- License: GNU GPL v3, 29 June 2007 (see LICENSE.txt)

local XPerl_Target_Events = { }
local conf, tconf, fconf
XPerl_RequestConfig(function(new)
	conf = new
	tconf = conf.target
	fconf = conf.focus
	if (XPerl_Target) then
		XPerl_Target.conf = conf.target
	end
	if (XPerl_Focus) then
		XPerl_Focus.conf = conf.focus
	end
	if (XPerl_TargetTarget) then
		XPerl_TargetTarget.conf = conf.targettarget
	end
	if (XPerl_FocusTarget) then
		XPerl_FocusTarget.conf = conf.focustarget
	end
	if (XPerl_PetTarget) then
		XPerl_PetTarget.conf = conf.pettarget
	end
end, "$Revision:  $")

local IsVanillaClassic = WOW_PROJECT_ID == WOW_PROJECT_CLASSIC

-- Secret value helpers from ZPerl.lua
local XPerl_CanAccess = XPerl_CanAccess
local XPerl_IsSecret = XPerl_IsSecret
local XPerl_GetPowerPercent = XPerl_GetPowerPercent
local XPerl_GetHealthPercent = XPerl_GetHealthPercent
local XPerl_SetAlphaFromBoolean = XPerl_SetAlphaFromBoolean
local XPerl_SafeBool = XPerl_SafeBool
local XPerl_AurasSecret = XPerl_AurasSecret
local XPerl_AuraContainer_SafeToReconfigure = XPerl_AuraContainer_SafeToReconfigure

local LCD = IsVanillaClassic and XPerl_ForeverAPI and XPerl_ForeverAPI.combatLog and LibStub and LibStub("LibClassicDurations", true)
if LCD then
	LCD.RegisterCallback("ZPerl", "UNIT_BUFF", function(event, unit)
		if unit ~= "target" then
			return
		end
		XPerl_Target_Events:UNIT_AURA(event, unit)
	end)
end

-- Upvalues
local _G = _G
local bit_band = bit.band
local format = format
local max = max
local pairs = pairs
local pcall = pcall
local select = select
local string = string
local tinsert = tinsert
local tonumber = tonumber
local tostring = tostring
local type = type
local unpack = unpack
local setmetatable = setmetatable
local hooksecurefunc = hooksecurefunc

local Enum = Enum

local CanInspect = CanInspect
local CheckInteractDistance = CheckInteractDistance
local CombatFeedbackText = CombatFeedbackText
local CombatLogGetCurrentEventInfo = CombatLogGetCurrentEventInfo
local GetComboPoints = GetComboPoints
-- True on any client with the secret-value system.
local XPerl_RestrictedClient = (issecretvalue ~= nil)
-- GetDifficultyColor takes a difficulty category here, not a level;
-- handed a level it matches nothing and always returns the same yellow.
local GetDifficultyColor = GetDifficultyColor
local GetCreatureDifficultyColor = GetCreatureDifficultyColor or GetQuestDifficultyColor
local GetInspectSpecialization = GetInspectSpecialization
local GetLootMethod = GetLootMethod or C_PartyInfo.GetLootMethod
local GetNumGroupMembers = GetNumGroupMembers
local GetRaidRosterInfo = GetRaidRosterInfo
local GetSpecializationInfoByID = GetSpecializationInfoByID
local GetSpellInfo = GetSpellInfo
local GetTime = GetTime
local InCombatLockdown = InCombatLockdown
local NotifyInspect = NotifyInspect
local PlaySound = PlaySound
local RegisterUnitWatch = RegisterUnitWatch
local UnitAffectingCombat = UnitAffectingCombat
local UnitBattlePetType = UnitBattlePetType
local UnitCanAssist = UnitCanAssist
local UnitCanAttack = UnitCanAttack
local UnitClass = UnitClass
local UnitClassBase = UnitClassBase
local UnitClassification = UnitClassification
local UnitCreatureType = UnitCreatureType
local UnitExists = UnitExists
local UnitFactionGroup = UnitFactionGroup
local UnitGUID = UnitGUID
local UnitHasVehicleUI = UnitHasVehicleUI
local UnitInParty = UnitInParty
local UnitInRaid = UnitInRaid
local UnitInRange = UnitInRange
local UnitInVehicle = UnitInVehicle
local UnitIsAFK = UnitIsAFK
local UnitIsBattlePet = UnitIsBattlePet
local UnitIsBattlePetCompanion = UnitIsBattlePetCompanion
local UnitIsCharmed = UnitIsCharmed
local UnitIsConnected = UnitIsConnected
local UnitIsDead = UnitIsDead
local UnitIsDeadOrGhost = UnitIsDeadOrGhost
local UnitIsEnemy = UnitIsEnemy
local UnitIsFriend = UnitIsFriend
local UnitIsGhost = UnitIsGhost
local UnitIsGroupAssistant = UnitIsGroupAssistant
local UnitIsGroupLeader = UnitIsGroupLeader
local UnitIsMercenary = UnitIsMercenary
local UnitIsPlayer = UnitIsPlayer
local UnitIsPVP = UnitIsPVP
local UnitIsPVPFreeForAll = UnitIsPVPFreeForAll
local UnitIsUnit = UnitIsUnit
local UnitIsVisible = UnitIsVisible
local UnitIsWildBattlePet = UnitIsWildBattlePet
local UnitLevel = UnitLevel
local UnitName = UnitName
local UnitPlayerControlled = UnitPlayerControlled
local UnitPower = UnitPower
local UnitPowerMax = UnitPowerMax
local UnregisterUnitWatch = UnregisterUnitWatch

local CombatFeedback_Initialize = CombatFeedback_Initialize
local CombatFeedback_OnUpdate = CombatFeedback_OnUpdate

local percD = "%d"..PERCENT_SYMBOL
local buffSetup
local lastInspectPending = 0

local ComboEventFrame = CreateFrame("Frame")

-- Loading Function
function XPerl_Target_OnLoad(self, partyid)
	self:RegisterForClicks("AnyUp")
	self:RegisterForDrag("LeftButton")
	XPerl_SetChildMembers(self)

	CombatFeedback_Initialize(self, self.hitIndicator.text, 30)

	self.hitIndicator.text:SetPoint("CENTER", self.portraitFrame, "CENTER", 0, 0)

	local events = {
		"UNIT_COMBAT",
		"PLAYER_FLAGS_CHANGED",
		"UNIT_CONNECTION",
		"UNIT_PHASE",
		"RAID_TARGET_UPDATE",
		"GROUP_ROSTER_UPDATE",
		"PARTY_LEADER_CHANGED",
		"PARTY_LOOT_METHOD_CHANGED",
		"UNIT_THREAT_LIST_UPDATE",
		"UNIT_FACTION",
		"UNIT_FLAGS",
		"UNIT_CLASSIFICATION_CHANGED",
		"UNIT_PORTRAIT_UPDATE",
		"UNIT_AURA",
		XPerl_ForeverAPI.healthEvent,
		"UNIT_MAXHEALTH",
		"UNIT_ABSORB_AMOUNT_CHANGED",
		"UNIT_POWER_FREQUENT",
		"UNIT_MAXPOWER",
		"UNIT_LEVEL",
		"UNIT_DISPLAYPOWER",
		"UNIT_NAME_UPDATE",
		"INCOMING_RESURRECT_CHANGED",
	}
	for i, event in pairs(events) do
		if string.find(event, "^UNIT_") or string.find(event, "^INCOMING") then
			if pcall(self.RegisterUnitEvent, self, event, partyid) then
				self:RegisterUnitEvent(event, partyid)
			end
		else
			if pcall(self.RegisterEvent, self, event) then
				self:RegisterEvent(event)
			end
		end
	end

	XPerl_Highlight:Register(XPerl_Target_HighlightCallback, self)

	self.partyid = partyid
	if (partyid == "target") then
		XPerl_BlizzFrameDisable(TargetFrame)
		XPerl_BlizzFrameDisable(TargetofTargetFrame)

		self.statsFrame.focusTarget:SetVertexColor(0.7, 1, 1, 0.5)

		self:RegisterEvent("PLAYER_TARGET_CHANGED")
		self:RegisterEvent("PLAYER_FOCUS_CHANGED")

		if (XPerl_Target_Events.INSPECT_READY) then
			self:RegisterEvent("INSPECT_READY")
		end

		self.nameFrame.cpMeter:SetFrameLevel(2)
		self.nameFrame.cpMeter:GetStatusBarTexture():SetHorizTile(false)
		self.nameFrame.cpMeter:GetStatusBarTexture():SetVertTile(false)

		-- Blizzard's ComboFrame, when the client has one.
		if (ComboFrame) then
			local parenting
			hooksecurefunc(ComboFrame, "SetParent", function(self)
				if parenting then
					return
				end
				if not InCombatLockdown() then
					parenting = true
					self:SetParent(XPerl_Target)
					parenting = nil
				end
			end)

			ComboFrame:SetParent(XPerl_Target)
		end

		self.combatMask = 0x00010000
	else
		XPerl_BlizzFrameDisable(FocusFrame)

		self:RegisterEvent("PLAYER_FOCUS_CHANGED")
		self:RegisterEvent("PLAYER_ENTERING_WORLD")
		self.combatMask = 0x00020000
	end
	self:RegisterEvent("PLAYER_REGEN_ENABLED")
	self:RegisterEvent("PLAYER_REGEN_DISABLED")

	local BuffOnUpdate, DebuffOnUpdate, BuffUpdateTooltip, DebuffUpdateTooltip
	BuffUpdateTooltip = XPerl_Unit_SetBuffTooltip
	DebuffUpdateTooltip = XPerl_Unit_SetDeBuffTooltip

	if (buffSetup) then
		self.buffSetup = buffSetup
	else
		self.buffSetup = {
			rightClickable = true,
			buffScripts = {
				OnEnter = XPerl_Unit_SetBuffTooltip,
				OnUpdate = BuffOnUpdate,
				OnLeave = XPerl_PlayerTipHide,
				OnClick = function(self, button)
					if button == "RightButton" then
						local unitFrame = self:GetParent():GetParent()
						if unitFrame and unitFrame.partyid and UnitIsUnit(unitFrame.partyid, "player") then
							CancelUnitBuff("player", self:GetID(), self.filter)
						end
					end
				end,
			},
			debuffScripts = {
				OnEnter = XPerl_Unit_SetDeBuffTooltip,
				OnUpdate = DebuffOnUpdate,
				OnLeave = XPerl_PlayerTipHide,
			},
			updateTooltipBuff = BuffUpdateTooltip,
			updateTooltipDebuff = DebuffUpdateTooltip,
			debuffParent = true,
			splitAbove = true,
			debuffSizeMod = 0.2,
			debuffAnchor1 = function(self, b)
				b:SetPoint("TOPLEFT", 0, 0)
			end,
		}
		self.buffSetup.buffAnchor1 = self.buffSetup.debuffAnchor1
		buffSetup = self.buffSetup
	end

	self.nameFrame:SetAttribute("*type1", "target")
	self.nameFrame:SetAttribute("type2", "togglemenu")
	self.nameFrame:SetAttribute("unit", partyid)

	self:SetAttribute("*type1", "target")
	self:SetAttribute("type2", "togglemenu")
	self:SetAttribute("unit", partyid)

	XPerl_RegisterClickCastFrame(self.nameFrame)
	XPerl_RegisterClickCastFrame(self)

	self.perlBuffs, self.perlDebuffs, self.time = 0, 0, 0

	if (partyid == "target" and XPerl_Target_AssistFrame) then
		-- Since target module is loaded after raid helper, we have to attach this manually
		-- because the target frame did not exist when this frame was created
		XPerl_Target_AssistFrame:SetParent(self)
		XPerl_Target_AssistFrame:ClearAllPoints()
		XPerl_Target_AssistFrame:SetPoint("TOPLEFT", self.portraitFrame, "TOPRIGHT", -2, -20)
		XPerl_Target_AssistFrame:Raise()
	end

	XPerl_RegisterHighlight(self.highlight, 3)
	XPerl_RegisterPerlFrames(self, {self.nameFrame, self.statsFrame, self.levelFrame, self.portraitFrame, self.typeFramePlayer, self.creatureTypeFrame, self.bossFrame, self.cpFrame})

	self.FlashFrames = {self.portraitFrame, self.nameFrame, self.levelFrame, self.statsFrame, self.bossFrame, self.typeFramePlayer, self.typeFrame}

	if (XPerl_ArcaneBar_RegisterFrame) then
		XPerl_ArcaneBar_RegisterFrame(self.nameFrame, partyid)
	end

	if (XPerlDB) then
		self.conf = XPerlDB[partyid]
	end

	XPerl_RegisterOptionChanger(XPerl_Target_Set_Bits, self)

	if (XPerl_Target and XPerl_Focus) then
		XPerl_Target_OnLoad = nil
	end
end

-- XPerl_Raid_HighlightCallback
function XPerl_Target_HighlightCallback(self, updateGUID)
	local guid = UnitGUID(self.partyid)
	if (guid and XPerl_CanAccess(guid) and guid == updateGUID and UnitIsFriend("player", self.partyid)) then
		XPerl_Highlight:SetHighlight(self, updateGUID)
	end
end

-- Buff Functions

local function XPerl_Target_BuffPositions(self)
	-- Even a direct unit like "target"/"focus" can have a secret
	-- identity inside an instance, and so a secret UnitCanAttack.
	if (self.partyid and XPerl_SafeBool(UnitCanAttack("player", self.partyid), false)) then
		XPerl_Unit_BuffPositions(self, self.buffFrame.debuff, self.buffFrame.buff, self.conf.debuffs.size, self.conf.buffs.size)
	else
		XPerl_Unit_BuffPositions(self, self.buffFrame.buff, self.buffFrame.debuff, self.conf.buffs.size, self.conf.debuffs.size)
	end
end

-- AuraContainer: real icons while auras are secret (see XPerl_AuraContainer_Create).

-- Re-anchors existing holders only. The second group anchors to the first
-- container, which grows with its rows.
local function XPerl_Target_AuraContainer_ApplyOrder(self)
	if (not self or not self.buffHalfFrame or not self.debuffHalfFrame or not self.buffContainer) then
		return
	end

	local buffsFirst = not XPerl_SafeBool(UnitCanAttack("player", self.partyid), false)
	local first, second = self.buffHalfFrame, self.debuffHalfFrame
	local firstContainer, firstEnabled = self.buffContainer, self.conf.buffs.enable
	if (not buffsFirst) then
		first, second = self.debuffHalfFrame, self.buffHalfFrame
		firstContainer, firstEnabled = self.debuffContainer, self.conf.debuffs.enable
	end

	first:ClearAllPoints()
	second:ClearAllPoints()
	if (XPerl_DebuffsStayBelow(self.conf)) then
		-- Only the buffs go above; the debuffs keep their box below
		self.buffHalfFrame:SetPoint("BOTTOMLEFT", self.buffFrame, "BOTTOMLEFT", 0, 0)
		self.debuffHalfFrame:SetPoint("TOPLEFT", self.debuffFrame, "TOPLEFT", 0, 0)
	elseif (self.conf.buffs.above) then
		-- Both go above, growing up, the first group nearest the frame
		first:SetPoint("BOTTOMLEFT", self.buffFrame, "BOTTOMLEFT", 0, 0)
		if (firstEnabled) then
			second:SetPoint("BOTTOMLEFT", firstContainer, "TOPLEFT", 0, 2)
		else
			second:SetPoint("BOTTOMLEFT", self.buffFrame, "BOTTOMLEFT", 0, 0)
		end
	else
		first:SetPoint("TOPLEFT", self.buffFrame, "TOPLEFT", 0, 0)
		if (firstEnabled) then
			second:SetPoint("TOPLEFT", firstContainer, "BOTTOMLEFT", 0, -2)
		else
			second:SetPoint("TOPLEFT", self.buffFrame, "TOPLEFT", 0, 0)
		end
	end
end

local function XPerl_Target_AuraContainer_Setup(self)
	if (not XPerl_HasAuraContainerNow() or self.buffContainer) then
		return
	end

	-- XPerlDB.buffs.cooldown is one global setting for buffs and debuffs by design.
	local showSwipe = conf.buffs.cooldown and true or false
	local buffs, debuffs = self.conf.buffs, self.conf.debuffs
	-- Wrap where the frame's own icons wrap, so extra frame width counts here too.
	local rowWidth = XPerl_Unit_AuraRowWidth(self)
	local lineSize = buffs.wrap and rowWidth or 2000
	-- The container has no row limit of its own; capping the icon count keeps
	-- it to the Buff Rows setting when combatRows is on.
	local limit = buffs.wrap and buffs.combatRows
	local maxBuffs = limit and XPerl_AuraContainer_MaxFrames(lineSize, buffs.size, buffs.rows) or nil
	local maxDebuffs = limit and XPerl_AuraContainer_MaxFrames(lineSize, debuffs.size, buffs.rows) or nil
	-- Big Buffs / Big Debuffs: the player's own come first at their Big size, as
	-- out of combat. With both groups in one flow the row limit is approximate.
	local bigBuffSize = buffs.big and (((buffs.bigSize or 0) >= buffs.size) and buffs.bigSize or buffs.size * 2) or nil
	local bigDebuffSize = debuffs.big and (((debuffs.bigSize or 0) >= debuffs.size) and debuffs.bigSize or debuffs.size * 2) or nil
	local maxBigBuffs = bigBuffSize and limit and XPerl_AuraContainer_MaxFrames(lineSize, bigBuffSize, buffs.rows) or nil
	local maxBigDebuffs = bigDebuffSize and limit and XPerl_AuraContainer_MaxFrames(lineSize, bigDebuffSize, buffs.rows) or nil

	-- Castable Buffs Only, as the classic icons apply it (RAID: buffs the player can
	-- cast). Curable Debuffs Only applies to friendly units only, which a filter fixed
	-- at creation cannot follow, so debuffs stay unfiltered here.
	local buffFilter = (buffs.castable == 1) and "HELPFUL|RAID" or "HELPFUL"

	-- buffFrame and debuffFrame are one XML rectangle, so the two containers
	-- stack inside it, friend/enemy deciding which comes first.
	local buffContainer, buffHalf = XPerl_AuraContainer_Create(self, "buffHalfFrame",
		self:GetName().."AuraBuffs", "buffs", buffFilter, buffs.size, lineSize, showSwipe, maxBuffs, bigBuffSize, maxBigBuffs)
	local debuffContainer, debuffHalf = XPerl_AuraContainer_Create(self, "debuffHalfFrame",
		self:GetName().."AuraDebuffs", "debuffs", "HARMFUL", debuffs.size, lineSize, showSwipe, maxDebuffs, bigDebuffSize, maxBigDebuffs)
	if (not buffContainer or not debuffContainer or not buffHalf or not debuffHalf) then
		return
	end

	-- A holder with no size leaves its container drawing nothing.
	buffHalf:SetSize(max(rowWidth, buffs.size), buffs.size)
	debuffHalf:SetSize(max(rowWidth, debuffs.size), debuffs.size)
	if (buffs.above) then
		XPerl_AuraContainer_GrowUp(buffContainer, buffHalf)
		if (not XPerl_DebuffsStayBelow(self.conf)) then
			XPerl_AuraContainer_GrowUp(debuffContainer, debuffHalf)
		end
	end

	self.buffContainer, self.debuffContainer = buffContainer, debuffContainer
	XPerl_Target_AuraContainer_ApplyOrder(self)
end

local function XPerl_Target_AuraContainer_Rebuild(self, runNow)
	if (not XPerl_HasAuraContainerNow()) then
		return
	end
	if (not runNow and C_Timer and C_Timer.After) then
		if (self.auraContainerRebuildScheduled) then
			return
		end
		self.auraContainerRebuildScheduled = true
		C_Timer.After(0, function()
			if (not self) then
				return
			end
			self.auraContainerRebuildScheduled = nil
			XPerl_Target_AuraContainer_Rebuild(self, true)
		end)
		return
	end
	-- Nothing live to disturb yet, so build even while secret -- otherwise a
	-- container nil'd mid-fight stays blank until combat ends.
	if (not self.buffContainer) then
		XPerl_Target_AuraContainer_Setup(self)
		return
	end
	if (not XPerl_AuraContainer_SafeToReconfigure()) then
		self.auraContainerPending = true
		return
	end
	self.auraContainerPending = nil
	if (self.buffContainer) then
		self.buffContainer:Hide()
		self.debuffContainer:Hide()
		self.buffContainer, self.debuffContainer = nil, nil
	end
	XPerl_Target_AuraContainer_Setup(self)
end

-- XPerl_Target_AuraContainer_Show / _Hide
local function XPerl_Target_AuraContainer_Show(self)
	XPerl_AuraContainer_ShowPair(self, self.conf.buffs.enable, self.conf.debuffs.enable)
end

local function XPerl_Target_AuraContainer_Hide(self)
	self.buffContainer:Hide()
	self.debuffContainer:Hide()
	if (self.auraContainerPending) then
		XPerl_Target_AuraContainer_Rebuild(self)
	end
end

function XPerl_Targets_BuffUpdate(self)
	if (not self.conf.buffs.enable and not self.conf.debuffs.enable) then
		self.buffFrame:Hide()
		self.debuffFrame:Hide()
		self.buffDisplayPath = nil
		if (self.buffContainer) then
			XPerl_Target_AuraContainer_Hide(self)
		end
		return
	end

	if (not self.buffContainer and XPerl_AurasSecret()) then
		self.buffDisplayPath = "frozen"
		if (self.conf.buffs.enable) then
			self.buffFrame:Show()
		else
			self.buffFrame:Hide()
		end
		if (self.conf.debuffs.enable) then
			self.debuffFrame:Show()
		else
			self.debuffFrame:Hide()
		end
		return
	end

	local inCombat = InCombatLockdown and InCombatLockdown()
	local keepContainer = self.buffContainer and (XPerl_AurasSecret() or (inCombat and self.buffDisplayPath == "container" and not conf.buffs.ignoreSeasonal))

	if (keepContainer) then
		self.buffFrame:Hide()
		self.debuffFrame:Hide()
		XPerl_Target_AuraContainer_ApplyOrder(self)
		XPerl_Target_AuraContainer_Show(self)
		self.buffDisplayPath = "container"
	else
		if (self.buffContainer) then
			XPerl_Target_AuraContainer_Hide(self)
			self.buffFrame:Show()
			self.debuffFrame:Show()
		end
		self.buffDisplayPath = "classic"
		XPerl_Unit_UpdateBuffs(self, nil, nil, self.conf.buffs.castable, self.conf.debuffs.curable)
		XPerl_Target_BuffPositions(self)
	end
end

-- Frame levels above the target frame for the segmented bar and the dots. The aura
-- containers start 10 above it and their buttons, cooldowns and timer text stack a few
-- more, so this clears them when buffs or debuffs share the combo display's edge.
local COMBO_ABOVE_AURAS = 20

-- Where the segmented strip sits (tconf.combo.barPos): above the name (default),
-- below the frame, or above or below the portrait. Below the portrait it clears the
-- creature type box when that is shown; without a portrait it falls back to the name.
local function XPerl_Target_ComboBarPlace(self, meter)
	local pos = tconf.combo.barPos
	local portrait = tconf.portrait and self.portraitFrame
	meter:ClearAllPoints()
	if (pos == "below") then
		meter:SetPoint("TOPLEFT", self.statsFrame, "BOTTOMLEFT", 6, -1)
		meter:SetPoint("TOPRIGHT", self.statsFrame, "BOTTOMRIGHT", -6, -1)
	elseif (pos == "portraitTop" and portrait) then
		meter:SetPoint("BOTTOMLEFT", portrait, "TOPLEFT", 4, 1)
		meter:SetPoint("BOTTOMRIGHT", portrait, "TOPRIGHT", -4, 1)
	elseif (pos == "portraitBottom" and portrait) then
		local drop = tconf.mobType and -21 or -1
		meter:SetPoint("TOPLEFT", portrait, "BOTTOMLEFT", 4, drop)
		meter:SetPoint("TOPRIGHT", portrait, "BOTTOMRIGHT", -4, drop)
	else
		meter:SetPoint("BOTTOMLEFT", self.nameFrame, "TOPLEFT", 6, 1)
		meter:SetPoint("BOTTOMRIGHT", self.nameFrame, "TOPRIGHT", -6, 1)
	end
end

-- Two combo meter looks (tconf.combo.segmented): the XML's faint tint inside the
-- name frame, or a thin strip with its own backing. Switchable without a reload.
local function XPerl_Target_ComboMeterLayout(self)
	local meter = self.nameFrame.cpMeter
	local segmented = tconf.combo.segmented and true or false
	local layoutKey = segmented and format("%s:%s:%s", tostring(tconf.combo.barPos), tostring(tconf.portrait), tostring(tconf.mobType)) or false
	if (meter.segmentedLayout == layoutKey) then
		return
	end
	meter.segmentedLayout = layoutKey

	if (not segmented) then
		-- Back to the XML's own layout, and drop the segmented-only art.
		meter:ClearAllPoints()
		meter:SetPoint("TOPLEFT", self.nameFrame, "TOPLEFT", 6, -6)
		meter:SetPoint("BOTTOMRIGHT", self.nameFrame, "BOTTOMRIGHT", -6, 6)
		if (meter.backing) then
			meter.backing:Hide()
		end
		if (meter.edges) then
			for i = 1, #meter.edges do
				meter.edges[i]:Hide()
			end
		end
		if (meter.segments) then
			for i = 1, #meter.segments do
				meter.segments[i]:Hide()
			end
		end
		meter.segWidth, meter.segMax = nil, nil
		meter:SetAlpha(1)
		-- Behind the name text, as the XML has it
		meter:SetFrameLevel(2)
		return
	end

	if (not meter.backing) then
		meter.backing = meter:CreateTexture(nil, "BACKGROUND")
		meter.backing:SetColorTexture(0, 0, 0, 0.5)
		meter.backing:SetAllPoints(meter)
	end
	meter.backing:Show()

	-- Outer edge. Combined with the dividers this outlines every segment.
	if (not meter.edges) then
		meter.edges = { }
		for i = 1, 4 do
			local edge = meter:CreateTexture(nil, "OVERLAY")
			edge:SetColorTexture(1, 1, 1, 0.8)
			meter.edges[i] = edge
		end
		local top, bottom, left, right = meter.edges[1], meter.edges[2], meter.edges[3], meter.edges[4]
		top:SetPoint("TOPLEFT")
		top:SetPoint("TOPRIGHT")
		top:SetHeight(1)
		bottom:SetPoint("BOTTOMLEFT")
		bottom:SetPoint("BOTTOMRIGHT")
		bottom:SetHeight(1)
		left:SetPoint("TOPLEFT")
		left:SetPoint("BOTTOMLEFT")
		left:SetWidth(1)
		right:SetPoint("TOPRIGHT")
		right:SetPoint("BOTTOMRIGHT")
		right:SetWidth(1)
	end
	for i = 1, #meter.edges do
		meter.edges[i]:Show()
	end

	XPerl_Target_ComboBarPlace(self, meter)
	meter:SetFrameLevel(self:GetFrameLevel() + COMBO_ABOVE_AURAS)
	-- 1px of this is the white edge top and bottom, so the red fill is height - 2.
	meter:SetHeight(11)
	meter.segWidth, meter.segMax = nil, nil
end

-- Static divider lines that make the combo meter read as pips. One frame per point
-- would need comparing the count, which is secret in combat; the bar takes the
-- count straight into SetValue.
local function XPerl_Target_ComboSegments(self, maxComboPoints)
	if (not tconf.combo.segmented) then
		return
	end
	local meter = self.nameFrame.cpMeter
	if (not maxComboPoints or XPerl_IsSecret(maxComboPoints) or maxComboPoints < 2) then
		maxComboPoints = 5
	end
	local width = meter:GetWidth()
	if (not width or width <= 0) then
		return
	end
	-- Cheap to call on every combo change: only rebuild when something moved.
	if (meter.segWidth == width and meter.segMax == maxComboPoints) then
		return
	end
	meter.segWidth, meter.segMax = width, maxComboPoints

	meter.segments = meter.segments or { }
	for i = 1, maxComboPoints - 1 do
		local divider = meter.segments[i]
		if (not divider) then
			divider = meter:CreateTexture(nil, "OVERLAY")
			divider:SetColorTexture(1, 1, 1, 0.8)
			divider:SetWidth(1)
			meter.segments[i] = divider
		end
		divider:ClearAllPoints()
		divider:SetPoint("TOP", meter, "TOPLEFT", width * (i / maxComboPoints), 0)
		divider:SetPoint("BOTTOM", meter, "BOTTOMLEFT", width * (i / maxComboPoints), 0)
		divider:Show()
	end
	for i = maxComboPoints, #meter.segments do
		meter.segments[i]:Hide()
	end
end

-- Hides the meter at zero combo points without comparing the secret count: a step
-- ColorCurve passed to UnitPowerPercent returns alpha 0 at zero and 1 above, which
-- goes straight into SetAlpha.
local comboAlphaCurve
local function XPerl_Target_ComboAlphaCurve()
	if (comboAlphaCurve or not XPerl_ForeverAPI.colorCurves) then
		return comboAlphaCurve
	end
	local curve = C_CurveUtil.CreateColorCurve()
	curve:SetType(Enum.LuaCurveType.Step)
	-- Domain is 0..1. One point out of five is 0.2, so anything above zero
	-- lands past the 0.1 step.
	curve:AddPoint(0, CreateColor(1, 1, 1, 0))
	curve:AddPoint(0.1, CreateColor(1, 1, 1, 1))
	comboAlphaCurve = curve
	return curve
end

-- Sets region's alpha from a step curve evaluated against the player's combo points.
-- Returns false when the client gives no colour, so the caller can fall back. pcall:
-- UnitPowerPercent may reject a curve for this power type.
local function XPerl_Target_ComboCurveAlpha(region, curve)
	if (not curve or not XPerl_ForeverAPI.powerPercent) then
		return false
	end
	local ok, color = pcall(UnitPowerPercent, "player", Enum.PowerType.ComboPoints, false, curve)
	if (not ok or color == nil or color.a == nil) then
		return false
	end
	return pcall(region.SetAlpha, region, color.a)
end

local function XPerl_Target_ComboAlpha(self)
	local meter = self.nameFrame.cpMeter
	if (not tconf.combo.segmented or not XPerl_ForeverAPI.powerPercent) then
		meter:SetAlpha(1)
		return
	end
	if (not XPerl_Target_ComboCurveAlpha(meter, XPerl_Target_ComboAlphaCurve())) then
		meter:SetAlpha(1)
	end
end

local function GetComboColor(num)
	if (num == 10) then
		return 0.3, 0, 1
	elseif (num == 9) then
		return 0.5, 0, 1
	elseif (num == 8) then
		return 0.7, 0, 1
	elseif (num == 7) then
		return 1, 0, 1
	elseif (num == 6) then
		return 1, 0, 0.5
	elseif (num == 5) then
		return 1, 0, 0
	elseif (num == 4) then
		return 1, 0.5, 0
	elseif (num == 3) then
		return 1, 1, 0
	elseif (num == 2) then
		return 0.5, 1, 0
	elseif (num == 1) then
		return 0, 1, 0
	end
end

-- A druid's combo maximum is 0 outside Cat Form; fall back to five.
local function XPerl_Target_ComboMax()
	local maxComboPoints = UnitPowerMax("player", Enum.PowerType.ComboPoints)
	if (not XPerl_CanAccess(maxComboPoints) or not maxComboPoints or maxComboPoints < 1) then
		return 5
	end
	return maxComboPoints
end

-- A druid holds combo points only while their power is Energy (any Energy form),
-- as Blizzard's own bar decides; otherwise the display is hidden, not emptied.
local function XPerl_Target_ComboHeld()
	local _, class = UnitClass("player")
	if (class ~= "DRUID" or UnitHasVehicleUI("player")) then
		return true
	end
	local powerType = UnitPowerType("player")
	return XPerl_CanAccess(powerType) and powerType == Enum.PowerType.Energy
end

-- Combo point dots (tconf.combo.dots): a row of red points along one edge of the
-- portrait (tconf.combo.pos), or curved round its top right corner ("arc"), or
-- round the ring of a round portrait. The name frame stands in when the portrait
-- is off.
local COMBO_DOT_SIZE, COMBO_DOT_STEP = 12, 11
local COMBO_POINT_TEXTURE = "Interface\\ComboFrame\\ComboPoint"

-- Dot art (tconf.combo.classicArt): the original gold-ringed point at the sizes the
-- original combo frame used, or the newer round atlas. The original art also stands
-- in when the atlas is missing. Its ring fills the top 12x12 of a 12x16 texture, so
-- the textures hang below the dot's frame.
local function XPerl_Target_ComboDotStyle(dot, classic)
	if (dot.classic == classic) then
		return
	end
	dot.classic = classic
	dot.socket:ClearAllPoints()
	dot.lit:ClearAllPoints()
	if (classic) then
		dot.socket:SetPoint("TOPLEFT")
		dot.socket:SetSize(COMBO_DOT_SIZE, 16)
		dot.socket:SetTexture(COMBO_POINT_TEXTURE)
		dot.socket:SetTexCoord(0, 0.375, 0, 1)
		dot.lit:SetPoint("TOPLEFT", 2, 0)
		dot.lit:SetSize(8, 16)
		dot.lit:SetTexture(COMBO_POINT_TEXTURE)
		dot.lit:SetTexCoord(0.375, 0.5625, 0, 1)
	else
		dot.socket:SetAllPoints()
		dot.socket:SetAtlas("uf-roguecp-bg")
		dot.lit:SetPoint("CENTER")
		dot.lit:SetSize(COMBO_DOT_SIZE - 2, COMBO_DOT_SIZE - 2)
		dot.lit:SetAtlas("uf-roguecp-icon-red")
	end
end

local function XPerl_Target_ComboDotsLayout(self)
	if (not tconf.combo.dots) then
		if (self.comboDots) then
			self.comboDots:Hide()
		end
		return
	end

	local count = XPerl_Target_ComboMax()
	local holder = self.comboDots
	if (not holder) then
		holder = CreateFrame("Frame", nil, self)
		holder:SetSize(1, 1)
		holder:SetPoint("CENTER", self.portraitFrame, "CENTER")
		holder.dots = { }
		self.comboDots = holder
	end
	-- Above the portrait, its model and the aura icons, which can sit on the same edge
	holder:SetFrameLevel(self:GetFrameLevel() + COMBO_ABOVE_AURAS)
	for i = #holder.dots + 1, count do
		local dot = CreateFrame("Frame", nil, holder)
		dot:SetSize(COMBO_DOT_SIZE, COMBO_DOT_SIZE)
		dot.socket = dot:CreateTexture(nil, "BACKGROUND")
		dot.lit = dot:CreateTexture(nil, "ARTWORK")
		dot.lit:SetAlpha(0)
		holder.dots[i] = dot
	end
	local classic = (tconf.combo.classicArt or not (C_Texture and C_Texture.GetAtlasInfo and C_Texture.GetAtlasInfo("uf-roguecp-bg"))) and true or false
	for i, dot in ipairs(holder.dots) do
		XPerl_Target_ComboDotStyle(dot, classic)
	end

	local region = tconf.portrait and self.portraitFrame or self.nameFrame
	local pos = tconf.combo.pos
	local half = COMBO_DOT_STEP * (count - 1) / 2
	for i, dot in ipairs(holder.dots) do
		dot:ClearAllPoints()
		if (i > count) then
			dot:Hide()
		else
			local point, x, y
			if (pos == "arc" and tconf.portrait and tconf.portraitRound) then
				-- Round portrait: just outside the ring, close together from about one
				-- o'clock round to four, as the original round frame had them
				local angle = math.rad(50 - (i - 1) * 20)
				point, x, y = "CENTER", 36 * math.cos(angle), 36 * math.sin(angle)
			elseif (pos == "arc") then
				-- From the top edge round to the right edge, centred just inside the
				-- corner so the middle dot sits on the corner itself
				local angle = math.rad(120 - (i - 1) * 150 / max(count - 1, 1))
				point, x, y = "TOPRIGHT", -13 + 20 * math.cos(angle), -13 + 20 * math.sin(angle)
			elseif (pos == "bottom") then
				point, x, y = "BOTTOM", (i - 1) * COMBO_DOT_STEP - half, 0
			elseif (pos == "left") then
				point, x, y = "LEFT", 0, half - (i - 1) * COMBO_DOT_STEP
			elseif (pos == "right") then
				point, x, y = "RIGHT", 0, half - (i - 1) * COMBO_DOT_STEP
			else
				point, x, y = "TOP", (i - 1) * COMBO_DOT_STEP - half, 0
			end
			dot:SetPoint("CENTER", region, point, x, y)
			dot:Show()
		end
	end
	holder.count = count
	holder:Show()
end

-- One step curve per dot: dot i of count lights once the points reach i, so a
-- secret count never needs comparing.
local comboDotCurves = { }
local function XPerl_Target_ComboDotCurve(index, count)
	local key = count * 100 + index
	local curve = comboDotCurves[key]
	if (curve or not XPerl_ForeverAPI.colorCurves) then
		return curve
	end
	curve = C_CurveUtil.CreateColorCurve()
	curve:SetType(Enum.LuaCurveType.Step)
	curve:AddPoint(0, CreateColor(1, 1, 1, 0))
	curve:AddPoint((index - 0.5) / count, CreateColor(1, 1, 1, 1))
	comboDotCurves[key] = curve
	return curve
end

local function XPerl_Target_UpdateComboDots(self, comboPoints, show)
	if (not tconf.combo.dots or not show) then
		if (self.comboDots) then
			self.comboDots:Hide()
		end
		return
	end
	local count = XPerl_Target_ComboMax()
	if (not self.comboDots or self.comboDots.count ~= count or not self.comboDots:IsShown()) then
		XPerl_Target_ComboDotsLayout(self)
	end
	local holder = self.comboDots
	if (XPerl_CanAccess(comboPoints) and comboPoints ~= nil) then
		holder:SetAlpha(comboPoints > 0 and 1 or 0)
		for i = 1, count do
			holder.dots[i].lit:SetAlpha(i <= comboPoints and 1 or 0)
		end
	else
		-- Secret: the sockets hide at zero points and each dot lights from its curve.
		-- Without curves the sockets show unlit, since nothing can read the count.
		if (not XPerl_Target_ComboCurveAlpha(holder, XPerl_Target_ComboAlphaCurve())) then
			holder:SetAlpha(1)
		end
		for i = 1, count do
			local lit = holder.dots[i].lit
			if (not XPerl_Target_ComboCurveAlpha(lit, XPerl_Target_ComboDotCurve(i, count))) then
				lit:SetAlpha(0)
			end
		end
	end
end

-- Combo Points
local function XPerl_Target_UpdateCombo(self)
	if (not XPerl_Target_ComboHeld()) then
		self.nameFrame.cpMeter:Hide()
		self.cpFrame:Hide()
		XPerl_Target_UpdateComboDots(self, nil, false)
		return
	end
	local comboPoints = GetComboPoints("player", "target")
	XPerl_Target_UpdateComboDots(self, comboPoints, not UnitIsDeadOrGhost("target") and UnitCanAttack(UnitHasVehicleUI("player") and "vehicle" or "player", "target"))
	-- A secret count still shows (SetValue and SetText take it), but GetComboColor
	-- cannot run on it, so it is coloured neutrally rather than hidden.
	local secretCombo = XPerl_IsSecret(comboPoints)
	local r, g, b
	if not secretCombo then
		r, g, b = GetComboColor(comboPoints)
	end
	if tconf.combo.enable and not UnitIsDeadOrGhost("target") and UnitCanAttack(UnitHasVehicleUI("player") and "vehicle" or "player", "target") then
		-- Re-read the maximum every time. A druid's is 0 outside cat
		-- form, so a bar sized while in caster form would never fill.
		local maxComboPoints = XPerl_Target_ComboMax()
		self.nameFrame.cpMeter:SetMinMaxValues(0, maxComboPoints)
		self.nameFrame.cpMeter:SetValue(comboPoints)
		XPerl_Target_ComboSegments(self, maxComboPoints)
		XPerl_Target_ComboAlpha(self)
		self.nameFrame.cpMeter:Show()
		if r and g and b then
			self.nameFrame.cpMeter:SetStatusBarColor(r, g, b, 0.7)
		elseif secretCombo then
			self.nameFrame.cpMeter:SetStatusBarColor(1, 0, 0, 0.8)
		else
			self.nameFrame.cpMeter:Hide()
		end
	else
		self.nameFrame.cpMeter:Hide()
	end

	if tconf.comboindicator.enable and not UnitIsDeadOrGhost("target") and UnitCanAttack(UnitHasVehicleUI("player") and "vehicle" or "player", "target") then
		self.cpFrame:Show()
		self.cpFrame.text:SetText(comboPoints)
		if r and g and b then
			self.cpFrame.text:SetTextColor(r, g, b)
		elseif secretCombo then
			self.cpFrame.text:SetTextColor(1, 1, 1)
		else
			self.cpFrame:Hide()
		end
	else
		self.cpFrame:Hide()
	end
end

-- The Update Functions
local function XPerl_Target_UpdatePVP(self)
	local partyid = self.partyid

	local pvpIcon = self.nameFrame.pvp

	local factionGroup, factionName = UnitFactionGroup(partyid)
	-- An enemy player's PvP flag is secret in PvP, so the badge is shown and the
	-- flag decides its alpha
	local flagged = UnitIsPVP(partyid)

	pvpIcon:SetAlpha(1)
	if self.conf.pvpIcon and UnitIsPVPFreeForAll(partyid) then
		pvpIcon.icon:SetTexture("Interface\\TargetingFrame\\UI-PVP-FFA")
		pvpIcon:Show()
	elseif self.conf.pvpIcon and factionGroup and XPerl_CanAccess(factionGroup) and factionGroup ~= "Neutral" and (XPerl_IsSecret(flagged) or flagged) then
		pvpIcon.icon:SetTexture("Interface\\TargetingFrame\\UI-PVP-"..factionGroup)
		XPerl_SetAlphaFromBoolean(pvpIcon, flagged, 1, 0)

		if type(UnitIsMercenary) == "function" and UnitIsMercenary(partyid) then
			if factionGroup == "Horde" then
				pvpIcon.icon:SetTexture("Interface\\TargetingFrame\\UI-PVP-Alliance")
			elseif factionGroup == "Alliance" then
				pvpIcon.icon:SetTexture("Interface\\TargetingFrame\\UI-PVP-Horde")
			end
		end

		pvpIcon:Show()
	else
		pvpIcon:Hide()
	end

	if (self.conf.reactionHighlight) then
		local c = XPerl_ReactionColour(partyid)
		self.nameFrame:SetBackdropColor(c.r, c.g, c.b)

		if (conf.colour.class and UnitPlayerControlled(partyid)) then
			XPerl_SetUnitNameColor(self.nameFrame.text, partyid)
		else
			self.nameFrame.text:SetTextColor(1, 1, 1, conf.transparency.text)
		end
	else
		if not self.conf.highlightDebuffs.enable then
			self.nameFrame:SetBackdropColor(conf.colour.frame.r, conf.colour.frame.g, conf.colour.frame.b, conf.colour.frame.a)
		end
		XPerl_SetUnitNameColor(self.nameFrame.text, partyid)
	end

	-- Indirect units can return secret flags; no icon in that case
	if XPerl_SafeBool(UnitIsVisible(partyid), false) and XPerl_SafeBool(UnitIsCharmed(partyid), false) and XPerl_SafeBool(UnitIsPlayer(partyid), false) then
		self.nameFrame.warningIcon:Show()
	else
		self.nameFrame.warningIcon:Hide()
	end
end

local function XPerl_Target_UpdateName(self)
	-- UnitName's second value is Forever's surname, so the full name is shown.
	self.nameFrame.text:SetText(XPerl_UnitFullName(self.partyid))
	XPerl_Target_UpdatePVP(self)
end

-- An enemy's level is coloured by the client's difficulty rating, as Blizzard's
-- target frame does; anything else by its level against yours.
local function XPerl_Target_LevelColour(unit, level)
	local getDifficulty = C_PlayerInfo and C_PlayerInfo.GetContentDifficultyCreatureForPlayer
	if (getDifficulty and GetDifficultyColor and XPerl_SafeBool(UnitCanAttack("player", unit), false)) then
		local difficulty = getDifficulty(unit)
		if (difficulty ~= nil and XPerl_CanAccess(difficulty)) then
			return GetDifficultyColor(difficulty)
		end
	end
	return GetCreatureDifficultyColor(level)
end

local function XPerl_Target_UpdateLevel(self)
	local targetlevel = UnitLevel(self.partyid)
	self.levelFrame.text:SetText(targetlevel)
	-- Set Level
	if (self.conf.level) then
		self.levelFrame:Show()
		self.levelFrame.skull:Hide()
		self.levelFrame:SetWidth(27)
		if (not XPerl_CanAccess(targetlevel)) then
			-- Creature levels are secret inside instances
			self.levelFrame.text:SetTextColor(1, 1, 1)
			self.levelFrame.text:Show()
		elseif (targetlevel < 0) then
			self.levelFrame.text:Hide()
			self.levelFrame.skull:Show()
		else
			local color = XPerl_Target_LevelColour(self.partyid, targetlevel)
			self.levelFrame.text:SetTextColor(color.r, color.g, color.b)
			self.levelFrame.text:Show()
			local classification = UnitClassification(self.partyid)
			if (not self.conf.elite and XPerl_CanAccess(classification) and (classification == "elite" or classification == "worldboss")) then
				self.levelFrame.text:SetFormattedText("%d+", targetlevel)
				self.levelFrame:SetWidth(33)
			end
		end
	end
end

-- Raid Helper's assist counter, once the target frame has adopted it
local function XPerl_Target_AssistCounter(self)
	local counter = XPerl_Target_AssistFrame
	if (counter and counter:GetParent() == self) then
		return counter
	end
end

-- Places the level box, class icon, classification text and the assist counter
-- right of the portrait, or with levelLeft beside the left edge of the name and
-- stats panels, moving the PvP icon to the free side.
local function XPerl_Target_PlaceLevelColumn(self)
	local left = self.conf.levelLeft
	local level, class, boss, pvp = self.levelFrame, self.typeFramePlayer, self.bossFrame, self.nameFrame.pvp
	local counter = XPerl_Target_AssistCounter(self)
	level:ClearAllPoints()
	class:ClearAllPoints()
	boss:ClearAllPoints()
	self.cpFrame:ClearAllPoints()
	pvp:ClearAllPoints()
	level:SetFrameLevel(self.portraitFrame:GetFrameLevel())
	level.outOfPlace = nil
	if (left) then
		level:SetPoint("TOPRIGHT", self.nameFrame, "TOPLEFT", 2, 0)
		class:SetPoint("BOTTOMRIGHT", self.statsFrame, "BOTTOMLEFT", -2, 2)
		boss:SetPoint("BOTTOMRIGHT", self.statsFrame, "BOTTOMLEFT", 2, 0)
		self.cpFrame:SetPoint("TOPRIGHT", level, "TOPLEFT", 4, 0)
		pvp:SetPoint("TOPLEFT", self.portraitFrame, "TOPRIGHT", -6, 1)
	else
		level:SetPoint("TOPLEFT", self.portraitFrame, "TOPRIGHT", -2, 0)
		class:SetPoint("BOTTOMLEFT", self.portraitFrame, "BOTTOMRIGHT", 2, 2)
		boss:SetPoint("BOTTOMLEFT", self.portraitFrame, "BOTTOMRIGHT", -2, 0)
		self.cpFrame:SetPoint("TOPLEFT", level, "TOPRIGHT", -4, 0)
		pvp:SetPoint("TOPLEFT", self.nameFrame, "TOPLEFT", -5, 1)
	end
	if (counter) then
		counter:ClearAllPoints()
		counter:SetFrameLevel(self.portraitFrame:GetFrameLevel())
		if (left) then
			counter:SetPoint("TOPRIGHT", self.nameFrame, "TOPLEFT", 2, -20)
		else
			counter:SetPoint("TOPLEFT", self.portraitFrame, "TOPRIGHT", -2, -20)
		end
		self.eliteFrame.assistOutOfPlace = nil
	end
end

local function XPerl_Target_UpdateClassification(self)
	local partyid = self.partyid
	local targetclassification = UnitClassification(partyid)
	local bossType, eliteGfx

	if (not XPerl_CanAccess(targetclassification)) then
		-- The classification is secret, nothing can be decided
		self.bossFrame:Hide()
		self.eliteFrame:Hide()
		self.typeFramePlayer:Hide()
		return
	end

	if (targetclassification == "normal" and UnitPlayerControlled(partyid)) then
		if (not UnitIsPlayer(partyid)) then
			bossType = XPERL_TYPE_PET
			self.bossFrame.text:SetTextColor(1, 1, 1)
			self.typeFramePlayer:Hide()
		end

	elseif (self.conf.level or targetclassification == "rareelite" or targetclassification == "rare" or targetclassification == "elite" or targetclassification == "worldboss") then
		if (self.conf.eliteGfx) then
			eliteGfx = true
			if (targetclassification == "worldboss" or targetclassification == "elite") then
				self.eliteFrame.tex:SetTexture("Interface\\Addons\\ZPerl\\Images\\XPerl_Elite")
				self.eliteFrame.tex:SetVertexColor(1, 1, 0, 1)
			elseif (targetclassification == "rareelite") then
				self.eliteFrame.tex:SetTexture("Interface\\Addons\\ZPerl\\Images\\XPerl_Elite")
				self.eliteFrame.tex:SetVertexColor(1, 1, 1, 1)
			elseif (targetclassification == "rare") then
				self.eliteFrame.tex:SetTexture("Interface\\Addons\\ZPerl\\Images\\XPerl_Rare")
				self.eliteFrame.tex:SetVertexColor(1, 1, 1, 1)
			else
				eliteGfx = nil
			end
		else
			if (targetclassification == "worldboss") then
				bossType = XPERL_TYPE_BOSS
				self.bossFrame.text:SetTextColor(1, 0.5, 0.5)
			elseif (targetclassification == "rareelite") then
				bossType = XPERL_TYPE_RAREPLUS
				self.bossFrame.text:SetTextColor(0.8, 0.8, 0.8)
			elseif (targetclassification == "elite") then
				bossType = XPERL_TYPE_ELITE
				self.bossFrame.text:SetTextColor(1, 1, 0.5)
			elseif (targetclassification == "rare") then
				bossType = XPERL_TYPE_RARE
				self.bossFrame.text:SetTextColor(0.8, 0.8, 0.8)
			end
		end

		self.typeFramePlayer:Hide()
	end

	if (partyid == "target" and bossType and not tconf.eliteNone) or (partyid == "focus" and bossType and not fconf.eliteNone) then
		self.bossFrame:Show()
		self.bossFrame.text:SetText(bossType)
		-- GetStringWidth() can be secret even for plain text
		XPerl_SafeSetWidthFromText(self.bossFrame, self.bossFrame.text, 10, 70)
	else
		self.bossFrame:Hide()
	end

	if (eliteGfx) then
		self.eliteFrame:Show()
	else
		self.eliteFrame:Hide()
	end
	-- The elite graphic covers the column right of the portrait, so the level and
	-- assist counter step onto the portrait's corner. A column on the left is clear.
	if (eliteGfx and not self.conf.levelLeft) then
		if (partyid == "target" and XPerl_Target_AssistFrame and XPerl_Target_AssistFrame:IsShown()) then
			XPerl_Target_AssistFrame:ClearAllPoints()
			XPerl_Target_AssistFrame:SetPoint("BOTTOMRIGHT", self.portraitFrame, "BOTTOMRIGHT", 0, 0)
			XPerl_Target_AssistFrame:SetFrameLevel(self.portraitFrame:GetFrameLevel() + 2)
			self.eliteFrame.assistOutOfPlace = true
		end
		if (self.conf.level) then
			self.levelFrame:ClearAllPoints()
			self.levelFrame:SetPoint("TOPRIGHT", self.portraitFrame, "TOPRIGHT", 0, 0)
			self.levelFrame:SetFrameLevel(self.portraitFrame:GetFrameLevel() + 2)
			self.levelFrame.outOfPlace = true
		end
		-- this is hidden if the mob is elite regardless of graphics (wihout gfx it says "Elite" for example)
	elseif (self.levelFrame.outOfPlace or self.eliteFrame.assistOutOfPlace) then
		XPerl_Target_PlaceLevelColumn(self)
	end
end

local function AdjustCreatureTypeFrame(self)
	-- If it's too long, we anchor it to left side of portrait instead of right, to avoid it overlapping some buffs
	self.creatureTypeFrame:ClearAllPoints()
	if (self.creatureTypeFrame:GetWidth() > self.portraitFrame:GetWidth()) then
		self.creatureTypeFrame:SetPoint("TOPLEFT", self.portraitFrame, "BOTTOMLEFT", 0, 2)
	else
		self.creatureTypeFrame:SetPoint("TOPRIGHT", self.portraitFrame, "BOTTOMRIGHT", 0, 2)
	end
end

-- XPerl_Target_UpdateTalents
local XPerl_Target_UpdateTalents
do
	local function ShowSpec(self, spec) -- , s1, s2, s3)
		if (self.conf.talentsAsText and type(spec) == "string") then
			self.creatureTypeFrame.text:SetText(spec)
		else
			self.creatureTypeFrame.text:SetText(spec)
		end
		-- GetStringWidth() can be secret even for plain text
		XPerl_SafeSetWidthFromText(self.creatureTypeFrame, self.creatureTypeFrame.text, 10, 70)
		self.creatureTypeFrame:Show()

		AdjustCreatureTypeFrame(self)
		XPerl_Target_BuffPositions(self)
	end

	local LGT = LibStub and LibStub("LibGroupTalents-1.0", true)
	local UpdateTalentsLGT
	if (LGT) then
		function UpdateTalentsLGT(self)
			local spec, s1, s2, s3 = LGT:GetUnitTalentSpec(self.partyid)
			if (spec) then
				ShowSpec(self, spec) -- , s1, s2, s3)
				return true
			end
		end
	end

	local inspectReady
	local lastInspectTime = 0
	local lastInspectName, lastInspectUnit, lastInspectGUID
	local talentCache = setmetatable({}, {__mode = "kv"})
	local LTQ = LibStub and LibStub("LibTalentQuery-1.0", true)
	local lastInspectInvalid
	if (LTQ) then
		local function TalentQuery_Ready(e, name, realm, unit)
			if (UnitIsUnit(unit, XPerl_Target.partyid)) then
				inspectReady = true
				XPerl_Target_UpdateTalents(XPerl_Target, UnitGUID(unit))
			end
		end
		LTQ:RegisterCallback("TalentQuery_Ready", TalentQuery_Ready)
	else
		function XPerl_Target_Events:INSPECT_READY(guid)
			local unitGUID = UnitGUID(self.partyid)
			if (unitGUID and XPerl_CanAccess(unitGUID) and unitGUID == guid) then
				inspectReady = true
				XPerl_Target_UpdateTalents(self, guid)
			end
		end
	end

	function XPerl_Target_UpdateTalents(self, guid)
		if (self.conf.showTalents and self == XPerl_Target and not self.creatureTypeFrame:IsShown()) then
			if (UpdateTalentsLGT and UpdateTalentsLGT(self)) then
				return
			end

			local partyid = self.partyid
			local level = UnitLevel(partyid)
			if (UnitIsVisible(partyid) and UnitExists(partyid) and UnitIsPlayer(partyid) and XPerl_CanAccess(level) and level > 10) then
				local name = UnitName(partyid)
				if (not name or not XPerl_CanAccess(name)) then
					return
				else
					local cached = talentCache[name]
					local name1, name2, name3, group, iconTexture, background
					local unitGUID = UnitGUID(partyid)
					if (cached) then
						name1, name2, name3, group = unpack(cached)
					-- Guard both GUIDs before comparing; the event's guid can be secret too.
					elseif (inspectReady and XPerl_CanAccess(unitGUID) and XPerl_CanAccess(guid) and guid == unitGUID) then
						local remoteInspectNeeded = not UnitIsUnit("player", partyid) or nil
						name1 = "Yok"

						inspectReady = nil
					end

					if (name1) then
						if (not cached) then
							talentCache[name] = {name1, name2, name3, group}
						end
						ShowSpec(self, name1)
					end

					if (not cached) then
						if (LTQ) then
							inspectReady = nil
							LTQ:Query(partyid)
						else
							if (lastInspectPending == 0 or GetTime() > lastInspectTime + 15) then
								if (UnitExists(partyid) and UnitIsVisible(partyid) and not InCombatLockdown() and CheckInteractDistance(partyid, 4)) then
									if (not UnitIsUnit("player", partyid)) then
										inspectReady = nil
										lastInspectInvalid = nil
										lastInspectPending = 0
										if (lastInspectName ~= XPerl_UnitFullName(partyid)) then
											NotifyInspect(partyid)
										end
									end
								end
							end
						end
					end
				end
			end
		end
	end
end

local function XPerl_Target_UpdateType(self)
	local partyid = self.partyid
	local targettype = UnitCreatureType(partyid)
	-- Creature types are secret inside instances
	local typeReadable = XPerl_CanAccess(targettype)

	if (typeReadable and (targettype == XPERL_TYPE_NOT_SPECIFIED or targettype == "")) then
		targettype = nil
	end

	if (self.conf.mobType) then
		self.creatureTypeFrame:Show()
	else
		self.creatureTypeFrame:Hide()
	end

	self.typeFramePlayer:Hide()

	self.creatureTypeFrame.text:SetText(targettype)

		local classification = UnitClassification(partyid)
		if (self.conf.classIcon and (UnitIsPlayer(partyid) or (XPerl_CanAccess(classification) and classification == "normal"))) then
			local LocalClass, PlayerClass = UnitClassBase(partyid)

			if (self.conf.classText) then
				self.bossFrame.text:SetText(LocalClass)
				self.bossFrame.text:SetTextColor(1, 1, 1)
				self.bossFrame:Show()
				-- GetStringWidth() can be secret even for plain text
				XPerl_SafeSetWidthFromText(self.bossFrame, self.bossFrame.text, 10, 70)
			else
				if (UnitIsPlayer(partyid) or not UnitPlayerControlled(partyid)) then
					local l, r, t, b = XPerl_ClassPos(LocalClass)
					self.typeFramePlayer.classTexture:SetTexCoord(l, r, t, b)
					self.typeFramePlayer:Show()
				end
			end
		end
		if (UnitIsPlayer(partyid)) then
			self.creatureTypeFrame:Hide()
		end
		if (targettype) then
			self.creatureTypeFrame.text:SetTextColor(1, 1, 1)
			-- GetStringWidth can be secret after a secret read earlier in this update, so the
			-- width itself is guarded.
			XPerl_SafeSetWidthFromText(self.creatureTypeFrame, self.creatureTypeFrame.text, 10, 70)
		else
			self.creatureTypeFrame:Hide()
		end

	AdjustCreatureTypeFrame(self)

	XPerl_Target_UpdateTalents(self)
end

function XPerl_Target_SetManaType(self)
	local unitPowerMax = UnitPowerMax(self.partyid)

	-- A secret maximum cannot be tested, keep the bar shown
	if ((XPerl_CanAccess(unitPowerMax) and unitPowerMax == 0) or not self.conf.mana) then
		if (self.statsFrame.manaBar:IsShown()) then
			self.statsFrame.manaBar:Hide()

			if (self == XPerl_Target or self == XPerl_Focus or self == XPerl_TargetTarget or self == XPerl_FocusTarget or self == XPerl_PetTarget or self == XPerl_TargetTargetTarget) then
				self.statsFrame:SetHeight(28 + ((conf.bar.fat or 0) * 2))
				XPerl_StatsFrameSetup(self)
			end
		end
		return
	end

	XPerl_SetManaBarType(self)

	if (not self.statsFrame.manaBar:IsShown()) then
		self.statsFrame.manaBar:Show()
		self.statsFrame.manaBar.text:Show()
		if (self == XPerl_Target or self == XPerl_Focus or self == XPerl_TargetTarget or self == XPerl_FocusTarget or self == XPerl_PetTarget or self == XPerl_TargetTargetTarget) then
			self.statsFrame:SetHeight(40)
			XPerl_StatsFrameSetup(self)
		end
	end
end

function XPerl_Target_SetMana(self)
	local partyid = self.partyid
	if not partyid then
		self.targetmana = 0
		self.targetmanamax = 0
		return
	end

	local powerType = XPerl_GetDisplayedPowerType(partyid)
	local unitPower = UnitPower(partyid, powerType)
	local unitPowerMax = UnitPowerMax(partyid, powerType)

	self.targetmana = unitPower
	self.targetmanamax = unitPowerMax

	-- Percent is plain maths when readable, Blizzard supplied otherwise
	local powerPct = XPerl_GetPowerPercent(partyid, powerType, unitPower, unitPowerMax)

	self.statsFrame.manaBar:SetMinMaxValues(0, unitPowerMax)
	self.statsFrame.manaBar:SetValue(unitPower)

	if powerType >= 1 then
		self.statsFrame.manaBar.percent:SetText(unitPower)
	else
		self.statsFrame.manaBar.percent:SetFormattedText(percD, powerPct) -- XPerl_Percent[floor(100 * (unitPower / unitPowerMax))])
	end

	XPerl_SetValuedText(self.statsFrame.manaBar.text, unitPower, unitPowerMax)
end

local function XPerl_Target_SetComboBar(self)
	if not tconf.combo.enable then
		return
	end

	local comboPoints = GetComboPoints("player", "target")
	local maxComboPoints = XPerl_Target_ComboMax()
	self.nameFrame.cpMeter:SetMinMaxValues(0, maxComboPoints)
	self.nameFrame.cpMeter:SetValue(comboPoints)
	XPerl_Target_ComboSegments(self, maxComboPoints)
end

local function XPerl_Target_UpdateHealPrediction(self)
	if self == XPerl_Target then
		if tconf.healprediction then
			XPerl_SetExpectedHealth(self)
		else
			self.statsFrame.expectedHealth:Hide()
		end
	elseif self == XPerl_TargetTarget or self == XPerl_TargetTargetTarget then
		if conf.targettarget.healprediction then
			XPerl_SetExpectedHealth(self)
		else
			self.statsFrame.expectedHealth:Hide()
		end
	elseif self == XPerl_Focus then
		if fconf.healprediction then
			XPerl_SetExpectedHealth(self)
		else
			self.statsFrame.expectedHealth:Hide()
		end
	elseif self == XPerl_FocusTarget then
		if conf.focustarget.healprediction then
			XPerl_SetExpectedHealth(self)
		else
			self.statsFrame.expectedHealth:Hide()
		end
	end
end

local function XPerl_Target_UpdateAbsorbPrediction(self)
	if self == XPerl_Target then
		if tconf.absorbs then
			XPerl_SetExpectedAbsorbs(self)
		else
			self.statsFrame.expectedAbsorbs:Hide()
		end
	elseif self == XPerl_TargetTarget or self == XPerl_TargetTargetTarget then
		if conf.targettarget.absorbs then
			XPerl_SetExpectedAbsorbs(self)
		else
			self.statsFrame.expectedAbsorbs:Hide()
		end
	elseif self == XPerl_Focus then
		if fconf.absorbs then
			XPerl_SetExpectedAbsorbs(self)
		else
			self.statsFrame.expectedAbsorbs:Hide()
		end
	elseif self == XPerl_FocusTarget then
		if conf.focustarget.absorbs then
			XPerl_SetExpectedAbsorbs(self)
		else
			self.statsFrame.expectedAbsorbs:Hide()
		end
	end
end

function XPerl_Target_UpdateResurrectionStatus(self)
	if (XPerl_SafeBool(UnitHasIncomingResurrection(self.partyid), false)) then
		if (self == XPerl_Target and tconf.portrait) or (self == XPerl_Focus and fconf.portrait) then
			self.portraitFrame.resurrect:Show()
		else
			self.statsFrame.resurrect:Show()
		end
	else
		if (self == XPerl_Target and tconf.portrait) or (self == XPerl_Focus and fconf.portrait) then
			self.portraitFrame.resurrect:Hide()
		else
			self.statsFrame.resurrect:Hide()
		end
	end
end

function XPerl_Target_UpdateHealth(self)
	local partyid = self.partyid
	if not partyid then
		self.targethp = 0
		self.targetmax = 0
		self.afk = false
		return
	end

	local hp, hpMax, percent = XPerl_Target_GetHealth(self)
	-- Secret health goes straight to the bar, no maths here
	local readable = XPerl_CanAccess(hp) and XPerl_CanAccess(hpMax)

	self.targethp = hp
	self.targethpmax = hpMax

	-- Indirect units (pettarget, targettarget...) can return
	-- secret booleans, which cannot be tested; treat those as "alive and normal"
	local ghost = XPerl_SafeBool(UnitIsGhost(partyid), false)
	local dead = XPerl_SafeBool(UnitIsDead(partyid), false)
	local offline = UnitExists(partyid) and not XPerl_SafeBool(UnitIsConnected(partyid), true)
	local afk = XPerl_SafeBool(UnitIsAFK(partyid), false)
	self.afk = afk and conf.showAFK == 1

	if (not readable) then
		XPerl_SetHealthBar(self, hp, hpMax)
	elseif hp and hp >= 0 and hpMax and hpMax > 0 then
		XPerl_SetHealthBar(self, hp, hpMax)
	end

	XPerl_Target_UpdateAbsorbPrediction(self)
	XPerl_Target_UpdateHealPrediction(self)
	XPerl_Target_UpdateResurrectionStatus(self)

	if (percent and readable) then
		if ghost or dead or hpMax == 0 then -- 4.3+ fix so if for some dumb reason max HP is 0, prevent any division by 0.
			self.statsFrame.healthBar.text:SetFormattedText(percD, 0)
		else
			self.statsFrame.healthBar.text:SetFormattedText(percD, 100 * hp / hpMax)
		end
	end

	local color
	if (self.conf.percent) then
		if (ghost) then
			self.statsFrame.manaBar.percent:Hide()
			self.statsFrame.healthBar.percent:SetText(XPERL_LOC_GHOST)
		elseif (dead) then
			self.statsFrame.healthBar.percent:SetText(XPERL_LOC_DEAD)
		elseif (offline) then
			self.statsFrame.manaBar.percent:Hide()
			self.statsFrame.healthBar.percent:SetText(XPERL_LOC_OFFLINE)
		elseif (afk and conf.showAFK) then
			self.statsFrame.healthBar.percent:SetText(CHAT_MSG_AFK)
		else
			self.statsFrame.manaBar.percent:Show()
			color = true
		end
	else
		if (ghost) then
			self.statsFrame.healthBar.text:SetText(XPERL_LOC_GHOST)
		elseif (dead) then
			self.statsFrame.healthBar.text:SetText(XPERL_LOC_DEAD)
		elseif (offline) then
			self.statsFrame.healthBar.text:SetText(XPERL_LOC_OFFLINE)
		elseif (afk and conf.showAFK) then
			self.statsFrame.healthBar.text:SetText(CHAT_MSG_AFK)
		else
			color = true
		end
	end

	if (color) then
		if (not readable) then
			XPerl_ColourHealthBar(self, XPerl_GetHealthPercent(partyid, hp, hpMax))
		elseif hp and hp >= 0 and hpMax and hpMax > 0 then
			XPerl_ColourHealthBar(self, hp / hpMax)
		end

		if (self.statsFrame.greyMana) then
			self.statsFrame.greyMana = nil
			XPerl_Target_SetManaType(self)
		end
	else
		self.statsFrame:SetGrey()
	end
end

function XPerl_Target_GetHealth(self)
	-- XPerl_Unit_GetHealth already answers "is max 100" and
	-- returns false when the values are secret and cannot be compared
	local hp, hpMax, percent = XPerl_Unit_GetHealth(self)
	return hp, hpMax, percent
end

function XPerl_Target_Update_Combat(self)
	if (UnitAffectingCombat(self.partyid)) then
		self.nameFrame.combatIcon:Show()
	else
		self.nameFrame.combatIcon:Hide()
	end
end

local function XPerl_Target_CombatFlash(self, elapsed, argNew, argGreen)
	if (XPerl_CombatFlashSet(self, elapsed, argNew, argGreen)) then
		XPerl_CombatFlashSetFrames(self)
	end
end

function XPerl_Target_Update_Range(self)
	if not self.partyid then
		return
	end
	if not tconf.range30yard then
		self.nameFrame.rangeIcon:Hide()
		return
	end
	local range, checkedRange = UnitInRange(self.partyid)
	if (XPerl_IsSecret(range) or XPerl_IsSecret(checkedRange)) then
		-- Secret booleans drive the icon's alpha directly
		local icon = self.nameFrame.rangeIcon
		icon:Show()
		icon:SetAlpha(1)
		XPerl_SetAlphaFromBoolean(icon, checkedRange, 1, 0)
		XPerl_SetAlphaFromBoolean(icon, range, 0, icon:GetAlpha())
		return
	end
	local inRange = false
	if not checkedRange then
		inRange = true
	end
	if not UnitIsConnected(self.partyid) or inRange then
		self.nameFrame.rangeIcon:Hide()
	else
		self.nameFrame.rangeIcon:Show()
		self.nameFrame.rangeIcon:SetAlpha(1)
	end
end

local function XPerl_Target_UpdateLeader(self)
	local leader
	local partyid = self.partyid

	-- UnitIsGroupLeader/UnitIsGroupAssistant can be secret booleans for a
	-- secret-identity target.
	if (XPerl_SafeBool(UnitIsGroupLeader(partyid), false)) then
		self.nameFrame.leaderIcon:Show()
		self.nameFrame.assistIcon:Hide()
	else
		self.nameFrame.leaderIcon:Hide()
		if (XPerl_SafeBool(UnitIsGroupAssistant(partyid), false)) then
			self.nameFrame.assistIcon:Show()
		else
			self.nameFrame.assistIcon:Hide()
		end
	end

	local masterLooter = false
	local method, partyID, raidID = GetLootMethod()

	if method and method == "master" then
		if raidID then
			if UnitIsUnit("raid"..raidID, partyid) then
				masterLooter = true
			end
		elseif partyID then
			if UnitIsUnit("party"..partyID, partyid) or (partyID == 0 and UnitIsUnit("player", partyid)) then
				masterLooter = true
			end
		end
	end

	if masterLooter then
		self.nameFrame.masterIcon:Show()
	else
		self.nameFrame.masterIcon:Hide()
	end
end

local function RaidTargetUpdate(self)
	local raidIcon = self.nameFrame.raidIcon

	XPerl_Update_RaidIcon(raidIcon, self.partyid)

	raidIcon:ClearAllPoints()
	if (self.conf.raidIconAlternate) then
		raidIcon:SetHeight(16)
		raidIcon:SetWidth(16)
		raidIcon:SetPoint("CENTER", self.nameFrame, "TOPRIGHT", -5, -4)
	else
		raidIcon:SetHeight(32)
		raidIcon:SetWidth(32)
		raidIcon:SetPoint("CENTER", self.nameFrame, "CENTER", 0, 0)
	end
end

local function XPerl_Target_CheckDebuffs(self)
	if (self.conf.highlightDebuffs.enable) then
		if (self.conf.highlightDebuffs.who == 1 or (self.conf.highlightDebuffs.who == 2 and UnitCanAssist("player", self.partyid)) or (self.conf.highlightDebuffs.who == 3 and not UnitCanAssist("player", self.partyid))) then
			XPerl_CheckDebuffs(self, self.partyid)
		else
			XPerl_CheckDebuffs(self, self.partyid, true)
		end
	end

	if (self.conf.reactionHighlight) then
		local c = XPerl_ReactionColour(self.partyid)
		self.nameFrame:SetBackdropColor(c.r, c.g, c.b)
	end
end

local function XPerl_Target_ComboFrame_Update()
	if (not ComboFrame or XPerl_RestrictedClient) then
		-- See XPerl_Target_RegisterComboEvents: showing or driving Blizzard's frame
		-- on a secret-value client crashes inside their own update.
		return
	end
	local comboPoints = GetComboPoints("player", "target")
	-- ComboPoints is secret when the target's identity is secret;
	-- it can't be compared against 0 or the loop index below, so drop our display
	if XPerl_IsSecret(comboPoints) then
		ComboFrame:Hide()
		ComboFrame.lastPoints = nil
		return
	end
	if tconf.combo.blizzard and comboPoints > 0 and not UnitIsDeadOrGhost("target") and UnitCanAttack(UnitHasVehicleUI("player") and "vehicle" or "player", "target") then
		if not ComboFrame:IsShown() then
			ComboFrame:Show()
			UIFrameFadeIn(ComboFrame, COMBOFRAME_FADE_IN)
		end

		local fadeInfo = { }
		for i = 1, 5 do
			local comboPoint = _G["ComboPoint"..i]
			if i < 6 then
				comboPoint:Show()
			else
				if comboPoints >= i then
					comboPoint:Show()
				else
					comboPoint:Hide()
				end
			end
			if i <= comboPoints then
				if i > (ComboFrame.lastPoints or 0) then
					-- Fade in the highlight and set a function that triggers when it is done fading
					fadeInfo.mode = "IN"
					fadeInfo.timeToFade = COMBOFRAME_HIGHLIGHT_FADE_IN
					fadeInfo.finishedFunc = ComboPointShineFadeIn
					fadeInfo.finishedArg1 = comboPoint.Shine
					UIFrameFade(comboPoint.Highlight, fadeInfo)
				end
			else
				comboPoint.Highlight:SetAlpha(0)
				comboPoint.Shine:SetAlpha(0)
			end
		end
	else
		ComboFrame:Hide()
	end
	ComboFrame.lastPoints = comboPoints
end

function XPerl_Target_UpdateDisplay(self)
	local partyid = self.partyid
	if not UnitExists(partyid) then
		return
	end

	XPerl_NoFadeBars(true)

	XPerl_Target_UpdateName(self)
	XPerl_Target_UpdateClassification(self)
	XPerl_Target_UpdateLevel(self)
	XPerl_Target_UpdateType(self)
	XPerl_Target_SetManaType(self)
	XPerl_Target_SetMana(self)
	XPerl_Target_UpdateHealth(self)
	XPerl_Target_Update_Combat(self)
	XPerl_Target_UpdateLeader(self)
	XPerl_Unit_ThreatStatus(self, partyid == "target" and "player" or nil, true)

	if self == XPerl_Target and tconf.combo.blizzard then
		XPerl_Target_ComboFrame_Update()
	end

	RaidTargetUpdate(self)

	if (self.conf.defer) then
		self.portraitFrame.portrait:Hide()
		self.portraitFrame.portrait3D:Hide()
		self.nameFrame.masterIcon:Hide()
		self.cpFrame:Hide()
		self.nameFrame.cpMeter:Hide()
		if (self.comboDots) then
			self.comboDots:Hide()
		end
		self.deferring = true
		self.time = -0.3
	else
		if self == XPerl_Target and (tconf.combo.enable or tconf.combo.dots or tconf.comboindicator.enable) then
			XPerl_Target_UpdateCombo(self)
		end
		XPerl_Unit_UpdatePortrait(self)
	end

	XPerl_Highlight:SetHighlight(self, UnitGUID(partyid))

	if tconf.range30yard then
		XPerl_Target_Update_Range(self)
	else
		self.nameFrame.rangeIcon:Hide()
	end
	XPerl_UpdateSpellRange(self, partyid)

	XPerl_NoFadeBars()

	-- Some optimizing here to limit the amount of work done on a target change
	local buffOptionString = tostring(self.statsFrame.manaBar:IsShown() or 0)..tostring(self.bossFrame:IsShown() or 0)..tostring(self.creatureTypeFrame:IsShown() or 0)..tostring(self.statsFrame:GetWidth())
	if (self.buffOptionString ~= buffOptionString) then
		self.buffOptionString = buffOptionString
		-- Work out where all our buffs can fit, we only do this for a fresh target
		XPerl_Target_BuffPositions(self)
	end

	-- A new target can switch friend and enemy order, so only the holder order is
	-- updated here; containers are never built on this path.
	XPerl_Target_AuraContainer_ApplyOrder(self)

	XPerl_Targets_BuffUpdate(self)
	if (self.conf.highlightDebuffs.enable) then
		XPerl_Target_CheckDebuffs(self)
	end

	XPerl_Target_UpdatePVP(self)
end

function XPerl_Target_OnUpdate(self, elapsed)
	local partyid = self.partyid
	if not partyid then
		return
	end

	if (tconf.hitIndicator and tconf.portrait) or (fconf.hitIndicator and fconf.portrait) then
		CombatFeedback_OnUpdate(self, elapsed)
	end

	-- Separate raw call from the guarded one in _UpdateHealth; default to
	-- self.afk when secret so this reads "no change" rather than crashing.
	local newAFK = XPerl_SafeBool(UnitIsAFK(partyid), self.afk)

	if (conf.showAFK and newAFK ~= self.afk) then
		XPerl_Target_UpdateHealth(self)
	end

	if self.deferring or conf.rangeFinder.enabled or tconf.range30yard then
		self.time = self.time + elapsed
		if (self.time > 0.2) then
			self.time = 0
			if tconf.range30yard then
				XPerl_Target_Update_Range(self)
			end
			if conf.rangeFinder.enabled then
				XPerl_UpdateSpellRange(self, partyid)
			end

			if (self.deferring) then
				self.deferring = nil
				XPerl_Target_Update_Combat(self)
				if self == XPerl_Target and (tconf.combo.enable or tconf.combo.dots or tconf.comboindicator.enable) then
					XPerl_Target_UpdateCombo(self)
				end
				XPerl_Unit_UpdatePortrait(self)
				RaidTargetUpdate(self)
			end
		end
	end

	if (conf.combatFlash and self.PlayerFlash) then
		XPerl_Target_CombatFlash(self, elapsed, false)
	end
end

-- Event Handler
function XPerl_Target_OnEvent(self, event, ...)
	local func = XPerl_Target_Events[event]
	func(self, ...)
end

function XPerl_Target_Events:PLAYER_REGEN_ENABLED()
	XPerl_Unit_ThreatStatus(self, self.partyid == "target" and "player" or nil)
	if (self.buffDisplayPath == "container") then
		XPerl_Targets_BuffUpdate(self)
	end
end

function XPerl_Target_Events:PLAYER_REGEN_DISABLED()
	XPerl_Unit_ThreatStatus(self, self.partyid == "target" and "player" or nil)
end

function XPerl_Target_Events:PET_BATTLE_OPENING_START()
	if (XPerl_Target) then
		XPerl_Target:Hide()
	end
	if (XPerl_Focus) then
		XPerl_Focus:Hide()
	end
	if (XPerl_PetTarget) then
		XPerl_PetTarget:Hide()
	end
	if (XPerl_TargetTarget) then
		XPerl_TargetTarget:Hide()
	end
	if (XPerl_FocusTarget) then
		XPerl_FocusTarget:Hide()
	end
end

function XPerl_Target_Events:PET_BATTLE_CLOSE()
	if (XPerl_Target and UnitExists("target")) then
		XPerl_Target:Show()
	end
	if (XPerl_Focus and XPerl_Focus.conf.enable and UnitExists("focus")) then
		XPerl_Focus:Show()
	end
	if (XPerl_PetTarget and UnitExists("pettarget")) then
		XPerl_PetTarget:Show()
	end
	if (XPerl_TargetTarget and XPerl_TargetTarget.conf.enable and UnitExists("targettarget")) then
		XPerl_TargetTarget:Show()
	end
	if (XPerl_FocusTarget and XPerl_FocusTarget.conf.enable and UnitExists("focustarget")) then
		XPerl_FocusTarget:Show()
	end
end

function XPerl_Target_Events:PLAYER_ENTERING_WORLD()
	if (UnitExists("focus")) then
		self.PlayerFlash = 0
		XPerl_CombatFlashSetFrames(self)
		XPerl_Target_UpdateDisplay(self)
	end
end

local amountIndex = {
	SWING_DAMAGE = 1,
	RANGE_DAMAGE = 4,
	SPELL_DAMAGE = 4,
	SPELL_PERIODIC_DAMAGE = 4,
	DAMAGE_SHIELD = 4,
	ENVIRONMENTAL_DAMAGE = 2,
}

local missIndex = {
	SWING_MISSED = 1,
	RANGE_MISSED = 4,
	SPELL_MISSED = 4,
	SPELL_PERIODIC_MISSED = 4,
}

function XPerl_Target_Events:UNIT_COMBAT(unit, action, descriptor, damage, damageType)
	if unit ~= self.partyid then
		return
	end

	XPerl_Target_Update_Combat(self)

	if (self.conf.hitIndicator and self.conf.portrait) then
		XPerl_CombatFeedback(self, action, descriptor, damage, damageType)
	end

	if (action == "HEAL") then
		XPerl_Target_CombatFlash(self, 0, true, true)
	elseif (action == "WOUND") then
		XPerl_Target_CombatFlash(self, 0, true)
	end
end

function XPerl_Target_Events:PLAYER_TARGET_CHANGED()
	if self ~= XPerl_Target then
		return
	end
	if (self.conf.sound and UnitExists("target")) then
		if (UnitIsEnemy("target", "player")) then
			PlaySound(873)
		elseif (UnitIsFriend("player", "target")) then
			PlaySound(867)
		else
			PlaySound(871)
		end
	end

	self.PlayerFlash = 0
	XPerl_CombatFlashSetFrames(self)
	XPerl_Target_UpdateDisplay(self)

	if (UnitIsUnit("target", "focus")) then
		self.statsFrame.focusTarget:Show()
	else
		self.statsFrame.focusTarget:Hide()
	end

	if (XPerl_Focus and XPerl_Focus:IsShown() and XPerl_FocusTarget) then
		XPerl_TargetTarget_UpdateDisplay(XPerl_FocusTarget)
	end
end

function XPerl_Target_Events:PLAYER_FOCUS_CHANGED()
	if self ~= XPerl_Focus then
		return
	end
	if (self.conf.sound and UnitExists("focus")) then
		if (UnitIsEnemy("focus", "player")) then
			PlaySound(873)
		elseif (UnitIsFriend("player", "focus")) then
			PlaySound(867)
		else
			PlaySound(871)
		end
	end

	self.PlayerFlash = 0
	XPerl_CombatFlashSetFrames(self)
	XPerl_Target_UpdateDisplay(self)

	if (UnitIsUnit("target", "focus")) then
		XPerl_Target.statsFrame.focusTarget:Show()
	else
		XPerl_Target.statsFrame.focusTarget:Hide()
	end

	if (XPerl_FocusTarget) then
		XPerl_TargetTarget_UpdateDisplay(XPerl_FocusTarget)
	end
end

function XPerl_Target_Events:UNIT_HEALTH_FREQUENT()
	XPerl_Target_UpdateHealth(self)
end

function XPerl_Target_Events:UNIT_HEALTH()
	XPerl_Target_UpdateHealth(self)
end

function XPerl_Target_Events:UNIT_MAXHEALTH()
	XPerl_Target_UpdateHealth(self)
end

function XPerl_Target_Events:PET_BATTLE_HEALTH_CHANGED()
	XPerl_Target_UpdateHealth(self)
end

function XPerl_Target_Events:UPDATE_SUMMONPETS_ACTION()
	if UnitIsBattlePet("target") then
		XPerl_Target_UpdateHealth(XPerl_Target)
	end

	if UnitIsBattlePet("focus") then
		XPerl_Target_UpdateHealth(XPerl_Focus)
	end
end

function XPerl_Target_Events:UNIT_FLAGS()
	XPerl_Target_UpdateName(self)
	XPerl_Target_UpdatePVP(self)
	XPerl_Target_Update_Combat(self)
end

function XPerl_Target_Events:RAID_TARGET_UPDATE()
	RaidTargetUpdate(XPerl_Target)
	RaidTargetUpdate(XPerl_Focus)
end

function XPerl_Target_Events:UNIT_POWER_FREQUENT()
	XPerl_Target_SetMana(self)
end

function XPerl_Target_Events:UNIT_MAXPOWER(unit)
	XPerl_Target_SetMana(self)
end

function XPerl_Target_Events:UNIT_DISPLAYPOWER()
	XPerl_Target_SetManaType(self)
	XPerl_Target_SetMana(self)
end

function XPerl_Target_Events:UNIT_PORTRAIT_UPDATE()
	XPerl_Unit_UpdatePortrait(self, true)
end

function XPerl_Target_Events:UNIT_NAME_UPDATE()
	XPerl_Target_UpdateName(self)
	XPerl_Target_UpdateHealth(self)
	XPerl_Target_UpdateClassification(self)
end

function XPerl_Target_Events:UNIT_LEVEL()
	XPerl_Target_UpdateLevel(self)
	XPerl_Target_UpdateClassification(self)
end

function XPerl_Target_Events:UNIT_CLASSIFICATION_CHANGED()
	XPerl_Target_UpdateClassification(self)
end

function XPerl_Target_Events:UNIT_AURA()
	if not UnitExists(self.partyid) then
		return
	end

	if (self.conf.highlightDebuffs.enable) then
		XPerl_Target_CheckDebuffs(self)
	end

	XPerl_Targets_BuffUpdate(self)
end

function XPerl_Target_Events:UNIT_FACTION()
	XPerl_Target_UpdatePVP(self)
	XPerl_Target_BuffPositions(self)
end

function XPerl_Target_Events:HONOR_PRESTIGE_UPDATE()
	XPerl_Target_UpdatePVP(self)
end

function XPerl_Target_Events:PLAYER_FLAGS_CHANGED()
	XPerl_Target_Update_Combat(self)
	XPerl_Target_UpdatePVP(self)
	XPerl_Target_UpdateHealth(self)
end

function XPerl_Target_Events:UNIT_CONNECTION(unit, online)
	if (unit == self.partyid) then
		XPerl_Target_UpdateDisplay(self)
	end
end

function XPerl_Target_Events:UNIT_PHASE(unit)
	if (unit == self.partyid) then
		XPerl_Target_UpdateDisplay(self)
	end
end

function XPerl_Target_Events:PARTY_LOOT_METHOD_CHANGED()
	XPerl_Target_UpdateLeader(self)
end
XPerl_Target_Events.GROUP_ROSTER_UPDATE = XPerl_Target_Events.PARTY_LOOT_METHOD_CHANGED
XPerl_Target_Events.PARTY_LEADER_CHANGED = XPerl_Target_Events.PARTY_LOOT_METHOD_CHANGED

function XPerl_Target_Events:UNIT_THREAT_LIST_UPDATE(unit)
	if (UnitCanAttack("player", self.partyid or "target")) then
		XPerl_Unit_ThreatStatus(self, self.partyid == "target" and "player" or nil)
	else
		XPerl_Unit_ThreatStatus(self)
	end
end

function XPerl_Target_Events:UNIT_HEAL_PREDICTION(unit)
	if self == XPerl_Target then
		if (tconf.healprediction and unit == self.partyid) then
			XPerl_SetExpectedHealth(self)
		end
	elseif self == XPerl_TargetTarget or self == XPerl_TargetTargetTarget then
		if (conf.targettarget.healprediction and unit == self.partyid) then
			XPerl_SetExpectedHealth(self)
		end
	elseif self == XPerl_Focus then
		if (fconf.healprediction and unit == self.partyid) then
			XPerl_SetExpectedHealth(self)
		end
	elseif self == XPerl_FocusTarget then
		if (conf.focustarget.healprediction and unit == self.partyid) then
			XPerl_SetExpectedHealth(self)
		end
	end
end

function XPerl_Target_Events:UNIT_ABSORB_AMOUNT_CHANGED(unit)
	if self == XPerl_Target then
		if (tconf.absorbs and unit == self.partyid) then
			XPerl_SetExpectedAbsorbs(self)
		end
	elseif self == XPerl_TargetTarget or self == XPerl_TargetTargetTarget then
		if (conf.targettarget.absorbs and unit == self.partyid) then
			XPerl_SetExpectedAbsorbs(self)
		end
	elseif self == XPerl_Focus then
		if (fconf.absorbs and unit == self.partyid) then
			XPerl_SetExpectedAbsorbs(self)
		end
	elseif self == XPerl_FocusTarget then
		if (conf.focustarget.absorbs and unit == self.partyid) then
			XPerl_SetExpectedAbsorbs(self)
		end
	end
end

function XPerl_Target_Events:INCOMING_RESURRECT_CHANGED(unit)
	if (unit == self.partyid) then
		XPerl_Target_UpdateResurrectionStatus(self)
	end
end

function XPerl_Target_SetWidth(self)
	self.conf.size.width = max(0, self.conf.size.width or 0)
	local w = 128 + ((self.conf.portrait and 1 or 0) * 62) + ((self.conf.percent and 1 or 0) * 32) + self.conf.size.width

	if not InCombatLockdown() then
		self:SetWidth(w)
	end

	if self.conf.percent then
		if not InCombatLockdown() then
			self.nameFrame:SetWidth(160 + self.conf.size.width)
			self.statsFrame:SetWidth(160 + self.conf.size.width)
		end
		self.statsFrame.healthBar.percent:Show()
		self.statsFrame.manaBar.percent:Show()
	else
		if not InCombatLockdown() then
			self.nameFrame:SetWidth(128 + self.conf.size.width)
			self.statsFrame:SetWidth(128 + self.conf.size.width)
		end
		self.statsFrame.healthBar.percent:Hide()
		self.statsFrame.manaBar.percent:Hide()
	end

	self.conf.scale = self.conf.scale or 0.8
	if not InCombatLockdown() then
		self:SetScale(self.conf.scale)
	end

	if not InCombatLockdown() then
		XPerl_SavePosition(self, true)
	end
end

function XPerl_Target_Set_Bits(self)
	local _, playerClass = UnitClass("player")

	if (self.conf.portrait) then
		self.portraitFrame:Show()
		self.portraitFrame:SetWidth(62)
		self.statsFrame.resurrect:Hide()
	else
		self.portraitFrame:Hide()
		self.portraitFrame:SetWidth(3)
	end
	XPerl_Portrait_SetRound(self.portraitFrame, self.conf.portrait and self.conf.portraitRound)

	if (self.conf.values) then
		self.statsFrame.healthBar.text:Show()
		self.statsFrame.manaBar.text:Show()
	else
		self.statsFrame.healthBar.text:Hide()
		self.statsFrame.manaBar.text:Hide()
	end

	self.eliteFrame:SetFrameLevel(self.portraitFrame:GetFrameLevel() + 3)

	if (self.conf.level) then
		self.levelFrame:Show()
	else
		self.levelFrame:Hide()
	end
	XPerl_Target_PlaceLevelColumn(self)

	if (self.conf.classIcon) then
		self.typeFramePlayer.classTexture:Show()
	else
		self.typeFramePlayer.classTexture:Hide()
	end

	self.conf.buffs.size = tonumber(self.conf.buffs.size) or 20
	XPerl_SetBuffSize(self)

	if self == XPerl_Target then
		XPerl_Register_Prediction(self, tconf, function(guid)
			if guid == UnitGUID("target") then
				return "target"
			end
		end, "target")
	end
	if self == XPerl_Focus then
		XPerl_Register_Prediction(self, fconf, function(guid)
			if guid == UnitGUID("focus") then
				return "focus"
			end
		end, "focus")
	end
	XPerl_Target_SetWidth(self)

	if (not InCombatLockdown()) then
		if (self.conf.enable) then
			RegisterUnitWatch(self)
		else
			self:Hide()
			UnregisterUnitWatch(self)
		end
	end

	if (self == XPerl_Target) then
		XPerl_Target_Set_BlizzCPFrame(self)
	end

	XPerl_StatsFrameSetup(self)

	self.buffFrame:ClearAllPoints()
	if (self.conf.buffs.above) then
		self.buffFrame:SetPoint("BOTTOMLEFT", self, "TOPLEFT", 2, 0)
	else
		self.buffFrame:SetPoint("TOPLEFT", self.statsFrame, "BOTTOMLEFT", 2, 0)
	end
	-- Debuffs stay below when only the buffs go above
	XPerl_Unit_PlaceDebuffFrame(self, self.statsFrame, 2, 0)
	self.buffOptMix = nil

	-- Build/rebuild the containers from option/setup flow, not target-click flow.
	XPerl_Target_AuraContainer_Rebuild(self)

	if (self:IsShown()) then
		XPerl_Target_UpdateDisplay(self)
	end
end

local function XPerl_Target_RegisterComboEvents(self)
	if not tconf.combo.blizzard and not tconf.combo.enable and not tconf.combo.dots and not tconf.comboindicator.enable then
		ComboEventFrame:UnregisterAllEvents()

		if (ComboFrame) then
			ComboFrame:UnregisterAllEvents()
			ComboFrame:Hide()
		end
		self.nameFrame.cpMeter:Hide()
		self.cpFrame:Hide()
		XPerl_Target_ComboDotsLayout(self)
		return
	end

	ComboEventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
	ComboEventFrame:RegisterUnitEvent("UNIT_POWER_FREQUENT", "player", "vehicle")
	-- Combo points arrive on UNIT_POWER_UPDATE ("COMBO_POINTS"), not
	-- UNIT_POWER_FREQUENT.
	XPerl_RegisterUnitEventSafe(ComboEventFrame, "UNIT_POWER_UPDATE", "player", "vehicle")
	ComboEventFrame:RegisterUnitEvent("UNIT_MAXPOWER", "player", "vehicle")
	ComboEventFrame:RegisterUnitEvent("UNIT_ENTERED_VEHICLE", "player")
	ComboEventFrame:RegisterUnitEvent("UNIT_EXITED_VEHICLE", "player")
	-- A druid gains and loses combo points with Cat Form, mid-fight too
	ComboEventFrame:RegisterEvent("UPDATE_SHAPESHIFT_FORM")
	ComboEventFrame:RegisterUnitEvent("UNIT_DISPLAYPOWER", "player")

	-- Blizzard's ComboFrame cannot be driven here: any event we register on it runs its
	-- unguarded update in our taint, which crashes on a secret count. It stays
	-- unregistered and hidden; Z-Perl's own meter covers it.
	local blizzardCombo = tconf.combo.blizzard and not XPerl_RestrictedClient

	if blizzardCombo and ComboFrame then
		ComboFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
		ComboFrame:RegisterEvent("UNIT_POWER_FREQUENT")
		-- Not UNIT_POWER_UPDATE: on Blizzard's ComboFrame it would crash (see above).
		-- ComboEventFrame takes it instead.
		ComboFrame:RegisterEvent("UNIT_MAXPOWER")
		ComboFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
		ComboFrame:RegisterUnitEvent("UNIT_ENTERED_VEHICLE", "player")
		ComboFrame:RegisterUnitEvent("UNIT_EXITED_VEHICLE", "player")

		ComboFrame.unit = UnitHasVehicleUI("player") and "vehicle" or "player"

		if (ComboFrame_UpdateMax) then
			ComboFrame_UpdateMax(ComboFrame)
		end
	end

	if not blizzardCombo and ComboFrame then
		ComboFrame:UnregisterAllEvents()
		ComboFrame:Hide()
	end

	if not tconf.combo.enable then
		self.nameFrame.cpMeter:Hide()
	else
		XPerl_Target_ComboMeterLayout(self)
		XPerl_Target_SetComboBar(self)
	end

	if not tconf.comboindicator.enable then
		self.cpFrame:Hide()
	end

	XPerl_Target_ComboDotsLayout(self)
end

-- Using the Blizzard Combo Point frame, but we move the buttons around a little
function XPerl_Target_Set_BlizzCPFrame(self)
	-- Blizzard's combo frame is left hidden on this client (see
	-- the combo setup above), and its ComboPoint icons may not exist at all.
	if tconf.combo.blizzard and ComboFrame and not XPerl_RestrictedClient and ComboPoint1 then
		ComboFrame:ClearAllPoints()
		for i = 1, 5 do
			local combo = _G["ComboPoint"..i]
			if i < 9 then
				combo:ClearAllPoints()

				if i < 6 then
					combo:SetAlpha(1)
				else
					combo:SetAlpha(0.5)
				end
			else
				combo:ClearAllPoints()
				combo:Hide()
			end
		end

		if tconf.combo.pos == "top" then
			ComboFrame:SetPoint("TOP", self.portraitFrame, "TOP", 98, 4)
			ComboPoint1:SetPoint("TOPLEFT", 0, 0)
			ComboPoint2:SetPoint("LEFT", ComboPoint1, "RIGHT", 0, 1)
			ComboPoint3:SetPoint("LEFT", ComboPoint2, "RIGHT", 0, 1)
			ComboPoint4:SetPoint("LEFT", ComboPoint3, "RIGHT", 0, -1)
			ComboPoint5:SetPoint("LEFT", ComboPoint4, "RIGHT", 0, -1)
		elseif tconf.combo.pos == "bottom" then
			ComboFrame:SetPoint("BOTTOM", self.portraitFrame, "BOTTOM", 98, -4)
			ComboPoint1:SetPoint("BOTTOMLEFT", 0, 0)
			ComboPoint2:SetPoint("LEFT", ComboPoint1, "RIGHT", 0, -1)
			ComboPoint3:SetPoint("LEFT", ComboPoint2, "RIGHT", 0, -1)
			ComboPoint4:SetPoint("LEFT", ComboPoint3, "RIGHT", 0, 1)
			ComboPoint5:SetPoint("LEFT", ComboPoint4, "RIGHT", 0, 1)
		elseif tconf.combo.pos == "left" then
			ComboFrame:SetPoint("BOTTOMLEFT", self.portraitFrame, "BOTTOMLEFT", -1, 0)
			ComboPoint1:SetPoint("BOTTOMLEFT", 0, 0)
			ComboPoint2:SetPoint("BOTTOM", ComboPoint1, "TOP", -1, 0)
			ComboPoint3:SetPoint("BOTTOM", ComboPoint2, "TOP", -1, 0)
			ComboPoint4:SetPoint("BOTTOM", ComboPoint3, "TOP", 1, 0)
			ComboPoint5:SetPoint("BOTTOM", ComboPoint4, "TOP", 1, 0)
		elseif tconf.combo.pos == "right" then
			ComboFrame:SetPoint("BOTTOMRIGHT", self.portraitFrame, "BOTTOMRIGHT", 2, 0)
			ComboPoint1:SetPoint("BOTTOMRIGHT", 0, 0)
			ComboPoint2:SetPoint("BOTTOM", ComboPoint1, "TOP", 1, 0)
			ComboPoint3:SetPoint("BOTTOM", ComboPoint2, "TOP", 1, 0)
			ComboPoint4:SetPoint("BOTTOM", ComboPoint3, "TOP", -1, 0)
			ComboPoint5:SetPoint("BOTTOM", ComboPoint4, "TOP", -1, 0)
		else
			ComboFrame:SetPoint("TOP", self.portraitFrame, "TOP", 98, 4)
			ComboPoint1:SetPoint("TOPLEFT", 0, 0)
			ComboPoint2:SetPoint("LEFT", ComboPoint1, "RIGHT", 0, 1)
			ComboPoint3:SetPoint("LEFT", ComboPoint2, "RIGHT", 0, 1)
			ComboPoint4:SetPoint("LEFT", ComboPoint3, "RIGHT", 0, -1)
			ComboPoint5:SetPoint("LEFT", ComboPoint4, "RIGHT", 0, -1)
		end
	end

	XPerl_Target_RegisterComboEvents(self)
end

ComboEventFrame:SetScript("OnEvent", function(self, event, unit, ...)
	local powerType = ...
	if event == "UNIT_POWER_FREQUENT" or event == "UNIT_POWER_UPDATE" then
		if powerType == "COMBO_POINTS" then
			if UnitExists("target") and XPerl_Target:IsShown() then
				XPerl_Target_UpdateCombo(XPerl_Target)
				if conf.target.combo.blizzard then
					XPerl_Target_ComboFrame_Update()
				end
			end

		end
	elseif event == "PLAYER_ENTERING_WORLD" or event == "UNIT_MAXPOWER" or event == "UNIT_ENTERED_VEHICLE" or event == "UNIT_EXITED_VEHICLE"
		or event == "UPDATE_SHAPESHIFT_FORM" or event == "UNIT_DISPLAYPOWER" then
		-- Only UNIT_MAXPOWER carries a power type. A full update re-reads the maximum and
		-- hides the display while a druid is out of Cat Form.
		if event ~= "UNIT_MAXPOWER" or powerType == "COMBO_POINTS" then
			if UnitExists("target") and XPerl_Target:IsShown() then
				XPerl_Target_UpdateCombo(XPerl_Target)
				if conf.target.combo.blizzard then
					XPerl_Target_ComboFrame_Update()
				end
			end

		end
	end
end)
