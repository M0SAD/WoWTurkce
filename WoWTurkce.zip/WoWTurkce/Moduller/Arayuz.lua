-- Genel arayüz çevirisi: Ayarlar, karakter penceresi (istatistik, itibar, beceriler, onur),
-- grup/raid yöneticisi, ESC menüsü. Pencere açıkken içindeki yazıları tarar ve sözlükte olanları
-- Türkçe yapar. Sadece yazıyı değiştirir; düğmelerin işlevine dokunmaz.
local OLAY_FIIL = { buried="gömüldü", freed="serbest bırakıldı", rescued="kurtarıldı", destroyed="yok edildi",
	explored="keşfedildi", found="bulundu", placed="yerleştirildi", planted="dikildi", cleansed="arındırıldı",
	captured="ele geçirildi", released="serbest bırakıldı", lit="yakıldı", burned="yakıldı", activated="etkinleştirildi",
	collected="toplandı", delivered="teslim edildi", defeated="yenildi", killed="öldürüldü", saved="kurtarıldı",
	escorted="korundu", marked="işaretlendi", investigated="araştırıldı", examined="incelendi", purified="arındırıldı",
	healed="iyileştirildi", discovered="keşfedildi", repaired="onarıldı", extinguished="söndürüldü", doused="söndürüldü",
	poisoned="zehirlendi", tamed="evcilleştirildi", summoned="çağrıldı", banished="sürgün edildi", slain="öldürüldü",
	captured_="ele geçirildi", visited="ziyaret edildi", searched="arandı", opened="açıldı", sabotaged="sabote edildi",
	infected="enfekte edildi", cured="iyileştirildi", fed="beslendi", returned="geri getirildi", protected="korundu",
	exploded="patlatıldı", detonated="patlatıldı", zapped="çarpıldı", shrunk="küçültüldü", touched="dokunuldu" }
local G = WoWTurkce
-- Görünürlük denetimi: bazı çerçeveler savaşta "gizli" (secret) değer döndürür; doğrudan if içinde kullanmak hata verir
local function gorunurMu(f)
	local ok, v = pcall(function() return f.IsShown and f:IsShown() and true or false end)
	return ok and v == true
end

-- Kaydedilmemesi gereken yazılar: kişisel bilgi (e-posta, link), oyuncu sohbeti, sohbet satırları,
-- cihaz adları ve bilerek İngilizce kalan özel adlar (NPC, bölge, fraksiyon adları)
function G.cop(s)
	if type(s) ~= "string" then return true end
	if s:find("@") or s:find("https?://") or s:find("www%.") then return true end
	if s:find("^%l") or s:find("^%s*/") then return true end
	if s:find(" says: ") or s:find(" yells: ") or s:find(" whispers: ") or s:find(" der: ") or s:find(" bağırır: ") then return true end
	if s:find("Audio") or s:find("Microphone") or s:find("Mikrofon") or s:find("Hoparl") or s:find("Speakers") or s:find("NVIDIA") or s:find("Realtek") or s:find("Radeon") or s:find("Desktop %-") then return true end
	if s:find("^%u%l+ %- %u") or s:find("^%u%l+ %d+ %- %u") then return true end -- "Furkan - Urfa", "Ege 3 - Manisa"
	if s:find("Changed Channel") or s:find("^%d+%. %a") then return true end
	-- Fısıltılar, sohbet satırları ve oyuncu adı geçen sistem mesajları: kişisel, kaydetme
	if s:find("^To %[") or s:find("^%[.-%]") or s:find("%]: ") or s:find(" creates ") or s:find("davet") or s:find("grupta%.") then return true end
	if s:find("%u%l+%-%u%a+") then return true end -- "Ad-Sunucu"
	local ben = UnitName and UnitName("player")
	if ben and ben ~= "" and s:find(ben, 1, true) then return true end
	-- Tek kelimelik, Türkçe/İngilizce olmayan harfli adlar ("Bekadiscó", "Freyjá")
	if not s:find("%s") and s:find("[\195][\128-\191]") and not s:find("[çğıöşüÇĞİÖŞÜ]") then return true end
	-- Yalnızca büyük harfle başlayan kelimelerden oluşan kısa yazılar (özel adlar): "Deathguard Lundmark", "Tirisfal Glades"
	local n, hepsi = 0, true
	for w in s:gmatch("%S+") do
		n = n + 1
		if not (w:find("^%u[%a'%.]*$") or w == "of" or w == "the" or w == "de") then hepsi = false; break end
	end
	if hepsi and n <= 4 then return true end
	return false
end

local KOKLER = {
	"SettingsPanel", "TutorialFrame", "CharacterFrame", "PaperDollFrame", "ReputationFrame", "SkillFrame", "HonorFrame",
	"CompactRaidFrameManager", "GameMenuFrame", "FriendsFrame", "AddonList", "InterfaceOptionsFrame",
	"VideoOptionsFrame", "KeyBindingFrame", "QuestLogFrame", "MerchantFrame", "ClassTrainerFrame",
	"TalentFrame", "PlayerTalentFrame", "MailFrame", "WorldMapFrame", "StaticPopup1", "StaticPopup2", "StaticPopup3", "StaticPopup4",
	"PVPFrame", "LFGParentFrame", "RaidFrame", "GuildFrame", "WhoFrame", "GossipFrame", "QuestFrame", "TaxiFrame",
	"BankFrame", "TradeFrame", "TradeSkillFrame", "CraftFrame", "PetStableFrame", "TabardFrame", "GuildRegistrarFrame",
	"InspectFrame", "DressUpFrame", "SpellBookFrame", "DropDownList1", "DropDownList2", "DropDownList3", "Lib_DropDownList1", "Lib_DropDownList2",
	"AuctionFrame", "ItemTextFrame", "BattlefieldFrame", "WorldStateScoreFrame", "ReadyCheckFrame", "LFGFrame", "LFTFrame", "ChannelFrame", "ColorPickerFrame", "GuildBankFrame", "PetPaperDollFrame", "BarberShopFrame", "ArenaFrame", "PetitionFrame", "CalendarFrame", "TokenFrame",
	"ChatMenu", "EmoteMenu", "LanguageMenu", "VoiceMacroMenu", "HelpFrame", "TimeManagerFrame", "ChatConfigFrame", "MacroFrame",
	"AuctionHouseFrame", "OpenMailFrame", "SendMailFrame", "InboxFrame", "LFGInvitePopup", "PartyInviteFrame", "LFGDungeonReadyPopup", "RolePollPopup",
}
-- Eklenti pencereleri (WoWTurkce'den önce yüklenip yazılarını XML ile koyanlar): adı bu öneklerle başlayan çerçeveler de taranır
local EK_ONEKLER = {} -- 3.3.0: diğer eklentilerin pencereleri artık çevrilmiyor (performans)
local ekKokler, ekKokZaman = {}, -100
-- Mağaza (Shop) ve onu açan düğmeler güvenli (korumalı) kodla çalışır. Bu yazılara eklentinin dokunması
-- "yalnızca Blizzard arayüzüne açık bir eylem engellendi" uyarısına yol açıyordu: bunlara hiç dokunma.
local KORUNAKLI = { "^WTR_Dok", "^Store", "Catalog", "Shop%f[^p]", "MicroButton", "MicroMenu", "^GameMenuButtonStore", "^StoreMicro", "^BlizzardStore" }
local korunakliBellek = setmetatable({}, { __mode = "k" })
-- 3.3.0: Diğer eklentilerin pencerelerine hiç dokunulmaz (çevrilmez, taranmaz, kaydedilmez): performans.
-- Çerçeve adı yüklü bir eklentinin adıyla ya da bilinen bir eklenti önekiyle başlıyorsa eklenti çerçevesi sayılır.
-- Questie hariç: görev takipçisindeki görev metinleri çevrilmeye devam eder.
local EK_SABIT = { "XPerl", "ZPerl", "BT4", "Bartender", "Titan", "LeaMaps", "LeaPlus", "Leatrix", "DBM", "BigWigs", "WeakAuras", "LibDBIcon", "AceConfig", "AceGUI",
	"ElvUI", "Plater", "VuhDo", "Vd%d", "Syndicator", "Baganator", "Bagnon", "BagBrother", "Atlas", "RSMap", "RareScanner", "RARESCANNER", "WIM", "Altoholic", "DataStore", "Pawn",
	"Healium", "Mapster", "BlizzMove", "AddonFactory", "GatherMate", "MBB", "MinimapButtonButton", "FDJ", "ForeverDungeonJournal", "DungeonJournal", "Auctionator",
	"IceHUD", "MoveAny", "Details", "TomTom", "BetterFishing", "Prat", "CMC", "Skada", "Recount", "OmniCC", "Clique", "Grid", "SUF", "ShadowUF", "PitBull", "Dominos" }
local ekOnekler
local function ekOnekKur()
	ekOnekler = {}
	for _, p in ipairs(EK_SABIT) do ekOnekler[#ekOnekler + 1] = "^" .. p end
	local say = (C_AddOns and C_AddOns.GetNumAddOns or GetNumAddOns)
	local bilgi = (C_AddOns and C_AddOns.GetAddOnInfo or GetAddOnInfo)
	if say and bilgi then
		for i = 1, say() do
			local ad = bilgi(i)
			if type(ad) == "string" and #ad >= 5 and not ad:find("^Blizzard_") and not ad:find("^WoWTurkce") and not ad:find("^Questie") then
				ekOnekler[#ekOnekler + 1] = "^" .. ad:gsub("%W", "%%%0")
			end
		end
	end
end
local function ekAdi(ad)
	if ad:find("^Questie") or ad:find("^WoWTurkce") or ad:find("^WTR_") then return false end
	if not ekOnekler then ekOnekKur() end
	for i = 1, #ekOnekler do if ad:find(ekOnekler[i]) then return true end end
	return false
end
local function korunakli(f)
	if not f then return false end
	local b = korunakliBellek[f]
	if b ~= nil then return b end
	local p, n, sonuc = f, 0, false
	while p and n < 10 do
		local ok, ad = pcall(p.GetName, p)
		if ok and type(ad) == "string" then
			for _, d in ipairs(KORUNAKLI) do if ad:find(d) then sonuc = true; break end end
			if not sonuc and ekAdi(ad) then sonuc = true end
			if sonuc then break end
		end
		local ok2, u = pcall(p.GetParent, p)
		p = ok2 and u or nil; n = n + 1
	end
	korunakliBellek[f] = sonuc
	return sonuc
end
G.korunakli = korunakli
-- Yazı/çerçeve bir eşya ipucunun içindeyse ve eşya çevirisi kapalıysa hiç dokunma (oyunun dilinde kalsın)
local ipucuSahipBellek = setmetatable({}, { __mode = "k" })
local function esyaIpucuIcinde(o)
	if not o then return false end
	local tp = ipucuSahipBellek[o]
	if tp == nil then
		tp = false
		local p, n = o, 0
		while p and n < 5 do
			if p.NumLines and p.GetItem and p.SetOwner then tp = p; break end
			local ok, u = pcall(p.GetParent, p)
			p = ok and u or nil; n = n + 1
		end
		ipucuSahipBellek[o] = tp
	end
	-- Eşya ipucu açıkken de buradan dokunulmaz: iki ayrı yerden yazılınca oyunun yenilemesiyle yarışıp titriyordu
	return tp and G.esyaIpucuMu(tp) or false
end
G.esyaIpucuIcinde = esyaIpucuIcinde

local ATLA_AD = { WoWTurkcePaylas = true, QuestLogDetailScrollFrame = true, QuestDetailScrollFrame = true,
	QuestProgressScrollFrame = true, QuestRewardScrollFrame = true, GossipGreetingScrollFrame = true, QuestGreetingScrollFrame = true }

-- Birim ipuçlarındaki kelimeler (ırk adları olduğu gibi kalır)
local KELIME = { Player = "Oyuncu", Elite = "Elit", Rare = "Nadir", ["Rare-Elite"] = "Nadir-Elit", Boss = "Boss",
	Beast = "Hayvan", Humanoid = "İnsansı", Demon = "İblis", Elemental = "Elemental", Dragonkin = "Ejderha",
	Giant = "Dev", Mechanical = "Mekanik", Critter = "Hayvancık", ["Not specified"] = "Belirsiz",
	Skinnable = "Yüzülebilir", Corpse = "Ceset", Tapped = "Alınmış", Pet = "Pet", Minion = "Hizmetkâr",
	Herbalism = "Bitkicilik", Mining = "Madencilik", Skinning = "Deri Yüzme", Totem = "Totem" }
local SINIF = { Warrior = "Savaşçı", Paladin = "Paladin", Hunter = "Avcı", Rogue = "Haydut", Priest = "Rahip",
	Shaman = "Şaman", Mage = "Büyücü", Warlock = "Warlock", Druid = "Druid" }

local TUS = {
	["Page Up"] = "Sayfa Yukarı", ["Page Down"] = "Sayfa Aşağı", ["Print Screen"] = "Ekran Görüntüsü",
	["Up Arrow"] = "Yukarı Ok", ["Down Arrow"] = "Aşağı Ok", ["Left Arrow"] = "Sol Ok", ["Right Arrow"] = "Sağ Ok",
	["Mouse Wheel Up"] = "Fare Tekerleği Yukarı", ["Mouse Wheel Down"] = "Fare Tekerleği Aşağı",
	["Middle Mouse"] = "Orta Fare Tuşu", ["Left Mouse Button"] = "Sol Fare Tuşu", ["Right Mouse Button"] = "Sağ Fare Tuşu",
	["Mouse Button 4"] = "Fare Tuşu 4", ["Mouse Button 5"] = "Fare Tuşu 5",
	["Space"] = "Boşluk", ["Backspace"] = "Geri Sil", ["Delete"] = "Sil", ["Insert"] = "Ekle",
	["Home"] = "Baş", ["End"] = "Son", ["Enter"] = "Enter", ["Escape"] = "Esc", ["Tab"] = "Tab",
	["Caps Lock"] = "Büyük Harf Kilidi", ["Scroll Lock"] = "Kaydırma Kilidi", ["Pause"] = "Duraklat",
}
-- "%s's X" başlıkları: "Mosad's Auctions" -> "Mosad'ın Müzayedeleri"
local IYELIK = {
	Auctions = "Müzayedeleri", Pets = "Evcil Hayvanları", Pet = "Evcil Hayvanı", Minion = "Kölesi", Guardian = "Koruyucusu",
	Totem = "Totemi", Mount = "Bineği", Spirit = "Ruhu", House = "Evi", ["New Balance"] = "Yeni Bakiyesi", Statue = "Heykeli",
	["War Banner"] = "Savaş Sancağı", Squire = "Silahtarı", Champion = "Şampiyonu", Bodyguard = "Koruması", Lightwell = "Işık Kuyusu",
	Gateway = "Geçidi", Assistant = "Yardımcısı", Companion = "Yoldaşı", Bank = "Bankası", Mailbox = "Posta Kutusu",
}
local function iyelikCevir(s)
	local ad, ne = s:match("^(.-)'s (.+)$")
	if not ad or ad == "" or not IYELIK[ne] then return nil end
	return ad .. "'" .. ((G.ekUyumla and G.ekUyumla(ad, "ın")) or "ın") .. " " .. IYELIK[ne]
end
G.iyelikCevir = iyelikCevir

-- Türkçeleşmiş / karışık metinlerin içinde kalan İngilizce özel adlar ("Bear Tartare hazırla.", "Gerekli: Cooking Fire",
-- "Legion Crafting Reagent"): bilinen en uzun ad öbeğini çevir. Yalnızca 2+ kelimelik öbekler.
local GENISLEME = { Classic = 1, Outland = 1, Northrend = 1, Cataclysm = 1, Pandaria = 1, Draenor = 1, Legion = 1, ["Kul"] = 1,
	Zandalari = 1, Shadowlands = 1, Dragon = 1, Khaz = 1, Midnight = 1, Broken = 1 }
local gomuBellek = {}
local function adBul(ph)
	local tr = (G.ZindanAdi and G.ZindanAdi[ph]) or (G.BuyuAdi and G.BuyuAdi[ph]) or (G.EsyaAdi and G.EsyaAdi[ph]) or G.Arayuz[ph] or (G.Nesne and G.Nesne[ph]) or (G.GorevAdi and G.GorevAdi[ph])
	if tr and tr ~= ph and not tr:find("|", 1, true) and not tr:find("#", 1, true) then return tr end
	-- "<Genişleme> <ad>": ilk kelimeyi koru, kalanı çevir ("Legion Crafting Reagent")
	local ilk, kalan = ph:match("^(%u%a+) (.+)$")
	if ilk and GENISLEME[ilk] then
		local k = adBul(kalan)
		if k then return ilk .. " " .. k end
	end
	local ik, kal = ph:match("^(%u%a+ %u%a+) (.+)$")
	if ik and (ik == "Dragon Isles" or ik == "Khaz Algar" or ik == "Kul Tiran" or ik == "Broken Isles") then
		local k = adBul(kal)
		if k then return ik .. " " .. k end
	end
end
local gomuluParca
function gomuluParca(s)
	if not s:find("%u%l+ %a") then return nil end
	local b = gomuBellek[s]
	if b ~= nil then return b or nil end
	local sonuc, degisti = s, false
	local kelimeler = {}
	for bas, w, son in s:gmatch("()([%a'%-]+)()") do kelimeler[#kelimeler + 1] = { bas, w, son } end
	local out, i, n = {}, 1, #kelimeler
	local son_pos = 1
	while i <= n do
		local k = kelimeler[i]
		local bulundu
		if k[2]:find("^%u") then
			for len = math.min(6, n - i + 1), 2, -1 do
				local ilk, last = kelimeler[i], kelimeler[i + len - 1]
				local ph = s:sub(ilk[1], last[3] - 1)
				if not ph:find("[^%a'%- ]") then
					local tr = adBul(ph)
					if tr then
						out[#out + 1] = s:sub(son_pos, ilk[1] - 1); out[#out + 1] = tr
						son_pos = last[3]; i = i + len; bulundu = true; degisti = true
						break
					end
				end
			end
		end
		if not bulundu then i = i + 1 end
	end
	if degisti then sonuc = table.concat(out) .. s:sub(son_pos) end
	if #gomuBellek < 0 then gomuBellek = {} end
	gomuBellek[s] = degisti and sonuc or false
	return degisti and sonuc or nil
end
-- Zindan/Raid adları (ek uyumlu: "Deadmines'ın" -> "Ölü Madenler'in") ve Türkçe metin içindeki tek kelimelik eşya adları
local zindanSirali
local function zindanGec(s)
	if not G.ZindanAdi then return nil end
	if not zindanSirali then
		zindanSirali = {}
		for en, tr in pairs(G.ZindanAdi) do zindanSirali[#zindanSirali + 1] = { en, tr } end
		table.sort(zindanSirali, function(a, b) return #a[1] > #b[1] end)
	end
	local r
	for _, p in ipairs(zindanSirali) do
		local en, tr = p[1], p[2]
		if s:find(en, 1, true) then
			local kalip = "%f[%w]" .. en:gsub("(%W)", "%%%1")
			local x = s:gsub(kalip .. "'([%a\195\196\128-\191]+)", function(ek) return tr .. "'" .. (G.ekUyumla and G.ekUyumla(tr, ek) or ek) end)
			x = x:gsub(kalip .. "%f[^%w]", (tr:gsub("%%", "%%%%")))
			if x ~= s then s = x; r = s end
		end
	end
	return r
end
local TEKSIZ = { Slightly = 1, Normal = 1, Common = 1, Poor = 1, Rare = 1, Epic = 1, Legendary = 1, Heroic = 1, Mythic = 1, Cooking = 1, Fishing = 1,
	Warrior = 1, Paladin = 1, Hunter = 1, Rogue = 1, Priest = 1, Shaman = 1, Mage = 1, Warlock = 1, Druid = 1, Horde = 1, Alliance = 1 }
local function tekEsyaGec(s)
	if not (G.turkceMi and G.turkceMi(s)) or not G.EsyaAdi then return nil end
	local degisti
	local r = s:gsub("%f[%a'%-](%u%l%l%l%l+)%f[^%a'%-]", function(w)
		if TEKSIZ[w] then return nil end
		local tr = G.EsyaAdi[w]
		if type(tr) == "string" and tr ~= w and #tr < 40 and not tr:find("[|#{]") then degisti = true; return tr end
	end)
	return degisti and r or nil
end
local gomuluIc
function G.gomuluCevir(s)
	local r = gomuluIc(s)
	if type(s) ~= "string" or #s > 400 then return r end
	local k = r or s
	local z = zindanGec(k)
	if z then k = z; r = z end
	local t = tekEsyaGec(k)
	if t then r = t end
	return r
end
function gomuluIc(s)
	if type(s) ~= "string" or #s > 400 then return nil end
	local function karma(r)
		if G.KarmaOn then
			local kaynak = r or s
			for en, tr in pairs(G.KarmaOn) do
				local a, b = kaynak:find(en, 1, true)
				if a then kaynak = kaynak:sub(1, a - 1) .. tr .. kaynak:sub(b + 1); r = kaynak end
			end
		end
		return r
	end
	if not s:find("|", 1, true) then return karma(gomuluParca(s)) end
	-- Renk kodlarını ayır, düz metin parçalarını ayrı ayrı çevir ("|cffffffffCooking Fire|r")
	local out, pos, degisti, not_ = {}, 1, false, false
	while pos <= #s do
		local a, b = s:find("|c%x%x%x%x%x%x%x%x", pos)
		for _, kal in ipairs({ "|H[^|]*|h", "|[rnh]" }) do
			local c, d = s:find(kal, pos)
			if c and (not a or c < a) then a, b = c, d end
		end
		local parca = s:sub(pos, (a or #s + 1) - 1)
		-- Kendi eklediğimiz gri "(English)" notuna dokunma (yoksa "Büyüyü Yut (Büyüyü Yut)" olur)
		local tr = parca ~= "" and not not_ and gomuluParca(parca)
		if tr then degisti = true end
		out[#out + 1] = tr or parca
		if a then
			local etiket = s:sub(a, b)
			out[#out + 1] = etiket; pos = b + 1
			not_ = (etiket == "|cff888888" or etiket == "|cffaaaaaa") and s:sub(pos, pos) == "("
		else break end
	end
	return karma(degisti and table.concat(out) or nil)
end
local function desenCevir(s)
	do local tr = iyelikCevir(s); if tr then return tr end end
	-- Questie eşya/yaratık ipucu: "1/1 Highly Toxic Strain (Filthy Mushroom)" / "(Erkin Azcan)"
	do
		local on, ad, ic = s:match("^(%s*%d+/%d+ )(.-) %((.+)%)$")
		if on and ad ~= "" then
			local function bul(x)
				return (G.EsyaAdi and G.EsyaAdi[x]) or (G.Yaratik and G.Yaratik[x]) or (G.Nesne and G.Nesne[x]) or G.Arayuz[x]
			end
			local atr = bul(ad)
			local r1, saf, r2 = ic:match("^(|c%x%x%x%x%x%x%x%x)(.-)(|r)$")
			if not r1 then r1, saf, r2 = "", ic, "" end
			local itr = bul(saf)
			if type(atr) == "string" or type(itr) == "string" then
				return on .. (type(atr) == "string" and atr or ad) .. " (" .. r1 .. (type(itr) == "string" and itr or saf) .. r2 .. ")"
			end
		end
	end
	-- Harita işareti ipucu (TomTom/Questie): "Turn in: Camping 101: Skinning" -> "Teslim et: Kampçılık 101: Deri Yüzme"
	do
		local fiil, ad = s:match("^(Turn in): (.+)$")
		if not fiil then fiil, ad = s:match("^(Accept): (.+)$") end
		if not fiil then fiil, ad = s:match("^(Objective): (.+)$") end
		if fiil and ad then
			local gad = (G.GorevAdi and G.GorevAdi[ad]) or G.Arayuz[ad]
			if gad then return ({ ["Turn in"] = "Teslim et", ["Accept"] = "Kabul et", ["Objective"] = "Hedef" })[fiil] .. ": " .. gad end
		end
	end
	-- Çanta penceresi başlığı (Baganator/Bagnon): "Erkin Azcan's Bags" -> "Erkin Azcan - Çantalar"
	do
		local kisi, tur = s:match("^(.-)'s (Bags)$")
		if not kisi then kisi, tur = s:match("^(.-)'s (Bank and Bags)$") end
		if not kisi then kisi, tur = s:match("^(.-)'s (Bank)$") end
		if not kisi then kisi, tur = s:match("^(.-)'s (Backpack)$") end
		if kisi and kisi ~= "" then
			local T = { ["Bags"] = "Çantalar", ["Bank and Bags"] = "Banka ve Çantalar", ["Bank"] = "Banka", ["Backpack"] = "Sırt Çantası" }
			return kisi .. " - " .. T[tur]
		end
	end
	-- "Structural - Windows": kategori - alt kategori, iki parça da biliniyorsa
	do
		local x, y = s:match("^(%a[%a' ]-) %- (%a[%a' ]-)$")
		if x and G.Arayuz[x] and G.Arayuz[y] then return G.Arayuz[x] .. " - " .. G.Arayuz[y] end
		x, y = s:match("^(%a[%a' ]-) | (%a[%a' ]-)$")
		if x and G.Arayuz[x] and G.Arayuz[y] then return G.Arayuz[x] .. " | " .. G.Arayuz[y] end
	end
	-- "(5) Mythic", "(3) Heroic": zorluk
	do
		local n, z = s:match("^%((%d+)%) (%a+)$")
		if n and G.Arayuz[z] and G.Arayuz[z] ~= z then return "(" .. n .. ") " .. G.Arayuz[z] end
	end
	-- "Complete the quest X in Y."
	do
		local q, yer = s:match("^Complete the quest (.-) in ([%u][%a' %-]+)%.$")
		if q then return yer .. " bölgesinde \"" .. (G.GorevAdi[q] or q) .. "\" görevini tamamla." end
	end
	-- Kalan süre kısaltmaları: "Tekrarlanabilir (Kalan: 5h)"
	do
		local on, sure = s:match("^(Tekrarlanabilir %(Kalan: )(.-)%)$")
		if on and sure:find("^[%d%a ]+$") then
			local r = sure:gsub("(%d+)h", "%1sa"):gsub("(%d+)d", "%1g"):gsub("(%d+)m", "%1dk")
			if r ~= sure then return on .. r .. ")" end
		end
	end
	-- "Toplam Sahip Olunan: # (Placed: #, Storage: #)"
	do
		local on, a, b = s:match("^(.-) %(Placed: (%d+), Storage: (%d+)%)$")
		if on then return on .. " (Yerleştirilen: " .. a .. ", Depoda: " .. b .. ")" end
	end
	-- Meslek unutma onayı
	do
		local m = s:match("^Do you want to unlearn (.-) and lose all associated recipes%?%s*Your specialization knowledge will remain should you choose to return to this profession%.$")
		if m then
			return (G.Arayuz[m] or m) .. " mesleğini unutmak ve ilgili tüm tarifleri kaybetmek istiyor musun? Bu mesleğe geri dönmeyi seçersen uzmanlık bilgin korunacak."
		end
	end
	-- "Legion Skinning 1/100": ad + ilerleme
	do
		local ad, sy = s:match("^(%a[%a' ]-) (%d+/%d+)$")
		local tr = ad and G.Arayuz[ad]
		if tr then return tr .. " " .. sy end
	end
	-- Yalnızca süreden oluşan yazılar: "59 Mins 51 Secs", "2 Days", "3 Hr"; "... remaining" / "Cooldown remaining: ..."
	if s:find("^%d+[%.,]?%d* %a+") then
		local govde, son = s:match("^(.-)%s+(remaining)$")
		local t = govde or s
		local temiz = t:gsub("%d+[%.,]?%d* (%a+)", function(b) return G.sureCevir("1 " .. b) ~= "1 " .. b and "" or b end):gsub("%s+", "")
		if temiz == "" then return G.sureCevir(t) .. (son and " kaldı" or "") end
	end
	do
		local kalan = s:match("^Cooldown remaining: (.+)$") or s:match("^Kalan bekleme süresi: (.+)$")
		if kalan and kalan:find("%d+ %a") then return "Kalan bekleme süresi: " .. G.sureCevir(kalan) end
	end
	-- "Level 2 Undead Priest" -> "Seviye 2 Undead Rahip"
	-- Birim ipucu: "Level 1 Undead Warlock (Player)", "Level ?? Elite Beast", "Level 5 Humanoid"
	local n, kalan = s:match("^Level (%S+) (.+)$")
	if n and (n:find("^%d+$") or n == "??") then
		kalan = kalan:gsub("%((%a+)%)", function(k) return "(" .. (KELIME[k] or k) .. ")" end)
		kalan = kalan:gsub("(%a+)", function(k) return KELIME[k] or k end) -- ırk ve sınıf adları İngilizce kalır
		return "Seviye " .. n .. " " .. kalan
	end
	-- Otomatik takip durumu: "Following Name" / "Following Name."
	do
		local ad = s:match("^Following (.-)%.?$")
		if ad and ad ~= "" then return ad .. " takip ediliyor" end
		if s == "Following" then return "Takip ediliyor" end
	end
	if KELIME[s] then return KELIME[s] end
	-- Karşılaştırma ipucu: "+16 Armor", "-3 Stamina", "+1.5 Damage Per Second"
	local isaret, ozellik = s:match("^([%+%-][%d%.,]+) (.+)$")
	if isaret then
		local tr = G.Arayuz[ozellik] or KELIME[ozellik]
		if tr then return isaret .. " " .. tr end
	end
	-- İlerleme çubuğu hedefi: "- Attack on Felsoul Hold (0%)"
	do
		local onk, ad, yz = s:match("^(%s*%-?%s*)Attack on (.-) %((%d+)%%%)$")
		if ad then return onk .. "Saldırı: " .. (G.Arayuz[ad] or ad) .. " (%" .. yz .. ")" end
		onk, ad, yz = s:match("^(%s*%-?%s*)(.-) %((%d+)%%%)$")
		if ad and G.Arayuz[ad .. " (#%)"] == nil and G.Arayuz[ad] then return onk .. G.Arayuz[ad] .. " (%" .. yz .. ")" end
	end
	-- Questie günlük satırı: "Friday, November 6, 2026 at 16:14 You Accepted the quest Discipline"
	do
		local GUN = { Monday = "Pazartesi", Tuesday = "Salı", Wednesday = "Çarşamba", Thursday = "Perşembe", Friday = "Cuma", Saturday = "Cumartesi", Sunday = "Pazar" }
		local AY = { January = "Ocak", February = "Şubat", March = "Mart", April = "Nisan", May = "Mayıs", June = "Haziran", July = "Temmuz",
			August = "Ağustos", September = "Eylül", October = "Ekim", November = "Kasım", December = "Aralık" }
		local VERB = { Accepted = "Kabul edilen görev:", Completed = "Tamamlanan görev:", Abandoned = "Bırakılan görev:" }
		local on, gun, ay, g, y, saat, fiil, gad = s:match("^(%s*)(%a+), (%a+) (%d+), (%d+) at (%d+:%d+)%s+You (%a+) the quest (.+)$")
		if gun and GUN[gun] and AY[ay] and VERB[fiil] then
			local ktr = G.GorevAdi[gad] or gad
			return on .. GUN[gun] .. ", " .. g .. " " .. AY[ay] .. " " .. y .. ", " .. saat .. " " .. VERB[fiil] .. " " .. ktr
		end
	end
	-- Meslek rehberi satırı: "Mining: Smelt Tin", "Cooking: Crab Cake" -> "Madencilik: Kalay Eritme (Smelt Tin)"
	do
		local MESLEK = { ["Mining"] = "Madencilik", ["Cooking"] = "Aşçılık", ["First Aid"] = "İlk Yardım", ["Blacksmithing"] = "Demircilik",
			["Leatherworking"] = "Deri İşleme", ["Tailoring"] = "Terzilik", ["Enchanting"] = "Büyücelik", ["Alchemy"] = "Simya",
			["Skinning"] = "Dericilik", ["Herbalism"] = "Bitkicilik", ["Engineering"] = "Mühendislik", ["Fishing"] = "Balıkçılık" }
		local onk, mes, tarif = s:match("^(%s*)([%a ]+): (.+)$")
		if mes and MESLEK[mes] and tarif then
			local tr = G.BuyuAdi and G.BuyuAdi[tarif] or (G.esyaAdiGoster and G.esyaAdiGoster(tarif))
			if tr and tr ~= tarif then
				return onk .. MESLEK[mes] .. ": " .. (G.adStil and G.adStil("stilBuyu", tr, tarif, "|cffaaaaaa") or tr)
			elseif tarif:find("[çğıöşüÇĞİÖŞÜ]") then
				return onk .. MESLEK[mes] .. ": " .. tarif
			end
		end
	end
	-- Sayı önde görev hedefi: "0/8 Juvenile Vuldren slain", "1/1 Samuel's Remains buried"
	do
		local onk2, sy2, ad2, fiil2 = s:match("^(%s*%-?%s*)(%d+/%d+) (.-) (%a+)$")
		local ftr2 = fiil2 and OLAY_FIIL[fiil2:lower()]
		if sy2 and ftr2 and ad2 ~= "" then
			local ktr2 = G.gorevNpc(ad2) or G.Arayuz[ad2] or G.esyaAdiGoster(ad2) or ad2
			return onk2 .. sy2 .. " " .. ktr2 .. " " .. ftr2
		end
	end
	-- Retail görev hedefi: "- 0/1 Bring 400 Ancient Mana to Thalyssra", "0/15 Sovereign Soul"
	do
		local onk, sy, gv = s:match("^(%s*%-?%s*)(%d+/%d+) (.+)$")
		do
			local nsy, nad = s:match("^(%s*[%d,%.]+) (%a.+)$")
			if nsy and nad then
				local tr = G.Arayuz[nad] or (G.esyaAdiGoster and G.esyaAdiGoster(nad))
				if tr and tr ~= nad then return nsy .. " " .. tr end
			end
		end
		-- Questie ipucu satırı: "5/6 Duskbat Wing  [75%]" (yüzde ve renk kodu sonda kalır)
		if sy and gv then
			local core, kuyruk = gv:match("^(.-)(%s+[|%x]*%[%d+%%%][|r]*)$")
			if core and core ~= "" then
				local ad = core:gsub("%s+$", "")
				local tr
				local yad = ad:match("^(.-) slain$")
				if yad then tr = (G.gorevNpc(yad) or yad) .. " öldürüldü"
				else tr = G.Arayuz[ad] or G.esyaAdiGoster(ad) or G.gorevNpc(ad) end
				if tr and tr ~= ad then return onk .. sy .. " " .. tr .. kuyruk end
			end
		end
		local opt = ""
		if gv and gv:find("%s%(Optional%)$") then gv = gv:gsub("%s%(Optional%)$", ""); opt = " (İsteğe bağlı)" end
		if sy and gv and gv:find(" slain$") then
			local yad2 = (gv:gsub(" slain$", ""))
			return onk .. sy .. " " .. (G.gorevNpc(yad2) or yad2) .. " öldürüldü" .. opt
		end
		if sy and gv then
			local tr = G.Arayuz[gv] or G.esyaAdiGoster(gv) or G.gorevNpc(gv)
			if tr and tr ~= gv then return onk .. sy .. " " .. tr .. opt end
		end
	end
	-- Questie duyurusu: "Questie: 12/12 Rattlecage Skeleton slain for Kafesleri Sallamak!"
	do
		local sy, gv, gor = s:match("^Questie: (%d+/%d+) (.-) for (.+)!$")
		if sy and gv then
			local yad = gv:match("^(.-) slain$")
			local ad
			if yad then
				local g = G.gorevNpc(yad) or yad
				ad = g .. " öldürüldü"
			else
				ad = G.Arayuz[gv] or (G.esyaAdiGoster and G.esyaAdiGoster(gv)) or G.gorevNpc(gv) or gv
			end
			return "Questie: " .. sy .. " " .. ad .. " – " .. (G.GorevAdi[gor] or gor) .. "!"
		end
		local gor2 = s:match("^Questie: Quest Completed: (.+)$")
		if gor2 then return "Questie: Görev tamamlandı: " .. (G.GorevAdi[gor2] or gor2) end
	end
	-- Görev hedefleri: " - Mindless Zombie slain: 8/8"
	local on, ad, sayi, art = s:match("^(%s*%-?%s*)(.-) slain: (%d+/%d+)(.*)$")
	if ad and ad ~= "" then
		local gos = G.gorevNpc(ad)
		return on .. (gos or ad) .. " öldürüldü: " .. sayi .. (art or "")
	end
	-- Sayısız: "Juvenile Vuldren slain"
	on, ad = s:match("^(%s*%-?%s*)(.-) slain%s*$")
	if ad and ad ~= "" and not ad:find("[:/]") then return on .. (G.gorevNpc(ad) or ad) .. " öldürüldü" end
	-- Questie takipçisi: "   Thurman's Remains: 2/5 (Mosad)  [40%]" -> sondaki oyuncu adı ve yüzdeyi ayır
	do
		local bas, kuyruk = s:match("^(.-: %d+/%d+)(%s+.+)$")
		if bas and (kuyruk:match("^%s*%([^%)]*%)%s*$") or kuyruk:match("^%s*%[%d+%%%]%s*$") or kuyruk:match("^%s*%([^%)]*%)%s*%[%d+%%%]%s*$")) then
			local t = desenCevir(bas)
			if t then return t .. kuyruk:gsub("%[(%d+)%%%]", "[%%%1]") end
		end
	end
	on, ad, sayi = s:match("^(%s*%-?%s*)(.-): (%d+/%d+)$")
	-- Olay hedefleri: "Samuel's Remains Buried: 0/1", "Prisoners Freed: 2/5"
	if ad then
		local kok, fiil = ad:match("^(.-) (%a+)$")
		local ftr = fiil and OLAY_FIIL[fiil:lower()]
		if ftr then
			local ktr = G.Arayuz[kok] or G.esyaAdiGoster(kok) or (G.modul("yaratik") and G.Yaratik[kok]) or kok
			return on .. ktr .. " " .. ftr .. ": " .. sayi
		end
	end
	-- Eşya hedefleri her zaman Türkçe; yaratık adları sadece "Yaratık adları" açıkken
	-- Özel görev hedefleri ("Heal and fortify Deathguard Kel: 0/1")
	if ad and G.Arayuz[ad] then return on .. G.Arayuz[ad] .. ": " .. sayi end
	local gad = ad and G.esyaAdiGoster(ad)
	if gad then return on .. gad .. ": " .. sayi end
	do local gn = ad and G.gorevNpc(ad); if gn then return on .. gn .. ": " .. sayi end end
	-- Tuş adları: "CTRL-SHIFT-Page Down", "Num Pad 5", "SHIFT-Mouse Wheel Up"
	local mod, tus = "", s
	while true do
		local m, r = tus:match("^(%u+%-)(.+)$")
		if not m then break end
		mod = mod .. m; tus = r
	end
	if tus ~= "" then
		local ttr = TUS[tus]
		if not ttr then
			local n = tus:match("^Num Pad (.+)$")
			if n then ttr = "Sayı Tuşu " .. n end
		end
		-- Genel kelimelerle karışabilecek tuşlar sadece "CTRL-" gibi önekle çevrilir
		if ttr and mod == "" and (tus == "Home" or tus == "End" or tus == "Delete" or tus == "Insert" or tus == "Space" or tus == "Pause" or tus == "Enter" or tus == "Escape" or tus == "Tab") then ttr = nil end
		if ttr then return mod .. ttr end
	end
	-- İsim içeren arayüz kalıpları (arkadaş notu, davet...)
	local kim = s:match("^Set Notes for (.+)$")
	if kim then return kim .. " için not yaz" end
	-- Tarih: "Sunday, November 01, 2026 at 22:38"
	local gun, ay, gn, yil, saat = s:match("^%s*(%a+), (%a+) (%d+), (%d+) at (%d+:%d+)%s*$")
	if gun then
		local GUN = { Monday = "Pazartesi", Tuesday = "Salı", Wednesday = "Çarşamba", Thursday = "Perşembe", Friday = "Cuma", Saturday = "Cumartesi", Sunday = "Pazar" }
		local AY = { January = "Ocak", February = "Şubat", March = "Mart", April = "Nisan", May = "Mayıs", June = "Haziran", July = "Temmuz", August = "Ağustos", September = "Eylül", October = "Ekim", November = "Kasım", December = "Aralık" }
		if GUN[gun] and AY[ay] then return tonumber(gn) .. " " .. AY[ay] .. " " .. yil .. " " .. GUN[gun] .. ", " .. saat end
	end
	-- Harita koordinatları: "Cursor: 74.8 X, 49.2 Y  |  Player: 58.3 X , 51.5 Y"
	if s:find("^Player: [%d%.]+,") then return (s:gsub("^Player:", "Oyuncu:")) end
	if s:find("^Cursor: ") then
		local r = s:gsub("^Cursor:", "İmleç:"):gsub("Player:", "Oyuncu:")
		return r
	end
	kim = s:match("^Do you want to make (.+) your new home%?$")
	if kim then return kim .. " yeni evin olsun mu?" end
	kim = s:match("^Discovered: (.+)$")
	if kim then return "Keşfedildi: " .. kim end
	local yer, xp = s:match("^Discovered (.+): (%d+) experience gained$")
	if yer then return "Keşfedildi: " .. yer .. " (+" .. xp .. " deneyim)" end
	kim = s:match("^Friends of (.+)$")
	if kim then return "Arkadaşları: " .. kim end
	kim = s:match("^(.-) %(Mutual%)$")
	if kim then return kim .. " (Ortak)" end
	kim = s:match("^Corpse of (.+)$")
	if kim then return "Ceset: " .. kim end
	kim = s:match("^(.+)'s Minion$")
	if kim then return "Uşak (" .. kim .. ")" end
	kim = s:match("^(.+)'s Pet$")
	if kim then return "Evcil Hayvan (" .. kim .. ")" end
	kim = s:match("^Do you want to destroy (.+)%?$")
	if kim then return (G.esyaAdiGoster(kim) or kim) .. " yok edilsin mi?" end
	local bolge, diyar = s:match("^Zone: (.-)|nRealm: (.+)$")
	if bolge then return "Bölge: " .. bolge .. "|nDiyar: " .. diyar end
	kim = s:match("^(.+) has challenged you to a duel%.$")
	if kim then return kim .. " seni düelloya davet etti." end
	kim = s:match("^You have requested to trade with (.+)%.$")
	if kim then return kim .. " ile takas isteği gönderdin." end
	kim = s:match("^(.+) attempts to run away in fear!$")
	if kim then return kim .. " korku içinde kaçmaya çalışıyor!" end
	kim = s:match("^Requires:? (.+)$")
	if kim then
		local tr = G.isimCevir(kim) or G.esyaAdiGoster(kim)
		if tr then return "Gerekli: " .. tr end
	end
	local yeni = s:match("^You have learned a new spell: (.+)%.$")
	if yeni then return "Yeni bir büyü öğrendin: " .. ((G.buyuAdiCevir and G.buyuAdiCevir(yeni)) or yeni) .. "." end
	on, ad = s:match("^(%s*%-?%s*)(.-) %(Complete%)$")
	if ad then
		-- Seviye öneki olabilir: "[5] Gordo's Task (Complete)" ve "(Failed)"
		local sev, ad2 = ad:match("^(%[[^%]]*%]%s*)(.+)$")
		if sev then return on .. sev .. (G.GorevAdi[ad2] or ad2) .. " (Tamamlandı)" end
		return on .. (G.GorevAdi[ad] or ad) .. " (Tamamlandı)"
	end
	-- Açılır menü: "Loot: Group Loot", "Pass on Loot: No"
	local etiket, deger = s:match("^(.-): (.+)$")
	if etiket and G.Arayuz[etiket .. ":"] then return G.Arayuz[etiket .. ":"] .. " " .. (G.Arayuz[deger] or deger) end
	-- Çıkış geri sayımı: "20 Seconds until logout", "1 Min until exit"
	local sayi, birim, ne = s:match("^(%d+) (%a+%.?) until (%a+)%.?$")
	if sayi then
		local b = birim:lower():sub(1, 3)
		b = (b == "sec" and "saniye") or (b == "min" and "dakika") or (b == "hou" and "saat") or birim
		local hedef = (ne == "logout" and "Oturumun kapanmasına") or (ne == "exit" or ne == "quit") and "Oyundan çıkışa" or nil
		if hedef then return hedef .. " " .. sayi .. " " .. b end
	end
	local bilgi = s:match("^For more information see our (.+)$")
	if bilgi then return "Daha fazla bilgi için: " .. bilgi:gsub("Privacy Policy", "Gizlilik Politikası") end
	-- Açılır uyarılar
	local g = s:match("^Abandon (.+)%?$")
	if g then return (G.GorevAdi[g] or g) .. " görevini bırakmak istiyor musun?" end
	g = s:match("^Do you want to delete (.+)%?$")
	if g then return g .. " silinsin mi?" end
	g = s:match("^(.+) has invited you to join a group%.$")
	if g then return g .. " seni bir gruba davet etti." end
	g = s:match("^(.+) has invited you to join the guild (.+)%.$")
	g = s:match("^Quest accepted: (.+)$")
	if g then return "Görev kabul edildi: " .. (G.GorevAdi[g] or g) end
	g = s:match("^(.+) completed%.$")
	if g and G.GorevAdi[g] then return G.GorevAdi[g] .. " tamamlandı." end
	g = s:match("^You receive item: %[(.+)%]%.?$")
	if g then return "Eşya aldın: [" .. (G.EsyaAdi[g] or g) .. "]." end
	g = s:match("^You receive loot: (.+)$")
	if g then return "Ganimet aldın: " .. g end
	local dil = s:match("^Language: (.+)$")
	if dil then return "Dil: " .. dil end
	local a, b = s:match("^(.-):%s*(.+)$") -- "Etiket: değer"
	if a and G.Arayuz[a .. ":"] and not b:find("%a") then return G.Arayuz[a .. ":"] .. " " .. b end
	-- Oyunun kendi isimli/değişkenli metinleri (GlobalStrings desenleri)
	-- Önce birebir sözlükler (oyun ipuçları, büyü açıklamaları...), en son genel desenler
	local tam = G.cevir(G.Egitim, s) or G.cevir(G.Buyu, s) or G.cevir(G.Secenek, s) or G.cevir(G.Hata, s)
	if tam then return tam end
	if G.globalDesenCevir then return G.globalDesenCevir(s) end
end

local cevirAsil
local function renksiz(s)
	return (s:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|cn[%w_]+:", ""):gsub("|[rR]", ""))
end
G.renksiz = renksiz
-- ForeverDB rotasyon satırı: "1. Power Word: Shield (level 6)" -> "1. Güç Sözü: Kalkan (Power Word: Shield) (seviye 6)"
local function rotasyonSatiri(s)
	local on, rest = s:match("^(%s*%d+%.%s+)(.+)$")
	if not on then return nil end
	local i = rest:find("%(level %d+%)") or rest:find("%(talent%)")
	if not i then return nil end
	local head, tail = rest:sub(1, i - 1), rest:sub(i)
	local pre = head:match("(%s*|c%x%x%x%x%x%x%x%x%s*)$") or head:match("(%s+)$") or ""
	local ad = head:sub(1, #head - #pre)
	if ad == "" then return nil end
	local tr = G.BuyuAdi and (G.BuyuAdi[ad] or (G.buyuAdiCevir and G.buyuAdiCevir(ad)))
	local yeni = tail:gsub("%(level (%d+)%)", "(seviye %1)"):gsub("%(talent%)", "(yetenek)")
	if not tr and yeni == tail then return nil end
	local gorunen = tr and G.adStil("stilBuyu", tr, ad) or ad
	return on .. gorunen .. pre .. yeni
end
-- Beceri penceresi savaş tablosu satırları (renk kodlu / kısmen çevrilmiş olabilir)
local function savasSatiri(s)
	if not (s:find("Chance to", 1, true) or s:find("Glancing Blows", 1, true)) then return nil end
	local degisti, cikti = false, {}
	for satir in (s .. "\n"):gmatch("(.-)\n") do
		local bas = satir:match("^(|[cC]%x%x%x%x%x%x%x%x)")
		local son = satir:find("|[rR]%s*$") and "|r" or ""
		local d = renksiz(satir):gsub("^%s+", ""):gsub("%s+$", "")
		local tr
		local v = d:match("^Chance to Hit, [andve]+ to avoid being Dodged or Parried:%s*(.+)$")
		if v then tr = "İsabet şansı ve Savuşturulma ya da Sıyırma ile karşılanmaktan kaçınma şansı: " .. v end
		if not tr then v = d:match("^Chance to Critically Hit:%s*(.+)$"); if v then tr = "Kritik Vuruş şansı: " .. v end end
		if not tr then
			local a1, a2 = d:match("^Glancing Blows occur (.-) of the time [andve]+ deal (.-) less damage$")
			if a1 then tr = "Teğet Vuruşlar zamanın " .. a1 .. " kadarında gerçekleşir ve " .. a2 .. " daha az hasar verir" end
		end
		if tr then degisti = true; satir = (bas or "") .. tr .. son end
		cikti[#cikti + 1] = satir
	end
	if degisti then return table.concat(cikti, "\n") end
end
-- Simgeyi ayır: baştaki ya da sondaki "|A:..|a" / "|T..|t"
local function simgeAyir(s)
	local bas, kalan = s:match("^(|[AT].-|[at]%s*)(.+)$")
	if bas then return bas, kalan, "" end
	local kalan2, son = s:match("^(.-)(%s*|[AT].-|[at])$")
	if kalan2 and kalan2 ~= "" then return "", kalan2, son end
	return "", s, ""
end
G.simgeAyir = simgeAyir
local function cevirHam(s)
	if G.gizli(s) or type(s) ~= "string" or s == "" then return nil end
	if G.gereksinimSatiri then local g = G.gereksinimSatiri(s); if g then return g end end
	-- Altoholic/DataStore sayaçları: "1 (Bags: 1, Bank: 2)" -> "1 (Çantalar: 1, Banka: 2)"
	if s:find("(", 1, true) and s:find(":", 1, true) then
		local SAYAC = { Bags = "Çantalar", Bank = "Banka", AH = "Müzayede", Equipped = "Kuşanılmış", Mail = "Posta", ["Reagent Bag"] = "Malzeme Çantası", ["Reagent Bank"] = "Malzeme Bankası", ["Void Storage"] = "Boşluk Deposu", Currency = "Para Birimi", ["Account Bank"] = "Hesap Bankası", ["Guild Bank"] = "Lonca Bankası" }
		local biri = false
		local r = s:gsub("([%(,]%s*)(%a[%a ]-)(:|?r?%s*|?c?%x*%d)", function(a, k, b)
			local tr = SAYAC[k]; if tr then biri = true; return a .. tr .. b end
		end)
		if biri then return r end
	end
	if G.turkceMi(s) then return nil end
	-- Oyuncu, lonca ve topluluk adları hiçbir zaman çevrilmez
	if G.oyuncuMu and G.oyuncuMu(s) then return nil end
	-- Birden çok simge: "|A:..|a Campaign   |A:..|a Dungeon" -> her parçayı ayrı çevir
	do
		local _, sn = s:gsub("|[AT]", "")
		if sn >= 2 then
			local biri = false
			local r = s:gsub("(|[AT].-|[at])([^|]*)", function(ic, txt)
				local b0, govde, son0 = txt:match("^(%s*)(.-)(%s*)$")
				local tr = govde ~= "" and cevirAsil(govde)
				if tr then biri = true; return ic .. b0 .. tr .. son0 end
			end)
			if biri then return r end
		end
	end
	local bas, kalan, son = simgeAyir(s)
	if bas ~= "" or son ~= "" then
		local tr = cevirAsil(kalan)
		return tr and (bas .. tr .. son)
	end
	return cevirAsil(s)
end
-- Çeviri önbelleği: aynı yazı (ipucu satırları, taramalar) her seferinde baştan çevrilmesin
local cevirBellek, cevirBellekSay = {}, 0
local function cevirHesapla(s)
	local r = cevirHam(s)
	if r and r:find("%d+ %a+") and r:find("[Hh]our") or (r and r:find("%d+ [MmSsDd][ie][nca][sy]?s?%f[%A]")) then r = G.sureCevir(r) end
	return r
end
local function cevir(s)
	if type(s) ~= "string" or G.gizli(s) then return cevirHesapla(s) end
	if not s:find(" ", 1, true) and G.oyuncuMu(s) then return nil end
	local b = cevirBellek[s]
	if b ~= nil then return b or nil end
	local r = cevirHesapla(s)
	if cevirBellekSay >= 20000 then cevirBellek = {}; cevirBellekSay = 0 end
	cevirBellek[s] = r or false; cevirBellekSay = cevirBellekSay + 1
	return r
end
G.dinle(function() cevirBellek = {}; cevirBellekSay = 0 end)
local paragrafCevir
-- Eğitmen/tarif gereksinim satırı: "Requires: Level 16, Mind Blast (Rank 1)" -> her parça ayrı ve hep aynı şekilde çevrilir
-- (yarı çevrilmiş "Gerektirir: Level 16, ..." satırları da tamamlanır; böylece tıklayınca dil gidip gelmez)
local function gerekParca(p)
	local c = p:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", "")
	local bas, govde, son = c:match("^(%s*)(.-)(%s*)$")
	local tr
	local n = govde:match("^Level (%d+)$") or govde:match("^Seviye (%d+)$")
	if n then tr = "Seviye " .. n end
	if not tr then
		local ad, r = govde:match("^(.-) %(Rank (%d+)%)$")
		if not ad then ad, r = govde:match("^(.-) %(Rütbe (%d+)%)$") end
		if ad then
			local at = G.turkceMi(ad) and ad or (G.BuyuAdi and G.BuyuAdi[ad]) or (G.buyuAdiCevir and G.buyuAdiCevir(ad)) or G.Arayuz[ad] or ad
			tr = at .. " (Rütbe " .. r .. ")"
		end
	end
	if not tr then
		local ad, d = govde:match("^(.-) %((%d+)%)$")
		if ad then
			local at = G.turkceMi(ad) and ad or (G.BuyuAdi and G.BuyuAdi[ad]) or G.Arayuz[ad] or ad
			tr = at .. " (" .. d .. ")"
		end
	end
	if not tr then tr = G.turkceMi(govde) and govde or (G.BuyuAdi and G.BuyuAdi[govde]) or G.Arayuz[govde] or govde end
	-- Renk kodlarını koru: ilk renk açılışı ve kapanışı
	local ac = p:match("|[cC]%x%x%x%x%x%x%x%x")
	local kap = p:find("|[rR]") and "|r" or ""
	return (ac or "") .. bas .. tr .. son .. kap
end
local function gereksinimSatiri(s)
	if type(s) ~= "string" or not (s:find("Requires", 1, true) or s:find("Gerektirir:", 1, true)) then return nil end
	local temiz = s:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", "")
	local onEk, kalan = s:match("^(.-Requires:?%s*)(.+)$")
	if not onEk then onEk, kalan = s:match("^(.-Gerektirir:%s*)(.+)$") end
	if not onEk then return nil end
	if not (temiz:find("^%s*Requires") or temiz:find("^%s*Gerektirir:")) then return nil end
	local renk = onEk:match("^(|[cC]%x%x%x%x%x%x%x%x)") or ""
	local parcalar = {}
	for parca in (kalan .. ","):gmatch("(.-),") do parcalar[#parcalar + 1] = gerekParca(parca) end
	local y = table.concat(parcalar, ",")
	-- Öneki: "Requires" -> "Gerektirir:" (renk korunur)
	local on = onEk:gsub("Requires:?%s*", "Gerektirir: ")
	local sonuc = on .. y
	if sonuc == s then return nil end
	return sonuc
end
G.gereksinimSatiri = gereksinimSatiri

cevirAsil = function(s)
	if not s or s == "" then return nil end
	do local g = gereksinimSatiri(s); if g then return g end end
	if G.turkceMi(s) then return nil end
	do local rs = rotasyonSatiri(s); if rs then return rs end end
	do local ss = savasSatiri(s); if ss then return ss end end
	if s:find("|n", 1, true) then
		-- "|n" satır sonu: önce bütün, olmazsa satır satır çevir (çevrilemeyen satır olduğu gibi kalır)
		local tam = G.cevir(G.Arayuz, renksiz(s):gsub("|n", " "))
		if tam then return tam end
		local parcalar, biri = {}, false
		for satir in (s .. "|n"):gmatch("(.-)|n") do
			local tr = satir:find("%S") and cevirAsil(satir)
			if tr then biri = true end
			parcalar[#parcalar + 1] = tr or satir
		end
		if biri and #parcalar > 1 then return table.concat(parcalar, "|n") end
	end
	if s:find("\n%s*\n") then
		local tr = paragrafCevir(s)
		if tr then return tr end
	end
	if s:find("\n") and not s:find("\n%s*\n") then
		-- Tek satır sonlarıyla ayrılmış satırlar: her satırı ayrı çevir
		local tam = G.cevir(G.Arayuz, renksiz(s))
		if tam then return tam end
		local parcalar, n = {}, 0
		for satir in (s .. "\n"):gmatch("(.-)\n") do
			n = n + 1
			if satir:find("%S") then
				local tr = cevirAsil(satir)
				if not tr then parcalar = nil; break end
				parcalar[n] = tr
			else parcalar[n] = satir end
		end
		if parcalar and n > 1 then return table.concat(parcalar, "\n") end
	end
	local temiz = renksiz(s)
	-- Tam büyü adı önce ("Power Word: Shield" -> "Güç Sözü: Kalkan"; yarım çeviri olmasın)
	local tr = G.cevir(G.Arayuz, temiz)
	-- Renk kodlu anahtarlar ("Position your hands and click |cFFFFD100Okay|r"): sözlükte renkli
	-- kayıtlı olanlar renksiz metinle bulunamıyordu; metni renkleriyle birlikte de dene (renk korunur)
	if not tr and temiz ~= s then
		tr = G.cevir(G.Arayuz, s)
		if not tr then
			local buyuk = s:gsub("|[cC](%x%x%x%x%x%x%x%x)", function(h) return "|c" .. h:upper() end)
			if buyuk ~= s then tr = G.cevir(G.Arayuz, buyuk) end
		end
	end
	if not tr and G.BuyuAdi then
		-- Eğitmen listelerinde adlar baştaki boşluklarla gelir ("  Power Word: Shield")
		local bas, sade = temiz:match("^(%s*)(.-)%s*$")
		local b = sade and (G.BuyuAdi[sade] or (G.buyuAdiCevir and G.buyuAdiCevir(sade)))
		if b then tr = bas .. b end
	end
	if not tr then
		-- Görev adları kısmi (kelime kelime) çeviriden ÖNCE tam eşleşmeyle çevrilir; görev adlarına İngilizce eklenmez
		local bosluk0, on0, ad0 = temiz:match("^(%s*)(%[[^%]]+%]%s*)(.-)$")
		if not ad0 then bosluk0, ad0 = temiz:match("^(%s*)(.-)$"); on0 = "" end
		if ad0 and G.GorevAdi[ad0] then return bosluk0 .. on0 .. G.GorevAdi[ad0] end
	end
	tr = tr or desenCevir(temiz)
	if not tr then
		-- Görev günlüğündeki görev adları ("  The Mindless Ones", "[5] Rude Awakening")
		local bosluk, on, ad = temiz:match("^(%s*)(%[[^%]]+%]%s*)(.-)$")
		if not ad then bosluk, ad = temiz:match("^(%s*)(.-)$"); on = "" end
		if ad and G.GorevAdi[ad] then tr = bosluk .. on .. G.GorevAdi[ad] end
	end
	if not tr then
		-- Büyü ve eşya adları, "Rank 3" alt başlıkları
		local bt = G.buyuAdiCevir and G.buyuAdiCevir(temiz)
		if bt then
			-- Büyü adı: ayardaki yazım tarzına göre ("Türkçe (English)")
			tr = G.BuyuAdi[temiz] and G.adStil("stilBuyu", bt, temiz) or bt
		elseif G.EsyaAdi[temiz] then
			tr = G.adStil("stilEsya", G.EsyaAdi[temiz], temiz)
		end
		if not tr then
			local n = temiz:match("^Rank (%d+)$")
			if n then tr = "Rütbe " .. n end
		end
		if not tr and G.BuyuAlt[temiz] then tr = G.BuyuAlt[temiz] end
		if not tr then tr = G.yaratikCevir(temiz) end
	end
	if not tr then
		-- Diğer sözlükler: oyun ipuçları, büyü açıklamaları, konuşma seçenekleri, hata mesajları
		tr = G.cevir(G.Egitim, temiz) or G.cevir(G.Buyu, temiz) or G.cevir(G.Secenek, temiz) or G.cevir(G.Hata, temiz)
	end
	if not tr and s:find("|c%x%x%x%x%x%x%x%x") then
		-- Renkli parçalı yazılar: "Buyout Price |cff808080(optional)|r" -> her parçayı ayrı çevir
		local parcalar, hepsi, biri = {}, true, false
		local i = 1
		local function parca(metin, onEk, sonEk)
			if metin:find("%a") then
				local b, govde, son = metin:match("^(%s*)(.-)(%s*)$")
				local t = G.cevir(G.Arayuz, govde) or desenCevir(govde)
				if t then biri = true; metin = b .. t .. son else hepsi = false end
			end
			parcalar[#parcalar + 1] = onEk .. metin .. sonEk
		end
		while true do
			local a, b, renk, ic = s:find("(|c%x%x%x%x%x%x%x%x)(.-)|r", i)
			if not a then parca(s:sub(i), "", ""); break end
			if a > i then parca(s:sub(i, a - 1), "", "") end
			parca(ic, renk, "|r")
			i = b + 1
		end
		if hepsi and biri then return table.concat(parcalar) end
	end
	if not tr then
		-- "ETİKET: açıklama" satırları (ayar ipuçları: "CMAA: Conservative ...")
		local etiket, aciklama = temiz:match("^([^:]+):%s+(.+)$")
		if etiket and #etiket <= 40 then
			local atr = G.cevir(G.Arayuz, aciklama) or desenCevir(aciklama)
			if atr then
				local i, j = s:find(aciklama, 1, true)
				local etr = G.cevir(G.Arayuz, etiket)
				if i then
					local yeni = s:sub(1, i - 1) .. atr .. s:sub(j + 1)
					if etr then
						local a, b = yeni:find(etiket, 1, true)
						if a then yeni = yeni:sub(1, a - 1) .. etr .. yeni:sub(b + 1) end
					end
					return yeni
				end
				return (etr or etiket) .. ": " .. atr
			end
		end
	end
	if not tr then
		-- Renkli etiketli kaynak satırı: |cFFFFD200Vendor: |rAd  -> etiket sarı kalır, değer beyaz
		local bas, et, ara, dg = s:match("^(|c%x%x%x%x%x%x%x%x)(%a[%a ]-):(%s*)|r(.+)$")
		local etr = et and G.EtiketTr and G.EtiketTr[et]
		if etr then
			local ds = G.cevir(G.Arayuz, renksiz(dg)) or dg
			for en, trk in pairs(G.DurumTr or {}) do ds = ds:gsub(" %- " .. en .. "$", " - " .. trk) end
			return bas .. etr .. ":" .. ara .. "|r" .. ds
		end
	end
	if not tr then
		-- Kaynak satırları: "Vendor: Ad", "Zone: Ad", "Faction: Ad - Exalted", "Cost: 100" (ad ve değer İngilizce kalır)
		local et, dg = temiz:match("^(%a[%a ]-):%s*(.+)$")
		local etr = et and G.EtiketTr and G.EtiketTr[et]
		if etr then
			local ds = G.cevir(G.Arayuz, dg) or dg
			for en, trk in pairs(G.DurumTr or {}) do ds = ds:gsub(" %- " .. en .. "$", " - " .. trk) end
			tr = etr .. ": " .. ds
		end
	end
	if not tr and s:find("\n", 1, true) and #s < 1500 then
		-- Çok satırlı kaynak blokları ("Vendor: ..\nZone: ..\nFaction: ..\nCost: 70"): her etiketli satırı ayrı çevir
		local out, biri = {}, false
		for line in (s .. "\n"):gmatch("(.-)\n") do
			local c1, et, sp, r, dg = line:match("^(|c%x%x%x%x%x%x%x%x)(%a[%a ]-):(%s*)(|r)(.*)$")
			if not et then c1, r = "", ""; et, sp, dg = line:match("^(%a[%a ]-):(%s*)(.*)$") end
			local etr = et and G.EtiketTr and G.EtiketTr[et]
			if etr then
				local ds = dg
				if dg ~= "" and not dg:find("|", 1, true) then
					ds = G.cevir(G.Arayuz, dg) or dg
					for en, trk in pairs(G.DurumTr or {}) do ds = ds:gsub(" %- " .. en .. "$", " - " .. trk) end
				end
				line = c1 .. etr .. ":" .. sp .. r .. ds
				biri = true
			end
			out[#out + 1] = line
		end
		if biri then tr = table.concat(out, "\n") end
	end
	if not tr then
		-- Baştaki boşluklarla girintili adlar ("  Power Word: Fortitude" - eğitmen/makro listeleri)
		local bosluk, govde = temiz:match("^(%s+)(%S.-)$")
		if govde then
			local gtr = G.cevir(G.Arayuz, govde) or (G.buyuAdiCevir and G.buyuAdiCevir(govde)) or G.EsyaAdi[govde]
			if gtr then tr = bosluk .. gtr end
		end
	end
	if not tr then
		-- Oyuncu adı geçen yazılar: "... for you, Mosad?" -> sözlükte "$N"
		local oyuncu = UnitName and UnitName("player")
		if oyuncu and oyuncu ~= "" then
			local kac = oyuncu:gsub("(%W)", "%%%1")
			if temiz:find(kac) then
				local ntr = G.cevir(G.Arayuz, (temiz:gsub(kac, "$N")))
				if ntr then tr = ntr:gsub("%$N", (oyuncu:gsub("%%", "%%%%"))) end
			end
		end
	end
	if tr and temiz ~= s then
		-- renk kodunu koru
		local bas = s:match("^(|c%x%x%x%x%x%x%x%x)")
		if bas then tr = bas .. tr .. "|r" end
	end
	return tr
end
-- Paragraflara bölüp her birini ayrı çevir (hepsi çevrilirse birleştir)
paragrafCevir = function(s)
	local tam = G.cevir(G.Arayuz, (s:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", "")))
	if tam then return tam end
	local parcalar, n, biri = {}, 0, false
	for p in (s .. "\n\n"):gmatch("(.-)\n%s*\n") do
		if p:find("%S") then
			n = n + 1
			local tr = cevirAsil(p)
			if tr then biri = true end
			parcalar[n] = tr or p
		end
	end
	if n < 2 or not biri then return nil end
	return table.concat(parcalar, "\n\n")
end
G.arayuzCevir = cevir

local kaydedilen = 0
local function kaydet(s)
	-- Arayüz yazıları artık kaydedilmiyor (yalnızca NPC ve görev pencereleri): hiç iş yapma
	if not G.KAYIT_IZINLI or not G.KAYIT_IZINLI.arayuz then return end
	if kaydedilen > 30000 or not G.ayar("kayit") then return end
	if s:find("WoWTurkce") or s:find("WoWTurkce") or s:find("^Level level") then return end
	local _, ic = simgeAyir(s)
	s = renksiz(ic):gsub("|H.-|h(.-)|h", "%1")
	if s:find("|[TKA]") then return end
	if #s < 3 or #s > 600 or not s:find("%a%a") then return end
	-- Tek kelimelik büyük harfle başlayan yazılar çoğunlukla oyuncu/NPC adıdır: kaydetme
	-- Tek kelimelik büyük harfle başlayan yazılar çoğunlukla ad: ayrı "kelime" kategorisine yaz (çeviride ayıklanır)
	if not s:find("[ :]") and s:find("^%u[%l']+$") then
		if not G.Yaratik[s] and not G.OyuncuAdi[s] and #s >= 3 then G.kaydetDiger("kelime", s) end
		return
	end
	if not s:find(" ") and s:find("%-") then return end
	if s:find("^%S+%-%S+,") or s:find("^%u+%d+$") then return end -- oyuncu-sunucu adları
	if s:find("^<") or s:find("^%[") then return end -- guild adları, sohbet kanalları
	if s:find("^%s*/") then return end -- sohbet komutları (/dance, /reload)
	if not s:find("%u") then return end -- tamamı küçük harf: oyuncu sohbeti
	if G.Yaratik[s] then return end -- yaratık adları bilerek İngilizce kalıyor
	local yad = s:match("^(.-) %(.+%)$"); if yad and G.Yaratik[yad] then return end
	if G.cop(s) then return end
	if s:find("%(VB%-Audio") or s:find("Audio") or s:find("Microphone") or s:find("NVIDIA") or s:find("Mikrofon") or s:find("Hoparl") then return end -- cihaz adları
	if s:find("%a%-%u%l") and s:find("%u%l+%-%u%l+") then return end -- "Ad-Sunucu" geçen yazılar
	-- Kendi çıktılarımız: "Türkçe (English)" biçimi
	local ic = s:match("^.+ %((.+)%)$")
	if ic and (G.EsyaAdi[ic] or G.BuyuAdi[ic]) then return end
	-- Kendi çevirilerimizi (Türkçe harfsiz olanlar dahil) tekrar kaydetme
	-- Kendi çevirilerimizin listesi arka planda hazırlanır; hazır değilse bu sefer kaydetme (kayıt şart değil, takılma olmasın)
	if not G.cevirDegerleri then return end
	local norm = s:gsub("%d+", "#")
	if G.cevirDegerleri[norm] or s:find("^Seviye ") then return end
	local kok = norm:match("^(.-)%s*%(%u+%)$") -- "Sosyal (O)"
	if kok and G.cevirDegerleri[kok] then return end
	kaydedilen = kaydedilen + 1
	G.kaydetDiger("arayuz", (s:gsub("%d+", "#")))
end

G.arayuzKaydet = function(t) if type(t) == "string" then kaydet(t) end end
G.arkaPlan(function()
	local d, say = {}, 0
	for _, tablo in ipairs({ G.Arayuz, G.BuyuAdi, G.EsyaAdi, G.GorevAdi, G.Egitim, G.Hata, G.Secenek, G.Esya, G.BuyuAlt, G.BuyuSekme, G.Yaratik }) do
		for _, v in pairs(tablo) do
			say = say + 1
			if say % 300 == 0 then G.adim() end
			if type(v) == "string" then d[(v:gsub("{%d}", "#"))] = true end
		end
	end
	G.cevirDegerleri = d
end)

-- Karışık çok satırlı yazı: bir satırı Türkçe, diğerleri İngilizce olabilir ("...armor types:\nKumaş").
-- İngilizce satırları tek tek çevirir, çevrilemeyenleri kaydeder; en az bir satır çevrildiyse sonucu döndürür.
local function karisikCevir(t)
	if type(t) ~= "string" or #t > 1500 then return nil end
	local ayrac = t:find("\n", 1, true) and "\n" or (t:find("|n", 1, true) and "|n") or nil
	local nokta = " \194\183 " -- "A · B · C" biçimli tek satırlar (ForeverDB vb.)
	if not ayrac and t:find(nokta, 1, true) then
		local parcalar, degisti = {}, false
		local i = 1
		while true do
			local a, b = t:find(nokta, i, true)
			local seg = t:sub(i, a and a - 1 or #t)
			if seg:find("%a%a") and not G.turkceMi(renksiz(seg)) then
				local tr = cevir(seg) or G.gomuluCevir(seg)
				if tr and tr ~= seg then seg = tr; degisti = true else pcall(kaydet, seg) end
			end
			parcalar[#parcalar + 1] = seg
			if not a then break end
			i = b + 1
		end
		return degisti and table.concat(parcalar, nokta) or nil
	end
	if not ayrac then
		-- Türkçe harf içerdiği için sablon çevirisine girmeyen "Görev adı from NPC al" satırları
		local q, npc = t:match("^(.-) from (%u[^|]-) al$")
		if q and q ~= "" then return q .. ", " .. npc .. " kişisinden al" end
		local q2, npc2 = t:match("^(.-) to (%u[^|]-) teslim et$")
		if q2 and q2 ~= "" then return q2 .. ", " .. npc2 .. " kişisine teslim et" end
		-- Görev rehberi satır sonundaki durum etiketi: "[2] Akılsızlar |cff3ddc84ready|r"
		local on, son = t:match("^(.-)ready(|r)$")
		if not on then on = t:match("^(.-)ready$"); son = "" end
		if on and (on:find("%s$") or on:find("%x%x%x%x%x%x%x%x$")) then return on .. "hazır" .. son end
		return nil
	end
	local parcalar, degisti = {}, false
	for satir in (t .. ayrac):gmatch("(.-)" .. (ayrac == "|n" and "|n" or "\n")) do
		if satir:find("%a%a") and not G.turkceMi(renksiz(satir)) then
			local tr = cevir(satir) or G.gomuluCevir(satir)
			if tr and tr ~= satir then satir = tr; degisti = true else pcall(kaydet, satir) end
		end
		parcalar[#parcalar + 1] = satir
	end
	return degisti and table.concat(parcalar, ayrac) or nil
end
G.karisikCevir = karisikCevir
-- gomuluCevir "X from NPC al" biçiminde yarım sonuç verirse hemen tam Türkçesine çevir (iki durum arasında titremesin)
do
	local og = G.gomuluCevir
	if og then
		G.gomuluCevir = function(t)
			local r = og(t)
			if type(r) == "string" then
				local q, npc = r:match("^(.-) from (%u[^|]-) al$")
				if q and q ~= "" then r = q .. ", " .. npc .. " kişisinden al" end
				local q2, npc2 = r:match("^(.-) to (%u[^|]-) teslim et$")
				if q2 and q2 ~= "" then r = q2 .. ", " .. npc2 .. " kişisine teslim et" end
			end
			return r
		end
	end
end
-- cevir sonucu kısmen İngilizce kalmış "A · B · C" ise parçaları da çevir (dinlenmiş/rested titremesi)
local function sonCevir(t)
	local tr = cevir(t)
	if tr and tr:find(" \194\183 ", 1, true) then
		local k = karisikCevir(tr)
		if k then tr = k end
	end
	return tr
end

local gorulen = setmetatable({}, { __mode = "k" }) -- fontstring -> son yazdığımız metin
-- Sohbet yazma kutusu ("Konuş:" gibi başlıklar) ve diğer yazı kutuları: genişlik İngilizceye göre
-- ayarlandığı için çevirince yazılar iç içe geçiyor; bunlara hiç dokunma.
-- Uzmanlık (specialization) adları İngilizce kalır: Demon Hunter / Havoc gibi
local UZMAN_NET = {}
for ad in ("Havoc|Vengeance|Devourer|Arms|Beast Mastery|Marksmanship|Survival|Assassination|Outlaw|Subtlety|Discipline|Elemental|Enhancement|Restoration|Affliction|Demonology|Destruction|Balance|Feral|Guardian|Brewmaster|Mistweaver|Windwalker|Devastation|Preservation|Augmentation|Unholy|Retribution"):gmatch("[^|]+") do UZMAN_NET[ad] = true end
local UZMAN_BELIRSIZ = { Holy = true, Shadow = true, Frost = true, Fire = true, Arcane = true, Blood = true, Protection = true, Fury = true }
local function uzmanAdi(fs)
	local t = fs.GetText and fs:GetText()
	if type(t) ~= "string" or G.gizli(t) then return false end
	if UZMAN_NET[t] then return true end
	if UZMAN_BELIRSIZ[t] then
		local p, n = fs, 0
		while p and n < 6 do
			local pn = p.GetName and p:GetName()
			if pn and (pn:find("Spec") or pn:find("Talent") or pn:find("PlayerSpells") or pn:find("Inspect")) then return true end
			p = p.GetParent and p:GetParent(); n = n + 1
		end
	end
	return false
end

local function yaziKutusunda(fs)
	if uzmanAdi(fs) then return true end
	local ad = fs.GetName and fs:GetName()
	local u = fs.GetParent and fs:GetParent()
	-- Arama kutusunun silik ipucu yazısı ("Search") çevrilebilir; yalnızca yazılan metin dokunulmaz
	if u and u.Instructions == fs then return false end
	if ad and ad:find("Instructions$") then return false end
	do
		local ok, pk = pcall(function() return fs.GetParentKey and fs:GetParentKey() end)
		if ok and pk == "Instructions" then return false end
	end
	if ad and ad:find("EditBox") then
		local okE, fe = pcall(fs.GetText, fs)
		if not (okE and type(fe) == "string" and fe:find(":%s*$") and #fe < 40 and type(G.Arayuz[fe]) == "string" and not ad:find("^ChatFrame")) then return true end
	end
	if u and u.GetObjectType and u:GetObjectType() == "EditBox" then
		-- Yazı kutusunun kendi yazısına dokunma; ama kutuya iliştirilmiş etiket (ör. Auctionator "Label") çevrilir
		local ok, ut = pcall(u.GetText, u)
		local ok2, ft = pcall(fs.GetText, fs)
		if not (ok and ok2 and type(ft) == "string" and ft ~= "" and ft ~= ut) then return true end
	end
	local un = u and u.GetName and u:GetName()
	if un and un:find("EditBox") then
		-- Kutuya iliştirilmiş bilinen etiket ("To:", "Subject:"): çevrilebilir
		local ok2, ft = pcall(fs.GetText, fs)
		if not (ok2 and type(ft) == "string" and ft:find(":%s*$") and #ft < 40 and type(G.Arayuz[ft]) == "string" and not un:find("^ChatFrame")) then return true end
	end
	-- Bölge adları (minimap başlığı, bölge afişi) İngilizce kalır
	local p, n = fs, 0
	while p and n < 4 do
		local pn = p.GetName and p:GetName()
		if pn and (pn:find("ZoneText") or pn:find("MinimapZone")) then return true end
		p = p.GetParent and p:GetParent(); n = n + 1
	end
	return false
end
G.yaziKutusunda = yaziKutusunda

-- Onay penceresindeki "Unlearn" düğmesi: "Onayla"
local function popupOnay(fs, t)
	if t ~= "Unlearn" then return false end
	local u, d = fs, 0
	while u and d < 6 do
		local ad = u.GetName and u:GetName()
		if ad and ad:find("^StaticPopup") then return true end
		u = u.GetParent and u:GetParent(); d = d + 1
	end
	return false
end
local gorevTrKume
local gorevTrKumeIs = G.arkaPlan(function()
	local d, say = {}, 0
	for _, v in pairs(G.GorevAdi) do
		say = say + 1
		if say % 500 == 0 then G.adim() end
		if type(v) == "string" then d[v] = true end
	end
	gorevTrKume = d
end)
-- Zaten Türkçeye çevrilmiş bir yazıyı ikinci kez çevirme ("Sell" -> "Sat" -> "Cmt" olmasın)
local trDeger
local trDegerIs = G.arkaPlan(function()
	local d, say = {}, 0
	for k, v in pairs(G.Arayuz) do
		say = say + 1
		if say % 500 == 0 then G.adim() end
		if type(v) == "string" and v ~= k and #v < 60 and not v:find("{", 1, true) then d[v] = true end
	end
	trDeger = d
end)
function G.trDegerMi(t)
	if type(t) ~= "string" or t == "" then return false end
	-- Arka plan işi bitmeden gerekirse hemen bitir (yalnızca girişten sonraki ilk saniyelerde olur)
	if not trDeger then trDegerIs.bitir() end
	return trDeger ~= nil and trDeger[t] == true and G.Arayuz[t] ~= nil
end
-- Eşya ipucu satırları için genel çeviri (Ipucu modülü kendi çeviremediği satırlarda kullanır; tek yazan o olsun)
function G.genelCevir(t)
	local ok, tr = pcall(function() return sonCevir(t) or karisikCevir(t) or G.gomuluCevir(t) end)
	if ok and type(tr) == "string" and tr ~= t then return tr end
end
local function yaziIsle(fs)
	-- Bir kez işlenen yazı değişmediyse hiç dokunma (aynı metni tekrar tekrar okumasın)
	local t = fs:GetText()
	if t == nil or t == "" or gorulen[fs] == t then return end
	if yaziKutusunda(fs) or korunakli(fs) or esyaIpucuIcinde(fs) then return end
	if G.gizli(t) then return end
	-- Yazı tipi atanmamış yazılar SetText'te "Font not set" hatası verir; varsayılan yazı tipini ver
	if type(t) == "string" and t ~= "" and fs.GetFont and fs.SetFontObject then
		local okf, df = pcall(fs.GetFont, fs)
		if okf and not df then pcall(fs.SetFontObject, fs, GameFontNormal) end
	end
	if popupOnay(fs, t) then G.sigdirKoy(fs, "Onayla"); gorulen[fs] = "Onayla"; return end
	-- Kendi eklediğimiz gri Türkçe ad notu varsa bir daha işleme (iç içe "(Acemi Elreth (Acemi Elreth))" olmasın)
	if type(t) == "string" and (t:find("|cffaaaaaa(", 1, true) or t:find("|cff888888(", 1, true)) then return end
	if G.gizli(t) then return end
	if not t or t == "" or gorulen[fs] == t then return end
	if G.YerAdi and (G.YerAdi[t] or G.YerAdi[(renksiz(t))]) then gorulen[fs] = t; return end -- yer/zindan adları İngilizce kalır
	if G.trDegerMi(t) then gorulen[fs] = t; return end
	-- Eklentiye özel çeviri (aynı İngilizce yazı o eklentide farklı çevrilsin): G.EkOzel[onek][metin]
	local tr
	if G.EkOzelMetin[t] then
		local f, n = fs, 0
		while f and n < 12 and not tr do
			local ad = f.GetName and f:GetName()
			if ad then for onek, tablo in pairs(G.EkOzel) do if tablo[t] and ad:find(onek) then tr = tablo[t]; break end end end
			f = f.GetParent and f:GetParent(); n = n + 1
		end
	end
	if not tr then tr = sonCevir(t) end
	if not tr then tr = karisikCevir(t) end
	if not tr and G.gorevHedefBul then tr = G.gorevHedefBul(t) end -- görev listesindeki hedef özeti
	-- Türkçe görev adına dokunma ("Çubuklar ve Kemikler" -> "Çubuklar ve Bones (Kemikler)" olmasın)
	if not gorevTrKume then gorevTrKumeIs.bitir() end
	local gorevTrMi
	do
		local kontrol = renksiz(tr or t)
		local _, ad1 = kontrol:match("^(%s*%[[^%]]+%]%s*)(.-)%s*$")
		gorevTrMi = gorevTrKume[kontrol] or (ad1 and gorevTrKume[ad1]) or gorevTrKume[(kontrol:gsub("^%s+", ""):gsub("%s+$", ""))]
	end
	if not gorevTrMi then local g = G.gomuluCevir(tr or t); if g then tr = g end end -- kalan İngilizce adları da çevir
	if tr then
		G.sigdirKoy(fs, tr); gorulen[fs] = tr
		G.tani.cevrilen = G.tani.cevrilen + 1
	else
		gorulen[fs] = t
		if not G.turkceMi(t) then G.sigdirSifirla(fs); kaydet(t)
		elseif t:find("\n", 1, true) then
			-- Yarı Türkçe çok satırlı metin: İngilizce kalan satırları ayrı ayrı kaydet
			for satir in (t .. "\n"):gmatch("(.-)\n") do
				local d = satir:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", ""):gsub("^%s+", ""):gsub("%s+$", "")
				if d:find("%a%a+%s+%a%a+") and not G.turkceMi(d) and not cevir(satir) then kaydet(satir) end
			end
		end
	end
end

G.tani = { taranan = 0, cevrilen = 0, hata = nil }
-- VuhDo: düğmenin kendi (gizli) yazısı; VuhDo bunu ayrı etiketlere kopyalıyor. Dokunursak büyük sarı yazı olarak görünüyor.
local function vuhdoGizli(fs)
	local p = fs.GetParent and fs:GetParent()
	local pn = p and p.GetName and p:GetName()
	if not (pn and pn:find("^VuhDo")) then return false end
	if p.GetFontString and p:GetFontString() == fs then return true end
	local fn = fs.GetName and fs:GetName()
	return fn == nil and p.GetObjectType and (p:GetObjectType() == "CheckButton" or p:GetObjectType() == "Button")
end
local function guvenliIsle(fs)
	if vuhdoGizli(fs) then return end
	G.tani.taranan = G.tani.taranan + 1
	local ok, e = pcall(yaziIsle, fs)
	if not ok then G.tani.hata = tostring(e) end
end

local function tara(f, derin)
	if derin > 14 or not f or (f.IsForbidden and f:IsForbidden()) then return end
	if f.IsShown and not f:IsShown() then return end
	local ad = f.GetName and f:GetName()
	if ad and ATLA_AD[ad] then return end
	-- Çanta pencereleri hiç taranmaz (istek üzerine; eşya açıklamaları ipucundan zaten çevriliyor)
	if ad and (ad:find("^Baganator") or ad:find("^Bagnon") or ad:find("^BagBrother") or ad:find("^Syndicator") or ad:find("^ContainerFrame") or ad:find("^BankFrame")
		or ad:find("^LootFrame") or ad:find("^GroupLoot") or ad:find("^LootHistory") or ad:find("^BonusRoll") or ad:find("^MasterLooter")) then return end
	if korunakli(f) or esyaIpucuIcinde(f) then return end
	-- Eşya düğmesi (çanta/banka yuvası): yalnızca sayı ve simge
	do
		local esya = false
		pcall(function() esya = (f.IconBorder ~= nil and (f.Count ~= nil or f.icon ~= nil)) or (f.GetItemID ~= nil and f.Count ~= nil) end)
		if esya then return end
	end
	if f.GetObjectType and f:GetObjectType() == "FontString" then guvenliIsle(f); return end
	if f.GetRegions then
		for _, r in ipairs({ f:GetRegions() }) do
			if r.GetObjectType and r:GetObjectType() == "FontString" and r:IsShown() then guvenliIsle(r) end
		end
	end
	-- Düğme yazıları (GetFontString)
	if f.GetFontString then local ok, fs = pcall(f.GetFontString, f); if ok and fs then guvenliIsle(fs) end end
	if f.GetChildren then
		for _, c in ipairs({ f:GetChildren() }) do
			-- Eşya düğmeleri (çanta/banka/satıcı yuvaları): içlerinde yalnızca sayı ve simge var; yüzlercesini taramak
			-- çanta açılınca takılma yapıyordu
			local esya = false
			pcall(function() esya = (c.IconBorder ~= nil and (c.Count ~= nil or c.icon ~= nil)) or (c.GetItemID ~= nil and c.Count ~= nil) end)
			local ok, e = true, nil
			if not esya then ok, e = pcall(tara, c, derin + 1) end
			if not ok then G.tani.hata = tostring(e) end
		end
	end
end

-- İpucu kutusunu satırlarına sığdır. Savaşta kutu boyutu değiştirilemeyebilir:
-- o zaman taşan satırın yazısını kutuya sığacak kadar küçült.
local ipucuFontAsil = {}
local function ipucuSigdir(tt)
	if not tt or not tt.NumLines or (tt.IsForbidden and tt:IsForbidden()) then return end
	-- Kendi Show çağrımız Show kancalarını yeniden tetiklemesin (zincirleme çeviri = takılma)
	G._sigdirde = true; pcall(tt.Show, tt); G._sigdirde = false
	local ad = tt:GetName(); if not ad then return end
	local en = tt:GetWidth() or 0
	for i = 1, tt:NumLines() do
		local fs = _G[ad .. "TextLeft" .. i]
		local sag = _G[ad .. "TextRight" .. i]
		if fs and fs:IsShown() and fs:GetText() then
			if not ipucuFontAsil[fs] then local f, b, st = fs:GetFont(); if f then ipucuFontAsil[fs] = { f, b, st or "" } end end
			local gerek = (fs:GetStringWidth() or 0) + ((sag and sag:IsShown() and sag:GetText()) and (sag:GetStringWidth() + 12) or 0) + 22
			-- Satır kaydırılan (çok satırlı) yazılar kutuyu genişletmez; aksi hâlde ipucu ekran boyu açılıyor
			-- Kaydırılabilen satırlar (açıklamalar) hiç genişletme sebebi sayılmaz: yoksa satır bir tek bir çift satır
			-- olup ipucu her yenilemede genişleyip daralıyor (titreme)
			local cokSatir = (fs.GetNumLines and (fs:GetNumLines() or 1) > 1) or (fs.CanWordWrap and fs:CanWordWrap())
			if cokSatir then gerek = 0 end
			if gerek > 420 then gerek = 420 end
			if gerek > en + 1 then
				local ok = pcall(tt.SetWidth, tt, gerek)
				if not ok or (tt:GetWidth() or 0) + 1 < gerek then
					local a = ipucuFontAsil[fs]
					if a then
						local oran = math.max(0.6, (en - 22 - (gerek - 22 - fs:GetStringWidth())) / fs:GetStringWidth())
						if oran < 1 and G.kucult("ipucu") then if G.fontSerbest(fs) then fs:SetFont(a[1], math.floor(a[2] * oran * 10) / 10, a[3]) end end
					end
				else
					en = tt:GetWidth()
				end
			end
		end
	end
end
local function ipucuFontSifirla(tt)
	local ad = tt and tt.GetName and tt:GetName(); if not ad then return end
	for i = 1, 4 do
		local fs = _G[ad .. "TextLeft" .. i]
		local a = fs and ipucuFontAsil[fs]
		if a then if G.fontSerbest(fs) then fs:SetFont(a[1], a[2], a[3]) end end
	end
end
G.ipucuSigdir = ipucuSigdir
-- Genel ipuçları (düğme, mini harita, menü çubuğu ipuçları). Eşya/büyü/birim ipuçlarına dokunmaz.
local imzaParca = {}
local function ipucuImza(tt, ad)
	local n = tt:NumLines() or 0
	if n == 0 then return nil end
	for i = 1, n do
		local l, r = _G[ad .. "TextLeft" .. i], _G[ad .. "TextRight" .. i]
		local a = l and l:IsShown() and l:GetText() or ""
		local b = r and r:IsShown() and r:GetText() or ""
		if G.gizli(a) or G.gizli(b) then return nil end
		imzaParca[i] = a .. "\31" .. b
	end
	for i = n + 1, #imzaParca do imzaParca[i] = nil end
	return table.concat(imzaParca, "\30", 1, n)
end
G.ipucuImza = ipucuImza
local function ipucuTara(tt)
	if not G.modul("arayuz") or not tt or not tt.NumLines then return end
	if G.esyaIpucuMu(tt) then return end
	local birim = tt.GetUnit and tt:GetUnit()
	if G.gizli(birim) then birim = true end -- Retail: gizli birim adı; yine birim ipucu say
	local ad = tt:GetName(); if not ad or ad == "WTR_DokTip" then return end
	-- Aynı içerik zaten işlendiyse tekrar okuma (fareyle aynı satırın üstünde gezinirken)
	local imza = ipucuImza(tt, ad)
	if imza and tt._gtrImza == imza then return end
	local degisti = false
	-- Oyuncu ipucu: adı ve lonca adı asla çevrilmez
	local oyuncu = false
	if birim and birim ~= true then
		local ok, op = pcall(UnitIsPlayer, birim)
		oyuncu = ok and op and true or false
		if oyuncu then G.oyuncuEkle(birim) end
	end
	if oyuncu then
		for i = 2, tt:NumLines() do
			local fs = _G[ad .. "TextLeft" .. i]
			local t = fs and fs:IsShown() and fs:GetText()
			if t and not G.gizli(t) and not G.turkceMi(t) then
				local tr = desenCevir(G.renksiz(t))
				if tr then fs:SetText(tr); degisti = true end
			end
		end
		if degisti then ipucuSigdir(tt) end
		return
	end
	if birim then
		local fs = _G[ad .. "TextLeft1"]
		local t = fs and fs:GetText()
		if G.gizli(t) then t = nil end
		local temiz = t and G.renksiz(t)
		local ytr = temiz and G.yaratikCevir(temiz)
		if ytr then
			local gos = G.adStil("stilYaratik", ytr, temiz, "|cffaaaaaa")
			fs:SetText((t:gsub(temiz:gsub("(%W)", "%%%1"), (gos:gsub("%%", "%%%%"))))); degisti = true
		elseif temiz and G.modul("arayuz") and not t:find("|cffaaaaaa(", 1, true) and not temiz:find("(", 1, true) and G.adTr(temiz) then
			-- Yaratık/NPC adları kapalı: orijinal ad kalır, yanına Türkçesi gri yazılır
			if G.ayar("stilYaratik") ~= "en" then
				fs:SetText((t:gsub(temiz:gsub("(%W)", "%%%1"), (G.adStil("stilYaratik", G.adTr(temiz), temiz, "|cffaaaaaa"):gsub("%%", "%%%%"))))); degisti = true
			end
		end
	end
	-- Görev takip ipucu: "<Click to view Quest Details>" altındaki görev özeti (hedef metni) veritabanındaki Türkçesiyle değiştir
	do
		local n = tt:NumLines() or 0
		local son = n >= 3 and _G[ad .. "TextLeft" .. n]
		local st = son and son:GetText()
		if st and (st:find("Click to view Quest Details", 1, true) or st:find("Görev Ayrıntılarını görmek için tıkla", 1, true)) then
			if not G.gorevBaslikIdx then
				local idx = {}
				for _, tb in ipairs({ G.Veri or {}, G.VeriEk or {} }) do
					for _, v in pairs(tb) do
						if type(v) == "table" and v.b and v.h and idx[v.b] == nil then idx[v.b] = v.h end
					end
				end
				G.gorevBaslikIdx = idx
			end
			local l1 = _G[ad .. "TextLeft1"]
			local bas = l1 and l1:GetText()
			bas = bas and G.renksiz(bas):gsub("^%[%d+%+?%]%s*", ""):gsub("^%s+", "")
			local h = bas and (G.gorevBaslikIdx[bas] or (G.GorevAdi and G.gorevBaslikIdx[G.GorevAdi[bas] or ""]))
			if h then
				for i = 2, n - 1 do
					local fs = _G[ad .. "TextLeft" .. i]
					local t = fs and fs:GetText()
					if t and not t:find("^%s*%-") and not t:find("^|c%x%x%x%x%x%x%x%x%-") and #t > 25 then
						local yeni = G.doldur and G.doldur(G.gorevAdCevir and G.gorevAdCevir(h) or h) or h
						if t ~= yeni then fs:SetText(yeni); degisti = true end
						break
					end
				end
			end
		end
	end
	local ilk = birim and 2 or 1
	if ilk == 1 and tt.GetSpell then
		-- Büyü ipucunun 1. satırı (büyü adı) ayardaki yazıma göre "Türkçe (English)" olarak Ipucu modülünde işlenir
		local oks, sn = pcall(tt.GetSpell, tt)
		if oks and sn then ilk = 2 end
	end
	if ilk == 1 then
		-- Buff/debuff ipucu (Forever'da GetSpell boş döner): 1. satır aura adıdır; "Türkçe (English)" yazımını
		-- Ipucu modülü yapar, burada düz Türkçeye çevirip İngilizcesini kaybettirme
		local l1 = _G[ad .. "TextLeft1"]
		local t1 = l1 and l1:GetText()
		local saf = type(t1) == "string" and not G.gizli(t1) and renksiz(t1) or nil
		local okS, sahip = pcall(tt.GetOwner, tt)
		local sad = okS and sahip and sahip.GetName and sahip:GetName() or ""
		if (saf and G.BuyuAdi and G.BuyuAdi[saf]) or sad:find("Buff") or sad:find("Aura") or sad:find("TempEnchant") then
			ilk = 2
			-- Aura adını burada "Türkçe (English)" yazımıyla çevir (ayara göre); zaten Türkçe/parantezliyse dokunma
			if saf and not G.turkceMi(saf) and not saf:find("(", 1, true) and G.modul("buyu") then
				local tr = (G.buyuAdiCevir and G.buyuAdiCevir(saf)) or (G.BuyuAdi and G.BuyuAdi[saf]) or G.Arayuz[saf]
				if type(tr) == "string" and tr ~= saf then
					local gos = G.adStil("stilBuyu", tr, saf)
					l1:SetText((t1:gsub(saf:gsub("(%W)", "%%%1"), (gos:gsub("%%", "%%%%")), 1)))
					degisti = true
				end
			end
		end
	end
	for i = ilk, tt:NumLines() do
		for _, taraf in ipairs({ "TextLeft", "TextRight" }) do
			local fs = _G[ad .. taraf .. i]
			local t = fs and fs:IsShown() and fs:GetText()
			if G.gizli(t) then t = nil end
			-- Yarı Türkçeleşmiş satır: bilinen İngilizce başlığı değiştir ("First-Time Collection Bonus: +10 Ev Tecrübesi")
			if t and G.turkceMi(t) then
				local g = G.gomuluCevir(t)
				if g and g ~= t then fs:SetText(g); degisti = true; t = g end
			end
			if t and G.KarmaOn and G.turkceMi(t) then
				for en, tr in pairs(G.KarmaOn) do
					local a, b = t:find(en, 1, true)
					if a then fs:SetText(t:sub(1, a - 1) .. tr .. t:sub(b + 1)); degisti = true; break end
				end
			end
			if t and t ~= "" and not G.turkceMi(t) then
				local tr = cevir(t)
				if not tr then
					-- "Character Info (C)" gibi kısayol ekli başlıklar
					local duz = t:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", "")
					local kok, ek = duz:match("^(.-)%s*(%b())$")
					local ktr = kok and cevir(kok)
					if ktr then tr = ktr .. " |cffffd200" .. ek .. "|r" end
				end
				if not tr and birim then
					-- NPC ünvanı: "<Innkeeper>" -> "<Hancı>"
					local u = t:match("^<(.+)>$")
					if u and G.Arayuz[u] then tr = "<" .. G.Arayuz[u] .. ">" end
				end
				if tr then fs:SetText(tr); degisti = true elseif not birim then kaydet(t) end
			end
		end
	end
	if degisti then ipucuSigdir(tt) end
	tt._gtrImza = ipucuImza(tt, ad)
end

-- TAM TARAMA: oyundaki tüm görünür çerçevelerin sabit yazılarını (XML'de baştan yazılmış,
-- sonradan hiç değişmeyen "Display Tips" gibi) bir kez işler. Yeni açılan çerçeveler de yakalanır.
local islenmis = setmetatable({}, { __mode = "k" })
local bolgeOnbellek = setmetatable({}, { __mode = "k" })
local tamSayac = 0
local tamImlec
local function bolgeler(f)
	local c = bolgeOnbellek[f]
	if not c then
		c = {}
		for _, r in ipairs({ f:GetRegions() }) do
			if r.GetObjectType and r:GetObjectType() == "FontString" then c[#c + 1] = r end
		end
		bolgeOnbellek[f] = c
	end
	return c
end
local function tamTaramaAsil()
	if not G.modul("arayuz") or not EnumerateFrames then return end
	if G.RETAIL and InCombatLockdown and InCombatLockdown() then return end
	-- Dilimli tarama: her çağrıda en çok ~1.5 ms çalışır, kaldığı çerçeveden devam eder (saniyede bir toplu takılma olmasın)
	local t0 = debugprofilestop and debugprofilestop()
	local f
	if tamImlec then f = EnumerateFrames(tamImlec) else
		tamSayac = tamSayac + 1
		if tamSayac % 20 == 0 then bolgeOnbellek = setmetatable({}, { __mode = "k" }) end -- ara sıra yenile
		f = EnumerateFrames()
	end
	tamImlec = nil
	local n = 0
	local say = 0
	while f do
		say = say + 1
		if t0 and say % 8 == 0 and debugprofilestop() - t0 > 1.0 then tamImlec = f; return n end
		local karar = islenmis[f]
		local okG, gorunur = false, false
		if karar ~= "atla" then
			local okY, yasak = pcall(f.IsForbidden, f)
			if okY and not yasak then okG, gorunur = pcall(f.IsVisible, f) end
		end
		if karar == "tamam" and okG and gorunur then
			-- Daha önce incelenmiş çerçeve: ata zincirini yeniden dolaşma, yalnızca değişen yazıları işle
			for _, r in ipairs(bolgeler(f)) do
				if r:IsShown() then local tt = r:GetText(); if tt and tt ~= "" and gorulen[r] ~= tt then guvenliIsle(r) end end
			end
			n = n + 1
		elseif karar ~= "atla" and okG and gorunur then
			local ad = f:GetName()
			local atla = ad and ad:find("^NamePlate")
			local u, d = f, 0
			local ayarPenceresi = false
			-- Ayar ve eklenti pencerelerinin (SettingsPanel, Auctionator vb.) içeriği ScrollChild içinde durur: atlama
			do
				local k, e = f, 0
				while k and e < 14 do
					local kn = k.GetName and k:GetName()
					if kn and (kn:find("^SettingsPanel") or kn:find("^InterfaceOptions") or kn:find("^Auctionator") or kn:find("^AuctionHouse") or kn:find("^AuctionFrame") or kn:find("^AddonList") or kn:find("^Professions") or kn:find("^TradeSkill") or kn:find("^CraftFrame")) then ayarPenceresi = true; break end
					k = k.GetParent and k:GetParent(); e = e + 1
				end
			end
			while u and d < 8 and not atla do
				local un = u.GetName and u:GetName()
				if un and (ATLA_AD[un] or un:find("^NamePlate") or (un:find("ScrollChild") and not ayarPenceresi)) then atla = true end
				u = u.GetParent and u:GetParent(); d = d + 1
			end
			if atla then islenmis[f] = "atla" else
				islenmis[f] = "tamam"
				for _, r in ipairs(bolgeler(f)) do
					if r:IsShown() then guvenliIsle(r) end
				end
				n = n + 1
			end
		end
		f = EnumerateFrames(f)
	end
	return n
end
local function tamTarama()
	local t0 = debugprofilestop and debugprofilestop() or 0
	local n = tamTaramaAsil()
	if debugprofilestop then
		local ms = debugprofilestop() - t0
		G.tani.tamMs = ms
		if ms > (G.tani.tamMax or 0) then G.tani.tamMax = ms end
	end
	return n
end

-- Meslek pencereleri: ad kurallarına ve ScrollBox gizlemelerine takılmadan, görünen tüm yazıları (çocuk çerçeveler dahil) tara
local meslekGor = setmetatable({}, { __mode = "k" })
local meslekDokum = {}
-- Tanı: meslek penceresi ilk açıldığında içindeki tüm yazı alanlarının yolunu ve metnini kayda yaz (tani)
local function meslekDokumu(kok)
	local ad = kok:GetName() or "?"
	local simdi = GetTime and GetTime() or 0
	if meslekDokum[ad] and simdi - meslekDokum[ad] < 0.8 then return end
	meslekDokum[ad] = simdi
	local K = G.kayitAc(); K.tani = K.tani or {}
	local say = 0
	local function gez2(f, yol, derin)
		if derin > 10 or say > 120 then return end
		local okR, regs = pcall(function() return { f:GetRegions() } end)
		if okR then
			for _, r in ipairs(regs) do
				if r.GetObjectType and r:GetObjectType() == "FontString" then
					local t = r:GetText()
					-- Büyü kitabı bölüm başlığı: üst çerçeve gizli/görünür fark etmeksizin hepsini çevir (gizli olanlara dokunmak zararsız)
					if type(t) == "string" and G.BuyuSekme and (kok:GetName() == "PlayerSpellsFrame" or kok:GetName() == "SpellBookFrame") then
						local tt = t:gsub("^%s+", ""):gsub("%s+$", "")
						local sek = G.BuyuSekme[tt]
						if sek and tt ~= "Shadow" and sek ~= tt then
							yakalayiciAcik = false
							pcall(r.SetText, r, G.adStil("stilBuyu", sek, tt, "|cffaaaaaa"))
							yakalayiciAcik = true
							t = r:GetText()
						end
						if tt:find("Holy") or tt:find("Discipline") or tt:find("Kutsal") or tt:find("Disiplin") then
							K.tani[("HD|%s|%s|%s|%s"):format((tt:gsub("[^%w]", function(c) return ("%%%02x"):format(c:byte()) end)), tostring(sek), tostring(r:IsShown()), tostring(r:IsVisible()))] = true
						end
					end
					if type(t) == "string" and t:find("%a%a") and r:IsShown() and not G.turkceMi(t) then
						say = say + 1
						pcall(kaydet, t)
						K.tani[("PD|%s|%s|%s|%s"):format(yol, tostring(r:GetName()), tostring(r:IsShown()), (t:sub(1, 80):gsub("|", "||")))] = true
					end
				end
			end
		end
		local okC, kids = pcall(function() return { f:GetChildren() } end)
		if okC then for i, c in ipairs(kids) do gez2(c, yol .. "/" .. (c.GetName and c:GetName() or ("#" .. i)), derin + 1) end end
	end
	pcall(gez2, kok, ad, 0)
end
local sekmeKok
local sekmeTers
local function meslekTara()
	if not G.modul("arayuz") then return end
	if G.RETAIL and InCombatLockdown and InCombatLockdown() then return end
	local function gez(f, derin)
		if derin > 14 or (f.IsForbidden and f:IsForbidden()) or not f:IsShown() then return end
		local ok, regs = pcall(function() return { f:GetRegions() } end)
		if ok then
			for _, r in ipairs(regs) do
				if r.GetObjectType and r:GetObjectType() == "FontString" and r:IsShown() then
					local t = r:GetText()
					if type(t) == "string" and t ~= "" and meslekGor[r] ~= t and not G.gizli(t) and #t < 700 and sekmeKok and (sekmeKok == "PlayerSpellsFrame" or sekmeKok == "SpellBookFrame") and G.BuyuSekme and not t:find("(", 1, true) then
						-- Büyü kitabı bölüm başlığı: "Kutsal (Holy)", "Gölge Büyüsü (Shadow Magic)"
						if not sekmeTers then sekmeTers = {}; for en, tr in pairs(G.BuyuSekme) do if en:find(" ") or #en > 5 or en == "Holy" then sekmeTers[tr] = sekmeTers[tr] or en end end end
						local en, tr
						if G.BuyuSekme[t] and t ~= "Shadow" then en, tr = t, G.BuyuSekme[t] elseif sekmeTers[t] then en, tr = sekmeTers[t], t end
						if en and tr and en ~= tr then
							G.sigdirKoy(r, G.adStil and G.adStil("stilBuyu", tr, en, "|cffaaaaaa") or (tr .. " |cffaaaaaa(" .. en .. ")|r")); meslekGor[r] = t
							t = nil
						end
					end
					if t and type(t) == "string" and t ~= "" and meslekGor[r] ~= t and not G.gizli(t) and #t < 700 then
						local sonuc = G.gomuluCevir(t)
						if (not sonuc or sonuc == t) and not G.turkceMi(t) then sonuc = cevir(t) or sonuc end
						if (not sonuc or sonuc == t) and t:find("\n") then
							-- çok satırlı metin: satır satır çevir
							local parcalar, say = {}, 0
							for satir in (t .. "\n"):gmatch("(.-)\n") do
								local c = satir ~= "" and (G.gomuluCevir(satir) or (not G.turkceMi(satir) and cevir(satir))) or nil
								if c and c ~= satir then say = say + 1; parcalar[#parcalar + 1] = c else parcalar[#parcalar + 1] = satir end
							end
							if say > 0 then sonuc = table.concat(parcalar, "\n") end
						end
						if sonuc and sonuc ~= t then
							G.sigdirKoy(r, sonuc); meslekGor[r] = sonuc
						else
							meslekGor[r] = t
							if not G.turkceMi(t) and t:find("%a%a") then kaydet(t) end
							-- tanı: gerekli/requires satırlarının ham halini kaydet (hata ayıklama için)
							if (t:find("Requires") or t:find("Gerekli")) and #t < 200 then
								local K = G.kayitAc(); K.tani = K.tani or {}
								K.tani[(t:gsub("|", "||"))] = true
							end
						end
					end
				end
			end
		end
		local ok2, kids = pcall(function() return { f:GetChildren() } end)
		if ok2 then for _, c in ipairs(kids) do gez(c, derin + 1) end end
	end
	for _, ad in ipairs({ "ProfessionsFrame", "ProfessionsCustomerOrdersFrame", "ProfessionsBookFrame", "TradeSkillFrame", "CraftFrame", "ClassTrainerFrame", "SpellBookFrame", "TalentFrame", "PlayerTalentFrame", "PlayerSpellsFrame", "MerchantFrame", "FriendsFrame", "CharacterFrame", "ReputationFrame", "SkillFrame", "BankFrame", "AchievementFrame", "CollectionsJournal", "EncounterJournal", "GuildFrame", "LFGParentFrame", "PVEFrame", "ProfessionsRecipeSchematicForm" }) do
		local f = _G[ad]
		if f and f.IsShown and f:IsShown() then sekmeKok = ad; pcall(gez, f, 0); sekmeKok = nil; if ad == "TradeSkillFrame" or ad == "CraftFrame" or ad == "ProfessionsFrame" or ad == "SpellBookFrame" or ad == "PlayerSpellsFrame" then pcall(meslekDokumu, f) end end
	end
	-- Sohbet giriş kutusu ipucu ("Type /2 to ask questions in Newcomer Chat")
	for i = 1, (NUM_CHAT_WINDOWS or 10) do
		local eb = _G["ChatFrame" .. i .. "EditBox"]
		if eb and eb.IsShown and eb:IsShown() then
			pcall(function()
				local liste = { eb:GetRegions() }
				for _, r in ipairs(liste) do
					if r.GetObjectType and r:GetObjectType() == "FontString" and r:IsShown() then
						local t = r:GetText()
						if type(t) == "string" and t ~= "" and not G.turkceMi(t) and #t < 200 and t:find("Newcomer") then
							local sonuc = G.gomuluCevir(t) or cevir(t)
							if sonuc and sonuc ~= t then G.sigdirKoy(r, sonuc) end
						end
					end
				end
			end)
		end
	end
	-- Topluluk pencereleri (Topluluk Ekle/Oluştur, Battle.net Grubu...): yalnızca iletişim kutuları; sohbet mesajlarına dokunma
	if _G.CommunitiesFrame then
		local function kutular(ust, derin)
			if derin > 3 or not ust or not ust.GetChildren then return end
			for _, c in ipairs({ ust:GetChildren() }) do
				local ok, ad = pcall(function() return c.GetName and c:GetName() end)
				local ok2, g = pcall(function() return c:IsShown() end)
				if ok2 and g then
					local okS, strata = pcall(function() return c:GetFrameStrata() end)
					local diyalogKat = okS and (strata == "DIALOG" or strata == "FULLSCREEN_DIALOG")
					if (ok and type(ad) == "string" and (ad:find("Dialog") or ad:find("Add") or ad:find("Create"))) or (diyalogKat and ust ~= UIParent) then pcall(gez, c, 0)
					elseif diyalogKat and ust == UIParent and ok and type(ad) == "string" and ad:find("Communit") then pcall(gez, c, 0)
					else
						for k, v in pairs(c) do
							if type(k) == "string" and k:find("Dialog") and type(v) == "table" and v.IsShown and v:IsShown() then pcall(gez, v, 0) end
						end
					end
				end
			end
		end
		-- Genel yol: Communities çerçevesinin soyundan gelen, DIALOG katmanındaki her görünür çerçeve
		pcall(function()
			if not (_G.CommunitiesFrame.IsShown and _G.CommunitiesFrame:IsShown()) then return end
			local f = EnumerateFrames()
			while f do
				if not (f.IsForbidden and f:IsForbidden()) and f:IsShown() then
					local st = f:GetFrameStrata()
					if st == "DIALOG" or st == "FULLSCREEN_DIALOG" then
						local u, d, bulundu = f, 0, false
						while u and d < 8 do
							local un = u.GetName and u:GetName()
							if un and un:find("Communit") then bulundu = true; break end
							u = u.GetParent and u:GetParent(); d = d + 1
						end
						if bulundu then pcall(gez, f, 0) end
					end
				end
				f = EnumerateFrames(f)
			end
		end)
		-- Başlığa göre bul: "Add Community" vb. yazan görünür çerçevenin kök iletişim kutusunu tara
		pcall(function()
			if not (_G.CommunitiesFrame.IsShown and _G.CommunitiesFrame:IsShown()) then return end
			local BASLIK = { ["Add Community"] = true, ["Topluluk Ekle"] = true, ["Create Community"] = true, ["Join Community"] = true }
			local f = EnumerateFrames()
			while f do
				if not (f.IsForbidden and f:IsForbidden()) and f:IsShown() then
					for _, r in ipairs({ f:GetRegions() }) do
						if r.GetObjectType and r:GetObjectType() == "FontString" then
							local t = r:GetText()
							if t and BASLIK[t] then
								local u, d = f, 0
								while u.GetParent and u:GetParent() and u:GetParent() ~= UIParent and u:GetParent() ~= _G.CommunitiesFrame and d < 6 do u = u:GetParent(); d = d + 1 end
								pcall(gez, u, 0)
								break
							end
						end
					end
				end
				f = EnumerateFrames(f)
			end
		end)
		pcall(kutular, UIParent, 0)
		pcall(kutular, _G.CommunitiesFrame, 0)
		for k, v in pairs(_G.CommunitiesFrame) do
			if type(k) == "string" and k:find("Dialog") and type(v) == "table" and v.IsShown and v:IsShown() then pcall(gez, v, 0) end
		end
	end
end

local zamanlayici
-- Eklenti pencerelerinin üst çerçevelerini bulmak için genel tabloyu (_G) parça parça dolaş:
-- tek seferde dolaşmak 100+ ms takılma yapıyordu. Her çağrıda en fazla ~1,5 ms çalışır, bitince 60 sn bekler.
local gKursor, gYeni, gBitti = nil, nil, 0
local function ekKokAdim()
	local simdi = GetTime and GetTime() or 0
	if not gYeni then
		if simdi - gBitti < 60 and ekKokZaman > 0 then return end
		gYeni, gKursor = {}, nil
	end
	local t0 = debugprofilestop and debugprofilestop() or 0
	local say = 0
	while true do
		local okN, ad, f = pcall(next, _G, gKursor)
		if not okN then gYeni, gKursor = nil, nil; return end -- tablo değişti: baştan
		gKursor = ad
		if ad == nil then
			ekKokler = gYeni; gYeni = nil; gBitti = simdi; ekKokZaman = simdi
			return
		end
		if type(ad) == "string" and type(f) == "table" and rawget(f, 0) ~= nil then
			for _, on in ipairs(EK_ONEKLER) do
				if ad:find(on) then
					local ok, u = pcall(f.GetParent, f)
					-- Yalnızca en üstteki çerçeveler (alt çerçeveler zaten onların içinde taranır)
					if ok and (u == nil or u == UIParent or (u.GetName and not (u:GetName() or ""):find(on))) then gYeni[#gYeni + 1] = f end
					break
				end
			end
		end
		say = say + 1
		if say % 200 == 0 and debugprofilestop and debugprofilestop() - t0 > 1.5 then return end
	end
end
local kokSira = 0
local function hepsiniTara()
	if not G.modul("arayuz") then return end
	local t0 = debugprofilestop and debugprofilestop() or 0
	local function sureDoldu() return debugprofilestop and (debugprofilestop() - t0) > 4 end
	local acikVar = false
	for _, ad in ipairs(KOKLER) do
		local f = _G[ad]
		if type(f) == "table" and gorunurMu(f) then
			acikVar = true
			local ok, e = pcall(tara, f, 0)
			if not ok then G.tani.hata = tostring(e) end
		end
	end
	if not (InCombatLockdown and InCombatLockdown()) then pcall(ekKokAdim) end
	-- Açık eklenti pencereleri: süre dolarsa kalanını bir sonraki çağrıya bırak (sırayla)
	local n = #ekKokler
	if n > 0 then
		for k = 1, n do
			if sureDoldu() then break end
			kokSira = kokSira % n + 1
			local f = ekKokler[kokSira]
			if f and gorunurMu(f) then
				local ok, e = pcall(tara, f, 0)
				if not ok then G.tani.hata = tostring(e) end
			end
		end
	end
	-- Yeni menü sistemi: adı olmayan açılır menüler (portre sağ tık, ganimet ayarları vb.)
	pcall(function()
		for _, c in ipairs({ UIParent:GetChildren() }) do
			if not (c.IsForbidden and c:IsForbidden()) and c:IsShown() and not c:GetName() then
				local strata = c:GetFrameStrata()
				if strata == "FULLSCREEN_DIALOG" or strata == "FULLSCREEN" or strata == "DIALOG" or strata == "TOOLTIP" then
					local ok, e = pcall(tara, c, 0)
					if not ok then G.tani.hata = tostring(e) end
				end
			end
		end
	end)
end

local function baslat()
	if not G.modul("arayuz") then return end
	C_Timer.After(0, hepsiniTara)
	if not zamanlayici then zamanlayici = G.olcTicker(1.0, hepsiniTara) end
	if not G.meslekZaman then G.meslekZaman = G.olcTicker(1.0, function() pcall(meslekTara) end) end
end
G.arayuzTara = baslat

-- GENEL YAKALAYICI: oyundaki her yazı alanına (FontString) yazı konduğu anda bakar.
-- Sözlükte varsa Türkçesini koyar, yoksa (anlamlıysa) kaydeder. Menüler, büyü kitabı,
-- sonradan açılan pencereler dahil her şeyi yakalar.
local hizli = {}      -- ham yazı -> çeviri ya da false (sayısız yazılar için)
local hizliSayi = 0
local uzunIsleniyor = {}
-- Önbellek dolunca durmak yerine sıfırlanır (eskiden 20000'de duruyordu; sohbet satırları doldurunca her şey yavaşlıyordu)
local function hizliKoy(t, v)
	if hizliSayi >= 20000 then wipe(hizli); hizliSayi = 0 end
	if hizli[t] == nil then hizliSayi = hizliSayi + 1 end
	hizli[t] = v
end
local sablonYok = {}  -- sayılı yazıların şablonu -> çevirisi yok
local yakalayiciAcik = true
-- "Yaratık adları" ayarı değişince önbelleği boşalt; görev penceresi yeniden çizilsin
G.dinleyiciler[#G.dinleyiciler + 1] = function(k)
	if k ~= "yaratik" and k ~= "arayuz" and k ~= "npc" then return end
	wipe(hizli); wipe(sablonYok); hizliSayi = 0
	pcall(function()
		if QuestLog_UpdateQuestDetails and QuestLogFrame and QuestLogFrame:IsShown() then QuestLog_UpdateQuestDetails() end
		if QuestWatch_Update then QuestWatch_Update() end
	end)
end
local function gorevMetniMi(fs)
	-- Meslek pencereleri (tarif listesi ScrollChild içinde olsa da görev metni değildir): yakalansın
	do
		local p, k = fs, 0
		while p and k < 12 do
			local pn = p.GetName and p:GetName()
			if pn and (pn:find("^Professions") or pn:find("^TradeSkill") or pn:find("^CraftFrame") or pn:find("^Craft")) then return false end
			p = p.GetParent and p:GetParent(); k = k + 1
		end
	end
	local u, d = fs, 0
	while u and d < 10 do
		local ad = u.GetName and u:GetName()
		if ad and (ATLA_AD[ad] or ad:find("^Quest") or ad:find("^Gossip") or ad:find("ScrollChild") or ad:find("^ChatFrame") or ad:find("^NamePlate")) then return true end
		u = u.GetParent and u:GetParent(); d = d + 1
	end
end
-- İpucu (tooltip) içindeki yazı değişince kutuyu yeni yazıya göre yeniden boyutlandır
local bekleyenIpucu = {}
local function ipucuBul(fs)
	local u = fs.GetParent and fs:GetParent()
	for _ = 1, 2 do
		if not u then return end
		if u.GetObjectType and u:GetObjectType() == "GameTooltip" then return u end
		u = u.GetParent and u:GetParent()
	end
end
local function koyYaz(fs, tr)
	do local g = G.gomuluCevir(tr); if g then tr = g end end -- çeviri içinde kalan İngilizce adlar
	if G.birimDuzelt then tr = G.birimDuzelt(tr) end
	local tt = ipucuBul(fs)
	if not tt then return G.sigdirKoy(fs, tr) end
	fs:SetText(tr) -- ipucunda küçültme yok: kutu büyüsün
	if not bekleyenIpucu[tt] then
		bekleyenIpucu[tt] = true
		C_Timer.After(0, function()
			bekleyenIpucu[tt] = nil
			if tt:IsShown() then pcall(ipucuSigdir, tt) end
		end)
	end
end
-- Kod metnindeki "--" yorum satırlarını çevir (renk kodlu satırlar dahil); kod satırları aynen kalır
function G.kodYorumCevir(t)
	if type(t) ~= "string" or not t:find("%-%-") then return nil end
	local KY = G.KodYorum or {}
	local parca, degisti = {}, false
	for satir in (t .. "\n"):gmatch("(.-)\n") do
		local on, govde, son = satir:match("^(%s*|c%x%x%x%x%x%x%x%x)(%-%-.-)(|r%s*)$")
		if not on then on, govde, son = satir:match("^(%s*)(%-%-.-)(%s*)$") end
		if govde then
			local y = KY[govde]
			if not y then y = govde:gsub("%f[%a]default%f[%A]", "varsayılan") end
			if y ~= govde then satir = on .. y .. son; degisti = true end
		end
		parca[#parca + 1] = satir
	end
	return degisti and table.concat(parca, "\n") or nil
end
-- Atlas eklentisindeki zindan adları İngilizce kalır (AtlasMaps[...].ZoneName)
local atlasAdlar, atlasSay = nil, -100
local function atlasZindanMi(fs, t)
	local maps = rawget(_G, "AtlasMaps")
	if type(maps) ~= "table" then return false end
	local acik = false
	for _, f in ipairs({ "AtlasFrame", "AtlasFrameLarge", "AtlasFrameSmall" }) do
		local fr = rawget(_G, f)
		if fr and fr.IsShown and fr:IsShown() then acik = true; break end
	end
	if not acik then return false end
	local simdi = GetTime and GetTime() or 0
	if not atlasAdlar or simdi - atlasSay > 30 then
		atlasAdlar, atlasSay = {}, simdi
		for _, m in pairs(maps) do
			local z = type(m) == "table" and type(m.ZoneName) == "table" and m.ZoneName[1]
			if type(z) == "string" and z ~= "" then
				atlasAdlar[z] = true
				atlasAdlar[(z:gsub("%s*%[.-%]%s*$", ""))] = true
				local on = z:match("^(.-):") if on then atlasAdlar[on] = true end
			end
		end
	end
	local sade = t:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", ""):gsub("^%s+", ""):gsub("%s+$", "")
	local temel = sade:gsub("%s*%(%d+%s*%-%s*%d+%)$", ""):gsub("%s*%[.-%]%s*$", "")
	if not (atlasAdlar[sade] or atlasAdlar[temel]) then return false end
	-- Atlas pencereleri ya da Atlas açıkken açılır menüler
	local u, d = fs, 0
	while u and d < 10 do
		local ad = u.GetName and u:GetName()
		if ad and ad:find("^Atlas") and not ad:find("^AtlasLoot") then return true end
		if ad and ad:find("DropDownList") then
			for _, f in ipairs({ "AtlasFrame", "AtlasFrameLarge", "AtlasFrameSmall" }) do
				local fr = rawget(_G, f)
				if fr and fr.IsShown and fr:IsShown() then return true end
			end
			return false
		end
		u = u.GetParent and u:GetParent(); d = d + 1
	end
	return false
end
-- "12.5s Fishing" / "Fishing" -> "12.5 sn Balıkçılık" / "Balıkçılık" (büyü çubukları; yalnızca Türkçe ad)
function G.buyuSureYazi(t)
	if type(t) ~= "string" or t == "" or G.gizli(t) then return nil end
	local sure, bad = t:match("^%s*(%-?%d+%.%d)s (.-)%s*$")
	if not sure then return nil end
	if not bad:find("%a%a") or G.turkceMi(bad) then return nil end
	local kok, rutbe = bad:match("^(.-)(%s*%(.-%))$")
	if not kok then kok, rutbe = bad:match("^(.-)(%s+%d+)$") end
	if not kok then kok, rutbe = bad, "" end
	local tr = (G.BuyuAdi and G.BuyuAdi[kok]) or (G.buyuAdiCevir and G.buyuAdiCevir(kok)) or (G.EsyaAdi and G.EsyaAdi[kok]) or G.Arayuz[kok]
	if type(tr) ~= "string" or tr == "" then return nil end
	tr = G.renksiz and G.renksiz(tr) or tr
	tr = tr:gsub("%s*%(.-%)%s*$", "")
	return sure .. " sn " .. tr .. (rutbe:gsub("Rank", "Rütbe"))
end
local function yakala(fs)
	if not yakalayiciAcik then return end
	if korunakli(fs) or esyaIpucuIcinde(fs) then return end
	local t = fs:GetText()
	if G.gizli(t) or type(t) ~= "string" then return end
	-- Kod düzenleyicileri (Details Auto Run Code...): yalnızca "--" yorum satırlarını çevir, koda dokunma
	if t ~= "" and #t < 20000 and (t:find("^%s*%-%-") or t:find("\n%s*%-%-") or t:find("^%s*|c%x%x%x%x%x%x%x%x%-%-")) then
		local y = G.kodYorumCevir(t)
		if y and y ~= t then yakalayiciAcik = false; pcall(fs.SetText, fs, y); yakalayiciAcik = true end
		return
	end
	if not t or t == "" or #t > 700 then return end
	-- Gereksinim satırları (eğitmen): her zaman aynı tam Türkçe biçim ("Gerektirir: Seviye 16, Zihin Patlaması (Rütbe 1)")
	do
		local g = G.gereksinimSatiri and G.gereksinimSatiri(t)
		if g and g ~= t then yakalayiciAcik = false; pcall(koyYaz, fs, g); yakalayiciAcik = true; return end
		if (t:find("^%s*Gerektirir:") or t:find("^|c%x%x%x%x%x%x%x%xGerektirir:")) then return end
	end
	if t:find("|cffaaaaaa(", 1, true) or t:find("|cff888888(", 1, true) then return end
	if G.oyuncuMu(t) then return end
	do local ok, z = pcall(atlasZindanMi, fs, t); if ok and z then return end end
	-- Yer adları (zindan, bölge, alt bölge) İngilizce kalır
	if G.YerAdi[t] or G.YerAdi[(t:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", ""))] then return end
	if G.trDegerMi(t) then return end
	-- "Görev adı (low level)": düşük seviyeli görev eki her yerde Türkçe
	if t:find("(low level)", 1, true) or t:find("(Low Level)", 1, true) then
		local on = t:gsub("%s*%([Ll]ow [Ll]evel%)", "")
		local tr = G.turkceMi(on) and on or (sonCevir(on) or (G.GorevAdi and G.GorevAdi[(renksiz(on):gsub("^%s+", ""))]) or on)
		yakalayiciAcik = false; pcall(fs.SetText, fs, tr .. " (düşük seviye)"); yakalayiciAcik = true
		return
	end
	-- Büyü çubuğu süre yazısı (IceHUD vb.): "12.5s Fishing" -> "12.5 sn Balıkçılık" (yalnızca Türkçe ad)
	do
		local y = G.buyuSureYazi(t)
		if y then yakalayiciAcik = false; pcall(fs.SetText, fs, y); yakalayiciAcik = true; return end
	end
	if t:find("Details[%.:]%a") or t:find("^%s*local %a") then return end
	-- Büyü kitabı bölüm başlığı (Holy, Discipline, Shadow Magic...): "Kutsal (Holy)" biçiminde göster
	if G.BuyuSekme and G.BuyuSekme[t] and G.BuyuSekme[t] ~= t and t ~= "Shadow" then
		local u, d = fs, 0
		while u and d < 12 do
			local un = u.GetName and u:GetName()
			if un and (un:find("^PlayerSpellsFrame") or un:find("^SpellBookFrame")) then
				yakalayiciAcik = false
				pcall(koyYaz, fs, G.adStil("stilBuyu", G.BuyuSekme[t], t, "|cffaaaaaa"))
				yakalayiciAcik = true
				return
			end
			u = u.GetParent and u:GetParent(); d = d + 1
		end
	end
	if popupOnay(fs, t) then yakalayiciAcik = false; pcall(koyYaz, fs, "Onayla"); yakalayiciAcik = true; return end
	-- Ad listeleri (arkadaş, lonca, kim, raid/grup çerçeveleri): ad ve lonca alanlarına hiç dokunma
	do
		local ad = fs.GetName and fs:GetName()
		if ad and (ad:find("Name$") or ad:find("Guild$") or ad:find("NameText$")) and
			(ad:find("^GuildFrame") or ad:find("^WhoFrame") or ad:find("^FriendsFrame") or ad:find("^Raid") or ad:find("^Party")
			or ad:find("^Compact") or ad:find("^Target") or ad:find("^Focus") or ad:find("^Player") or ad:find("^Ignore")) then return end
		local ust = fs.GetParent and fs:GetParent()
		-- Yazı kutusuna iliştirilmiş etiketler ("To:", "Subject:" — posta): kutunun yazısı değil, ":" ile biten bilinen etiket
		if ust and ust.GetObjectType and ust:GetObjectType() == "EditBox" and t:find(":%s*$") and #t < 40 then
			local un0 = ust.GetName and ust:GetName() or ""
			local okU, ut0 = pcall(ust.GetText, ust)
			local tr0 = G.Arayuz[t] or G.Arayuz[(t:gsub("%s+$", ""))]
			if type(tr0) == "string" and okU and ut0 ~= t and not un0:find("^ChatFrame") then
				yakalayiciAcik = false; pcall(fs.SetText, fs, tr0); yakalayiciAcik = true
				return
			end
		end
		-- Sohbet yazma kutusu ("Say:", "/say", kanal başlıkları): genişliği İngilizceye göre hesaplanıyor,
		-- çevirince yazılar iç içe geçiyor. Yazı kutularının içindeki hiçbir yazıya dokunma.
		if ad and ad:find("EditBox") then return end
		if ust and ust.GetObjectType and ust:GetObjectType() == "EditBox" then
			local ok, ut = pcall(ust.GetText, ust)
			if not ok or (type(ut) == "string" and ut ~= "" and ut == t) then return end
		end
		local uname = ust and ust.GetName and ust:GetName()
		if uname and uname:find("EditBox") then return end
		if ust and (rawget(ust, "name") == fs or rawget(ust, "Name") == fs) then
			local un = ust.GetName and ust:GetName() or ""
			local uu = ust.GetParent and ust:GetParent()
			local uun = uu and uu.GetName and uu:GetName() or ""
			-- Yeni stil listeler (ScrollBox içindeki arkadaş ve lonca satırları)
			if un:find("Friend") or un:find("Guild") or un:find("Who") or uun:find("Friend") or uun:find("Guild") or uun:find("Who")
				or rawget(ust, "gameAccountInfo") or rawget(ust, "buttonType") then return end
		end
	end
	-- Birim çerçeveleri ve isim plakaları: çerçevenin birimi oyuncuysa adına dokunma
	do
		local u, d = fs, 0
		while u and d < 6 do
			local birim = rawget(u, "unit") or rawget(u, "displayedUnit")
			if type(birim) == "string" then
				local ok, op = pcall(UnitIsPlayer, birim)
				if ok and op then
					G.oyuncuEkle(birim)
					-- Yalnızca ad/lonca yazısına dokunma; "Away", "Dead", "Ghost" gibi durum yazıları çevrilsin
					if G.oyuncuMu(t) then return end
					local okn, nm = pcall(UnitName, birim)
					if okn and type(nm) == "string" and not G.gizli(nm) and nm ~= "" and t:find(nm, 1, true) then return end
					if t:find("%s") == nil and t:find("^%u%l+$") and not (G.Arayuz[t] or G.DurumTr[t]) then return end
				end
				break
			end
			u = u.GetParent and u:GetParent(); d = d + 1
		end
	end
	-- Görev adları: görev takipçisi (Retail ObjectiveTracker), harita görev günlüğü, dünya görevleri
	local gOn, gAd = t:match("^(%[[%d%+%?]+%]%s*)(.+)$")
	if not (gAd and G.GorevAdi[gAd]) then gOn, gAd = "", t end
	if G.modul("gorev") and G.GorevAdi[gAd] and not G.turkceMi(gAd) then
		local u, d = fs, 0
		while u and d < 12 do
			local ad = u.GetName and u:GetName()
			if ad and (ad:find("ObjectiveTracker") or ad:find("QuestScrollFrame") or ad:find("QuestMapFrame") or ad:find("QuestLog") or ad:find("WorldMap") or ad:find("Questie")) then
				yakalayiciAcik = false; pcall(koyYaz, fs, gOn .. G.GorevAdi[gAd]); yakalayiciAcik = true
				return
			end
			u = u.GetParent and u:GetParent(); d = d + 1
		end
	end
	-- Genel görev hedefleri: "Defeat Mephistroth" -> "Yen: Mephistroth" (görev çerçeveleri içinde)
	if G.RETAIL and G.modul("gorev") and not G.turkceMi(t) then
		local fiil, nesne = t:match("^%s*%-?%s*(%a+) (.+)$")
		local FIIL = { Defeat = "Yen", Kill = "Öldür", Slay = "Öldür", Find = "Bul", Collect = "Topla", Locate = "Bul", Rescue = "Kurtar", Protect = "Koru", Escort = "Refakat et", Destroy = "Yok et", Retrieve = "Geri al", Investigate = "Araştır", Survive = "Hayatta kal" }
		local ftr = fiil and nesne and nesne:find("^%u") and FIIL[fiil]
		if ftr then
			local u, d = fs, 0
			while u and d < 12 do
				local ad = u.GetName and u:GetName()
				if ad and (ad:find("ObjectiveTracker") or ad:find("QuestScrollFrame") or ad:find("QuestMapFrame") or ad:find("QuestLog") or ad:find("WorldMap")) then
					local on = t:match("^(%s*%-?%s*)") or ""
					local ntr = (G.modul("yaratik") and G.Yaratik[nesne]) or G.Arayuz[nesne] or nesne
					yakalayiciAcik = false; pcall(koyYaz, fs, on .. ftr .. ": " .. ntr); yakalayiciAcik = true
					return
				end
				u = u.GetParent and u:GetParent(); d = d + 1
			end
		end
	end
	-- Virgülle ayrılmış eşya türü satırları ("Wrist, Cloth", "Main Hand, One-Hand, Sword", AtlasLoot vb.)
	if t:find(", ", 1, true) and #t < 80 and t:find("^[%a%-' ]+, [%a%-', ]+$") then
		local YUVA = { Back = "Sırt", Mail = "Zincir", Plate = "Plaka", Axe = "Balta", Mace = "Topuz", ["Off Hand"] = "Yan El" }
		local parca, hepsi = {}, true
		for p in (t .. ", "):gmatch("(.-), ") do
			local tr = YUVA[p] or G.Arayuz[p]
			if type(tr) ~= "string" then hepsi = false; break end
			parca[#parca + 1] = tr
		end
		if hepsi and #parca > 1 then yakalayiciAcik = false; pcall(koyYaz, fs, table.concat(parca, ", ")); yakalayiciAcik = true; return end
	end
	-- AtlasLoot eşya satırında tek başına yuva adı: "Back" -> "Sırt" (düğmelerdeki "Back" = "Geri" kalır)
	if t == "Back" or t == "Mail" then
		local u, d = fs, 0
		while u and d < 8 do
			local ad = u.GetName and u:GetName()
			if ad and ad:find("^AtlasLoot") then yakalayiciAcik = false; pcall(koyYaz, fs, t == "Back" and "Sırt" or "Zincir"); yakalayiciAcik = true; return end
			u = u.GetParent and u:GetParent(); d = d + 1
		end
	end
	-- Retail meslek penceresi (ProfessionsFrame): tarif, malzeme ve kategori adları
	local pf = rawget(_G, "ProfessionsFrame")
	if pf and pf:IsShown() and not G.turkceMi(t) and (G.modul("buyuadi") or G.modul("arayuz")) then
		local u, d = fs, 0
		while u and d < 12 do
			local ad = u.GetName and u:GetName()
			if ad and (ad:find("^ProfessionsFrame") or ad:find("^ProfessionsCustomerOrders")) then
				local bas, isim, son = t:match("^(%s*)(.-)(%s*%(%d+%))$")
				if not isim then bas, isim, son = "", t, "" end
				local tr = G.isimCevir(isim) or (G.esyaAdiGoster and G.esyaAdiGoster(isim))
				if tr and tr ~= isim then yakalayiciAcik = false; pcall(koyYaz, fs, bas .. tr .. son); yakalayiciAcik = true; return end
				break
			end
			u = u.GetParent and u:GetParent(); d = d + 1
		end
	end
	local onbellek = hizli[t]
	if onbellek == false then return end
	-- Uzun yazılar ilk kez görüldüğünde çeviri arka planda (karelere bölünerek) yapılır, sonra uygulanır
	if onbellek == nil and #t > 250 and not uzunIsleniyor[t] then
		uzunIsleniyor[t] = true
		local hedef = fs
		G.arkaPlan(function()
			local ok, tr = pcall(function()
				if G.turkceMi(t) then return karisikCevir(t) or G.gomuluCevir(t) end
				return sonCevir(t) or karisikCevir(t) or G.gomuluCevir(t)
			end)
			tr = ok and tr or nil
			hizliKoy(t, tr or false)
			uzunIsleniyor[t] = nil
			if tr and tr ~= t and hedef:GetText() == t then
				yakalayiciAcik = false; pcall(koyYaz, hedef, tr); yakalayiciAcik = true
			end
		end)
		return
	end
	if onbellek then
		yakalayiciAcik = false; pcall(koyYaz, fs, onbellek); yakalayiciAcik = true
		return
	end
	if not t:find("%a%a") then return end
	if G.turkceMi(t) then
		local g = karisikCevir(t) or G.gomuluCevir(t)
		if g and g ~= t then hizliKoy(t, g); yakalayiciAcik = false; pcall(koyYaz, fs, g); yakalayiciAcik = true
		else
			hizliKoy(t, false)
			if G.ingilizceBaskin(t) and not gorevMetniMi(fs) then kaydet(t) end
		end
		return
	end
	local sayili = t:find("%d")
	if sayili then
		local sab = t:gsub("%d+", "#")
		if sablonYok[sab] then return end
		local tr = sonCevir(t)
		if not tr then
			-- Yazıyı sürekli yeniden yazan eklentilerde (ATT, TSM...) İngilizce ile Türkçe arasında titremesin:
			-- kısmi (gömülü ad) çeviriyi de burada, yazı konduğu anda uygula
			local g = karisikCevir(t) or G.gomuluCevir(t)
			if g and g ~= t then tr = g end
		end
		if tr and G.ingilizceBaskin(tr) and not gorevMetniMi(fs) then kaydet(t) end -- yarım çeviri: özgün satırı da kaydet
		if tr then
			hizliKoy(t, tr)
			yakalayiciAcik = false; pcall(koyYaz, fs, tr); yakalayiciAcik = true
		else
			sablonYok[sab] = true
			if not gorevMetniMi(fs) then kaydet(t) end
		end
		return
	end
	local tr = sonCevir(t)
	if not tr then tr = karisikCevir(t) or G.gomuluCevir(t) end
	hizliKoy(t, tr or false)
	if tr and G.ingilizceBaskin(tr) and not gorevMetniMi(fs) then kaydet(t) end -- yarım çeviri: özgün satırı da kaydet
	if tr then
		yakalayiciAcik = false; pcall(koyYaz, fs, tr); yakalayiciAcik = true
	elseif not gorevMetniMi(fs) then
		kaydet(t)
	end
end
-- Mesafeyi metreye çevir (TomTom, harita ipuçları): "202 yarda" -> "185 metre", "202 yds" -> "185 m"
local function metreYaz(yd, kisa)
	local m = yd * 0.9144
	if m >= 1000 then return (string.format("%.1f km", m / 1000):gsub("%.", ",")) end
	return math.floor(m + 0.5) .. (kisa and " m" or " metre")
end
function G.metreyeCevir(s)
	if type(s) ~= "string" or not (s:find("yard", 1, true) or s:find("yd", 1, true) or s:find("mil", 1, true)) then return s end
	local y = s
	y = y:gsub("(%d+) mil (%d+) yarda", function(a, b) return metreYaz(tonumber(a) * 1760 + tonumber(b)) end)
	y = y:gsub("(%d+) miles? (%d+) yards?", function(a, b) return metreYaz(tonumber(a) * 1760 + tonumber(b)) end)
	y = y:gsub("(%d+[%.,]?%d*)K yds?", function(a) return metreYaz(tonumber((a:gsub(",", "."))) * 1000, true) end)
	y = y:gsub("(%d+) yarda", function(a) return metreYaz(tonumber(a)) end)
	y = y:gsub("(%d+) yards?", function(a) return metreYaz(tonumber(a)) end)
	y = y:gsub("(%d+) yds?%f[%A]", function(a) return metreYaz(tonumber(a), true) end)
	return y
end
local function yakalayiciKur()
	local ornek = UIParent:CreateFontString()
	local mt = getmetatable(ornek)
	local yontem = mt and mt.__index
	if type(yontem) ~= "table" then return end
	G.tani.yakalayici = true
	-- Aynı yazı alanına aynı İngilizce metin tekrar tekrar yazılıyorsa (HealBot, Details, çerçeve güncellemeleri)
	-- ve daha önce çevrilecek bir şey bulunmadıysa tekrar işleme: oyunun en sıcak yolu burası.
	local degismez = setmetatable({}, { __mode = "k" })
	G.degismezSifirla = function() degismez = setmetatable({}, { __mode = "k" }) end
	local perf = debugprofilestop
	-- Kare bütçesi: bu karede eklentinin işi 4 ms'yi geçtiyse kalan yazılar sonraki karelere bırakılır.
	-- Böylece ne olursa olsun tek bir karede oyuna 6-8 ms'den fazla yük bindirmeyiz.
	local bekleyen, bekleyenSay, isleniyorBekleyen = {}, 0, false
	local kancaAsil
	local function haritada(fs)
		local wm = WorldMapFrame
		if not wm or not wm:IsShown() then return false end
		if wm.IsMouseOver and wm:IsMouseOver() then return true end -- fare haritadayken açılan etiketler (haritaya bağlı olmasalar da)
		local p, k = fs:GetParent(), 0
		while p and k < 10 do if p == wm then return true end; p = p:GetParent(); k = k + 1 end
		return false
	end
	-- Eşya ipucu satırları Ipucu modülünün işi: buradan da işlemek her yenilemede satır başına
	-- onlarca arama + çöp üretiyordu (ipucu üstünde dururken takılmanın ana sebebi)
	local ttSatir = setmetatable({}, { __mode = "k" })
	local function esyaVarMi(p) local _, l = p:GetItem(); return l ~= nil end
	local function esyaIpucuSatiri(fs)
		local p = ttSatir[fs]
		if p == nil then
			p = false
			local ad = fs.GetName and fs:GetName()
			if ad and ad:find("Text[LR][ei][fg]h?t?%d+$") then
				local par = fs:GetParent()
				if par and par.GetItem then p = par end
			end
			ttSatir[fs] = p
		end
		if not p then return false end
		return G.esyaIpucuMu(p)
	end
	local function kanca(fs)
		if esyaIpucuSatiri(fs) or esyaIpucuIcinde(fs) then return end
		-- Bütçe dolu olsa da: önbellekte çevirisi hazır olan yazılar ve harita yazıları hemen çevrilir
		-- (harita açılınca önce İngilizce, sonra Türkçe görünmesin)
		if not isleniyorBekleyen and G.kareIs > 4 then
			local t = fs.GetText and fs:GetText()
			if t ~= nil and G.gizli(t) then return end -- gizli (secret) yazılar okunamaz; dokunma
			if type(t) == "string" and (hizli[t] or haritada(fs)) then return kancaAsil(fs) end
			if not bekleyen[fs] and bekleyenSay < 5000 then bekleyen[fs] = true; bekleyenSay = bekleyenSay + 1 end
			return
		end
		return kancaAsil(fs)
	end
	do
		local bf = CreateFrame("Frame")
		bf:SetScript("OnUpdate", function()
			if bekleyenSay == 0 or not debugprofilestop then return end
			local t0 = debugprofilestop()
			isleniyorBekleyen = true
			for fs in pairs(bekleyen) do
				bekleyen[fs] = nil; bekleyenSay = bekleyenSay - 1
				pcall(kancaAsil, fs)
				if debugprofilestop() - t0 > 4 then break end
			end
			isleniyorBekleyen = false
			G.kareIs = G.kareIs + (debugprofilestop() - t0)
		end)
	end
	kancaAsil = function(fs)
		local tn = G.tani
		tn.kanca = (tn.kanca or 0) + 1
		if not G.modul("arayuz") then return end
		if G.RETAIL and InCombatLockdown and InCombatLockdown() then return end
		if vuhdoGizli(fs) then return end
		local t0 = perf and perf() or 0
		local metin = fs:GetText()
		if type(metin) == "string" and not G.gizli(metin) then
			-- Harf içermeyen yazılar (sayılar, süreler, yüzdeler) hiçbir zaman çevrilmez
			if not metin:find("%a%a") then return end
			-- Oyuncu sohbet satırları: sohbet modülü zaten çevirir; burada her satırı yeniden işlemek takılma yapıyordu
			if metin:find("|Hplayer:", 1, true) or metin:find("|HBNplayer:", 1, true) or metin:find("|Hchannel:", 1, true) or #metin > 3000 then return end
			if degismez[fs] == metin then tn.atlanan = (tn.atlanan or 0) + 1; return end
		else
			metin = nil
		end
		local ok, e = pcall(yakala, fs)
		if not ok then G.tani.hata = tostring(e); yakalayiciAcik = true end
		if metin then
			local son = fs:GetText()
			if type(son) == "string" and not G.gizli(son) and son == metin then degismez[fs] = metin else degismez[fs] = nil end
		end
		if perf then tn.kMs = (tn.kMs or 0) + (perf() - t0) end
	end
	kanca = G.olcSar("FontString SetText kancası", kanca)
	hooksecurefunc(yontem, "SetText", kanca)
	-- Yeni menüler ve ayarlar paneli yazıyı SetTextToFit ile koyuyor
	for _, ad in ipairs({ "SetFormattedText", "SetTextToFit" }) do
		if yontem[ad] then hooksecurefunc(yontem, ad, kanca) end
	end
	-- Düğme yazıları (Button:SetText) FontString:SetText'ten geçmiyor; bu yüzden listelerde
	-- (müzayede kategorileri vb.) önce İngilizce görünüp sonra değişiyordu. Aynı karede çevir.
	-- CheckButton (menülerdeki işaretli/radyo satırları: Bagnon konum ve karakter menüsü) ayrı metatablo kullanır
	local dugmeKancali = {}
	for _, tur in ipairs({ "Button", "CheckButton" }) do
	local okd, dugme = pcall(CreateFrame, tur)
	local dmt = okd and getmetatable(dugme)
	local dyontem = dmt and dmt.__index
	if type(dyontem) == "table" and dyontem.SetText and not dugmeKancali[dyontem] then
		dugmeKancali[dyontem] = true
		local function dugmeKanca(b)
			if not G.modul("arayuz") then return end
			if G.RETAIL and InCombatLockdown and InCombatLockdown() then return end
			local fs = b.GetFontString and b:GetFontString()
			if fs then local ok, e = pcall(yakala, fs); if not ok then G.tani.hata = tostring(e); yakalayiciAcik = true end end
		end
		dugmeKanca = G.olcSar("Düğme SetText kancası (" .. tur .. ")", dugmeKanca)
		hooksecurefunc(dyontem, "SetText", dugmeKanca)
		if dyontem.SetFormattedText then hooksecurefunc(dyontem, "SetFormattedText", dugmeKanca) end
	end
	end
	-- Çok satırlı kod kutuları (Details Otomatik Kod vb.): yorum satırlarını çevir
	local eb = CreateFrame("EditBox"); eb:Hide()
	local emt = getmetatable(eb)
	local eyontem = emt and emt.__index
	if type(eyontem) == "table" and eyontem.SetText then
		local yaziyor = false
		hooksecurefunc(eyontem, "SetText", function(kutu, metin)
			if yaziyor or not G.modul("arayuz") or type(metin) ~= "string" or G.gizli(metin) then return end
			if not (kutu.IsMultiLine and kutu:IsMultiLine()) then return end
			if not (metin:find("^%s*%-%-") or metin:find("\n%s*%-%-") or metin:find("|c%x%x%x%x%x%x%x%x%-%-")) then return end
			local ok, y = pcall(G.kodYorumCevir, metin)
			if ok and y and y ~= metin then yaziyor = true; pcall(kutu.SetText, kutu, y); yaziyor = false end
		end)
	end
end
G.dinle(function(k) if k == "arayuz" or k == "acik" then wipe(hizli); hizliSayi = 0; wipe(sablonYok); if G.degismezSifirla then G.degismezSifirla() end end end)

G.basla(function()
	pcall(yakalayiciKur)
	for _, ad in ipairs(KOKLER) do
		local f = _G[ad]
		if type(f) == "table" and f.HookScript then pcall(f.HookScript, f, "OnShow", baslat) end
	end
	-- Bazı pencereler (TalentFrame vb.) sonradan yüklenir
	local f = CreateFrame("Frame")
	f:RegisterEvent("ADDON_LOADED")
	f:SetScript("OnEvent", function()
		for _, ad in ipairs(KOKLER) do
			local fr = _G[ad]
			if type(fr) == "table" and fr.HookScript and not fr._gtrKanca then fr._gtrKanca = true; pcall(fr.HookScript, fr, "OnShow", baslat) end
		end
	end)
	for _, ad in ipairs(KOKLER) do local fr = _G[ad]; if type(fr) == "table" then fr._gtrKanca = true end end
	-- Yetenek penceresi: sekme adları pencere açıldıktan sonra ve sekmeye tıklanınca güncelleniyor; birkaç kez yeniden tara
	do
		local function gecikmeliTara() for _, t in ipairs({ 0.1, 0.4, 1 }) do C_Timer.After(t, baslat) end end
		for _, fn in ipairs({ "PlayerTalentFrame_Update", "TalentFrame_Update", "PlayerTalentFrame_UpdateTabs", "PlayerTalentFrame_Refresh", "PlayerTalentFrameTab_OnClick", "PanelTemplates_SetTab" }) do
			if type(_G[fn]) == "function" then pcall(hooksecurefunc, fn, gecikmeliTara) end
		end
		local fx = CreateFrame("Frame")
		for _, ev in ipairs({ "PLAYER_TALENT_UPDATE", "CHARACTER_POINTS_CHANGED", "ACTIVE_TALENT_GROUP_CHANGED", "TRAIT_CONFIG_UPDATED", "SPELLS_CHANGED" }) do pcall(fx.RegisterEvent, fx, ev) end
		fx:SetScript("OnEvent", gecikmeliTara)
	end
	-- Girişte zaten açık olan pencereler (ör. grup içindeyken raid yöneticisi) için
	baslat()
	f:RegisterEvent("GROUP_ROSTER_UPDATE")
	f:HookScript("OnEvent", function(_, e) if e == "GROUP_ROSTER_UPDATE" then baslat() end end)
	for _, fn in ipairs({ "CompactRaidFrameManager_Expand", "CompactRaidFrameManager_Toggle", "CompactRaidFrameManager_UpdateShown" }) do
		if _G[fn] then hooksecurefunc(fn, baslat) end
	end
	if _G.QuestWatch_Update then
		hooksecurefunc("QuestWatch_Update", function() pcall(function()
			local f = QuestWatchFrame
			if not f or not G.modul("arayuz") then return end
			for i = 1, 30 do
				local fs = _G["QuestWatchLine" .. i]
				if fs and fs:IsShown() then
					-- Görev başlıkları (Questie "[8] Başlık" biçimi dahil)
					local t = fs:GetText()
					local on, ad = "", t
					if type(t) == "string" and not G.gizli(t) then
						local a, b = t:match("^(%[[^%]]*%]%s*)(.+)$")
						if a then on, ad = a, b end
					end
					local tr = type(ad) == "string" and G.modul("gorev") and G.GorevAdi[ad]
					if tr then G.asilKaydet(fs, on .. tr); fs:SetText(on .. tr)
					else gorulen[fs] = nil; yaziIsle(fs) end
				end
			end
			-- Türkçe yazı daha uzun olabilir: çerçeve genişliğini yeni yazıya göre ayarla (ekran dışına taşmasın)
			local enGenis = 0
			for i = 1, 30 do
				local fs = _G["QuestWatchLine" .. i]
				if fs and fs:IsShown() then enGenis = math.max(enGenis, fs:GetStringWidth() or 0) end
			end
			if enGenis > 0 and f.GetWidth and enGenis + 10 > f:GetWidth() then f:SetWidth(enGenis + 10) end
		end) end)
	end
	if _G.UIDropDownMenu_AddButton then hooksecurefunc("UIDropDownMenu_AddButton", function() C_Timer.After(0, baslat) end) end
	-- Sohbet sekmeleri (General, Combat Log)
	local function sekmeler()
		if not G.modul("arayuz") then return end
		for i = 1, 10 do
			local tab = _G["ChatFrame" .. i .. "Tab"]
			local fs = tab and (tab.Text or (tab.GetFontString and tab:GetFontString()) or _G["ChatFrame" .. i .. "TabText"])
			if fs then gorulen[fs] = nil; guvenliIsle(fs) end
		end
	end
	C_Timer.After(2, sekmeler)
	if _G.FCF_SetWindowName then hooksecurefunc("FCF_SetWindowName", function() C_Timer.After(0, sekmeler) end) end
	-- Sürekli tarama (açık pencere yoksa neredeyse maliyetsiz)
	baslat()
	C_Timer.After(3, function() pcall(tamTarama) end)
	-- OLAY TABANLI tarama: tüm ekran sürekli taranmaz. Pencere açılınca (Show, NPC/satıcı/görev olayları)
	-- 2 tam geçiş yapılır; ayrıca saniyede bir tam geçiş. Her geçiş ~1.5 ms'lik dilimlere bölünür.
	local kirli, sonTam = 2, 0
	local gosterilen, gosterilenVar = setmetatable({}, { __mode = "k" }), false
	local function isaretle() kirli = 2 end
	G.tamTaramaIsaretle = isaretle
	local OLAYLAR = { "GOSSIP_SHOW", "QUEST_GREETING", "QUEST_DETAIL", "QUEST_PROGRESS", "QUEST_COMPLETE", "MERCHANT_SHOW",
		"TRAINER_SHOW", "TAXIMAP_OPENED", "BANKFRAME_OPENED", "MAIL_SHOW", "TRADE_SHOW", "AUCTION_HOUSE_SHOW",
		"PLAYER_ENTERING_WORLD", "ADDON_LOADED", "SKILL_LINES_CHANGED", "CRAFT_SHOW", "TRADE_SKILL_SHOW", "PET_STABLE_SHOW" }
	local ey = CreateFrame("Frame")
	for _, o in ipairs(OLAYLAR) do pcall(ey.RegisterEvent, ey, o) end
	ey:SetScript("OnEvent", function() kirli = 2 end)
	do
		local mt = getmetatable(CreateFrame("Frame"))
		local y = mt and mt.__index
		if type(y) == "table" and y.Show then
			hooksecurefunc(y, "Show", function(fr)
				-- Yalnızca açılan çerçeveyi kuyruğa al; tüm ekranı yeniden tarama
				if gosterilen[fr] then return end
				local ad = fr.GetName and fr:GetName()
				if ad and (ad:find("^NamePlate") or ad:find("^Compact") or ad:find("^Raid") or ad:find("^Party") or ad:find("Highlight")) then return end
				if fr.GetObjectType and fr:GetObjectType() == "GameTooltip" then return end
				-- Harita üzerindeki etiket/ipucu çerçeveleri (Questie, Leatrix Maps...): bekletmeden hemen çevir
				if WorldMapFrame and WorldMapFrame:IsShown() and WorldMapFrame:IsMouseOver() and not (fr.IsForbidden and fr:IsForbidden()) then
					pcall(tara, fr, 0)
					-- Yazı çoğu zaman Show'dan hemen sonra atanır: bir sonraki karede (çizimden önce) tekrar tara
					C_Timer.After(0, function() if fr:IsVisible() then pcall(tara, fr, 0) end end)
					return
				end
				gosterilen[fr] = true; gosterilenVar = true
			end)
		end
	end
	G.olcTicker(0.3, function()
		local simdi = GetTime()
		-- Açılan çerçeveler: yalnızca onların içini tara (bütçeli)
		if gosterilenVar then
			local t0 = debugprofilestop()
			gosterilenVar = false
			for fr in pairs(gosterilen) do
				if debugprofilestop() - t0 > 1.5 then gosterilenVar = true; break end
				gosterilen[fr] = nil
				if not (fr.IsForbidden and fr:IsForbidden()) and fr.IsVisible and fr:IsVisible() and not korunakli(fr) then pcall(tara, fr, 0) end
			end
			if gosterilenVar then return end
		end
		-- Tam ekran taraması: olaylarla (NPC/görev/satıcı penceresi) ya da en geç 5 sn'de bir
		if not tamImlec and kirli <= 0 and simdi - sonTam < 5 then return end
		-- Savaşta periyodik tam tarama yapma (FPS en çok orada önemli); olay tabanlı taramalar sürer
		if kirli <= 0 and UnitAffectingCombat and UnitAffectingCombat("player") then return end
		local ok, e = pcall(tamTarama)
		if not ok then G.tani.hata = tostring(e) end
		if not tamImlec then
			sonTam = simdi
			if kirli > 0 then kirli = kirli - 1 end
		end
	end)
	-- "Sell Price:" öneki: yazıya doğrudan kanca; oyun hangi yoldan yeniden yazarsa yazsın anında Türkçe kalsın
	local satisKancali, satisMesgul = {}, false
	local function satisYazisi(fs, zorla)
		if not fs or not fs.GetText or satisKancali[fs] then return end
		local t = fs:GetText()
		if not zorla and (type(t) ~= "string" or not t:find("^%s*Sell Price")) then return end
		satisKancali[fs] = true
		local function duzelt(self)
			if satisMesgul then return end
			local x = self:GetText()
			if type(x) == "string" and x:find("^%s*Sell Price") then
				local ptr = cevir(x)
				if ptr then satisMesgul = true; self:SetText(ptr); satisMesgul = false end
			end
		end
		pcall(hooksecurefunc, fs, "SetText", duzelt)
		pcall(hooksecurefunc, fs, "SetFormattedText", duzelt)
		duzelt(fs)
	end
	G._satisYazisi = satisYazisi
	local function paraCerceve(cer)
		if not cer then return end
		satisYazisi(cer.PrefixText, true)
		local n = cer.GetName and cer:GetName()
		if n then satisYazisi(_G[n .. "PrefixText"], true) end
	end
	if _G.MoneyFrame_Update then hooksecurefunc("MoneyFrame_Update", function(f) pcall(function() if type(f) == "string" then f = _G[f] end paraCerceve(f) end) end) end
	if _G.SetTooltipMoney then hooksecurefunc("SetTooltipMoney", function(tt)
		if G.esyaAtla(tt) then return end
		pcall(function() for i = 1, 4 do paraCerceve(_G[(tt:GetName() or "") .. "MoneyFrame" .. i]) end end)
	end) end
	-- Satış fiyatı satırı oyun tarafından ipucuna eklendiği anda (çizimden önce) çevrilsin
	local satirKancaIsleniyor = false
	local function hemenTara(tt)
		if satirKancaIsleniyor or not tt then return end
		satirKancaIsleniyor = true
		pcall(ipucuTara, tt)
		satirKancaIsleniyor = false
	end
	if TooltipDataProcessor and Enum and Enum.TooltipDataLineType then
		for _, y in ipairs({ "AddLinePostCall", "AddLinePreCall" }) do
			local f = TooltipDataProcessor[y]
			if f then
				for _, tip in ipairs({ "SellPrice", "None", "ItemName" }) do
					local t = Enum.TooltipDataLineType[tip]
					if t ~= nil then pcall(f, t, function(tt) hemenTara(tt) end) end
				end
			end
		end
	end
	local kancali = {}
	local function ipucuKanca()
	for _, ad in ipairs({ "GameTooltip", "SettingsTooltip", "ItemRefTooltip", "ShoppingTooltip1", "ShoppingTooltip2", "ShoppingTooltip3", "ItemRefShoppingTooltip1", "ItemRefShoppingTooltip2", "ItemRefShoppingTooltip3" }) do
		local tt = _G[ad]
		if tt and tt.HookScript and not kancali[tt] then
			kancali[tt] = true
			if tt.HookScript then pcall(tt.HookScript, tt, "OnTooltipCleared", function(self) ipucuFontSifirla(self) end) end
			for _, sc in ipairs({ "OnTooltipAddMoney", "OnTooltipSetItem" }) do
				pcall(tt.HookScript, tt, sc, function(self) hemenTara(self) end)
			end
			tt:HookScript("OnShow", function(self)
				if G.ipucuKapali or G.esyaAtla(self) then return end
				pcall(ipucuTara, self)
				-- Gizli (secret) başlıklı ipuçları (yeni aura düğmeleri: IceHUD hedef büffleri): büyü numarasından çevir
				pcall(function()
					local l1 = _G[(self:GetName() or "") .. "TextLeft1"]
					local t1 = l1 and l1:GetText()
					if t1 ~= nil and G.gizli(t1) and G.ipucuCevir then G.ipucuCevir(self) end
				end)
				C_Timer.After(0, function() if self:IsShown() then pcall(ipucuTara, self) end end)
			end)
			-- Bazı ipuçları açıkken her saniye yeniden yazılıyor (Ana Menü: FPS, gecikme...).
			-- Her yeniden çizimde (Show çağrısı) tekrar çevir.
			local isleniyor = false
			local function yeniden(self)
				if isleniyor or G._sigdirde or G.ipucuKapali then return end
				-- Eşya ipuçları Ipucu modülünde çevriliyor; burada her Show'da tekrar taramak takılma yapıyordu
				local okI, _, lnk = pcall(self.GetItem, self)
				if okI and lnk then return end
				isleniyor = true
				pcall(ipucuTara, self)
				isleniyor = false
				-- Karşılaştırma satırları Show'dan hemen sonra eklenebiliyor
				C_Timer.After(0, function() if self:IsShown() and not isleniyor then isleniyor = true; pcall(ipucuTara, self); isleniyor = false end end)
			end
			hooksecurefunc(tt, "Show", yeniden)
			-- Her kare yeniden yazılan ipuçları (birim ipucu, eklenti ipuçları): çizimden önce son durumu da çevir,
			-- böylece Türkçe/İngilizce arasında titreme olmaz
			-- Adı bilinmeyen para çerçeveleri için: ipucunun alt çerçevelerindeki yazıları da tara
			local function altTara(cer, derin)
				for _, c in ipairs({ cer:GetChildren() }) do
					if c then
						for _, r in ipairs({ c:GetRegions() }) do
							if r and r.GetObjectType and r:GetObjectType() == "FontString" then
								local t = r:GetText()
								if type(t) == "string" and t ~= "" and t:find("^%s*Sell Price") then
									satisYazisi(r)
									local ptr = cevir(t)
									if ptr then r:SetText(ptr) end
								end
							end
						end
						if derin < 2 then altTara(c, derin + 1) end
					end
				end
			end
			do
				tt:HookScript("OnUpdate", G.olcSar("ipucu OnUpdate", function(self, gecen)
					if G.ipucuKapali or G.esyaAtla(self) then return end
					-- Kare bütçesi doluysa bu kare hiç çalışma (kendi birikimimiz sonraki kareye kalır)
					self._gtrAcc = (self._gtrAcc or 0); self._gtrAcc2 = (self._gtrAcc2 or 0)
					if G.kareIs >= 3 then self._gtrAcc = self._gtrAcc + (gecen or 0); self._gtrAcc2 = self._gtrAcc2 + (gecen or 0); return end
					-- Ağır alt tarama saniyede ~5 kez yeter (her karede çalışması çok bellek ayırıp oyunu kasıyordu)
					local agir = false
					self._gtrAcc = (self._gtrAcc or 0) + (gecen or 0)
					if self._gtrAcc >= 0.2 then self._gtrAcc = 0; agir = true end
					-- Para satırı öneki ("Sell Price:") oyun tarafından her yenilemede İngilizce yazılır: çizimden önce çevir
					local tad = agir and self:GetName()
					if tad then
						-- Taşan satır var mı? (çeviri ya da başka eklenti satırı ipucu boyutlandıktan sonra uzadıysa) kutuyu genişlet
						local gen = self:GetWidth() or 0
						for li = 1, math.min(self:NumLines() or 0, 30) do
							local lf = _G[tad .. "TextLeft" .. li]
							if lf and lf:IsShown() and not (lf.CanWordWrap and lf:CanWordWrap()) then
								local rf = _G[tad .. "TextRight" .. li]
								local w = (lf:GetStringWidth() or 0) + ((rf and rf:IsShown() and rf:GetText()) and ((rf:GetStringWidth() or 0) + 12) or 0) + 22
								if w > gen + 1 and w <= 420 then ipucuSigdir(self); break end
							end
						end
						for mi = 1, 4 do
							local pf = _G[tad .. "MoneyFrame" .. mi .. "PrefixText"]
							local pt = pf and pf.GetText and pf:GetText()
							if type(pt) == "string" and pt ~= "" and not G.gizli(pt) and not G.turkceMi(pt) then
								local ptr = cevir(pt)
								if ptr then pf:SetText(ptr) end
							end
						end
					end
					-- Alt çerçeve taraması yalnızca ipucu içeriği değişince (her 0.2 sn'de baştan dolaşmak takılma yapıyordu)
					if agir then
						local l1 = _G[(self:GetName() or "") .. "TextLeft1"]
						local okI, t1 = pcall(function() return l1 and l1:GetText() end)
						local im = (self:NumLines() or 0) .. "\31" .. ((okI and type(t1) == "string" and not G.gizli(t1)) and t1 or "")
						if self._gtrAltIm ~= im then self._gtrAltIm = im; pcall(altTara, self, 1) end
					end
					-- Savaşta yazıları gizli gelen aura ipuçları her yenilemede gizliye döner: simge önbelleğinden yeniden yaz
					if agir and G.ipucuCevir then
						pcall(function()
							local l1 = _G[(self:GetName() or "") .. "TextLeft1"]
							local t1 = l1 and l1:GetText()
							if t1 ~= nil and G.gizli(t1) then G.ipucuCevir(self) end
						end)
					end
					-- Satır taraması saniyede ~20 kez yeter (her karede çalışması toplamda en pahalı işlerden biriydi)
					self._gtrAcc2 = (self._gtrAcc2 or 0) + (gecen or 0)
					if self._gtrAcc2 >= 0.1 and not isleniyor then self._gtrAcc2 = 0; isleniyor = true; pcall(ipucuTara, self); isleniyor = false end
				end))
			end
			-- Satış fiyatı düz satır olarak da eklenebiliyor (Bagnon: "Sell Price: 2[gümüş] 25[bakır]"): eklendiği anda çevir
			local function satisSatiri(self)
				local tad = self:GetName(); if not tad then return end
				local n = self:NumLines() or 0
				for i = math.max(1, n - 3), n do
					local fs = _G[tad .. "TextLeft" .. i]
					local x = fs and fs.GetText and fs:GetText()
					if type(x) == "string" and not G.gizli(x) and (x:find("Sell Price", 1, true) or x:find("^%s*Minimum:") or x:find("^%s*Maximum:")) then
						local y = x:gsub("Sell Price", "Satış Fiyatı", 1):gsub("^(%s*)Minimum:", "%1En az:"):gsub("^(%s*)Maximum:", "%1En çok:")
						if y ~= x then fs:SetText(y) end
					end
				end
			end
			-- Simgeli satırlar ("[sol tık] Drag   [sol][sağ] Search"): simgeler arasındaki her sözcüğü eklendiği anda çevir
			local function simgeliSatir(self)
				local tad = self:GetName(); if not tad then return end
				local n = self:NumLines() or 0
				local fs = _G[tad .. "TextLeft" .. n]
				local x = fs and fs.GetText and fs:GetText()
				if type(x) ~= "string" or G.gizli(x) or G.turkceMi(x) or not x:find("|[AT]") then return end
				local biri = false
				local y = x:gsub("(|[AT].-|[at])([^|]*)", function(ic, txt)
					local b0, govde, son0 = txt:match("^(%s*)(.-)(%s*)$")
					if govde == "" then return nil end
					local tr = G.cevir(G.Arayuz, govde) or G.cevir(G.Arayuz, G.renksiz(govde))
					if tr then biri = true; return ic .. b0 .. tr .. son0 end
				end)
				if biri and y ~= x then fs:SetText(y) end
			end
			if tt.AddLine then hooksecurefunc(tt, "AddLine", function(self) if G.esyaAtla(self) then return end; pcall(satisSatiri, self); pcall(simgeliSatir, self) end) end
			-- İpucu açıkken kendini yenileyen yerler (karakter yuvaları, birimler) Show çağırmadan yazar
			for _, yontem in ipairs({ "SetText", "AddLine", "AddDoubleLine" }) do
				if tt[yontem] then hooksecurefunc(tt, yontem, yeniden) end
			end
		end
	end
	end
	ipucuKanca()
	-- Veri tabanlı ipuçları (birim, aura vb.) her yenilendiğinde
	if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and TooltipDataProcessor.AllTypes then
		TooltipDataProcessor.AddTooltipPostCall(TooltipDataProcessor.AllTypes, function(tt) pcall(ipucuTara, tt) end)
	end
	local yk = CreateFrame("Frame")
	yk:RegisterEvent("ADDON_LOADED")
	yk:SetScript("OnEvent", ipucuKanca)
	if SettingsPanel then SettingsPanel:HookScript("OnShow", ipucuKanca) end
	-- Açılır pencereler (yok etme, takas onayı, ruhunu bırak...): yazı ve düğmeler.
	-- Eski ve yeni pencere şablonlarında alan adları farklı; hepsini dene.
	local function popupYazilari(f)
		local t = {}
		local function ekle(x) if x and x.GetText and x.SetText then t[#t + 1] = x end end
		local ad = f:GetName()
		ekle(f.text); ekle(f.Text); ekle(ad and _G[ad .. "Text"])
		for j = 1, 4 do
			local b = f["button" .. j] or (ad and _G[ad .. "Button" .. j]) or (f.ButtonContainer and f.ButtonContainer["Button" .. j])
			if b then ekle(b.GetFontString and b:GetFontString()); ekle(b.Text) end
		end
		return t
	end
	local popupKancali = {}
	local function popupCevir(fs)
		if not G.modul("arayuz") then return end
		local t = fs:GetText()
		if not t or G.gizli(t) or t == "" or G.turkceMi(t) then return end
		local ok, tr = pcall(cevir, t)
		if ok and tr and tr ~= t then
			popupKancali[fs] = "yaziyor"; pcall(fs.SetText, fs, tr); popupKancali[fs] = true
		end
	end
	local function popuplar()
		for i = 1, 4 do
			local f = _G["StaticPopup" .. i]
			if f and f:IsShown() then
				for _, fs in ipairs(popupYazilari(f)) do
					if not popupKancali[fs] then
						popupKancali[fs] = true
						-- Geri sayım gibi her saniye yeniden yazılan metinler için
						hooksecurefunc(fs, "SetText", function(self) if popupKancali[self] ~= "yaziyor" then popupCevir(self) end end)
						if fs.SetFormattedText then hooksecurefunc(fs, "SetFormattedText", function(self) if popupKancali[self] ~= "yaziyor" then popupCevir(self) end end) end
					end
					popupCevir(fs)
				end
			end
		end
	end
	if _G.StaticPopup_Show then
		hooksecurefunc("StaticPopup_Show", function()
			pcall(popuplar)
			C_Timer.After(0, function() pcall(popuplar) end)
			C_Timer.After(0.1, function() pcall(popuplar) end)
		end)
	end
	for i = 1, 4 do
		local f = _G["StaticPopup" .. i]
		if f and f.HookScript then f:HookScript("OnShow", function() C_Timer.After(0, function() pcall(popuplar) end) end) end
	end
	local dugme = _G.CompactRaidFrameManagerToggleButton
	if dugme then dugme:HookScript("OnClick", baslat) end
end)

G.dinle(function(k)
	if k == "arayuz" or k == "acik" then wipe(gorulen) end
end)

-- Oyunun hazır metinleri (BattleNet arkadaş bildirimi, satış fiyatı vb.) doğrudan değiştirilir
local GLOBAL_TR = {
	BN_INLINE_TOAST_FRIEND_ONLINE = "%s çevrimiçi oldu.",
	BN_INLINE_TOAST_FRIEND_OFFLINE = "%s çevrimdışı oldu.",
	BN_INLINE_TOAST_FRIEND_ADDED = "%s arkadaş listene eklendi.",
	BN_INLINE_TOAST_FRIEND_REMOVED = "%s arkadaş listenden çıkarıldı.",
	BN_INLINE_TOAST_FRIEND_REQUEST = "Bir arkadaşlık isteğin var.",
	BN_INLINE_TOAST_FRIEND_PENDING = "%d bekleyen arkadaşlık isteğin var.",
	BN_INLINE_TOAST_BROADCAST = "%s: %s",
	SELL_PRICE = "Satış Fiyatı",
	REPAIR_AN_ITEM = "Bir Eşyayı Onar",
	REPAIR_ALL_ITEMS = "Tüm Eşyaları Onar",
	REPAIR_ITEMS = "Eşyaları Onar",
	TRAINER_FILTER_AVAILABLE = "Mevcut",
	TRAINER_FILTER_UNAVAILABLE = "Mevcut Değil",
	TRAINER_FILTER_USED = "Zaten Bilinen",
	ITEM_SPELL_KNOWN = "Zaten biliniyor",
	NO_ROLE = "Rol Yok",
	MISS = "Iska", DODGE = "Sıyrılma", PARRY = "Savuşturma", BLOCK = "Blok", RESIST = "Direnç",
	IMMUNE = "Bağışık", ABSORB = "Emildi", EVADE = "Kaçındı", DEFLECT = "Saptırıldı", REFLECT = "Yansıtıldı",
	ERR_ZONE_EXPLORED = "Keşfedildi: %s",
	ERR_ZONE_EXPLORED_XP = "Keşfedildi: %s (+%d deneyim)",
	ERR_QUEST_MUST_CHOOSE = "Bir ödül seçmelisin.",
	CONFIRM_BINDER = "%s yeni evin olsun mu?",
	NAMEPLATES_MESSAGE_ENEMY_ON = "Düşman isim levhaları açıldı",
	NAMEPLATES_MESSAGE_ENEMY_OFF = "Düşman isim levhaları kapatıldı",
	NAMEPLATES_MESSAGE_FRIENDLY_ON = "Dost isim levhaları açıldı",
	NAMEPLATES_MESSAGE_FRIENDLY_OFF = "Dost isim levhaları kapatıldı",
	NAMEPLATES_MESSAGE_ALL_ON = "İsim levhaları açıldı",
	NAMEPLATES_MESSAGE_ALL_OFF = "İsim levhaları kapatıldı",
	CHAT_MONSTER_SAY_GET = "%s: ",
	CHAT_MONSTER_YELL_GET = "%s bağırır: ",
	CHAT_MONSTER_WHISPER_GET = "%s fısıldar: ",
	NEWBIE_TOOLTIP_FREE_FOR_ALL = "Herkes Serbest kuralında herkes her şeyi toplayabilir.",
	NEWBIE_TOOLTIP_ROUND_ROBIN = "Sırayla kuralında ganimet grup üyeleri arasında sırayla dağıtılır.",
	NEWBIE_TOOLTIP_MASTER_LOOTER = "Ganimet Ustası kuralında ganimet eşiğinin üzerindeki eşyaları yalnızca ganimet ustası dağıtabilir; diğer eşyalar sırayla dağıtılır.",
	NEWBIE_TOOLTIP_GROUP_LOOT = "Grup Ganimeti kuralında ganimet sırayla dağıtılır. Ganimet eşiğinin üzerindeki eşyalar için tüm grup zar atabilir.",
	NEWBIE_TOOLTIP_NEED_BEFORE_GREED = "Önce İhtiyaç kuralında ganimet sırayla dağıtılır. Ganimet eşiğinin üzerindeki eşyalar için yalnızca o eşyayı kullanabilen grup üyeleri zar atabilir.",
}
for _, son in ipairs({ "FREE_FOR_ALL", "ROUND_ROBIN", "MASTER_LOOTER", "GROUP_LOOT", "NEED_BEFORE_GREED" }) do
	GLOBAL_TR["NEWBIE_TOOLTIP_UNIT_" .. son] = GLOBAL_TR["NEWBIE_TOOLTIP_" .. son]
	GLOBAL_TR["LOOT_" .. son .. "_DESC"] = GLOBAL_TR["NEWBIE_TOOLTIP_" .. son]
end
local globalAsil = {}
local function globalUygula()
	local acik = G.modul("arayuz")
	for k, v in pairs(GLOBAL_TR) do
		if globalAsil[k] == nil and type(_G[k]) == "string" then globalAsil[k] = _G[k] end
		if globalAsil[k] ~= nil then
			-- Retail: Blizzard global yazılarını değiştirmek onları kirletir (taint) ve güvenli kodu bozabilir;
			-- orada yalnızca sözlüğe ekleriz, yakalayıcı ekrandaki yazıyı yine çevirir.
			-- Classic'te de yalnızca güvenli kodun okumadığı sohbet biçimlerini değiştiriyoruz; ötekiler
			-- (MISS, SELL_PRICE, ERR_... gibi) eylem engellendi uyarısına yol açabiliyordu.
			if not G.RETAIL and not G.FOREVER and (k:find("^CHAT_MONSTER_") or k:find("^BN_INLINE_TOAST_")) then _G[k] = acik and v or globalAsil[k] end
			-- Menüler metni yüklenirken kopyalamış olabilir: İngilizce aslını sözlüğe de ekle
			if G.Arayuz and not v:find("%%") then G.Arayuz[globalAsil[k]] = v end
		end
	end
end
pcall(globalUygula)
local gf = CreateFrame("Frame")
gf:RegisterEvent("PLAYER_LOGIN")
gf:SetScript("OnEvent", function() pcall(globalUygula) end)
G.dinle(function(k) if k == "arayuz" or k == "acik" then pcall(globalUygula) end end)

-- Diğer eklentiler (Questie) için: görev hedefi gibi kısa metinleri çevirir, çeviri yoksa nil döner
function G.hedefCevir(s)
	if type(s) ~= "string" or not G.modul("arayuz") then return nil end
	return G.cevir(G.Arayuz, s) or desenCevir(s)
end

-- "Tümü" (All) daralt/genişlet düğmeleri: sekme alanı "All" için çizilmiş, Türkçe yazı taşıyordu.
-- Yazıyı İngilizcesinin genişliğine yakın olacak şekilde küçült (görev günlüğü, beceriler, eğitmen, meslekler).
local HEPSI = { "QuestLogCollapseAllButton", "SkillFrameCollapseAllButton", "ClassTrainerCollapseAllButton",
	"TradeSkillCollapseAllButton", "CraftCollapseAllButton", "TrainerCollapseAllButton" }
local hepsiKurulu = {}
local function hepsiKucult(b)
	local fs = b and b.GetFontString and b:GetFontString()
	if not fs or not fs.GetFont then return end
	if not b._gtrFont then local d, bo, st = fs:GetFont(); if d then b._gtrFont = { d, bo, st or "" } end end
	local f = b._gtrFont
	if not f then return end
	if G.fontSerbest(fs) then fs:SetFont(f[1], f[2], f[3]) end
	local t = fs:GetText()
	if type(t) == "string" and G.turkceMi(t) and G.kucult("hepsi") then
		local g = fs.GetUnboundedStringWidth and fs:GetUnboundedStringWidth() or fs:GetStringWidth()
		local sinir = 24 -- "All" yazısının genişliği civarı
		local oran = (g and g > sinir) and math.max(0.65, sinir / g) or 1
		if G.fontSerbest(fs) then fs:SetFont(f[1], math.floor(f[2] * math.min(0.82, oran) * 10 + 0.5) / 10, f[3]) end
	end
end
local function hepsiKur()
	for _, ad in ipairs(HEPSI) do
		local b = _G[ad]
		if b and not hepsiKurulu[ad] and b.GetFontString then
			hepsiKurulu[ad] = true
			hooksecurefunc(b, "SetText", function(self)
				pcall(hepsiKucult, self)
				C_Timer.After(0, function() pcall(hepsiKucult, self) end)
			end)
			b:HookScript("OnShow", function(self) C_Timer.After(0, function() pcall(hepsiKucult, self) end) end)
			pcall(hepsiKucult, b)
		end
	end
end
local hk = CreateFrame("Frame")
hk:RegisterEvent("PLAYER_LOGIN")
hk:RegisterEvent("ADDON_LOADED")
hk:SetScript("OnEvent", function() C_Timer.After(0.5, hepsiKur) end)

-- Sohbet giriş kutusu ipucu ("Type /2 to ask questions in Newcomer Chat"): kutu açılınca ve ipucu güncellenince çevir
local sohbetIpucuKurulu, ipucuYaziyor = {}, false
local function sohbetIpucuCevir()
	if not G.modul("arayuz") then return end
	for i = 1, (NUM_CHAT_WINDOWS or 10) do
		local eb = _G["ChatFrame" .. i .. "EditBox"]
		if eb then
			pcall(function()
				local adaylar = { eb.NewcomerHint, eb.prompt, eb.Instructions }
				for _, r in ipairs({ eb:GetRegions() }) do adaylar[#adaylar + 1] = r end
				for _, c in ipairs({ eb:GetChildren() }) do
					if c.GetRegions then for _, r in ipairs({ c:GetRegions() }) do adaylar[#adaylar + 1] = r end end
				end
				for _, r in ipairs({ ChatFrame1:GetRegions() }) do adaylar[#adaylar + 1] = r end
				for _, r in pairs(adaylar) do
					if type(r) == "table" and r.GetObjectType and r:GetObjectType() == "FontString" then
						local t = r:GetText()
						if type(t) == "string" and t ~= "" and #t < 200 and not G.turkceMi(t) and t:find("Newcomer") then
							local sonuc = G.gomuluCevir(t) or cevir(t)
							if sonuc and sonuc ~= t then
								ipucuYaziyor = true
								pcall(r.SetText, r, sonuc)
								ipucuYaziyor = false
							end
						end
						-- Blizzard ipucunu her açılışta yeniden yazar: SetText'e de kanca tak
						if not sohbetIpucuKurulu[r] and r.SetText then
							sohbetIpucuKurulu[r] = true
							hooksecurefunc(r, "SetText", function(self, m)
								if ipucuYaziyor or type(m) ~= "string" or not m:find("Newcomer") or G.turkceMi(m) or not G.modul("arayuz") then return end
								local sn = G.gomuluCevir(m) or cevir(m)
								if sn and sn ~= m then
									ipucuYaziyor = true
									pcall(self.SetText, self, sn)
									ipucuYaziyor = false
								end
							end)
						end
					end
				end
			end)
		end
	end
end
local function sohbetIpucuKur()
	for i = 1, (NUM_CHAT_WINDOWS or 10) do
		local eb = _G["ChatFrame" .. i .. "EditBox"]
		if eb and not sohbetIpucuKurulu[eb] then
			sohbetIpucuKurulu[eb] = true
			eb:HookScript("OnShow", function() C_Timer.After(0, sohbetIpucuCevir) end)
			if eb.NewcomerHint and eb.NewcomerHint.HookScript then
				eb.NewcomerHint:HookScript("OnShow", function() C_Timer.After(0, sohbetIpucuCevir) end)
			end
		end
	end
	if type(_G.ChatEdit_UpdateNewcomerEditBoxHint) == "function" and not sohbetIpucuKurulu.fn then
		sohbetIpucuKurulu.fn = true
		hooksecurefunc("ChatEdit_UpdateNewcomerEditBoxHint", function() C_Timer.After(0, sohbetIpucuCevir) end)
	end
	sohbetIpucuCevir()
end
local sik = CreateFrame("Frame")
sik:RegisterEvent("PLAYER_LOGIN")
sik:RegisterEvent("PLAYER_ENTERING_WORLD")
sik:RegisterEvent("CHAT_MSG_CHANNEL_NOTICE")
sik:SetScript("OnEvent", function()
	C_Timer.After(1, sohbetIpucuKur)
	C_Timer.After(4, sohbetIpucuKur)
end)

-- Türkçe harf (ç ğ ı ş ö ü) desteklemeyen özel yazı tipli eklenti yazıları:
-- yazıda Türkçe harf varsa ve yazı tipi oyunun kendi tipi değilse, Türkçe destekli tipe geç.
do
	local G = WoWTurkce
	local trHarf = "[\195\135\195\167\196\158\196\159\196\176\196\177\195\150\195\182\197\158\197\159\195\156\195\188]"
	local duzeltilen = setmetatable({}, { __mode = "k" })
	local function fontDuzelt(fs, metin)
		-- Her seferinde gerçek yazı tipine bak: eklentiler (Questie takipçisi gibi) yazı tipini SetFontObject ile geri alabiliyor
		if type(metin) ~= "string" or not metin:find(trHarf) then return end
		if not G.fontSerbest(fs) then return end
		local ok, yol, boy, bayrak = pcall(fs.GetFont, fs)
		if not ok or type(yol) ~= "string" then return end
		local k = yol:lower():gsub("/", "\\")
		if k:find("wowturkce", 1, true) then duzeltilen[fs] = true; return end
		-- Oyunun kendi tipleri de (ARIALN, FRIZQT...) çoğu Türkçe harfi içermez: hepsini değiştir
		duzeltilen[fs] = true
		pcall(fs.SetFont, fs, G.FONT_ARAYUZ, boy or 12, bayrak or "")
	end
	local ornek = UIParent:CreateFontString()
	local mt = getmetatable(ornek)
	local yontem = mt and mt.__index
	if type(yontem) == "table" then
		if yontem.SetFont then
			local icerde = false
			hooksecurefunc(yontem, "SetFont", function(fs)
				if icerde then return end
				icerde = true
				duzeltilen[fs] = nil
				local ok, m = pcall(fs.GetText, fs)
				if ok then pcall(fontDuzelt, fs, m) end
				icerde = false
			end)
		end
		for _, ad in ipairs({ "SetText", "SetFormattedText" }) do
			if yontem[ad] then
				hooksecurefunc(yontem, ad, function(fs, m, ...)
					if ad == "SetFormattedText" then m = fs:GetText() end
					pcall(fontDuzelt, fs, m)
				end)
			end
		end
		if yontem.SetFontObject then
			local icerde2 = false
			hooksecurefunc(yontem, "SetFontObject", function(fs)
				if icerde2 then return end
				icerde2 = true
				local ok, m = pcall(fs.GetText, fs)
				if ok then pcall(fontDuzelt, fs, m) end
				icerde2 = false
			end)
		end
	end
end

-- Questie görev takipçisi: çerçevedeki tüm yazıları (renk kodlarını koruyarak) doğrudan çevir.
-- Metin kancaları bu çerçeveyi kaçırdığında bile görev adları ve hedefleri Türkçe görünsün.
do
	local kancali = setmetatable({}, { __mode = "k" })
	local isleniyor = false
	local function cevirSatir(core)
		if type(core) ~= "string" or core == "" or G.turkceMi(core) then return nil end
		local on, ad = core:match("^(%s*%[[%d%+%?%a]+%]%s*)(.+)$")
		if not on then on, ad = core:match("^(%s*)(.+)$") end
		if G.modul("gorev") and G.GorevAdi[ad] then return on .. G.GorevAdi[ad] end
		local sy, gv = core:match("^(%s*%-?%s*%d+/%d+) (.+)$")
		if sy and gv then
			local yad = gv:match("^(.-) slain$")
			if yad then
				local g = G.yaratikCevir and G.yaratikCevir(yad)
				if g then return sy .. " " .. g .. " öldürüldü" end
			end
		end
		return G.hedefCevir(core)
	end
	local function yazDuzelt(fs)
		if isleniyor or not G.modul("arayuz") then return end
		local t = fs:GetText()
		if type(t) ~= "string" or t == "" or #t > 400 then return end
		local c1, core, c2 = t:match("^(|c%x%x%x%x%x%x%x%x)(.-)(|r)$")
		if not c1 then c1, core, c2 = "", t, "" end
		if core:find("|", 1, true) then return end
		local ok, tr = pcall(cevirSatir, core)
		if ok and tr and tr ~= core then
			isleniyor = true
			if G.trAsilEkle then G.trAsilEkle(c1 .. tr .. c2, t) end
			pcall(fs.SetText, fs, c1 .. tr .. c2)
			isleniyor = false
			G.tani.qCevrilen = (G.tani.qCevrilen or 0) + 1
		end
	end
	local function gez(f, d)
		if d > 6 then return end
		if f.GetRegions then
			for _, r in ipairs({ f:GetRegions() }) do
				if r.GetObjectType and r:GetObjectType() == "FontString" then
					if not kancali[r] then
						kancali[r] = true
						pcall(hooksecurefunc, r, "SetText", yazDuzelt)
					end
					yazDuzelt(r)
				end
			end
		end
		if f.GetChildren then
			for _, c in ipairs({ f:GetChildren() }) do gez(c, d + 1) end
		end
	end
	local function tara()
		if not G.modul("arayuz") then return end
		local k = _G.Questie_BaseFrame
		if k and k:IsShown() then pcall(gez, k, 0) end
	end
	G.olcTicker(1.5, tara)
	function G.questieDokum()
		local k = _G.Questie_BaseFrame
		if not k then G.yaz("Questie_BaseFrame yok"); return end
		local n = 0
		local function d(f, dep)
			if dep > 6 or n > 25 then return end
			for _, r in ipairs({ f.GetRegions and f:GetRegions() and { f:GetRegions() } or {} }) do
				for _, x in ipairs(r) do
					if x.GetObjectType and x:GetObjectType() == "FontString" and x:GetText() and n <= 25 then
						n = n + 1; G.yaz((x:GetText():gsub("|", "||")))
					end
				end
			end
			for _, c in ipairs({ f:GetChildren() }) do d(c, dep + 1) end
		end
		d(k, 0)
	end
end

-- İngilizce moda geçince görev pencerelerinde kalan Türkçe yazıları özgün hâline döndür.
-- (Takipçiler yazılarını kendiliğinden yenilemiyor; çerçeveler de yeniden kullanıldığı için çerçeve bazlı geri alma kaçırıyordu.)
do
	local tersAd
	local function tersKur()
		tersAd = {}
		for en, tr in pairs(G.GorevAdi or {}) do
			if type(en) == "string" and type(tr) == "string" and tersAd[tr] == nil then tersAd[tr] = en end
		end
	end
	local SABIT = { ["(Tamamlandı)"] = "(Complete)", ["(Başarısız)"] = "(Failed)", ["Teslim edilmeye hazır"] = "Ready for turn-in" }
	local function ingilizcesi(t)
		local en = G.trAsil and G.trAsil[t]
		if en then return en end
		if not tersAd then tersKur() end
		local degisti = false
		-- renk kodlarını koruyarak parça parça: "[21] Görev Adı", "(Tamamlandı)"
		local y = t:gsub("%(Tamamlandı%)", function() degisti = true; return "(Complete)" end)
		y = y:gsub("%(Başarısız%)", function() degisti = true; return "(Failed)" end)
		local function adDegis(on, ad, son)
			local e = tersAd[ad]
			if e then degisti = true; return on .. e .. son end
		end
		-- tüm satır tek bir ad (önekli/öneksiz, renk sarmalı olabilir)
		local c1, govde, c2 = y:match("^(|c%x%x%x%x%x%x%x%x)(.-)(|r.*)$")
		if not c1 then c1, govde, c2 = "", y, "" end
		local on, ad, son = govde:match("^(%s*%[[^%]]*%]%s*)(.-)(%s*)$")
		if not on then on, ad, son = govde:match("^(%s*%-?%s*)(.-)(%s*)$") end
		local yeni = ad and adDegis(on, ad, son)
		if yeni then y = c1 .. yeni .. c2 end
		if SABIT[y] then y = SABIT[y]; degisti = true end
		if degisti and y ~= t then return y end
	end
	local KOK = { "Questie_BaseFrame", "QuestScrollFrame", "QuestMapFrame", "QuestLogFrame", "QuestLogDetailFrame", "ObjectiveTrackerFrame", "QuestWatchFrame", "WatchFrame", "QuestFrame" }
	local function gez(f, d, say)
		if d > 10 or not f or (f.IsForbidden and f:IsForbidden()) then return say end
		if f.GetRegions then
			for _, r in ipairs({ f:GetRegions() }) do
				if r.GetObjectType and r:GetObjectType() == "FontString" then
					local t = r:GetText()
					if type(t) == "string" and t ~= "" and not G.gizli(t) and #t < 600 then
						local en = ingilizcesi(t)
						if en and en ~= t then r:SetText(en); if G.sigdirSifirla then pcall(G.sigdirSifirla, r) end; say = say + 1 end
					end
				end
			end
		end
		if f.GetChildren then for _, c in ipairs({ f:GetChildren() }) do say = gez(c, d + 1, say) end end
		return say
	end
	local function supur()
		if G.ayar("acik") then return end
		local say = 0
		for _, ad in ipairs(KOK) do
			local f = _G[ad]
			if type(f) == "table" then local ok, n = pcall(gez, f, 0, 0); if ok and n then say = say + n end end
		end
		G.tani.supurulen = (G.tani.supurulen or 0) + say
	end
	G.ingilizceSupur = supur
	-- Geçiş anında bir kez: ekrandaki bütün pencerelerde, defterde aslı olan Türkçe yazıları geri al
	local function genelSupur()
		if G.ayar("acik") or not EnumerateFrames or not G.trAsil then return end
		local say = 0
		local f = EnumerateFrames()
		while f do
			if not (f.IsForbidden and f:IsForbidden()) and f.IsVisible and f:IsVisible() and f.GetRegions and not korunakli(f) then
				for _, r in ipairs({ f:GetRegions() }) do
					if r.GetObjectType and r:GetObjectType() == "FontString" then
						local t = r:GetText()
						if type(t) == "string" and t ~= "" and not G.gizli(t) then
							local en = G.trAsil[t]
							if en and en ~= t then r:SetText(en); if G.sigdirSifirla then pcall(G.sigdirSifirla, r) end; say = say + 1 end
						end
					end
				end
			end
			f = EnumerateFrames(f)
		end
		G.tani.genelSupurulen = (G.tani.genelSupurulen or 0) + say
	end
	-- Türkçeye dönünce: görev pencerelerindeki yazıları kendilerine yeniden yazdır; böylece bütün çeviri kancaları
	-- (görev adı, hedef satırları, Questie takipçisi) ilk yazıldıkları andaki gibi yeniden çalışır.
	local function yenidenYaz(f, d)
		if d > 10 or not f or (f.IsForbidden and f:IsForbidden()) then return end
		if f.GetRegions then
			for _, r in ipairs({ f:GetRegions() }) do
				if r.GetObjectType and r:GetObjectType() == "FontString" then
					local t = r:GetText()
					if type(t) == "string" and t ~= "" and not G.gizli(t) and #t < 2000 and not G.turkceMi(t) then pcall(r.SetText, r, t) end
				end
			end
		end
		if f.GetChildren then for _, c in ipairs({ f:GetChildren() }) do yenidenYaz(c, d + 1) end end
	end
	local function turkceyeDon()
		if not G.ayar("acik") then return end
		for _, ad in ipairs(KOK) do
			local f = _G[ad]
			if type(f) == "table" and f.IsVisible and f:IsVisible() then pcall(yenidenYaz, f, 0) end
		end
		if G.gorevYenile then pcall(G.gorevYenile) end
	end
	G.dinle(function(k)
		if k ~= "acik" then return end
		if G.ayar("acik") then
			pcall(turkceyeDon)
			if C_Timer and C_Timer.After then
				for _, sn in ipairs({ 0.1, 0.5 }) do C_Timer.After(sn, function() pcall(turkceyeDon) end) end
			end
			return
		end
		pcall(genelSupur)
		if C_Timer and C_Timer.After then C_Timer.After(0.4, function() pcall(genelSupur) end) end
		pcall(supur)
		if C_Timer and C_Timer.After then
			for _, sn in ipairs({ 0.05, 0.3, 1.0 }) do C_Timer.After(sn, function() pcall(supur) end) end
		end
	end)
	-- İngilizce moddayken görev pencereleri yeniden çizilirse (kaydırma, sekme değişimi) yine süpür
	local sf, gecen = CreateFrame("Frame"), 0
	sf:SetScript("OnUpdate", function(_, e)
		if G.ayar("acik") then return end
		gecen = gecen + e
		if gecen < 0.5 then return end
		gecen = 0
		pcall(supur)
	end)
end
