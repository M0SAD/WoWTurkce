-- Büyü çubuğu (cast bar): büyü adı oyun yazar yazmaz, aynı karede Türkçeye çevrilir.
-- Böylece önce İngilizce adın görünüp sonra değişmesi (titreme) olmaz.
local G = WoWTurkce

local CUBUKLAR = { "CastingBarFrame", "PlayerCastingBarFrame", "PetCastingBarFrame", "TargetFrameSpellBar", "FocusFrameSpellBar" }

local function yaziAlani(f)
	local ad = f:GetName()
	return f.Text or f.text or (ad and _G[ad .. "Text"])
end

-- Çubuğun durum yazıları (büyü başarısız olunca ya da kesilince)
local DURUM = { ["Failed"] = "Başarısız", ["Interrupted"] = "Kesildi", ["Canceled"] = "İptal edildi",
	["Cancelled"] = "İptal edildi", ["Channeling"] = "Kanalize ediliyor", ["Failed attempt"] = "Başarısız deneme" }

local function cevirAd(t)
	if not t or t == "" or G.gizli(t) or G.turkceMi(t) then return nil end
	if DURUM[t] then return DURUM[t] end
	if G.BuyuAdi and G.BuyuAdi[t] then return G.BuyuAdi[t] end
	if G.buyuAdiCevir then return G.buyuAdiCevir(t) end
end

local function kur(f)
	if not f or f._gtrCubuk then return end
	local fs = yaziAlani(f)
	if not fs or not fs.SetText then return end
	f._gtrCubuk = true
	local yaziyor = false
	local function duzelt()
		if yaziyor or not G.ayar("acik") or not G.modul("buyuadi") then return end
		local tr = cevirAd(fs:GetText())
		if tr then yaziyor = true; fs:SetText(tr); yaziyor = false end
	end
	-- Oyun adı SetText ile yazdığı anda (çizimden önce) değiştir
	hooksecurefunc(fs, "SetText", function() pcall(duzelt) end)
	if f.HookScript then f:HookScript("OnEvent", function() pcall(duzelt) end) end
	if f.HookScript then f:HookScript("OnShow", function() pcall(duzelt) end) end
end

G.basla(function()
	for _, ad in ipairs(CUBUKLAR) do pcall(kur, _G[ad]) end
	-- İsim levhası büyü çubukları ve sonradan yüklenen çerçeveler
	local f = CreateFrame("Frame")
	f:RegisterEvent("ADDON_LOADED")
	f:RegisterEvent("NAME_PLATE_UNIT_ADDED")
	f:SetScript("OnEvent", function(_, olay, birim)
		for _, ad in ipairs(CUBUKLAR) do pcall(kur, _G[ad]) end
		if olay == "NAME_PLATE_UNIT_ADDED" and C_NamePlate and C_NamePlate.GetNamePlateForUnit then
			local p = C_NamePlate.GetNamePlateForUnit(birim)
			local uf = p and p.UnitFrame
			local cb = uf and (uf.castBar or uf.CastBar)
			if cb and not (cb.IsForbidden and cb:IsForbidden()) then pcall(kur, cb) end
		end
	end)
end)
