-- Büyü kitabı: büyü adlarını, alt başlıkları (Rank 1, Passive) ve sekme adlarını Türkçe gösterir.
-- Sadece yazıyı değiştirir; büyülerin kendisine ve kısayol tuşlarına dokunmaz.
local G = WoWTurkce

local function altCevir(s)
	if not s or s == "" then return nil end
	local tr = G.BuyuAlt[s]
	if tr then return tr end
	local n = s:match("^Rank (%d+)$")
	if n then return "Rütbe " .. n end
end
G.buyuAltCevir = altCevir

local function dugmeCevir(btn)
	if not btn or not btn.GetName or not G.modul("buyuadi") then return end
	local ad = btn:GetName()
	local isim = _G[ad .. "SpellName"] or btn.SpellName
	local alt = _G[ad .. "SubSpellName"] or btn.SubSpellName or btn.SpellSubName
	if isim and isim.GetText then
		local t = isim:GetText()
		local tr = t and G.buyuAdiCevir(t)
		if tr then G.sigdirKoy(isim, tr)
		elseif t and t ~= "" and not G.turkceMi(t) then G.kaydetDiger("buyuadi", t) end
	end
	if alt and alt.GetText then
		local tr = altCevir(alt:GetText())
		if tr then alt:SetText(tr) end
	end
end

local function hepsi()
	if not G.modul("buyuadi") then return end
	for i = 1, 12 do dugmeCevir(_G["SpellButton" .. i]) end
	if SpellBookTitleText and SpellBookTitleText.GetText then
		local t = SpellBookTitleText:GetText()
		if t == "Spellbook" then SpellBookTitleText:SetText("Büyü Kitabı") end
	end
	-- "Page 2" -> "Sayfa 2"
	if SpellBookPageText and SpellBookPageText.GetText then
		local n = (SpellBookPageText:GetText() or ""):match("^Page (%d+)$")
		if n then SpellBookPageText:SetText("Sayfa " .. n) end
	end
	-- "Show all spell ranks" kutusu
	for _, ad in ipairs({ "ShowAllSpellRanksCheckboxText", "ShowAllSpellRanksCheckBoxText" }) do
		local fs = _G[ad]
		if fs and fs.GetText and fs:GetText() == "Show all spell ranks" then fs:SetText("Tüm rütbeleri göster") end
	end
	local kutu = _G.ShowAllSpellRanksCheckbox or _G.ShowAllSpellRanksCheckBox
	if kutu and kutu.Text and kutu.Text.GetText and kutu.Text:GetText() == "Show all spell ranks" then
		kutu.Text:SetText("Tüm rütbeleri göster")
	end
end
G.buyuKitabiYenile = hepsi

G.dinle(function(k)
	-- Savaşta büyü kitabını (güvenli büyü düğmeleri) addon kodundan yenileme
	if (k == "buyuadi" or k == "acik") and SpellBookFrame and SpellBookFrame:IsShown() and SpellBookFrame_Update
		and not (InCombatLockdown and InCombatLockdown()) then
		SpellBookFrame_Update()
	end
end)

G.basla(function()
	if SpellButton_UpdateButton then hooksecurefunc("SpellButton_UpdateButton", dugmeCevir) end
	if SpellBookFrame_Update then hooksecurefunc("SpellBookFrame_Update", hepsi) end
	if SpellBookFrame then SpellBookFrame:HookScript("OnShow", function() C_Timer.After(0, hepsi) end) end
	-- Sekme ipuçları (General, Holy, Shadow...)
	for i = 1, 8 do
		local sekme = _G["SpellBookSkillLineTab" .. i]
		if sekme then
			sekme:HookScript("OnEnter", function(self)
				-- Dal başlıkları (Holy, Shadow Magic...) büyü adı ayarından bağımsız, her zaman Türkçe
				if not G.ayar("acik") then return end
				local fs = GameTooltipTextLeft1
				local t = fs and fs:GetText()
				local tr = t and G.BuyuSekme[t]
				if tr then fs:SetText(tr); GameTooltip:Show() end
			end)
		end
	end
end)

-- Meslek pencereleri (TradeSkillFrame, CraftFrame): tarif adları, malzemeler, açıklama ve gereksinimler
local function tarifCevir(fs)
	if not fs or not fs.GetText or not fs:IsShown() then return end
	local t = fs:GetText()
	if type(t) ~= "string" or t == "" or G.gizli(t) or G.turkceMi(t) then return end
	local bas, ad, son = t:match("^(%s*)(.-)(%s*%[%d+%])$")
	if not ad then bas, ad, son = t:match("^(%s*)(.-)(%s*)$") end
	local tr = ad and ad ~= "" and (G.isimCevir(ad) or (G.esyaAdiGoster and G.esyaAdiGoster(ad)))
	if not tr and ad and ad ~= "" and G.arayuzCevir then
		-- kategori başlıkları ("Smelted Bars"), araçlar vb.: arayüz sözlüğü; yoksa kayda al
		tr = G.arayuzCevir(ad) or G.gomuluCevir(ad)
		if (not tr or tr == ad) and ad:find("%a%a") and G.arayuzKaydet then pcall(G.arayuzKaydet, ad) end
	end
	if tr and tr ~= ad then G.sigdirKoy(fs, bas .. tr .. son) end
end
-- Meslek aletleri ve üretim yerleri ("Requires: Forge, Anvil")
local ALET = {
	["Forge"] = "Demirci Ocağı", ["Anvil"] = "Örs", ["Master Forge"] = "Usta Demirci Ocağı",
	["Cooking Fire"] = "Yemek Ateşi", ["Campfire"] = "Kamp Ateşi", ["Basic Campfire"] = "Basit Kamp Ateşi",
	["Moonwell"] = "Ay Kuyusu", ["Sharpening Wheel"] = "Bileme Çarkı", ["Alchemy Lab"] = "Simya Laboratuvarı",
	["Black Anvil"] = "Kara Örs", ["Black Forge"] = "Kara Demirci Ocağı", ["Lightforge"] = "Işık Ocağı",
}
local function parcaCevir(ad)
	return ALET[ad] or (G.esyaAdiGoster and G.esyaAdiGoster(ad)) or G.isimCevir(ad) or (G.arayuzCevir and G.arayuzCevir(ad))
end
-- "Requires: |cffff2020Forge|r, Anvil" -> "Gerekli: |cffff2020Demirci Ocağı|r, Örs"
-- Başta renk kodu olabilir: "|cffffd100Requires:|r |cffff2020Forge|r"
local function gerekCevir(t)
	local on, govde
	for _, k in ipairs({ "Requires:", "Requires", "Gerekli:", "Gerektirir:" }) do
		local a, b = t:find(k, 1, true)
		if a then
			local o = t:sub(1, a - 1)
			if o == "" or o:match("^|c%x%x%x%x%x%x%x%x$") then on, govde = o, t:sub(b + 1); break end
		end
	end
	if not govde then return nil end
	local kapat = ""
	local r, kalan = govde:match("^(|r)(.*)$")
	if r then kapat, govde = r, kalan end
	govde = govde:gsub("^%s+", "")
	if govde == "" then return nil end
	local parca, aletSay = {}, 0
	for p in (govde .. ", "):gmatch("(.-), ") do
		-- Sarmalayıcıları soy: renk |c..|r ve bağlantı |H..|h..|h ("|HSpellFocusRequirement|hForge|h")
		local on2, ic, son2 = "", p, ""
		for _ = 1, 4 do
			local a1, i1, z1 = ic:match("^(|c%x%x%x%x%x%x%x%x)(.-)(|r)$")
			if not a1 then a1, i1, z1 = ic:match("^(|H[^|]*|h)(.-)(|h)$") end
			if not a1 then break end
			on2, ic, son2 = on2 .. a1, i1, z1 .. son2
		end
		local x = parcaCevir(ic)
		if ALET[ic] then aletSay = aletSay + 1 end
		parca[#parca + 1] = on2 .. (x or ic) .. son2
	end
	return on .. "Gerekli:" .. kapat .. " " .. table.concat(parca, ", "), aletSay
end
G.meslekGerekCevir = gerekCevir
local function metinCevir(fs, gerekMi)
	if not fs or not fs.GetText then return end
	local t = fs:GetText()
	if type(t) ~= "string" or t == "" or G.gizli(t) then return end
	local tr
	if gerekMi then tr = gerekCevir(t) end
	if not tr then
		if G.turkceMi(t) then return end
		local Y = _G.WoWTurkceYeni
		tr = G.cevir(G.Buyu, t) or (Y and Y.BuyuSatirCevir and Y.BuyuSatirCevir(t)) or G.cevir(G.Esya, t)
			or (G.arayuzCevir and G.arayuzCevir(t)) or (G.hedefCevir and G.hedefCevir(t))
	end
	if tr and tr ~= t then G.asilKaydet(fs, tr); fs:SetText(tr) end
end
local function meslekCevir(onek, ad, malzeme, aciklama, gerek)
	if not G.modul("buyuadi") and not G.modul("arayuz") then return end
	for i = 1, 40 do tarifCevir(_G[onek .. i]) end
	tarifCevir(_G[ad])
	for i = 1, 8 do tarifCevir(_G[malzeme .. i .. "Name"]) end
	metinCevir(_G[aciklama]); metinCevir(_G[gerek], true)
end
-- Oyun gereksinim/açıklama yazısını her yenilediğinde anında çevir (titremeyi önler)
local kanca = {}
local function yaziKancasi(ad, gerekMi)
	local fs = _G[ad]
	if not fs or kanca[ad] or not fs.SetText then return end
	kanca[ad] = true
	local mesgul
	hooksecurefunc(fs, "SetText", function(self)
		if mesgul or not G.ayar("acik") then return end
		mesgul = true; pcall(metinCevir, self, gerekMi); mesgul = false
	end)
	if fs.SetFormattedText then
		hooksecurefunc(fs, "SetFormattedText", function(self)
			if mesgul or not G.ayar("acik") then return end
			mesgul = true; pcall(metinCevir, self, gerekMi); mesgul = false
		end)
	end
end
G.meslekYaziKancasi = yaziKancasi
local function tsCevir() pcall(meslekCevir, "TradeSkillSkill", "TradeSkillSkillName", "TradeSkillReagent", "TradeSkillDescription", "TradeSkillRequirementText") end
local function crCevir() pcall(meslekCevir, "Craft", "CraftName", "CraftReagent", "CraftDescription", "CraftRequirements") end
local kurulan = {}
local function meslekKur()
	if not kurulan.ts and _G.TradeSkillFrame_Update then
		kurulan.ts = true
		hooksecurefunc("TradeSkillFrame_Update", tsCevir)
		yaziKancasi("TradeSkillRequirementText", true); yaziKancasi("TradeSkillDescription")
		if _G.TradeSkillFrame_SetSelection then hooksecurefunc("TradeSkillFrame_SetSelection", tsCevir) end
	end
	if not kurulan.cr and _G.CraftFrame_Update then
		kurulan.cr = true
		hooksecurefunc("CraftFrame_Update", crCevir)
		yaziKancasi("CraftRequirements", true); yaziKancasi("CraftDescription")
		if _G.CraftFrame_SetSelection then hooksecurefunc("CraftFrame_SetSelection", crCevir) end
	end
end
-- Yeni meslek penceresi (ProfessionsFrame): tarif şemasındaki "Requires:" ve açıklama yazıları.
-- Oyun bunları sık sık yeniden yazıyor; her yazışta anında çevrilir (Forge <-> Demirci Ocağı titremesi olmasın).
local semaKurulan = setmetatable({}, { __mode = "k" })
local function semaKancasi(form)
	if type(form) ~= "table" or semaKurulan[form] then return end
	semaKurulan[form] = true
	local function kanca(fs, gerekMi)
		if type(fs) ~= "table" or not fs.SetText then return end
		local mesgul
		local function isle(self)
			if mesgul or not G.ayar("acik") then return end
			mesgul = true; pcall(metinCevir, self, gerekMi); mesgul = false
		end
		hooksecurefunc(fs, "SetText", isle)
		if fs.SetFormattedText then hooksecurefunc(fs, "SetFormattedText", isle) end
		pcall(isle, fs)
	end
	kanca(form.RequiredTools, true)
	kanca(form.Description)
	-- Başka bir yer (arayüz taraması vb.) kancayı atlayıp yazarsa: her karede denetle, gerekirse düzelt
	local son = {}
	if form.HookScript then
		form:HookScript("OnUpdate", function()
			if not G.ayar("acik") then return end
			for fs, gerekMi in pairs({ [form.RequiredTools or false] = true, [form.Description or false] = false }) do
				if fs then
					local ok, t = pcall(fs.GetText, fs)
					if ok and type(t) == "string" and not G.gizli(t) and t ~= son[fs] then
						pcall(metinCevir, fs, gerekMi)
						local ok2, t2 = pcall(fs.GetText, fs)
						son[fs] = ok2 and t2 or t
						if gerekMi then
							WoWTurkce_Ayar = WoWTurkce_Ayar or {}
							local T = WoWTurkce_Ayar._meslekTani or {}
							WoWTurkce_Ayar._meslekTani = T
							if #T < 20 then T[#T + 1] = { ham = t, sonuc = son[fs] } end
						end
					end
				end
			end
		end)
	end
	if form.RecraftingRequiredTools then kanca(form.RecraftingRequiredTools, true) end
end
local function semalariBul()
	local PF = rawget(_G, "ProfessionsFrame")
	if PF and PF.CraftingPage and PF.CraftingPage.SchematicForm then semaKancasi(PF.CraftingPage.SchematicForm) end
	local OF = rawget(_G, "ProfessionsCustomerOrdersFrame")
	if OF and OF.Form then semaKancasi(OF.Form) end
end
G.meslekSemaBul = semalariBul
-- Hangi pencere olursa olsun: "Requires: ..." ile başlayan her yazı anında "Gerekli: ..." olur.
-- (Forever'ın meslek penceresi beklenen adla bulunamadığında da çalışır.) Tüm yazı nesnelerinin SetText'ine
-- tek bir hafif kanca: yalnızca başı "Requires" olan yazılarda iş yapar.
do
	local ornek = UIParent:CreateFontString()
	local mt = getmetatable(ornek)
	local idx = mt and mt.__index
	local mesgul
	local function yolu(fs)
		local p, k, ad = fs, 0, {}
		while p and k < 6 do
			local n = p.GetName and p:GetName()
			ad[#ad + 1] = n or (p.GetParentKey and p:GetParentKey()) or "?"
			p = p.GetParent and p:GetParent(); k = k + 1
		end
		return table.concat(ad, " < ")
	end
	if type(idx) == "table" and idx.SetText then
		hooksecurefunc(idx, "SetText", function(fs, t)
			if mesgul or type(t) ~= "string" or G.gizli(t) then return end
			local b = t:byte(1)
			if b ~= 82 and b ~= 124 and b ~= 71 then return end -- "R", "G" ya da "|"
			if not (t:find("^Requires") or t:find("^|c%x%x%x%x%x%x%x%xRequires") or t:find("^Gerekli:") or t:find("^|c%x%x%x%x%x%x%x%xGerekli:")) then return end
			if not t:find("Forge", 1, true) and not t:find("Anvil", 1, true) and not t:find("Fire", 1, true) and not t:find("Moonwell", 1, true) and not t:find("Wheel", 1, true) and not t:find("Lab", 1, true) then return end
			if not G.ayar("acik") then return end
			local tr, aletSay = gerekCevir(t)
			if tr and tr ~= t and (aletSay or 0) > 0 then
				mesgul = true
				pcall(G.asilKaydet, fs, tr)
				pcall(fs.SetText, fs, tr)
				mesgul = false
				WoWTurkce_Ayar = WoWTurkce_Ayar or {}
				local T = WoWTurkce_Ayar._meslekTani or {}
				WoWTurkce_Ayar._meslekTani = T
				if #T < 10 then local ok, y = pcall(yolu, fs); T[#T + 1] = { ham = t, sonuc = tr, yol = ok and y or "?" } end
			end
		end)
	end
end
local mk = CreateFrame("Frame")
mk:RegisterEvent("ADDON_LOADED")
mk:RegisterEvent("PLAYER_LOGIN")
mk:SetScript("OnEvent", function() meslekKur(); pcall(semalariBul) end)
G.dinle(function(k)
	if k == "acik" or k == "buyuadi" or k == "arayuz" then
		if TradeSkillFrame and TradeSkillFrame:IsShown() and TradeSkillFrame_Update then TradeSkillFrame_Update() end
		if CraftFrame and CraftFrame:IsShown() and CraftFrame_Update then CraftFrame_Update() end
	end
end)
