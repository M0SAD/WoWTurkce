local _, addon = ...;

local format = _G.format;

local Utils = addon.import('Core/Utils');
local SlashCommands = addon.import('Core/SlashCommands');

local module = addon.export('Core/HelpCommands', {});

local helpers = {};

local function addHelper(command, callback)
  helpers[command] = callback;
end

function module.addHelper(commands, callback)
  if (type(commands) == 'table') then
    for _, command in ipairs(commands) do
      addHelper(command, callback);
    end
  else
    addHelper(commands, callback);
  end
end

local function printAvailableHelpers ()
  Utils.printTableKeys(helpers);
end

SlashCommands.addCommand('help', function (command, ...)
  if (command == nil) then
    Utils.printAddonMessage('Şu komutlar için yardım mevcut:');
    printAvailableHelpers();
    return;
  end

  local helper = helpers[command];

  if (helper == nil) then
    Utils.printAddonMessage(format('%s komutu için yardım bulunamadı. Şu komutlar için yardım mevcut:'), command);
    printAvailableHelpers();
    return;
  end

  if (type(helper) == 'function') then
    helper(...);
  else
    Utils.printAddonMessage(helper);
  end
end);
