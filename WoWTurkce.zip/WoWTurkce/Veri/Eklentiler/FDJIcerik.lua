-- ForeverDungeonJournal görev ve rehber metinleri (Türkçe). Ozellikler/DungeonJournal.lua kullanır.
local G = WoWTurkce
local Q, P, D = {}, {}, {}
G.FDJIcerik = { quests = Q, places = P, dungeons = D }
Q[-96902] = { name = "Cadı Doktorun Kafası", objective = "Witch Doctor Zum'rah'ı öldür ve Zum'rah'ın Kafası'nı Dalaran'daki Archmage Lan'dalock'a getir." }
Q[-96901] = { name = "Coldbringer'ın Gözü", note = "Görev veren henüz doğrulanmadı: Archmage Lan'dalock'a teslim edilir.", objective = "Coldbringer'ın Gözü'nü Razorfen Downs'tan geri al." }
Q[17] = { name = "Uldaman Malzeme Seferi", objective = "Thelsamar'daki Ghak Healtouch'a 12 Macenta Mantar Şapkası getir." }
Q[65] = { description = "Gerekli Defias Brotherhood zincirinin ilk adımı.", name = "Defias Kardeşliği", objective = "Gryan Stoutmantle, Lakeshire'daki Wiley ile konuşmanı istiyor." }
Q[132] = { description = "Defias Brotherhood zincirinin ikinci adımı.", name = "Defias Kardeşliği", objective = "Wiley'nin Notunu Westfall'daki Gryan Stoutmantle'a götür." }
Q[135] = { description = "Shaw, Defias ile Taş Ustaları arasındaki bağlantıyı araştırıyor.", name = "Defias Kardeşliği", objective = "Wiley'nin Notunu Stormwind'deki Mathias Shaw'a götür." }
Q[141] = { description = "Shaw'ın Edwin VanCleef hakkındaki bulgularını Gryan'a geri götürür.", name = "Defias Kardeşliği", objective = "Shaw'ın raporunu Westfall'daki Gryan Stoutmantle'a götür." }
Q[142] = { description = "Ulak, Moonbrook, Gold Coast Quarry ve Jangolode Mine arasındaki yollarda dolaşır.", name = "Defias Kardeşliği", note = "Defias Messenger, Moonbrook, Gold Coast Quarry ve Jangolode Mine arasındaki yollarda devriye gezer.", objective = "Westfall'daki Defias Ulağını bul ve mesajını Stoutmantle'a getir." }
Q[153] = { description = "Red Silk Bandanas öncesi gerekli.", objective = "15 Kırmızı Deri Bandanayı Sentinel Hill'deki Scout Galiaan'a getir." }
Q[155] = { description = "The Defias Brotherhood'un zindan adımı öncesi son ön koşul.", name = "Defias Kardeşliği", objective = "Defias Hainine Defias Kardeşliği'nin gizli sığınağına kadar eşlik et. Defias Haini sana VanCleef ve adamlarının nerede saklandığını gösterince bilgiyle Gryan Stoutmantle'a dön." }
Q[166] = { name = "Defias Kardeşliği", note = "Defias Brotherhood zincirinin son zindan adımı; önce önceki adımları tamamla.", objective = "Edwin VanCleef'i öldür ve kellesini Gryan Stoutmantle'a getir.", pickup = "Gryan Stoutmantle, Sentinel Hill kulesi, Westfall (56.4, 47.5)" }
Q[167] = { name = "Ah Kardeşim...", note = "Ustabaşı, zindan portalından önceki tünellerde.", objective = "Ustabaşı Thistlenettle'ın Explorers' League Rozeti'ni Stormwind'deki Wilder Thistlenettle'a getir." }
Q[168] = { name = "Anıları Toplamak", note = "Undead yan tüneli zindan portalından önce.", objective = "4 Madenciler Sendikası Kartı bul ve Stormwind'deki Wilder Thistlenettle'a geri getir." }
Q[214] = { name = "Kırmızı İpek Bandanalar", note = "Defias Brotherhood eskort adımı gerekir.", objective = "Sentinel Hill Kulesi'ndeki Gözcü Riell, kendisine 10 Kırmızı İpek Bandana getirmeni istiyor.", pickup = "Scout Riell, Sentinel Hill kulesi, Westfall", turnin = "Scout Riell, Sentinel Hill kulesi, Westfall" }
Q[261] = { name = "Kızıl Yol", objective = "30 Undead Ravager yok et, sonra Nijel's Point'teki Brother Anton'a dön." }
Q[275] = { description = "Horrors in the Highland öncesi gerekli son adım.", name = "Topraktaki Kabarcıklar", objective = "8 Fen Creeper öldür, sonra Wetlands'teki Rethiel the Greenwarden'a dön." }
Q[276] = { description = "Horrors in the Highland öncesi gerekli ikinci adım.", name = "Ezen Pençeler", objective = "15 Mosshide Gnoll ve 10 Mosshide Mongrel öldür, sonra Wetlands'teki Rethiel the Greenwarden'a dön." }
Q[277] = { description = "Horrors in the Highland öncesi gerekli üçüncü adım.", name = "Ateş Yasağı", objective = "Rethiel the Greenwarden'a 9 Kaba Çakmaktaşı getir." }
Q[303] = { description = "The Fury Runs Deep'i açmak için The Dark Iron War'u tamamla.", name = "Kara Demir Savaşı", objective = "Dun Modr'daki Motley Garmason 10 Dark Iron Dwarf, 5 Dark Iron Tunneler, 5 Dark Iron Saboteur ve 5 Dark Iron Demolitionist öldürmeni istiyor." }
Q[356] = { description = "İkisi de Linnea'nın kampının doğusundaki Balnir Farmstead'de.", name = "Artçı Devriyesi", objective = "8 Bleeding Horror ve 8 Wandering Spirit öldür, sonra kampındaki Linnea'ya rapor ver.", pickup = "Deathguard Linnea, Brill'in güneydoğusundaki kamp, Tirisfal Glades", turnin = "Deathguard Linnea, Brill'in güneydoğusundaki kamp, Tirisfal Glades" }
Q[373] = { description = "The Stockade Riots görevine götüren gerekli ilk adım.", name = "Gönderilmemiş Mektup", note = "Bazil Thredd ile devam eden bir zincir başlatır.", objective = "Şehir Mimarına Mektup'u Stormwind'deki Baros Alexston'a teslim et.", pickup = "Edwin VanCleef'ten alınan An Unsent Letter'ı kullan." }
Q[377] = { name = "Suç ve Ceza", objective = "Darkshire'dan Meclis Üyesi Millstipe, Dextren Ward'ın elini kendisine getirmeni istiyor." }
Q[378] = { name = "Öfke Derinlerde", note = "Bu görevin açılması için önce The Dark Iron War gerekir.", objective = "Motley Garmason, Kam Deepfury'nin kellesinin Dun Modr'da kendisine getirilmesini istiyor." }
Q[386] = { name = "Ne Ekersen...", objective = "Dehşet Targorr'un kafasını Lakeshire'daki Muhafız Berton'a getir." }
Q[387] = { name = "İsyanı Bastır", objective = "Stormwind'den Gardiyan Thelwater, The Stockade'de 10 Defias Mahkûmu, 8 Defias Hükümlüsü ve 8 Defias Asisi öldürmeni istiyor.", pickup = "Warden Thelwater, The Stockade'in dışında, Stormwind", turnin = "Warden Thelwater, The Stockade'in dışında, Stormwind" }
Q[388] = { name = "Kanın Rengi", objective = "Stormwind'den Nikova Raskol, 10 Kırmızı Yün Bandana toplamanı istiyor." }
Q[389] = { description = "The Stockade Riots görevine götüren ikinci gerekli adım.", name = "Bazil Thredd", objective = "Stockade'deki Gardiyan Thelwater ile konuş.", turnin = "Warden Thelwater, The Stockade'in dışında, Stormwind" }
Q[391] = { name = "Stockade İsyanı", note = "The Deadmines'ta Edwin VanCleef'ten gelen The Unsent Letter ile başlayan zincirin parçası.", objective = "Bazil Thredd'i öldür ve kellesini Stockade'deki Gardiyan Thelwater'a getir.", pickup = "Warden Thelwater, The Stockade'in dışında, Stormwind", turnin = "Warden Thelwater, The Stockade'in dışında, Stormwind" }
Q[447] = { name = "Ölümün Tarifi", objective = "6 Boz Ayı Kalbi ve 6 Skittering Kanı örneği topla ve Undercity'deki Master Apothecary Faranell'e teslim et." }
Q[450] = { name = "Ölümün Tarifi", objective = "Apothecary Berard'ın günlüğünü Pyrewood Village'dan al ve Sepulcher'daki Apothecary Renferrel'e götür.", warning = "Grup görevi: han, düşman köylülerin arasında, Pyrewood Village'da." }
Q[451] = { name = "Ölümün Tarifi", objective = "Undercity'deki Master Apothecary Faranell'e 6 Lake Creeper Yosunu örneği, 6 Lake Skulker Yosunu örneği ve bir Sertleşmiş Tümör getir." }
Q[463] = { description = "Horrors in the Highland öncesi gerekli ilk adım.", name = "Greenwarden", objective = "Greenwarden'ı bul." }
Q[484] = { description = "Highland Hides öncesi gerekli. Forever'da Daily Delivery gerekli değil.", name = "Genç Timsah Derileri", objective = "Menethil Harbor'daki James Halloran için 4 Genç Timsah Derisi edin." }
Q[544] = { name = "Hapishaneye Sızma", note = "Aynı anda Magus Wordeen Voidglare'den Key to the City görevini de al.", objective = "Hainleri bul ve eserlerini geri al, sonra Tarren Mill'deki Magus Voidglare'e dön." }
Q[545] = { description = "Prison Break In tamamlandıktan sonra alınabilir.", name = "Dalaran Devriyeleri", objective = "6 Dalaran Summoner ve 12 Elemental Slave öldür, sonra Tarren Mill'deki Magus Voidglare'e dön." }
Q[629] = { name = "Vile Reef", objective = "Grom'gol Üssü'ndeki Kin'weelay'e bir Tablet Parçası getir.", warning = "Grup görevi: Vile Reef'teki Saltscale murlocları elit." }
Q[704] = { name = "Agmond'un Akıbeti", note = "Küpler, zindan portalından önce, dış Uldaman mağarasında.\n\nİsteğe bağlı giriş görevi:", objective = "Loch Modan'daki Kâşif Ironband'e 4 Oyma Taş Kavanoz getir." }
Q[707] = { name = "Ironband Seni İstiyor!", note = "Agmond's Fate görevine götüren giriş adımı.", objective = "Loch Modan'daki Ironband Kazı Alanı'nda Maden Arayıcısı Ironband ile konuş.", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[709] = { name = "Kıyamete Çare", objective = "Ryun'eh Tableti'ni Kayıp Theldurin'e getir." }
Q[720] = { name = "Bir Umut İşareti", objective = "Maden Arayıcı Ryedol'u bul ve ona Hammertoe Grez'in hayatta olduğunu bildir." }
Q[721] = { name = "Bir Umut Işığı", objective = "Uldaman'da Hammertoe Grez'i bul." }
Q[722] = { name = "Sırlar Muskası", objective = "Hammertoe'nun Muskası'nı bul ve Uldaman'da ona geri götür.", pickup = "Hammertoe Grez, Uldaman kazısı (zindanın dışında)", turnin = "Hammertoe Grez, Uldaman kazısı (zindanın dışında)" }
Q[723] = { name = "İnanç Arayışı", objective = "Hammertoe'nun Muskasını Badlands'teki Maden Arayıcı Ryedol'a götür." }
Q[724] = { name = "İnanç Arayışı", objective = "Hammertoe'nun Muskasını Ironforge'daki Tarihçi Karnik'e götür." }
Q[725] = { name = "Tehdit Haberini İletmek", objective = "Danışman Belgrum'u bul ve notunu ona ver." }
Q[726] = { name = "Tehdit Haberini İletmek", objective = "Tarihçi Karnik ile konuş." }
Q[738] = { name = "Agmond'u Bul", objective = "Agmond'u bul." }
Q[739] = { name = "Murdaloc", objective = "Agmond'un katili Murdaloc'u öldür.$B$B12 Stonevault Bonesnapper öldür.$B$BLoch Modan'daki Maden Arayıcı Ironband'e rapor ver." }
Q[762] = { name = "Bir Kötülük Elçisi", objective = "Angor Fortress'ta Ambassador Infernus'u öldür ve ölümünün kanıtını Ironforge'daki Danışman Belgrum'a getir." }
Q[865] = { description = "Smart Drinks açılmadan önce gerekli.", name = "Raptor Boynuzları", objective = "Sunscale Scytheclaw'lardan 5 Sağlam Raptor Boynuzu topla ve Ratchet'teki Mebok Mizzyrix'e getir." }
Q[870] = { description = "Forgotten Pools'un altındaki yarığı araştır.", name = "Unutulmuş Havuzlar", objective = "Bulduklarınla Tonga Runetotem'e rapor ver." }
Q[877] = { description = "The Forgotten Pools'tan sonraki gerekli vaha araştırması.", name = "Durgun Vaha", objective = "Stagnant Oasis'i araştırdıktan sonra Crossroads'taki Tonga'ya dön." }
Q[880] = { description = "Altered Beings'i tamamlamak Hamuul Runetotem'i açar.", name = "Değişmiş Varlıklar", objective = "Crossroads'taki Tonga Runetotem'e 8 Değişmiş Snapjaw Kabuğu getir." }
Q[914] = { name = "Diş'in Önderleri", note = "Barrens vaha görev zinciri gerekir. Leaders of the Fang açılmadan önce The Barrens Oases, The Forgotten Pools, The Stagnant Oasis ve Altered Beings'i, ardından Hamuul Runetotem ve Nara Wildmane'i tamamla.", objective = "Cobrahn, Anacondra, Pythas ve Serpentis'in Mücevherleri'ni Thunder Bluff'taki Nara Wildmane'e getir." }
Q[959] = { name = "Rıhtımda Sorun", objective = "Ratchet'taki Vinç Operatörü Bigglefuzz, Wailing Caverns'ta saklanan Mad Magglish'ten 99 Yıllık Porto şişesini geri almanı istiyor." }
Q[962] = { name = "Yılançiçeği", objective = "Thunder Bluff'taki Simyacı Zamah 10 Yılançiçeği toplamanı istiyor." }
Q[971] = { name = "Derinliklerdeki Bilgi", note = "Lorgalis Elyazması, Ghamoo-ra'nın kaplumbağa odasını hemen geçince kuzey girintide, Pool of Ask'ar'da su altındaki bir Oyuk Demir Sandık'ın içinde.", objective = "Lorgalis El Yazması'nı Ironforge'daki Forlorn Cavern'da bulunan Gerrig Bonegrip'e götür.", pickup = "Gerrig Bonegrip, Forlorn Cavern, Ironforge (50.8, 5.6)" }
Q[1013] = { name = "Ur'un Kitabı", objective = "Ur'un Kitabı'nı Undercity'deki Apothecarium'da bulunan Muhafız Bel'dugur'a getir." }
Q[1014] = { name = "Arugal Ölmeli", note = "Güncel Forever görev verisi ödül olarak öğrenilen Arcane Intellect'i de listeliyor.", objective = "Arugal'ı öldür ve kellesini Sepulcher'daki Dalar Dawnweaver'a getir." }
Q[1048] = { name = "Scarlet Monastery'ye", note = "Herod Armory'de; Loksey Library'de; Mograine ve Whitemane Cathedral'da.", objective = "Yüce Engizitör Whitemane'i, Kızıl Komutan Mograine'i, Kızıl Şampiyon Herod'u ve Tazı Ustası Loksey'i öldür, ardından Undercity'deki Varimathras'a rapor ver." }
Q[1049] = { name = "Düşmüşlerin Derlemesi", objective = "Tirisfal Glades'teki Manastır'dan Düşmüşlerin Derlemesi'ni al ve Thunder Bluff'taki Bilge Truthseeker'a dön.", warning = "Undead'ler bu görevi alamaz" }
Q[1050] = { name = "Titanların Mitolojisi", objective = "Manastır'dan Titanların Mitolojisi'ni al ve Ironforge'daki Kütüphaneci Mae Paledust'a getir." }
Q[1051] = { name = "Vorrel'in İntikamı", objective = "Vorrel Sengutz'un alyansını Tarren Mill'deki Monika Sengutz'a geri götür.", pickup = "Vorrel Sengutz, Graveyard içinde" }
Q[1052] = { name = "Kızıl Yol", objective = "Brother Anton'un Takdir Mektubunu Southshore'daki Dindar Raleigh'e götür." }
Q[1053] = { name = "Işık Adına", note = "Herod Armory'de; Loksey Library'de; Mograine ve Whitemane Cathedral'da.\n\nİsteğe bağlı giriş görevi:", objective = "Yüce Engizitör Whitemane'i, Kızıl Komutan Mograine'i, Kızıl Şampiyon Herod'u ve Tazı Ustası Loksey'i öldür, ardından Southshore'daki Dindar Raleigh'e rapor ver." }
Q[1098] = { name = "Shadowfang'deki Ölüm Avcıları", objective = "Ölüm Avcısı Adamant ile Ölüm Avcısı Vincent'ı bul.", turnin = "Deathstalker Vincent, Shadowfang Keep içinde" }
Q[1100] = { description = "The Crone of the Kraul öncesi gerekli.", name = "Lonebrow'un Günlüğü", objective = "Henrig Lonebrow'un Günlüğünü oku.", pickup = "Henrig Lonebrow'un Günlüğü, Great Lift'in dibinde cesedinin yanında" }
Q[1101] = { name = "Kraul'un Cadısı", objective = "Razorflank'in Madalyonu'nu Thalanaar'daki Falfindel Waywarder'a getir." }
Q[1102] = { name = "İntikamcı Bir Kader", objective = "Razorflank'in Kalbi'ni Thunder Bluff'taki Auld Stonespire'a getir." }
Q[1109] = { description = "Hearts of Zeal öncesi gerekli.", name = "Ver Elini Gübre!", objective = "Undercity'deki Usta Eczacı Faranell'e 1 yığın Kraul Gübresi getir." }
Q[1113] = { name = "Bağnazlık Yürekleri", note = "Manastır genelinde toplama: Cathedral'a giden yoldaki herhangi bir Scarlet insansısı Şevk Kalbi düşürebilir.", objective = "Undercity'deki Baş Simyacı Faranell 20 Bağnazlık Yüreği istiyor." }
Q[1139] = { name = "Kayıp İrade Tabletleri", objective = "İrade Tableti'ni bul ve Ironforge'daki Danışman Belgrum'a getir." }
Q[1142] = { name = "Can Çekişen", objective = "Treshala'nın Kolyesi'ni bul ve Darnassus'taki Treshala Fallowbrook'a geri götür.", pickup = "Heralath Fallowbrook, Razorfen Kraul içinde" }
Q[1144] = { name = "İthalatçı Willix", objective = "İthalatçı Willix'e Razorfen Kraul'dan çıkana kadar eşlik et.", pickup = "Willix the Importer, Razorfen Kraul içinde", turnin = "Willix the Importer, Razorfen Kraul içinde" }
Q[1149] = { name = "İnanç Sınavı", objective = "İnancın varsa Thousand Needles'a bakan kalaslardan atla." }
Q[1150] = { name = "Dayanıklılık Sınavı", objective = "Grenka'nın Pençesini Thousand Needles'taki Dorn Plainstalker'a getir." }
Q[1151] = { name = "Güç Sınavı", objective = "Rok'Alim'in Parçalarını Thousand Needles'taki Dorn Plainstalker'a getir." }
Q[1152] = { name = "Bilgi Sınavı", objective = "Stonetalon Mountains'ta Talondeep Path girişi yakınındaki Braug Dimspirit'i bul." }
Q[1154] = { name = "Bilgi Sınavı", objective = "Legacy of the Aspects'i bul ve Stonetalon Mountains'ta Talondeep Path girişi yakınındaki Braug Dimspirit'e getir." }
Q[1159] = { name = "Bilgi Sınavı", objective = "Undercity'deki Parqual Fintallas'ı bul." }
Q[1160] = { description = "Kitap Scarlet Monastery: Library içinde.", name = "Bilgi Sınavı", objective = "Ölümsüz Tehdidin Başlangıcı'nı bul ve Undercity'deki Parqual Fintallas'a getir." }
Q[1198] = { description = "Blackfathom Villainy'nin Alliance sürümü öncesi gerekli.", name = "Thaelrid'in Peşinde", objective = "Blackfathom Deeps'te Argent Muhafızı Thaelrid'i bul.", turnin = "Argent Guard Thaelrid, Blackfathom Deeps içinde" }
Q[1199] = { name = "Alacakaranlığın Düşüşü", objective = "10 Alacakaranlık Kolyesi'ni Darnassus'taki Argent Muhafızı Manados'a götür.", pickup = "Argent Guard Manados, Craftsmen's Terrace, Darnassus (55, 24)" }
Q[1200] = { name = "Blackfathom'un Kötülüğü", objective = "Alacakaranlık Lordu Kelris'in başını Darnassus'taki Şafak Gözcüsü Selgorm'a götür.", pickup = "Argent Guard Thaelrid, Blackfathom Deeps içinde" }
Q[1221] = { name = "Mavi Yaprak Yumruları", objective = "Bir Delikli Sandık al.$BBir Snufflenose Komuta Çubuğu al.$BSnufflenose Kullanım Kılavuzu'nu al ve oku.$B$BRazorfen Kraul'da Delikli Sandık'ı kullanarak bir Snufflenose Sincabı çağır, sonra Komuta Çubuğu'nu sincabın üzerinde kullanarak Yumru aramasını sağla.$B$B6 Mavi Yaprak Yumrusu'nu, Snufflenose Komuta Çubuğu'nu ve Delikli Sandık'ı Ratchet'taki Mebok Mizzyrix'e getir." }
Q[1275] = { name = "Yozlaşmayı Araştırmak", note = "İsteğe bağlı giriş görevi:", objective = "Auberdine'daki Gershala Nightwhisper 8 Yozlaşmış Beyin Sapı istiyor.", pickup = "Gershala Nightwhisper, Auberdine, Darkshore (38.3, 43.1)" }
Q[1360] = { name = "Geri Alınan Hazineler", objective = "Uldaman'ın Kuzey Ortak Salonu'ndaki sandığından Krom Stoutarm'ın değerli varlığını al ve Ironforge'da ona getir." }
Q[1394] = { name = "Son Geçit", objective = "Thousand Needles'taki Dorn Plainstalker ile konuş.", warning = "Bu, bir adımı Library'de olan uzun bir zincir" }
Q[1424] = { name = "Gözyaşı Havuzu", objective = "Stonard'daki Fel'zerul 10 Atal'ai Eseri toplamanı istiyor." }
Q[1429] = { name = "Atal'ai Sürgünü", objective = "Atal'ai Eserleri Bohçasını Hinterlands'teki Atal'ai Exile'a götür." }
Q[1444] = { name = "Fel'Zerul'a Dönüş", objective = "Stonard'daki Fel'Zerul'a dön." }
Q[1445] = { name = "Temple of Atal'Hakkar", note = "Atal'ai trollerinden 20 Hakkar Fetişi topla; dış tapınaktaki troller de düşürür.", objective = "20 Hakkar Fetişi topla ve Stonard'daki Fel'Zerul'a getir." }
Q[1446] = { name = "Kâhin Jammal'an", note = "Jammal'an'ın bariyerini düşürmek için balkonlardaki altı trol muhafızını öldür, sonra kafasını geri getir.", objective = "The Hinterlands'teki Atal'ai Sürgünü, Jammal'an'ın Başı'nı istiyor." }
Q[1448] = { name = "Tapınağın Peşinde", objective = "Stormwind'deki Brohann Caskbelly senden Temple of Atal'Hakkar'ı aramanı istiyor." }
Q[1449] = { name = "Hinterlands'e", objective = "Hinterlands'deki Aerie Peak'te Yüce Thane Falstad Wildhammer ile konuş." }
Q[1450] = { name = "Grifon Ustası Talonaxe", objective = "Aerie Peak Kuşhanesi'nin içindeki Grifon Ustası Talonaxe ile konuş." }
Q[1451] = { name = "Rhapsody Shindigger", objective = "Hinterlands'de Rhapsody Shindigger'ı bul." }
Q[1452] = { name = "Rhapsody'nin Kalimdor Kokteyli", objective = "Hinterlands'deki Rhapsody Shindigger ona 3 Roc Taşlığı, 3 Groddoc Ciğeri ve 3 Ironfur Ciğeri getirmeni istiyor." }
Q[1469] = { name = "Rhapsody'nin Hikâyesi", objective = "Atal'ai Tablet Parçası'nı Stormwind'deki Brohann Caskbelly'ye götür." }
Q[1475] = { name = "Temple of Atal'Hakkar'a Giriş", note = "Tapınağın çevresinden 10 Atal'ai Tableti topla; dış tapınaktaki tabletler de sayılır.", objective = "Stormwind'deki Brohann Caskbelly için 10 Atal'ai Tableti topla." }
Q[1486] = { name = "Sapkın Postlar", objective = "Wailing Caverns'taki Nalpak 20 Sapkın Post istiyor.", pickup = "Nalpak, Wailing Caverns girişinin üstünde, The Barrens", turnin = "Nalpak, Wailing Caverns girişinin üstünde, The Barrens" }
Q[1487] = { name = "Sapkınların Kökünü Kazımak", objective = "Wailing Caverns'taki Ebru senden 7 Sapkın Yağmacı, 7 Sapkın Engerek, 7 Sapkın Sendeleyen ve 7 Sapkın Dehşetdiş öldürmeni istiyor.", pickup = "Ebru, Wailing Caverns girişinin üstünde, The Barrens", turnin = "Ebru, Wailing Caverns girişinin üstünde, The Barrens" }
Q[1489] = { description = "Tonga, Altered Beings'ten sonra seni Hamuul'a gönderir.", name = "Hamuul Runetotem", objective = "Hamuul Runetotem ile konuş." }
Q[1490] = { description = "Nara Wildmane, Leaders of the Fang açılmadan önceki son ön koşul.", name = "Nara Wildmane", objective = "Nara Wildmane ile konuş." }
Q[1491] = { name = "Zekâ İksirleri", objective = "Ratchet'taki Mebok Mizzyrix'e 6 porsiyon Ağıt Özü getir." }
Q[1651] = { name = "Yiğitlik Kitabı", objective = "Daphne Stilwell'i Defias saldırısından koru.$B$BBaşarmak istiyorsan ikinizin de ruhu ölümlü bedeninden ayrılmamalı.$B$BBaşardıktan sonra Daphne Stilwell ile tekrar konuş." }
Q[1652] = { name = "Yiğitlik Kitabı", objective = "Stormwind'deki Duthorian Rall ile konuş." }
Q[1653] = { name = "Doğruluk Sınavı", objective = "Ironforge'daki Jordan Stilwell ile konuş" }
Q[1654] = { name = "Doğruluk Sınavı", objective = "Jordan'ın Silah Notlarını kullanarak biraz Whitestone Meşe Kerestesi, Bailor'ın Arıtılmış Cevher Sevkiyatı, Jordan'ın Demirci Çekici ve bir Kor Taşı bul ve Ironforge'daki Jordan Stilwell'e getir." }
Q[1740] = { name = "Soran'ruk Küresi", note = "Warlock sınıf görevi. Parçalar Shadowfang Keep ve Blackfathom Deeps'ten gelir.", objective = "3 Soran'ruk Parçası ve 1 Büyük Soran'ruk Parçası bul ve bunları Barrens'taki Doan Karhan'a geri getir." }
Q[1806] = { description = "Son adım. Ödül: Verigan's Fist.", name = "Doğruluk Sınavı", note = "İnsanlar ve cüceler için Paladin sınıf görevi. Bu zindanda: Whitestone Meşe Kerestesi Goblin Woodcarver'lardan düşer. Diğer parçalar Jordan's Smithing Hammer (Shadowfang Keep), Kor Gem (Blackfathom Deeps) ve Jordan'ın cevher sevkiyatı (Loch Modan).", objective = "Jordan Stilwell'in senin için bir silah dövmeyi bitirmesini bekle.", warning = "Bu, bir adımı The Deadmines'ta olan bir zincir görev" }
Q[1954] = { name = "Cehennem Küresi", objective = "Dustwallow Marsh'taki Tabetha'ya bir Cehennem Küresi götür." }
Q[1955] = { name = "Kovma Ayini", objective = "Küre İblisi'ni öldür, sonra Tabetha ile konuş." }
Q[1956] = { name = "Uldaman'daki Güç", note = "Mage sınıf görevi. Obsidian Sentinel, Uldaman'ın arka girişini korur. Celestial Orb veya Celestial Stave için Mana Surges ile devam eder.", objective = "Bir Obsidyen Güç Kaynağı elde et ve onu Dustwallow Marsh'taki Tabetha'ya götür." }
Q[2040] = { name = "Yeraltı Saldırısı", note = "Speak with Shoni görevinden sonra gelir.", objective = "Deadmines'tan Gnoam Sprecklesprocket'ı al ve Stormwind'deki Sessiz Shoni'ye geri götür." }
Q[2041] = { description = "Bu, doğrudan Underground Assault görevine götürür.", objective = "Stormwind'deki Sessiz Shoni ile konuş." }
Q[2198] = { name = "Parçalanmış Kolye", objective = "Parçalanmış kolyenin olası değerini öğrenmek için asıl yapımcısını ara.", pickup = "Parçalanmış Kolye (Uldaman'da düşer)" }
Q[2199] = { name = "Bedeli Olan Bilgi", objective = "Ironforge'daki Talvash del Kissel'e beş gümüş külçe getir." }
Q[2200] = { name = "Uldaman'a Dönüş", objective = "Uldaman'da Talvash'ın kolyesinin şu anki durumuna dair ipuçları ara. Bahsettiği öldürülmüş paladin kolyeye en son sahip olan kişiydi." }
Q[2201] = { name = "Mücevherleri Bul", note = "Safir Grimlok'tan düşer.", objective = "Uldaman'ın dört bir yanına dağılmış yakutu, safiri ve topazı bul. Hepsini aldıktan sonra Talvash del Kissel'in sana daha önce verdiği Kâhinlik Şişesi'ni kullanarak onunla uzaktan iletişim kur.$B$BGünlükten bildiğin kadarıyla...$B* Yakut, barikatlı bir Shadowforge bölgesine saklanmış.$B* Topaz, Trogg bölgelerinden birinde, birkaç İttifak dwarf'ının yakınındaki bir kavanoza gizlenmiş.$B$B* Safiri trogg lideri Grimlok sahiplenmiş.", turnin = "Talvash del Kissel (Kehanet Şişesi)" }
Q[2202] = { name = "Uldaman Malzeme Seferi", objective = "Kargath'taki Jarkal Mossmeld'e 12 Macenta Mantar Şapkası getir." }
Q[2204] = { name = "Kolyeyi Onarmak", note = "Güç kaynağı Archaedas'tan düşer. Bitirmek Talvash's Enhancing Necklace'ı açar.", objective = "Uldaman'da bulabildiğin en güçlü yapay yaratıktan bir güç kaynağı al ve Ironforge'daki Talvash del Kissel'e teslim et." }
Q[2240] = { name = "Gizli Oda", note = "İsteğe bağlı giriş görevi:", objective = "Baelog'un Günlüğü'nü oku, gizli odayı keşfet, sonra Kâşif Stormpike'a rapor ver." }
Q[2258] = { name = "Badlands Reaktif Turu", objective = "Badlands'te Kargath'taki Jarkal Mossmeld'e 5 Akbaba Taşlığı, 10 Crag Coyote Dişi ve 5 Kaya Elementali Parçası getir." }
Q[2278] = { name = "Platin Diskler", note = "Diskler, Ironaya'yı geçince Map Chamber'da.", objective = "Taş gözcüyle konuş ve sakladığı kadim bilgiyi öğren. Sunduğu bilgiyi öğrendikten sonra Norgannon Diskleri'ni etkinleştir." }
Q[2279] = { name = "Platin Diskler", note = "Önce Stone Watcher ile konuş ve diskleri etkinleştir. Sonra ödül senedini Ironforge kasasındaki Dinita Stonemantle'a ver ve ödülünü seç.", objective = "Norgannon Diskleri'nin minyatür kopyasını Ironforge'daki Kâşifler Birliği'ne götür." }
Q[2280] = { name = "Platin Diskler", note = "Önce Stone Watcher ile konuş ve diskleri etkinleştir. Sonra ödül senedini Thunder Bluff'taki Bena Winterhoof'a ver ve ödülünü seç.", objective = "Norgannon Diskleri'nin minyatür kopyasını Thunder Bluff'taki bilgelerden birine götür." }
Q[2283] = { name = "Kolyeyi Kurtarmak", objective = "Uldaman kazı alanında değerli bir kolye ara ve Orgrimmar'daki Dran Droffers'a getir. Kolye hasarlı olabilir." }
Q[2284] = { name = "Kolyeyi Kurtarmak, 2. Deneme", objective = "Uldaman'ın derinliklerinde mücevherlerin yerine dair bir ipucu bul." }
Q[2318] = { name = "Günlüğü Çevirmek", objective = "Paladin'in günlüğünü çevirebilecek birini bul.  Birinin olabileceği en yakın yer, Badlands'deki Kargath." }
Q[2338] = { name = "Günlüğü Tercüme Etmek", objective = "Jarkal'ın kolyeyi ödünç almasına izin ver. Karşılığında sana günlüğü tercüme edecek." }
Q[2339] = { name = "Mücevherleri ve Güç Kaynağını Bul", note = "Safir Grimlok'tan, güç kaynağı ise Archaedas'tan düşer.", objective = "Uldaman'dan üç mücevheri ve kolye için bir güç kaynağını al, sonra hepsini Kargath'taki Jarkal Mossmeld'e getir. Jarkal, bir güç kaynağının Uldaman'daki en güçlü yapay yaratıkta bulunabileceğini düşünüyor.$B$BGünlükten bildiğin kadarıyla...$B* Yakut, barikatlı bir Shadowforge bölgesine saklanmış.$B* Topaz, Trogg bölgelerinden birinde, birkaç İttifak dwarf'ının yakınındaki bir kavanoza gizlenmiş.$B* Safiri trogg lideri Grimlok sahiplenmiş." }
Q[2342] = { name = "Geri Alınan Hazineler", objective = "Uldaman'ın Güney Ortak Salonu'ndaki aile sandığından Patrick Garrett'ın aile hazinesini al ve Undercity'de ona getir." }
Q[2398] = { name = "Kayıp Dwarf'lar", note = "The Hidden Chamber görevine götüren giriş adımı.", objective = "Uldaman'da Baelog'u bul.", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[2418] = { name = "Güç Taşları", note = "Güç taşları, dış mağaradaki Shadowforge cücelerinden düşer.", objective = "Badlands'deki Rigglefuzz'a 8 Dentrium Güç Taşı ve 8 An'Alleum Güç Taşı getir." }
Q[2500] = { name = "Badlands Malzeme Turu", objective = "Ghak Healtouch'un ihtiyaç duyduğu malzemeleri Badlands'ten edin, sonra Thelsamar'daki sahibine dön." }
Q[2768] = { name = "Kehanomatik Çubuk", note = "Asa, piramit olayından sonra Sergeant Bly'dan düşer.", objective = "Kehanomatik Çubuk'u Gadgetzan'daki Baş Mühendis Bilgewhizzle'a getir." }
Q[2769] = { name = "Brassbolts Kardeşler", note = "Gahz'rilla görevine götüren giriş adımı.", objective = "Shimmering Flats'teki Wizzle Brassbolts ile konuş.", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[2770] = { name = "Gahz'rilla", note = "İsteğe bağlı giriş görevi:", objective = "Gahz'rilla'nın Elektrikli Pulu'nu Shimmering Flats'teki Wizzle Brassbolts'a getir." }
Q[2841] = { description = "Forever'da ışınlayıcı zincirini açmak için Rig Wars'un devam ediyor olması gerekir.", name = "Platform Savaşları", note = "Önce Rig Wars'u kabul et; Chief Engineer Scooty için tamamlanması gerekmez.", objective = "Araç Planları'nı ve Thermaplugg'ın Kasa Şifresi'ni Gnomeregan'dan alıp Orgrimmar'daki Nogg'a götür.$B", warning = "Chief Engineer Scooty'den önce Rig Wars'u kabul et. Rig Wars kaybolursa Chief Engineer Scooty'yi bırak, yeniden görünecektir." }
Q[2842] = { description = "Gnomer-gooooone! öncesi gerekli.", name = "Baş Mühendis Scooty", objective = "Booty Bay'deki Scooty ile konuş." }
Q[2843] = { name = "Gnomer-gooooone!", objective = "Scooty'nin Goblin Vericisi'ni ayarlamasını bekle." }
Q[2846] = { name = "Derinliklerin Tacı", note = "Taç, Hydromancer Velratha'dan düşer.\n\nİsteğe bağlı giriş görevi:", objective = "Derinliklerin Tacı'nı Dustwallow Marsh'taki Tabetha'ya getir." }
Q[2861] = { name = "Tabetha'nın Görevi", note = "Tiara of the Deep görevine götüren giriş adımı.", objective = "Dustwallow Marsh'taki Tabetha ile konuş.", pickup = "Mage eğitmenleri (yalnızca mage'ler)", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[2864] = { name = "Tran'rek", note = "Scarab Shells görevine götüren giriş adımı.", objective = "Gadgetzan'daki Tran'rek ile konuş.", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[2865] = { name = "Skarabe Kabukları", note = "İsteğe bağlı giriş görevi:", objective = "5 Çatlamamış Skarabe Kabuğu'nu Gadgetzan'daki Tran'rek'e getir." }
Q[2904] = { name = "Tam Bir Rezalet", objective = "Kernobee'ye Clockwerk Run çıkışına kadar eşlik et, ardından Booty Bay'deki Scooty'ye rapor ver.", pickup = "Kernobee, Gnomeregan içinde" }
Q[2922] = { name = "Techbot'un Beynini Kurtar!", objective = "Techbot'un Hafıza Çekirdeği'ni Ironforge'daki Tamirci Ustası Overspark'a götür." }
Q[2924] = { name = "Temel Yapaylar", objective = "12 Temel Yapay'ı Ironforge'daki Klockmort Spannerspan'e götür." }
Q[2926] = { description = "The Only Cure is More Green Glow öncesi gerekli.", name = "Gnogaine", objective = "Radyoaktif serpinti toplamak için Boş Kurşun Toplama Şişesi'ni Işınlanmış İstilacılar ya da Işınlanmış Yağmacılar üzerinde kullan. Şişe dolunca onu Kharanos'taki Ozzie Togglevolt'a geri götür." }
Q[2928] = { name = "Gyrodrillmatic Kazıcılar", objective = "Stormwind'deki Shoni'ye yirmi dört Robo-mekanik Bağırsak getir." }
Q[2929] = { name = "Büyük İhanet", objective = "Gnomeregan'a git ve Mekgineer Thermaplugg'ı öldür. Görev tamamlanınca Yüce Tamirci Mekkatorque'a dön." }
Q[2930] = { name = "Veri Kurtarma", objective = "Bir Prizmatik Delikli Kart'ı Ironforge'daki Usta Mekanikçi Castpipe'a götür." }
Q[2933] = { name = "Zehir Şişeleri", objective = "Bir Zehir Şişesi'ni Tarren Mill'deki bir eczacıya götür." }
Q[2934] = { name = "Hasarsız Zehir Kesesi", objective = "Tarren Mill'deki Eczacı Lydon'a bir Hasarsız Zehir Kesesi getir." }
Q[2935] = { name = "Usta Gadrin'e Danış", objective = "Sen'jin Village'daki Usta Gadrin ile konuş." }
Q[2936] = { name = "Örümcek Tanrı", note = "Theka Tableti, Theka the Martyr'ın odasında.", objective = "Witherbark örümcek tanrısının adını öğrenmek için Theka'nın Tableti'ni oku, ardından Usta Gadrin'e dön." }
Q[2945] = { name = "Kirle Kaplı Yüzük", objective = "Kirle Kaplı Yüzük'teki kiri temizlemenin bir yolunu bul.", pickup = "Kirle Kaplı Yüzük, Gnomeregan'daki Dark Iron cücelerinden düşer", turnin = "The Sparklematic 5200, Gnomeregan içinde" }
Q[2947] = { description = "Gnome Improvement öncesi gerekli Alliance adımı.", name = "Yüzüğün Dönüşü", objective = "Yüzüğü kendine saklayabilir ya da halkanın iç kısmındaki mühür izinden ve kazımalardan sorumlu kişiyi bulabilirsin.", pickup = "The Sparklematic 5200, Gnomeregan içinde" }
Q[2948] = { name = "Gnom İşi Geliştirme", objective = "Parlak Altın Yüzük'ü, bir Gümüş Külçe'yi, bir Yosun Akik'i ve 30 gümüş sikkeyi Ironforge'daki Talvash del Kissel'e getir." }
Q[2949] = { description = "Nogg's Ring Redo öncesi gerekli Horde adımı.", name = "Yüzüğün Dönüşü", objective = "Yüzüğü kendine saklayabilir ya da halkanın iç kısmındaki mühür izinden ve kazımalardan sorumlu kişiyi bulabilirsin.", pickup = "The Sparklematic 5200, Gnomeregan içinde" }
Q[2950] = { name = "Nogg'un Yüzük Tamiri", objective = "Parlak Altın Yüzük'ü, bir Gümüş Külçe'yi, bir Yosun Akik'i ve 30 gümüş sikkeyi Orgrimmar'daki Nogg'a getir." }
Q[2951] = { name = "Sparklematic 5200!", objective = "Kirle Kaplı bir Eşyayı Sparklematic 5200'e yerleştir ve makineyi çalıştırmak için yanında üç gümüş sikke bulunduğundan emin ol.", pickup = "The Sparklematic 5200, Gnomeregan içinde", turnin = "The Sparklematic 5200, Gnomeregan içinde" }
Q[2962] = { name = "Tek Çare Daha Fazla Yeşil Parıltı", objective = "Gnomeregan'a git ve Yüksek Etkili Radyoaktif Serpinti getir. Uyarayım, serpinti kararsızdır ve oldukça çabuk bozulur.$B$BGörev tamamlandığında Ozzie, Ağır Kurşun Toplama Şişeni de isteyecek.$B" }
Q[2988] = { name = "Witherbark Kafesleri", objective = "İki Witherbark köyündeki kafesleri kontrol et, sonra Grifon Ustası Talonaxe'a dön." }
Q[2989] = { name = "Zul Sunağı", objective = "Altar of Zul'un tepesini kontrol et, sonra Grifon Ustası Talonaxe'a dön." }
Q[2990] = { name = "Thadius Grimshade", objective = "Sharpbeak'in Tüyü'nü Blasted Lands'teki Thadius Grimshade'e götür." }
Q[2991] = { name = "Nekrum'un Madalyonu", note = "Madalyon Nekrum Gutchewer'dan düşer.", objective = "Nekrum'un Madalyonu'nu Blasted Lands'teki Thadius Grimshade'e getir." }
Q[3042] = { name = "Trol Sertleştiricisi", objective = "20 Şişe Trol Sertleştiricisi'ni Gadgetzan'daki Trenton Lighthammer'a getir." }
Q[3341] = { name = "Sonu Getir", objective = "Andrew Brownell, Soğukgetiren Amnennar'ı öldürüp kafatasını getirmeni istiyor." }
Q[3373] = { name = "Eranikus'un Özü", objective = "Eranikus'un Özü'nü Sunken Temple'daki bu inde bulunan Öz Pınarı'na yerleştir.", pickup = "Eranikus'un Özü (Shade of Eranikus'tan düşer)" }
Q[3444] = { name = "Taş Çember", objective = "Taş Çember'i Ratchet'teki Marvon Rivetseeker'ın atölyesinden al." }
Q[3446] = { name = "Derinliklere", note = "Tapınak bodrumundaki Hakkar Sunağı'nı incele. The Stone Circle'dan sonra Marvon Rivetseeker'dan başlar.", objective = "Swamp of Sorrows'taki Sunken Temple'da Hakkar Sunağı'nı bul." }
Q[3447] = { name = "Çemberin Sırrı", note = "Atal'alarion'u çağırmak için çemberin etrafındaki heykelleri doğru sırayla yak.", objective = "Sunken Temple'a git ve heykel çemberinde saklı sırrı keşfet." }
Q[3520] = { name = "Çığlıkçı Ruhları", objective = "Feralas'ta 3 screecher'ın ruhunu yakala, sonra Steamwheedle Port'taki Yeh'kinya'ya dön." }
Q[3523] = { name = "Downs'ın Belası", objective = "Belnistrasz'a yardım etmeyi kabul ediyorsan onunla tekrar konuş ve sana verdiği Yemin Taşı'nı ona geri ver." }
Q[3525] = { name = "Putu Söndürmek", note = "Ritüel sırasında undead dalgaları saldırır. Bitirmek için ardından idolün yanındaki mangalla konuş.", objective = "Razorfen Downs'taki Quilboar putuna kadar Belnistrasz'a eşlik et.$B$BBelnistrasz putu kapatmak için ayini gerçekleştirirken onu koru." }
Q[3527] = { name = "Mosh'aru Kehaneti", note = "Tabletler Theka the Martyr ve Hydromancer Velratha'dan düşer.", objective = "Birinci ve İkinci Mosh'aru Tabletleri'ni Tanaris'teki Yeh'kinya'ya getir." }
Q[3528] = { name = "Tanrı Hakkar", note = "Avatar of Hakkar'ı çağırmak için Hakkar Yumurtası'nı Hakkari Bloodkeeper'lardan doldur.", objective = "Dolu Hakkar Yumurtası'nı Tanaris'teki Yeh'kinya'ya getir." }
Q[3636] = { name = "Işığı Getir", objective = "Başpiskopos Bendictus, Razorfen Downs'ta Soğukgetiren Amnennar'ı öldürmeni istiyor." }
Q[3701] = { name = "Thaurissan'ın Tüten Harabeleri", objective = "Burning Steppes'teki Ruins of Thaurissan'a git ve Thaurissan Kalıntıları'ndan bilgi topla. Bilgiyi topladığında Kraliyet Tarihçisi Archesonus'a dön." }
Q[3702] = { name = "Thaurissan'ın Tüten Harabeleri", objective = "Kraliyet Tarihçisi Archesonus'un Thaurissan tarihini anlatmasını dinle." }
Q[3765] = { description = "Researching the Corruption görevine götüren isteğe bağlı Alliance yönlendirme görevi.", name = "Uzaklardaki Yozlaşma", note = "Researching the Corruption görevine götüren giriş adımı.", objective = "Auberdine'daki Gershala Nightwhisper'a git.", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[3801] = { name = "Dark Iron Mirası", objective = "Şehrin ana anahtarını elde etmekle ilgileniyorsan Franclorn Forgewright ile konuş.", warning = "Bu adamla konuşmak için ölü olman gerekir. Blackrock Mountain'da, zincirden BRD'ye inerken bir odada." }
Q[3802] = { name = "Dark Iron Mirası", note = "Ölüyken Franclorn'un hayaletiyle konuş. Ironfel için Fineous Darkvire'ı öldür ve onu Ring of Law yanındaki Franclorn anıtına yerleştir. Shadowforge Anahtarı BRD içindeki kısayolları açar.", objective = "Fineous Darkvire'ı öldür ve büyük çekiç Ironfel'i geri al. Ironfel'i Thaurissan Tapınağı'na götür ve Franclorn Forgewright'ın heykeline yerleştir." }
Q[3906] = { name = "Alevin Uyumsuzluğu", objective = "Blackrock Mountain'daki taş ocağına git ve Baş Efendi Pyron'u öldür. Bu görevi tamamladığında Thunderheart'a dön.$B" }
Q[3907] = { name = "Ateşin Uyumsuzluğu", note = "BRD içindeki Black Anvil'de Lord Incendius'u öldür ve Kurniya Tableti'ni geri getir.", objective = "Blackrock Depths'e gir ve Lord Incendius'un izini sür. Onu öldür ve bulabileceğin her türlü bilgi kaynağını Thunderheart'a getir.$B" }
Q[3981] = { name = "Komutan Gor'shak", objective = "Blackrock Depths'te Komutan Gor'shak'ı bul.$B$BOrk'un kabaca çizilmiş resminin portresinin üzerinde parmaklıklar çizili olduğunu hatırlıyorsun. Belki bir tür hapishane aramalısın." }
Q[3982] = { name = "Neler Oluyor?", note = "High Interrogator Gerstahn'dan alınan Hapishane Hücresi Anahtarı ile hücresini aç, sonra onu savun.", objective = "Gor'shak'ı savun." }
Q[4001] = { name = "Neler Oluyor?", objective = "Kharan Mighthammer ile konuş ve Prenses Moira Bronzebeard'ün kaçırılması hakkında bilgi topla. Bu bilgileri Orgrimmar'daki Thrall'a götür.$B$BGor'shak'ın, Kharan'ın yakınlardaki bir hücrede tutulduğundan bahsettiğini hatırlıyorsun.$B" }
Q[4002] = { name = "Doğu Krallığı", objective = "Planladığı görevi üstlenmeye hazırsan Thrall ile konuş." }
Q[4003] = { name = "Kraliyet Kurtarma Operasyonu", note = "Princess Moira'yı hayatta tut ve Emperor Thaurissan öldükten sonra onunla konuş. Onun The Princess Saved? görevi ödül için seni Thrall'a geri gönderir.", objective = "İmparator Dagran Thaurissan'ı öldür ve Prenses Moira Bronzebeard'ü onun kötü büyüsünden kurtar.$B" }
Q[4024] = { name = "Alevin Tadı", note = "Önce Cyrus'a bir Kara Ejderha Uçuşu Deri Döküntüsü göster (A Taste of Flame ya da çağırdığı drake'i öldür). Sonra Bael'Gar'ı öldür ve Kaplı Ateşli Öz'ü toplamak için Değiştirilmiş Kara Ejderha Uçuşu Deri Döküntüsü'nü kalıntıları üzerinde kullan.", objective = "Blackrock Depths'e git ve Bael'Gar'ı öldür.$B$BTek bildiğin, devin Blackrock Depths'in içinde yaşadığı. Ateşli Öz'ü yakalamak için Değiştirilmiş Kara Ejderha Soyu Deri Kabuğu'nu Bael'Gar'ın kalıntıları üzerinde kullanmayı unutma.$B$BMuhafazalı Ateşli Öz'ü Cyrus Therepentous'a götür.$B$B" }
Q[4061] = { name = "Makinelerin Yükselişi", objective = "Burning Steppes'e git ve Hierophant Theodora Mulvadania için 10 Kırık Element Parçası topla.$B$BTheodora'nın o bölgenin golemlerini ve elementallerini bu parçaların kaynağı olarak andığını hatırlıyorsun." }
Q[4062] = { name = "Makinelerin Yükselişi", objective = "Element Parçası Örneğini Lotwil Veriatus'a götür.$B$BTheodora'nın Lotwil'in doğudaki bir kampta konuşlandığını söylediğini hatırlıyorsun." }
Q[4063] = { name = "Makinelerin Yükselişi", note = "Kafası için Golem Lord Argelmach'ı öldür ve onu koruyan yapılardan 10 Sağlam Elemental Çekirdek topla.", objective = "Golem Lordu Argelmach'ı bul ve öldür. Kafasını Lotwil'e getir. Ayrıca Argelmach'ı koruyan Ragereaver Golemleri ile Warbringer Yapılarından 10 Sağlam Element Çekirdeği toplaman gerekecek. Bunu biliyorsun, çünkü medyumsun." }
Q[4081] = { name = "GÖRÜLDÜĞÜ YERDE ÖLDÜR: Dark Iron Cüceleri", objective = "Blackrock Depths'e git ve alçak saldırganları yok et!$B$BSavaş Lordu Goretooth senden 15 Anvilrage Muhafızı, 10 Anvilrage Gardiyanı ve 5 Anvilrage Piyadesi öldürmeni istiyor. Görevin bittiğinde ona geri dön.$B$B" }
Q[4082] = { name = "GÖRÜNCE ÖLDÜR: Üst Rütbeli Dark Iron Yetkilileri", objective = "Blackrock Depths'e git ve alçak saldırganları yok et!$B$BSavaş Lordu Goretooth, 10 Anvilrage Hekimi, 10 Anvilrage Askeri ve 10 Anvilrage Subayı öldürmeni istiyor. Görev tamamlanınca ona dön." }
Q[4083] = { name = "Hayalet Kadeh", note = "Madencilik 230. Seven savaşından önce Gloom'rel ile konuş; Smelt Dark Iron'u öğrenmek için Hayalet Kadeh'e 2 Yıldız Yakutu, 20 Altın Külçe ve 10 Truesilver Külçe ver.", objective = "Gloom'rel'e 2 Yıldız Yakutu, 20 Altın Külçe ve 10 Truesilver Külçe getir, sonra bunları Summoners' Tomb'daki Hayalet Kadeh'e koy." }
Q[4121] = { name = "Tehlikeli Durum", objective = "Mahkûmun Grark Lorkrub'u Burning Steppes'ten ve Blackrock Mountain'dan geçirerek Searing Gorge'a götür.$B$BLexlort'un adamlarını karşı tarafta Grark'ı gözaltına almak için bekleteceğini söylediğini hatırlıyorsun.$B$BAyrıca Toryum Kelepçelerini Lexlort'a teslim etmen gerekecek." }
Q[4122] = { name = "Grark Lorkrub", objective = "Burning Steppes'e git ve Grark Lorkrub'ı bul. Lexlort'un, onun en son devasa bir Blackrock kalesinde görüldüğünden bahsettiğini hatırlıyorsun.$B$BGrark Lorkrub'ı bulduğunda, onu bağlamak için Toryum Prangalarını kullan ve ardından Blackrock Mountain'dan geçirerek Searing Gorge'a geri götür. Lexlort'un adamları, Grark'ı gözaltına almak için diğer tarafta bekliyor olacak.$B" }
Q[4123] = { name = "Dağın Kalbi", note = "Dağın Kalbi, Dark Keeper'lardan sonra kasadaki kasada.", objective = "Dağın Kalbi'ni Burning Steppes'teki Maxwort Uberglint'e getir." }
Q[4126] = { name = "Hurley Blackbreath", note = "Hurley Blackbreath ve muhafızlarını ortaya çıkarmak için Grim Guzzler deposundaki üç fıçıyı kır.\n\nİsteğe bağlı giriş görevi:", objective = "Kayıp Thunderbrew Tarifi'ni Kharanos'taki Ragnar Thunderbrew'a getir." }
Q[4128] = { name = "Ragnar Thunderbrew", note = "Hurley Blackbreath görevine götüren giriş adımı.", objective = "Ragnar Thunderbrew ile konuş.", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[4132] = { name = "Operasyon: Angerforge'a Ölüm", note = "Önce her iki KILL ON SIGHT görevi ve Grark Lorkrub eskortu gerekir.", objective = "Blackrock Depths'e git ve General Angerforge'u öldür! Görev tamamlanınca Savaş Lordu Goretooth'a dön." }
Q[4133] = { name = "Vivian Lagrave", note = "Lost Thunderbrew Recipe görevine götüren giriş adımı.", objective = "Kargath'taki Gölge Ustası Vivian Lagrave ile konuş.", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[4134] = { name = "Kayıp Thunderbrew Tarifi", note = "Hurley Blackbreath ve muhafızlarını ortaya çıkarmak için Grim Guzzler deposundaki üç fıçıyı kır.\n\nİsteğe bağlı giriş görevi:", objective = "Kayıp Thunderbrew Tarifi'ni Kargath'taki Vivian Lagrave'e getir." }
Q[4136] = { name = "Ribbly Screwspigot", note = "İsteğe bağlı giriş görevi:", objective = "Ribbly'nin Kafası'nı Burning Steppes'teki Yuka Screwspigot'a götür." }
Q[4141] = { name = "Muigin ve Larion", objective = "15 Bloodpetal topla ve Muigin'e dön." }
Q[4142] = { name = "Gregan'a Bir Ziyaret", objective = "Bir Bloodpetal'ı Feralas'taki Gregan Brewspewer'a götür." }
Q[4143] = { name = "Kötülük Pusu", note = "Atal'ai Sisi, tapınağın solucanlarından, pusucularından ve balçıklarından düşer.", objective = "5 Atal'ai Pusu örneği topla, ardından Un'Goro Crater'daki Muigin'e dön." }
Q[4145] = { name = "Larion ve Muigin", objective = "Marshal's Refuge'daki Larion için 5 Bloodpetal Lasher, 5 Bloodpetal Thresher, 5 Bloodpetal Flayer ve 5 Bloodpetal Trapper avla." }
Q[4146] = { name = "Böcek Çarpıcı Yakıtı", note = "Atal'ai Sisi, tapınağın solucanlarından, pusucularından ve balçıklarından düşer.", objective = "Boş Böcek Çarpıcı'yı ve 5 Atal'ai Pusu örneğini Marshal's Refuge'daki Larion'a götür." }
Q[4147] = { name = "Marvon'un Atölyesi", objective = "Ratchet'taki Marvon Rivetseeker'ın atölyesine git." }
Q[4182] = { name = "Ejderha Soyu Tehdidi", objective = "15 Black Broodling, 10 Black Dragonspawn, 4 Black Wyrmkin ve 1 Black Drake öldür. Görev tamamlanınca Helendis Riverhorn'a dön." }
Q[4183] = { name = "Gerçek Efendiler", objective = "Lakeshire'a git ve Helendis Riverhorn'un Mektubu'nu Yargıç Solomon'a teslim et." }
Q[4184] = { name = "Gerçek Efendiler", objective = "Stormwind'e git ve Solomon'un Yalvarısı'nı Highlord Bolvar Fordragon'a teslim et.$B$BBolvar, Stormwind Keep'te oturuyor. " }
Q[4185] = { name = "Gerçek Efendiler", objective = "Lady Katrana Prestor ile konuştuktan sonra Highlord Bolvar Fordragon ile konuş." }
Q[4186] = { name = "Gerçek Efendiler", objective = "Bolvar'ın Fermanı'nı Lakeshire'daki Yargıç Solomon'a götür.$B" }
Q[4201] = { name = "Aşk İksiri", note = "Gromsblood, Dev Gümüş Damarları (Azshara uçurum devleri) ve Un'Goro'daki Golakka Hot Springs'te doldurulan şişe. Sonraki ziyaretlerde bardan barışçıl bir geçiş açar.", objective = "4 Gromsblood, 10 Dev Gümüş Damarı ve Nagmara'nın Dolu Şişesi'ni Blackrock Depths'teki Mistress Nagmara'ya getir." }
Q[4223] = { name = "Gerçek Efendiler", objective = "Burning Steppes'teki Mareşal Maxwell ile konuş." }
Q[4224] = { name = "Gerçek Efendiler", objective = "Mareşal Windsor'un akıbetini öğrenmek için Ragged John ile konuş ve bu görevi tamamlayınca Mareşal Maxwell'e dön.$B$BMareşal Maxwell'in onu kuzeydeki bir mağarada aramanı söylediğini hatırlıyorsun." }
Q[4241] = { name = "Mareşal Windsor", objective = "Kuzeybatıdaki Blackrock Mountain'a git ve Blackrock Depths'e gir. Mareşal Windsor'a ne olduğunu öğren.$B$BRagged John'un, Windsor'ın bir hapishaneye sürüklendiğinden bahsettiğini hatırlıyorsun." }
Q[4242] = { name = "Terk Edilmiş Umut", objective = "Mareşal Maxwell'e kötü haberi ver." }
Q[4262] = { name = "Baş Efendi Pyron", objective = "Baş Efendi Pyron'u öldür ve Jalinda Sprig'e dön.$B$BJalinda'nın, Pyron'un taş ocağını koruduğundan bahsettiğini hatırlıyorsun. Belki de orayı aramalısın?" }
Q[4263] = { name = "Incendius!", note = "BRD içindeki Black Anvil'de Lord Incendius'u öldür.", objective = "Blackrock Depths'te Lord Incendius'u bul ve yok et!" }
Q[4264] = { name = "Buruşuk Bir Not", objective = "Belki de Marshal Windsor'un görmek isteyeceği bir şeye rastladın. Sonuçta umut olabilir.", pickup = "Buruşturulmuş Bir Not (Dark Iron cücelerinden düşer)" }
Q[4282] = { name = "Bir Umut Kırıntısı", objective = "Mareşal Windsor'ın Kayıp Bilgileri'ni geri getir.$B$BMareşal Windsor, bilgilerin Golem Lordu Argelmach ve General Angerforge'un elinde olduğuna inanıyor." }
Q[4286] = { name = "İyi Şeyler", note = "Dark Iron Bel Çantaları, BRD'deki Dark Iron cücelerinden düşer.", objective = "Blackrock Depths'e git ve 20 Dark Iron Bel Çantası topla. Bu görevi tamamladığında Oralius'a dön. Blackrock Depths'teki Dark Iron cücelerinin bu 'bel çantası' denen zımbırtıları taşıdığını tahmin ediyorsun.$B" }
Q[4295] = { name = "Rocknot'un Birası", note = "Plugger Spazzring'den Dark Iron Bira Kupası satın al ve Rocknot'a vermeye devam et. Sarhoşluk olayı bar yolunu açar ve Phalanx'ı düşman yapabilir.", objective = "Er Rocknot'a iki Dark Iron Bira Kupası getir." }
Q[4322] = { name = "Firar!", note = "Marshal Windsor'a hapishane boyunca eşlik et. Önce devriyeleri temizle ve başlamadan önce herkesin hazır olmasını sağla.", objective = "Mareşal Windsor'ın teçhizatını geri almasına ve dostlarını serbest bırakmasına yardım et. Başarırsan Mareşal Maxwell'e dön." }
Q[4324] = { name = "Yuka Screwspigot", note = "Ribbly Screwspigot görevine götüren giriş adımı.", objective = "Burning Steppes'teki Yuka Screwspigot ile konuş.", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[4341] = { name = "Kharan Mighthammer", objective = "Blackrock Depths'e git ve Kharan Mighthammer'ı bul.$B$BKral, Kharan'ın orada esir tutulduğundan bahsetti; belki de bir hapishane aramalısın." }
Q[4342] = { name = "Kharan'ın Hikâyesi", objective = "Kharan Mighthammer hikâyesini anlatırken dinle." }
Q[4361] = { name = "Kötü Haber Getiren", objective = "Ironforge'a dön ve kötü haberi Kral Magni Bronzebeard'a ilet." }
Q[4362] = { name = "Krallığın Kaderi", note = "Princess Moira'yı hayatta tut ve Emperor Thaurissan öldükten sonra onunla konuş. Onun The Princess's Surprise görevi ödül için seni Magni'ye geri gönderir.", objective = "Blackrock Depths'e dön ve Prenses Moira Bronzebeard'ü İmparator Dagran Thaurissan'ın kötü pençelerinden kurtar.$B" }
Q[4701] = { name = "Onu Yere Ser", note = "Worg ini annesi Halycon'u öldür. Hemen ardından sana gelecek olan Gizrul the Slavener'a hazır ol.", objective = "Blackrock Spire'a git ve worg tehdidinin kaynağını yok et. Helendis'ten ayrılırken bir isim haykırdı: Halycon. Orklar worg'lar için böyle diyor." }
Q[4724] = { name = "Sürünün Hanımı", note = "Worg ini annesi Halycon'u öldür. Hemen ardından sana gelecek olan Gizrul the Slavener'a hazır ol.", objective = "Bloodaxe worglarının sürü hanımı Halycon'u öldür." }
Q[4726] = { name = "Yavru Ejderha Özü", objective = "Burning Steppes'teki Flame Crest'te bulunan Tinkee Steamboil'e 8 Yavru Ejderha Özü ve Draco-Incarcinatrix 900'ü getir." }
Q[4729] = { name = "Kibler'ın Egzotik Evcil Hayvanları", note = "Verilen kafesi worg bölgesindeki bir Bloodaxe Worg Yavrusu üzerinde kullan.", objective = "Blackrock Spire'a git ve Bloodaxe Worg Yavrularını bul. Vahşi küçük canavarları taşımak için kafesi kullan. Kibler'a Kafesli Worg Yavrusu getir." }
Q[4734] = { name = "Yumurta Dondurma", objective = "Yumurtaskop Prototipi'ni Yuvalık'taki bir yumurtanın üzerinde kullan." }
Q[4735] = { name = "Yumurta Toplama", note = "Modülü Rookery'deki yumurtalarda kullanmak yavruların çıkmasına yol açabilir.", objective = "8 Toplanmış Ejderha Yumurtası'nı ve Toplatronik Modül'ü Burning Steppes'teki Flame Crest'te bulunan Tinkee Steamboil'e götür." }
Q[4742] = { name = "Yükseliş Mührü", objective = "Üç komuta mücevherini bul: Smolderthorn Mücevheri, Spirestone Mücevheri ve Bloodaxe Mücevheri. Bunları Süssüz Yükseliş Mührü ile birlikte Vaelan'a götür.$B$BVaelan'ın sana söylediğine göre generaller şunlardır: Smolderthorn'dan Savaş Ustası Voone, Spirestone'dan Yüce Lord Omokk ve Bloodaxe'tan Derebeyi Wyrmthalak.", pickup = "Vaelan (Scarshield Infiltrator), Lower Blackrock Spire", turnin = "Vaelan (Scarshield Infiltrator), Lower Blackrock Spire" }
Q[4743] = { name = "Yükseliş Mührü", note = "Dövülmemiş Mühür'ü ve Ejderha Enerjisi Küresi'ni Dustwallow Marsh'taki Wyrmbog'da Emberstrife'a götür. Dövülmüş mühür UBRS kapısını açar.", objective = "Dustwallow Marsh'taki Wyrmbog'a git. Kadim ejder Emberstrife'ı bul ve iradesi kırılana dek onu acımadan döv.$B$BTam o anda Dövülmemiş Yükseliş Mührü'nü o büyük yaratığın önüne koymalısın. Ardından hızla Ejderha Enerjisi Küresi'ni zayıf düşmüş bedeni üzerinde kullanmalı ve zihnine hükmetmelisin. Yaratığı kontrol et ve Kara Ejderha Soyu'nun Alevleri'ni Dövülmemiş Yükseliş Mührü'ne püskürtmeye zorla!" }
Q[4764] = { name = "Doomrigger'ın Tokası", note = "Doomrigger'ın Sandığı Rookery'de. Ardından ödül için Delivery to Ridgewell'i Stormwind Keep'teki Count Remington Ridgewell'e götür.\n\nİsteğe bağlı giriş görevi:", objective = "Doomrigger'ın Tokası'nı Burning Steppes'teki Mayara Brightwing'e götür." }
Q[4766] = { name = "Mayara Brightwing", note = "Doomrigger's Clasp görevine götüren giriş adımı.", objective = "Burning Steppes'teki Mayara Brightwing ile konuş.", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[4768] = { name = "Darkstone Tableti", note = "Darkstone Tableti Rookery'de yerde duruyor.\n\nİsteğe bağlı giriş görevi:", objective = "Darkstone Tableti'ni Kargath'taki Gölge Büyücüsü Vivian Lagrave'e götür." }
Q[4769] = { name = "Vivian Lagrave ve Darkstone Tableti", note = "The Darkstone Tablet görevine götüren giriş adımı.", objective = "Gölge Büyücüsü Vivian Lagrave ile konuş.", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[4771] = { name = "Şafak Kumarı", note = "Viewing Room'da Dawn's Gambit'i kullan ve Vectus'u yen.", objective = "Şafak Kumarı'nı Scholomance'taki Seyir Odası'na yerleştir. Vectus'u yen, ardından Betina Bigglezink'e dön." }
Q[4787] = { name = "Kadim Yumurta", objective = "Kadim Yumurta'yı Tanaris'teki Yeh'kinya'ya getir." }
Q[4788] = { name = "Son Tabletler", note = "Beşinci ve altıncı Mosh'aru tabletleri Smolderthorn trol bölgesinde. Confront Yeh'kinya ve The Hand of Rastakhan ile devam eder.", objective = "Beşinci ve Altıncı Mosh'aru Tabletleri'ni Tanaris'teki Maden Arayıcısı Ironboot'a götür." }
Q[4808] = { name = "Felnok Steelspring", objective = "Tinkee'nin Mektubu'nu Felnok Steelspring'e ver." }
Q[4809] = { name = "Chillwind Boynuzları", objective = "Felnok Steelspring'e 8 Çatlamamış Chillwind Boynuzu getir." }
Q[4810] = { name = "Tinkee'ye Dönüş", objective = "Felnok'un Paketi'ni Burning Steppes'teki Tinkee Steamboil'e götür." }
Q[4862] = { name = "Evcilleştirme Sanatı", note = "Spire Örümcek Yumurtaları örümcek tünellerinde.", objective = "Blackrock Spire'a git ve Kibler için 15 Kule Örümceği Yumurtası topla.$B$BAnlaşılan bu yumurtalar örümceklerin yakınında bulunabilir.$B" }
Q[4866] = { name = "Ana Sütü", note = "Mother Smolderweb tarafından zehirlen ve hâlâ zehirliyken Ragged John'a ulaş. Kimsenin zehri temizlemesine izin verme.", objective = "Blackrock Spire'ın kalbinde Mother Smolderweb'i bulacaksın. Onunla savaş ve seni zehirlemesini sağla. Büyük ihtimalle onu öldürmen de gerekecek. Zehirlendiğinde, seni 'sağabilmesi' için Ragged John'a dön." }
Q[4867] = { name = "Urok Doomhowl", note = "Dalgaları başlatmak için Highlord Omokk'un Kafası'nı ve bir Roughshod Mızrağı'nı örümceklerin ötesindeki Urok's Tribute Pile'a getir.", objective = "Warosh'un Parşömeni'ni oku. Warosh'un Mojosu'nu Warosh'a getir." }
Q[4903] = { name = "Savaş Beyi'nin Emri", note = "Command eşyasını almak için Goretooth ile konuş ve görevi başlatmak için ona tıkla. Önemli Blackrock Belgeleri üç generalin yakınında çıkar.", objective = "Yüce Lord Omokk'u, Savaş Ustası Voone'u ve Derebeyi Wyrmthalak'ı öldür. Önemli Blackrock Belgeleri'ni ele geçir. Görev tamamlandığında Kargath'taki Savaş Beyi Goretooth'a dön." }
Q[4907] = { name = "Tinkee Steamboil", objective = "Tinkee Steamboil ile konuş." }
Q[4941] = { name = "Eitrigg'in Bilgeliği", objective = "Orgrimmar'daki Eitrigg ile konuş. Eitrigg ile meseleleri görüştükten sonra Thrall'a danış.$B$BEitrigg'i Thrall'ın odasında gördüğünü hatırlıyorsun." }
Q[4974] = { name = "Horde İçin!", objective = "Blackrock Spire'a git ve Savaş Şefi Rend Blackhand'i öldür. Kellesini al ve Orgrimmar'a dön." }
Q[4981] = { name = "Ajan Bijou", objective = "Blackrock Spire'a git ve Bijou'ya ne olduğunu öğren." }
Q[4982] = { name = "Bijou'nun Eşyaları", note = "Ardından ödül için Bijou's Reconnaissance Report'u Kargath'taki Lexlort'a götür.", objective = "Bijou'nun Eşyaları'nı bul ve ona geri götür. Onları şehrin en alt katına sakladığından bahsettiğini hatırlıyorsun.$B" }
Q[5001] = { name = "Bijou'nun Eşyaları", note = "Bijou, ilk köprülerin ötesindeki bir girintide saklanır. Eşyaları trol ve ork odalarının çevresindeki birkaç yerden birinde çıkar.", objective = "Bijou'nun Eşyaları'nı bul ve ona geri götür. Bol şans!$B" }
Q[5002] = { name = "Maxwell'e Mesaj", objective = "Burning Steppes'e git ve Bijou'nun Bilgileri'ni Mareşal Maxwell'e ver." }
Q[5047] = { name = "Finkle Einhorn, Hizmetinizde!", note = "Savaştan sonra The Beast'in cesedinden çıkar. Malyfous ardından Pristine Hide of the Beast takaslarını sunar.", objective = "Everlook'taki Malyfous Darkhammer ile konuş.", pickup = "The Beast'in cesedinden, Upper Blackrock Spire" }
Q[5065] = { name = "Mosh'aru'nun Kayıp Tabletleri", objective = "Üçüncü ve Dördüncü Mosh'aru Tabletleri'ni Tanaris'teki Maden Arayıcı Ironboot'a getir." }
Q[5081] = { name = "Maxwell'in Görevi", objective = "Blackrock Spire'a git ve Savaş Ustası Voone'u, Yüce Lord Omokk'u ve Derebeyi Wyrmthalak'ı yok et. İş bittiğinde Mareşal Maxwell'e dön." }
Q[5089] = { name = "General Drakkisath'ın Emri", note = "Upper Blackrock Spire'daki General Drakkisath's Demise görevine götürür.", objective = "General Drakkisath'ın Emri'ni Burning Steppes'teki Mareşal Maxwell'e götür.", pickup = "General Drakkisath's Command (Overlord Wyrmthalak'tan düşer)" }
Q[5102] = { name = "General Drakkisath'ın Sonu", note = "UBRS'nin sonunda General Drakkisath'ı öldür.", objective = "Blackrock Spire'a git ve General Drakkisath'ı yok et. İş bittiğinde Mareşal Maxwell'e dön.$B" }
Q[5122] = { name = "İnanç Madalyonu", note = "Madalyon, Scarlet Bastion'daki Malor'un Kasası'nda. Baron ile savaşmadan önce onu şapeldeki Aurius'a ver.", objective = "İnanç Madalyonu'nu Scarlet Bastion'daki Malor the Zealous'tan al ve Aurius'a geri getir." }
Q[5125] = { name = "Aurius'un Hesaplaşması", note = "Baron savaşından önce İnanç Madalyonu'nu Aurius'a ver; Baron Rivendare öldükten sonra onunla konuş.", objective = "İnanç Madalyonu'nu Aurius'a ver; Baron Rivendare'e karşı savaşa katılır. Savaştan sonra ödülünü al." }
Q[5127] = { name = "İblis Ocağı", note = "Demircilik 270 (Zırh Ustası). Kana Bulanmış Mızrak'ı Goraluk'un cesedinde kullan ve yakındaki Dövülmemiş Rün Kaplı Göğüslük'ü al.", objective = "Blackrock Spire'a git ve Goraluk Anvilcrack'ı bul. Onu öldür, sonra Kana Bulanmış Mızrak'ı cesedi üzerinde kullan. Ruhu emildikten sonra mızrak Ruha Bulanmış hale gelecek.$B$BAyrıca Dövülmemiş Rün Kaplı Göğüs Zırhı'nı da bulmalısın.$B$BHem Ruha Bulanmış Mızrak'ı hem de Dövülmemiş Rün Kaplı Göğüs Zırhı'nı Winterspring'deki Lorax'a götür." }
Q[5160] = { name = "Koruyucu Ana", note = "Awbee, Rend'den sonra arena yolunun yakınındaki yaralı mavi ejderha. Haleh'e ulaşmak için Mazthoril mağarasının derinlerindeki rünü kullan.", objective = "Winterspring'e git ve Haleh'i bul. Ona Awbee'nin pulunu ver." }
Q[5212] = { name = "Et Yalan Söylemez", note = "Stratholme'daki her undead Vebalı Et Örneği düşürebilir.", objective = "Stratholme'dan 10 Vebalı Et Örneği al ve Betina Bigglezink'e getir. Stratholme'daki her yaratığın bu et örneğini taşıyacağından şüpheleniyorsun." }
Q[5213] = { name = "Etkin Madde", objective = "Stratholme'e git ve zigguratları ara. Yeni Scourge Verileri'ni bul ve Betina Bigglezink'e getir.$B" }
Q[5214] = { name = "Büyük Fras Siabi", note = "Daha yeni Classic kayıtları ona Ezra Grimm der. Tütün dükkânını temizle, tütün kutusuna dokun ve dükkân sahibini öldür.", objective = "Stratholme'de Fras Siabi'nin tütün dükkânını bul ve bir kutu Siabi'nin Seçkin Tütünü'nü getir. İş bitince Smokey LaRue'ya dön.$B" }
Q[5243] = { name = "Kutsalın Evleri", note = "Sokaklardaki erzak sandıklarından 5 Stratholme Kutsal Suyu topla; bazı sandıklardan düşman çıkar.", objective = "Kuzeydeki Stratholme'a git. Şehri dolduran erzak sandıklarını ara ve 5 Stratholme Kutsal Suyu bul. Yeterince kutsal sıvı topladığında Saygıdeğer Leonid Barthalomew'e dön." }
Q[5244] = { name = "Kel'Theril Harabeleri", objective = "Starfall Village'daki Jaron Stoneshaper ile konuş." }
Q[5245] = { name = "Kel'Theril'in Huzursuz Ruhları", objective = "Jaron'un Kazması'nı kullanarak dört Highborne Kalıntı Parçası'nı bul. Onları Eastern Plaguelands'teki Aurora Skycaller'a götür." }
Q[5246] = { name = "Geçmişin Parçaları", objective = "Azshara'daki Zin-Malor Tapınağı'nda Kutsal Highborne Yazıları'nı bul ve Eastern Plaguelands'te Northpass Tower yakınındaki Aurora Skycaller'a getir." }
Q[5247] = { name = "Geçmişin Parçaları", note = "Dire Maul West'te Eldreth Row boyunca uğursuz havuzda şişesini doldur; ayrıca 1 Efsunlu Thorium Külçesi ve 5 Crystal Restore getir.\n\nİsteğe bağlı giriş görevi:", objective = "Eastern Plaguelands'te Northpass Tower yakınındaki Aurora Skycaller'a bir Büyülü Toryum Külçesi, 5 Crystal Restore ve bir Şişe Uğursuz Su getir." }
Q[5250] = { name = "Starfall", note = "Fragments of the Past görevine götüren giriş adımı.", objective = "Winterspring'de Starfall'u bul ve Wynd Nightchaser ile konuş.", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[5251] = { name = "Arşivci", note = "Scarlet Bastion'da Archivist Galford'u öldür ve arşivleri yak.", objective = "Stratholme'e git ve Scarlet Crusade'den Arşivci Galford'u bul. Onu yok et ve Scarlet Arşivi'ni yakıp kül et." }
Q[5262] = { name = "Gerçek Bütün Ağırlığıyla Çöküyor", note = "Önce The Archivist'i teslim et, yoksa Balnazzar'ın kafası bu görevi başlatmaz.", objective = "Balnazzar'ın Kafası'nı Eastern Plaguelands'teki Dük Nicholas Zverenhoff'a götür.", pickup = "Balnazzar'ın Kafası (Balnazzar'dan düşer)" }
Q[5263] = { name = "Beklentilerin Ötesinde", note = "Ardından Light's Hope Chapel'daki Lord Maxwell Tyrosus ve The Argent Hold silah veya kalkan ödülünü verir.", objective = "Stratholme'e git ve Baron Rivendare'i yok et. Kafasını al ve Dük Nicholas Zverenhoff'a dön.$B" }
Q[5281] = { name = "Huzursuz Ruhlar", note = "The Restless Souls görevine götüren giriş adımı.", objective = "Egan'ı bul. Yalnızca en son Stratholme civarında görüldüğünü biliyorsun.", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[5282] = { name = "Huzursuz Ruhlar", note = "İsteğe bağlı giriş görevi:", objective = "Egan'ın Patlatıcısı'nı Stratholme'ün hayaletimsi ve tayfsı sakinleri üzerinde kullan. Huzursuz ruhlar hayalet kabuklarından kurtulduğunda patlatıcıyı yeniden kullan; özgürlüklerine kavuşacaklar!$B$B15 Huzursuz Ruh'u özgür bırak ve Egan'a dön." }
Q[5341] = { name = "Barov Ailesinin Serveti", note = "Dört tapu: ilk büyük salonda Southshore, yavrulardan önce Tarren Mill, Ras Frostwhisper'ın yanında Brill, Lord Alexei Barov'un yanında Caer Darrow. Devam görevi The Last Barov seni rakip kardeşi öldürmeye gönderir.", objective = "Scholomance'a git ve Barov ailesinin servetini geri getir. Bu servet dört tapudan oluşuyor: Caer Darrow Tapusu, Brill Tapusu, Tarren Mill Tapusu ve Southshore Tapusu. Bu görevi tamamladığında Alexi Barov'a dön." }
Q[5343] = { name = "Barov Ailesinin Serveti", note = "Dört tapu: ilk büyük salonda Southshore, yavrulardan önce Tarren Mill, Ras Frostwhisper'ın yanında Brill, Lord Alexei Barov'un yanında Caer Darrow. Devam görevi The Last Barov seni rakip kardeşi öldürmeye gönderir.", objective = "Scholomance'a git ve Barov ailesinin servetini geri getir. Bu servet dört tapudan oluşuyor: Caer Darrow Tapusu, Brill Tapusu, Tarren Mill Tapusu ve Southshore Tapusu. Bu görevi tamamladığında Weldon Barov'a dön." }
Q[5382] = { name = "Doktor Theolen Krastinov, Kasap", objective = "Scholomance'ın içinde Doktor Theolen Krastinov'u bul. Onu yok et, ardından Eva Sarkhoff'un Kalıntıları'nı ve Lucien Sarkhoff'un Kalıntıları'nı yak. Görev tamamlandığında Eva Sarkhoff'a dön.$B" }
Q[5384] = { name = "Haberci Kirtonos", note = "Masumların Kanı'nı Scholomance verandasındaki mangalda kullan. Ödül: Spectral Essence.", objective = "Masumların Kanı ile Scholomance'a dön. Sundurmayı bul ve Masumların Kanı'nı mangala koy. Kirtonos ruhunla ziyafet çekmeye gelecek.$B$BYiğitçe savaş, bir adım bile geri atma! Kirtonos'u yok et ve Eva Sarkhoff'a dön.$B" }
Q[5461] = { name = "İnsan, Ras Frostwhisper", objective = "Arathi Highlands'e, Stromgarde harabelerine git. Stromgarde'da bir Anma Hatırası ara. Böyle bir eşya bulursan onunla Yargıç Marduke'a dön." }
Q[5462] = { name = "Ölmekte Olan, Ras Frostwhisper", objective = "Eastern Plaguelands'teki Light's Hope'a git ve Saygıdeğer Leonid Barthalomew'i bul. Ona Anma Hatırası'nı göster ve keşfettiğin her şeyi anlat." }
Q[5463] = { name = "Menethil'in Armağanı", note = "Baron Rivendare öldükten sonra odasının zeminindeki parlayan rünü kullan, sonra devam görevini Leonid'e geri götür.", objective = "Stratholme'a git ve Menethil's Gift'i bul. Anma Yadigârı'nı kutsal olmayan toprağa yerleştir. " }
Q[5464] = { name = "Menethil'in Hediyesi", objective = "Ruha Bağlı Hatıra'yı Eastern Plaguelands'teki Leonid Barthalomew'e götür." }
Q[5465] = { name = "Ruha Bağlı Hatıra", objective = "Caer Darrow'daki Yargıç Marduke'a dön. Ona Ruha Bağlı Hatıra'yı göster." }
Q[5466] = { name = "Lich Ras Frostwhisper", note = "Soulbound Keepsake'i Ras Frostwhisper üzerinde kullanarak onu insana dönüştür, sonra onu öldür ve insan kafasını geri getir.", objective = "Scholomance'ta Ras Frostwhisper'ı bul. Onu bulduğunda, Ruha Bağlı Hatıra'yı ölümsüz suretine karşı kullan. Onu ölümlüye dönüştürmeyi başarırsan, yere ser ve Ras Frostwhisper'ın İnsan Başı'nı al. Başı Yargıç Marduke'a götür." }
Q[5515] = { name = "Krastinov'un Dehşet Çantası", note = "Çanta Jandice Barov'dan düşer.", objective = "Scholomance'ta Jandice Barov'u bul ve yok et. Cesedinden Krastinov'un Dehşet Çantası'nı al. Çantayı Eva Sarkhoff'a götür." }
Q[5518] = { name = "Gordok Ogre Kostümü", note = "4 Rün Kumaşı Topu, 8 Sağlam Deri, 2 Rün İpliği ve 1 Ogre Tanen'i (Knot'un ötesinde üst kattaki sepet) getir. Knot'u serbest bırakmadan önce istediğin takımları yap ve deseni öğren, çünkü gidiyor.", objective = "4 Top Rün Kumaşı, 8 Sert Deri, 2 Rün İpliği ve Ogre Tanen Özü'nü Knot Thimblejack'e getir. Kendisi şu anda Dire Maul'un Gordok kanadında zincirli durumda." }
Q[5522] = { name = "Leonid Barthalomew", objective = "Donmuş Yumurtalar'ı Eastern Plaguelands'teki Leonid Barthalomew'e götür." }
Q[5525] = { name = "Knot'u Kurtar!", note = "North ogrelerinden bir Gordok Pranga Anahtarı al ve Knot'u serbest bırak; zulasında ganimet var.", objective = "Gordok kanadındaki ogrelerden bir Gordok Pranga Anahtarı bul ve Knot Thimblejack'i serbest bırakmak için kullan." }
Q[5526] = { name = "Felvine Parçaları", note = "Alzzin the Wildshaper'ı öldür, sarmaşığın yanından bir Felvine Parçası al ve onu Reliquary of Purity'ye mühürle.", objective = "Dire Maul'da Felvine'ı bul ve ondan bir parça elde et. Büyük ihtimalle bir parçayı ancak Vahşibiçimci Alzzin'in ölümüyle elde edebileceksin. Parçayı güvenle içine mühürlemek için Saflık Mahfazası'nı kullan ve onu Moonglade, Nighthaven'daki Rabine Saturna'ya götür." }
Q[5527] = { name = "Bir Saflık Mahfazası", objective = "Silithus'a git ve Southwind Village harabelerinde bir Saflık Mahfazası ara. Bulabilirsen onu Moonglade, Nighthaven'daki Rabine Saturna'ya getir." }
Q[5529] = { name = "Vebalı Yavrular", note = "20 Vebalı Yavru öldür. Bunu teslim ettikten sonra yavrular, Betina'ya tekrarlanabilir teslim başlatan Sağlıklı Ejderha Pulu düşürebilir.", objective = "20 Vebalı Yavru öldür, ardından Light's Hope Chapel'daki Betina Bigglezink'e dön." }
Q[5531] = { name = "Betina Bigglezink", objective = "Donmuş Yumurtalar'ı Betina Bigglezink'e götür." }
Q[5542] = { name = "İblis Köpekleri", objective = "20 Plaguehound Runt, 5 Plaguehound ve 5 Frenzied Plaguehound öldür. Görev tamamlanınca Tirion Fordring'e dön." }
Q[5543] = { name = "Kanla Lekelenmiş Gökyüzü", objective = "30 Veba Yarasası öldür ve Tirion Fordring'e dön." }
Q[5544] = { name = "Leş Yemeği", objective = "Bölgedeki Carrion Grub ve Devourer'ları bul. Onları öldür ve etlerini topla. 15 Dilim Leş Kurdu Eti topladığında Tirion Fordring'e dön.$B" }
Q[5722] = { name = "Kayıp Çantayı Aramak", objective = "Ragefire Chasm'de Maur Grimtotem'in cesedini ara ve üzerinde ilgi çekici bir şey olup olmadığına bak.", turnin = "Ragefire Chasm içindeki Maur Grimtotem'in cesedi. İlk büyük üç yollu kavşaktan sağdaki tünele gir, onu yokuş yukarı çıkmaza doğru takip et, sonra soldaki küçük yan odaya gir. Oradaki Maur'un cesediyle etkileşime geç." }
Q[5723] = { name = "Düşmanın Gücünü Sınamak", objective = "Orgrimmar'da Ragefire Chasm'i ara, ardından Thunder Bluff'taki Rahauro'ya dönmeden önce 8 Ragefire Trogg'u ve 8 Ragefire Şamanı öldür." }
Q[5724] = { name = "Kayıp Çantayı Geri Götürmek", objective = "Grimtotem Çantası'nı Thunder Bluff'taki Rahauro'ya götür.", pickup = "Grimtotem Heybesi, Ragefire Chasm içindeki Maur Grimtotem'in cesedinden alınır" }
Q[5725] = { name = "Yok Etme Gücü...", objective = "Gölge Büyüleri ve Nether'den Efsunlar adlı kitapları Undercity'deki Varimathras'a getir." }
Q[5726] = { description = "Ragefire Chasm zinciri için gerekli ilk Hidden Enemies adımı.", name = "Gizli Düşmanlar", objective = "Orgrimmar'daki Thrall'a bir Teğmen Nişanı getir." }
Q[5727] = { description = "Neeru, Ragefire Chasm girişinin yakınındaki Cleft of Shadow'da.", name = "Gizli Düşmanlar", objective = "Teğmen Nişanı'nı Neeru Fireblade'e götür ve onunla konuş. Seni Burning Blade üyesi sanıp sanmadığını anla, sonra Orgrimmar'daki Thrall'a dön." }
Q[5728] = { name = "Gizli Düşmanlar", note = "Orgrimmar'daki önceki Hidden Enemies zincir adımları gerekir. Sonraki Hidden Enemies adımı daha sonra şunları sunar:", objective = "Orgrimmar'daki Thrall'a dönmeden önce Bazzalan'ı ve Çağırıcı Jergosh'u öldür." }
Q[5742] = { name = "Kefaret", objective = "Tirion Fordring'in söyleyeceklerini dinle." }
Q[5761] = { name = "Canavarı Öldürmek", objective = "Ragefire Chasm'e gir ve Aç Gözlü Taragaman'ı öldür, ardından kalbini Orgrimmar'daki Neeru Fireblade'e getir." }
Q[5781] = { name = "Unutulmuş Anılar", objective = "Eastern Plaguelands'in en güney kesimindeki Undercroft'a git ve Taelan'ın Çekici'ni geri al. Hedefini tamamladıktan sonra Tirion Fordring'e dön." }
Q[5845] = { name = "Kayıp Onur", objective = "Eastern Plaguelands'in kuzeydoğusundaki Northdale'e git ve Kayıp Onur Sembolü'nü geri al. Hedefini tamamladıktan sonra Tirion Fordring'e dön." }
Q[5846] = { name = "Sevgi ve Aile", objective = "Veba Topraklarının güney-orta bölgesindeki Caer Darrow adasına git ve tablonun nerede olduğuna dair ipucu ara." }
Q[5848] = { name = "Aşka ve Aileye Dair", note = "Arşivleri yakmadan önce Archivist Galford'un odasındaki ikiz aylar resminin arkasına gizlenmiş tabloyu al.", objective = "Plaguelands'in kuzeyindeki Stratholme'e git. 'Aşka ve Aileye Dair' tablosunu Scarlet Bastion'da, dünyamızın ikiz aylarını tasvir eden başka bir tablonun arkasına gizlenmiş hâlde bulacaksın.$B$BTabloyu Tirion Fordring'e getir." }
Q[5961] = { name = "Banshee Kraliçesi'nin Şampiyonu", note = "Ramstein görevine götüren giriş adımı.", objective = "Eastern Plaguelands'deki Nathanos Blightcaller ile konuş. Söylendiğine göre Marris Stead'e yerleşmiş.$B", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[6022] = { name = "Bir Amaçla Öldürmek", objective = "Doğudaki Corin's Crossing'e git ve kasabada yaşayan Scourge'u katlet. 10 dakikadan kısa sürede 7 parça Canlı Çürük topla. Canlı Çürüğü Pıhtılaşmış Çürüğe öğütmek için Havan ve Tokmak'ı kullan." }
Q[6042] = { name = "Ölümsüzlüğün Küçük Dertleri", objective = "20 Noxious Plaguebat ve 10 Monstrous Plaguebat öldür. Bitirince Nathanos Blightcaller'a dön." }
Q[6133] = { name = "Korucu Lordun Emri", objective = "Eastern Plaguelands'in kuzey sınırlarına git ve Quel'Thalas Kaydı'nı geri al. Eşya Quel'Lithien kulübesinde bir yerde.$B$BAyrıca 8 Ranger, 8 Pathstrider ve 8 Woodsman öldürmelisin." }
Q[6135] = { name = "Duskwing, Ah Senden Nasıl Nefret Ediyorum...", objective = "Duskwing'i bul ve öldür. Cesedinden bir Duskwing Tüyü Parçası al ve Nathanos Blightcaller'a getir.$B$BDuskwing'in Marris Stead'in kuzeyindeki kırsalda dolaştığı söyleniyor." }
Q[6136] = { name = "Şişko Olan", objective = "Eastern Plaguelands'in kuzey çorak topraklarında Borelgore'u bul ve yok et. Görev tamamlanınca Nathanos Blightcaller'a dön." }
Q[6141] = { name = "Brother Anton", note = "In the Name of the Light görevine götüren giriş adımı.", objective = "Desolace'taki Brother Anton ile konuş.", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[6163] = { name = "Ramstein", note = "İsteğe bağlı giriş görevi:", objective = "Stratholme'e git ve Obur Ramstein'ı öldür. Nathanos için hatıra olarak kafasını al." }
Q[6402] = { name = "Stormwind Buluşması", objective = "Stormwind City'ye git ve şehir kapılarına ilerle. Marshal Windsor'a geldiğini bildirmesi için Squire Rowe ile konuş." }
Q[6403] = { name = "Büyük Maskeli Balo", objective = "Reginald Windsor'u Stormwind boyunca takip et. Onu zarardan koru!" }
Q[6501] = { name = "Ejderhanın Gözü", objective = "Ejderhanın Gözü Parçası'nın gücünü geri getirebilecek bir varlık için dünyayı ara. Böyle bir varlık hakkında sahip olduğun tek bilgi, var olduğu." }
Q[6502] = { name = "Drakefire Muskası", note = "Onyxia uyumlanmasının parçası.", objective = "Kara Ejderha Şampiyonunun Kanı'nı General Drakkisath'tan almalısın. Drakkisath, Blackrock Spire'da Yükseliş Salonları'nın ardındaki taht odasında bulunabilir." }
Q[6521] = { description = "Son adım. Ambassador Malcin, Razorfen Downs'ın dışında.", name = "Kirli Bir İttifak", note = "Ambassador Malcin, zindan portalından önce, dış diken labirentindeki çadırlarda. Razorfen Kraul'da Charlga Razorflank'in düşürdüğü Küçük Parşömen ile başlar.", objective = "Elçi Malcin'in Kafası'nı Undercity'deki Varimathras'a getir.", warning = "Bu görev Razorfen Downs'ın DIŞINDAKİ bölgede tamamlanır." }
Q[6522] = { name = "Kirli Bir İttifak", objective = "Küçük Parşömen'i Undercity'deki Varimathras'a götür.", pickup = "Küçük Parşömen, Charlga Razorflank düşürür" }
Q[6561] = { name = "Blackfathom'un Kötülüğü", objective = "Alacakaranlık Lordu Kelris'in başını Thunder Bluff'taki Bashana Runetotem'e götür.", pickup = "Argent Guard Thaelrid, Blackfathom Deeps içinde" }
Q[6562] = { name = "Derinliklerdeki Sorun", note = "The Essence of Aku'Mai görevine götüren giriş adımı.", objective = "Ashenvale'deki Je'neu Sancrea ile konuş.", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[6563] = { name = "Aku'Mai'nin Özü", note = "İsteğe bağlı giriş görevi:", objective = "20 Aku'Mai Safiri'ni Ashenvale'deki Je'neu Sancrea'ya götür.", pickup = "Je'neu Sancrea, Zoram'gar Outpost, Ashenvale (12, 34)" }
Q[6564] = { name = "Kadim Tanrılara Bağlılık", objective = "Islak Not'u Ashenvale'deki Je'neu Sancrea'ya götür.", pickup = "Blackfathom Tide Priestess'lerin düşürdüğü Nemli Not'u kullan" }
Q[6565] = { name = "Kadim Tanrılara Bağlılık", note = "Allegiance to the Old Gods görevinin Nemli Not sürümünden sonra gelir.", objective = "Blackfathom Deeps'te Lorgus Jett'i öldür ve ardından Ashenvale'deki Je'neu Sancrea'ya dön.", pickup = "Je'neu Sancrea, Zoram'gar Outpost, Ashenvale (12, 34)" }
Q[6566] = { name = "Rüzgârın Taşıdıkları", objective = "Thrall'ı dinle." }
Q[6567] = { name = "Horde'un Şampiyonu", objective = "Rexxar'ı bul. Savaş Şefi sana nerede olduğunu anlattı. Stonetalon Mountains ile Feralas arasındaki Desolace yollarını ara." }
Q[6568] = { name = "Rexxar'ın Vasiyeti", objective = "Rexxar'ın Mektubunu Western Plaguelands'teki Cadı Myranda'ya teslim et." }
Q[6569] = { name = "Oculus İllüzyonları", note = "Horde Onyxia zincirinin parçası. Kara Ejderha Yavrusu Gözleri UBRS'deki dragonspawn'lardan düşer.", objective = "Blackrock Spire'a git ve 20 Kara Ejderha Türevi Gözü topla. Görev tamamlandığında Cadı Myranda'ya dön." }
Q[6570] = { name = "Emberstrife", objective = "Dustwallow Marsh'taki Wyrmbog'a git ve Emberstrife'ın İni'ni bul. İçeri girince Ejderha Yıkım Muskası'nı tak ve Emberstrife ile konuş." }
Q[6582] = { name = "Kafatası Sınavı, Scryer", objective = "Mavi ejderha soyunun ejder şampiyonu Scryer'ı bul ve öldür. Kafatasını cesedinden sök ve Emberstrife'a getir.$B$BScryer'ın Winterspring'de bulunabileceğini biliyorsun." }
Q[6583] = { name = "Kafatası Sınavı, Somnus", objective = "Yeşil Soy'un ejder şampiyonu Somnus'u yok et. Kafatasını al ve Emberstrife'a getir." }
Q[6584] = { name = "Kafatası Sınavı, Chronalis", objective = "Tanaris Çölü'ndeki Caverns of Time'ı Nozdormu'nun çocuğu Chronalis koruyor. Onu yok et ve kafatasını Emberstrife'a getir." }
Q[6585] = { name = "Kafatası Sınavı, Axtroz", objective = "Grim Batol'a git ve Kızıl Soy'un ejder şampiyonu Axtroz'un izini sür. Onu yok et ve kafatasını al. Kafatasını Emberstrife'a getir." }
Q[6601] = { name = "Yükseliş...", objective = "Görünüşe göre maskaralık bitti. Cadı Myranda'nın senin için yaptığı Ejderha Yıkım Muskası'nın Blackrock Spire'da çalışmayacağını biliyorsun. Belki Rexxar'ı bulup durumunu açıklamalısın. Ona Sönük Ejder Ateşi Muskası'nı göster. Umarım ne yapılacağını bilir." }
Q[6602] = { name = "Kara Ejderha Şampiyonu'nun Kanı", note = "Onyxia uyumlanmasının parçası.", objective = "Blackrock Spire'a git ve General Drakkisath'ı öldür. Kanını topla ve Rexxar'a götür." }
Q[6626] = { name = "Kötülük Ordusu", note = "Bu yaratıklar zindanın dışında, girişin çevresinde.", objective = "8 Razorfen Savaş Muhafızı, 8 Razorfen Dikenördücüsü ve 8 Death's Head Tarikatçısı öldür ve Razorfen Downs girişinin yakınındaki Myriam Moonsinger'a dön.", pickup = "Myriam Moonsinger, Razorfen Downs diken labirenti, The Barrens", turnin = "Myriam Moonsinger, Razorfen Downs diken labirenti, The Barrens" }
Q[6627] = { name = "Bilgi Sınavı", objective = "Braug Dimspirit'in sorusunu doğru cevapla, sonra onunla tekrar konuş. Hazır olduğunda Stonetalon Mountains'ta olacak.", warning = "CEVAP: Neltharion" }
Q[6628] = { name = "Bilgi Sınavı", objective = "Parqual Fintallas'ın sorusunu doğru cevapla, sonra onunla tekrar konuş. Sen hazır olana dek Undercity'de kalacak.", warning = "CEVAP: Ner'zhul" }
Q[6921] = { name = "Harabelerin Arasında", note = "Fathom Taşı, isteğe bağlı Baron Aquanis karşılaşmasıyla da ilişkilidir.", objective = "Derinlik Çekirdeği'ni Ashenvale'deki Zoram'gar Üssü'nde bulunan Je'neu Sancrea'ya götür.", pickup = "Je'neu Sancrea, Zoram'gar Outpost, Ashenvale (12, 34)" }
Q[6922] = { name = "Baron Aquanis", objective = "Tuhaf Su Küresini Ashenvale'de Zoram'gar Outpost'taki Je'neu Sancrea'ya getir.", pickup = "Garip Su Küresi, Blackfathom Deeps içinde Baron Aquanis düşürür", warning = "Baron Aquanis, 'Amongst the Ruins' görevindeki Fathom Çekirdeği alınınca ortaya çıkar." }
Q[6981] = { name = "Parlayan Kristal Parçası", note = "Doğrudan görevin eşya ödülü yok. Devamı olan In Nightmares daha sonra şunları sunar:", objective = "Parlayan parça hakkında sana daha fazlasını anlatabilecek birini bulmak için Ratchet'a git.$B$BArdından parçayı sana söylenen yere teslim et.", objectiveWhere = "Sputtervalve, Ratchet'taki uçuş ustasının yanında (63.0, 37.2); başının üstünde ? yok", pickup = "Eşyayla başlar: Glowing Shard, Mutanus the Devourer düşürür", turnin = "Falla Sagewind, Wailing Caverns'ın üstündeki dağın tepesinde, The Barrens (48.2, 32.8)" }
Q[7028] = { name = "Çarpık Kötülükler", note = "Maraudon'daki her yaratık Theradric Kristal Oymalarını düşürebilir.", objective = "Desolace'taki Willow için 15 Theradric Kristal Oyması topla." }
Q[7029] = { name = "Vyletongue Yozlaşması", note = "Kaplanmış Gök Mavisi Şişe'yi dış mağaralardaki turuncu kristal havuzunda doldur, sonra içerideki (turuncu taraf) Vylestem Sarmaşıkları üzerinde kullan ve 8 bitkiyi iyileştirmek için Noxxious Scion'ları öldür.", objective = "Kaplamalı Gök Mavisi Şişe'yi Maraudon'daki turuncu kristal havuzda doldur.$B$BDolu Gök Mavisi Şişe'yi Vylestem Sarmaşıkları üzerinde kullanarak yozlaşmış Noxxious Filizi'nin ortaya çıkmasını sağla.$B$BBu Noxxious Filizleri'ni öldürerek 8 bitkiyi iyileştir, ardından Shadowprey Village'daki Vark Battlescar'a dön." }
Q[7041] = { name = "Vyletongue Yozlaşması", note = "Kaplanmış Gök Mavisi Şişe'yi dış mağaralardaki turuncu kristal havuzunda doldur, sonra içerideki (turuncu taraf) Vylestem Sarmaşıkları üzerinde kullan ve 8 bitkiyi iyileştirmek için Noxxious Scion'ları öldür.", objective = "Kaplamalı Gök Mavisi Şişe'yi Maraudon'daki turuncu kristal havuzda doldur.$B$BDolu Gök Mavisi Şişe'yi Vylestem Sarmaşıkları üzerinde kullanarak yozlaşmış Noxxious Filizi'nin ortaya çıkmasını sağla.$B$BBu Noxxious Filizleri'ni öldürerek 8 bitkiyi iyileştir, ardından Nijel's Point'teki Talendria'ya dön." }
Q[7044] = { name = "Maraudon Efsaneleri", note = "Celebrian Asası Noxxion'dan, Celebrian Elması ise Lord Vyletongue'dan düşer.", objective = "Celebras Asası'nın iki parçasını geri al: Celebrian Çubuğu ve Celebrian Elması.$B$BCelebras ile konuşmanın bir yolunu bul." }
Q[7046] = { name = "Celebras Asası", note = "Yolların birleştiği yerde Celebras the Cursed'ü yen ve Legends of Maraudon'u Celebras the Redeemed'e teslim et, sonra ritüeline yardım et ve asa için onunla tekrar konuş.", objective = "Kurtarılmış Celebras, Celebras Asası'nı yaratırken ona yardım et.$B$BRitüel tamamlandığında onunla konuş." }
Q[7064] = { name = "Toprağın ve Tohumun Yozlaşması", note = "İç mağarada Princess Theradras'ı öldür.", objective = "Prenses Theradras'ı öldür ve Desolace'taki Shadowprey Village yakınlarında bulunan Selendra'ya dön." }
Q[7065] = { name = "Toprağın ve Tohumun Yozlaşması", note = "İç mağarada Princess Theradras'ı öldür.", objective = "Prenses Theradras'ı öldür ve Desolace'taki Nijel's Point'te bulunan Bekçi Marandis'e dön." }
Q[7066] = { name = "Yaşam Tohumu", note = "Zaetar's Spirit, Princess Theradras öldükten sonra belirir.", objective = "Moonglade'deki Remulos'u bul ve ona Yaşam Tohumu'nu ver." }
Q[7067] = { name = "Dışlanmışın Talimatları", note = "Dış mağaralardaki Nameless Prophet'ten Ruhlar Muskası'nı al, sonra beş Khan ile savaşmak için kullan: üçü dış mağaralarda, biri mor rotada ve biri turuncu rotada. Taşlarını muskayla birleştir.", objective = "Dışlanmışın Talimatları'nı oku. Ardından Maraudon'dan Birlik Tılsımı'nı al ve güney Desolace'taki Kentaur Dışlanmışı'na götür.", pickup = "Centaur Pariah, güney Desolace", turnin = "Centaur Pariah, güney Desolace" }
Q[7068] = { name = "Gölge Kırığı Parçaları", note = "Dıştaki mor kristalli mağaralardaki Shadowshard elementalleri. Zindana girmeden yapılabilir.", objective = "Maraudon'dan 10 Gölge Kırığı Parçası topla ve Orgrimmar'daki Uthel'nay'a götür." }
Q[7070] = { name = "Gölge Kırığı Parçaları", note = "Dıştaki mor kristalli mağaralardaki Shadowshard elementalleri. Zindana girmeden yapılabilir.", objective = "Maraudon'dan 10 Gölge Kırığı Parçası topla ve Dustwallow Marsh kıyısındaki Theramore'da bulunan Başbüyücü Tervosh'a götür." }
Q[7201] = { name = "Son Element", note = "Elementlerin Özü, BRD elementallerinden ve golemlerinden düşer.", objective = "Blackrock Depths'e git ve 10 Elementlerin Özü topla. İlk aklına gelen golemleri ve golem yapımcılarını aramak. Vivian Lagrave'in de elementallerle ilgili bir şeyler mırıldandığını hatırlıyorsun.$B" }
Q[7441] = { name = "Pusillin ve Yaşlı Azj'Tordin", note = "Pusillin'i kanat boyunca kovala ve o savaşana kadar onunla konuş, sonra kitap için onu öldür. Hilal Anahtarı'nı da düşürür.", objective = "Dire Maul'a git ve imp Pusillin'i bul. Gereken her yolu kullanarak Pusillin'i sana Azj'Tordin'in Büyü Kitabı'nı vermeye ikna et.$B$BBüyü Kitabı'nı geri alırsan Feralas'taki Lariss Pavilion'da bulunan Azj'Tordin'e dön." }
Q[7461] = { name = "İçerideki Delilik", note = "Beş pilonun hepsinin muhafızlarını, sonra Immol'thar'ı, sonra Prince Tortheldrin'i öldür. Ancient'a dön, The Treasure of the Shen'dralar'ı al ve ödül için kütüphane merdivenlerinin altındaki sandığı aç.", objective = "Immol'thar'ın Hapishanesi'ne güç veren 5 Kule'yi çevreleyen muhafızları yok etmelisin. Kuleler devre dışı kaldığında Immol'thar'ı çevreleyen güç kalkanı dağılmış olacak.$B$BSonra Immol'thar'ın Hapishanesi'ne gir ve kalbinde duran iğrenç iblisi yok et. Son olarak Athenaeum'da Prens Tortheldrin'le yüzleş.$B$BBu görevi tamamlarsan avludaki Shen'dralar Kadimi'ne dön." }
Q[7463] = { name = "Gizemli Ferahlık", note = "Mage sınıf görevi. Lydros, Athenaeum'da (Kuzey/Batı); Hydrospawn Özü, Doğu'daki Hydrospawn'dan düşer. Ödül: Conjure Water (Rütbe 7).", objective = "Dire Maul'un Warpwood Quarter bölgesine git ve su elementali Hydrospawn'ı öldür. Hydrospawn Özü ile Athenaeum'daki Bilge Lydros'a dön." }
Q[7481] = { name = "Elf Efsaneleri", note = "Athenaeum'da Lorekeeper Lydros'un yanındaki Telmius Dreamseeker'ın İskelet Kalıntıları ile etkileşime geç. Lydros'un libram takaslarını açar.", objective = "Dire Maul'da Kariel Winthalus'u ara. Bulabildiğin her bilgiyle Camp Mojache'deki Bilge Korolusk'a rapor ver." }
Q[7482] = { name = "Elf Efsaneleri", note = "Athenaeum'da Lorekeeper Lydros'un yanındaki Telmius Dreamseeker'ın İskelet Kalıntıları ile etkileşime geç. Lydros'un libram takaslarını açar.", objective = "Dire Maul'da Kariel Winthalus'u ara. Bulabildiğin her bilgiyle Feathermoon'daki Bilgin Runethorn'a rapor ver." }
Q[7483] = { name = "Çabukluk Duaları Kitabı", note = "Tekrarlanabilir. Önce fraksiyonunun Elven Legends görevinin teslim edilmiş olması gerekir.", objective = "Çabukluk Mührü almak için bir Çabukluk Duaları Kitabı, 1 Kusursuz Siyah Elmas, 2 Büyük Parlak Kristal ve 2 Kahramanların Kanı'nı Dire Maul'daki Bilge Lydros'a getir." }
Q[7484] = { name = "Odak Duaları Kitabı", note = "Tekrarlanabilir. Önce fraksiyonunun Elven Legends görevinin teslim edilmiş olması gerekir.", objective = "Odak Mührü almak için bir Odak Duaları Kitabı, 1 Kusursuz Siyah Elmas, 4 Büyük Parlak Kristal ve 2 Gölge Derisi'ni Dire Maul'daki Bilge Lydros'a getir." }
Q[7485] = { name = "Koruma Duaları Kitabı", note = "Tekrarlanabilir. Önce fraksiyonunun Elven Legends görevinin teslim edilmiş olması gerekir.", objective = "Koruma Mührü almak için bir Koruma Duaları Kitabı, 1 Kusursuz Siyah Elmas, 2 Büyük Parlak Kristal ve 1 Yıpranmış Abomination Dikişi'ni Dire Maul'daki Bilge Lydros'a getir." }
Q[7488] = { name = "Lethtendris'in Ağı", note = "Ağ, Lethtendris'ten düşer.\n\nİsteğe bağlı giriş görevi:", objective = "Lethtendris'in Ağı'nı Feralas'taki Feathermoon Stronghold'da bulunan Latronicus Moonspear'a götür." }
Q[7489] = { name = "Lethtendris'in Ağı", note = "Ağ, Lethtendris'ten düşer.\n\nİsteğe bağlı giriş görevi:", objective = "Lethtendris'in Ağı'nı Feralas'taki Camp Mojache'de bulunan Talo Thornhoof'a götür." }
Q[7492] = { name = "Camp Mojache", note = "Lethtendris's Web görevine götüren giriş adımı.", objective = "Feralas'taki Camp Mojache'de bulunan Talo Thornhoof ile konuş.", pickup = "Harbinger Balthazad, Undercity (veya Warcaller Gorlach, Orgrimmar / Bluff Runner Windstrider, Thunder Bluff)", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[7494] = { name = "Feathermoon Stronghold", note = "Lethtendris's Web görevine götüren giriş adımı.", objective = "Feralas'taki Feathermoon Stronghold'da bulunan Latronicus Moonspear ile konuş.", pickup = "Crier Goodman, Stormwind (veya Courier Hammerfall, Ironforge / Herald Moonstalker, Darnassus)", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[7498] = { name = "Garona: Gizlilik ve İhanet Üzerine Bir İnceleme", note = "Rogue sınıf kitabı. Görevi başlatmak için kitaba tıkla.", objective = "Kitabı gerçek sahiplerine geri götür.", pickup = "Garona: A Study on Stealth and Treachery (kitap, Dire Maul ganimeti)" }
Q[7499] = { name = "Savunma Kodeksi", note = "Warrior sınıf kitabı. Görevi başlatmak için kitaba tıkla.", objective = "Kitabı gerçek sahiplerine geri götür.", pickup = "Codex of Defense (kitap, Dire Maul ganimeti)" }
Q[7500] = { name = "Arcanist'in Yemek Kitabı", note = "Mage sınıf kitabı. Görevi başlatmak için kitaba tıkla.", objective = "Kitabı gerçek sahiplerine geri götür.", pickup = "The Arcanist's Cookbook (kitap, Dire Maul ganimeti)" }
Q[7501] = { name = "Işık ve Onu Nasıl Savurmalı", note = "Paladin sınıf kitabı. Görevi başlatmak için kitaba tıkla.", objective = "Kitabı gerçek sahiplerine geri götür.", pickup = "The Light and How To Swing It (kitap, Dire Maul ganimeti)" }
Q[7502] = { name = "Gölgeleri Dizginlemek", note = "Warlock sınıf kitabı. Görevi başlatmak için kitaba tıkla.", objective = "Kitabı gerçek sahiplerine geri götür.", pickup = "Harnessing Shadows (kitap, Dire Maul ganimeti)" }
Q[7503] = { name = "Avcıların En Büyük Irkı", note = "Hunter sınıf kitabı. Görevi başlatmak için kitaba tıkla.", objective = "Kitabı gerçek sahiplerine geri götür.", pickup = "The Greatest Race of Hunters (kitap, Dire Maul ganimeti)" }
Q[7504] = { name = "Kutsal Saçmalık: Işık'ın Sana Söylemedikleri", note = "Priest sınıf kitabı. Görevi başlatmak için kitaba tıkla.", objective = "Kitabı gerçek sahiplerine geri götür.", pickup = "Holy Bologna: What the Light Won't Tell You (kitap, Dire Maul ganimeti)" }
Q[7505] = { name = "Ayaz Şoku ve Sen", note = "Shaman sınıf kitabı. Görevi başlatmak için kitaba tıkla.", objective = "Kitabı gerçek sahiplerine geri götür.", pickup = "Frost Shock and You (kitap, Dire Maul ganimeti)" }
Q[7506] = { name = "Zümrüt Rüya...", note = "Druid sınıf kitabı. Görevi başlatmak için kitaba tıkla.", objective = "Kitabı gerçek sahiplerine geri götür.", pickup = "The Emerald Dream (kitap, Dire Maul ganimeti)" }
Q[7507] = { name = "Foror'un Derlemesi", note = "Warrior ve Paladin'ler. Lydros ardından Onyxia's Lair'de tamamlanan The Forging of Quel'Serrar'ı verir.", objective = "Foror'un Ejderha Avcılığı Derlemesi'ni Athenaeum'a geri götür.", pickup = "Nostro's Compendium of Dragon Slaying (nadir Dire Maul ganimeti)" }
Q[7563] = { name = "Kanın Öfkesi", objective = "30 şişe Kudurmuş Canavar Kanı'nı Burning Steppes'teki Mor'zul Bloodbringer'a getir." }
Q[7564] = { name = "Wildeyes", objective = "Kan Kutusu'nu Burning Steppes'teki Gorzeeki Wildeyes'a getir." }
Q[7604] = { name = "Bağlayıcı Bir Sözleşme", note = "Demircilik. Sözleşmeyi almak için Grim Guzzler'daki Lokhtos'a bir Sulfuron Külçesi (Golemagg, Molten Core) getir, sonra Sulfuron Çekici planları için geri teslim et.", objective = "Sulfuron planlarını almak istiyorsan Thorium Brotherhood Sözleşmesi'ni Lokhtos Darkbargainer'a teslim et.", pickup = "Thorium Brotherhood Sözleşmesi (bir Sulfuron Külçesi karşılığında Lokhtos Darkbargainer'dan)" }
Q[7623] = { name = "Lord Banehollow", objective = "Burning Steppes'teki Gorzeeki'den Gölgeli İksir satın al.$B$BBu iksirleri kullanarak Jaedenar'dan geç ve Lord Banehollow ile konuş." }
Q[7624] = { name = "Hain Ulathek", objective = "Ulathek ile yüzleş, ardından Hainin Kalbi'ni Jaedenar'daki Lord Banehollow'a getir." }
Q[7625] = { name = "Xoroth Yıldız Tozu", objective = "Ur'dan'dan Xoroth Yıldız Tozu satın al. Onu Burning Steppes'teki Gorzeeki Wildeyes'a getir." }
Q[7626] = { name = "Dethmoora'nın Çanı", objective = "10 Gölge Gücü İksiri'ni Burning Steppes'teki Gorzeeki Wildeyes'a getir." }
Q[7627] = { name = "Kara Yürüyüş Çarkı", objective = "6 Büyük Parlak Kırık ve 25 Dark Iron Cevheri'ni Burning Steppes'teki Gorzeeki'ye getir." }
Q[7628] = { name = "Kıyamet Mumu", objective = "35 Kara Ejderha Pulu'nu Burning Steppes'teki Gorzeeki Wildeyes'a getir." }
Q[7629] = { name = "Imp Teslimatı", note = "Warlock dreadsteed görevi. Ras Frostwhisper'ın odasındaki simya laboratuvarında Kavanozdaki İmp'i serbest bırak ve parşömeni bekle.", objective = "Kavanozdaki Imp'i Scholomance'taki simya laboratuvarına götür. Parşömen yapıldıktan sonra kavanozu Gorzeeki Wildeyes'a geri getir." }
Q[7630] = { name = "Arcanite", objective = "3 Arcanite Külçesi'ni Burning Steppes'teki Gorzeeki'ye getir." }
Q[7631] = { name = "Xoroth'un Dreadsteed'i", note = "Warlock dreadsteed görevi. Immol'thar öldükten sonra J'eevee'nin Kavanozu, Kara Mıknatıs Taşı ve Xorothian Glifleri ile onun hapishanesinde ritüeli yap. Ruh Kırıkları getir.", objective = "Mor'zul'un Talimatları'nı oku. Bir Xoroth Dreadsteed'i çağır, onu yen ve ruhunu kendine bağla." }
Q[7637] = { name = "Fedakârlığa Vurgu", objective = "Ironforge'a git ve Yüksek Rahip Rohan'ın Şeytan Kovma Buhurdanı'nı al. Onu edinmek için 150 altın bağış yapman gerekecek." }
Q[7639] = { name = "Hak Edilmiş Adaleti Göstermek", objective = "Şeytan Kovma Buhurdanı'nı Stormwind'in Cathedral District'indeki Lord Grayson Shadowbreaker'a götür." }
Q[7640] = { name = "Terrordale'i Arındırmak", objective = "Şeytan Kovma Buhurdanı'nı kullanarak Terrordale'e eziyet eden ruhları kov. 25 Terrordale Ruhu'nu öldürdüğünde Stormwind'in Cathedral District'indeki Lord Grayson Shadowbreaker'a dön." }
Q[7641] = { name = "Grimand Elmore'un Ustalığı", objective = "Stormwind'in Dwarven District'indeki Grimand Elmore ile konuş." }
Q[7642] = { name = "Malzeme Toplama", objective = "40 Runecloth, 6 Arcanite Külçesi, 10 Arthas' Tears, 5 şişe Stratholme Kutsal Suyu ve 150 altını Stormwind'in Dwarven District'indeki Grimand Elmore'a götür." }
Q[7643] = { name = "Kadim At Ruhu", note = "Paladin savaş atı görevi. Tendris Warpwood'u öldür, sonra Ancient Equine Spirit'i besle ve ona Arcanite Barding'i ver. Manna ile Zenginleştirilmiş At Yemi'ni Southshore'daki Merideth Carlson'dan getir.", objective = "Bir ruh atını beslemek için kullanılan özel at yemini edin. Görünüşe göre bu yemin kaynağı Southshore'daki Merideth Carlson.$B$BFeralas'taki Dire Maul zindanına git ve Tendris Warpwood'u öldür. Böylece Kadim At Ruhu'nu özgür bırakacaksın. Ona özel at yemini yedirerek ruhu yatıştır. Son olarak, kutsaması için ona Arcanite At Zırhı'nı ver." }
Q[7644] = { name = "Kutsanmış Arcanite At Zırhı", objective = "Kutsanmış Arcanite At Zırhı ile Stormwind'in Cathedral District'indeki Lord Grayson Shadowbreaker'a dön." }
Q[7645] = { name = "Mana ile Zenginleştirilmiş At Yemi", objective = "Southshore, Hillsbrad Foothills'teki Merideth Carlson için Mana ile Zenginleştirilmiş At Yemi'nin temel malzemesi olan 20 Zenginleştirilmiş Mana Bisküvisi getir. Bisküvilerin tek satıcısının Argent Dawn olduğu biliniyor.$B$BAyrıca kırılan gururunu okşamak için ona 50 altın vermen gerekiyor." }
Q[7646] = { name = "Kehanet Kristali", objective = "Bir Azerothian Elmas ile bir Kusursuz Kara Elmas'ı Stormwind'in Cathedral District'indeki Lord Grayson Shadowbreaker'a götür." }
Q[7647] = { name = "Hüküm ve Kurtuluş", note = "Paladin savaş atı görevi. Great Ossuary'de Rattlegore'un bodrumunu temizle, Divination Scryer'ı kullan ve ruhları ve Death Knight Darkreaver'ı yen.", objective = "Kehanet Kristali'ni Scholomance'taki Great Ossuary'nin bodrumunun tam ortasında kullan. Bu, yargılaman gereken ruhları ortaya çıkaracak. Bu ruhları yenmek Ölüm Şövalyesi Darkreaver'ı çağıracak. Onu yen ve düşmüş savaş atının kayıp ruhunu geri al.$B$BSavaş Atının Kurtarılmış Ruhu'nu ve Kutsanmış Efsunlu At Zırhı'nı Darkreaver'ın Düşmüş Savaş Atı'na ver." }
Q[7648] = { name = "Grimand'ın En İyi İşi", objective = "Arcanite At Zırhı'nı incelemesi için Stormwind'in Cathedral District'indeki Lord Grayson Shadowbreaker'a götür." }
Q[7667] = { name = "Maddi Yardım", objective = "Orgrimmar'ın Valley of Wisdom bölgesindeki Sagorne Crestrider'a yardım etmek istersen ona bir Azeroth Elması ve bir Kusursuz Kara Elmas getir." }
Q[7668] = { name = "Darkreaver Tehdidi", note = "Shaman görevi. Rattlegore'un bodrumunu temizle, kâhin aletini kullan ve Death Knight Darkreaver'ı yen; kafasını geri getir.", objective = "Scholomance'taki Great Ossuary'nin bodrumunun tam ortasında Kehanet Aleti'ni kullan. Bu, savaşman gereken ruhları ortaya çıkaracak. Bu ruhları yenmek Ölüm Şövalyesi Darkreaver'ı çağıracak; onu yen.$B$BDarkreaver'ın Kellesi'ni Orgrimmar'daki Valley of Wisdom'da Sagorne Creststrider'a götür." }
Q[7703] = { name = "Gordok'un Yarım Kalan İşi", note = "Batı hedefi: Gordok Gücü Eldiveni, Prince Tortheldrin'in yakınındaki bir sandıkta. Görevin kendisi, Gordok kralı olduktan sonra Dire Maul North'taki dost Captain Kromcrush'tan gelir.", objective = "Gordok Kudreti Demir Eldiveni'ni bul ve Dire Maul'daki Kaptan Kromcrush'a geri getir.$B$BKromcrush'a göre \"eski zaman hikâyesi\", kendine prens diyen \"ürkütücü\" bir elf olan Tortheldrin'in onu Gordok krallarından birinden çaldığını söylüyor." }
Q[7761] = { name = "Blackhand'in Emri", note = "Scarshield Quartermaster, Spire portalının dışındaki koridorda. General Drakkisath'ın arkasındaki Drakkisath's Brand'e dokun; bu, Blackwing Lair'e giden Orb of Command kısayolunu açar.", objective = "Bu ork gerçekten aptalın teki. Görünüşe göre Komuta Küresi'ne erişmek için bu dağlama demirini bulup Drakkisath'ın Damgası'nı edinmen gerekiyor.$B$BMektuba göre dağlama demirini General Drakkisath koruyor. Belki de araştırmalısın.", pickup = "Blackhand's Command (Scarshield Quartermaster'dan mektup, Blackrock Mountain)" }
Q[7848] = { name = "Çekirdeğe Uyumlanma", note = "Çekirdek Parçası, BRD'nin derinlerinde Molten Core portalının yanındaki kayanın üzerinde. Lothos'un Molten Core'a ışınlamasını açar.", objective = "Blackrock Depths'teki Molten Core giriş geçidine git ve bir Çekirdek Parçası al. Çekirdek Parçası'nı aldığında Blackrock Mountain'daki Lothos Riftwaker'a dön." }
Q[8151] = { name = "Avcının Tılsımı", note = "The Green Drake görevine götüren giriş adımı.", objective = "Azshara'daki Ogtinc ile konuş.", pickup = "Hunter eğitmenleri", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[8153] = { name = "Koşucu Geyik Boynuzları", objective = "Azshara'daki Ogtinc'e bir çift Kusursuz Koşucu Geyik Boynuzu getir. Ogtinc, Ruins of Eldarath'ın kuzeydoğusundaki yamaçların tepesinde yaşıyor." }
Q[8231] = { name = "Dalgadöven Avı", objective = "Azshara'daki Ogtinc'e 6 Dalgadöven Pulu getir. Ogtinc, Ruins of Eldarath'ın kuzeydoğusundaki yamaçların tepesinde yaşıyor." }
Q[8232] = { name = "Yeşil Ejder", note = "Hunter sınıf görevi. Morphaz'ın Dişi Morphaz'dan düşer.\n\nİsteğe bağlı giriş görevi:", objective = "Morphaz'ın Dişi'ni Azshara'daki Ogtinc'e getir. Ogtinc, Ruins of Eldarath'ın kuzeydoğusundaki yamaçların tepesinde yaşıyor." }
Q[8233] = { name = "Basit Bir Rica", note = "The Azure Key görevine götüren giriş adımı.", objective = "Ravenholdt Malikânesi'ndeki Lord Jorach Ravenholdt ile konuş.", pickup = "Rogue eğitmenleri", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[8234] = { name = "Mühürlü Mavi Kese", objective = "Mühürlü Mavi Kese'yi Azshara'daki Timbermaw Şamanı'ndan geri al. Sonra keseyi yine Azshara'da bulunan Başbüyücü Xylem'e götür." }
Q[8235] = { name = "Şifreli Parçalar", objective = "Azshara'daki Başbüyücü Xylem'e 10 Şifreli Parça getir." }
Q[8236] = { name = "Mavi Anahtar", note = "Rogue sınıf görevi. Gök Mavisi Anahtar Morphaz'dan düşer.\n\nİsteğe bağlı giriş görevi:", objective = "Mavi Anahtar'ı Lord Jorach Ravenholdt'a götür." }
Q[8250] = { name = "Büyücülük Sanatı", note = "Destroy Morphaz görevine götüren giriş adımı.", objective = "Sanath Lim-yo'yu bul ve Başbüyücü Xylem'i görmek için geçiş izni al.", pickup = "Mage eğitmenleri", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[8251] = { name = "Büyülü Toz", objective = "Başbüyücü Xylem'e 10 Parıltılı Toz getir." }
Q[8252] = { name = "Sirenin Mercanı", objective = "6 Büyülü Mercan topla ve Başbüyücü Xylem'e dön." }
Q[8253] = { name = "Morphaz'ı Yok Et", note = "Mage sınıf görevi. Arkan Kırığı Morphaz'dan düşer.\n\nİsteğe bağlı giriş görevi:", objective = "Morphaz'dan Gizemli Kristal Parçası'nı al ve Başbüyücü Xylem'e dön." }
Q[8254] = { name = "Cenarion Yardımı", note = "Blood of Morphaz görevine götüren giriş adımı.", objective = "Azshara'daki Ogtinc'i bul.", pickup = "Priest eğitmenleri", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[8255] = { name = "Koşucuları İyi Tanırız", objective = "4 Sağlıklı Koşucu Bezi edin ve Azshara'daki Ogtinc'e getir. Ogtinc, Ruins of Eldarath'ın kuzeydoğusundaki uçurumların tepesinde yaşar." }
Q[8256] = { name = "Ölümsüzlüğün İrini", objective = "Azshara'daki Ogtinc için bir Ölümsüzlük İrini edin. Ogtinc, Ruins of Eldarath'ın kuzeydoğusundaki uçurumların tepesinde yaşar." }
Q[8257] = { name = "Morphaz'ın Kanı", note = "Priest sınıf görevi. Morphaz'ın kanı Ogtinc'e değil, Greta Mosshoof'a teslim edilir.\n\nİsteğe bağlı giriş görevi:", objective = "Batık Atal'Hakkar tapınağında Morphaz'ı öldür ve kanını Felwood'daki Greta Mosshoof'a götür. Batık tapınağın girişi Swamp of Sorrows'ta bulunur." }
Q[8410] = { name = "Element Ustalığı", objective = "Rüzgârgözcüsü Bath'rah için hava, ateş, toprak ve su örneklerini topla." }
Q[8412] = { name = "Ruh Totemi", objective = "Ruh totemi için gereken parçaları Rüzgârgözcüsü Bath'rah'a getir." }
Q[8413] = { name = "Vudu İşi", note = "Shaman sınıf görevi. Altı trol muhafızından 2 kehribar, 2 mavi ve 2 yeşil Vudu Tüyü gerekir: Gasher, Mijan, Zolo, Hukku, Zul'Lor ve Loro.", objective = "Vudu tüylerini Rüzgârgözcüsü Bath'rah'a getir." }
Q[8414] = { name = "Kötülüğü Arındırmak", objective = "20 Hizmetkâr Scourge Taşı topla ve Western Plaguelands'teki Yüksek Rahip Thel'danis'e götür." }
Q[8415] = { name = "Chillwind Point", note = "Forging the Mightstone görevine götüren giriş adımı.", objective = "Chillwind Camp'teki Komutan Ashlam Valorfist ile konuş.", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[8416] = { name = "Etkisiz Scourge Taşları", objective = "Etkisiz Scourge Taşı'nı Chillwind Point'teki Komutan Ashlan Valorfist'e götür." }
Q[8417] = { name = "Huzursuz Bir Ruh", note = "Voodoo Feathers görevine götüren giriş adımı.", objective = "Blasted Lands'in girişindeki Horde'un Düşmüş Kahramanı ile konuş.", pickup = "Warrior eğitmenleri", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[8418] = { name = "Kudret Taşı'nı Dövmek", note = "Paladin sınıf görevi. Altı trol muhafızından 2 kehribar, 2 mavi ve 2 yeşil Vudu Tüyü gerekir: Gasher, Mijan, Zolo, Hukku, Zul'Lor ve Loro.\n\nİsteğe bağlı giriş görevi:", objective = "Vudu tüylerini Ashlam Valorfist'e götür." }
Q[8419] = { name = "Bir Imp'in Ricası", objective = "Felwood'daki Impsy'ye bir parça fel kumaşı getir.", pickup = "Sınıf eğitmenin" }
Q[8420] = { name = "Sıcak ve Kaşındırıcı", objective = "Felwood'daki Impsy'ye bir parça fel kumaşı getir." }
Q[8421] = { name = "Yanlış Malzeme", objective = "10 Çürüyen Odun ve 4 Bloodvenom Özütü'nü Felwood'daki Impsy'ye getir." }
Q[8422] = { name = "Aynı Tüyün Trolleri", note = "Warlock sınıf görevi. Altı trol muhafızından 2 kehribar, 2 mavi ve 2 yeşil Vudu Tüyü gerekir: Gasher, Mijan, Zolo, Hukku, Zul'Lor ve Loro.", objective = "Batık tapınaktaki trollerden toplam 6 Vudu Tüyü getir." }
Q[8423] = { name = "Savaşçı Akrabalığı", objective = "Blasted Lands'te 7 Helboar öldür ve Horde'un Düşmüş Kahramanı'na dön." }
Q[8424] = { name = "Shadowsworn'a Karşı Savaş", objective = "Blasted Lands'teki Shadowsworn'u katlet ve Horde'un Düşmüş Kahramanı'na dön." }
Q[8425] = { name = "Voodoo Tüyleri", note = "Her iki fraksiyon için Warrior sınıf görevi. Altı trol muhafızından 2 kehribar, 2 mavi ve 2 yeşil Vudu Tüyü gerekir: Gasher, Mijan, Zolo, Hukku, Zul'Lor ve Loro.\n\nİsteğe bağlı giriş görevi:", objective = "Sunken Temple'daki Troll'lardan aldığın Voodoo Tüyleri'ni Horde'un Düşmüş Kahramanı'na getir." }
Q[8945] = { name = "Ölü Adamın Yakarışı", note = "Süreli: Baron Rivendare'i 45 dakika içinde öldürerek Ysida Harmon'u kurtar. Anthion'u görmek için Boyutlar Ötesi Hayalet Gösterici'yi kullan.", objective = "Stratholme'e gir ve Ysida Harmon'u Baron Rivendare'in elinden kurtar." }
Q[9051] = { name = "Zehir Testi", objective = "Devilsaur Dikeni'ni bir Devilsaura sapla. Bu görevi tamamladığında Un'Goro Crater'daki Torwa Pathfinder'a dön." }
Q[9052] = { name = "Kanyaprağı Zehri", objective = "8 Kan Başlığı ve 8 Gorishi İğnesi topla, ardından Un'Goro Crater'daki Torwa Pathfinder'a dön." }
Q[9053] = { name = "Daha İyi Bir Malzeme", note = "Druid sınıf görevi. Çürümüş Sarmaşık, tapınak bodrumundaki Atal'alarion'dan düşer.\n\nİsteğe bağlı giriş görevi:", objective = "Sunken Temple'ın dibindeki muhafızdan bir Çürümüş Sarmaşık al ve Torwa Pathfinder'a dön." }
Q[9063] = { name = "Torwa Pathfinder", note = "A Better Ingredient görevine götüren giriş adımı.", objective = "Un'Goro Crater'daki Torwa Pathfinder ile konuş.", pickup = "Druid eğitmenleri", warning = "İSTEĞE BAĞLI, gerekli değil" }
Q[78261] = { name = "Xelthos'un Borusu", objective = "Shadowfang Keep'in içinde Xelthos'un Borusu'nu bul. Ardından onu Pyrewood Village yakınlarındaki C'nin gizli teslim noktasına götür. Bu işi tek başına tamamlamalısın.", warning = "Tek kişilik iş: herhangi bir grubun dışında, tek başına yapmalısın." }
Q[78307] = { description = "C'nin bir sonraki mektubu sana bir başkentte ulaştıktan sonra sunulur.", name = "Xelthos'un Borusu", note = "Rogue sınıf görevi. C'nin mektubu 20. seviyede bir başkentte gelir; işi Pyrewood Village yakınındaki Dead Drop'tan al. Bir çanta yuvasını boş tut.", objective = "C'nin ödemesini Pyrewood Village yakınındaki Dead Drop'tan al.", warning = "Tek kişilik iş: herhangi bir grubun dışında, tek başına yapmalısın." }
Q[78676] = { name = "Bhossca'nın Gözü", objective = "Scarlet Monastery'nin içinde Bhossca'nın Gözü'nü bul. Ardından onu Pyrewood Village yakınındaki C'nin gizli bırakma noktasına götür. Bu işi tek başına tamamlamalısın.", warning = "Tek kişilik iş: herhangi bir grubun dışında, tek başına yapmalısın." }
Q[78699] = { description = "C'nin bir sonraki mektubu sana bir başkentte ulaştıktan sonra sunulur.", name = "Bhossca'nın Gözü", note = "The Horn of Xelthos'tan sonraki Rogue sınıf görevi; C'nin bir sonraki mektubu (yaklaşık 30. seviyede) seni Dead Drop'a geri gönderir. Her kanatta Scarlet Initiate's Uniform giy: gizlenmek ya da saldırmak onu çıkarır.", objective = "Kayıt", warning = "Tek kişilik iş: herhangi bir grubun dışında, tek başına yapmalısın." }
Q[79007] = { objective = "Notun kömürleşmiş kalıntıları tek rehberin.", pickup = "Camp Taurajo'nun güneyindeki yol üzerinde yanık kuledeki yanmış kalıntılar, The Barrens (46.3, 73.9)", turnin = "Alexston Farmstead'deki araba enkazının içindeki yanmış kalıntılar, Westfall (37.3, 50.6)" }
Q[79008] = { name = "... ve bulduğun o not", objective = "Notun yanmış kalıntıları tek rehberin.", pickup = "Alexston Farmstead'deki araba enkazının içindeki yanmış kalıntılar, Westfall (37.3, 50.6)", turnin = "Camp Taurajo'nun güneyindeki yol üzerinde yanık kuledeki yanmış kalıntılar, The Barrens (46.3, 73.9)" }
Q[79192] = { name = "Basamak Taşları", note = "Sun Rock Retreat'in (50.9, 52.3) kuzeydoğusundaki yoldan terk edilmiş kampa çık; cep döküntüleri bir kutunun üzerinde. İsteğe bağlı: bu görevden gelen Basit Odun ve Çakmaktaşı ile kampın ortasındaki ateş çukurunu yak (Rekindle).", objective = "Notu tahtadan koparıp üzerindeki karalanmış yazıyı okuyorsun.", pickup = "Camp Taurajo'nun güneyindeki yanık kulenin yanında çivili tahta, The Barrens (46.4, 73.8)", turnin = "Terk edilmiş kamptaki bir kutunun üzerinde cep döküntüleri, Stonetalon Mountains (40.8, 52.6)" }
Q[79974] = { name = "Islak İş", note = "Heykelciğe ulaşmak için barajın Wetlands'e bakan tarafındaki oyma kafaların üzerine atla. Oraya ulaşmak Horde için zordur.", objective = "Topraktan baş gösteren bir haberci çantasının tozunu silkelediğinde, erzakların arasına sıkışmış bir parşömen buluyorsun.", pickup = "Kampın kuzeyindeki uçurumun altındaki toprak yığını, Stonetalon Mountains (39.6, 49.9)", turnin = "Stonewrought Dam'in oyma kafalarının üzerindeki oyma heykelcik, Loch Modan (49.4, 12.9)" }
Q[79975] = { name = "Kartal Yumruğu", note = "Hillsbrad tarafındaki arabadan (87.3, 49.6) Thoradin's Wall'a tırman, duvardaki odadan geç ve dışarıya, sağa bak: çanta orada asılı.", objective = "Su serpintisi havayı nemlendiriyor, manzara inanılmaz.", pickup = "Stonewrought Dam'in oyma kafalarının üzerindeki oyma heykelcik, Loch Modan (49.4, 12.9)", turnin = "Thoradin's Wall'da asılı Ulak Çantası, Hillsbrad Foothills (85.7, 52.2)" }
Q[79976] = { name = "Burası Olmalı", objective = "Burada her kim idiyse, onları kıl payı kaçırdın.", pickup = "Thoradin's Wall'da asılı Ulak Çantası, Hillsbrad Foothills (85.7, 52.2)", turnin = "Aceleyle Sarılmış Heybe, Ulak Çantası'nın hemen altında" }
Q[79980] = { name = "Telaş", note = "Kamptan dümdüz kuzeye git, tepeye tırman ve kenarından toprak yığınına atla. Adımına dikkat et.", objective = "Seni neyin beklediğini bul.", pickup = "Terk edilmiş kamptaki bir kutunun üzerinde cep döküntüleri, Stonetalon Mountains (40.8, 52.6)", turnin = "Kampın kuzeyindeki uçurumun altındaki toprak yığını, Stonetalon Mountains (39.6, 49.9)" }
Q[92401] = { name = "Korku Dolu Bir Rica", objective = "Ruins of Lordaeron'da Edward Heartweaver'ın ortadan kayboluşunu araştır." }
Q[92415] = { name = "Seni Sevdiğimi Unutma", note = "Blood-Stained Letter ile başlayan görev.", objective = "Kana Bulanmış Mektup'u Stormwind City'deki Yetimhane Başhemşiresi Nightingale'e götür.", pickup = "Eşyayla başlar: Blood-Stained Letter, Ruins of Lordaeron içindeki mezarlık" }
Q[92421] = { name = "Işığın Adaleti", objective = "Undercity'deki Morbin Lightbane için The Ruins of Lordaeron'da 25 Sağlam Uzuv topla." }
Q[92422] = { name = "Rath'mael'in Gazabı", objective = "Brill'deki Ölüm Muhafızı Kristof için Ruins of Lordaeron'da Rath'mael'i öldür." }
Q[92432] = { description = "Heart of Disruption ve Starving Arcane görevlerine götüren giriş görevi.", name = "Endişe Verici Bir Talep", objective = "City of Dalaran yakınlarındaki Başbüyücü Modera'nın Sureti'ne rapor ver.", turnin = "Image of Archmage Modera, Dalaran yakınındaki Lordamere Lake" }
Q[92434] = { name = "Sokaklarda Kan", note = "Magus Wordeen Voidglare'in Dalaran görevleri gerekir. Keeper Bel'varil'in Stone Tokens ve Bracers of Binding görevleri isteğe bağlıdır, uyumlanma için gerekli değildir.", objective = "Lordamere Lake boyunca Dalaran'a girmenin bir yolunu bul.", turnin = "Image of Archmage Modera, Dalaran yakınındaki Lordamere Lake" }
Q[92456] = { name = "Yeşil Bir Numune", note = "Görev verisi betada kaydedildi; zindana erişim mümkün olmayabilir.", objective = "Stormwind City'deki Shylamiir için City of Dalaran'dan bir Fel Aşılı Çiçek topla." }
Q[92457] = { name = "Arkan Açlığı", note = "İçeride bu yaratıklardan tek seferde bitirmeye yetecek kadar olmayabilir.", objective = "Dalaran'ın dışındaki Başbüyücü Modera için City of Dalaran'ın içinde 8 Seeking Remnant, 8 Saturated Remnant ve 8 Mana Echo yen.", pickup = "Image of Archmage Modera, Dalaran yakınındaki Lordamere Lake", turnin = "Image of Archmage Modera, Dalaran yakınındaki Lordamere Lake" }
Q[92458] = { name = "Bozulmanın Kalbi", objective = "City of Dalaran yakınlarındaki Başbüyücü Modera'nın Sureti için Arkan Zerre'yi topla.", pickup = "Image of Archmage Modera, Dalaran yakınındaki Lordamere Lake", turnin = "Image of Archmage Modera, Dalaran yakınındaki Lordamere Lake" }
Q[92489] = { name = "Ezici Güç", note = "Görev verisi betada kaydedildi; zindana erişim mümkün olmayabilir.", objective = "Stormwind City'deki Yüce Büyücü Andromath için City of Dalaran'daki Mana Elementali'ni öldür." }
Q[92742] = { description = "Toxic Soil zincirinin ilk görevi.", name = "Kuyuları Test Etmek", objective = "Kuyu Suyu Örnek Kiti'ni kullanarak Jansen Stead ve Molsen Farm'daki kuyulardan örnek al.", pickup = "Alba Fairmoon, Sentinel Hill hanı, Westfall", turnin = "Alba Fairmoon, Sentinel Hill hanı, Westfall" }
Q[92744] = { description = "Toxic Soil zincirinin ikinci görevi.", name = "Murloc Solungaçları", objective = "Alba Fairmoon, Westfall kıyı şeridi boyunca 7 Longshore Murloc Solungacı toplamanı istiyor.", pickup = "Alba Fairmoon, Sentinel Hill hanı, Westfall", turnin = "Alba Fairmoon, Sentinel Hill hanı, Westfall" }
Q[92745] = { description = "Westfall madenlerinin kirlenmeye yol açıp açmadığını araştır.", name = "Madenlerin Durumu", objective = "Jangolode Mine'da 4 Kobold Digger ve Gold Coast Quarry'de 6 Riverpaw Miner öldür.", pickup = "Alba Fairmoon, Sentinel Hill hanı, Westfall", turnin = "Alba Fairmoon, Sentinel Hill hanı, Westfall" }
Q[92747] = { description = "Erzaklar, Deadmines girişine doğru giden mağaralarda bulunur.", name = "Moonbrook Casusluğu", objective = "Moonbrook'tan 8 Şüpheli Endüstriyel Malzeme topla.", pickup = "Alba Fairmoon, Sentinel Hill hanı, Westfall", turnin = "Alba Fairmoon, Sentinel Hill hanı, Westfall" }
Q[92748] = { description = "Toxic Soil zincirinin patlayıcı bölümünü başlatır.", name = "Patlayıcı Danışmanlık", objective = "Stormwind'deki Dwarven District'e git ve yardım edebilecek bir mühendis bul.", pickup = "Alba Fairmoon, Sentinel Hill hanı, Westfall" }
Q[92749] = { description = "Kaba Dinamit üretilebilir, takas edilebilir ya da müzayede evinden alınabilir.", name = "Dinamit Gibi Bir Plan", note = "Kaba Dinamit üretilebilir, takas edilebilir ya da müzayede evinden alınabilir.", objective = "Üreterek, takas ederek ya da müzayede salonundan 10 Kaba Dinamit edin, ardından Stormwind'in Dwarven District'indeki Sprite Jumpsprocket'a dön." }
Q[92750] = { description = "Planlanan patlama için uzaktan bir fünye gerekiyor.", name = "Uzaktan Patlatma", objective = "Uzaktan kumandalı bir patlatıcı edinmek için Stormwind İstihbaratı'ndan biriyle konuş." }
Q[92751] = { description = "Uzaktan fünyeyi mühendise geri götürür.", name = "Uzaktan Patlatma", objective = "Uzaktan Patlatıcı Kiti'ni Stormwind'in Dwarven District'indeki Sprite Jumpsprocket'a götür.", pickup = "Jasper Fel, SI:7, Old Town, Stormwind" }
Q[92752] = { description = "Deadmines'taki Destruction öncesi son hazırlık.", name = "Patlayıcı Danışmanlık", objective = "Westfall'daki Alba Fairmoon'a dön.", turnin = "Alba Fairmoon, Sentinel Hill hanı, Westfall" }
Q[92753] = { description = "Patlayıcıları demirhaneye yerleştir, sonra Alba Fairmoon'a dön.", name = "Deadmines'ta Yıkım", objective = "Deadmines'ta gizlenmiş demirhaneyi bul ve Ekstra Yıkıcı Patlayıcılar'ı yakınına yerleştir. Ardından Deadmines çıkışında Alba Fairmoon ile buluş.", pickup = "Extra-Destructive Explosives görev başlatma eşyasını kullan.", turnin = "Alba Fairmoon, Sentinel Hill hanı, Westfall" }
Q[92819] = { description = "Toxic Soil zincirinin son adımı.", name = "Deadmines'ta Yıkım", objective = "Patlatıcıyı kullan.", pickup = "Alba Fairmoon, Sentinel Hill hanı, Westfall", turnin = "Alba Fairmoon, Sentinel Hill hanı, Westfall" }
Q[93680] = { name = "Şehrin Anahtarı", note = "Bu görev Prison Break In ile aynı anda kabul edilebilir.", objective = "Tarren Mill'deki Büyücü Wordeen Voidglare için Dalaran Lağım Anahtarı'nı edin." }
Q[94907] = { name = "Küçük Bir İyilik", objective = "Twilight's Shroud içindeki bir kanaldan bir Twilight's Thrall çağır ve onu Amberhall'un Ruh Taşı ile yakala.", pickup = "Ashe Amberhall, Riverglades (tam yeri henüz bilinmiyor)" }
Q[94968] = { name = "Mugg'ın Gözü", objective = "Krol'dok Stronghold'a sız ve liderlerinin ölümünün kanıtıyla Krom'rosh'a dön.", pickup = "Krom'rosh, Riverglades (tam yeri henüz bilinmiyor)" }
Q[94972] = { name = "Alacakaranlık Cildi", objective = "Alacakaranlık Cildi'ni Krol'dok Stronghold'dan geri al.", pickup = "Riverglades (görev veren henüz bilinmiyor)", turnin = "Riverglades (henüz bilinmiyor)" }
Q[94975] = { name = "Bir İntikam Nişanesi", objective = "Krol'dok Stronghold'daki Twilight's Hammer'dan 15 Tarikatçı Kulağı topla.", pickup = "Riverglades (görev veren henüz bilinmiyor)", turnin = "Riverglades (henüz bilinmiyor)" }
Q[94982] = { name = "Mugg'ın Gözü", objective = "Krol'dok Stronghold'a sız ve liderlerinin ölümünün kanıtıyla Commander Brant'e dön.", pickup = "Commander Demar Brant, Farholde Keep, Riverglades (tam yeri henüz bilinmiyor)" }
Q[94983] = { name = "Alacakaranlık Hatıraları", objective = "Krol'dok Stronghold'daki Twilight's Hammer'dan 8 Alacakaranlık Bileziği topla.", pickup = "Farholde Keep, Riverglades (görev veren henüz bilinmiyor)", turnin = "Farholde Keep, Riverglades (henüz bilinmiyor)" }
Q[94984] = { name = "Alacakaranlık Cildi", objective = "Krol'dok Stronghold'da Nar'gurk'u öldür ve değerli her bilgiyi ele geçir.", pickup = "Ashe Amberhall, Riverglades (tam yeri henüz bilinmiyor)" }
Q[95034] = { description = "Görev zinciri 18. seviyede Tirisfal Glades'teki Bandarion Keep'te Danitha Morr'dan Diplomatic Incident ile başlar. Seni Fenris Keep'ten Lumina Windsinger'ı kurtardığın Fenris Isle'a götürür.", name = "Borç", objective = "The Sepulcher'daki Lumina Windsinger ile konuş." }
Q[95036] = { name = "Ayın Öptüğü Kılıç", objective = "The Sepulcher'daki Trevan Rol ile konuş ve ona ihtiyaç duyduğu malzemeleri getir." }
Q[95111] = { name = "Hafife Alınan Bir Yetenek", objective = "Ott ile konuş ve kılıcını dövmesini iste." }
Q[95125] = { name = "Ott'un Başyapıtı", objective = "Ott kılıcını döverken onu izle." }
Q[95126] = { name = "Ay Gümüşü Kılıç", objective = "Ott'un Başyapıtı'nı Silverpine Forest'taki Trevan Rol'e götür." }
Q[95140] = { description = "Son adım. Old Fire-Eye, güney Silverpine Forest'taki Greymane Wall'da. Ödül: Wolfsbane.", name = "Yaşlı Ateşgöz", note = "Undead'ler ve taurenler için Paladin sınıf görevi. Bu zindanda: Whitestone Meşe Kerestesi Goblin Woodcarver'lardan düşer. Diğer parçalar Enchanted Silver Ingot (Shadowfang Keep) ve Purified Kor Gem (Blackfathom Deeps).", objective = "Silverpine Forest'taki Old Fire-Eye'ı yok etmek için Ay Gümüşü Kılıç'ı kullan.", warning = "Bu, bir adımı The Deadmines'ta olan bir zincir görev" }
Q[95189] = { name = "Lordaeron Arması", note = "Topluluk bildirimlerine göre Arma, zindanın içinde birkaç farklı yerde çıkabiliyor. Bildirilen yerler arasında kulelerin üst katları, The Baron yakınındaki yan/mahzen odaları ve Bjork'un çevresi var.", objective = "Lordaeron Arması'nı Stormwind City'deki Leydi Dena Kennedy'ye geri götür.", pickup = "Eşyayla başlar: Crest of Lordaeron, Ruins of Lordaeron içinde" }
Q[95195] = { name = "Kana Bulanmış Nişan", objective = "10 Kana Bulanmış Nişan topla ve onları Stormwind City'deki General Marcus Jonathan'a götür.", pickup = "Eşyayla başlar: Bloodied Insignia, Ruins of Lordaeron içinde" }
Q[95204] = { name = "Lordaeron Arması", note = "Topluluk bildirimlerine göre Arma, zindanın içinde birkaç farklı yerde çıkabiliyor. Bildirilen yerler arasında kulelerin üst katları, The Baron yakınındaki yan/mahzen odaları ve Bjork'un çevresi var.", objective = "Lordaeron Arması'nı Undercity'deki Oran Snakewrithe'a götür.", pickup = "Eşyayla başlar: Crest of Lordaeron, Ruins of Lordaeron içinde" }
Q[95216] = { name = "Yeni Veba", objective = "Undercity'deki Theodore Griffs için Ruins of Lordaeron'daki Witherfang'den Son Derece Zehirli Suş'u topla." }
Q[95250] = { name = "İğrenç Yaratıklar", objective = "Ruins of Lordaeron'da Baron'un Kafası'nı ele geçir ve Yüzbaşı Truman'a geri getir.", pickup = "Captain Truman, Ruins of Lordaeron'un hemen içinde (girişin solunda)", turnin = "Captain Truman, Ruins of Lordaeron'un hemen içinde" }
Q[95646] = { name = "Yaylalardaki Dehşet", objective = "Excavation Sites'ta bir Highland Horror öldür ve kök çekirdeğini Wetlands'teki Yeşil Muhafız Rethiel'e götür." }
Q[95647] = { description = "Heartwoven öncesi gerekli.", name = "Çalılıkta Kaybolanlar", objective = "Excavation Sites'ta Ardin Grassman'i bul.", turnin = "Ardin Grassman, Excavation Site: Wetlands içinde" }
Q[95663] = { description = "Open the Maw öncesi gerekli.", name = "Dragonmaw Söylentileri", objective = "Wetlands'e git ve Dragonmaw kampının yukarısındaki tepelerde Ölüm Takipçisi Ajanı ile buluş.", turnin = "Deathstalker Agent, Dragonmaw kampının üstündeki tepeler, Wetlands" }
Q[95664] = { name = "Kadim Bilgi", objective = "Titan Kalıntısı'nı Thunder Bluff'taki Elder Rise'a götür ve sana onun hakkında daha fazlasını anlatabilecek birini ara.", pickup = "Titan Kalıntısı (Relic Guardian düşürür)" }
Q[95682] = { name = "Dragonmaw İnini Aç", note = "İlgili giriş görevi: Dragonmaw Rumors. Dragonmaw Gönderisi, zindanın içindeki Dragonmaw kuvvetlerinden alınır.", objective = "Excavation Site'taki Dragonmaw kuvvetlerini katlet ve ele geçirdiğin her şeyle dışarıdaki Ölüm Takipçisi Ajanı'na dön.", pickup = "Deathstalker Agent, Excavation Site: Wetlands'in hemen dışında", turnin = "Deathstalker Agent, Excavation Site: Wetlands'in hemen dışında" }
Q[95697] = { name = "Değişen Damak Zevkleri", note = "Thicket Raptor Eti, Shadetooth'un bölgesi olan Stalker's Thicket'teki Thicket raptorlarından (Thicket Lurker, Thicket Hunter, Thicket Matriarch) gelir.", objective = "Wetlands'teki Excavation Sites'a gir ve Çalılık Raptoru Eti getir." }
Q[95748] = { name = "Eski Gurubashi Efsaneleri", objective = "Postu ve kömürü kullanarak Üçüncü Trol Efsanesi tabletinin bir kopyasını çıkar." }
Q[95770] = { description = "Mağara, Sunken Hollow'da, yaklaşık 21, 28 civarında su altında: Drowned City'nin girişi.", name = "Kayıp Şehrin İzinde", objective = "Vile Reef'i keşfet ve mağara girişini bul." }
Q[95772] = { name = "Songblade'i Aramak", note = "Daewyn'i zindanın içinde bul. Fallen in the Fen seni Lakeshire'daki Dorin Songblade'e geri gönderir.", objective = "Dorin Songblade'in kardeşi Daewyn'i Whelgar's Excavation Site'ta ara.", turnin = "Daewyn Songblade, Excavation Site: Wetlands içinde" }
Q[95773] = { name = "Sulardaki Düşmanlar", objective = "Brinescale Skirmisher'lardan 10 Brinescale Mızrağı topla.", pickup = "Grom'gol Base Camp, Stranglethorn Vale (görev veren henüz bilinmiyor)", turnin = "Grom'gol Base Camp, Stranglethorn Vale (henüz bilinmiyor)" }
Q[95775] = { name = "Batık Şehir", objective = "Batık Şehir'de bulunan tabletlerin izlerini çıkarmak için postu ve kömürü kullan." }
Q[95776] = { name = "Tek İyi Brinescale...", objective = "Batık Şehir'de Var'Taka'yı öldür.", pickup = "Grom'gol Base Camp, Stranglethorn Vale (görev veren henüz bilinmiyor)", turnin = "Grom'gol Base Camp, Stranglethorn Vale (henüz bilinmiyor)" }
Q[95787] = { name = "Suyla İki Tane Al", note = "Görev veren henüz doğrulanmadı. Giriş görevi: An Acquaintance in Southshore, Savage Coast Rapor Destesi'ni Loremaster Dibbs'e götürmek.", objective = "Drowned City'deki dört I'lalai Tableti'nin kopyasını çıkar." }
Q[95788] = { name = "Drowned City'nin Büyüleri", objective = "Drowned City'deki trollerden 5 I'lalai Fetişi topla.", pickup = "Henüz bilinmiyor", turnin = "Henüz bilinmiyor" }
Q[95789] = { name = "Şüpheli Saltseer'lar", objective = "Drowned City'deki Saltseer korsanlarından 10 Vuduyla Dolu Eser topla." }
Q[95791] = { name = "Saltseer Kaptanı", objective = "Drowned City'de Captain Dreadrise'ı ve 3 Saltseer Coroner'ı öldür.", pickup = "Krazek, Booty Bay, Stranglethorn Vale (doğrulanmadı)", turnin = "Krazek, Booty Bay, Stranglethorn Vale (doğrulanmadı)" }
Q[95795] = { name = "Bataklıkta Düşenler", objective = "Dorin Songblade'e dön.", pickup = "Daewyn Songblade, Excavation Site: Wetlands içinde" }
Q[95809] = { name = "Yürekten Dokunmuş", note = "Lost in the Thicket Things görevinin devamı.", objective = "Menethil Harbor'daki Caitlin Grassman'e dön.", pickup = "Ardin Grassman, Excavation Site: Wetlands içinde" }
Q[95810] = { name = "Kayıp Kalıntının Taşınması", objective = "Titan Kalıntısı'nı Wetlands kazı alanındaki Kâşif Whelgar'a götür.", pickup = "Titan Kalıntısı (Relic Guardian düşürür)" }
Q[96391] = { description = "Dark Iron Haritası bu görevi başlatır ve doğrudan Old Ironforge Incursion görevine götürür.", name = "Yeraltı Haritası", objective = "Dark Iron Haritası'nı Dun Morogh'daki Toprak Kâhini Farsen'e teslim et.", pickup = "Dark Iron Haritası, Ironband's Compound'daki Dark Iron Casusları düşürür, Dun Morogh" }
Q[96393] = { name = "Old Ironforge Baskını", note = "Zincir, Dun Morogh'daki Dark Iron Casuslarından Dark Iron Haritası düşmesiyle başlar.", objective = "Old Ironforge'un altındaki Hall of Thanes'e gir ve Durgen Dirgehammer'ın Kafası'nı al.", pickup = "Earthseer Farsen, Dun Morogh (Yeraltı Haritası'ndan sonra)" }
Q[96394] = { name = "Huzursuz Ölüler", objective = "15 Enraged Apparition ve 10 Tormented Soul öldür, ardından Anvilmar'ın ruhunu huzura kavuştur.", pickup = "Afadra Dunwall, Old Ironforge'un tepesinde, zindanın dışında" }
Q[96395] = { name = "Kadim Bir Kin", objective = "Faldrim Anvilmar'ın ruhunu huzura kavuştur, ardından Hall of Thanes'teki Hayalet Hizmetkâr'a dön.", pickup = "Ghostly Attendant, Hall of Thanes içinde, ilk odadan sonra", turnin = "Ghostly Attendant, zindanın içinde" }
Q[96403] = { name = "Önemli Yadigârlar", objective = "Hall of Thanes'ten 8 Cüce Yadigârı topla.", pickup = "Thom Filch, Ironforge'daki köprü / kasa girişinin yanında", turnin = "Thom Filch, zindan girişinin yakınında" }
Q[96771] = { name = "Highborne'un İntikamı", note = "Zalfan Moonshadow, kalenin içindeki Twilight's Hammer arasında bir highborne; nerede durduğu henüz bilinmiyor.", objective = "Krol'dok Stronghold'a git ve Zalfan Moonshadow'u öldür.", pickup = "Henüz bilinmiyor (bir highborne; Kirin Tor itibarı, yani muhtemelen Dalaran'da)", turnin = "Henüz bilinmiyor" }
Q[96774] = { name = "Kadim Gurubashi Putu", objective = "Batık Şehir'den Kadim bir Gurubashi Putu'nu geri getir." }
Q[96800] = { name = "Vadesi Geçmiş", note = "Forever'da yeni. Kitap Arcanist Doan'dadır.", objective = "Runemaster'ların Kayıp Büyüsü adlı kitabı Scarlet Monastery'den geri getir." }
Q[96984] = { name = "Bozulmanın Kalbi", note = "Horde Dalaran uyumlanması. Stone Tokens ve Bracers of Binding zincirle birlikte yapılabilir ama isteğe bağlıdır, uyumlanma için gerekli değildir.", objective = "Tarren Mill'deki Magus Wordeen Voidglare için City of Dalaran'da Arkan Zerre'yi topla.", pickup = "Image of Archmage Modera, Dalaran yakınındaki Lordamere Lake" }
Q[96986] = { name = "Mezar Şövalyesi", note = "Görev verisi betada kaydedildi; zindana erişim mümkün olmayabilir.", objective = "Tarren Mill'deki Melisara için City of Dalaran'da Mezar Şövalyesi Atrexis'i yen." }
Q[96987] = { name = "Fırsatçı Eğitim", note = "Görev verisi betada kaydedildi; zindana erişim mümkün olmayabilir.", objective = "Kanalizasyon girişinin yakınındaki Rexxie Copperclutch için City of Dalaran'dan \"Dalaran'ın Kuruluşu\" kitabını topla.", pickup = "Rexxie Copperclutch, zindanın içinde, lağım girişinin yakınında", turnin = "Rexxie Copperclutch, zindanın içinde, lağım girişinin yakınında" }
Q[96988] = { name = "Gücün Kaynağı", note = "Görev verisi betada kaydedildi; zindana erişim mümkün olmayabilir.", objective = "Undercity'deki Doktor Martin Felben için City of Dalaran'da 6 Çatlak Nöbetçi Çekirdeği topla." }
Q[97130] = { name = "Kadim Gurubashi Sırları", objective = "Drowned City'den bir Kadim Gurubashi İdolü geri al.", pickup = "Henüz bilinmiyor (Dalaran'da Archmage Lan'dalock ile çalışan bir Kirin Tor büyücüsü)", turnin = "Henüz bilinmiyor" }
Q[97288] = { name = "Bitmeyen Azap", note = "Eşya seçimi, Undercity'deki sonraki Unending Torment adımında verilir.", objective = "İğrenç Kafa'yı Undercity'deki Usta Eczacı Faranell'e teslim et.", pickup = "Eşyayla başlar: Abominable Head, Ruins of Lordaeron içinde", rewardHeader = "Zincir ödülü — devam görevi" }
Q[98423] = { name = "Anlaşma Antlaşması", note = "Tablet, Durgen Dirgehammer'ın son boss odasında, Reliquary of Kings'teki kasalardan birinin içinde. Zindandan ayrılmadan önce kasaları aç ve tabletle etkileşime geç.", objective = "Anlaşma Antlaşması'nı Ironforge'daki Magni Bronzebeard'a teslim et.", pickup = "Reliquary of Kings'teki bir kasanın içindeki taş tablet (Durgen Dirgehammer'ın odası)" }
Q[98815] = { name = "Yayla Postları", objective = "4 Çalılık Raptoru Postu'nu Menethil Harbor'daki tabak James Halloran'a götür." }
Q[98823] = { name = "Toprağın Yankısı", objective = "Titan Kalıntısı'nı Mulgore'un kuzeybatısındaki Skywatcher Plateau'da bulunan Muln Earthfury'ye götür." }
Q[98824] = { name = "Tarih Öncesi Prizma", objective = "Titan Kalıntısı'nı Ironforge'daki Hall of Explorers'ta bulunan Baş Kâşif Magellas'a götür." }
Q[99156] = { name = "Artçı Devriyesi", objective = "Riptear'ın Kalbi'ni Deathguard Linnea'ya getir.", pickup = "Deathguard Linnea, Brill'in güneydoğusundaki kamp, Tirisfal Glades", turnin = "Deathguard Linnea, Brill'in güneydoğusundaki kamp, Tirisfal Glades", warning = "Grup görevi: Riptear 13. seviye elit." }
Q[2930001] = { description = "Rastgele düşer; genellikle dış bölgeyi ilk temizleyişinde alırsın.", name = "Beyaz Delikli Kart", objective = "Beyaz Delikli Kart düşene kadar dış Gnomeregan bölgesindeki yaratıkları öldür.", pickup = "Caverndeep Pillager, Caverndeep Invader, Irradiated Invader ve Addled Leper'lar, zindanın dışında", turnin = "Kartı Matrix Punchograph 3005-A için sakla" }
Q[2930002] = { description = "Zindanın dışındaki tek delgeçler: Train Depot'daki yükseltilmiş platformda ve Workshop (arka kapı) girişinin yanında.", name = "Sarı Delikli Kart (Punchograph 3005-A)", objective = "Sarı Delikli Kart almak için Beyaz Delikli Kart ile Matrix Punchograph 3005-A'yı kullan.", pickup = "Matrix Punchograph 3005-A, Train Depot'nun atölye bölümü, zindanın dışında", turnin = "Bir Sarı Delikli Kart alırsın" }
Q[2930003] = { description = "Zindanın içinde, Dormitory'de.", name = "Mavi Delikli Kart (Punchograph 3005-B)", objective = "Mavi Delikli Kart almak için Sarı Delikli Kart ile Matrix Punchograph 3005-B'yi kullan.", pickup = "Matrix Punchograph 3005-B, The Dormitory (Clean Zone'u hemen geçince), zindanın içinde", turnin = "Bir Mavi Delikli Kart alırsın" }
Q[2930004] = { description = "Electrocutioner 6000'in platformunda.", name = "Kırmızı Delikli Kart (Punchograph 3005-C)", objective = "Kırmızı Delikli Kart almak için Mavi Delikli Kart ile Matrix Punchograph 3005-C'yi kullan.", pickup = "Matrix Punchograph 3005-C, Electrocutioner 6000'in bulunduğu Launch Bay'in üst platformu", turnin = "Bir Kırmızı Delikli Kart alırsın" }
Q[2930005] = { description = "Asansörle aşağı in; terminal sağdaki ilk geçitte.", name = "Prizmatik Delikli Kart (Punchograph 3005-D)", objective = "Prizmatik Delikli Kart almak için Kırmızı Delikli Kart ile Matrix Punchograph 3005-D'yi kullan, sonra onu Ironforge'daki Master Mechanic Castpipe'a götür.", pickup = "Matrix Punchograph 3005-D, Engineering Labs'in alt katının batı tarafı" }
P["A Crumpled Up Note (drops from Dark Iron dwarves)"] = "Buruşturulmuş Bir Not (Dark Iron cücelerinden düşer)"
P["A Small Favor"] = "Küçük Bir İyilik"
P["A Titan dig site trapped in time above Whelgar's Excavation, where errant Titan constructs have stopped obeying anyone. Areas inside: Lost Marsh, Stalker's Thicket, Site of the Guardian and Lost Dig Site."] = "Whelgar's Excavation'ın üstünde zamanda donmuş bir Titan kazı alanı; başıboş Titan yapıları artık kimseye itaat etmiyor. İçerideki bölgeler: Lost Marsh, Stalker's Thicket, Site of the Guardian ve Lost Dig Site."
P["A Token of Vengeance"] = "Bir İntikam Nişanesi"
P["A chest in a hut beside Pyrewood Village"] = "Pyrewood Village'ın yanındaki bir kulübede sandık"
P["A chest in a hut beside Pyrewood Village, Silverpine Forest"] = "Pyrewood Village'ın yanındaki bir kulübede sandık, Silverpine Forest"
P["A flooded night elf ruin on the Zoram Strand, occupied by naga, murlocs and Twilight's Hammer cultists serving Aku'mai."] = "Zoram Strand'de nagaların, murlocların ve Aku'mai'ye hizmet eden Twilight's Hammer tarikatçılarının işgal ettiği sular altında kalmış bir gece elfi harabesi."
P["A sprawling thorn maze occupied by the quilboar of Razorfen Kraul."] = "Razorfen Kraul domuzadamlarının işgal ettiği uçsuz bucaksız bir diken labirenti."
P["ANSWER: Neltharion"] = "CEVAP: Neltharion"
P["ANSWER: Ner'zhul"] = "CEVAP: Ner'zhul"
P["Accept %s before %s. If %s disappears, abandon %s and it will reappear."] = "%s görevini %s görevinden önce kabul et. %s kaybolursa %s görevini bırak, yeniden görünecektir."
P["Accept Rig Wars before Chief Engineer Scooty. If Rig Wars disappears, abandon Chief Engineer Scooty and it will reappear."] = "Chief Engineer Scooty'den önce Rig Wars'u kabul et. Rig Wars kaybolursa Chief Engineer Scooty'yi bırak, yeniden görünecektir."
P["Accept Rig Wars first; completion is not required for Chief Engineer Scooty."] = "Önce Rig Wars'u kabul et; Chief Engineer Scooty için tamamlanması gerekmez."
P["Accept Rig Wars here"] = "Rig Wars'u burada kabul et"
P["Afadra Dunwall — top of Old Ironforge"] = "Afadra Dunwall — Old Ironforge'un tepesi"
P["Afadra Dunwall, top of Old Ironforge, outside the dungeon"] = "Afadra Dunwall, Old Ironforge'un tepesinde, zindanın dışında"
P["After Baron Rivendare dies, use the glowing rune on the floor of his room, then take the follow-up back to Leonid."] = "Baron Rivendare öldükten sonra odasının zeminindeki parlayan rünü kullan, sonra devam görevini Leonid'e geri götür."
P["Alba Fairmoon is inside the Sentinel Hill inn"] = "Alba Fairmoon, Sentinel Hill hanının içinde"
P["Alba Fairmoon — Sentinel Hill inn"] = "Alba Fairmoon — Sentinel Hill hanı"
P["Alba Fairmoon, Sentinel Hill inn, Westfall"] = "Alba Fairmoon, Sentinel Hill hanı, Westfall"
P["Alliance step required before Gnome Improvement."] = "Gnome Improvement öncesi gerekli Alliance adımı."
P["Ambassador Malcin is in the tents of the outdoor thorn maze, before the instance portal. Starts from the Small Scroll dropped by Charlga Razorflank in Razorfen Kraul."] = "Ambassador Malcin, zindan portalından önce, dış diken labirentindeki çadırlarda. Razorfen Kraul'da Charlga Razorflank'in düşürdüğü Küçük Parşömen ile başlar."
P["An ancient titan facility in the northern hills of Un'Goro Crater, overlooking dinosaurs, tar pits and powerful crystals. Collect power crystals across Un'Goro and use them at the consoles inside the terrace. Known bosses so far: Nanaya, Cinder, Bolt and Snowtalon."] = "Un'Goro Crater'ın kuzey tepelerinde, dinozorlara, katran çukurlarına ve güçlü kristallere bakan kadim bir titan tesisi. Un'Goro genelinde güç kristalleri topla ve onları terasın içindeki konsollarda kullan. Şimdilik bilinen bosslar: Nanaya, Cinder, Bolt ve Snowtalon."
P["An ancient titan vault buried beneath the Badlands, overrun by troggs and Shadowforge dwarves. Archaedas guards the Discs of Norgannon in its deepest chamber."] = "Badlands'in altına gömülü, trogglar ve Shadowforge cüceleri tarafından istila edilmiş kadim bir titan kasası. Archaedas en derin odada Discs of Norgannon'u korur."
P["Ancient Gurubashi Secrets"] = "Kadim Gurubashi Sırları"
P["Anthion Harmon — outside the Stratholme main gate (needs the Ghost Revealer)"] = "Anthion Harmon — Stratholme ana kapısının dışında (Hayalet Gösterici gerekir)"
P["Anthion Harmon: outside the Stratholme main gate (needs the Ghost Revealer)"] = "Anthion Harmon: Stratholme ana kapısının dışında (Hayalet Gösterici gerekir)"
P["Any Maraudon creature can drop the Theradric Crystal Carvings."] = "Maraudon'daki her yaratık Theradric Kristal Oymalarını düşürebilir."
P["Any undead in Stratholme can drop Plagued Flesh Samples."] = "Stratholme'daki her undead Vebalı Et Örneği düşürebilir."
P["Apothecary Zinge: The Apothecarium, Undercity"] = "Apothecary Zinge: The Apothecarium, Undercity"
P["Arch Druid Hamuul Runetotem: Elder Rise, Thunder Bluff"] = "Arch Druid Hamuul Runetotem: Elder Rise, Thunder Bluff"
P["Archmage Arugal and his worgen followers hold the keep above Pyrewood Village."] = "Archmage Arugal ve worgen takipçileri Pyrewood Village'ın üstündeki kaleyi elinde tutuyor."
P["Ardin Grassman, inside Excavation Site: Wetlands"] = "Ardin Grassman, Excavation Site: Wetlands içinde"
P["Argent Guard Manados, Craftsmen's Terrace, Darnassus (55, 24)"] = "Argent Guard Manados, Craftsmen's Terrace, Darnassus (55, 24)"
P["Argent Guard Thaelrid, inside Blackfathom Deeps"] = "Argent Guard Thaelrid, Blackfathom Deeps içinde"
P["Argos Nightwhisper is in The Park, beside the moonwell area."] = "Argos Nightwhisper, The Park'ta, ay kuyusu alanının yanında."
P["Ashe Amberhall, Riverglades (exact spot not known yet)"] = "Ashe Amberhall, Riverglades (tam yeri henüz bilinmiyor)"
P["Atal'ai Haze drops from the temple's worms, lurkers and oozes."] = "Atal'ai Sisi, tapınağın solucanlarından, pusucularından ve balçıklarından düşer."
P["Available after completing Prison Break In."] = "Prison Break In tamamlandıktan sonra alınabilir."
P["Awbee is the wounded blue dragon near the arena route after Rend. Use the rune deep in the Mazthoril cave to reach Haleh."] = "Awbee, Rend'den sonra arena yolunun yakınındaki yaralı mavi ejderha. Haleh'e ulaşmak için Mazthoril mağarasının derinlerindeki rünü kullan."
P["Baron Aquanis spawns by looting the Fathom Core from the 'Amongst the Ruins' quest."] = "Baron Aquanis, 'Amongst the Ruins' görevindeki Fathom Çekirdeği alınınca ortaya çıkar."
P["Battered Dwarven Skeleton: Agmond's End, Badlands"] = "Hırpalanmış Cüce İskeleti: Agmond's End, Badlands"
P["Begins the explosives portion of the Toxic Soil chain."] = "Toxic Soil zincirinin patlayıcı bölümünü başlatır."
P["Below the cliff north of the abandoned camp"] = "Terk edilmiş kampın kuzeyindeki uçurumun altında"
P["Beneath Ironforge, Dun Morogh"] = "Ironforge'un altında, Dun Morogh"
P["Beside the Burned-Out Remains, south of Camp Taurajo"] = "Yanmış kalıntıların yanında, Camp Taurajo'nun güneyinde"
P["Beyond a long-sealed gate in Azshara lies the furbolg city of the Blackmaw clan, fighting a corruption that spreads through its groves and mountain tunnels. A large max-level dungeon with several routes and bosses; its depths may lead even farther below Azeroth."] = "Azshara'da uzun süredir mühürlü bir kapının ardında, korularına ve dağ tünellerine yayılan bir bozulmayla savaşan Blackmaw klanının furbolg şehri yatıyor. Birkaç rotası ve bossu olan büyük bir en üst seviye zindan; derinlikleri Azeroth'un daha da altına inebilir."
P["Bijou hides in a recess beyond the early bridges. Her belongings spawn in one of several places around the troll and orc rooms."] = "Bijou, ilk köprülerin ötesindeki bir girintide saklanır. Eşyaları trol ve ork odalarının çevresindeki birkaç yerden birinde çıkar."
P["Blackhand's Command (letter from the Scarshield Quartermaster, Blackrock Mountain)"] = "Blackhand's Command (Scarshield Quartermaster'dan mektup, Blackrock Mountain)"
P["Blacksmithing 270 (Armorsmith). Use the Blood Stained Pike on Goraluk's corpse and loot the Unforged Rune Covered Breastplate nearby."] = "Demircilik 270 (Zırh Ustası). Kana Bulanmış Mızrak'ı Goraluk'un cesedinde kullan ve yakındaki Dövülmemiş Rün Kaplı Göğüslük'ü al."
P["Blacksmithing. Bring a Sulfuron Ingot (Golemagg, Molten Core) to Lokhtos in the Grim Guzzler to get the contract, then hand it back for the Sulfuron Hammer plans."] = "Demircilik. Sözleşmeyi almak için Grim Guzzler'daki Lokhtos'a bir Sulfuron Külçesi (Golemagg, Molten Core) getir, sonra Sulfuron Çekici planları için geri teslim et."
P["Blue Punch Card (Punchograph 3005-B)"] = "Mavi Delikli Kart (Punchograph 3005-B)"
P["Both are at the Balnir Farmstead, east of Linnea's camp."] = "İkisi de Linnea'nın kampının doğusundaki Balnir Farmstead'de."
P["Break the three kegs in the Grim Guzzler storeroom to spawn Hurley Blackbreath and his guards.\n\nOptional introductory quest:"] = "Hurley Blackbreath ve muhafızlarını ortaya çıkarmak için Grim Guzzler deposundaki üç fıçıyı kır.\n\nİsteğe bağlı giriş görevi:"
P["Bring 4 Bolts of Runecloth, 8 Rugged Leather, 2 Rune Threads and 1 Ogre Tannin (basket on the upper level beyond Knot). Make any suits and learn the pattern before freeing Knot, because he leaves."] = "4 Rün Kumaşı Topu, 8 Sağlam Deri, 2 Rün İpliği ve 1 Ogre Tanen'i (Knot'un ötesinde üst kattaki sepet) getir. Knot'u serbest bırakmadan önce istediğin takımları yap ve deseni öğren, çünkü gidiyor."
P["Bring Gloom'rel 2 Star Rubies, 20 Gold Bars and 10 Truesilver Bars, then place them in the Spectral Chalice in the Summoners' Tomb."] = "Gloom'rel'e 2 Yıldız Yakutu, 20 Altın Külçe ve 10 Truesilver Külçe getir, sonra bunları Summoners' Tomb'daki Hayalet Kadeh'e koy."
P["Bring Highlord Omokk's Head and a Roughshod Pike to Urok's Tribute Pile beyond the spiders to start the waves."] = "Dalgaları başlatmak için Highlord Omokk'un Kafası'nı ve bir Roughshod Mızrağı'nı örümceklerin ötesindeki Urok's Tribute Pile'a getir."
P["Bring Private Rocknot two Dark Iron Ale Mugs."] = "Er Rocknot'a iki Dark Iron Bira Kupası getir."
P["Bring the Dragonmaw Dispatch to the Deathstalker Agent just outside Excavation Site: Wetlands."] = "Dragonmaw Gönderisi'ni Excavation Site: Wetlands'in hemen dışındaki Deathstalker Agent'a getir."
P["Brother Crowley: Cathedral of Light, Stormwind"] = "Brother Crowley: Cathedral of Light, Stormwind"
P["Burned-Out Remains at the burnt tower on the road south of Camp Taurajo, The Barrens (46.3, 73.9)"] = "Camp Taurajo'nun güneyindeki yol üzerinde yanık kuledeki yanmış kalıntılar, The Barrens (46.3, 73.9)"
P["Burned-Out Remains in the cart wreckage at the Alexston Farmstead, Westfall (37.3, 50.6)"] = "Alexston Farmstead'deki araba enkazının içindeki yanmış kalıntılar, Westfall (37.3, 50.6)"
P["Buy Dark Iron Ale Mugs from Plugger Spazzring and keep handing them to Rocknot. The drunken event opens the bar route and can turn Phalanx hostile."] = "Plugger Spazzring'den Dark Iron Bira Kupası satın al ve Rocknot'a vermeye devam et. Sarhoşluk olayı bar yolunu açar ve Phalanx'ı düşman yapabilir."
P["Captain Truman, just inside Ruins of Lordaeron"] = "Captain Truman, Ruins of Lordaeron'un hemen içinde"
P["Captain Truman, just inside Ruins of Lordaeron (left of the entrance)"] = "Captain Truman, Ruins of Lordaeron'un hemen içinde (girişin solunda)"
P["Carved Figurine on the carved heads of the Stonewrought Dam, Loch Modan (49.4, 12.9)"] = "Stonewrought Dam'in oyma kafalarının üzerindeki oyma heykelcik, Loch Modan (49.4, 12.9)"
P["Caverndeep Pillagers, Caverndeep Invaders, Irradiated Invaders and Addled Lepers, outside the instance"] = "Caverndeep Pillager, Caverndeep Invader, Irradiated Invader ve Addled Leper'lar, zindanın dışında"
P["Cavindra: Maraudon orange-side caverns, Desolace"] = "Cavindra: Maraudon turuncu taraf mağaraları, Desolace"
P["Centaur Pariah, southern Desolace"] = "Centaur Pariah, güney Desolace"
P["Chain reward — follow-up"] = "Zincir ödülü — devam görevi"
P["Chase and talk to Pusillin through the wing until he fights, then kill him for the book. He also drops the Crescent Key."] = "Pusillin'i kanat boyunca kovala ve o savaşana kadar onunla konuş, sonra kitap için onu öldür. Hilal Anahtarı'nı da düşürür."
P["Climb into Thoradin's Wall from the cart on the Hillsbrad side (87.3, 49.6), go through the room in the wall and look outside to the right: the bag hangs there."] = "Hillsbrad tarafındaki arabadan (87.3, 49.6) Thoradin's Wall'a tırman, duvardaki odadan geç ve dışarıya, sağa bak: çanta orada asılı."
P["Codex of Defense (book, Dire Maul drop)"] = "Codex of Defense (kitap, Dire Maul ganimeti)"
P["Collect 10 Atal'ai Tablets around the temple; tablets in the outer temple also count."] = "Tapınağın çevresinden 10 Atal'ai Tableti topla; dış tapınaktaki tabletler de sayılır."
P["Collect 10 Voodoo-Infused Artifacts from the Saltseer pirates in the Drowned City."] = "Drowned City'deki Saltseer korsanlarından 10 Vuduyla Dolu Eser topla."
P["Collect 15 Cultist Ears from the Twilight's Hammer in Krol'dok Stronghold."] = "Krol'dok Stronghold'daki Twilight's Hammer'dan 15 Tarikatçı Kulağı topla."
P["Collect 20 Fetishes of Hakkar from Atal'ai trolls; outer-temple trolls also drop them."] = "Atal'ai trollerinden 20 Hakkar Fetişi topla; dış tapınaktaki troller de düşürür."
P["Collect 4 Thicket Raptor Hides and take them to James Halloran in Menethil Harbor."] = "4 Thicket Raptor Postu topla ve Menethil Harbor'daki James Halloran'a götür."
P["Collect 5 I'lalai Fetishes from the trolls in the Drowned City."] = "Drowned City'deki trollerden 5 I'lalai Fetişi topla."
P["Collect 5 Stratholme Holy Water from the supply crates in the streets; some crates spawn enemies."] = "Sokaklardaki erzak sandıklarından 5 Stratholme Kutsal Suyu topla; bazı sandıklardan düşman çıkar."
P["Collect 6 Cracked Sentry Cores from the constructs in Dalaran."] = "Dalaran'daki yapılardan 6 Çatlak Nöbetçi Çekirdeği topla."
P["Collect 8 Twilight Bangles from the Twilight's Hammer in Krol'dok Stronghold."] = "Krol'dok Stronghold'daki Twilight's Hammer'dan 8 Alacakaranlık Bileziği topla."
P["Collect C's payment from the Dead Drop near Pyrewood Village."] = "C'nin ödemesini Pyrewood Village yakınındaki Dead Drop'tan al."
P["Combine the Sister's Half-Key and the Brother's Half-Key, picked from the sister (dining hall) and the brother (upstairs) in Shadowfang Keep. Combining them breaks stealth"] = "Shadowfang Keep'teki kız kardeşten (yemek salonu) ve erkek kardeşten (üst kat) çalınan Kız Kardeşin Yarım Anahtarı ile Erkek Kardeşin Yarım Anahtarı'nı birleştir. Birleştirmek gizlenmeyi bozar"
P["Commander Demar Brant, Farholde Keep, Riverglades (exact spot not known yet)"] = "Commander Demar Brant, Farholde Keep, Riverglades (tam yeri henüz bilinmiyor)"
P["Community reports indicate the Crest can spawn at one of several locations inside the dungeon. Reported spots include upper floors of towers, side/crypt rooms near The Baron, and the area around Bjork."] = "Topluluk bildirimlerine göre Arma, zindanın içinde birkaç farklı yerde çıkabiliyor. Bildirilen yerler arasında kulelerin üst katları, The Baron yakınındaki yan/mahzen odaları ve Bjork'un çevresi var."
P["Complete Daily Delivery first."] = "Önce Daily Delivery'yi tamamla."
P["Complete The Dark Iron War to unlock The Fury Runs Deep."] = "The Fury Runs Deep'i açmak için The Dark Iron War'u tamamla."
P["Completing Altered Beings unlocks Hamuul Runetotem."] = "Altered Beings'i tamamlamak Hamuul Runetotem'i açar."
P["Continue the chain with Bazil Thredd here"] = "Zincire burada Bazil Thredd ile devam et"
P["Continue with Blisters on The Land here"] = "Burada Blisters on The Land ile devam et"
P["Continue with Fire Taboo here"] = "Burada Fire Taboo ile devam et"
P["Continue with Tramping Paws here"] = "Burada Tramping Paws ile devam et"
P["Continues with Earthen Echo, which sends you to Muln Earthfury in northwest Mulgore."] = "Seni kuzeybatı Mulgore'daki Muln Earthfury'ye gönderen Earthen Echo ile devam eder."
P["Count Remington Ridgewell: Stormwind Keep"] = "Count Remington Ridgewell: Stormwind Keep"
P["Crier Goodman — Stormwind (walks around)"] = "Crier Goodman — Stormwind (dolaşır)"
P["Crier Goodman, Stormwind (or Courier Hammerfall, Ironforge / Herald Moonstalker, Darnassus)"] = "Crier Goodman, Stormwind (veya Courier Hammerfall, Ironforge / Herald Moonstalker, Darnassus)"
P["Crier Goodman: Trade District, Stormwind (walks around)"] = "Crier Goodman: Trade District, Stormwind (dolaşır)"
P["Daewyn Songblade, inside Excavation Site: Wetlands"] = "Daewyn Songblade, Excavation Site: Wetlands içinde"
P["Dalaran sewer entrance"] = "Dalaran lağım girişi"
P["Daphne Stilwell is in the far south of Westfall"] = "Daphne Stilwell, Westfall'un en güneyinde"
P["Daphne Stilwell — southern Westfall"] = "Daphne Stilwell — güney Westfall"
P["Daphne Stilwell: Stilwell farm, southern Westfall"] = "Daphne Stilwell: Stilwell çiftliği, güney Westfall"
P["Dark Iron Fanny Packs drop from Dark Iron dwarves in BRD."] = "Dark Iron Bel Çantaları, BRD'deki Dark Iron cücelerinden düşer."
P["Dark Iron Map drops from Dark Iron Spies around Ironband's Compound"] = "Dark Iron Haritası, Ironband's Compound çevresindeki Dark Iron Casuslarından düşer"
P["Dark Iron Map, dropped by Dark Iron Spies at Ironband's Compound, Dun Morogh"] = "Dark Iron Haritası, Ironband's Compound'daki Dark Iron Casusları düşürür, Dun Morogh"
P["Daryn Lightwind: Rut'theran Village, Teldrassil"] = "Daryn Lightwind: Rut'theran Village, Teldrassil"
P["Deathguard Kristof — southeast of Brill"] = "Deathguard Kristof — Brill'in güneydoğusu"
P["Deathguard Linnea, camp south-east of Brill, Tirisfal Glades"] = "Deathguard Linnea, Brill'in güneydoğusundaki kamp, Tirisfal Glades"
P["Deathstalker Agent, hills above the Dragonmaw camp, Wetlands"] = "Deathstalker Agent, Dragonmaw kampının üstündeki tepeler, Wetlands"
P["Deathstalker Agent, just outside Excavation Site: Wetlands"] = "Deathstalker Agent, Excavation Site: Wetlands'in hemen dışında"
P["Deathstalker Vincent, inside Shadowfang Keep"] = "Deathstalker Vincent, Shadowfang Keep içinde"
P["Deep beneath the Barrens, druids and fanglords guard the sleeping Naralex while twisted beasts prowl the caverns."] = "Barrens'ın derinliklerinde druidler ve fanglordlar uyuyan Naralex'i korurken çarpık canavarlar mağaralarda dolaşıyor."
P["Defeat 2 Dragonmaw Saboteurs and 4 Dragonmaw Warders, recover the Dragonmaw Dispatch, and report to the Deathstalker Agent outside the dungeon."] = "2 Dragonmaw Saboteur ve 4 Dragonmaw Warder'ı yen, Dragonmaw Gönderisi'ni ele geçir ve zindanın dışındaki Deathstalker Agent'a rapor ver."
P["Defeat Atrexis the Grave Knight in the Dalaran Underbelly."] = "Dalaran Underbelly'de Atrexis the Grave Knight'ı yen."
P["Defeat Celebras the Cursed where the paths meet and turn in Legends of Maraudon to Celebras the Redeemed, then help with his ritual and speak to him again for the scepter."] = "Yolların birleştiği yerde Celebras the Cursed'ü yen ve Legends of Maraudon'u Celebras the Redeemed'e teslim et, sonra ritüeline yardım et ve asa için onunla tekrar konuş."
P["Defias Traitor: Sentinel Hill, Westfall"] = "Defias Hainı: Sentinel Hill, Westfall"
P["Defias prisoners have overrun Stormwind's prison beneath the Canal District."] = "Defias tutsakları Canal District'in altındaki Stormwind hapishanesini ele geçirmiş."
P["Deliver the Titan Relic to High Explorer Magellas in the Hall of Explorers."] = "Titan Kalıntısı'nı Hall of Explorers'taki High Explorer Magellas'a teslim et."
P["Deliver the Titan Relic to Muln Earthfury on Skywatcher Plateau in northwest Mulgore."] = "Titan Kalıntısı'nı kuzeybatı Mulgore'daki Skywatcher Plateau'da Muln Earthfury'ye teslim et."
P["Deliver the Titan Relic to Prospector Whelgar at the Wetlands excavation site."] = "Titan Kalıntısı'nı Wetlands kazı alanındaki Prospector Whelgar'a teslim et."
P["Doomrigger's Coffer is in the Rookery. Then take Delivery to Ridgewell to Count Remington Ridgewell in Stormwind Keep for the reward.\n\nOptional introductory quest:"] = "Doomrigger'ın Sandığı Rookery'de. Ardından ödül için Delivery to Ridgewell'i Stormwind Keep'teki Count Remington Ridgewell'e götür.\n\nİsteğe bağlı giriş görevi:"
P["Dorn Plainstalker in Thousand Needles"] = "Dorn Plainstalker, Thousand Needles'ta"
P["Dropped by Balnazzar (hand in The Archivist first)"] = "Balnazzar düşürür (önce The Archivist'i teslim et)"
P["Dropped by Brinescale Skirmishers around the Vile Reef, west of Grom'gol (around 22, 26)"] = "Grom'gol'un batısındaki Vile Reef çevresindeki (yaklaşık 22, 26) Brinescale Skirmisher'lar düşürür"
P["Dropped by Dark Iron dwarves in Gnomeregan"] = "Gnomeregan'daki Dark Iron cüceleri düşürür"
P["Dropped by Ferocious Grizzled Bears and Giant Grizzled Bears all over Silverpine Forest"] = "Silverpine Forest'ın her yerindeki Ferocious Grizzled Bear ve Giant Grizzled Bear'lar düşürür"
P["Dropped by Highlord Omokk, Lower Blackrock Spire"] = "Lower Blackrock Spire'da Highlord Omokk düşürür"
P["Dropped by Lake Creepers and Elder Lake Creepers on the Dawning Isles in Lordamere Lake (around 77, 25)"] = "Lordamere Lake'teki Dawning Isles'ta (yaklaşık 77, 25) Lake Creeper ve Elder Lake Creeper'lar düşürür"
P["Dropped by Lake Skulkers and Elder Lake Skulkers on the Dawning Isles in Lordamere Lake (around 72, 35)"] = "Lordamere Lake'teki Dawning Isles'ta (yaklaşık 72, 35) Lake Skulker ve Elder Lake Skulker'lar düşürür"
P["Dropped by Moss Stalkers and Mist Creepers in the Skittering Dark, north-west of the Sepulcher (around 35, 12)"] = "Sepulcher'ın kuzeybatısındaki Skittering Dark'taki (yaklaşık 35, 12) Moss Stalker ve Mist Creeper'lar düşürür"
P["Dropped by Overlord Wyrmthalak in Lower Blackrock Spire"] = "Lower Blackrock Spire'da Overlord Wyrmthalak düşürür"
P["Dropped by Overlord Wyrmthalak, Lower Blackrock Spire"] = "Lower Blackrock Spire'da Overlord Wyrmthalak düşürür"
P["Dropped by Riptear (level 13 elite) in Venomweb Vale, north-east Tirisfal Glades (around 84, 44)"] = "Kuzeydoğu Tirisfal Glades'teki Venomweb Vale'de (yaklaşık 84, 44) Riptear (13. seviye elit) düşürür"
P["Dropped by War Master Voone, Lower Blackrock Spire"] = "Lower Blackrock Spire'da War Master Voone düşürür"
P["Dropped by the Saltseer pirates in the Drowned City"] = "Drowned City'deki Saltseer korsanları düşürür"
P["Dropped by the Scarshield Quartermaster in the hallway outside the Spire portal"] = "Spire portalının dışındaki koridorda Scarshield Quartermaster düşürür"
P["Dropped by the Shade of Eranikus"] = "Shade of Eranikus düşürür"
P["Dropped by the Twilight's Hammer cultists in Krol'dok Stronghold"] = "Krol'dok Stronghold'daki Twilight's Hammer tarikatçıları düşürür"
P["Dropped by the trolls in the Drowned City"] = "Drowned City'deki troller düşürür"
P["Dropped by:"] = "Düşüren:"
P["Dropped by: Dark Iron Agents"] = "Düşüren: Dark Iron Agents"
P["Dropped by: Dark Iron Spies in Dun Morogh"] = "Düşüren: Dun Morogh'daki Dark Iron Casusları"
P["Dropped by: Goblin Woodcarver, The Deadmines"] = "Düşüren: Goblin Woodcarver, The Deadmines"
P["Dropped by: Mutanus the Devourer"] = "Düşüren: Mutanus the Devourer"
P["Dropped by: Relic Guardian"] = "Düşüren: Relic Guardian"
P["Dropped by: The Baron"] = "Düşüren: The Baron"
P["Dropped by: undead enemies inside Ruins of Lordaeron"] = "Düşüren: Ruins of Lordaeron içindeki undead düşmanlar"
P["Drops from Baron Aquanis inside Blackfathom Deeps."] = "Blackfathom Deeps içinde Baron Aquanis'ten düşer."
P["Drops from Blackfathom Tide Priestess in the entrance tunnels leading to Blackfathom Deeps."] = "Blackfathom Deeps'e giden giriş tünellerindeki Blackfathom Tide Priestess'lerden düşer."
P["Drops from Charlga Razorflank in Razorfen Kraul"] = "Razorfen Kraul'da Charlga Razorflank'ten düşer"
P["Drops from Dark Iron dwarves in Blackrock Depths once Abandoned Hope is turned in"] = "Abandoned Hope teslim edildikten sonra Blackrock Depths'teki Dark Iron cücelerinden düşer"
P["Drops from the dwarves and troggs in Uldaman"] = "Uldaman'daki cücelerden ve trogglardan düşer"
P["Drops in Dire Maul; also tradeable"] = "Dire Maul'da düşer; takas da edilebilir"
P["Druid class book. Click the book to start the quest."] = "Druid sınıf kitabı. Görevi başlatmak için kitaba tıkla."
P["Druid class quest. The Putrid Vine drops from Atal'alarion in the temple basement.\n\nOptional introductory quest:"] = "Druid sınıf görevi. Çürümüş Sarmaşık, tapınak bodrumundaki Atal'alarion'dan düşer.\n\nİsteğe bağlı giriş görevi:"
P["Druid trainers"] = "Druid eğitmenleri"
P["Durgen Dirgehammer's room"] = "Durgen Dirgehammer'ın odası"
P["Duthorian Rall: Cathedral of Light, Stormwind"] = "Duthorian Rall: Cathedral of Light, Stormwind"
P["Earthseer Farsen, Dun Morogh (after Underground Map)"] = "Earthseer Farsen, Dun Morogh (Yeraltı Haritası'ndan sonra)"
P["Ebru, above the entrance to Wailing Caverns, The Barrens"] = "Ebru, Wailing Caverns girişinin üstünde, The Barrens"
P["Emissary Jacques in Southshore, Hillsbrad Foothills"] = "Emissary Jacques, Southshore, Hillsbrad Foothills"
P["Enohar Thunderbrew: Nethergarde Keep, Blasted Lands"] = "Enohar Thunderbrew: Nethergarde Keep, Blasted Lands"
P["Enter the Excavation Sites in the Wetlands and bring back 4 Thicket Raptor Meat."] = "Wetlands'teki Excavation Sites'a gir ve 4 Thicket Raptor Eti getir."
P["Escort Marshal Windsor through the prison. Clear the patrols first and have everyone ready before you start."] = "Marshal Windsor'a hapishane boyunca eşlik et. Önce devriyeleri temizle ve başlamadan önce herkesin hazır olmasını sağla."
P["Essence of Eranikus (drops from the Shade of Eranikus)"] = "Eranikus'un Özü (Shade of Eranikus'tan düşer)"
P["Essence of the Elements drops from BRD elementals and golems."] = "Elementlerin Özü, BRD elementallerinden ve golemlerinden düşer."
P["Examine the Altar of Hakkar in the temple basement. Started from Marvon Rivetseeker after The Stone Circle."] = "Tapınak bodrumundaki Hakkar Sunağı'nı incele. The Stone Circle'dan sonra Marvon Rivetseeker'dan başlar."
P["Extra-Destructive Explosives quest-start item"] = "Extra-Destructive Explosives görev başlatma eşyası"
P["Eye of Mugg"] = "Mugg'ın Gözü"
P["Falla Sagewind — above Wailing Caverns"] = "Falla Sagewind — Wailing Caverns'ın üstünde"
P["Falla Sagewind, on top of the mountain above Wailing Caverns, The Barrens (48.2, 32.8)"] = "Falla Sagewind, Wailing Caverns'ın üstündeki dağın tepesinde, The Barrens (48.2, 32.8)"
P["Farholde Keep, Riverglades (giver not known yet)"] = "Farholde Keep, Riverglades (görev veren henüz bilinmiyor)"
P["Farholde Keep, Riverglades (not known yet)"] = "Farholde Keep, Riverglades (henüz bilinmiyor)"
P["Farm Dark Iron Spies here for the Dark Iron Map"] = "Dark Iron Haritası için Dark Iron Casuslarını burada kes"
P["Fill her vial at the dire pool along Eldreth Row in Dire Maul West; also bring 1 Enchanted Thorium Bar and 5 Crystal Restore.\n\nOptional introductory quest:"] = "Dire Maul West'te Eldreth Row boyunca uğursuz havuzda şişesini doldur; ayrıca 1 Efsunlu Thorium Külçesi ve 5 Crystal Restore getir.\n\nİsteğe bağlı giriş görevi:"
P["Fill the Coated Cerulean Vial at the orange crystal pool in the outer caves, then use it on Vylestem Vines inside (orange side) and kill the Noxxious Scions to heal 8 plants."] = "Kaplanmış Gök Mavisi Şişe'yi dış mağaralardaki turuncu kristal havuzunda doldur, sonra içerideki (turuncu taraf) Vylestem Sarmaşıkları üzerinde kullan ve 8 bitkiyi iyileştirmek için Noxxious Scion'ları öldür."
P["Fill the Egg of Hakkar from the Hakkari Bloodkeepers to summon the Avatar of Hakkar."] = "Avatar of Hakkar'ı çağırmak için Hakkar Yumurtası'nı Hakkari Bloodkeeper'lardan doldur."
P["Final boss, in Honor's Tomb."] = "Son boss, Honor's Tomb'da."
P["Final boss, in the Athenaeum. Doan's Strongbox behind him holds The Scarlet Key."] = "Son boss, Athenaeum'da. Arkasındaki Doan's Strongbox'ta The Scarlet Key var."
P["Final dungeon step of the Defias Brotherhood chain; complete the earlier steps first."] = "Defias Brotherhood zincirinin son zindan adımı; önce önceki adımları tamamla."
P["Final preparation before Destruction in Deadmines."] = "Deadmines'taki Destruction öncesi son hazırlık."
P["Final prerequisite before the dungeon step of The Defias Brotherhood."] = "The Defias Brotherhood'un zindan adımı öncesi son ön koşul."
P["Final required step before Horrors in the Highland."] = "Horrors in the Highland öncesi gerekli son adım."
P["Final step of the Toxic Soil chain."] = "Toxic Soil zincirinin son adımı."
P["Final step. Ambassador Malcin is outside Razorfen Downs."] = "Son adım. Ambassador Malcin, Razorfen Downs'ın dışında."
P["Final step. Old Fire-Eye is at the Greymane Wall in southern Silverpine Forest. Rewards Wolfsbane."] = "Son adım. Old Fire-Eye, güney Silverpine Forest'taki Greymane Wall'da. Ödül: Wolfsbane."
P["Final step. Rewards Verigan's Fist."] = "Son adım. Ödül: Verigan's Fist."
P["Find Ardin Grassman in the Excavation Sites. Learn what happened to Ardin Grassman."] = "Excavation Sites'ta Ardin Grassman'ı bul. Ardin Grassman'a ne olduğunu öğren."
P["Find Daewyn inside the dungeon. Fallen in the Fen sends you back to Dorin Songblade in Lakeshire."] = "Daewyn'i zindanın içinde bul. Fallen in the Fen seni Lakeshire'daki Dorin Songblade'e geri gönderir."
P["Find a Gordok Shackle Key on the ogres of the Gordok wing and use it to free Knot Thimblejack."] = "Gordok kanadındaki ogrelerden bir Gordok Pranga Anahtarı bul ve Knot Thimblejack'i serbest bırakmak için kullan."
P["First quest of the Toxic Soil chain."] = "Toxic Soil zincirinin ilk görevi."
P["First required Hidden Enemies step for the Ragefire Chasm chain."] = "Ragefire Chasm zinciri için gerekli ilk Hidden Enemies adımı."
P["First required step before Horrors in the Highland."] = "Horrors in the Highland öncesi gerekli ilk adım."
P["First required step leading to The Stockade Riots."] = "The Stockade Riots görevine götüren gerekli ilk adım."
P["First step of the required Defias Brotherhood chain."] = "Gerekli Defias Brotherhood zincirinin ilk adımı."
P["Follow-up of Lost in the Thicket Things."] = "Lost in the Thicket Things görevinin devamı."
P["Follows Speak with Shoni."] = "Speak with Shoni görevinden sonra gelir."
P["Follows the Damp Note version of Allegiance to the Old Gods."] = "Allegiance to the Old Gods görevinin Nemli Not sürümünden sonra gelir."
P["Found in a Pitted Iron Chest underwater in the Pool of Ask'ar, in the northern alcove just past Ghamoo-ra's turtle room."] = "Ghamoo-ra'nın kaplumbağa odasını hemen geçince kuzey girintide, Pool of Ask'ar'da su altındaki bir Oyuk Demir Sandık'ta bulunur."
P["Found in the graveyard inside Ruins of Lordaeron"] = "Ruins of Lordaeron içindeki mezarlıkta bulunur"
P["Found in: Jordan's Hammer, Shadowfang Keep courtyard"] = "Bulunduğu yer: Jordan's Hammer, Shadowfang Keep avlusu"
P["Found in: a locked chest in the courtyard stables of Shadowfang Keep. Open it with the Twin Key"] = "Bulunduğu yer: Shadowfang Keep avlusundaki ahırda kilitli bir sandık. Twin Key ile aç"
P["Found in: the Padlocked Reliquary in the first small room on the left of the Scarlet Monastery Library. Open it with the Reliquary Key"] = "Bulunduğu yer: Scarlet Monastery Library'nin solundaki ilk küçük odadaki Asma Kilitli Emanet Sandığı. Reliquary Key ile aç"
P["Found in: the Personal Letterbox in Arcanist Doan's room, Scarlet Monastery Library. Open it with the Scryer's Key"] = "Bulunduğu yer: Scarlet Monastery Library'de Arcanist Doan'ın odasındaki Kişisel Mektup Kutusu. Scryer's Key ile aç"
P["Found in: the Stone Coffer in the mausoleum on the north side of the Scarlet Monastery Graveyard. It opens after you sit on both benches between the two statues"] = "Bulunduğu yer: Scarlet Monastery Graveyard'ın kuzey tarafındaki türbedeki Taş Sandık. İki heykel arasındaki iki banka da oturduktan sonra açılır"
P["Found in: the Supply Locker in the stables behind the Scarlet Monastery. Wear it to pass the Scarlet Crusade"] = "Bulunduğu yer: Scarlet Monastery'nin arkasındaki ahırdaki Erzak Dolabı. Scarlet Crusade'in arasından geçmek için giy"
P["Found on Berard's Bookshelf in the Pyrewood Village inn (Silverpine Forest 43, 73)"] = "Pyrewood Village hanındaki Berard'ın Kitaplığı'nda bulunur (Silverpine Forest 43, 73)"
P["Found on a table in Archmage Arugal's room at the end of Shadowfang Keep, after you kill him"] = "Shadowfang Keep'in sonunda Archmage Arugal'ı öldürdükten sonra odasındaki bir masada bulunur"
P["Found while investigating the Dalaran forces around the Lordamere Internment Camp"] = "Lordamere Internment Camp çevresindeki Dalaran kuvvetleri araştırılırken bulunur"
P["From Amnennar the Coldbringer, the last boss of Razorfen Downs"] = "Razorfen Downs'ın son boss'u Amnennar the Coldbringer'dan"
P["From Nar'gurk in Krol'dok Stronghold"] = "Krol'dok Stronghold'daki Nar'gurk'tan"
P["From Overlord Mugg, the last boss of Krol'dok Stronghold"] = "Krol'dok Stronghold'un son boss'u Overlord Mugg'dan"
P["From The Beast's corpse, Upper Blackrock Spire"] = "The Beast'in cesedinden, Upper Blackrock Spire"
P["From Veenix, Stonetalon Mountains, for a Venture Co. Work Order. Blows open the courtyard gate of Shadowfang Keep"] = "Bir Venture Co. İş Emri karşılığında Stonetalon Mountains'taki Veenix'ten. Shadowfang Keep'in avlu kapısını patlatarak açar"
P["From the first major three-way junction, take the right-hand tunnel, follow it uphill toward the dead end, then enter the small side room on the left. Interact with Maur's corpse there."] = "İlk büyük üç yollu kavşaktan sağdaki tünele gir, onu yokuş yukarı çıkmaza doğru takip et, sonra soldaki küçük yan odaya gir. Oradaki Maur'un cesediyle etkileşime geç."
P["From the most powerful priest in the Drowned City"] = "Drowned City'deki en güçlü rahipten"
P["From the tablet Gri'lek the Wanderer, at the bottom of the Vile Reef (around 25, 23)"] = "Gri'lek the Wanderer tabletinden, Vile Reef'in dibinde (yaklaşık 25, 23)"
P["Frost Shock and You (book, Dire Maul drop)"] = "Frost Shock and You (kitap, Dire Maul ganimeti)"
P["Garona: A Study on Stealth and Treachery (book, Dire Maul drop)"] = "Garona: A Study on Stealth and Treachery (kitap, Dire Maul ganimeti)"
P["General Drakkisath's Command (drops from Overlord Wyrmthalak)"] = "General Drakkisath's Command (Overlord Wyrmthalak'tan düşer)"
P["Gerrig Bonegrip, Forlorn Cavern, Ironforge (50.8, 5.6)"] = "Gerrig Bonegrip, Forlorn Cavern, Ironforge (50.8, 5.6)"
P["Gershala Nightwhisper, Auberdine, Darkshore (38.3, 43.1)"] = "Gershala Nightwhisper, Auberdine, Darkshore (38.3, 43.1)"
P["Get a Gordok Shackle Key from the North ogres and free Knot; his cache has loot."] = "North ogrelerinden bir Gordok Pranga Anahtarı al ve Knot'u serbest bırak; zulasında ganimet var."
P["Get poisoned by Mother Smolderweb and reach Ragged John while still poisoned. Don't let anyone cleanse it."] = "Mother Smolderweb tarafından zehirlen ve hâlâ zehirliyken Ragged John'a ulaş. Kimsenin zehri temizlemesine izin verme."
P["Ghostly Attendant, inside Hall of Thanes, after the first room"] = "Ghostly Attendant, Hall of Thanes içinde, ilk odadan sonra"
P["Ghostly Attendant, inside the dungeon"] = "Ghostly Attendant, zindanın içinde"
P["Give Aurius the Medallion of Faith before the Baron fight; speak to him after Baron Rivendare dies."] = "Baron savaşından önce İnanç Madalyonu'nu Aurius'a ver; Baron Rivendare öldükten sonra onunla konuş."
P["Give Aurius the Medallion of Faith; he joins the fight against Baron Rivendare. Claim his reward after the battle."] = "İnanç Madalyonu'nu Aurius'a ver; Baron Rivendare'e karşı savaşa katılır. Savaştan sonra ödülünü al."
P["Given by Ashe Amberhall when you accept the quest"] = "Görevi kabul ettiğinde Ashe Amberhall verir"
P["Given by Jordan Stilwell when you accept the quest"] = "Görevi kabul ettiğinde Jordan Stilwell verir"
P["Given by Trevan Rol in the Sepulcher"] = "Sepulcher'daki Trevan Rol verir"
P["Gnomeregan — outer area"] = "Gnomeregan — dış bölge"
P["Gordok Commons, the ogre-held northern wing. Kill King Gordok to become the new king; leave the guards alive (the Tribute Run) for a bigger tribute chest."] = "Ogrelerin elindeki kuzey kanadı Gordok Commons. Yeni kral olmak için King Gordok'u öldür; daha büyük bir haraç sandığı için muhafızları hayatta bırak (Tribute Run)."
P["Grime-Encrusted Ring, dropped by Dark Iron dwarves in Gnomeregan"] = "Kirle Kaplı Yüzük, Gnomeregan'daki Dark Iron cücelerinden düşer"
P["Grimtotem Satchel, taken from Maur Grimtotem's corpse inside Ragefire Chasm"] = "Grimtotem Heybesi, Ragefire Chasm içindeki Maur Grimtotem'in cesedinden alınır"
P["Grom'gol Base Camp, Stranglethorn Vale (not known yet)"] = "Grom'gol Base Camp, Stranglethorn Vale (henüz bilinmiyor)"
P["Grom'gol Base Camp, Stranglethorn Vale (quest giver not known yet)"] = "Grom'gol Base Camp, Stranglethorn Vale (görev veren henüz bilinmiyor)"
P["Gromsblood, Giant Silver Veins (Azshara cliff giants) and the vial filled at Golakka Hot Springs in Un'Goro. Opens a peaceful way through the bar on later visits."] = "Gromsblood, Dev Gümüş Damarları (Azshara uçurum devleri) ve Un'Goro'daki Golakka Hot Springs'te doldurulan şişe. Sonraki ziyaretlerde bardan barışçıl bir geçiş açar."
P["Group quest: Riptear is a level 13 elite."] = "Grup görevi: Riptear 13. seviye elit."
P["Group quest: the Saltscale murlocs at the Vile Reef are elite."] = "Grup görevi: Vile Reef'teki Saltscale murlocları elit."
P["Group quest: the inn is in Pyrewood Village, among hostile villagers."] = "Grup görevi: han, düşman köylülerin arasında, Pyrewood Village'da."
P["Gryan Stoutmantle, Sentinel Hill tower, Westfall (56.4, 47.5)"] = "Gryan Stoutmantle, Sentinel Hill kulesi, Westfall (56.4, 47.5)"
P["Gryan Stoutmantle: Sentinel Hill, Westfall"] = "Gryan Stoutmantle: Sentinel Hill, Westfall"
P["Hammertoe Grez — Uldaman excavation (outside the instance)"] = "Hammertoe Grez — Uldaman kazısı (zindanın dışında)"
P["Hammertoe Grez, Uldaman excavation (outside the instance)"] = "Hammertoe Grez, Uldaman kazısı (zindanın dışında)"
P["Hammertoe is in the outer excavation caves, before the instance portal"] = "Hammertoe, zindan portalından önce dış kazı mağaralarında"
P["Hand in The Archivist first, or Balnazzar's head will not start this quest."] = "Önce The Archivist'i teslim et, yoksa Balnazzar'ın kafası bu görevi başlatmaz."
P["Hanging outside the room in Thoradin's Wall"] = "Thoradin's Wall'daki odanın dışında asılı"
P["Harbinger Balthazad — Undercity (walks around)"] = "Harbinger Balthazad — Undercity (dolaşır)"
P["Harbinger Balthazad, Undercity (or Warcaller Gorlach, Orgrimmar / Bluff Runner Windstrider, Thunder Bluff)"] = "Harbinger Balthazad, Undercity (veya Warcaller Gorlach, Orgrimmar / Bluff Runner Windstrider, Thunder Bluff)"
P["Harbinger Balthazad: Trade Quarter, Undercity (walks around)"] = "Harbinger Balthazad: Trade Quarter, Undercity (dolaşır)"
P["Harnessing Shadows (book, Dire Maul drop)"] = "Harnessing Shadows (kitap, Dire Maul ganimeti)"
P["Hastily Rolled-Up Satchel, right under the Messenger Bag"] = "Aceleyle Sarılmış Heybe, Ulak Çantası'nın hemen altında"
P["He appears from The Beast's corpse after the fight. Malyfous then offers the Pristine Hide of the Beast exchanges."] = "Savaştan sonra The Beast'in cesedinden çıkar. Malyfous ardından Pristine Hide of the Beast takaslarını sunar."
P["Head of Balnazzar (drops from Balnazzar)"] = "Balnazzar'ın Kafası (Balnazzar'dan düşer)"
P["Head straight north from the camp, climb the hill and jump down from its edge to the Mound of Dirt. Watch your step."] = "Kamptan dümdüz kuzeye git, tepeye tırman ve kenarından toprak yığınına atla. Adımına dikkat et."
P["Henrig Lonebrow — bottom of the Great Lift"] = "Henrig Lonebrow — Great Lift'in dibi"
P["Henrig Lonebrow's Journal beside his corpse at the bottom of the Great Lift"] = "Henrig Lonebrow'un Günlüğü, Great Lift'in dibinde cesedinin yanında"
P["Heralath Fallowbrook, inside Razorfen Kraul"] = "Heralath Fallowbrook, Razorfen Kraul içinde"
P["Herod is in the Armory; Loksey in the Library; Mograine and Whitemane in the Cathedral."] = "Herod Armory'de; Loksey Library'de; Mograine ve Whitemane Cathedral'da."
P["Herod is in the Armory; Loksey in the Library; Mograine and Whitemane in the Cathedral.\n\nOptional introductory quest:"] = "Herod Armory'de; Loksey Library'de; Mograine ve Whitemane Cathedral'da.\n\nİsteğe bağlı giriş görevi:"
P["Holy Bologna: What the Light Won't Tell You (book, Dire Maul drop)"] = "Holy Bologna: What the Light Won't Tell You (kitap, Dire Maul ganimeti)"
P["Horde Dalaran attunement. Stone Tokens and Bracers of Binding can be done alongside the chain, but they are optional and are not required for attunement."] = "Horde Dalaran uyumlanması. Stone Tokens ve Bracers of Binding zincirle birlikte yapılabilir ama isteğe bağlıdır, uyumlanma için gerekli değildir."
P["Horde step required before Nogg's Ring Redo."] = "Nogg's Ring Redo öncesi gerekli Horde adımı."
P["Hunter class book. Click the book to start the quest."] = "Hunter sınıf kitabı. Görevi başlatmak için kitaba tıkla."
P["Hunter class quest. The Tooth of Morphaz drops from Morphaz.\n\nOptional introductory quest:"] = "Hunter sınıf görevi. Morphaz'ın Dişi Morphaz'dan düşer.\n\nİsteğe bağlı giriş görevi:"
P["Hunter trainers"] = "Hunter eğitmenleri"
P["I'lalai, a lost Gurubashi troll city, has risen from the sea off the coast of Stranglethorn Vale, west of Grom'gol. Trolls and naga roam the streets of this open-air dungeon, a pirate ship lies wrecked nearby, and the weather builds into a full storm before the final fight. Dive underwater to find the entrance."] = "Kayıp bir Gurubashi trol şehri olan I'lalai, Stranglethorn Vale kıyısı açıklarında, Grom'gol'un batısında denizden yükseldi. Bu açık hava zindanının sokaklarında troller ve nagalar dolaşıyor, yakında bir korsan gemisi batık yatıyor ve son savaştan önce hava tam bir fırtınaya dönüşüyor. Girişi bulmak için su altına dal."
P["Image of Archmage Modera — Lordamere Lake near Dalaran"] = "Image of Archmage Modera — Dalaran yakınındaki Lordamere Lake"
P["Image of Archmage Modera, Lordamere Lake near Dalaran"] = "Image of Archmage Modera, Dalaran yakınındaki Lordamere Lake"
P["In Krol'dok Stronghold (the Alliance quest of the same name takes it from Nar'gurk)"] = "Krol'dok Stronghold'da (aynı adlı Alliance görevi onu Nar'gurk'tan alır)"
P["In a tent on top of the mountain above Wailing Caverns"] = "Wailing Caverns'ın üstündeki dağın tepesinde bir çadırda"
P["In the Chamber of Atonement. Drops Vorrel's Wedding Ring for Vorrel's Revenge."] = "Chamber of Atonement'ta. Vorrel's Revenge için Vorrel's Wedding Ring düşürür."
P["In the Map Chamber beyond Archaedas, inside Uldaman"] = "Uldaman içinde, Archaedas'ın ötesindeki Map Chamber'da"
P["Infiltrate Krol'dok Stronghold and return to Commander Brant with proof of their leader's demise."] = "Krol'dok Stronghold'a sız ve liderlerinin ölümünün kanıtıyla Commander Brant'e dön."
P["Infiltrate Krol'dok Stronghold and return to Krom'rosh with proof of their leader's demise."] = "Krol'dok Stronghold'a sız ve liderlerinin ölümünün kanıtıyla Krom'rosh'a dön."
P["Inside a vault in the Reliquary of Kings (Durgen Dirgehammer's room)"] = "Reliquary of Kings'teki bir kasanın içinde (Durgen Dirgehammer'ın odası)"
P["Inside the building in Tarren Mill"] = "Tarren Mill'deki binanın içinde"
P["Inside the instance, in the Dormitory."] = "Zindanın içinde, Dormitory'de."
P["Interact with the Skeletal Remains of Telmius Dreamseeker beside Lorekeeper Lydros in the Athenaeum. Unlocks Lydros's libram exchanges."] = "Athenaeum'da Lorekeeper Lydros'un yanındaki Telmius Dreamseeker'ın İskelet Kalıntıları ile etkileşime geç. Lydros'un libram takaslarını açar."
P["Introductory quest leading to Heart of Disruption and Starving Arcane."] = "Heart of Disruption ve Starving Arcane görevlerine götüren giriş görevi."
P["Introductory step leading to A Better Ingredient."] = "A Better Ingredient görevine götüren giriş adımı."
P["Introductory step leading to Agmond's Fate."] = "Agmond's Fate görevine götüren giriş adımı."
P["Introductory step leading to Blood of Morphaz."] = "Blood of Morphaz görevine götüren giriş adımı."
P["Introductory step leading to Destroy Morphaz."] = "Destroy Morphaz görevine götüren giriş adımı."
P["Introductory step leading to Doomrigger's Clasp."] = "Doomrigger's Clasp görevine götüren giriş adımı."
P["Introductory step leading to Forging the Mightstone."] = "Forging the Mightstone görevine götüren giriş adımı."
P["Introductory step leading to Fragments of the Past."] = "Fragments of the Past görevine götüren giriş adımı."
P["Introductory step leading to Gahz'rilla."] = "Gahz'rilla görevine götüren giriş adımı."
P["Introductory step leading to Hurley Blackbreath."] = "Hurley Blackbreath görevine götüren giriş adımı."
P["Introductory step leading to In the Name of the Light."] = "In the Name of the Light görevine götüren giriş adımı."
P["Introductory step leading to Lethtendris's Web."] = "Lethtendris's Web görevine götüren giriş adımı."
P["Introductory step leading to Lost Thunderbrew Recipe."] = "Lost Thunderbrew Recipe görevine götüren giriş adımı."
P["Introductory step leading to Ramstein."] = "Ramstein görevine götüren giriş adımı."
P["Introductory step leading to Researching the Corruption."] = "Researching the Corruption görevine götüren giriş adımı."
P["Introductory step leading to Ribbly Screwspigot."] = "Ribbly Screwspigot görevine götüren giriş adımı."
P["Introductory step leading to Scarab Shells."] = "Scarab Shells görevine götüren giriş adımı."
P["Introductory step leading to The Azure Key."] = "The Azure Key görevine götüren giriş adımı."
P["Introductory step leading to The Darkstone Tablet."] = "The Darkstone Tablet görevine götüren giriş adımı."
P["Introductory step leading to The Essence of Aku'Mai."] = "The Essence of Aku'Mai görevine götüren giriş adımı."
P["Introductory step leading to The Green Drake."] = "The Green Drake görevine götüren giriş adımı."
P["Introductory step leading to The Hidden Chamber."] = "The Hidden Chamber görevine götüren giriş adımı."
P["Introductory step leading to The Restless Souls."] = "The Restless Souls görevine götüren giriş adımı."
P["Introductory step leading to Tiara of the Deep."] = "Tiara of the Deep görevine götüren giriş adımı."
P["Introductory step leading to Voodoo Feathers."] = "Voodoo Feathers görevine götüren giriş adımı."
P["Investigate the fissure beneath the Forgotten Pools."] = "Forgotten Pools'un altındaki yarığı araştır."
P["Investigate whether Westfall's mines are causing the contamination."] = "Westfall madenlerinin kirlenmeye yol açıp açmadığını araştır."
P["Item start:"] = "Eşyayla başlar:"
P["Item start: Abominable Head, inside Ruins of Lordaeron"] = "Eşyayla başlar: Abominable Head, Ruins of Lordaeron içinde"
P["Item start: Blood-Stained Letter, graveyard inside Ruins of Lordaeron"] = "Eşyayla başlar: Blood-Stained Letter, Ruins of Lordaeron içindeki mezarlık"
P["Item start: Bloodied Insignia, inside Ruins of Lordaeron"] = "Eşyayla başlar: Bloodied Insignia, Ruins of Lordaeron içinde"
P["Item start: Crest of Lordaeron, inside Ruins of Lordaeron"] = "Eşyayla başlar: Crest of Lordaeron, Ruins of Lordaeron içinde"
P["Item start: Glowing Shard, dropped by Mutanus the Devourer"] = "Eşyayla başlar: Glowing Shard, Mutanus the Devourer düşürür"
P["Item-start quest from the Blood-Stained Letter."] = "Blood-Stained Letter ile başlayan görev."
P["Jasper Fel, SI:7, Old Town, Stormwind"] = "Jasper Fel, SI:7, Old Town, Stormwind"
P["Jasper Fel: SI:7, Old Town, Stormwind"] = "Jasper Fel: SI:7, Old Town, Stormwind"
P["Je'neu Sancrea, Zoram'gar Outpost, Ashenvale (12, 34)"] = "Je'neu Sancrea, Zoram'gar Outpost, Ashenvale (12, 34)"
P["Jordan Stilwell stands outside the gates of Ironforge"] = "Jordan Stilwell, Ironforge kapılarının dışında duruyor"
P["Jump onto the carved heads of the dam, on the side facing the Wetlands, to reach the figurine. Getting there is tricky for the Horde."] = "Heykelciğe ulaşmak için barajın Wetlands'e bakan tarafındaki oyma kafaların üzerine atla. Oraya ulaşmak Horde için zordur."
P["KILL ON SIGHT poster"] = "GÖRÜLDÜĞÜ YERDE ÖLDÜR afişi"
P["KILL ON SIGHT poster — Kargath, Badlands"] = "GÖRÜLDÜĞÜ YERDE ÖLDÜR afişi — Kargath, Badlands"
P["Keep Princess Moira alive and speak to her after Emperor Thaurissan dies. Her The Princess Saved? sends you back to Thrall for the reward."] = "Princess Moira'yı hayatta tut ve Emperor Thaurissan öldükten sonra onunla konuş. Onun The Princess Saved? görevi ödül için seni Thrall'a geri gönderir."
P["Keep Princess Moira alive and speak to her after Emperor Thaurissan dies. Her The Princess's Surprise sends you back to Magni for the reward."] = "Princess Moira'yı hayatta tut ve Emperor Thaurissan öldükten sonra onunla konuş. Onun The Princess's Surprise görevi ödül için seni Magni'ye geri gönderir."
P["Keep the card for Matrix Punchograph 3005-A"] = "Kartı Matrix Punchograph 3005-A için sakla"
P["Kernobee, inside Gnomeregan"] = "Kernobee, Gnomeregan içinde"
P["Kill 20 Plagued Hatchlings. After turning this in, hatchlings can drop Healthy Dragon Scales, which start a repeatable turn-in to Betina."] = "20 Vebalı Yavru öldür. Bunu teslim ettikten sonra yavrular, Betina'ya tekrarlanabilir teslim başlatan Sağlıklı Ejderha Pulu düşürebilir."
P["Kill Alzzin the Wildshaper, pick up a Felvine Shard near the vine and seal it in the Reliquary of Purity."] = "Alzzin the Wildshaper'ı öldür, sarmaşığın yanından bir Felvine Parçası al ve onu Reliquary of Purity'ye mühürle."
P["Kill Archivist Galford in the Scarlet Bastion and burn the archives."] = "Scarlet Bastion'da Archivist Galford'u öldür ve arşivleri yak."
P["Kill General Drakkisath at the end of UBRS."] = "UBRS'nin sonunda General Drakkisath'ı öldür."
P["Kill Golem Lord Argelmach for his head and collect 10 Intact Elemental Cores from the constructs guarding him."] = "Kafası için Golem Lord Argelmach'ı öldür ve onu koruyan yapılardan 10 Sağlam Elemental Çekirdek topla."
P["Kill Halycon, the worg den mother. Be ready for Gizrul the Slavener, who comes for you right after."] = "Worg ini annesi Halycon'u öldür. Hemen ardından sana gelecek olan Gizrul the Slavener'a hazır ol."
P["Kill Lord Incendius at the Black Anvil inside BRD and bring back the Tablet of Kurniya."] = "BRD içindeki Black Anvil'de Lord Incendius'u öldür ve Kurniya Tableti'ni geri getir."
P["Kill Lord Incendius at the Black Anvil inside BRD."] = "BRD içindeki Black Anvil'de Lord Incendius'u öldür."
P["Kill Nar'gurk in Krol'dok Stronghold and recover any valuable information."] = "Krol'dok Stronghold'da Nar'gurk'u öldür ve değerli her bilgiyi ele geçir."
P["Kill Princess Theradras in the inner cavern."] = "İç mağarada Princess Theradras'ı öldür."
P["Kill a Highland Horror within Excavation Sites and bring its root core to Rethiel the Greenwarden in the Wetlands."] = "Excavation Sites içinde bir Highland Horror öldür ve kök çekirdeğini Wetlands'teki Rethiel the Greenwarden'a getir."
P["Kill mobs in the outer Gnomeregan area until a White Punch Card drops."] = "Beyaz Delikli Kart düşene kadar dış Gnomeregan bölgesindeki yaratıkları öldür."
P["Kill the guardians of all five pylons, then Immol'thar, then Prince Tortheldrin. Return to the Ancient, take The Treasure of the Shen'dralar and open the chest under the library stairs for the reward."] = "Beş pilonun hepsinin muhafızlarını, sonra Immol'thar'ı, sonra Prince Tortheldrin'i öldür. Ancient'a dön, The Treasure of the Shen'dralar'ı al ve ödül için kütüphane merdivenlerinin altındaki sandığı aç."
P["Kill the six troll guardians on the balconies to drop Jammal'an's barrier, then bring back his head."] = "Jammal'an'ın bariyerini düşürmek için balkonlardaki altı trol muhafızını öldür, sonra kafasını geri getir."
P["Kin'weelay at Grom'gol Base Camp, Stranglethorn Vale"] = "Kin'weelay, Grom'gol Base Camp, Stranglethorn Vale"
P["Klockmort Spannerspan: Tinker Town, Ironforge"] = "Klockmort Spannerspan: Tinker Town, Ironforge"
P["Krazek — upper floor"] = "Krazek — üst kat"
P["Krazek, Booty Bay, Stranglethorn Vale (not confirmed)"] = "Krazek, Booty Bay, Stranglethorn Vale (doğrulanmadı)"
P["Krazek, upstairs in Booty Bay, Stranglethorn Vale"] = "Krazek, Booty Bay'de üst katta, Stranglethorn Vale"
P["Krazek: Booty Bay inn, upper floor"] = "Krazek: Booty Bay hanı, üst kat"
P["Krom'rosh, Riverglades (exact spot not known yet)"] = "Krom'rosh, Riverglades (tam yeri henüz bilinmiyor)"
P["Leads to General Drakkisath's Demise in Upper Blackrock Spire."] = "Upper Blackrock Spire'daki General Drakkisath's Demise görevine götürür."
P["Light the statues around the circle in the right order to summon Atal'alarion."] = "Atal'alarion'u çağırmak için çemberin etrafındaki heykelleri doğru sırayla yak."
P["Long rumored to hold high-ranking prisoners, including King Varian Wrynn, the prison on Alcaz Island has been out of reach until now. Inside, the Defias Brotherhood and the naga are at war. Known bosses so far: Blazeroar."] = "Uzun zamandır King Varian Wrynn dahil üst düzey tutsakları barındırdığı söylenen Alcaz Island'daki hapishaneye şimdiye kadar ulaşılamıyordu. İçeride Defias Brotherhood ile nagalar savaş hâlinde. Şimdilik bilinen bosslar: Blazeroar."
P["Look for Dorin Songblade's brother, Daewyn, in Whelgar's Excavation Site."] = "Dorin Songblade'in kardeşi Daewyn'i Whelgar's Excavation Site'ta ara."
P["Loot Lonebrow's Journal here"] = "Lonebrow'un Günlüğü'nü buradan al"
P["Loot the Amulet of Spirits from the Nameless Prophet in the outer caves, then use it to fight the five Khans: three in the outer caves, one on the purple route and one on the orange route. Combine their gems with the amulet."] = "Dış mağaralardaki Nameless Prophet'ten Ruhlar Muskası'nı al, sonra beş Khan ile savaşmak için kullan: üçü dış mağaralarda, biri mor rotada ve biri turuncu rotada. Taşlarını muskayla birleştir."
P["Looted from"] = "Alındığı yer:"
P["Looted from Edwin VanCleef"] = "Edwin VanCleef'ten alınır"
P["Loremaster Dibbs in Southshore, Hillsbrad Foothills"] = "Loremaster Dibbs, Southshore, Hillsbrad Foothills"
P["Lying at the dwarf dig site west of Hammertoe's Digsite, Badlands"] = "Badlands'te Hammertoe's Digsite'ın batısındaki cüce kazı alanında yerde duruyor"
P["Mage class book. Click the book to start the quest."] = "Mage sınıf kitabı. Görevi başlatmak için kitaba tıkla."
P["Mage class quest. Lydros is in the Athenaeum (North/West); Hydrospawn Essence drops from Hydrospawn in East. Rewards Conjure Water (Rank 7)."] = "Mage sınıf görevi. Lydros, Athenaeum'da (Kuzey/Batı); Hydrospawn Özü, Doğu'daki Hydrospawn'dan düşer. Ödül: Conjure Water (Rütbe 7)."
P["Mage class quest. The Arcane Shard drops from Morphaz.\n\nOptional introductory quest:"] = "Mage sınıf görevi. Arkan Kırığı Morphaz'dan düşer.\n\nİsteğe bağlı giriş görevi:"
P["Mage class quest. The Obsidian Sentinel guards the back entrance of Uldaman. Continues with Mana Surges for the Celestial Orb or Celestial Stave."] = "Mage sınıf görevi. Obsidian Sentinel, Uldaman'ın arka girişini korur. Celestial Orb veya Celestial Stave için Mana Surges ile devam eder."
P["Mage trainers"] = "Mage eğitmenleri"
P["Mage trainers (mages only)"] = "Mage eğitmenleri (yalnızca mage'ler)"
P["Magics of the Drowned City"] = "Drowned City'nin Büyüleri"
P["Make rubbings of the four Tablets of I'lalai in the Drowned City."] = "Drowned City'deki dört I'lalai Tableti'nin kopyasını çıkar."
P["Malor's Strongbox in the Scarlet Bastion holds the medallion. Give it to Aurius in the chapel before fighting the Baron."] = "Madalyon, Scarlet Bastion'daki Malor'un Kasası'nda. Baron ile savaşmadan önce onu şapeldeki Aurius'a ver."
P["Master Mathias Shaw: SI:7, Old Town, Stormwind"] = "Master Mathias Shaw: SI:7, Old Town, Stormwind"
P["Matrix Punchograph 3005-A, Workshop area of the Train Depot, outside the instance"] = "Matrix Punchograph 3005-A, Train Depot'nun atölye bölümü, zindanın dışında"
P["Matrix Punchograph 3005-B, The Dormitory (just past the Clean Zone), inside the instance"] = "Matrix Punchograph 3005-B, The Dormitory (Clean Zone'u hemen geçince), zindanın içinde"
P["Matrix Punchograph 3005-C, upper platform of the Launch Bay with Electrocutioner 6000"] = "Matrix Punchograph 3005-C, Electrocutioner 6000'in bulunduğu Launch Bay'in üst platformu"
P["Matrix Punchograph 3005-D, west side of the lower level of the Engineering Labs"] = "Matrix Punchograph 3005-D, Engineering Labs'in alt katının batı tarafı"
P["Maur Grimtotem's corpse"] = "Maur Grimtotem'in cesedi"
P["Maur Grimtotem's corpse inside Ragefire Chasm. From the first major three-way junction, take the right-hand tunnel, follow it uphill toward the dead end, then enter the small side room on the left. Interact with Maur's corpse there."] = "Ragefire Chasm içindeki Maur Grimtotem'in cesedi. İlk büyük üç yollu kavşaktan sağdaki tünele gir, onu yokuş yukarı çıkmaza doğru takip et, sonra soldaki küçük yan odaya gir. Oradaki Maur'un cesediyle etkileşime geç."
P["Mazu'kon of the Earthen Ring, north-west Mulgore"] = "Earthen Ring'den Mazu'kon, kuzeybatı Mulgore"
P["Messenger Bag hanging at Thoradin's Wall, Hillsbrad Foothills (85.7, 52.2)"] = "Thoradin's Wall'da asılı Ulak Çantası, Hillsbrad Foothills (85.7, 52.2)"
P["Mining 230. Talk to Gloom'rel before the Seven fight; give the Spectral Chalice 2 Star Rubies, 20 Gold Bars and 10 Truesilver Bars to learn Smelt Dark Iron."] = "Madencilik 230. Seven savaşından önce Gloom'rel ile konuş; Smelt Dark Iron'u öğrenmek için Hayalet Kadeh'e 2 Yıldız Yakutu, 20 Altın Külçe ve 10 Truesilver Külçe ver."
P["Monastery-wide collection: any Scarlet humanoid on the way to the Cathedral can drop Hearts of Zeal."] = "Manastır genelinde toplama: Cathedral'a giden yoldaki herhangi bir Scarlet insansısı Şevk Kalbi düşürebilir."
P["Mound of Dirt below the cliff north of the camp, Stonetalon Mountains (39.6, 49.9)"] = "Kampın kuzeyindeki uçurumun altındaki toprak yığını, Stonetalon Mountains (39.6, 49.9)"
P["Myriam Moonsinger, Razorfen Downs thorn maze, The Barrens"] = "Myriam Moonsinger, Razorfen Downs diken labirenti, The Barrens"
P["Nailed Plank on the side of the burnt tower south of Camp Taurajo, The Barrens (46.4, 73.8)"] = "Camp Taurajo'nun güneyindeki yanık kulenin yanında çivili tahta, The Barrens (46.4, 73.8)"
P["Nalpak, above the entrance to Wailing Caverns, The Barrens"] = "Nalpak, Wailing Caverns girişinin üstünde, The Barrens"
P["Nara Wildmane is the final prerequisite before Leaders of the Fang becomes available."] = "Nara Wildmane, Leaders of the Fang açılmadan önceki son ön koşul."
P["Near the entrance to Talondeep Path"] = "Talondeep Path girişinin yakınında"
P["Needs both KILL ON SIGHT quests and the Grark Lorkrub escort first."] = "Önce her iki KILL ON SIGHT görevi ve Grark Lorkrub eskortu gerekir."
P["Neeru is in the Cleft of Shadow near the Ragefire Chasm entrance."] = "Neeru, Ragefire Chasm girişinin yakınındaki Cleft of Shadow'da."
P["New in Forever. The book is held by Arcanist Doan."] = "Forever'da yeni. Kitap Arcanist Doan'dadır."
P["Newer Classic records call him Ezra Grimm. Clear the smoke shop, touch the tobacco box and kill the shopkeeper."] = "Daha yeni Classic kayıtları ona Ezra Grimm der. Tütün dükkânını temizle, tütün kutusuna dokun ve dükkân sahibini öldür."
P["Northern Barrens"] = "Kuzey Barrens"
P["Nostro's Compendium of Dragon Slaying (rare Dire Maul drop)"] = "Nostro's Compendium of Dragon Slaying (nadir Dire Maul ganimeti)"
P["Not confirmed yet"] = "Henüz doğrulanmadı"
P["Not known yet"] = "Henüz bilinmiyor"
P["Not known yet (a Kirin Tor mage who works with Archmage Lan'dalock in Dalaran)"] = "Henüz bilinmiyor (Dalaran'da Archmage Lan'dalock ile çalışan bir Kirin Tor büyücüsü)"
P["Not known yet (a highborne; Kirin Tor reputation, so probably in Dalaran)"] = "Henüz bilinmiyor (bir highborne; Kirin Tor itibarı, yani muhtemelen Dalaran'da)"
P["OPTIONAL, not required"] = "İSTEĞE BAĞLI, gerekli değil"
P["Objective not confirmed yet."] = "Hedef henüz doğrulanmadı."
P["Offered after C's next letter reaches you in a capital city."] = "C'nin bir sonraki mektubu sana bir başkentte ulaştıktan sonra sunulur."
P["Ogre outrunners have been kidnapping travelers and raiding settlements across the Riverglades. Their trail leads to a fortress of workshops, encampments and guarded inner passages, where strange chanting is heard after nightfall."] = "Ogre akıncıları Riverglades genelinde yolcuları kaçırıyor ve yerleşimlere baskın yapıyor. İzleri atölyeler, kamplar ve korunan iç geçitlerden oluşan, gece çökünce tuhaf ilahilerin duyulduğu bir kaleye çıkıyor."
P["On Electrocutioner 6000's platform."] = "Electrocutioner 6000'in platformunda."
P["On a box at the abandoned camp"] = "Terk edilmiş kamptaki bir kutunun üzerinde"
P["On the carved heads of the dam, facing the Wetlands"] = "Barajın Wetlands'e bakan oyma kafalarının üzerinde"
P["On the ground at Agmond's End, southern Badlands"] = "Güney Badlands'te Agmond's End'de yerde"
P["On the ground in the Witherbark troll camps, The Hinterlands"] = "Witherbark trol kamplarında yerde, The Hinterlands"
P["On the wall in Kargath, Badlands"] = "Kargath'ta duvarda, Badlands"
P["Open his cell with the Prison Cell Key from High Interrogator Gerstahn, then defend him."] = "High Interrogator Gerstahn'dan alınan Hapishane Hücresi Anahtarı ile hücresini aç, sonra onu savun."
P["Optional Alliance breadcrumb leading to Researching the Corruption."] = "Researching the Corruption görevine götüren isteğe bağlı Alliance yönlendirme görevi."
P["Optional introductory quest:"] = "İsteğe bağlı giriş görevi:"
P["Orc, Tauren and Troll only; Undead cannot take this quest."] = "Yalnızca Orc, Tauren ve Troll; Undead'ler bu görevi alamaz."
P["Outside Dalaran near Lordamere Lake"] = "Lordamere Lake yakınında, Dalaran'ın dışında"
P["Paladin charger quest. Clear Rattlegore's basement in the Great Ossuary, use the Divination Scryer and defeat the spirits and Death Knight Darkreaver."] = "Paladin savaş atı görevi. Great Ossuary'de Rattlegore'un bodrumunu temizle, Divination Scryer'ı kullan ve ruhları ve Death Knight Darkreaver'ı yen."
P["Paladin charger quest. Kill Tendris Warpwood, then feed the Ancient Equine Spirit and give it the Arcanite Barding. Bring the Manna-Enriched Horse Feed from Merideth Carlson in Southshore."] = "Paladin savaş atı görevi. Tendris Warpwood'u öldür, sonra Ancient Equine Spirit'i besle ve ona Arcanite Barding'i ver. Manna ile Zenginleştirilmiş At Yemi'ni Southshore'daki Merideth Carlson'dan getir."
P["Paladin class book. Click the book to start the quest."] = "Paladin sınıf kitabı. Görevi başlatmak için kitaba tıkla."
P["Paladin class quest for humans and dwarves. In this dungeon: Whitestone Oak Lumber drops from Goblin Woodcarvers. The other parts are Jordan's Smithing Hammer (Shadowfang Keep), the Kor Gem (Blackfathom Deeps) and Jordan's ore shipment (Loch Modan)."] = "İnsanlar ve cüceler için Paladin sınıf görevi. Bu zindanda: Whitestone Meşe Kerestesi Goblin Woodcarver'lardan düşer. Diğer parçalar Jordan's Smithing Hammer (Shadowfang Keep), Kor Gem (Blackfathom Deeps) ve Jordan'ın cevher sevkiyatı (Loch Modan)."
P["Paladin class quest for undead and tauren. In this dungeon: Whitestone Oak Lumber drops from Goblin Woodcarvers. The other parts are the Enchanted Silver Ingot (Shadowfang Keep) and the Purified Kor Gem (Blackfathom Deeps)."] = "Undead'ler ve taurenler için Paladin sınıf görevi. Bu zindanda: Whitestone Meşe Kerestesi Goblin Woodcarver'lardan düşer. Diğer parçalar Enchanted Silver Ingot (Shadowfang Keep) ve Purified Kor Gem (Blackfathom Deeps)."
P["Paladin class quest. Needs 2 amber, 2 blue and 2 green Voodoo Feathers from the six troll guardians: Gasher, Mijan, Zolo, Hukku, Zul'Lor and Loro.\n\nOptional introductory quest:"] = "Paladin sınıf görevi. Altı trol muhafızından 2 kehribar, 2 mavi ve 2 yeşil Vudu Tüyü gerekir: Gasher, Mijan, Zolo, Hukku, Zul'Lor ve Loro.\n\nİsteğe bağlı giriş görevi:"
P["Parqual Fintallas in Undercity"] = "Parqual Fintallas, Undercity'de"
P["Part of the Horde Onyxia chain. Black Dragonspawn Eyes drop from the dragonspawn in UBRS."] = "Horde Onyxia zincirinin parçası. Kara Ejderha Yavrusu Gözleri UBRS'deki dragonspawn'lardan düşer."
P["Part of the Onyxia attunement."] = "Onyxia uyumlanmasının parçası."
P["Part of the chain that begins with The Unsent Letter from Edwin VanCleef in The Deadmines."] = "The Deadmines'ta Edwin VanCleef'ten gelen The Unsent Letter ile başlayan zincirin parçası."
P["Pick pocket a Scarlet Scryer in the first big room of the Scarlet Monastery Graveyard"] = "Scarlet Monastery Graveyard'ın ilk büyük odasındaki bir Scarlet Scryer'ın cebini çal"
P["Pick up Key to the City from Magus Wordeen Voidglare at the same time."] = "Aynı anda Magus Wordeen Voidglare'den Key to the City görevini de al."
P["Plant the explosives at the forge, then return to Alba Fairmoon."] = "Patlayıcıları demirhaneye yerleştir, sonra Alba Fairmoon'a dön."
P["Pocket Litter on a box at the abandoned camp, Stonetalon Mountains (40.8, 52.6)"] = "Terk edilmiş kamptaki bir kutunun üzerinde cep döküntüleri, Stonetalon Mountains (40.8, 52.6)"
P["Priest class book. Click the book to start the quest."] = "Priest sınıf kitabı. Görevi başlatmak için kitaba tıkla."
P["Priest class quest. Morphaz's blood is turned in to Greta Mosshoof, not Ogtinc.\n\nOptional introductory quest:"] = "Priest sınıf görevi. Morphaz'ın kanı Ogtinc'e değil, Greta Mosshoof'a teslim edilir.\n\nİsteğe bağlı giriş görevi:"
P["Priest trainers"] = "Priest eğitmenleri"
P["Prismatic Punch Card (Punchograph 3005-D)"] = "Prizmatik Delikli Kart (Punchograph 3005-D)"
P["Provided for Blood in the Streets"] = "Blood in the Streets için verilir"
P["Quest data is recorded in the beta; dungeon access may be unavailable."] = "Görev verisi betada kaydedildi; zindana erişim mümkün olmayabilir."
P["Quest giver not confirmed yet. Lead-in: An Acquaintance in Southshore, taking the Savage Coast Report Bundle to Loremaster Dibbs."] = "Görev veren henüz doğrulanmadı. Giriş görevi: An Acquaintance in Southshore, Savage Coast Rapor Destesi'ni Loremaster Dibbs'e götürmek."
P["Quest giver not confirmed yet: it is handed in to Archmage Lan'dalock."] = "Görev veren henüz doğrulanmadı: Archmage Lan'dalock'a teslim edilir."
P["Random drop from Blackrock Spire trash"] = "Blackrock Spire'daki sıradan yaratıklardan rastgele düşer"
P["Random drop from mobs outside the Gnomeregan instance"] = "Gnomeregan zindanı dışındaki yaratıklardan rastgele düşer"
P["Random drop; you usually get it during your first clear of the outer area."] = "Rastgele düşer; genellikle dış bölgeyi ilk temizleyişinde alırsın."
P["Rare drop from Vile Fin murlocs around Lordamere Lake; the higher-level ones on the Dawning Isles and on the south-west shore behind Ambermill are the best bet"] = "Lordamere Lake çevresindeki Vile Fin murloclarından nadiren düşer; en iyi şans Dawning Isles'taki ve Ambermill'in arkasındaki güneybatı kıyısındaki yüksek seviyeli olanlarda"
P["Rare spawn."] = "Nadir yaratık."
P["Recover The Coldbringer's Eye from Razorfen Downs."] = "Coldbringer'ın Gözü'nü Razorfen Downs'tan geri al."
P["Recover The Founding of Dalaran and deliver it to Rexxie Copperclutch."] = "The Founding of Dalaran'ı geri al ve Rexxie Copperclutch'a teslim et."
P["Recover an Ancient Gurubashi Idol from the Drowned City."] = "Drowned City'den bir Kadim Gurubashi İdolü geri al."
P["Recover the Tome of Twilight from Krol'dok Stronghold."] = "Alacakaranlık Cildi'ni Krol'dok Stronghold'dan geri al."
P["Red Punch Card (Punchograph 3005-C)"] = "Kırmızı Delikli Kart (Punchograph 3005-C)"
P["Related lead-in: Dragonmaw Rumors. The Dragonmaw Dispatch is recovered from the Dragonmaw forces inside the dungeon."] = "İlgili giriş görevi: Dragonmaw Rumors. Dragonmaw Gönderisi, zindanın içindeki Dragonmaw kuvvetlerinden alınır."
P["Repeatable. Needs your faction's Elven Legends turned in first."] = "Tekrarlanabilir. Önce fraksiyonunun Elven Legends görevinin teslim edilmiş olması gerekir."
P["Report Daewyn's fate to Dorin Songblade in Lakeshire."] = "Daewyn'in akıbetini Lakeshire'daki Dorin Songblade'e bildir."
P["Reported random spawn inside Ruins of Lordaeron; check towers, side rooms and the Bjork area"] = "Ruins of Lordaeron içinde rastgele çıktığı bildiriliyor; kulelere, yan odalara ve Bjork bölgesine bak"
P["Required before Gnomer-gooooone!"] = "Gnomer-gooooone! öncesi gerekli."
P["Required before Hearts of Zeal."] = "Hearts of Zeal öncesi gerekli."
P["Required before Heartwoven."] = "Heartwoven öncesi gerekli."
P["Required before Highland Hides. Daily Delivery is not required in Forever."] = "Highland Hides öncesi gerekli. Forever'da Daily Delivery gerekli değil."
P["Required before Open the Maw."] = "Open the Maw öncesi gerekli."
P["Required before Red Silk Bandanas."] = "Red Silk Bandanas öncesi gerekli."
P["Required before Smart Drinks becomes available."] = "Smart Drinks açılmadan önce gerekli."
P["Required before The Crone of the Kraul."] = "The Crone of the Kraul öncesi gerekli."
P["Required before The Only Cure is More Green Glow."] = "The Only Cure is More Green Glow öncesi gerekli."
P["Required before the Alliance version of Blackfathom Villainy."] = "Blackfathom Villainy'nin Alliance sürümü öncesi gerekli."
P["Requires Magus Wordeen Voidglare's Dalaran quests. Stone Tokens and Bracers of Binding from Keeper Bel'varil are optional and are not required for attunement."] = "Magus Wordeen Voidglare'in Dalaran görevleri gerekir. Keeper Bel'varil'in Stone Tokens ve Bracers of Binding görevleri isteğe bağlıdır, uyumlanma için gerekli değildir."
P["Requires The Dark Iron War before this quest becomes available."] = "Bu görevin açılması için önce The Dark Iron War gerekir."
P["Requires the Barrens oasis quest chain. Complete The Barrens Oases, The Forgotten Pools, The Stagnant Oasis and Altered Beings, then Hamuul Runetotem and Nara Wildmane before Leaders of the Fang becomes available."] = "Barrens vaha görev zinciri gerekir. Leaders of the Fang açılmadan önce The Barrens Oases, The Forgotten Pools, The Stagnant Oasis ve Altered Beings'i, ardından Hamuul Runetotem ve Nara Wildmane'i tamamla."
P["Requires the Defias Brotherhood escort step."] = "Defias Brotherhood eskort adımı gerekir."
P["Requires the earlier Hidden Enemies chain steps in Orgrimmar. The next Hidden Enemies step later offers:"] = "Orgrimmar'daki önceki Hidden Enemies zincir adımları gerekir. Sonraki Hidden Enemies adımı daha sonra şunları sunar:"
P["Retrieve a Fel Infused Blossom from Dalaran's central garden."] = "Dalaran'ın merkez bahçesinden bir Fel ile Dolu Çiçek al."
P["Retrieve the Medallion of Faith from Malor the Zealous in the Scarlet Bastion and bring it back to Aurius."] = "İnanç Madalyonu'nu Scarlet Bastion'daki Malor the Zealous'tan al ve Aurius'a geri getir."
P["Return to Caitlin Grassman in Menethil Harbor."] = "Menethil Harbor'daki Caitlin Grassman'a dön."
P["Returns Shaw's findings about Edwin VanCleef to Gryan."] = "Shaw'ın Edwin VanCleef hakkındaki bulgularını Gryan'a geri götürür."
P["Returns the remote detonator to the engineer."] = "Uzaktan fünyeyi mühendise geri götürür."
P["Reward from the quest Bailor's Ore Shipment: Bailor Stonehand, Thelsamar, Loch Modan"] = "Bailor's Ore Shipment görevinin ödülü: Bailor Stonehand, Thelsamar, Loch Modan"
P["Reward from the quest Seeking the Kor Gem: Thundris Windweaver, Auberdine, Darkshore. The Corrupted Kor Gem he asks for drops from Blackfathom Tide Priestesses and Oracles at the Blackfathom Deeps entrance and from Blackfathom Sea Witches inside."] = "Seeking the Kor Gem görevinin ödülü: Thundris Windweaver, Auberdine, Darkshore. İstediği Bozulmuş Kor Taşı, Blackfathom Deeps girişindeki Blackfathom Tide Priestess ve Oracle'lardan ve içerideki Blackfathom Sea Witch'lerden düşer."
P["Reward from the quest Seeking the Kor Gem: Ulric Frostveil, Zoram'gar Outpost, Ashenvale. The Corrupted Kor Gem he asks for drops from Blackfathom Tide Priestesses and Oracles at the Blackfathom Deeps entrance and from Blackfathom Sea Witches inside, once you have his quest."] = "Seeking the Kor Gem görevinin ödülü: Ulric Frostveil, Zoram'gar Outpost, Ashenvale. İstediği Bozulmuş Kor Taşı, görevini aldıktan sonra Blackfathom Deeps girişindeki Blackfathom Tide Priestess ve Oracle'lardan ve içerideki Blackfathom Sea Witch'lerden düşer."
P["Rexxie Copperclutch, inside the dungeon, near the sewer entrance"] = "Rexxie Copperclutch, zindanın içinde, lağım girişinin yakınında"
P["Rig Wars must be in progress to unlock the transporter chain in Forever."] = "Forever'da ışınlayıcı zincirini açmak için Rig Wars'un devam ediyor olması gerekir."
P["Right under the Messenger Bag"] = "Ulak Çantası'nın hemen altında"
P["Riverglades (giver not known yet)"] = "Riverglades (görev veren henüz bilinmiyor)"
P["Riverglades (not known yet)"] = "Riverglades (henüz bilinmiyor)"
P["Rogue class book. Click the book to start the quest."] = "Rogue sınıf kitabı. Görevi başlatmak için kitaba tıkla."
P["Rogue class quest after The Horn of Xelthos; C's next letter (around level 30) sends you back to the Dead Drop. Wear the Scarlet Initiate's Uniform in every wing: stealth or attacking removes it."] = "The Horn of Xelthos'tan sonraki Rogue sınıf görevi; C'nin bir sonraki mektubu (yaklaşık 30. seviyede) seni Dead Drop'a geri gönderir. Her kanatta Scarlet Initiate's Uniform giy: gizlenmek ya da saldırmak onu çıkarır."
P["Rogue class quest. C's letter arrives at level 20 in a capital city; take the job at the Dead Drop near Pyrewood Village. Keep a bag slot free."] = "Rogue sınıf görevi. C'nin mektubu 20. seviyede bir başkentte gelir; işi Pyrewood Village yakınındaki Dead Drop'tan al. Bir çanta yuvasını boş tut."
P["Rogue class quest. The Azure Key drops from Morphaz.\n\nOptional introductory quest:"] = "Rogue sınıf görevi. Gök Mavisi Anahtar Morphaz'dan düşer.\n\nİsteğe bağlı giriş görevi:"
P["Rogue trainers"] = "Rogue eğitmenleri"
P["Rough Dynamite can be crafted, traded or bought from the auction house."] = "Kaba Dinamit üretilebilir, takas edilebilir ya da müzayede evinden alınabilir."
P["Rubbing of the tablet Fall of Gurubashi, in the troll ruins on the coast north of the Vile Reef (around 23, 12)"] = "Fall of Gurubashi tabletinin kopyası, Vile Reef'in kuzeyindeki kıyıda trol harabelerinde (yaklaşık 23, 12)"
P["Scarlet Monastery trash (Chain of the Scarlet Crusade)"] = "Scarlet Monastery'deki sıradan yaratıklar (Chain of the Scarlet Crusade)"
P["Scarlet Monastery trash (very rare)"] = "Scarlet Monastery'deki sıradan yaratıklar (çok nadir)"
P["Scourge forces still haunt the ruined capital while a necromancer gathers power within the city."] = "Bir nekromans şehrin içinde güç toplarken Scourge kuvvetleri hâlâ yıkık başkentin peşini bırakmıyor."
P["Scout Riell, Sentinel Hill tower, Westfall"] = "Scout Riell, Sentinel Hill kulesi, Westfall"
P["Second quest of the Toxic Soil chain."] = "Toxic Soil zincirinin ikinci görevi."
P["Second required step before Horrors in the Highland."] = "Horrors in the Highland öncesi gerekli ikinci adım."
P["Second required step leading to The Stockade Riots."] = "The Stockade Riots görevine götüren ikinci gerekli adım."
P["Second step of the Defias Brotherhood chain."] = "Defias Brotherhood zincirinin ikinci adımı."
P["Sentinel Hill inn"] = "Sentinel Hill hanı"
P["Sentinel Hill tower"] = "Sentinel Hill kulesi"
P["Serpentbloom starts from Apothecary Zamah in the Pools of Vision beneath Spirit Rise"] = "Serpentbloom, Spirit Rise'ın altındaki Pools of Vision'da Apothecary Zamah'tan başlar"
P["Shadowshard elementals in the outer purple-crystal caves. It can be done without entering the instance."] = "Dıştaki mor kristalli mağaralardaki Shadowshard elementalleri. Zindana girmeden yapılabilir."
P["Shady Saltseers"] = "Şüpheli Saltseer'lar"
P["Shaman class book. Click the book to start the quest."] = "Shaman sınıf kitabı. Görevi başlatmak için kitaba tıkla."
P["Shaman class quest. Needs 2 amber, 2 blue and 2 green Voodoo Feathers from the six troll guardians: Gasher, Mijan, Zolo, Hukku, Zul'Lor and Loro."] = "Shaman sınıf görevi. Altı trol muhafızından 2 kehribar, 2 mavi ve 2 yeşil Vudu Tüyü gerekir: Gasher, Mijan, Zolo, Hukku, Zul'Lor ve Loro."
P["Shaman quest. Clear Rattlegore's basement, use the scryer and defeat Death Knight Darkreaver; return his head."] = "Shaman görevi. Rattlegore'un bodrumunu temizle, kâhin aletini kullan ve Death Knight Darkreaver'ı yen; kafasını geri getir."
P["Shattered Necklace (drops in Uldaman)"] = "Parçalanmış Kolye (Uldaman'da düşer)"
P["Shaw investigates the connection between the Defias and the Stonemasons."] = "Shaw, Defias ile Taş Ustaları arasındaki bağlantıyı araştırıyor."
P["Show Cyrus a Black Dragonflight Molt first (A Taste of Flame, or kill the drake he summons). Then kill Bael'Gar and use the Altered Black Dragonflight Molt on his remains to collect the Encased Fiery Essence."] = "Önce Cyrus'a bir Kara Ejderha Uçuşu Deri Döküntüsü göster (A Taste of Flame ya da çağırdığı drake'i öldür). Sonra Bael'Gar'ı öldür ve Kaplı Ateşli Öz'ü toplamak için Değiştirilmiş Kara Ejderha Uçuşu Deri Döküntüsü'nü kalıntıları üzerinde kullan."
P["Slay Arcanic Enigma, the Mana Elemental in the City of Dalaran, and return to High Sorcerer Andromath in Stormwind City."] = "City of Dalaran'daki Mana Elementali Arcanic Enigma'yı öldür ve Stormwind City'deki High Sorcerer Andromath'a dön."
P["Slay Captain Dreadrise and 3 Saltseer Coroners in the Drowned City."] = "Drowned City'de Captain Dreadrise'ı ve 3 Saltseer Coroner'ı öldür."
P["Slay Witch Doctor Zum'rah and bring Zum'rah's Head to Archmage Lan'dalock in Dalaran."] = "Witch Doctor Zum'rah'ı öldür ve Zum'rah'ın Kafası'nı Dalaran'daki Archmage Lan'dalock'a getir."
P["Small Scroll, dropped by Charlga Razorflank"] = "Küçük Parşömen, Charlga Razorflank düşürür"
P["Solo job: you must do it alone, outside any group."] = "Tek kişilik iş: herhangi bir grubun dışında, tek başına yapmalısın."
P["Someone has broken into the royal dwarven burial chamber beneath Ironforge."] = "Biri Ironforge'un altındaki kraliyet cüce mezar odasına girmiş."
P["Someone on the Elder Rise, Thunder Bluff"] = "Thunder Bluff'taki Elder Rise'da biri"
P["Speak to Franclorn's ghost while dead. Kill Fineous Darkvire for Ironfel and place it on Franclorn's monument by the Ring of Law. The Shadowforge Key opens shortcuts inside BRD."] = "Ölüyken Franclorn'un hayaletiyle konuş. Ironfel için Fineous Darkvire'ı öldür ve onu Ring of Law yanındaki Franclorn anıtına yerleştir. Shadowforge Anahtarı BRD içindeki kısayolları açar."
P["Speak with the Stone Watcher and activate the discs first. Then hand the reward voucher to Bena Winterhoof in Thunder Bluff and choose your reward."] = "Önce Stone Watcher ile konuş ve diskleri etkinleştir. Sonra ödül senedini Thunder Bluff'taki Bena Winterhoof'a ver ve ödülünü seç."
P["Speak with the Stone Watcher and activate the discs first. Then hand the reward voucher to Dinita Stonemantle in the Ironforge vault and choose your reward."] = "Önce Stone Watcher ile konuş ve diskleri etkinleştir. Sonra ödül senedini Ironforge kasasındaki Dinita Stonemantle'a ver ve ödülünü seç."
P["Spire Spider Eggs are in the spider tunnels."] = "Spire Örümcek Yumurtaları örümcek tünellerinde."
P["Sprite Jumpsprocket: Dwarven District, Stormwind"] = "Sprite Jumpsprocket: Dwarven District, Stormwind"
P["Sputtervalve, by the flight master in Ratchet (63.0, 37.2); he has no ? over his head"] = "Sputtervalve, Ratchet'taki uçuş ustasının yanında (63.0, 37.2); başının üstünde ? yok"
P["Start Chief Engineer Scooty here"] = "Chief Engineer Scooty'yi burada başlat"
P["Start Dragonmaw Rumors here"] = "Dragonmaw Rumors'u burada başlat"
P["Start Gnogaine here"] = "Gnogaine'i burada başlat"
P["Start Going, Going, Guano! here"] = "Going, Going, Guano!'yu burada başlat"
P["Start Hidden Enemies here"] = "Hidden Enemies'i burada başlat"
P["Start In Search of Thaelrid here"] = "In Search of Thaelrid'i burada başlat"
P["Start Lost in the Thicket Things here"] = "Lost in the Thicket Things'i burada başlat"
P["Start Raptor Horns here"] = "Raptor Horns'u burada başlat"
P["Start Red Leather Bandanas here"] = "Red Leather Bandanas'ı burada başlat"
P["Start Speak with Shoni here"] = "Speak with Shoni'yi burada başlat"
P["Start Testing the Wells here"] = "Testing the Wells'i burada başlat"
P["Start The Dark Iron War here"] = "The Dark Iron War'u burada başlat"
P["Start The Defias Brotherhood here"] = "The Defias Brotherhood'u burada başlat"
P["Start The Forgotten Pools here"] = "The Forgotten Pools'u burada başlat"
P["Start The Greenwarden here"] = "The Greenwarden'ı burada başlat"
P["Start Young Crocolisk Skins here"] = "Young Crocolisk Skins'i burada başlat"
P["Starts a follow-up chain that continues with Bazil Thredd."] = "Bazil Thredd ile devam eden bir zincir başlatır."
P["Stone tablet inside a vault in the Reliquary of Kings"] = "Reliquary of Kings'teki bir kasanın içindeki taş tablet"
P["Stone tablet inside a vault in the Reliquary of Kings (Durgen Dirgehammer's room)"] = "Reliquary of Kings'teki bir kasanın içindeki taş tablet (Durgen Dirgehammer'ın odası)"
P["Strange Water Globe, dropped by Baron Aquanis inside Blackfathom Deeps"] = "Garip Su Küresi, Blackfathom Deeps içinde Baron Aquanis düşürür"
P["Summon a Twilight's Thrall from a conduit within the Twilight's Shroud and capture it with Amberhall's Soulstone."] = "Twilight's Shroud içindeki bir kanaldan bir Twilight's Thrall çağır ve onu Amberhall'un Ruh Taşı ile yakala."
P["Supplied by Sprite Jumpsprocket during Explosive Consultation; plant it at the Deadmines forge"] = "Explosive Consultation sırasında Sprite Jumpsprocket verir; onu Deadmines demirhanesine yerleştir"
P["Take Two With Water"] = "Suyla İki Tane Al"
P["Take the Reed-woven Heart back to Caitlin Grassman in Menethil Harbor."] = "Sazdan Örülmüş Kalp'i Menethil Harbor'daki Caitlin Grassman'a geri götür."
P["Take the Titan Relic to the Elder Rise in Thunder Bluff and look for someone who can tell you more about it."] = "Titan Kalıntısı'nı Thunder Bluff'taki Elder Rise'a götür ve sana onun hakkında daha fazlasını anlatabilecek birini ara."
P["Take the Unforged Seal and the Orb of Draconic Energy to Emberstrife in the Wyrmbog, Dustwallow Marsh. The forged seal opens the UBRS door."] = "Dövülmemiş Mühür'ü ve Ejderha Enerjisi Küresi'ni Dustwallow Marsh'taki Wyrmbog'da Emberstrife'a götür. Dövülmüş mühür UBRS kapısını açar."
P["Take the elevator down; the terminal is in the first passage on the right."] = "Asansörle aşağı in; terminal sağdaki ilk geçitte."
P["Take the painting hidden behind the twin-moons picture in Archivist Galford's room before you burn the archives."] = "Arşivleri yakmadan önce Archivist Galford'un odasındaki ikiz aylar resminin arkasına gizlenmiş tabloyu al."
P["Take the path north-east of Sun Rock Retreat (50.9, 52.3) up to the abandoned camp; the Pocket Litter lies on a box. Optional: light the Firepit in the middle of the camp with the Simple Wood and Flint and Tinder from this quest (Rekindle)."] = "Sun Rock Retreat'in (50.9, 52.3) kuzeydoğusundaki yoldan terk edilmiş kampa çık; cep döküntüleri bir kutunun üzerinde. İsteğe bağlı: bu görevden gelen Basit Odun ve Çakmaktaşı ile kampın ortasındaki ateş çukurunu yak (Rekindle)."
P["Talk to Goretooth to receive his Command item and click it to start the quest. The Important Blackrock Documents spawn near the three generals."] = "Command eşyasını almak için Goretooth ile konuş ve görevi başlatmak için ona tıkla. Önemli Blackrock Belgeleri üç generalin yakınında çıkar."
P["Talvash del Kissel (Phial of Scrying)"] = "Talvash del Kissel (Kehanet Şişesi)"
P["The Arcanist's Cookbook (book, Dire Maul drop)"] = "The Arcanist's Cookbook (kitap, Dire Maul ganimeti)"
P["The Barov family crypt on Caer Darrow, turned into the Cult of the Damned's school of necromancy. Darkmaster Gandling rules the halls; the Skeleton Key from the Barov quests opens the doors."] = "Caer Darrow'daki Barov ailesi mahzeni, Cult of the Damned'in nekromansi okuluna dönüşmüş. Salonları Darkmaster Gandling yönetir; Barov görevlerinden gelen İskelet Anahtarı kapıları açar."
P["The Capital Gardens and the Court of the Highborne, where the last Shen'dralar keep the demon Immol'thar imprisoned behind five pylons. Needs the Crescent Key from Pusillin."] = "Son Shen'dralar'ın şeytan Immol'thar'ı beş pilonun arkasında hapsettiği Capital Gardens ve Court of the Highborne. Pusillin'den Hilal Anahtarı gerekir."
P["The Celebrian Rod drops from Noxxion and the Celebrian Diamond from Lord Vyletongue."] = "Celebrian Asası Noxxion'dan, Celebrian Elması ise Lord Vyletongue'dan düşer."
P["The Coldbringer's Eye"] = "Coldbringer'ın Gözü"
P["The Core Fragment is on the rock beside the Molten Core portal deep inside BRD. Unlocks Lothos's teleport to Molten Core."] = "Çekirdek Parçası, BRD'nin derinlerinde Molten Core portalının yanındaki kayanın üzerinde. Lothos'un Molten Core'a ışınlamasını açar."
P["The Dark Iron Map starts this quest and leads directly into Old Ironforge Incursion."] = "Dark Iron Haritası bu görevi başlatır ve doğrudan Old Ironforge Incursion görevine götürür."
P["The Darkstone Tablet lies on the ground in the Rookery.\n\nOptional introductory quest:"] = "Darkstone Tableti Rookery'de yerde duruyor.\n\nİsteğe bağlı giriş görevi:"
P["The Deathstalker Agent waits at the new dig camp right outside the portal. He takes the Dragonmaw Dispatch off your hands; where the Dispatch drops has not been confirmed yet."] = "Deathstalker Agent, portalın hemen dışındaki yeni kazı kampında bekliyor. Dragonmaw Gönderisi'ni senden alır; Gönderi'nin nereden düştüğü henüz doğrulanmadı."
P["The Defias Brotherhood is building a warship in the mines beneath Moonbrook."] = "Defias Brotherhood, Moonbrook'un altındaki madenlerde bir savaş gemisi inşa ediyor."
P["The Defias Messenger patrols the roads between Moonbrook, Gold Coast Quarry and Jangolode Mine."] = "Defias Messenger, Moonbrook, Gold Coast Quarry ve Jangolode Mine arasındaki yollarda devriye gezer."
P["The Emerald Dream (book, Dire Maul drop)"] = "The Emerald Dream (kitap, Dire Maul ganimeti)"
P["The Fathom Stone is also associated with the optional Baron Aquanis encounter."] = "Fathom Taşı, isteğe bağlı Baron Aquanis karşılaşmasıyla da ilişkilidir."
P["The Greatest Race of Hunters (book, Dire Maul drop)"] = "The Greatest Race of Hunters (kitap, Dire Maul ganimeti)"
P["The Heart of the Mountain is in the vault safe after the Dark Keepers."] = "Dağın Kalbi, Dark Keeper'lardan sonra kasadaki kasada."
P["The Light and How To Swing It (book, Dire Maul drop)"] = "The Light and How To Swing It (kitap, Dire Maul ganimeti)"
P["The Lorgalis Manuscript is inside a Pitted Iron Chest underwater in the Pool of Ask'ar, in the northern alcove just past Ghamoo-ra's turtle room."] = "Lorgalis Elyazması, Ghamoo-ra'nın kaplumbağa odasını hemen geçince kuzey girintide, Pool of Ask'ar'da su altındaki bir Oyuk Demir Sandık'ın içinde."
P["The Saltseer Captain"] = "Saltseer Kaptanı"
P["The Scarshield Quartermaster is in the hallway outside the Spire portal. Touch Drakkisath's Brand behind General Drakkisath; this unlocks the Orb of Command shortcut to Blackwing Lair."] = "Scarshield Quartermaster, Spire portalının dışındaki koridorda. General Drakkisath'ın arkasındaki Drakkisath's Brand'e dokun; bu, Blackwing Lair'e giden Orb of Command kısayolunu açar."
P["The Sparklematic 5200, inside Gnomeregan"] = "The Sparklematic 5200, Gnomeregan içinde"
P["The Tablet of Theka is in Theka the Martyr's room."] = "Theka Tableti, Theka the Martyr'ın odasında."
P["The Temple of Atal'Hakkar, sunk beneath the Pool of Tears in the Swamp of Sorrows. The Atal'ai trolls try to summon their blood god Hakkar here, while the green dragons of Eranikus guard the lower halls."] = "Swamp of Sorrows'taki Pool of Tears'ın altına batmış Temple of Atal'Hakkar. Atal'ai trolleri burada kan tanrıları Hakkar'ı çağırmaya çalışırken Eranikus'un yeşil ejderhaları alt salonları korur."
P["The Tiara drops from Hydromancer Velratha.\n\nOptional introductory quest:"] = "Taç, Hydromancer Velratha'dan düşer.\n\nİsteğe bağlı giriş görevi:"
P["The Witch Doctor's Head"] = "Cadı Doktorun Kafası"
P["The ancient burial grounds of the quilboar, now held by the Scourge. Amnennar the Coldbringer leads the undead from the top of the Downs."] = "Domuzadamların kadim mezarlığı, artık Scourge'un elinde. Amnennar the Coldbringer, Downs'ın tepesinden undead'leri yönetiyor."
P["The armory wing of the Scarlet Monastery, where the Crusade drills its recruits under the eye of Herod, the Scarlet Champion. The door is locked: you need The Scarlet Key from the Library."] = "Haçlı Seferi'nin acemilerini Scarlet Champion Herod'un gözetiminde eğittiği Scarlet Monastery'nin cephanelik kanadı. Kapı kilitli: Library'den The Scarlet Key gerekir."
P["The bag drops from Jandice Barov."] = "Çanta Jandice Barov'dan düşer."
P["The book is inside Scarlet Monastery: Library."] = "Kitap Scarlet Monastery: Library içinde."
P["The burnt tower on the road south of Camp Taurajo"] = "Camp Taurajo'nun güneyindeki yol üzerindeki yanık kule"
P["The capital of the Dark Iron dwarves beneath Blackrock Mountain: the Detention Block, the Ring of Law, the Grim Guzzler and Shadowforge City, ruled by Emperor Dagran Thaurissan."] = "Blackrock Mountain'ın altındaki Dark Iron cücelerinin başkenti: Emperor Dagran Thaurissan'ın yönettiği Detention Block, Ring of Law, Grim Guzzler ve Shadowforge City."
P["The cart wreckage at the Alexston Farmstead"] = "Alexston Farmstead'deki araba enkazı"
P["The cave is in Sunken Hollow, underwater around 21, 28: the entrance to the Drowned City."] = "Mağara, Sunken Hollow'da, yaklaşık 21, 28 civarında su altında: Drowned City'nin girişi."
P["The chain begins by dropping Dark Iron Map from Dark Iron Spies in Dun Morogh."] = "Zincir, Dun Morogh'daki Dark Iron Casuslarından Dark Iron Haritası düşmesiyle başlar."
P["The current Forever quest data also lists Arcane Intellect as a learned reward."] = "Güncel Forever görev verisi ödül olarak öğrenilen Arcane Intellect'i de listeliyor."
P["The direct quest has no item reward. Its follow-up, In Nightmares, later offers:"] = "Doğrudan görevin eşya ödülü yok. Devamı olan In Nightmares daha sonra şunları sunar:"
P["The discs are in the Map Chamber, past Ironaya."] = "Diskler, Ironaya'yı geçince Map Chamber'da."
P["The eastern quarter of the ruined Highborne city of Eldre'Thalas, overgrown by the Warpwood and ruled by the satyr Alzzin the Wildshaper. Pusillin carries the Crescent Key that opens the other wings."] = "Warpwood ile kaplanmış ve satir Alzzin the Wildshaper'ın yönettiği yıkık Highborne şehri Eldre'Thalas'ın doğu mahallesi. Pusillin, diğer kanatları açan Hilal Anahtarı'nı taşır."
P["The fifth and sixth Mosh'aru tablets are in the Smolderthorn troll area. Continues with Confront Yeh'kinya and The Hand of Rastakhan."] = "Beşinci ve altıncı Mosh'aru tabletleri Smolderthorn trol bölgesinde. Confront Yeh'kinya ve The Hand of Rastakhan ile devam eder."
P["The foreman is in the tunnels before the instance portal."] = "Ustabaşı, zindan portalından önceki tünellerde."
P["The four deeds: Southshore in the first large chamber, Tarren Mill before the hatchlings, Brill by Ras Frostwhisper, Caer Darrow by Lord Alexei Barov. The follow-up The Last Barov sends you to kill the rival brother."] = "Dört tapu: ilk büyük salonda Southshore, yavrulardan önce Tarren Mill, Ras Frostwhisper'ın yanında Brill, Lord Alexei Barov'un yanında Caer Darrow. Devam görevi The Last Barov seni rakip kardeşi öldürmeye gönderir."
P["The glowing rune on the floor of Baron Rivendare's room, Stratholme (Undead side)"] = "Baron Rivendare'in odasının zeminindeki parlayan rün, Stratholme (Undead tarafı)"
P["The graveyard wing of the Scarlet Monastery, haunted by restless dead and Scarlet defenders."] = "Scarlet Monastery'nin mezarlık kanadı; huzursuz ölüler ve Scarlet savunucularıyla dolu."
P["The heart of the Scarlet Monastery: the Chapel Gardens and the Crusader's Chapel, held by Scarlet Commander Mograine and High Inquisitor Whitemane. The door is locked: you need The Scarlet Key from the Library."] = "Scarlet Monastery'nin kalbi: Scarlet Commander Mograine ve High Inquisitor Whitemane'in elindeki Chapel Gardens ve Crusader's Chapel. Kapı kilitli: Library'den The Scarlet Key gerekir."
P["The irradiated underground city of the gnomes, overrun by troggs and Mekgineer Thermaplugg's forces."] = "Troggların ve Mekgineer Thermaplugg'ın kuvvetlerinin istila ettiği, gnomların radyasyonlu yeraltı şehri."
P["The item choice is awarded on the follow-up Unending Torment step in Undercity."] = "Eşya seçimi, Undercity'deki sonraki Unending Torment adımında verilir."
P["The library wing of the Scarlet Monastery, home to the Houndmaster's kennels and Arcanist Doan's athenaeum."] = "Scarlet Monastery'nin kütüphane kanadı; Houndmaster'ın köpek kulübeleri ve Arcanist Doan'ın okuma salonu burada."
P["The lower halls of Blackrock Spire, held by the Spirestone, Smolderthorn and Bloodaxe clans of the Dark Horde under Overlord Wyrmthalak."] = "Overlord Wyrmthalak komutasındaki Dark Horde'un Spirestone, Smolderthorn ve Bloodaxe klanlarının elindeki Blackrock Spire'ın alt salonları."
P["The main gate of Stratholme: the burning streets, the Scarlet Bastion and the Hall of Lights, where Grand Crusader Dathrohan reveals himself as the dreadlord Balnazzar."] = "Stratholme'un ana kapısı: yanan sokaklar, Scarlet Bastion ve Grand Crusader Dathrohan'ın kendini dehşet lordu Balnazzar olarak gösterdiği Hall of Lights."
P["The medallion drops from Nekrum Gutchewer."] = "Madalyon Nekrum Gutchewer'dan düşer."
P["The messenger travels the roads between Moonbrook, Gold Coast Quarry and Jangolode Mine."] = "Ulak, Moonbrook, Gold Coast Quarry ve Jangolode Mine arasındaki yollarda dolaşır."
P["The next required oasis investigation after The Forgotten Pools."] = "The Forgotten Pools'tan sonraki gerekli vaha araştırması."
P["The only punchographs outside the instance: on the raised platform in the Train Depot and by the Workshop (back door) entrance."] = "Zindanın dışındaki tek delgeçler: Train Depot'daki yükseltilmiş platformda ve Workshop (arka kapı) girişinin yanında."
P["The power source drops from Archaedas. Finishing it unlocks Talvash's Enhancing Necklace."] = "Güç kaynağı Archaedas'tan düşer. Bitirmek Talvash's Enhancing Necklace'ı açar."
P["The power stones drop from Shadowforge dwarves in the outer cave."] = "Güç taşları, dış mağaradaki Shadowforge cücelerinden düşer."
P["The questline starts at level 18 with Diplomatic Incident from Danitha Morr at Bandarion Keep, Tirisfal Glades. It takes you to Fenris Isle, where you free Lumina Windsinger from Fenris Keep."] = "Görev zinciri 18. seviyede Tirisfal Glades'teki Bandarion Keep'te Danitha Morr'dan Diplomatic Incident ile başlar. Seni Fenris Keep'ten Lumina Windsinger'ı kurtardığın Fenris Isle'a götürür."
P["The restored mage city of Dalaran has become a new five-player dungeon in WoW Forever. Enter through the sewers and the Underbelly, then fight through the streets to the Violet Citadel."] = "Yeniden kurulan büyücü şehri Dalaran, WoW Forever'da beş kişilik yeni bir zindan oldu. Lağımlardan ve Underbelly'den gir, sonra sokaklarda savaşarak Violet Citadel'e ulaş."
P["The rod drops from Sergeant Bly after the pyramid event."] = "Asa, piramit olayından sonra Sergeant Bly'dan düşer."
P["The ruined city of Lordaeron"] = "Yıkık Lordaeron şehri"
P["The sacred caverns of the centaur in Desolace, where Princess Theradras and her corrupted earth elementals rule beneath Zaetar's grave. The orange and purple wings lead to the inner caves; the Scepter of Celebras opens the shortcut to the waterfall."] = "Desolace'teki kentaurların kutsal mağaraları; Princess Theradras ve bozulmuş toprak elementalleri Zaetar'ın mezarının altında hüküm sürüyor. Turuncu ve mor kanatlar iç mağaralara çıkar; Celebras Asası şelaleye giden kısayolu açar."
P["The sapphire drops from Grimlok and the power source from Archaedas."] = "Safir Grimlok'tan, güç kaynağı ise Archaedas'tan düşer."
P["The sapphire drops from Grimlok."] = "Safir Grimlok'tan düşer."
P["The service entrance side of Stratholme, held by the Scourge: the three ziggurats, the Slaughter House and Baron Rivendare's stronghold. Kill the Baron within 45 minutes to save Ysida Harmon."] = "Stratholme'un Scourge elindeki servis girişi tarafı: üç ziggurat, Slaughter House ve Baron Rivendare'in kalesi. Ysida Harmon'u kurtarmak için Baron'u 45 dakika içinde öldür."
P["The sun-baked troll city in the deserts of Tanaris, home of the Sandfury tribe and their chief, Ukorz Sandscalp."] = "Tanaris çöllerinde güneşte kavrulan trol şehri; Sandfury kabilesinin ve şefleri Ukorz Sandscalp'ın yurdu."
P["The supplies are found in the caves leading toward the Deadmines entrance."] = "Erzaklar, Deadmines girişine doğru giden mağaralarda bulunur."
P["The tablet is inside one of the vaults in the Reliquary of Kings, in Durgen Dirgehammer's final boss room. Open the vaults and interact with the tablet before leaving the dungeon."] = "Tablet, Durgen Dirgehammer'ın son boss odasında, Reliquary of Kings'teki kasalardan birinin içinde. Zindandan ayrılmadan önce kasaları aç ve tabletle etkileşime geç."
P["The tablets drop from Theka the Martyr and Hydromancer Velratha."] = "Tabletler Theka the Martyr ve Hydromancer Velratha'dan düşer."
P["The top of Blackrock Spire, held by Rend Blackhand's Dark Horde and General Drakkisath's black dragonflight. The door needs the Seal of Ascension."] = "Rend Blackhand'in Dark Horde'unun ve General Drakkisath'ın kara ejderha uçuşunun elindeki Blackrock Spire'ın tepesi. Kapı için Seal of Ascension gerekir."
P["The undead side tunnel is before the instance portal."] = "Undead yan tüneli zindan portalından önce."
P["The urns are in the outer Uldaman cave, before the instance portal.\n\nOptional introductory quest:"] = "Küpler, zindan portalından önce, dış Uldaman mağarasında.\n\nİsteğe bağlı giriş görevi:"
P["The web drops from Lethtendris.\n\nOptional introductory quest:"] = "Ağ, Lethtendris'ten düşer.\n\nİsteğe bağlı giriş görevi:"
P["Then Lord Maxwell Tyrosus and The Argent Hold, in Light's Hope Chapel, give the weapon or shield reward."] = "Ardından Light's Hope Chapel'daki Lord Maxwell Tyrosus ve The Argent Hold silah veya kalkan ödülünü verir."
P["Then take Bijou's Reconnaissance Report to Lexlort in Kargath for the reward."] = "Ardından ödül için Bijou's Reconnaissance Report'u Kargath'taki Lexlort'a götür."
P["There may not be enough of these mobs inside to finish it in one run."] = "İçeride bu yaratıklardan tek seferde bitirmeye yetecek kadar olmayabilir."
P["These mobs are outside the instance, around the entrance."] = "Bu yaratıklar zindanın dışında, girişin çevresinde."
P["Thicket Raptor Meat comes from the Thicket raptors (Thicket Lurker, Thicket Hunter, Thicket Matriarch) in Stalker's Thicket, the area of Shadetooth."] = "Thicket Raptor Eti, Shadetooth'un bölgesi olan Stalker's Thicket'teki Thicket raptorlarından (Thicket Lurker, Thicket Hunter, Thicket Matriarch) gelir."
P["Third required step before Horrors in the Highland."] = "Horrors in the Highland öncesi gerekli üçüncü adım."
P["This is a chain quest with a step in Blackfathom Deeps"] = "Bu, bir adımı Blackfathom Deeps'te olan bir zincir görev"
P["This is a chain quest with a step in Shadowfang Keep"] = "Bu, bir adımı Shadowfang Keep'te olan bir zincir görev"
P["This is a chain quest with a step in The Deadmines"] = "Bu, bir adımı The Deadmines'ta olan bir zincir görev"
P["This is a long chain that has a step in the Library"] = "Bu, bir adımı Library'de olan uzun bir zincir"
P["This leads directly into Underground Assault."] = "Bu, doğrudan Underground Assault görevine götürür."
P["This quest can be accepted alongside Prison Break In."] = "Bu görev Prison Break In ile aynı anda kabul edilebilir."
P["This quest is completed in the area OUTSIDE Razorfen Downs."] = "Bu görev Razorfen Downs'ın DIŞINDAKİ bölgede tamamlanır."
P["Thom Filch — Hall of Thanes portal, Ironforge"] = "Thom Filch — Hall of Thanes portalı, Ironforge"
P["Thom Filch, by the bridge / vault entrance in Ironforge"] = "Thom Filch, Ironforge'daki köprü / kasa girişinin yanında"
P["Thom Filch, near the dungeon entrance"] = "Thom Filch, zindan girişinin yakınında"
P["Thorium Brotherhood Contract (from Lokhtos Darkbargainer with a Sulfuron Ingot)"] = "Thorium Brotherhood Sözleşmesi (bir Sulfuron Külçesi karşılığında Lokhtos Darkbargainer'dan)"
P["Thrall: Grommash Hold, Orgrimmar"] = "Thrall: Grommash Hold, Orgrimmar"
P["Timed: rescue Ysida Harmon by killing Baron Rivendare within 45 minutes. Use the Extra-Dimensional Ghost Revealer to see Anthion."] = "Süreli: Baron Rivendare'i 45 dakika içinde öldürerek Ysida Harmon'u kurtar. Anthion'u görmek için Boyutlar Ötesi Hayalet Gösterici'yi kullan."
P["Titan Relic (dropped by Relic Guardian)"] = "Titan Kalıntısı (Relic Guardian düşürür)"
P["Tome of Twilight"] = "Alacakaranlık Cildi"
P["Tonga Runetotem: The Crossroads, The Barrens"] = "Tonga Runetotem: The Crossroads, The Barrens"
P["Tonga sends you to Hamuul after Altered Beings."] = "Tonga, Altered Beings'ten sonra seni Hamuul'a gönderir."
P["Top of Old Ironforge, outside the dungeon"] = "Old Ironforge'un tepesi, zindanın dışında"
P["Travel to Krol'dok Stronghold and slay Zalfan Moonshadow."] = "Krol'dok Stronghold'a git ve Zalfan Moonshadow'u öldür."
P["Troggs and Burning Blade cultists infest the molten caverns beneath Orgrimmar."] = "Trogglar ve Burning Blade tarikatçıları Orgrimmar'ın altındaki erimiş mağaraları istila etmiş."
P["Twilight Mementos"] = "Alacakaranlık Hatıraları"
P["Undead cannot take this quest"] = "Undead'ler bu görevi alamaz"
P["Use An Unsent Letter, looted from Edwin VanCleef."] = "Edwin VanCleef'ten alınan An Unsent Letter'ı kullan."
P["Use Dawn's Gambit in the Viewing Room and defeat Vectus."] = "Viewing Room'da Dawn's Gambit'i kullan ve Vectus'u yen."
P["Use Matrix Punchograph 3005-A with the White Punch Card to get a Yellow Punch Card."] = "Sarı Delikli Kart almak için Beyaz Delikli Kart ile Matrix Punchograph 3005-A'yı kullan."
P["Use Matrix Punchograph 3005-B with the Yellow Punch Card to get a Blue Punch Card."] = "Mavi Delikli Kart almak için Sarı Delikli Kart ile Matrix Punchograph 3005-B'yi kullan."
P["Use Matrix Punchograph 3005-C with the Blue Punch Card to get a Red Punch Card."] = "Kırmızı Delikli Kart almak için Mavi Delikli Kart ile Matrix Punchograph 3005-C'yi kullan."
P["Use Matrix Punchograph 3005-D with the Red Punch Card to get the Prismatic Punch Card, then bring it to Master Mechanic Castpipe in Ironforge."] = "Prizmatik Delikli Kart almak için Kırmızı Delikli Kart ile Matrix Punchograph 3005-D'yi kullan, sonra onu Ironforge'daki Master Mechanic Castpipe'a götür."
P["Use the Blood of Innocents at the brazier on the Scholomance porch. Rewards the Spectral Essence."] = "Masumların Kanı'nı Scholomance verandasındaki mangalda kullan. Ödül: Spectral Essence."
P["Use the Damp Note dropped by Blackfathom Tide Priestesses"] = "Blackfathom Tide Priestess'lerin düşürdüğü Nemli Not'u kullan"
P["Use the Extra-Destructive Explosives quest-start item."] = "Extra-Destructive Explosives görev başlatma eşyasını kullan."
P["Use the Soulbound Keepsake on Ras Frostwhisper to make him human, then kill him and bring back his human head."] = "Soulbound Keepsake'i Ras Frostwhisper üzerinde kullanarak onu insana dönüştür, sonra onu öldür ve insan kafasını geri getir."
P["Use the supplied cage on a Bloodaxe Worg Pup in the worg area."] = "Verilen kafesi worg bölgesindeki bir Bloodaxe Worg Yavrusu üzerinde kullan."
P["Using the module on the eggs in the Rookery can hatch whelps."] = "Modülü Rookery'deki yumurtalarda kullanmak yavruların çıkmasına yol açabilir."
P["Vaelan (Scarshield Infiltrator), Lower Blackrock Spire"] = "Vaelan (Scarshield Infiltrator), Lower Blackrock Spire"
P["Vengeance of the Highborne"] = "Highborne'un İntikamı"
P["Vile Fin murlocs — Lordamere Lake"] = "Vile Fin murlocları — Lordamere Lake"
P["Vorrel Sengutz, inside the Graveyard"] = "Vorrel Sengutz, Graveyard içinde"
P["WANTED poster"] = "ARANIYOR afişi"
P["WANTED poster — Kargath, Badlands"] = "ARANIYOR afişi — Kargath, Badlands"
P["Warden Thelwater, outside The Stockade, Stormwind"] = "Warden Thelwater, The Stockade'in dışında, Stormwind"
P["Warlock class book. Click the book to start the quest."] = "Warlock sınıf kitabı. Görevi başlatmak için kitaba tıkla."
P["Warlock class quest. Needs 2 amber, 2 blue and 2 green Voodoo Feathers from the six troll guardians: Gasher, Mijan, Zolo, Hukku, Zul'Lor and Loro."] = "Warlock sınıf görevi. Altı trol muhafızından 2 kehribar, 2 mavi ve 2 yeşil Vudu Tüyü gerekir: Gasher, Mijan, Zolo, Hukku, Zul'Lor ve Loro."
P["Warlock class quest. The fragments come from Shadowfang Keep and Blackfathom Deeps."] = "Warlock sınıf görevi. Parçalar Shadowfang Keep ve Blackfathom Deeps'ten gelir."
P["Warlock dreadsteed quest. After Immol'thar dies, run the ritual in his prison with J'eevee's Jar, the Black Lodestone and the Xorothian Glyphs. Bring Soul Shards."] = "Warlock dreadsteed görevi. Immol'thar öldükten sonra J'eevee'nin Kavanozu, Kara Mıknatıs Taşı ve Xorothian Glifleri ile onun hapishanesinde ritüeli yap. Ruh Kırıkları getir."
P["Warlock dreadsteed quest. Release the Imp in a Jar at the alchemy lab in Ras Frostwhisper's room and wait for the parchment."] = "Warlock dreadsteed görevi. Ras Frostwhisper'ın odasındaki simya laboratuvarında Kavanozdaki İmp'i serbest bırak ve parşömeni bekle."
P["Warrior class book. Click the book to start the quest."] = "Warrior sınıf kitabı. Görevi başlatmak için kitaba tıkla."
P["Warrior class quest for both factions. Needs 2 amber, 2 blue and 2 green Voodoo Feathers from the six troll guardians: Gasher, Mijan, Zolo, Hukku, Zul'Lor and Loro.\n\nOptional introductory quest:"] = "Her iki fraksiyon için Warrior sınıf görevi. Altı trol muhafızından 2 kehribar, 2 mavi ve 2 yeşil Vudu Tüyü gerekir: Gasher, Mijan, Zolo, Hukku, Zul'Lor ve Loro.\n\nİsteğe bağlı giriş görevi:"
P["Warrior trainers"] = "Warrior eğitmenleri"
P["Warriors and Paladins. Lydros then gives The Forging of Quel'Serrar, which is finished in Onyxia's Lair."] = "Warrior ve Paladin'ler. Lydros ardından Onyxia's Lair'de tamamlanan The Forging of Quel'Serrar'ı verir."
P["Waves of undead attack during the ritual. Talk to the brazier near the idol afterwards to finish."] = "Ritüel sırasında undead dalgaları saldırır. Bitirmek için ardından idolün yanındaki mangalla konuş."
P["West objective: the Gauntlet of Gordok Might is in a chest near Prince Tortheldrin. The quest itself comes from a friendly Captain Kromcrush in Dire Maul North after you become the Gordok king."] = "Batı hedefi: Gordok Gücü Eldiveni, Prince Tortheldrin'in yakınındaki bir sandıkta. Görevin kendisi, Gordok kralı olduktan sonra Dire Maul North'taki dost Captain Kromcrush'tan gelir."
P["White Punch Card"] = "Beyaz Delikli Kart"
P["White Punch Cards drop from the mobs here"] = "Beyaz Delikli Kartlar buradaki yaratıklardan düşer"
P["Wiley the Black: Lakeshire inn, Redridge Mountains"] = "Wiley the Black: Lakeshire hanı, Redridge Mountains"
P["Willix the Importer, inside Razorfen Kraul"] = "Willix the Importer, Razorfen Kraul içinde"
P["Yellow Punch Card (Punchograph 3005-A)"] = "Sarı Delikli Kart (Punchograph 3005-A)"
P["Yorba Screwspigot: Steamwheedle Port, Tanaris"] = "Yorba Screwspigot: Steamwheedle Port, Tanaris"
P["You have to be dead to talk to this guy. He's in Blackrock Mountain, in a room while walking the chain down to BRD."] = "Bu adamla konuşmak için ölü olman gerekir. Blackrock Mountain'da, zincirden BRD'ye inerken bir odada."
P["You need a remote detonator for the planned explosion."] = "Planlanan patlama için uzaktan bir fünye gerekiyor."
P["You receive a Blue Punch Card"] = "Bir Mavi Delikli Kart alırsın"
P["You receive a Red Punch Card"] = "Bir Kırmızı Delikli Kart alırsın"
P["You receive a Yellow Punch Card"] = "Bir Sarı Delikli Kart alırsın"
P["Your class trainer"] = "Sınıf eğitmenin"
P["Zaetar's Spirit appears after Princess Theradras dies."] = "Zaetar's Spirit, Princess Theradras öldükten sonra belirir."
P["Zalfan Moonshadow, a highborne among the Twilight's Hammer inside the stronghold; where he stands is not known yet."] = "Zalfan Moonshadow, kalenin içindeki Twilight's Hammer arasında bir highborne; nerede durduğu henüz bilinmiyor."
P["above the entrance to"] = "girişin üstünde"
P["after the first room"] = "ilk odadan sonra"
P["beneath Spirit Rise"] = "Spirit Rise'ın altında"
P["beside the moonwell area"] = "ay kuyusu alanının yanında"
P["dropped by Dark Iron Spies"] = "Dark Iron Casusları düşürür"
P["graveyard inside Ruins of Lordaeron"] = "Ruins of Lordaeron içindeki mezarlık"
P["inside Blackfathom Deeps"] = "Blackfathom Deeps içinde"
P["inside Excavation Site: Wetlands"] = "Excavation Site: Wetlands içinde"
P["inside Gnomeregan"] = "Gnomeregan içinde"
P["inside Hall of Thanes"] = "Hall of Thanes içinde"
P["inside Ragefire Chasm"] = "Ragefire Chasm içinde"
P["inside Razorfen Kraul"] = "Razorfen Kraul içinde"
P["inside Ruins of Lordaeron"] = "Ruins of Lordaeron içinde"
P["inside Shadowfang Keep"] = "Shadowfang Keep içinde"
P["inside the Deadmines"] = "Deadmines içinde"
P["inside the Graveyard"] = "Graveyard içinde"
P["inside the dungeon"] = "zindanın içinde"
P["just inside Ruins of Lordaeron"] = "Ruins of Lordaeron'un hemen içinde"
P["just outside Excavation Site: Wetlands"] = "Excavation Site: Wetlands'in hemen dışında"
P["left of the entrance"] = "girişin solunda"
P["near the Dalaran sewer entrance"] = "Dalaran lağım girişinin yakınında"
P["near the dungeon entrance"] = "zindan girişinin yakınında"
P["near the sewer entrance"] = "lağım girişinin yakınında"
P["outside Excavation Site: Wetlands"] = "Excavation Site: Wetlands'in dışında"
P["southeast of Brill"] = "Brill'in güneydoğusunda"
P["the dungeon entrance"] = "zindan girişi"
