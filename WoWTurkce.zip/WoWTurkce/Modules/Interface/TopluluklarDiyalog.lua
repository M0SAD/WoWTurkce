-- "Topluluk Ekle" penceresi: Blizzard bu pencereyi güvenli ortamda (secure environment) çalıştırıyor; addon metne dokunamaz.
-- Çözüm: pencere açılınca (öznitelik "shown") orijinali gizleyip aynı işi yapan Türkçe bir pencere gösteriyoruz.
local G = WoWTurkce

local cerceve
local function kur()
	local f = CreateFrame("Frame", "WoWTurkceTopluluklarDiyalog", UIParent, "BackdropTemplate")
	f:SetSize(514, 400)
	f:SetPoint("TOP", UIParent, "TOP", 0, -142)
	f:SetFrameStrata("DIALOG")
	f:EnableMouse(true)
	f:SetBackdrop({
		bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
		edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
		tile = true, tileSize = 32, edgeSize = 32,
		insets = { left = 11, right = 12, top = 12, bottom = 11 },
	})
	f:Hide()

	local baslik = f:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	baslik:SetPoint("TOP", 0, -20); baslik:SetText("Topluluk Ekle")

	local kapat = CreateFrame("Button", nil, f, "UIPanelCloseButton")
	kapat:SetPoint("TOPRIGHT", -6, -6)
	kapat:SetScript("OnClick", function() f:Hide() end)

	-- WoW topluluğu
	local wowEtiket = f:CreateFontString(nil, "ARTWORK", "GameFontHighlightMedium")
	wowEtiket:SetPoint("TOPLEFT", 36, -70); wowEtiket:SetWidth(280); wowEtiket:SetJustifyH("LEFT")
	local wowAcik = f:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	wowAcik:SetPoint("TOPLEFT", wowEtiket, "BOTTOMLEFT", 0, -4); wowAcik:SetWidth(280); wowAcik:SetJustifyH("LEFT")
	wowAcik:SetText("- Oyun içi arkadaşlar için ideal\n- Herhangi bir realm'den karakterleri davet et\n- Takvim ve Hızlı Katılım desteği")
	local wowDugme = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
	wowDugme:SetSize(140, 30); wowDugme:SetPoint("TOPRIGHT", -36, -90); wowDugme:SetText("WoW Topluluğu")
	wowDugme:SetScript("OnClick", function()
		f:Hide()
		if CommunitiesCreateCommunityDialog then CommunitiesCreateCommunityDialog() end
		if PlaySound and SOUNDKIT then PlaySound(SOUNDKIT.GS_TITLE_OPTION_OK) end
	end)

	-- Battle.net grubu
	local bnEtiket = f:CreateFontString(nil, "ARTWORK", "GameFontHighlightMedium")
	bnEtiket:SetPoint("TOPLEFT", wowAcik, "BOTTOMLEFT", 0, -30); bnEtiket:SetWidth(280); bnEtiket:SetJustifyH("LEFT")
	bnEtiket:SetText("Battle.net Grubu Oluştur")
	local bnAcik = f:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	bnAcik:SetPoint("TOPLEFT", bnEtiket, "BOTTOMLEFT", 0, -4); bnAcik:SetWidth(280); bnAcik:SetJustifyH("LEFT")
	bnAcik:SetText("- Oyunlar arası arkadaşlar için ideal\n- Herhangi bir oyuncuyu davet et (üyeler BattleTag'leriyle katılır)")
	local bnDugme = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
	bnDugme:SetSize(140, 30); bnDugme:SetPoint("LEFT", wowDugme, "LEFT", 0, 0)
	bnDugme:SetPoint("TOP", bnEtiket, "TOP", 0, 8); bnDugme:SetText("Battle.net Grubu")
	bnDugme:SetScript("OnClick", function()
		f:Hide()
		if CommunitiesCreateBattleNetDialog then CommunitiesCreateBattleNetDialog() end
		if PlaySound and SOUNDKIT then PlaySound(SOUNDKIT.GS_TITLE_OPTION_OK) end
	end)

	local ayirac = f:CreateTexture(nil, "ARTWORK")
	ayirac:SetColorTexture(1, 1, 1, 0.2); ayirac:SetSize(438, 1)
	ayirac:SetPoint("TOP", f, "TOP", 0, -250)

	-- Katıl
	local katilEtiket = f:CreateFontString(nil, "ARTWORK", "GameFontHighlightMedium")
	katilEtiket:SetPoint("TOPLEFT", ayirac, "BOTTOMLEFT", 0, -24); katilEtiket:SetText("Topluluğa Katıl")
	local katilAcik = f:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	katilAcik:SetPoint("TOPLEFT", katilEtiket, "BOTTOMLEFT", 0, -4); katilAcik:SetText("Bir topluluğun davet bağlantısını veya kodunu gir:")
	local kutu = CreateFrame("EditBox", nil, f, "InputBoxTemplate")
	kutu:SetSize(340, 20); kutu:SetPoint("TOPLEFT", katilAcik, "BOTTOMLEFT", 6, -12)
	kutu:SetAutoFocus(false); kutu:SetMaxLetters(120)
	local katil = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
	katil:SetSize(80, 24); katil:SetPoint("LEFT", kutu, "RIGHT", 12, 0); katil:SetText("Katıl")
	local function katilTikla()
		local m = kutu:GetText()
		if m and m ~= "" and C_Club and C_Club.RedeemTicket then
			C_Club.RedeemTicket(m); f:Hide()
		end
		if PlaySound and SOUNDKIT then PlaySound(SOUNDKIT.GS_TITLE_OPTION_OK) end
	end
	katil:SetScript("OnClick", katilTikla)
	kutu:SetScript("OnEnterPressed", katilTikla)
	kutu:SetScript("OnEscapePressed", kutu.ClearFocus)

	f:SetScript("OnShow", function()
		local etiket, kisa = UnitFactionGroup("player")
		if etiket then
			wowEtiket:SetText("World of Warcraft Topluluğu Oluştur\n(" .. (kisa or etiket) .. " veya Hizipler Arası)")
			wowDugme:Enable()
		else
			wowEtiket:SetText("World of Warcraft Topluluğu Oluştur"); wowDugme:Disable()
		end
		bnDugme:SetEnabled(not C_Club or not C_Club.ShouldAllowClubType or C_Club.ShouldAllowClubType(Enum.ClubType.BattleNet))
		kutu:SetText(""); kutu:SetFocus()
	end)
	tinsert(UISpecialFrames, "WoWTurkceTopluluklarDiyalog")
	return f
end


-- Topluluk / Battle.net grubu oluşturma penceresi (orijinali yine güvenli ortamda; Türkçe karşılığı)
local olustur
local function olusturKur()
	local f = CreateFrame("Frame", "WoWTurkceTopluluklarOlustur", UIParent, "BackdropTemplate")
	f:SetSize(530, 500)
	f:SetPoint("TOP", UIParent, "TOP", 0, -142)
	f:SetFrameStrata("DIALOG")
	f:EnableMouse(true)
	f:SetBackdrop({
		bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
		edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
		tile = true, tileSize = 32, edgeSize = 32,
		insets = { left = 11, right = 12, top = 12, bottom = 11 },
	})
	f:Hide()
	f.tur = Enum.ClubType.Character
	f.avatar = 1

	local baslik = f:CreateFontString(nil, "ARTWORK", "GameFontHighlight")
	baslik:SetPoint("TOP", 0, -20)

	local function etiket(yer)
		local e = f:CreateFontString(nil, "ARTWORK", "GameFontNormal")
		e:SetPoint("TOPLEFT", 34, yer); return e
	end
	local function kutuYap(sinir)
		local k = CreateFrame("EditBox", nil, f, "InputBoxInstructionsTemplate")
		k:SetSize(460, 24); k:SetAutoFocus(false); k:SetMaxLetters(sinir)
		k:SetFontObject("ChatFontNormal")
		return k
	end
	local adE = etiket(-56); adE:SetText("Ad")
	local ad = kutuYap(50); ad:SetPoint("TOPLEFT", adE, "BOTTOMLEFT", 2, -6)
	local kisaE = etiket(-120); kisaE:SetText("Kısa Ad")
	local kisa = kutuYap(6); kisa:SetPoint("TOPLEFT", kisaE, "BOTTOMLEFT", 2, -6)
	local acikE = etiket(-184)
	local aciklama = CreateFrame("ScrollFrame", nil, f, "InputScrollFrameTemplate")
	aciklama:SetSize(458, 110); aciklama:SetPoint("TOPLEFT", acikE, "BOTTOMLEFT", 4, -8)
	aciklama.EditBox:SetMaxLetters(120); aciklama.EditBox:SetWidth(440)
	if aciklama.CharCount then aciklama.CharCount:Hide() end
	aciklama.hideCharCount = true

	local ring = f:CreateTexture(nil, "OVERLAY")
	ring:SetSize(110, 110); ring:SetPoint("TOP", f, "TOP", -60, -332)
	local onizleme = f:CreateTexture(nil, "ARTWORK")
	onizleme:SetSize(80, 80); onizleme:SetPoint("CENTER", ring, "CENTER")
	local degistir = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
	degistir:SetSize(120, 26); degistir:SetPoint("LEFT", ring, "RIGHT", 24, 0); degistir:SetText("Değiştir")

	local olusturD = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
	olusturD:SetSize(190, 28); olusturD:SetPoint("BOTTOM", f, "BOTTOM", -100, 28)
	local iptal = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
	iptal:SetSize(150, 28); iptal:SetPoint("LEFT", olusturD, "RIGHT", 14, 0); iptal:SetText("İptal")

	local function avatarKoy()
		pcall(C_Club.SetAvatarTexture, onizleme, f.avatar, f.tur)
	end
	local function gecerli()
		local t = f.tur
		local a = C_Club.ValidateText(t, ad:GetText(), Enum.ClubFieldType.ClubName)
		local k = C_Club.ValidateText(t, kisa:GetText(), Enum.ClubFieldType.ClubShortName)
		return a == Enum.ValidateNameResult.Success and k == Enum.ValidateNameResult.Success, a, k
	end
	local function guncelle() olusturD:SetEnabled((gecerli())) end
	ad:HookScript("OnTextChanged", guncelle); kisa:HookScript("OnTextChanged", guncelle)

	function f:Ac(tur)
		self.tur = tur
		local bn = tur == Enum.ClubType.BattleNet
		baslik:SetText(bn and "Battle.net Grubu Oluştur" or "World of Warcraft Topluluğu Oluştur")
		pcall(ring.SetAtlas, ring, bn and "communities-ring-blue" or "communities-ring-gold")
		ad.Instructions:SetText(bn and "Grubunun adı" or "Topluluğunun adı")
		kisa.Instructions:SetText(bn and "Grup adının kısa hali" or "Topluluk adının kısa hali")
		acikE:SetText(bn and "Grup Açıklaması" or "Topluluk Açıklaması")
		if aciklama.EditBox.Instructions then aciklama.EditBox.Instructions:SetText(bn and "Grubunun isteğe bağlı açıklaması" or "Topluluğunun isteğe bağlı açıklaması") end
		olusturD:SetText(bn and "Grup Oluştur" or "Topluluk Oluştur")
		ad:SetText(""); kisa:SetText(""); aciklama.EditBox:SetText("")
		local liste = C_Club.GetAvatarIdList(tur)
		self.avatar = (liste and #liste > 0) and liste[math.random(1, #liste)] or 1
		avatarKoy(); guncelle()
		self:Show()
	end

	degistir:SetScript("OnClick", function()
		f:Hide()
		if CommunitiesAvatarPicker_OpenDialog and CommunitiesAvatarPickerDialog then
			CommunitiesAvatarPicker_OpenDialog(f.tur, f.avatar, function()
				local id = CommunitiesAvatarPickerDialog:GetAvatarId()
				CommunitiesAvatarPickerDialog:Hide()
				if id then f.avatar = id end
				avatarKoy(); f:Show()
			end, function()
				CommunitiesAvatarPickerDialog:Hide(); f:Show()
			end)
		else
			f:Show()
		end
	end)
	olusturD:SetScript("OnClick", function()
		if (gecerli()) then
			C_Club.CreateClub(ad:GetText(), kisa:GetText(), aciklama.EditBox:GetText(), f.tur, f.avatar)
			f:Hide()
		end
		if PlaySound and SOUNDKIT then PlaySound(SOUNDKIT.GS_TITLE_OPTION_OK) end
	end)
	olusturD:SetScript("OnEnter", function(self)
		local ok, a, k = gecerli()
		if ok then return end
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:AddLine("Geçerli bir ad ve kısa ad girmelisin.", 1, 0.82, 0)
		local ha = a ~= Enum.ValidateNameResult.Success and C_Club.GetCommunityNameResultText(a)
		local hk = k ~= Enum.ValidateNameResult.Success and C_Club.GetCommunityNameResultText(k)
		if ha then GameTooltip:AddLine("Ad: " .. ha, 1, 0.3, 0.3, true) end
		if hk then GameTooltip:AddLine("Kısa ad: " .. hk, 1, 0.3, 0.3, true) end
		GameTooltip:Show()
	end)
	olusturD:SetScript("OnLeave", function() GameTooltip:Hide() end)
	iptal:SetScript("OnClick", function() f:Hide() end)
	ad:SetScript("OnEnterPressed", function() if olusturD:IsEnabled() then olusturD:Click() end end)
	kisa:SetScript("OnEnterPressed", function() if olusturD:IsEnabled() then olusturD:Click() end end)
	ad:SetScript("OnEscapePressed", ad.ClearFocus); kisa:SetScript("OnEscapePressed", kisa.ClearFocus)
	tinsert(UISpecialFrames, "WoWTurkceTopluluklarOlustur")
	return f
end

local gecen = 0
local izleyici = CreateFrame("Frame")
izleyici:SetScript("OnUpdate", function(_, dt)
	gecen = gecen + dt
	if gecen < 0.05 then return end
	gecen = 0
	local d = _G.CommunitiesAddDialog
	if not d or not G.modul or not G.modul("arayuz") then return end
	local ok, acik = pcall(d.GetAttribute, d, "shown")
	if ok and acik then
		pcall(d.SetAttribute, d, "setshown", false)
		cerceve = cerceve or kur()
		if cerceve:IsShown() then cerceve:Hide() else cerceve:Show() end
	end
	local c = _G.CommunitiesCreateDialog
	if c then
		local ok2, acik2 = pcall(c.GetAttribute, c, "shown")
		if ok2 and acik2 then
			pcall(c.SetAttribute, c, "setshown", false)
			local _, tur = pcall(c.GetAttribute, c, "setclubtype")
			olustur = olustur or olusturKur()
			olustur:Ac(tonumber(tur) or Enum.ClubType.Character)
		end
	end
end)
