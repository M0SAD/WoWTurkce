-- Görev penceresi ve görev günlüğü çevirisi
local G = WoWTurkce

local orijinalFont = {}
local function fontAyarla(fs, baslik)
	if not fs or not fs.GetFont then return end
	if not orijinalFont[fs] then orijinalFont[fs] = { fs:GetFont() } end
	local o = orijinalFont[fs]
	if G.modul("gorev") and G.ayar("font") then
		if G.fontSerbest(fs) then fs:SetFont(baslik and G.FONT_BASLIK or G.FONT_METIN, o[2] or 13, o[3] or "") end
	elseif o[1] then
		if G.fontSerbest(fs) then fs:SetFont(o[1], o[2], o[3] or "") end
	end
end

local function miningDuzelt(tr)
	if type(tr) ~= "string" or not tr:find("Mining", 1, true) then return tr end
	return (tr:gsub("()%f[%a]Mining%f[%A]", function(pos)
		local once = tr:sub(math.max(1, pos - 12), pos - 1)
		local sonra = tr:sub(pos + 6, pos + 11)
		if once:find("Canyon $") or once:find("Deepmountain $") or once:find("Deep Mountain $") or sonra:find("^ Guild") or sonra:find("^ and ") or sonra:find("^ Co") then return nil end
		return "Madencilik"
	end))
end

local function koy(adlar, metin, baslik)
	if not metin then return end
	metin = miningDuzelt(metin)
	for _, ad in ipairs(adlar) do
		local fs = _G[ad]
		if fs and fs.SetText then
			fontAyarla(fs, baslik)
			-- Görev adı (başlık) saf Türkçe kalır: adCevir "Kemikler" -> "Bones (Kemikler)" gibi İngilizce ek koyuyordu
			fs:SetText(G.doldur((not baslik and G.turkceMi(metin)) and G.gorevAdCevir(metin) or metin))
		end
	end
end

local BASLIK = { "QuestInfoTitleHeader", "QuestTitleText", "QuestLogQuestTitle" }
local ACIKLAMA = { "QuestInfoDescriptionText", "QuestDescription", "QuestLogQuestDescription" }
local HEDEF = { "QuestInfoObjectivesText", "QuestObjectiveText", "QuestLogObjectivesText" }
local TAMAM = { "QuestInfoRewardText", "QuestRewardText" }
local TAMAM_BASLIK = { "QuestRewardTitleText" }
local ILERLEME = { "QuestProgressText" }
local ILERLEME_BASLIK = { "QuestProgressTitleText" }
local HEPSI = {}
for _, t in ipairs({ BASLIK, ACIKLAMA, HEDEF, TAMAM, TAMAM_BASLIK, ILERLEME, ILERLEME_BASLIK }) do
	for _, a in ipairs(t) do HEPSI[#HEPSI + 1] = a end
end

local function fontlariSifirla()
	for _, ad in ipairs(HEPSI) do
		local fs = _G[ad]
		local o = fs and orijinalFont[fs]
		if o and o[1] then if G.fontSerbest(fs) then fs:SetFont(o[1], o[2], o[3] or "") end end
	end
end

local ALAN = { b = "baslik", a = "aciklama", h = "hedef", i = "ilerleme", t = "tamamlama" }

-- Çevirinin yapıldığı İngilizce metnin parmak izi oyundaki metinle uyuşuyor mu?
-- Parmak izi ya tüm metnin ya da metindeki (yer tutucu içermeyen) bir cümlenin izidir.
local izOnbellek, izSayisi = {}, 0
local function izler(en)
	local t = izOnbellek[en]
	if t then return t end
	if izSayisi > 200 then izOnbellek, izSayisi = {}, 0 end
	izSayisi = izSayisi + 1
	t = {}
	local tam = G.iz(en)
	if tam then t[tam] = true end
	for parca in en:gsub("%$[Bb]", "\n"):gmatch("[^%.!%?\n]+") do
		local n = parca:lower():gsub("[^%w]", "")
		if #n > 0 then
			local h = 5381
			for i = 1, #n do h = (h * 33 + n:byte(i)) % 4294967296 end
			t[h] = true
		end
	end
	izOnbellek[en] = t
	return t
end

-- Görev hedef özeti (görev listesi/takipçi): İngilizce hedef metninin parmak iziyle Türkçesini bul.
-- Görev başlığı, ipucu ve liste aynı kaynaktan (G.Veri) beslenir.
local hedefIdx, hedefSonuc = nil, setmetatable({}, { __mode = "k" })
local hedefOnbellek = {}
function G.gorevHedefBul(en)
	if type(en) ~= "string" or #en < 12 or not en:find(" ") then return nil end
	local v = hedefOnbellek[en]
	if v ~= nil then return v or nil end
	if not hedefIdx then
		hedefIdx = {}
		for _, tb in ipairs({ G.Veri or {}, G.VeriEk or {} }) do
			for _, q in pairs(tb) do
				if type(q) == "table" and q.h and q.k and q.k.h and hedefIdx[q.k.h] == nil then hedefIdx[q.k.h] = q.h end
			end
		end
	end
	local on, govde = en:match("^(%s*%-%s*)(.+)$")
	local metin = govde or en
	local tr
	local tam = G.iz(metin)
	if tam and hedefIdx[tam] then tr = hedefIdx[tam] end
	if not tr then
		-- Tek cümlelik hedef: cümle izi
		local n = metin:lower():gsub("[^%w]", "")
		if #n > 0 then
			local h = 5381
			for i = 1, #n do h = (h * 33 + n:byte(i)) % 4294967296 end
			tr = hedefIdx[h]
		end
	end
	if tr then tr = (on or "") .. (G.doldur and G.doldur(tr) or tr) end
	hedefOnbellek[en] = tr or false
	return tr
end

local function gecerli(v, k, en)
	if not v or not v[k] then return false end
	if v.k and v.k[k] and en and en ~= "" and not izler(en)[v.k[k]] then return false end
	return true
end

-- Ana çeviri ya da sürüm farkı (VeriEk) içinden bu İngilizce metne uyan alanı bul
local function alanBul(id, k, en, siki)
	local v = G.Veri[id]
	if gecerli(v, k, en) then return v[k] end
	local e = G.VeriEk[id]
	if gecerli(e, k, en) then return e[k] end
	-- Kimliği bilinmeyen yeni görevler (ekran görüntüsünden çevrilenler): metnin parmak izine göre
	if en and en ~= "" and G.GorevMetni and next(G.GorevMetni) then
		local tr = G.izBul(G.GorevMetni, en)
		if tr then return tr end
		if k == "b" and G.GorevAdi[en] then return G.GorevAdi[en] end
	end
	-- Blizzard metni sonradan biraz değiştirdiyse (yazım düzeltmesi, ufak ekleme) parmak izi tutmaz;
	-- yine de aynı görevin çevirisini göster (kayıt "değişmiş" olarak işaretlenir, sonra güncellenir)
	if not siki and not G.RETAIL then
		if v and v[k] then return v[k] end
		if e and e[k] then return e[k] end
	end
end
G.gorevAlan = alanBul

local function kaydet(id, en)
	G.tani = G.tani or {}
	G.tani.gorevKanca = (G.tani.gorevKanca or 0) + 1
	G.tani.gorevId = id
	if not G.ayar("kayit") then G.tani.gorevKayitKapali = true; return end
	if not id then
		-- Görev kimliği alınamadıysa metni doğrudan (kimliksiz) kaydet
		G.tani.gorevIdsiz = (G.tani.gorevIdsiz or 0) + 1
		if G.kaydetDiger then
			for k, metin in pairs(en) do
				if metin and metin ~= "" and #metin > 3 then G.kaydetDiger("gorevmetin", metin, k) end
			end
		end
		return
	end
	local v = G.Veri[id]
	local e = G.VeriEk[id]
	G.tani.gorevVeri = (v and "Veri" or "-") .. "/" .. (e and "Ek" or "-")
	do local d = {}; for k in pairs(en) do d[#d+1] = k .. "=" .. #(en[k] or "") .. (alanBul(id, k, en[k], false) and "T" or "e") end; G.tani.gorevAlan = table.concat(d, " ") end
	for k, alan in pairs(ALAN) do
		local metin = en[k]
		if metin and metin ~= "" then
			local var = (v and v[k]) or (e and e[k])
			local degisti = var and not alanBul(id, k, metin, true)
			if not var or degisti then
				local K = G.kayitAc()
				local r = K[id]
				if not r then r = {}; K[id] = r; G.ilkKayitBildir(); if G.istSay then G.istSay("gorev") end end
				G.tani.gorevYazildi = (G.tani.gorevYazildi or 0) + 1
				if not r[alan] then r[alan] = metin end
				if degisti then r.degisen = r.degisen or {}; r.degisen[alan] = true end
			end
		end
	end
end

-- Görev penceresindeki sabit başlıklar ve düğmeler ("Quest Objectives", "Rewards", "Accept" ...)
local SABIT = {
	["Quest Objectives"] = "Görev Hedefleri",
	["Description"] = "Açıklama",
	["Rewards"] = "Ödüller",
	["Reward"] = "Ödül",
	["You will receive:"] = "Alacakların:",
	["You will also receive:"] = "Ayrıca alacakların:",
	["You will be able to choose one of these rewards:"] = "Bu ödüllerden birini seçebileceksin:",
	["Choose one of these rewards:"] = "Bu ödüllerden birini seç:",
	["You will learn:"] = "Öğreneceklerin:",
	["You will be able to learn:"] = "Öğrenebileceklerin:",
	["Experience:"] = "Deneyim:",
	["Required items:"] = "Gerekli eşyalar:",
	["Required Money:"] = "Gereken Para:",
	["Accept"] = "Kabul Et",
	["Decline"] = "Reddet",
	["Continue"] = "Devam",
	["Complete Quest"] = "Görevi Tamamla",
	["Complete"] = "Tamamla",
	["Goodbye"] = "Hoşça kal",
	["Cancel"] = "İptal",
	["Abandon Quest"] = "Görevi Bırak",
	["Share Quest"] = "Görevi Paylaş",
	["Track Quest"] = "Görevi Takip Et",
	["Quest Log"] = "Görev Günlüğü",
	["No Active Quests"] = "Aktif Görev Yok",
	["Current Quests"] = "Mevcut Görevler",
	["Available Quests"] = "Alınabilir Görevler",
}
local SABIT_ADLAR = {
	"QuestInfoObjectivesHeader", "QuestInfoDescriptionHeader", "QuestInfoRewardsHeader", "QuestInfoItemChooseText",
	"QuestInfoItemReceiveText", "QuestInfoSpellLearnText", "QuestInfoXPFrameReceiveText", "QuestProgressRequiredItemsText",
	"QuestProgressRequiredMoneyText", "QuestFrameAcceptButton", "QuestFrameDeclineButton", "QuestFrameCompleteButton",
	"QuestFrameCompleteQuestButton", "QuestFrameGoodbyeButton", "QuestFrameCancelButton", "QuestFrameGreetingGoodbyeButton",
	"QuestLogFrameAbandonButton", "QuestFramePushQuestButton", "QuestLogFrameTrackButton", "QuestLogTitleText",
	"QuestLogNoQuestsText", "CurrentQuestsText", "AvailableQuestsText", "QuestLogObjectivesHeader", "QuestLogDescriptionTitle",
	"QuestLogQuestDescriptionTitle", "QuestLogRewardTitleText", "QuestLogItemChooseText", "QuestLogItemReceiveText",
	"QuestRewardRewardTitleText", "QuestRewardItemChooseText", "QuestRewardItemReceiveText", "QuestDetailObjectiveTitleText",
	"QuestDetailRewardTitleText", "QuestDetailItemChooseText", "QuestDetailItemReceiveText",
}
local sabitOrijinal = {}
local function sabitCevir(ac)
	local liste = {}
	for _, ad in ipairs(SABIT_ADLAR) do liste[#liste + 1] = _G[ad] end
	local rf = QuestInfoRewardsFrame
	if rf then
		if rf.Header then liste[#liste + 1] = rf.Header end
		if rf.ItemChooseText then liste[#liste + 1] = rf.ItemChooseText end
		if rf.ItemReceiveText then liste[#liste + 1] = rf.ItemReceiveText end
		if rf.XPFrame and rf.XPFrame.ReceiveText then liste[#liste + 1] = rf.XPFrame.ReceiveText end
	end
	for _, o in ipairs(liste) do
		if o and o.GetText and o.SetText then
			local m = o:GetText()
			if ac then
				local tr = m and SABIT[m]
				if tr then sabitOrijinal[o] = m; G.sigdirKoy(o, tr) end
			elseif sabitOrijinal[o] and m == SABIT[sabitOrijinal[o]] then
				o:SetText(sabitOrijinal[o]); G.sigdirSifirla(o)
			end
		end
	end
end

local function uygula(id, tur, en)
	fontlariSifirla()
	sabitCevir(G.modul("gorev"))
	local v = id and (G.Veri[id] or G.VeriEk[id])
	if not G.modul("gorev") then return end
	en = en or {}
	-- Veritabanında olmayan görev: metin parmak iziyle bulunabiliyorsa yine çevir
	if not v and not (next(G.GorevMetni) and ((en.a and G.izBul(G.GorevMetni, en.a)) or (en.b and G.GorevAdi[en.b]))) then return end
	local function al(k)
		local tr = alanBul(id, k, en[k])
		-- Retail metinlerindeki "$1oa" gibi miktar belirteçlerini İngilizce metindeki sayılarla doldur
		-- (ve "$30474w", "$3409cur" gibi büyü değeri belirteçleri): Türkçede zaten yazılı olan sayılar çıkarılır,
		-- kalan İngilizce sayılar belirteçlere sırayla konur
		if tr and tr:find("%$%d+%a") then
			local var = {}
			for n in tr:gsub("%$%d+%a+", ""):gmatch("%d+") do var[n] = (var[n] or 0) + 1 end
			local sayilar = {}
			for n in (en[k] or ""):gmatch("%d[%d,%.]*") do
				local saf = n:gsub("[,%.]$", "")
				if var[saf] and var[saf] > 0 then var[saf] = var[saf] - 1 else sayilar[#sayilar + 1] = saf end
			end
			local i = 0
			tr = tr:gsub("%$%d+%a+", function() i = i + 1; return sayilar[i] or "" end)
		end
		-- Çeviride İngilizce kalmış "Mining" kelimesi (özel adlarda değil): Madencilik
		if type(tr) == "string" and tr:find("Mining", 1, true) then
			tr = tr:gsub("()%f[%a]Mining%f[%A]", function(pos)
				local once = tr:sub(math.max(1, pos - 12), pos - 1)
				local sonra = tr:sub(pos + 6, pos + 11)
				if once:find("Canyon $") or once:find("Deepmountain $") or once:find("Deep Mountain $") or sonra:find("^ Guild") or sonra:find("^ and ") or sonra:find("^ Co") then return nil end
				return "Madencilik"
			end)
		end
		return tr
	end
	-- Başlık çevirisini hatırla: NPC'nin görev listesinde (konuşma penceresi) de Türkçe görünsün
	if en.b and not G.GorevAdi[en.b] then
		local tb = al("b")
		if type(tb) == "string" and tb ~= en.b then G.GorevAdi[en.b] = tb end
	end
	if tur == "detay" or tur == "log" then
		koy(BASLIK, al("b"), true); koy(ACIKLAMA, al("a")); koy(HEDEF, al("h"))
	elseif tur == "ilerleme" then
		koy(ILERLEME_BASLIK, al("b"), true); koy(ILERLEME, al("i"))
	elseif tur == "tamamla" then
		koy(BASLIK, al("b"), true); koy(TAMAM_BASLIK, al("b"), true); koy(TAMAM, al("t"))
	end
end

local function npcID()
	if GetQuestID then
		local id = GetQuestID()
		if id and id > 0 then return id end
	end
	if QuestInfoFrame and QuestInfoFrame.questID and QuestInfoFrame.questID > 0 then return QuestInfoFrame.questID end
	if QuestFrame and QuestFrame.questID and QuestFrame.questID > 0 then return QuestFrame.questID end
end

local function logID()
	if C_QuestLog and C_QuestLog.GetSelectedQuest then
		local id = C_QuestLog.GetSelectedQuest()
		if id and id > 0 then return id end
	end
	if GetQuestLogSelection and GetQuestLogTitle then
		local i = GetQuestLogSelection()
		if i and i > 0 then
			local id = select(8, GetQuestLogTitle(i))
			if id and id > 0 then return id end
		end
	end
end

local son = {}
local bayrakGuncelle
local function cagir(f) return f and f() end

local function npcDetay()
	local id = npcID()
	local en = { b = cagir(GetTitleText), a = cagir(GetQuestText), h = cagir(GetObjectiveText) }
	son.id, son.tur, son.en = id, "detay", en
	kaydet(id, en); uygula(id, "detay", en)
	if bayrakGuncelle then pcall(bayrakGuncelle) end
end

local function npcIlerleme()
	local id = npcID()
	local en = { b = cagir(GetTitleText), i = cagir(GetProgressText) }
	son.id, son.tur, son.en = id, "ilerleme", en
	kaydet(id, en); uygula(id, "ilerleme", en)
	if bayrakGuncelle then pcall(bayrakGuncelle) end
end

local function npcTamamla()
	local id = npcID()
	local en = { b = cagir(GetTitleText), t = cagir(GetRewardText) }
	son.id, son.tur, son.en = id, "tamamla", en
	kaydet(id, en); uygula(id, "tamamla", en)
	if bayrakGuncelle then pcall(bayrakGuncelle) end
end

local function logDetay()
	local id = logID()
	local en = {}
	if GetQuestLogSelection and GetQuestLogTitle then en.b = GetQuestLogTitle(GetQuestLogSelection() or 0)
	elseif id and C_QuestLog and C_QuestLog.GetTitleForQuestID then en.b = C_QuestLog.GetTitleForQuestID(id) end
	if GetQuestLogQuestText then en.a, en.h = GetQuestLogQuestText() end
	kaydet(id, en); uygula(id, "log", en)
	if bayrakGuncelle then pcall(bayrakGuncelle) end
end

local function ingilizce()
	fontlariSifirla()
	sabitCevir(false)
	if not (QuestFrame and QuestFrame:IsShown()) or not son.en then return end
	local en = son.en
	if son.tur == "detay" then
		koy(BASLIK, en.b); koy(ACIKLAMA, en.a); koy(HEDEF, en.h)
	elseif son.tur == "ilerleme" then
		koy(ILERLEME_BASLIK, en.b); koy(ILERLEME, en.i)
	elseif son.tur == "tamamla" then
		koy(BASLIK, en.b); koy(TAMAM_BASLIK, en.b); koy(TAMAM, en.t)
	end
	fontlariSifirla()
end

local dugmeler = {}
local function yenile()
	for _, b in ipairs(dugmeler) do b:SetText(G.modul("gorev") and "TR" or "EN") end
	if G.modul("gorev") then
		if QuestFrame and QuestFrame:IsShown() then uygula(son.id, son.tur, son.en) end
	else
		ingilizce()
	end
	if QuestLogFrame and QuestLogFrame:IsShown() and QuestLog_UpdateQuestDetails then QuestLog_UpdateQuestDetails() end
end
G.gorevYenile = yenile

-- "!" bayrakları: işaretli görevde kırmızı ve basılı görünür
local bayraklar = {}
local function anahtarBul(parent)
	if parent == QuestLogFrame then
		local id = logID()
		local b = GetQuestLogSelection and GetQuestLogTitle and GetQuestLogTitle(GetQuestLogSelection() or 0)
		return id, b
	end
	return son.id, son.en and son.en.b
end
bayrakGuncelle = function()
	local K = WoWTurkce_Kayit
	for _, y in ipairs(bayraklar) do
		local id, b = anahtarBul(y.parent)
		local isaretli = K and K.yanlis and ((id and K.yanlis[id]) or (b and K.yanlis[b])) and true or false
		local fs = y:GetFontString()
		if isaretli then
			y:LockHighlight()
			if fs then fs:SetTextColor(1, 0.25, 0.25) end
			y:SetText("|cffff4040!|r")
		else
			y:UnlockHighlight()
			if fs then fs:SetTextColor(1, 0.82, 0) end
			y:SetText("!")
		end
		y.isaretli = isaretli
	end
end

local function dugmeEkle(parent)
	if not parent then return end
	local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
	b:SetSize(32, 18)
	-- Başlık çubuğunun altına, kaydırma çubuğunun soluna koy (NPC adının üstüne binmesin)
	local kapat = (parent.GetName and parent:GetName() and _G[parent:GetName() .. "CloseButton"]) or parent.CloseButton
	if kapat then b:SetPoint("TOPRIGHT", kapat, "BOTTOMLEFT", -2, -4)
	else b:SetPoint("TOPRIGHT", parent, "TOPRIGHT", -48, -44) end
	b:SetFrameStrata("HIGH")
	b:SetScript("OnClick", function() G.ayarla("gorev", not G.ayar("gorev")) end)
	b:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:AddLine("WoWTurkce")
		GameTooltip:AddLine("Görev metnini Türkçe / İngilizce arasında değiştir.", 1, 1, 1, true)
		GameTooltip:Show()
	end)
	b:SetScript("OnLeave", function() GameTooltip:Hide() end)
	b:SetText(G.modul("gorev") and "TR" or "EN")
	dugmeler[#dugmeler + 1] = b
	-- "Bu çeviri yanlış" bayrağı: görevi düzeltilecekler listesine yazar (bir sonraki toplamada düzeltilir)
	local y = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
	y:SetSize(22, 18)
	y:SetPoint("RIGHT", b, "LEFT", -2, 0)
	y:SetFrameStrata("HIGH")
	y:SetText("!")
	y.parent = parent
	bayraklar[#bayraklar + 1] = y
	y:SetScript("OnClick", function()
		local id, baslik, en
		if parent == QuestLogFrame then
			id = logID()
			if GetQuestLogSelection and GetQuestLogTitle then baslik = GetQuestLogTitle(GetQuestLogSelection() or 0) end
			en = { b = baslik }
			if GetQuestLogQuestText then en.a, en.h = GetQuestLogQuestText() end
		else
			id = son.id; baslik = son.en and son.en.b
			en = {}
			for k, v in pairs(son.en or {}) do en[k] = v end
		end
		if not id and not baslik then G.yaz("İşaretlenecek görev bulunamadı."); return end
		local K = G.kayitAc()
		K.yanlis = K.yanlis or {}
		local anahtar = id or baslik
		if K.yanlis[anahtar] then
			K.yanlis[anahtar] = nil
			G.yaz(("İşaret kaldırıldı: %s"):format(baslik or tostring(id)))
		else
			K.yanlis[anahtar] = { id = id, b = baslik, en = en, tur = (parent == QuestLogFrame) and "log" or son.tur, zaman = date and date("%Y-%m-%d %H:%M") }
			G.yaz(("|cffffd200Düzeltilecekler listesine eklendi:|r %s. Bir sonraki gönderimde düzeltilecek (tekrar basarsan işaret kalkar)."):format(baslik or tostring(id)))
		end
		bayrakGuncelle()
	end)
	y:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:AddLine(self.isaretli and "|cffff4040İşaretli: düzeltilecekler listesinde|r" or "Bu çeviri yanlış / eksik")
		GameTooltip:AddLine("Görevi düzeltilecekler listesine ekler. Tekrar basınca işaret kalkar.", 1, 1, 1, true)
		GameTooltip:Show()
	end)
	y:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

G.dinle(function(k) if k == "gorev" or k == "acik" or k == "font" then yenile() end end)

G.basla(function()
	if QuestInfo_Display then
		hooksecurefunc("QuestInfo_Display", function(template, parentFrame)
			local log = (QUEST_TEMPLATE_LOG and template == QUEST_TEMPLATE_LOG)
				or (QUEST_TEMPLATE_MAP_DETAILS and template == QUEST_TEMPLATE_MAP_DETAILS)
				or (parentFrame and QuestLogDetailScrollChildFrame and parentFrame == QuestLogDetailScrollChildFrame)
			if log then logDetay()
			elseif QUEST_TEMPLATE_REWARD and template == QUEST_TEMPLATE_REWARD then npcTamamla()
			else npcDetay() end
		end)
	else
		if QuestFrameDetailPanel then QuestFrameDetailPanel:HookScript("OnShow", npcDetay) end
		if QuestFrameRewardPanel then QuestFrameRewardPanel:HookScript("OnShow", npcTamamla) end
	end
	if QuestLog_UpdateQuestDetails then hooksecurefunc("QuestLog_UpdateQuestDetails", logDetay) end
	if QuestFrameProgressPanel then QuestFrameProgressPanel:HookScript("OnShow", npcIlerleme) end
	if QuestFrameRewardPanel then QuestFrameRewardPanel:HookScript("OnShow", npcTamamla) end
	if QuestFrameDetailPanel then QuestFrameDetailPanel:HookScript("OnShow", npcDetay) end
	dugmeEkle(QuestFrame)
	dugmeEkle(QuestLogFrame)
end)

-- Test için dışa açık
G._gorev = { npcDetay = npcDetay, npcIlerleme = npcIlerleme, logDetay = logDetay }
