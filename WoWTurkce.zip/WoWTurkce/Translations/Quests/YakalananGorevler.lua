-- Oyundan yakalanan görev metinleri ("çevir" ile eklenir). Metin parmak iziyle eşleşir.
local G = WoWTurkce
local gorev = G.yeniGorev
if not gorev then return end

-- Karanlıkta Bir Işık (98389)
gorev(nil, nil, {
	{ "Greetings, priest. Yes, I am a paladin. Not even death can stop the Light.\r\n\r\nThis is something my kind have in common with all Forsaken--we have overcome what the living view as their end. However, some even among our own fear us; they suspect we will smite them as some monstrosity.\r\n\r\nIn truth, our relationship with undeath is complex, but I am not here to hurt our own. Help me show the others this. Venture to Night's Web Hollow to the northwest and free the freshly raised fools trapped by the spiders there.",
	  "Selamlar, rahip. Evet, ben bir paladinim. Ölüm bile Işık'ı durduramaz.\r\n\r\nBu, bizim türümüzün tüm Forsaken'larla ortak noktası--yaşayanların son saydığı şeyin üstesinden geldik. Yine de kendi aramızdan bazıları bile bizden korkuyor; onları bir canavarmışız gibi cezalandıracağımızdan şüpheleniyorlar.\r\n\r\nAslında ölümsüzlükle ilişkimiz karmaşık, ama ben kendi halkımıza zarar vermeye gelmedim. Bunu diğerlerine göstermeme yardım et. Kuzeybatıdaki Night's Web Hollow'a git ve oradaki örümceklerin tuzağına düşmüş, yeni diriltilmiş aptalları kurtar." },
})
