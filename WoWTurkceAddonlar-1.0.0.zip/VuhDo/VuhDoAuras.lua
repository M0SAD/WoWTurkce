local _;

local pairs = pairs;
local ipairs = ipairs;
local tinsert = table.insert;
local tremove = table.remove;
local twipe = table.wipe;
local floor = math.floor;
local strfind = string.find;
local gsub = string.gsub;
local strsub = string.sub;
local gmatch = string.gmatch;
local strupper = string.upper;
local format = string.format;
local next = next;

local GetUnitAuras = C_UnitAuras and C_UnitAuras.GetUnitAuras;
local GetAuraDataByAuraInstanceID = C_UnitAuras and C_UnitAuras.GetAuraDataByAuraInstanceID;
local IsAuraFilteredOutByInstanceID = C_UnitAuras and C_UnitAuras.IsAuraFilteredOutByInstanceID;
local UnitIsUnit = UnitIsUnit;
local UnitCanAttack = UnitCanAttack;
local issecretvalue = issecretvalue;

local VUHDO_CONFIG;
local VUHDO_AURA_GROUPS;
local VUHDO_AURA_IGNORE_LIST;
local VUHDO_DEFAULT_AURA_GROUPS;
local VUHDO_PANEL_MODELS;
local VUHDO_PANEL_SETUP;
local VUHDO_DEFAULT_AURA_DEFAULTS;
local VUHDO_UNIT_BUTTONS_PANEL;
local VUHDO_RAID;
local VUHDO_I18N_AURA_GROUP_NAMES;
local VUHDO_BOUQUETS;
local VUHDO_BOUQUET_BUFFS_SPECIAL;
local VUHDO_AURA_FRAMES;
local VUHDO_UPDATE_DEBUFF;

local VUHDO_UNIT_AURA_SOURCE_MINE;
local VUHDO_UNIT_AURA_SOURCE_OTHERS;
local VUHDO_UNIT_AURA_SOURCE_BOTH;

local VUHDO_AURA_CONDITION_BOOLEAN_KEYS;
local VUHDO_AURA_MATCH_ANY_FILTER_TOKEN_ORDER;
local VUHDO_AURA_NAME_MATCH_SPELL_NAMES;

local VUHDO_generateUUID;
local VUHDO_determineAura;
local VUHDO_updateAuraDisplaysForUnit;
local VUHDO_updateEventBouquet;
local VUHDO_refreshListBouquetsForUnit;
local VUHDO_isAuraDataRestricted;
local VUHDO_isAuraModeContainers;
local VUHDO_needsUnitAuraEvent;
local VUHDO_checkAuraGroupSounds;
local VUHDO_getPlayerDispelTypeNames;
local VUHDO_getPlayerPurgeDispelTypeNames;
local VUHDO_shouldDropRestrictedAuraEvent;
local VUHDO_resetAuraFrameDisplayCache;
local VUHDO_displayAurasAtAnchorFromCache;
local VUHDO_classifyBouquetRestrictedMode;
local VUHDO_getBouquetLayerTemplate;
local VUHDO_getUnitButtonsPanel;
local VUHDO_updateHealthBarsFor;
local VUHDO_getAuraListEntryMatchValue;

VUHDO_UNIT_AURA_CACHE = VUHDO_UNIT_AURA_CACHE or { };
local VUHDO_UNIT_AURA_CACHE = VUHDO_UNIT_AURA_CACHE;

VUHDO_UNIT_AURA_SLOTS = VUHDO_UNIT_AURA_SLOTS or { };
local VUHDO_UNIT_AURA_SLOTS = VUHDO_UNIT_AURA_SLOTS;

VUHDO_UNIT_AURA_SLOT_INDEX = VUHDO_UNIT_AURA_SLOT_INDEX or { };
local VUHDO_UNIT_AURA_SLOT_INDEX = VUHDO_UNIT_AURA_SLOT_INDEX;

VUHDO_UNIT_AURA_BY_SPELL = VUHDO_UNIT_AURA_BY_SPELL or { };
local VUHDO_UNIT_AURA_BY_SPELL = VUHDO_UNIT_AURA_BY_SPELL;

VUHDO_UNIT_AURA_LIST_SLOTS = VUHDO_UNIT_AURA_LIST_SLOTS or { };
local VUHDO_UNIT_AURA_LIST_SLOTS = VUHDO_UNIT_AURA_LIST_SLOTS;

VUHDO_AURA_LIST_BOUQUETS = VUHDO_AURA_LIST_BOUQUETS or { };
local VUHDO_AURA_LIST_BOUQUETS = VUHDO_AURA_LIST_BOUQUETS;

VUHDO_ACTIVE_AURA_SPELLS = { };
local VUHDO_ACTIVE_AURA_SPELLS = VUHDO_ACTIVE_AURA_SPELLS;

VUHDO_ACTIVE_AURA_FILTERS = { };
local VUHDO_ACTIVE_AURA_FILTERS = VUHDO_ACTIVE_AURA_FILTERS;

VUHDO_AURA_SPELL_TO_BOUQUETS = VUHDO_AURA_SPELL_TO_BOUQUETS or { };
local VUHDO_AURA_SPELL_TO_BOUQUETS = VUHDO_AURA_SPELL_TO_BOUQUETS;

VUHDO_AURA_MIGRATION_VERSION = 12;
local VUHDO_AURA_MIGRATION_VERSION = VUHDO_AURA_MIGRATION_VERSION;

VUHDO_AURA_GROUP_COLOR_OFF = 1;
VUHDO_AURA_GROUP_COLOR_DISPEL = 2;
VUHDO_AURA_GROUP_COLOR_CUSTOM = 3;
VUHDO_AURA_GROUP_COLOR_ALL_DISPEL = 4;

VUHDO_AURA_GROUP_UNIT_SCOPE_BOTH = 1;
VUHDO_AURA_GROUP_UNIT_SCOPE_FRIENDLY = 2;
VUHDO_AURA_GROUP_UNIT_SCOPE_HOSTILE = 3;

local VUHDO_ALL_DISPELLABLE_TOKEN = "VUHDO_ALL_DISPELLABLE";

local VUHDO_HOTS_RADIOVALUE_GROWTH = {
	[1] = "LEFT",
	[2] = "RIGHT",
	[3] = "LEFT",
	[4] = "RIGHT",
	[5] = "RIGHT",
	[6] = "LEFT",
	[7] = "RIGHT",
	[8] = "LEFT",
	[9] = "RIGHT",
	[10] = "RIGHT",
	[11] = "LEFT",
	[12] = "RIGHT",
	[13] = "RIGHT",
	[14] = "LEFT",
};

local VUHDO_HOTS_RADIOVALUE_WRAP = {
	[1] = "DOWN",
	[2] = "DOWN",
	[3] = "DOWN",
	[4] = "DOWN",
	[5] = "UP",
	[6] = "UP",
	[7] = "UP",
	[8] = "UP",
	[9] = "DOWN",
	[10] = "DOWN",
	[11] = "UP",
	[12] = "UP",
	[13] = "UP",
	[14] = "UP",
};

local VUHDO_POINT_TO_RADIOVALUE = {
	["TOPLEFT"] = 9,
	["TOPRIGHT"] = 17,
	["BOTTOMLEFT"] = 13,
	["BOTTOMRIGHT"] = 14,
};

local VUHDO_DEBUFF_OFFSET_TRANSLATION = {
	["TOPLEFT"] = {
		["x"] = 0,
		["y"] = 0,
	},
	["TOPRIGHT"] = {
		["x"] = 2,
		["y"] = 34,
	},
	["BOTTOMLEFT"] = {
		["x"] = -2,
		["y"] = -34,
	},
	["BOTTOMRIGHT"] = {
		["x"] = 2,
		["y"] = -34,
	},
};

local sEmpty = { };
local sAssignedAuras = { };
local sSlotsToClear = { };
local sSlotsToClearCount = 0;
local sFilteredAuras = { };

local sIsBatchingListAnchors = false;
local sPendingListAnchors = { };

local sAuraDataPool;
local sSlotIndexPool;
local sSlotDataPool;
local sReverseIndexArrayPool;

local sHasActiveAuraFilters = false;

local sAllGroups = { };
local sScaleCounts = { };
local sProcessAuraScratch = { };

local sSpecialAuraUnits = { "player", "pet", "target", "focus" };

for tCnt = 1, VUHDO_MAX_BOSS_FRAMES do
	tinsert(sSpecialAuraUnits, string.format("boss%d", tCnt));
end



do
	--
	local tCount;
	function VUHDO_tableCount(aTable)

		tCount = 0;

		if aTable then
			for _ in pairs(aTable) do
				tCount = tCount + 1;
			end
		end

		return tCount;

	end



	--
	local function VUHDO_createSlotDataDelegate()

		return {
			["color"] = { },
		};

	end



	--
	local function VUHDO_cleanupSlotDataDelegate(aSlotData)

		aSlotData["icon"] = nil;
		aSlotData["expirationTime"] = nil;
		aSlotData["stacks"] = nil;
		aSlotData["duration"] = nil;
		aSlotData["name"] = nil;
		aSlotData["spellId"] = nil;
		aSlotData["auraInstanceID"] = nil;
		aSlotData["entryType"] = nil;
		aSlotData["isActive"] = nil;
		aSlotData["clipL"] = nil;
		aSlotData["clipR"] = nil;
		aSlotData["clipT"] = nil;
		aSlotData["clipB"] = nil;
		aSlotData["isAliveTime"] = nil;
		aSlotData["groupId"] = nil;
		aSlotData["entryIndex"] = nil;

		if aSlotData["color"] then
			twipe(aSlotData["color"]);
		end

		return;

	end



	--
	function VUHDO_aurasInitLocalOverrides()

		VUHDO_CONFIG = _G["VUHDO_CONFIG"];
		VUHDO_AURA_GROUPS = VUHDO_CONFIG["AURA_GROUPS"];
		VUHDO_AURA_IGNORE_LIST = _G["VUHDO_AURA_IGNORE_LIST"];
		VUHDO_DEFAULT_AURA_GROUPS = _G["VUHDO_DEFAULT_AURA_GROUPS"];
		VUHDO_PANEL_MODELS = _G["VUHDO_PANEL_MODELS"];
		VUHDO_PANEL_SETUP = _G["VUHDO_PANEL_SETUP"];
		VUHDO_DEFAULT_AURA_DEFAULTS = _G["VUHDO_DEFAULT_AURA_DEFAULTS"];
		VUHDO_UNIT_BUTTONS_PANEL = _G["VUHDO_UNIT_BUTTONS_PANEL"];
		VUHDO_RAID = _G["VUHDO_RAID"];
		VUHDO_I18N_AURA_GROUP_NAMES = _G["VUHDO_I18N_AURA_GROUP_NAMES"];
		VUHDO_BOUQUETS = _G["VUHDO_BOUQUETS"];
		VUHDO_BOUQUET_BUFFS_SPECIAL = _G["VUHDO_BOUQUET_BUFFS_SPECIAL"];
		VUHDO_AURA_FRAMES = _G["VUHDO_AURA_FRAMES"];
		VUHDO_UPDATE_DEBUFF = _G["VUHDO_UPDATE_DEBUFF"];

		VUHDO_UNIT_AURA_SOURCE_MINE = _G["VUHDO_UNIT_AURA_SOURCE_MINE"];
		VUHDO_UNIT_AURA_SOURCE_OTHERS = _G["VUHDO_UNIT_AURA_SOURCE_OTHERS"];
		VUHDO_UNIT_AURA_SOURCE_BOTH = _G["VUHDO_UNIT_AURA_SOURCE_BOTH"];

		VUHDO_AURA_CONDITION_BOOLEAN_KEYS = _G["VUHDO_AURA_CONDITION_BOOLEAN_KEYS"];
		VUHDO_AURA_MATCH_ANY_FILTER_TOKEN_ORDER = _G["VUHDO_AURA_MATCH_ANY_FILTER_TOKEN_ORDER"];
		VUHDO_AURA_NAME_MATCH_SPELL_NAMES = _G["VUHDO_AURA_NAME_MATCH_SPELL_NAMES"];

		VUHDO_generateUUID = _G["VUHDO_generateUUID"];
		VUHDO_determineAura = _G["VUHDO_determineAura"];
		VUHDO_updateAuraDisplaysForUnit = _G["VUHDO_updateAuraDisplaysForUnit"];
		VUHDO_updateEventBouquet = _G["VUHDO_updateEventBouquet"];
		VUHDO_refreshListBouquetsForUnit = _G["VUHDO_refreshListBouquetsForUnit"];
		VUHDO_isAuraDataRestricted = _G["VUHDO_isAuraDataRestricted"];
		VUHDO_isAuraModeContainers = _G["VUHDO_isAuraModeContainers"];
		VUHDO_needsUnitAuraEvent = _G["VUHDO_needsUnitAuraEvent"];
		VUHDO_checkAuraGroupSounds = _G["VUHDO_checkAuraGroupSounds"];
		VUHDO_getPlayerDispelTypeNames = _G["VUHDO_getPlayerDispelTypeNames"];
		VUHDO_getPlayerPurgeDispelTypeNames = _G["VUHDO_getPlayerPurgeDispelTypeNames"];
		VUHDO_shouldDropRestrictedAuraEvent = _G["VUHDO_shouldDropRestrictedAuraEvent"];
		VUHDO_resetAuraFrameDisplayCache = _G["VUHDO_resetAuraFrameDisplayCache"];
		VUHDO_displayAurasAtAnchorFromCache = _G["VUHDO_displayAurasAtAnchorFromCache"];
		VUHDO_classifyBouquetRestrictedMode = _G["VUHDO_classifyBouquetRestrictedMode"];
		VUHDO_getBouquetLayerTemplate = _G["VUHDO_getBouquetLayerTemplate"];
		VUHDO_getUnitButtonsPanel = _G["VUHDO_getUnitButtonsPanel"];
		VUHDO_updateHealthBarsFor = _G["VUHDO_updateHealthBarsFor"];
		VUHDO_getAuraListEntryMatchValue = _G["VUHDO_getAuraListEntryMatchValue"];

		VUHDO_updateAuraDisplaysForUnit = _G["VUHDO_deferUpdateAuraDisplaysForUnit"];
		VUHDO_updateHealthBarsFor = _G["VUHDO_deferUpdateHealthBarsFor"];

		sAuraDataPool = VUHDO_createTablePool("AuraData", 500);
		sSlotIndexPool = VUHDO_createTablePool("SlotIndex", 200);
		sSlotDataPool = VUHDO_createTablePool("SlotData", 500, VUHDO_createSlotDataDelegate, VUHDO_cleanupSlotDataDelegate);
		sReverseIndexArrayPool = VUHDO_createTablePool("ReverseIndexArray", 300);

		VUHDO_initAuraGroupFilters();

		return;

	end



	--
	function VUHDO_getSlotData()

		return sSlotDataPool:get();

	end
end



do
	--
	local tSecretTemplate;
	local tSecretValidatorEntry;
	local tSecretIsActive;
	local tSecretBool;
	local tSecretPlainActive;
	local function VUHDO_getNonAuraSlotTrigger(aBouquetName, anInfo)

		tSecretTemplate = VUHDO_getBouquetLayerTemplate(aBouquetName);

		if not tSecretTemplate or not tSecretTemplate["hasBools"] or not anInfo then
			return false;
		end

		tSecretPlainActive = true;

		for tIdx = 1, #tSecretTemplate["booleanValidators"] do
			tSecretValidatorEntry = tSecretTemplate["booleanValidators"][tIdx];

			tSecretIsActive, _, _, _, _, _, _, _, _, _, _, tSecretBool = tSecretValidatorEntry["special"]["validator"](anInfo, tSecretValidatorEntry["item"]);

			if issecretvalue(tSecretBool) then
				return true, nil, tSecretBool, tSecretValidatorEntry["special"]["isInverted"] == true;
			end

			if not tSecretIsActive then
				tSecretPlainActive = false;
			end
		end

		return true, tSecretPlainActive, nil, false;

	end



	--
	local tNonAuraEntries;
	local tNonAuraInfo;
	local tNonAuraIsFixed;
	local tNonAuraButtonName;
	local tNonAuraButtonFrames;
	local tNonAuraDisplaySlot;
	local tNonAuraSlotData;
	local tNonAuraActualSlot;
	local tNonAuraSlotFrame;
	local tNonAuraEntry;
	local tNonAuraHasBools;
	local tNonAuraPlainActive;
	local tNonAuraSecretBool;
	local tNonAuraIsInverted;
	local function VUHDO_applyNonAuraSecretSlotAlpha(aUnit, aPanelNum, anAnchorIndex, anAnchorConfig, aGroup, aListSlots, aMaxSlots, aPanelUnitButtons)

		if not aListSlots then
			return;
		end

		tNonAuraEntries = aGroup["entries"];

		if not tNonAuraEntries then
			return;
		end

		tNonAuraInfo = VUHDO_RAID[aUnit];
		tNonAuraIsFixed = anAnchorConfig["fixedSlots"];

		for _, tButton in pairs(aPanelUnitButtons or sEmpty) do
			tNonAuraButtonName = tButton:GetName();
			tNonAuraButtonFrames = VUHDO_AURA_FRAMES[tNonAuraButtonName] and VUHDO_AURA_FRAMES[tNonAuraButtonName][anAnchorIndex];

			if tNonAuraButtonFrames then
				tNonAuraDisplaySlot = 0;

				for tSlotIndex = 1, aMaxSlots do
					tNonAuraSlotData = aListSlots[tSlotIndex];

					if tNonAuraSlotData and tNonAuraSlotData["isActive"] then
						tNonAuraDisplaySlot = tNonAuraDisplaySlot + 1;
						tNonAuraActualSlot = tNonAuraIsFixed and tSlotIndex or tNonAuraDisplaySlot;

						tNonAuraSlotFrame = tNonAuraButtonFrames[tNonAuraActualSlot];
						tNonAuraEntry = tNonAuraEntries[tSlotIndex];

						if tNonAuraSlotFrame and tNonAuraEntry and tNonAuraEntry["entryType"] == VUHDO_AURA_LIST_ENTRY_BOUQUET
							and VUHDO_classifyBouquetRestrictedMode(tNonAuraEntry["value"]) == VUHDO_BOUQUET_RESTRICTED_NON_AURA then
							tNonAuraHasBools, tNonAuraPlainActive, tNonAuraSecretBool, tNonAuraIsInverted = VUHDO_getNonAuraSlotTrigger(tNonAuraEntry["value"], tNonAuraInfo);

							if tNonAuraHasBools then
								if tNonAuraPlainActive ~= nil then
									tNonAuraSlotFrame:SetAlpha(tNonAuraPlainActive and 1 or 0);
								elseif tNonAuraIsInverted then
									tNonAuraSlotFrame:SetAlphaFromBoolean(tNonAuraSecretBool, 0, 1);
								else
									tNonAuraSlotFrame:SetAlphaFromBoolean(tNonAuraSecretBool, 1, 0);
								end

								VUHDO_resetAuraFrameDisplayCache(tNonAuraSlotFrame);
							end
						end
					end
				end
			end
		end

		return;

	end



	--
	local tNonAuraAnchorConfig;
	local tNonAuraGroup;
	local tNonAuraListSlots;
	local tNonAuraMaxSlots;
	local tNonAuraPanelUnitButtons;
	function VUHDO_renderNonAuraListSlots(aUnit, aPanelNum, anAnchorIndex)

		if not aUnit or not aPanelNum or not anAnchorIndex then
			return;
		end

		tNonAuraAnchorConfig = VUHDO_PANEL_SETUP[aPanelNum]
			and VUHDO_PANEL_SETUP[aPanelNum]["AURA_ANCHORS"]
			and VUHDO_PANEL_SETUP[aPanelNum]["AURA_ANCHORS"][anAnchorIndex];

		if not tNonAuraAnchorConfig or tNonAuraAnchorConfig["enabled"] == false then
			return;
		end

		tNonAuraGroup = VUHDO_getAuraGroup(tNonAuraAnchorConfig["groupId"]);

		if not tNonAuraGroup or (tNonAuraGroup["type"] or 1) ~= VUHDO_AURA_GROUP_TYPE_LIST then
			return;
		end

		tNonAuraListSlots = VUHDO_UNIT_AURA_LIST_SLOTS[aUnit]
			and VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][aPanelNum]
			and VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][aPanelNum][anAnchorIndex];

		tNonAuraMaxSlots = tNonAuraAnchorConfig["maxDisplay"] or 5;
		tNonAuraPanelUnitButtons = VUHDO_getUnitButtonsPanel(aUnit, aPanelNum);

		VUHDO_displayAurasAtAnchorFromCache(aUnit, aPanelNum, anAnchorIndex, tNonAuraAnchorConfig, tNonAuraListSlots, tNonAuraMaxSlots);

		VUHDO_applyNonAuraSecretSlotAlpha(aUnit, aPanelNum, anAnchorIndex, tNonAuraAnchorConfig, tNonAuraGroup, tNonAuraListSlots, tNonAuraMaxSlots, tNonAuraPanelUnitButtons);

		return;

	end
end



do
	--
	local tUpper;
	function VUHDO_filterContainsToken(aFilter, aToken)

		if not aFilter then
			return false;
		end

		for tToken in gmatch(aFilter, "[^|]+") do
			tUpper = strupper(tToken);

			if tUpper == aToken then
				return true;
			end
		end

		return false;

	end



	--
	local tFilter;
	function VUHDO_initAuraGroupFilters()

		for _, tGroup in pairs(VUHDO_DEFAULT_AURA_GROUPS or sEmpty) do
			tFilter = tGroup["filter"];

			if tFilter then
				tGroup["isHarmful"] = VUHDO_filterContainsToken(tFilter, "HARMFUL");
			end
		end

		for _, tGroup in pairs(VUHDO_AURA_GROUPS or sEmpty) do
			tFilter = tGroup["filter"];

			if tFilter then
				tGroup["isHarmful"] = VUHDO_filterContainsToken(tFilter, "HARMFUL");
			end
		end

		return;

	end



	--
	local tGroup;
	function VUHDO_getAuraGroupRaw(aGroupId)

		if not aGroupId then
			return nil;
		end

		tGroup = VUHDO_AURA_GROUPS[aGroupId];

		if not tGroup then
			tGroup = VUHDO_DEFAULT_AURA_GROUPS[aGroupId];
		end

		return tGroup;

	end



	--
	local tSourceUnit;
	local tIsMine;
	function VUHDO_auraSourceMatchesFilter(aCachedAura, aLayerInfos)

		if aLayerInfos["mine"] and aLayerInfos["others"] then
			return true;
		end

		tSourceUnit = aCachedAura["sourceUnit"];

		if issecretvalue(tSourceUnit) then
			return aLayerInfos["mine"] == true or aLayerInfos["others"] == true;
		end

		tIsMine = UnitIsUnit(tSourceUnit or "", "player");

		if aLayerInfos["mine"] and tIsMine then
			return true;
		end

		if aLayerInfos["others"] and not tIsMine then
			return true;
		end

		return false;

	end



	--
	local tGroup;
	local tIsBuiltIn;
	function VUHDO_getAuraGroup(aGroupId)

		if not aGroupId then
			return nil;
		end

		tGroup = VUHDO_AURA_GROUPS[aGroupId];
		tIsBuiltIn = false;

		if not tGroup then
			tGroup = VUHDO_DEFAULT_AURA_GROUPS[aGroupId];
			tIsBuiltIn = tGroup ~= nil;
		end

		if not tGroup then
			return nil;
		end

		if tGroup["enabled"] == false then
			return nil;
		end

		if tIsBuiltIn and VUHDO_CONFIG["AURA_GROUP_DISABLED"] and VUHDO_CONFIG["AURA_GROUP_DISABLED"][aGroupId] then
			return nil;
		end

		if tGroup["playerClassRequired"] and tGroup["playerClassRequired"] ~= VUHDO_PLAYER_CLASS then
			return nil;
		end

		return tGroup;

	end



	--
	local tUnitScope;
	local tIsHostile;
	function VUHDO_getAuraGroupEffectiveUnitScope(aGroup)

		if not aGroup then
			return VUHDO_AURA_GROUP_UNIT_SCOPE_BOTH;
		end

		return aGroup["unitScope"] or VUHDO_AURA_GROUP_UNIT_SCOPE_BOTH;

	end



	--
	function VUHDO_isAuraGroupInScopeForUnit(aGroup, aUnit)

		if not aGroup or not aUnit then
			return false;
		end

		tUnitScope = VUHDO_getAuraGroupEffectiveUnitScope(aGroup);

		if tUnitScope == VUHDO_AURA_GROUP_UNIT_SCOPE_BOTH then
			return true;
		end

		tIsHostile = UnitCanAttack("player", aUnit);

		if tUnitScope == VUHDO_AURA_GROUP_UNIT_SCOPE_FRIENDLY then
			return not tIsHostile;
		end

		return tIsHostile;

	end



	--
	local tGroup;
	function VUHDO_getAuraGroupForUnit(aGroupId, aUnit)

		tGroup = VUHDO_getAuraGroup(aGroupId);

		if not tGroup then
			return nil;
		end

		if not VUHDO_isAuraGroupInScopeForUnit(tGroup, aUnit) then
			return nil;
		end

		return tGroup;

	end



	--
	function VUHDO_isAuraGroupScopeFriendly(aUnitScope)

		tUnitScope = aUnitScope or VUHDO_AURA_GROUP_UNIT_SCOPE_BOTH;

		return tUnitScope == VUHDO_AURA_GROUP_UNIT_SCOPE_BOTH or tUnitScope == VUHDO_AURA_GROUP_UNIT_SCOPE_FRIENDLY;

	end



	--
	function VUHDO_isAuraGroupScopeHostile(aUnitScope)

		tUnitScope = aUnitScope or VUHDO_AURA_GROUP_UNIT_SCOPE_BOTH;

		return tUnitScope == VUHDO_AURA_GROUP_UNIT_SCOPE_BOTH or tUnitScope == VUHDO_AURA_GROUP_UNIT_SCOPE_HOSTILE;

	end



	--
	function VUHDO_applyAuraGroupScopeFlags(aEntry, aGroup)

		if not aEntry or not aGroup then
			return;
		end

		tUnitScope = VUHDO_getAuraGroupEffectiveUnitScope(aGroup);

		if tUnitScope == VUHDO_AURA_GROUP_UNIT_SCOPE_FRIENDLY then
			aEntry["friendlyOnly"] = true;
			aEntry["hostileOnly"] = nil;
		elseif tUnitScope == VUHDO_AURA_GROUP_UNIT_SCOPE_HOSTILE then
			aEntry["hostileOnly"] = true;
			aEntry["friendlyOnly"] = nil;
		else
			aEntry["friendlyOnly"] = nil;
			aEntry["hostileOnly"] = nil;
		end

		return;

	end



	--
	local tGroup;
	local tSpellId;
	local tName;
	local tIgnoreList;
	function VUHDO_isAuraIgnored(anAuraData, aGroupId)

		if not anAuraData or not aGroupId then
			return false;
		end

		tSpellId = anAuraData["spellId"];
		tName = anAuraData["name"];

		if tName ~= nil and issecretvalue(tName) then
			tName = nil;
		end

		if tSpellId and not issecretvalue(tSpellId) and VUHDO_AURA_IGNORE_LIST[tSpellId] then
			return true;
		end

		if tName and VUHDO_AURA_IGNORE_LIST[tName] then
			return true;
		end

		tGroup = VUHDO_getAuraGroupRaw(aGroupId);

		if not tGroup then
			return false;
		end

		tIgnoreList = tGroup["ignoreList"];

		if not tIgnoreList then
			return false;
		end

		if tSpellId and not issecretvalue(tSpellId) and (tIgnoreList[tSpellId] or tIgnoreList[tostring(tSpellId)]) then
			return true;
		end

		if tName and tIgnoreList[tName] then
			return true;
		end

		return false;

	end



	--
	local tSpellId;
	local tSpellName;
	function VUHDO_shouldCacheAura(aUnit, anAuraData)

		if not aUnit or not anAuraData then
			return false;
		end

		tSpellId = anAuraData["spellId"];
		tSpellName = anAuraData["name"];

		if (tSpellId and not issecretvalue(tSpellId) and VUHDO_ACTIVE_AURA_SPELLS[tSpellId]) or
			(tSpellName and not issecretvalue(tSpellName) and VUHDO_ACTIVE_AURA_SPELLS[tSpellName]) then
			return true;
		end

		if sHasActiveAuraFilters then
			return true;
		end

		return false;

	end
end



do
	--
	local tBouquet;
	local tName;
	local tSpellId;
	function VUHDO_activateAurasFromBouquet(aBouquetName)

		if not aBouquetName then
			return;
		end

		if not VUHDO_BOUQUETS or not VUHDO_BOUQUETS["STORED"] then
			return;
		end

		tBouquet = VUHDO_BOUQUETS["STORED"][aBouquetName];

		if not tBouquet then
			return;
		end

		if type(tBouquet) ~= "table" then
			VUHDO_BOUQUETS["STORED"][aBouquetName] = VUHDO_decompressIfCompressed(tBouquet);

			tBouquet = VUHDO_BOUQUETS["STORED"][aBouquetName];
		end

		if type(tBouquet) ~= "table" then
			return;
		end

		for _, tInfos in pairs(tBouquet) do
			tName = tInfos["name"];

			if not VUHDO_strempty(tName) and not (VUHDO_BOUQUET_BUFFS_SPECIAL and VUHDO_BOUQUET_BUFFS_SPECIAL[tName]) then
				VUHDO_ACTIVE_AURA_SPELLS[tName] = true;

				if not VUHDO_AURA_SPELL_TO_BOUQUETS[tName] then
					VUHDO_AURA_SPELL_TO_BOUQUETS[tName] = { };
				end

				VUHDO_AURA_SPELL_TO_BOUQUETS[tName][aBouquetName] = true;

				tSpellId = tonumber(tName);

				if tSpellId then
					VUHDO_ACTIVE_AURA_SPELLS[tSpellId] = true;

					if not VUHDO_AURA_SPELL_TO_BOUQUETS[tSpellId] then
						VUHDO_AURA_SPELL_TO_BOUQUETS[tSpellId] = { };
					end

					VUHDO_AURA_SPELL_TO_BOUQUETS[tSpellId][aBouquetName] = true;
				end
			end
		end

		return;

	end
end



do
	--
	local tAnchors;
	local tActiveGroupIds = { };
	local tSeenFilters = { };
	local tGroup;
	local tEffectiveColorType;
	local tValue;
	function VUHDO_rebuildActiveAuraCaches()

		twipe(VUHDO_ACTIVE_AURA_SPELLS);
		twipe(VUHDO_ACTIVE_AURA_FILTERS);
		twipe(VUHDO_AURA_SPELL_TO_BOUQUETS);

		twipe(tActiveGroupIds);
		twipe(tSeenFilters);

		for tPanelNum = 1, VUHDO_MAX_PANELS do
			if VUHDO_PANEL_MODELS and VUHDO_PANEL_MODELS[tPanelNum] then
				tAnchors = VUHDO_PANEL_SETUP and VUHDO_PANEL_SETUP[tPanelNum] and VUHDO_PANEL_SETUP[tPanelNum]["AURA_ANCHORS"];

				if tAnchors then
					for _, tAnchor in pairs(tAnchors) do
						if tAnchor["enabled"] ~= false and tAnchor["groupId"] then
							tActiveGroupIds[tAnchor["groupId"]] = true;
						end
					end
				end
			end
		end

		for tGroupId, tGroup in pairs(VUHDO_CONFIG["AURA_GROUPS"] or sEmpty) do
			if tGroup["enabled"] ~= false then
				tEffectiveColorType = tGroup["colorType"] or VUHDO_AURA_GROUP_COLOR_OFF;

				if tEffectiveColorType >= VUHDO_AURA_GROUP_COLOR_DISPEL or (tGroup["sound"] and tGroup["sound"] ~= "") then
					tActiveGroupIds[tGroupId] = true;
				end
			end
		end

		for tGroupId, tGroup in pairs(VUHDO_DEFAULT_AURA_GROUPS or sEmpty) do
			if not (VUHDO_CONFIG["AURA_GROUPS"] or sEmpty)[tGroupId] then
				if tGroup["enabled"] ~= false and not (VUHDO_CONFIG["AURA_GROUP_DISABLED"] and VUHDO_CONFIG["AURA_GROUP_DISABLED"][tGroupId]) then
					tEffectiveColorType = tGroup["colorType"] or VUHDO_AURA_GROUP_COLOR_OFF;

					if tEffectiveColorType >= VUHDO_AURA_GROUP_COLOR_DISPEL or (tGroup["sound"] and tGroup["sound"] ~= "") then
						tActiveGroupIds[tGroupId] = true;
					end
				end
			end
		end

		for tGroupId, _ in pairs(tActiveGroupIds) do
			tGroup = VUHDO_getAuraGroupRaw(tGroupId);

			if tGroup then
				if (tGroup["type"] or 1) == VUHDO_AURA_GROUP_TYPE_FILTER then
					if tGroup["filter"] and not tSeenFilters[tGroup["filter"]] then
						tSeenFilters[tGroup["filter"]] = true;

						tinsert(VUHDO_ACTIVE_AURA_FILTERS, tGroup["filter"]);
					end
				elseif tGroup["type"] == VUHDO_AURA_GROUP_TYPE_LIST and tGroup["entries"] then
					for _, tEntry in pairs(tGroup["entries"]) do
						if tEntry["entryType"] == VUHDO_AURA_LIST_ENTRY_SPELL then
							tValue = VUHDO_getAuraListEntryMatchValue(tEntry);

							if tValue then
								VUHDO_ACTIVE_AURA_SPELLS[tValue] = true;

								if type(tValue) == "number" then
									VUHDO_ACTIVE_AURA_SPELLS[tostring(tValue)] = true;
								end
							end
						elseif tEntry["entryType"] == VUHDO_AURA_LIST_ENTRY_BOUQUET then
							VUHDO_activateAurasFromBouquet(tEntry["value"]);
						end
					end
				end
			end
		end

		for tBouquetName, _ in pairs(VUHDO_getRegisteredBouquets()) do
			VUHDO_activateAurasFromBouquet(tBouquetName);
		end

		sHasActiveAuraFilters = #VUHDO_ACTIVE_AURA_FILTERS > 0;

		return;

	end
end



do
	--
	function VUHDO_isBuiltInAuraGroup(aGroupId)

		if not aGroupId then
			return false;
		end

		return VUHDO_DEFAULT_AURA_GROUPS[aGroupId] ~= nil;

	end



	--
	function VUHDO_generateAuraGroupId()

		return VUHDO_generateUUID("CUSTOM_", 12);

	end



	--
	local tDisplayName;
	local tGroup;
	function VUHDO_getAuraGroupDisplayName(aGroupId)

		if not aGroupId then
			return "";
		end

		tGroup = VUHDO_AURA_GROUPS[aGroupId];

		if tGroup and tGroup["displayName"] then
			return tGroup["displayName"];
		end

		tDisplayName = VUHDO_I18N_AURA_GROUP_NAMES[aGroupId];

		if tDisplayName then
			return tDisplayName;
		end

		return aGroupId;

	end



	--
	local tNewId;
	local tSourceGroup;
	local tNewGroup;
	function VUHDO_cloneAuraGroup(aSourceGroupId, aNewDisplayName)

		tSourceGroup = VUHDO_getAuraGroupRaw(aSourceGroupId);

		if not tSourceGroup then
			return nil;
		end

		tNewId = VUHDO_generateAuraGroupId();
		tNewGroup = VUHDO_deepCopyTable(tSourceGroup);

		tNewGroup["displayName"] = aNewDisplayName;
		tNewGroup["priority"] = VUHDO_getNextAuraGroupPriority();

		if VUHDO_isBuiltInAuraGroup(aSourceGroupId) and VUHDO_CONFIG["AURA_GROUP_DISABLED"] and VUHDO_CONFIG["AURA_GROUP_DISABLED"][aSourceGroupId] then
			tNewGroup["enabled"] = false;
		end

		VUHDO_AURA_GROUPS[tNewId] = tNewGroup;

		return tNewId;

	end



	--
	function VUHDO_getAllAuraGroups()

		twipe(sAllGroups);

		for tGroupId, tGroup in pairs(VUHDO_DEFAULT_AURA_GROUPS or _G["VUHDO_DEFAULT_AURA_GROUPS"] or sEmpty) do
			if not tGroup["playerClassRequired"] or tGroup["playerClassRequired"] == VUHDO_PLAYER_CLASS then
				sAllGroups[tGroupId] = tGroup;
			end
		end

		for tGroupId, tGroup in pairs(VUHDO_AURA_GROUPS or (_G["VUHDO_CONFIG"] and _G["VUHDO_CONFIG"]["AURA_GROUPS"]) or sEmpty) do
			sAllGroups[tGroupId] = tGroup;
		end

		return sAllGroups;

	end



	--
	local tCandidate;
	local tSuffix;
	local tAllGroups;
	local tFound;
	function VUHDO_ensureUniqueAuraGroupDisplayName(aBaseName)

		tCandidate = aBaseName;
		tSuffix = 0;

		tAllGroups = VUHDO_getAllAuraGroups();

		while true do
			tFound = false;

			for _, tGroup in pairs(tAllGroups or sEmpty) do
				if tGroup["displayName"] == tCandidate then
					tFound = true;

					tSuffix = tSuffix + 1;
					tCandidate = aBaseName .. " (" .. tSuffix .. ")";

					break;
				end
			end

			if not tFound then
				return tCandidate;
			end
		end

	end



	--
	local tAllGroups;
	local tMaxPriority;
	local tPriority;
	function VUHDO_getNextAuraGroupPriority()

		tAllGroups = VUHDO_getAllAuraGroups();

		tMaxPriority = 0;

		for _, tGroup in pairs(tAllGroups) do
			tPriority = tGroup["priority"] or 0;

			if tPriority > tMaxPriority then
				tMaxPriority = tPriority;
			end
		end

		return tMaxPriority + 1;

	end



	--
	local tLegacyBoolKey;
	local tLegacyMatchAnyBooleans;
	local tNormalizeCandidateBooleans;
	local tConditionsVersion;
	local tMatchAnyBooleanKeys;
	function VUHDO_migrateAuraGroupConditions(aGroup)

		if not aGroup then
			return;
		end

		tConditionsVersion = _G["VUHDO_AURA_GROUP_CONDITIONS_VERSION"];

		if aGroup["conditionsVersion"] == tConditionsVersion then
			return;
		end

		tMatchAnyBooleanKeys = _G["VUHDO_AURA_MATCH_ANY_BOOLEAN_KEYS"];
		tNormalizeCandidateBooleans = aGroup["candidateBooleans"];

		if tNormalizeCandidateBooleans then
			for tCnt = 1, #tMatchAnyBooleanKeys do
				tLegacyBoolKey = tMatchAnyBooleanKeys[tCnt];

				if tNormalizeCandidateBooleans[tLegacyBoolKey] == 1 then
					tLegacyMatchAnyBooleans = aGroup["matchAnyBooleans"];

					if not tLegacyMatchAnyBooleans then
						tLegacyMatchAnyBooleans = { };
						aGroup["matchAnyBooleans"] = tLegacyMatchAnyBooleans;
					end

					tLegacyMatchAnyBooleans[tLegacyBoolKey] = 1;
					tNormalizeCandidateBooleans[tLegacyBoolKey] = nil;
				end
			end

			if not next(tNormalizeCandidateBooleans) then
				aGroup["candidateBooleans"] = nil;
			end
		end

		aGroup["conditionsVersion"] = tConditionsVersion;

		return;

	end



	--
	local tFilter;
	local tNative;
	function VUHDO_resolveAuraGroupFilter(aGroup)

		if not aGroup then
			return;
		end

		VUHDO_migrateAuraGroupConditions(aGroup);

		tFilter = aGroup["filter"];

		if not tFilter then
			aGroup["resolvedFilter"] = nil;
			aGroup["dispellableOnly"] = nil;

			return;
		end

		if strfind(tFilter, "NOT_CANCELABLE", 1, true) then
			tFilter = gsub(tFilter, "NOT_CANCELABLE", "!CANCELABLE");
			aGroup["filter"] = tFilter;
		end

		if strfind(tFilter, "RAID_PLAYER_DISPELLABLE", 1, true) and strfind(tFilter, "|PLAYER", 1, true) then
			tFilter = gsub(tFilter, "|PLAYER", "");
			aGroup["filter"] = tFilter;
		end

		if strfind(tFilter, VUHDO_ALL_DISPELLABLE_TOKEN, 1, true) then
			tNative = gsub(tFilter, VUHDO_ALL_DISPELLABLE_TOKEN, "DISPELLABLE");

			if tNative == "DISPELLABLE" then
				tNative = "HARMFUL|DISPELLABLE";
			end

			aGroup["resolvedFilter"] = tNative;
		else
			tNative = tFilter;

			if strfind(tFilter, "RAID_PLAYER_DISPELLABLE", 1, true) and VUHDO_filterContainsToken(tFilter, "HARMFUL") then
				tNative = gsub(tFilter, "RAID_PLAYER_DISPELLABLE", "DISPELLABLE");
			end

			aGroup["resolvedFilter"] = tNative;
		end

		aGroup["dispellableOnly"] = nil;

		if strfind(tFilter, "RAID_PLAYER_DISPELLABLE", 1, true) then
			if VUHDO_filterContainsToken(tFilter, "HARMFUL") then
				aGroup["dispellableOnly"] = "harmful";
			elseif VUHDO_filterContainsToken(tFilter, "HELPFUL") then
				aGroup["dispellableOnly"] = "helpful";
			end
		end

		return;

	end



	--
	local tAuraGroups;
	function VUHDO_resolveAllAuraGroupFilters()

		for _, tGroup in pairs(VUHDO_DEFAULT_AURA_GROUPS or sEmpty) do
			VUHDO_resolveAuraGroupFilter(tGroup);
		end

		tAuraGroups = VUHDO_CONFIG and VUHDO_CONFIG["AURA_GROUPS"];

		for _, tGroup in pairs(tAuraGroups or sEmpty) do
			VUHDO_resolveAuraGroupFilter(tGroup);
		end

		return;

	end



	--
	local tAuras;
	function VUHDO_getFilteredAuras(aUnit, aFilter, aMaxCount, aSortRule, aSortDir)

		if not aUnit or not aFilter then
			return { };
		end

		if VUHDO_isAuraDataRestricted() then
			return sEmpty;
		end

		tAuras = GetUnitAuras(aUnit, aFilter, aMaxCount or 40, aSortRule or 0, aSortDir or 0);

		return tAuras or { };

	end



	--
	function VUHDO_auraMatchesFilter(aUnit, anAuraInstanceId, aFilter)

		if not aUnit or not anAuraInstanceId or not aFilter then
			return false;
		end

		if VUHDO_isAuraDataRestricted() then
			return false;
		end

		if anAuraInstanceId < 0 then
			return false;
		end

		if IsAuraFilteredOutByInstanceID(aUnit, anAuraInstanceId, aFilter) then
			return false;
		end

		return true;

	end



	--
	local tTriValue;
	function VUHDO_getTriStateBool(aConfig, aFieldName, aDefaultValue)

		tTriValue = aConfig and aConfig[aFieldName];

		if tTriValue == 1 then
			return true;
		elseif tTriValue == 3 then
			return false;
		else
			return aDefaultValue;
		end

	end



	--
	function VUHDO_getAnchorTriStateBool(anAnchorConfig, aFieldName, aDefaultValue)

		return VUHDO_getTriStateBool(anAnchorConfig, aFieldName, aDefaultValue);

	end



	--
	local tSpellId;
	local tFieldValue;
	local function VUHDO_getAuraConditionBool(anAuraData, aBoolKey)

		if aBoolKey == "isRoleAura" then
			if issecretvalue(anAuraData["isTankRoleAura"]) or issecretvalue(anAuraData["isHealerRoleAura"]) or issecretvalue(anAuraData["isDPSRoleAura"]) then
				return nil;
			end

			if AuraUtil.IsRoleAura(anAuraData) == true then
				return true;
			end

			return false;
		elseif aBoolKey == "isPriorityAura" then
			tSpellId = anAuraData["spellId"];

			if issecretvalue(tSpellId) then
				return nil;
			end

			if AuraUtil.IsPriorityDebuff(tSpellId) == true then
				return true;
			end

			return false;
		elseif aBoolKey == "isBossOrRoleAura" then
			if issecretvalue(anAuraData["isBossAura"]) then
				return nil;
			end

			if issecretvalue(anAuraData["isTankRoleAura"]) or issecretvalue(anAuraData["isHealerRoleAura"]) or issecretvalue(anAuraData["isDPSRoleAura"]) then
				return nil;
			end

			if anAuraData["isBossAura"] == true or AuraUtil.IsRoleAura(anAuraData) == true then
				return true;
			end

			return false;
		else
			tFieldValue = anAuraData[aBoolKey];

			if issecretvalue(tFieldValue) then
				return nil;
			end

			if tFieldValue == true then
				return true;
			end

			return false;
		end

	end



	--
	local tDispelTypes;
	local tDispelName;
	local tCandidateBooleans;
	local tBoolKey;
	local tResolvedBool;
	local tResolvedType;
	local tProcessAuraData;
	local tFullAuraData;
	local tAnyShowRequired;
	local tAnyShowMatched;
	local tBoolMatches;
	local tMatchAnyBooleans;
	local tMatchAnyFilters;
	local tFilterToken;
	local tBranchFilterString;
	local tMaxDuration;
	local tExcludeDispel;
	function VUHDO_isAuraMatchingGroupFilters(aUnit, aGroupId, aGroup, anAuraData)

		if not aGroup or not anAuraData then
			return false;
		end

		if aGroup["resolvedFilter"] and not VUHDO_auraMatchesFilter(aUnit, anAuraData["auraInstanceID"], aGroup["resolvedFilter"]) then
			return false;
		end

		if aGroup["excludeFilter"] and VUHDO_auraMatchesFilter(aUnit, anAuraData["auraInstanceID"], aGroup["excludeFilter"]) then
			return false;
		end

		if VUHDO_isAuraIgnored(anAuraData, aGroupId) then
			return false;
		end

		if aGroup["dispellableOnly"] == "harmful" then
			tDispelTypes = VUHDO_getPlayerDispelTypeNames();

			if next(tDispelTypes) ~= nil then
				tDispelName = anAuraData["dispelName"];

				if not tDispelName or not tDispelTypes[tDispelName] then
					return false;
				end
			end
		elseif aGroup["dispellableOnly"] == "helpful" then
			tDispelTypes = VUHDO_getPlayerPurgeDispelTypeNames();

			if next(tDispelTypes) ~= nil then
				tDispelName = anAuraData["dispelName"];

				if not tDispelName or not tDispelTypes[tDispelName] then
					return false;
				end
			end
		end

		tCandidateBooleans = aGroup["candidateBooleans"];
		tMatchAnyBooleans = aGroup["matchAnyBooleans"];
		tMatchAnyFilters = aGroup["matchAnyFilters"];

		tAnyShowRequired = false;
		tAnyShowMatched = false;

		if tCandidateBooleans then
			for tCnt = 1, #VUHDO_AURA_CONDITION_BOOLEAN_KEYS do
				tBoolKey = VUHDO_AURA_CONDITION_BOOLEAN_KEYS[tCnt];
				tResolvedBool = VUHDO_getTriStateBool(tCandidateBooleans, tBoolKey, nil);

				if tResolvedBool ~= nil then
					tBoolMatches = VUHDO_getAuraConditionBool(anAuraData, tBoolKey);

					if tBoolMatches == nil then
						return false;
					elseif tBoolMatches ~= tResolvedBool then
						return false;
					end
				end
			end
		end

		if tMatchAnyBooleans then
			for tCnt = 1, #VUHDO_AURA_CONDITION_BOOLEAN_KEYS do
				tBoolKey = VUHDO_AURA_CONDITION_BOOLEAN_KEYS[tCnt];

				if tMatchAnyBooleans[tBoolKey] == 1 then
					tAnyShowRequired = true;

					tBoolMatches = VUHDO_getAuraConditionBool(anAuraData, tBoolKey);

					if tBoolMatches == true then
						tAnyShowMatched = true;
					end
				end
			end
		end

		if tMatchAnyFilters and anAuraData["auraInstanceID"] then
			for tCnt = 1, #VUHDO_AURA_MATCH_ANY_FILTER_TOKEN_ORDER do
				tFilterToken = VUHDO_AURA_MATCH_ANY_FILTER_TOKEN_ORDER[tCnt];

				if tMatchAnyFilters[tFilterToken] == 1 then
					tAnyShowRequired = true;
					tBranchFilterString = (aGroup["resolvedFilter"] or aGroup["filter"] or "") .. "|" .. tFilterToken;

					if VUHDO_auraMatchesFilter(aUnit, anAuraData["auraInstanceID"], tBranchFilterString) then
						tAnyShowMatched = true;
					end
				end
			end
		end

		if tAnyShowRequired and not tAnyShowMatched then
			return false;
		end

		tExcludeDispel = aGroup["excludeDispelTypes"];

		if tExcludeDispel and tExcludeDispel[anAuraData["dispelName"]] then
			return false;
		end

		if aGroup["processedAuraType"] then
			tResolvedType = AuraUtil.AuraUpdateChangedType[aGroup["processedAuraType"]];

			if tResolvedType and tResolvedType ~= AuraUtil.AuraUpdateChangedType.None then
				tFullAuraData = anAuraData;

				if anAuraData["auraInstanceID"] then
					tFullAuraData = VUHDO_getAuraDataByInstanceId(aUnit, anAuraData["auraInstanceID"]) or anAuraData;
				end

				tProcessAuraData = sProcessAuraScratch;

				twipe(tProcessAuraData);

				for tKey, tValue in pairs(tFullAuraData) do
					tProcessAuraData[tKey] = tValue;
				end

				if AuraUtil.ProcessAura(tProcessAuraData, false, false, false, false) ~= tResolvedType then
					return false;
				end
			end
		end

		tMaxDuration = aGroup["maxDurationSeconds"];

		if tMaxDuration ~= nil then
			if tMaxDuration <= 0 then
				if anAuraData["duration"] == 0 then
					return false;
				end
			elseif anAuraData["duration"] > tMaxDuration or anAuraData["duration"] == 0 then
				return false;
			end
		elseif aGroup["hasDuration"] and anAuraData["duration"] == 0 then
			return false;
		end

		return true;

	end



	--
	local tAuraData;
	function VUHDO_getAuraDataByInstanceId(aUnit, anAuraInstanceId)

		if not aUnit or not anAuraInstanceId then
			return nil;
		end

		tAuraData = GetAuraDataByAuraInstanceID(aUnit, anAuraInstanceId);

		return tAuraData;

	end
end



do
	--
	local tUnitAuraSpell;
	local tInstanceIds;
	local tInstanceId;
	local tAuraInfo;
	local tAuraCache;
	local tNumSpellId;
	local tIsHarmful;
	local tIsHelpful;
	local function VUHDO_cachedAuraInfoMatchesFilter(aCachedInfo, aFilter)

		if not aCachedInfo then
			return false;
		end

		if not aFilter then
			return true;
		end

		if "HARMFUL" == aFilter then
			tIsHarmful = aCachedInfo["isHarmful"];

			if issecretvalue(tIsHarmful) then
				return false;
			end

			return tIsHarmful == true;
		end

		if "HELPFUL" == aFilter then
			tIsHelpful = aCachedInfo["isHelpful"];

			if issecretvalue(tIsHelpful) then
				return false;
			end

			return tIsHelpful == true;
		end

		return true;

	end



	--
	local tSourceUnit;
	local tIsMine;
	local function VUHDO_cachedAuraMatchesSourceType(aCachedInfo, aSourceType)

		if aSourceType == VUHDO_UNIT_AURA_SOURCE_BOTH then
			return true;
		end

		tSourceUnit = aCachedInfo["sourceUnit"];

		if issecretvalue(tSourceUnit) then
			if aSourceType == VUHDO_UNIT_AURA_SOURCE_OTHERS then
				return true;
			end

			return false;
		end

		tIsMine = UnitIsUnit(tSourceUnit or "", "player");

		if aSourceType == VUHDO_UNIT_AURA_SOURCE_MINE then
			return tIsMine;
		end

		if aSourceType == VUHDO_UNIT_AURA_SOURCE_OTHERS then
			return not tIsMine;
		end

		return true;

	end



	--
	function VUHDO_hasUnitAura(aUnit, aSpell, aFilter, aSourceType)

		if not aUnit or not aSpell then
			return false;
		end

		aSourceType = aSourceType or VUHDO_UNIT_AURA_SOURCE_MINE;

		tUnitAuraSpell = VUHDO_UNIT_AURA_BY_SPELL[aUnit];

		if not tUnitAuraSpell then
			return false;
		end

		tInstanceIds = tUnitAuraSpell[aSpell];

		if not tInstanceIds and type(aSpell) == "string" then
			tNumSpellId = tonumber(aSpell);

			if tNumSpellId then
				tInstanceIds = tUnitAuraSpell[tNumSpellId];
			end
		end

		if not tInstanceIds then
			return false;
		end

		tAuraCache = VUHDO_UNIT_AURA_CACHE[aUnit];

		if not tAuraCache then
			return false;
		end

		for tIdx = 1, #tInstanceIds do
			tInstanceId = tInstanceIds[tIdx];

			tAuraInfo = tAuraCache[tInstanceId];

			if tAuraInfo and VUHDO_cachedAuraInfoMatchesFilter(tAuraInfo, aFilter)
				and VUHDO_cachedAuraMatchesSourceType(tAuraInfo, aSourceType) then
				return true;
			end
		end

		return false;

	end



end



--
local tDefaults;
function VUHDO_resolveAuraTriState(anAnchorValue, aFieldName)

	if anAnchorValue == 1 then
		return true;
	elseif anAnchorValue == 3 then
		return false;
	end

	tDefaults = VUHDO_PANEL_SETUP and VUHDO_PANEL_SETUP["AURA_DEFAULTS"];

	if tDefaults and tDefaults[aFieldName] ~= nil then
		return tDefaults[aFieldName];
	end

	return VUHDO_DEFAULT_AURA_DEFAULTS[aFieldName];

end



do
	--
	local tCachedData;
	local tAuraInstanceId;
	local tSpellId;
	local tSpellName;
	function VUHDO_cacheAuraData(aUnit, anAuraData)

		if not aUnit or not anAuraData then
			return nil;
		end

		tAuraInstanceId = anAuraData["auraInstanceID"];

		if not tAuraInstanceId then
			return nil;
		end

		if not VUHDO_UNIT_AURA_CACHE[aUnit] then
			VUHDO_UNIT_AURA_CACHE[aUnit] = { };
		end

		tCachedData = sAuraDataPool:get();

		tCachedData["auraInstanceID"] = tAuraInstanceId;
		tCachedData["icon"] = anAuraData["icon"];
		tCachedData["name"] = anAuraData["name"];
		tCachedData["spellId"] = anAuraData["spellId"];
		tCachedData["applications"] = anAuraData["applications"];
		tCachedData["duration"] = anAuraData["duration"];
		tCachedData["expirationTime"] = anAuraData["expirationTime"];
		tCachedData["sourceUnit"] = anAuraData["sourceUnit"];
		tCachedData["isHarmful"] = anAuraData["isHarmful"];
		tCachedData["isHelpful"] = anAuraData["isHelpful"];
		tCachedData["dispelName"] = anAuraData["dispelName"];

		VUHDO_UNIT_AURA_CACHE[aUnit][tAuraInstanceId] = tCachedData;

		tSpellId = anAuraData["spellId"];

		if tSpellId and not issecretvalue(tSpellId) then
			if not VUHDO_UNIT_AURA_BY_SPELL[aUnit] then
				VUHDO_UNIT_AURA_BY_SPELL[aUnit] = { };
			end

			if not VUHDO_UNIT_AURA_BY_SPELL[aUnit][tSpellId] then
				VUHDO_UNIT_AURA_BY_SPELL[aUnit][tSpellId] = sReverseIndexArrayPool:get();
			end

			tinsert(VUHDO_UNIT_AURA_BY_SPELL[aUnit][tSpellId], tAuraInstanceId);

			tSpellName = anAuraData["name"];

			if tSpellName and not issecretvalue(tSpellName) then
				if not VUHDO_UNIT_AURA_BY_SPELL[aUnit][tSpellName] then
					VUHDO_UNIT_AURA_BY_SPELL[aUnit][tSpellName] = sReverseIndexArrayPool:get();
				end

				tinsert(VUHDO_UNIT_AURA_BY_SPELL[aUnit][tSpellName], tAuraInstanceId);
			end
		end

		return tCachedData;

	end
end



do
	--
	local tCachedData;
	local tSpellId;
	local tSpellName;
	local tBySpell;
	function VUHDO_uncacheAuraData(aUnit, anAuraInstanceId)

		if not aUnit or not anAuraInstanceId then
			return;
		end

		if not VUHDO_UNIT_AURA_CACHE[aUnit] then
			return;
		end

		tCachedData = VUHDO_UNIT_AURA_CACHE[aUnit][anAuraInstanceId];

		if tCachedData then
			tSpellId = tCachedData["spellId"];
			tSpellName = tCachedData["name"];

			if tSpellId and not issecretvalue(tSpellId) and VUHDO_UNIT_AURA_BY_SPELL[aUnit] then
				tBySpell = VUHDO_UNIT_AURA_BY_SPELL[aUnit][tSpellId];

				if tBySpell then
					for tIdx = #tBySpell, 1, -1 do
						if tBySpell[tIdx] == anAuraInstanceId then
							tremove(tBySpell, tIdx);

							break;
						end
					end

					if #tBySpell == 0 then
						sReverseIndexArrayPool:release(tBySpell);
						VUHDO_UNIT_AURA_BY_SPELL[aUnit][tSpellId] = nil;
					end
				end
			end

			if tSpellName and not issecretvalue(tSpellName) and VUHDO_UNIT_AURA_BY_SPELL[aUnit] then
				tBySpell = VUHDO_UNIT_AURA_BY_SPELL[aUnit][tSpellName];

				if tBySpell then
					for tIdx = #tBySpell, 1, -1 do
						if tBySpell[tIdx] == anAuraInstanceId then
							tremove(tBySpell, tIdx);

							break;
						end
					end

					if #tBySpell == 0 then
						sReverseIndexArrayPool:release(tBySpell);
						VUHDO_UNIT_AURA_BY_SPELL[aUnit][tSpellName] = nil;
					end
				end
			end

			sAuraDataPool:release(tCachedData);

			VUHDO_UNIT_AURA_CACHE[aUnit][anAuraInstanceId] = nil;
		end

		return;

	end
end



--
local tUnitCache;
local tUnitSlots;
local tListPanels;
function VUHDO_clearUnitAuraCache(aUnit)

	if not aUnit then
		return;
	end

	tUnitCache = VUHDO_UNIT_AURA_CACHE[aUnit];

	if tUnitCache then
		for tInstanceId, tCachedData in pairs(tUnitCache) do
			sAuraDataPool:release(tCachedData);
			tUnitCache[tInstanceId] = nil;
		end
	end

	tUnitSlots = VUHDO_UNIT_AURA_SLOT_INDEX[aUnit];

	if tUnitSlots then
		for tInstanceId, tAuraIndex in pairs(tUnitSlots) do
			for tPanelNum, tPanelIndex in pairs(tAuraIndex) do
				sSlotIndexPool:release(tPanelIndex);
			end

			sSlotIndexPool:release(tAuraIndex);
			tUnitSlots[tInstanceId] = nil;
		end
	end

	if VUHDO_UNIT_AURA_SLOTS[aUnit] then
		for tPanelNum, tPanelSlots in pairs(VUHDO_UNIT_AURA_SLOTS[aUnit]) do
			for tAnchorIndex, tAnchorSlots in pairs(tPanelSlots) do
				twipe(tAnchorSlots);
			end
		end
	end

	if VUHDO_UNIT_AURA_BY_SPELL[aUnit] then
		for tBySpellKey, tBySpellArray in pairs(VUHDO_UNIT_AURA_BY_SPELL[aUnit]) do
			sReverseIndexArrayPool:release(tBySpellArray);
		end

		VUHDO_UNIT_AURA_BY_SPELL[aUnit] = nil;
	end

	if VUHDO_UNIT_AURA_LIST_SLOTS[aUnit] then
		tListPanels = VUHDO_UNIT_AURA_LIST_SLOTS[aUnit];

		for tPanelNum, tListAnchors in pairs(tListPanels) do
			for tAnchorIndex, tAnchorList in pairs(tListAnchors) do
				for tEntryIndex, tSlotData in pairs(tAnchorList) do
					if tSlotData then
						sSlotDataPool:release(tSlotData);
					end
				end
			end
		end

		VUHDO_UNIT_AURA_LIST_SLOTS[aUnit] = nil;
	end

	VUHDO_clearUnitBouquetActiveCache(aUnit);

	return;

end



--
function VUHDO_clearAllAuraCaches()

	for tUnit, _ in pairs(VUHDO_UNIT_AURA_CACHE) do
		VUHDO_clearUnitAuraCache(tUnit);
	end

	return;

end



--
local tDegradeInfo;
function VUHDO_degradeAuraCacheForUnit(aUnit)

	if not aUnit then
		return;
	end

	tDegradeInfo = VUHDO_RAID and VUHDO_RAID[aUnit];

	if tDegradeInfo then
		tDegradeInfo["debuff"], tDegradeInfo["debuffName"] = VUHDO_determineAura(aUnit);

		if not VUHDO_isAuraModeContainers() then
			tDegradeInfo["charmed"] = nil;
		end
	end

	return;

end



--
function VUHDO_refreshAllUnitAuras()

	if not VUHDO_RAID then
		return;
	end

	for tUnit, _ in pairs(VUHDO_RAID) do
		VUHDO_fullAuraRefresh(tUnit);
	end

	return;

end



--
local tPanelAnchors;
function VUHDO_initUnitAuraSlots(aUnit)

	if not aUnit then
		return;
	end

	if not VUHDO_UNIT_AURA_SLOTS[aUnit] then
		VUHDO_UNIT_AURA_SLOTS[aUnit] = { };
	end

	if not VUHDO_UNIT_AURA_SLOT_INDEX[aUnit] then
		VUHDO_UNIT_AURA_SLOT_INDEX[aUnit] = { };
	end

	if not VUHDO_UNIT_AURA_CACHE[aUnit] then
		VUHDO_UNIT_AURA_CACHE[aUnit] = { };
	end

	if not VUHDO_UNIT_AURA_LIST_SLOTS[aUnit] then
		VUHDO_UNIT_AURA_LIST_SLOTS[aUnit] = { };
	end

	for tPanelNum = 1, VUHDO_MAX_PANELS do
		if not VUHDO_UNIT_AURA_SLOTS[aUnit][tPanelNum] then
			VUHDO_UNIT_AURA_SLOTS[aUnit][tPanelNum] = { };
		end

		if not VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][tPanelNum] then
			VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][tPanelNum] = { };
		end

		tPanelAnchors = VUHDO_PANEL_SETUP[tPanelNum] and VUHDO_PANEL_SETUP[tPanelNum]["AURA_ANCHORS"];

		if tPanelAnchors then
			for tAnchorKey, _ in pairs(tPanelAnchors) do
				if not VUHDO_UNIT_AURA_SLOTS[aUnit][tPanelNum][tAnchorKey] then
					VUHDO_UNIT_AURA_SLOTS[aUnit][tPanelNum][tAnchorKey] = { };
				end

				if not VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][tPanelNum][tAnchorKey] then
					VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][tPanelNum][tAnchorKey] = { };
				end
			end
		end
	end

	return;

end



--
function VUHDO_initSpecialUnitAuraSlots()

	if VUHDO_isAuraModeContainers() then
		return;
	end

	for _, tUnit in ipairs(sSpecialAuraUnits) do
		VUHDO_initUnitAuraSlots(tUnit);
	end

	return;

end



--
local tOldAuraId;
local tAuraIndex;
local tPanelIndex;
function VUHDO_setAnchorSlotAuraId(aUnit, aPanelNum, anAnchorIndex, aSlotIndex, anAuraInstanceId)

	if not aUnit or not aPanelNum or not anAnchorIndex or not aSlotIndex then
		return;
	end

	if not VUHDO_UNIT_AURA_SLOTS[aUnit] or not VUHDO_UNIT_AURA_SLOTS[aUnit][aPanelNum] or not VUHDO_UNIT_AURA_SLOTS[aUnit][aPanelNum][anAnchorIndex] then
		return;
	end

	tOldAuraId = VUHDO_UNIT_AURA_SLOTS[aUnit][aPanelNum][anAnchorIndex][aSlotIndex];

	if tOldAuraId and tOldAuraId ~= anAuraInstanceId then
		tAuraIndex = VUHDO_UNIT_AURA_SLOT_INDEX[aUnit][tOldAuraId];

		if tAuraIndex then
			tPanelIndex = tAuraIndex[aPanelNum];

			if tPanelIndex then
				tPanelIndex[anAnchorIndex] = nil;

				if not next(tPanelIndex) then
					tAuraIndex[aPanelNum] = nil;
				end
			end

			if not next(tAuraIndex) then
				VUHDO_UNIT_AURA_SLOT_INDEX[aUnit][tOldAuraId] = nil;
			end
		end
	end

	VUHDO_UNIT_AURA_SLOTS[aUnit][aPanelNum][anAnchorIndex][aSlotIndex] = anAuraInstanceId;

	if anAuraInstanceId then
		if not VUHDO_UNIT_AURA_SLOT_INDEX[aUnit][anAuraInstanceId] then
			VUHDO_UNIT_AURA_SLOT_INDEX[aUnit][anAuraInstanceId] = sSlotIndexPool:get();
		end

		if not VUHDO_UNIT_AURA_SLOT_INDEX[aUnit][anAuraInstanceId][aPanelNum] then
			VUHDO_UNIT_AURA_SLOT_INDEX[aUnit][anAuraInstanceId][aPanelNum] = sSlotIndexPool:get();
		end

		VUHDO_UNIT_AURA_SLOT_INDEX[aUnit][anAuraInstanceId][aPanelNum][anAnchorIndex] = aSlotIndex;
	end

	return;

end



--
local tAuraIndex;
function VUHDO_findAllAnchorSlotsByAuraId(aUnit, anAuraInstanceId)

	if not aUnit or not anAuraInstanceId then
		return nil;
	end

	if not VUHDO_UNIT_AURA_SLOT_INDEX[aUnit] then
		return nil;
	end

	tAuraIndex = VUHDO_UNIT_AURA_SLOT_INDEX[aUnit][anAuraInstanceId];

	if not tAuraIndex or not next(tAuraIndex) then
		return nil;
	end

	return tAuraIndex;

end



--
local function VUHDO_markPendingListAnchor(aPanelNum, anAnchorIndex, anAnchorConfig)

	if not aPanelNum or not anAnchorIndex then
		return;
	end

	if not sPendingListAnchors[aPanelNum] then
		sPendingListAnchors[aPanelNum] = { };
	end

	sPendingListAnchors[aPanelNum][anAnchorIndex] = anAnchorConfig;

	return;

end



--
function VUHDO_refreshListSlotsForAnchor(aUnit, aPanelNum, anAnchorIndex, anAnchorConfig)

	if sIsBatchingListAnchors then
		VUHDO_markPendingListAnchor(aPanelNum, anAnchorIndex, anAnchorConfig);

		return;
	end

	VUHDO_updateListSlotsForAnchor(aUnit, aPanelNum, anAnchorIndex, anAnchorConfig);

	return;

end



--
local function VUHDO_drainPendingListAnchors(aUnit)

	if not aUnit then
		return;
	end

	for tPanelNum, tAnchorMap in pairs(sPendingListAnchors) do
		for tAnchorIndex, tAnchorConfig in pairs(tAnchorMap) do
			VUHDO_updateListSlotsForAnchor(aUnit, tPanelNum, tAnchorIndex, tAnchorConfig);
		end

		twipe(tAnchorMap);
	end

	return;

end



--
local tInfo;
function VUHDO_onUnitAura(aUnit, aUpdateInfo)

	if not aUnit then
		return;
	end

	tInfo = (VUHDO_RAID or sEmpty)[aUnit];

	if not tInfo then
		return;
	end

	if VUHDO_isAuraModeContainers() then
		if not VUHDO_needsUnitAuraEvent() then
			return;
		end

		if VUHDO_shouldDropRestrictedAuraEvent(aUpdateInfo) then
			return;
		end

		tInfo["debuff"], tInfo["debuffName"] = VUHDO_determineAura(aUnit, aUpdateInfo);

		if aUpdateInfo and aUpdateInfo["addedAuras"] then
			for _, tAura in pairs(aUpdateInfo["addedAuras"]) do
				VUHDO_checkAuraGroupSounds(aUnit, tAura);
			end
		end

		return;
	end

	if VUHDO_shouldDropRestrictedAuraEvent(aUpdateInfo) then
		return;
	end

	if not aUpdateInfo or aUpdateInfo["isFullUpdate"] then
		VUHDO_fullAuraRefresh(aUnit);

		return;
	else
		VUHDO_incrementalAuraUpdate(aUnit, aUpdateInfo);
	end

	tInfo["debuff"], tInfo["debuffName"] = VUHDO_determineAura(aUnit, aUpdateInfo);

	return;

end



--
local tAuras;
function VUHDO_fullAuraRefresh(aUnit)

	if not aUnit then
		return;
	end

	if VUHDO_isAuraModeContainers() then
		return;
	end

	if VUHDO_shouldDropRestrictedAuraEvent(nil) then
		return;
	end

	VUHDO_clearUnitAuraCache(aUnit);
	VUHDO_initUnitAuraSlots(aUnit);

	tAuras = GetUnitAuras(aUnit, "HELPFUL", 40, 0, 0);

	if tAuras then
		for _, tAura in pairs(tAuras) do
			if VUHDO_shouldCacheAura(aUnit, tAura) then
				VUHDO_cacheAuraData(aUnit, tAura);
			end
		end
	end

	tAuras = GetUnitAuras(aUnit, "HARMFUL", 40, 0, 0);

	if tAuras then
		for _, tAura in pairs(tAuras) do
			if VUHDO_shouldCacheAura(aUnit, tAura) then
				VUHDO_cacheAuraData(aUnit, tAura);
			end
		end
	end

	if VUHDO_UNIT_BUTTONS_PANEL[aUnit] then
		for tPanelNum, _ in pairs(VUHDO_UNIT_BUTTONS_PANEL[aUnit]) do
			VUHDO_rebuildSlotAssignmentsForPanel(aUnit, tPanelNum);
		end
	end

	VUHDO_refreshListBouquetsForUnit(aUnit);

	VUHDO_updateAuraDisplaysForUnit(aUnit);

	tInfo = (VUHDO_RAID or sEmpty)[aUnit];

	if tInfo then
		tInfo["debuff"], tInfo["debuffName"] = VUHDO_determineAura(aUnit);

		VUHDO_updateHealthBarsFor(aUnit, VUHDO_UPDATE_DEBUFF);
	end

	return;

end



--
local tBouquetsForSpell;
function VUHDO_updateBouquetsForSpell(aUnit, aSpellId, aSpellName)

	if not aUnit then
		return;
	end

	if aSpellId and not issecretvalue(aSpellId) then
		tBouquetsForSpell = VUHDO_AURA_SPELL_TO_BOUQUETS[aSpellId];

		if tBouquetsForSpell then
			for tBouquetName, _ in pairs(tBouquetsForSpell) do
				VUHDO_updateEventBouquet(aUnit, tBouquetName, 4);
			end
		end
	end

	if aSpellName and not issecretvalue(aSpellName) and aSpellName ~= aSpellId then
		tBouquetsForSpell = VUHDO_AURA_SPELL_TO_BOUQUETS[aSpellName];

		if tBouquetsForSpell then
			for tBouquetName, _ in pairs(tBouquetsForSpell) do
				VUHDO_updateEventBouquet(aUnit, tBouquetName, 4);
			end
		end
	end

	return;

end



do
	--
	local tAura;
	local tCachedData;
	local tPanelAnchors;
	local tGroup;
	function VUHDO_incrementalAuraUpdate(aUnit, aUpdateInfo)

		if not aUnit or not aUpdateInfo then
			return;
		end

		if VUHDO_isAuraModeContainers() then
			return;
		end

		twipe(sPendingListAnchors);
		sIsBatchingListAnchors = true;

		if aUpdateInfo["addedAuras"] then
			for _, tAura in pairs(aUpdateInfo["addedAuras"]) do
				if VUHDO_shouldCacheAura(aUnit, tAura) then
					VUHDO_cacheAuraData(aUnit, tAura);

					VUHDO_onAuraAdded(aUnit, tAura);
				end
			end
		end

		if aUpdateInfo["updatedAuraInstanceIDs"] then
			for _, tAuraInstanceId in pairs(aUpdateInfo["updatedAuraInstanceIDs"]) do
				tCachedData = VUHDO_UNIT_AURA_CACHE[aUnit] and VUHDO_UNIT_AURA_CACHE[aUnit][tAuraInstanceId];

				tAura = VUHDO_getAuraDataByInstanceId(aUnit, tAuraInstanceId);

				if tCachedData and tAura then
					tCachedData["applications"] = tAura["applications"];
					tCachedData["duration"] = tAura["duration"];
					tCachedData["expirationTime"] = tAura["expirationTime"];
					tCachedData["icon"] = tAura["icon"];
				end

				if tAura then
					VUHDO_onAuraUpdated(aUnit, tAura);
				end
			end
		end

		if aUpdateInfo["removedAuraInstanceIDs"] then
			for _, tAuraInstanceId in pairs(aUpdateInfo["removedAuraInstanceIDs"]) do
				tCachedData = VUHDO_UNIT_AURA_CACHE[aUnit] and VUHDO_UNIT_AURA_CACHE[aUnit][tAuraInstanceId];

				VUHDO_uncacheAuraData(aUnit, tAuraInstanceId);

				VUHDO_onAuraRemoved(aUnit, tAuraInstanceId, tCachedData and tCachedData["spellId"], tCachedData and tCachedData["name"]);
			end
		end

		sIsBatchingListAnchors = false;

		VUHDO_drainPendingListAnchors(aUnit);

		VUHDO_updateAuraDisplaysForUnit(aUnit);

		return;

	end



	--
	function VUHDO_onAuraAdded(aUnit, anAuraData)

		if not aUnit or not anAuraData then
			return;
		end

		VUHDO_checkAuraGroupSounds(aUnit, anAuraData);

		if VUHDO_UNIT_BUTTONS_PANEL[aUnit] then
			for tPanelNum, _ in pairs(VUHDO_UNIT_BUTTONS_PANEL[aUnit]) do
				if VUHDO_PANEL_MODELS[tPanelNum] then
					VUHDO_checkAuraForPanelAnchors(aUnit, tPanelNum, anAuraData);
				end
			end
		end

		VUHDO_updateBouquetsForSpell(aUnit, anAuraData["spellId"], anAuraData["name"]);

		return;

	end



	--
	function VUHDO_onAuraUpdated(aUnit, anAuraData)

		if not aUnit or not anAuraData then
			return;
		end

		if VUHDO_UNIT_BUTTONS_PANEL[aUnit] then
			for tPanelNum, _ in pairs(VUHDO_UNIT_BUTTONS_PANEL[aUnit]) do
				if VUHDO_PANEL_MODELS[tPanelNum] then
					tPanelAnchors = VUHDO_PANEL_SETUP[tPanelNum] and VUHDO_PANEL_SETUP[tPanelNum]["AURA_ANCHORS"];

					if tPanelAnchors then
						for tAnchorIndex, tAnchorConfig in pairs(tPanelAnchors) do
							if tAnchorConfig["enabled"] ~= false then
								tGroup = VUHDO_getAuraGroupRaw(tAnchorConfig["groupId"]);

								if tGroup and tGroup["type"] == VUHDO_AURA_GROUP_TYPE_LIST then
									VUHDO_refreshListSlotsForAnchor(aUnit, tPanelNum, tAnchorIndex, tAnchorConfig);
								end
							end
						end
					end
				end
			end
		end

		return;

	end
end



do
	--
	local tPanelNum;
	local tAuraIndex;
	local tAnchorIndex;
	local tSlotIndex;
	local tIdx;
	local tPanelAnchorsRemove;
	local tGroupRemove;
	function VUHDO_onAuraRemoved(aUnit, anAuraInstanceId, aSpellId, aSpellName)

		if not aUnit or not anAuraInstanceId then
			return;
		end

		tAuraIndex = VUHDO_findAllAnchorSlotsByAuraId(aUnit, anAuraInstanceId);

		if tAuraIndex then
			twipe(sSlotsToClear);
			sSlotsToClearCount = 0;

			for tPanelNum, tPanelIndex in pairs(tAuraIndex) do
				for tAnchorIndex, tSlotIndex in pairs(tPanelIndex) do
					sSlotsToClearCount = sSlotsToClearCount + 1;
					tIdx = sSlotsToClearCount * 3;

					sSlotsToClear[tIdx - 2] = tPanelNum;
					sSlotsToClear[tIdx - 1] = tAnchorIndex;
					sSlotsToClear[tIdx] = tSlotIndex;
				end
			end

			for tIdx = 1, sSlotsToClearCount do
				tPanelNum = sSlotsToClear[tIdx * 3 - 2];
				tAnchorIndex = sSlotsToClear[tIdx * 3 - 1];
				tSlotIndex = sSlotsToClear[tIdx * 3];

				VUHDO_setAnchorSlotAuraId(aUnit, tPanelNum, tAnchorIndex, tSlotIndex, nil);

				VUHDO_refillAnchorSlots(aUnit, tPanelNum, tAnchorIndex);
			end
		end

		if VUHDO_UNIT_BUTTONS_PANEL[aUnit] then
			for tPanelNum, _ in pairs(VUHDO_UNIT_BUTTONS_PANEL[aUnit]) do
				if VUHDO_PANEL_MODELS[tPanelNum] then
					tPanelAnchorsRemove = VUHDO_PANEL_SETUP[tPanelNum] and VUHDO_PANEL_SETUP[tPanelNum]["AURA_ANCHORS"];

					if tPanelAnchorsRemove then
						for tAnchorIndex, tAnchorConfigRemove in pairs(tPanelAnchorsRemove) do
							if tAnchorConfigRemove["enabled"] ~= false then
								tGroupRemove = VUHDO_getAuraGroup(tAnchorConfigRemove["groupId"]);

								if tGroupRemove and (tGroupRemove["type"] or 1) == VUHDO_AURA_GROUP_TYPE_LIST then
									VUHDO_refreshListSlotsForAnchor(aUnit, tPanelNum, tAnchorIndex, tAnchorConfigRemove);
								end
							end
						end
					end
				end
			end
		end

		if aSpellId then
			VUHDO_updateBouquetsForSpell(aUnit, aSpellId, aSpellName);
		end

		return;

	end
end



do
	--
	local tPanelAnchors;
	local tGroup;
	function VUHDO_checkAuraForPanelAnchors(aUnit, aPanelNum, anAuraData)

		if not aUnit or not aPanelNum or not anAuraData then
			return;
		end

		tPanelAnchors = VUHDO_PANEL_SETUP[aPanelNum] and VUHDO_PANEL_SETUP[aPanelNum]["AURA_ANCHORS"];

		if not tPanelAnchors then
			return;
		end

		for tAnchorIndex, tAnchorConfig in pairs(tPanelAnchors) do
			if tAnchorConfig["enabled"] ~= false then
				tGroup = VUHDO_getAuraGroupForUnit(tAnchorConfig["groupId"], aUnit);

				if tGroup then
					if tGroup["type"] == VUHDO_AURA_GROUP_TYPE_LIST then
						VUHDO_refreshListSlotsForAnchor(aUnit, aPanelNum, tAnchorIndex, tAnchorConfig);
					elseif VUHDO_isAuraMatchingGroupFilters(aUnit, tAnchorConfig["groupId"], tGroup, anAuraData) then
						VUHDO_tryAddAuraToAnchor(aUnit, aPanelNum, tAnchorIndex, tAnchorConfig, anAuraData);
					end
				end
			end
		end

		return;

	end
end



do
	--
	local tAnchorSlots;
	local tMaxSlots;
	local tOccupied;
	function VUHDO_tryAddAuraToAnchor(aUnit, aPanelNum, anAnchorIndex, anAnchorConfig, anAuraData)

		if not aUnit or not aPanelNum or not anAnchorIndex or not anAnchorConfig or not anAuraData then
			return;
		end

		tMaxSlots = anAnchorConfig["maxDisplay"] or 5;
		tAnchorSlots = VUHDO_UNIT_AURA_SLOTS[aUnit] and VUHDO_UNIT_AURA_SLOTS[aUnit][aPanelNum] and VUHDO_UNIT_AURA_SLOTS[aUnit][aPanelNum][anAnchorIndex];

		for tSlotIndex = 1, tMaxSlots do
			tOccupied = (tAnchorSlots and tAnchorSlots[tSlotIndex]);

			if not tOccupied then
				VUHDO_setAnchorSlotAuraId(aUnit, aPanelNum, anAnchorIndex, tSlotIndex, anAuraData["auraInstanceID"]);

				break;
			end
		end

		return;

	end
end



do
	--
	local tAnchorConfig;
	function VUHDO_refillAnchorSlots(aUnit, aPanelNum, anAnchorIndex)

		if not aUnit or not aPanelNum or not anAnchorIndex then
			return;
		end

		tAnchorConfig = VUHDO_PANEL_SETUP[aPanelNum] and VUHDO_PANEL_SETUP[aPanelNum]["AURA_ANCHORS"] and VUHDO_PANEL_SETUP[aPanelNum]["AURA_ANCHORS"][anAnchorIndex];

		if tAnchorConfig then
			VUHDO_rebuildSlotAssignmentsForAnchor(aUnit, aPanelNum, anAnchorIndex, tAnchorConfig);
		end

		return;

	end
end



--
local tPanelAnchors;
function VUHDO_rebuildSlotAssignmentsForPanel(aUnit, aPanelNum)

	if not aUnit or not aPanelNum then
		return;
	end

	tPanelAnchors = VUHDO_PANEL_SETUP[aPanelNum] and VUHDO_PANEL_SETUP[aPanelNum]["AURA_ANCHORS"];

	if not tPanelAnchors then
		return;
	end

	for tAnchorIndex, tAnchorConfig in pairs(tPanelAnchors) do
		if tAnchorConfig["enabled"] ~= false then
			VUHDO_rebuildSlotAssignmentsForAnchor(aUnit, aPanelNum, tAnchorIndex, tAnchorConfig);
		end
	end

	return;

end



--
local tGroup;
local tUnitCache;
local tSlotIndex;
local tMaxSlots;
local tAnchorSlots;
local tInstanceId;
local tInferredAura;
function VUHDO_rebuildSlotAssignmentsForAnchor(aUnit, aPanelNum, anAnchorIndex, anAnchorConfig)

	if not aUnit or not aPanelNum or not anAnchorIndex or not anAnchorConfig then
		return;
	end

	tGroup = VUHDO_getAuraGroupForUnit(anAnchorConfig["groupId"], aUnit);

	if not tGroup then
		return;
	end

	if (tGroup["type"] or 1) == VUHDO_AURA_GROUP_TYPE_LIST then
		VUHDO_refreshListSlotsForAnchor(aUnit, aPanelNum, anAnchorIndex, anAnchorConfig);

		return;
	end

	tMaxSlots = anAnchorConfig["maxDisplay"] or 5;
	tUnitCache = VUHDO_UNIT_AURA_CACHE[aUnit];

	if tGroup["isInferred"] then
		for tClearIdx = 1, tMaxSlots do
			VUHDO_setAnchorSlotAuraId(aUnit, aPanelNum, anAnchorIndex, tClearIdx, nil);
		end

		tInferredAura = VUHDO_getInferredAura(aUnit, anAnchorConfig["groupId"]);

		if tInferredAura then
			VUHDO_setAnchorSlotAuraId(aUnit, aPanelNum, anAnchorIndex, 1, tInferredAura["auraInstanceID"]);
		end

		return;
	end

	if anAnchorConfig["fixedSlots"] then
		tAnchorSlots = VUHDO_UNIT_AURA_SLOTS[aUnit] and VUHDO_UNIT_AURA_SLOTS[aUnit][aPanelNum] and VUHDO_UNIT_AURA_SLOTS[aUnit][aPanelNum][anAnchorIndex];

		twipe(sAssignedAuras);

		if tAnchorSlots then
			for tSlotIdx = 1, tMaxSlots do
				tInstanceId = tAnchorSlots[tSlotIdx];

				if tInstanceId then
					if tUnitCache and tUnitCache[tInstanceId] then
						if VUHDO_isAuraMatchingGroupFilters(aUnit, anAnchorConfig["groupId"], tGroup, tUnitCache[tInstanceId]) then
							sAssignedAuras[tInstanceId] = true;
						else
							VUHDO_setAnchorSlotAuraId(aUnit, aPanelNum, anAnchorIndex, tSlotIdx, nil);
						end
					else
						VUHDO_setAnchorSlotAuraId(aUnit, aPanelNum, anAnchorIndex, tSlotIdx, nil);
					end
				else
					VUHDO_setAnchorSlotAuraId(aUnit, aPanelNum, anAnchorIndex, tSlotIdx, nil);
				end
			end
		end

		if tUnitCache then
			for tInstanceId, tAuraData in pairs(tUnitCache) do
				if not sAssignedAuras[tInstanceId] then
					if VUHDO_isAuraMatchingGroupFilters(aUnit, anAnchorConfig["groupId"], tGroup, tAuraData) then
						for tSlotIdx = 1, tMaxSlots do
							tAnchorSlots = VUHDO_UNIT_AURA_SLOTS[aUnit] and VUHDO_UNIT_AURA_SLOTS[aUnit][aPanelNum] and VUHDO_UNIT_AURA_SLOTS[aUnit][aPanelNum][anAnchorIndex];

							if not (tAnchorSlots and tAnchorSlots[tSlotIdx]) then
								VUHDO_setAnchorSlotAuraId(aUnit, aPanelNum, anAnchorIndex, tSlotIdx, tInstanceId);

								sAssignedAuras[tInstanceId] = true;

								break;
							end
						end
					end
				end
			end
		end
	else
		tSlotIndex = 0;

		for tClearIdx = 1, tMaxSlots do
			VUHDO_setAnchorSlotAuraId(aUnit, aPanelNum, anAnchorIndex, tClearIdx, nil);
		end

		if tUnitCache then
			for tInstanceId, tAuraData in pairs(tUnitCache) do
				if VUHDO_isAuraMatchingGroupFilters(aUnit, anAnchorConfig["groupId"], tGroup, tAuraData) then
					tSlotIndex = tSlotIndex + 1;

					if tSlotIndex <= tMaxSlots then
						VUHDO_setAnchorSlotAuraId(aUnit, aPanelNum, anAnchorIndex, tSlotIndex, tInstanceId);
					end
				end
			end
		end
	end

	return;

end



do
	--
	local tGroup;
	local tEntries;
	local tLookupKey;
	local tAuraInstances;
	local tCachedAura;
	local tSlotData;
	local tOldSlot;
	local tEntryCount;
	function VUHDO_updateListSlotsForAnchor(aUnit, aPanelNum, anAnchorIndex, anAnchorConfig)

		if not aUnit or not aPanelNum or not anAnchorIndex or not anAnchorConfig then
			return;
		end

		tGroup = VUHDO_getAuraGroup(anAnchorConfig["groupId"]);

		if not tGroup then
			return;
		end

		if (tGroup["type"] or 1) ~= VUHDO_AURA_GROUP_TYPE_LIST then
			return;
		end

		if not VUHDO_isAuraGroupInScopeForUnit(tGroup, aUnit) then
			if VUHDO_UNIT_AURA_LIST_SLOTS[aUnit] and VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][aPanelNum] and VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][aPanelNum][anAnchorIndex] then
				for tClearEntryIndex, tClearSlot in pairs(VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][aPanelNum][anAnchorIndex]) do
					if tClearSlot then
						sSlotDataPool:release(tClearSlot);
					end

					VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][aPanelNum][anAnchorIndex][tClearEntryIndex] = nil;
				end
			end

			return;
		end

		tEntries = tGroup["entries"];

		if not tEntries then
			return;
		end

		if not VUHDO_UNIT_AURA_LIST_SLOTS[aUnit] then
			VUHDO_UNIT_AURA_LIST_SLOTS[aUnit] = { };
		end

		if not VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][aPanelNum] then
			VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][aPanelNum] = { };
		end

		if not VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][aPanelNum][anAnchorIndex] then
			VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][aPanelNum][anAnchorIndex] = { };
		end

		for tEntryIndex, tEntry in ipairs(tEntries) do
			if tEntry["entryType"] == VUHDO_AURA_LIST_ENTRY_EMPTY then
				tOldSlot = VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][aPanelNum][anAnchorIndex][tEntryIndex];

				if tOldSlot then
					sSlotDataPool:release(tOldSlot);
				end

				VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][aPanelNum][anAnchorIndex][tEntryIndex] = nil;
			elseif tEntry["entryType"] == VUHDO_AURA_LIST_ENTRY_SPELL then
				tLookupKey = tEntry["value"];

				if tEntry["isNameMatch"] and type(tLookupKey) == "number" then
					tLookupKey = VUHDO_AURA_NAME_MATCH_SPELL_NAMES[tLookupKey] or tLookupKey;
				end

				tOldSlot = VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][aPanelNum][anAnchorIndex][tEntryIndex];

				if tOldSlot then
					sSlotDataPool:release(tOldSlot);
				end

				VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][aPanelNum][anAnchorIndex][tEntryIndex] = nil;

				if tLookupKey and VUHDO_UNIT_AURA_BY_SPELL[aUnit] then
					tAuraInstances = VUHDO_UNIT_AURA_BY_SPELL[aUnit][tLookupKey];

					if tAuraInstances then
						for _, tAuraInstanceId in ipairs(tAuraInstances) do
							if not ShouldUnitAuraInstanceBeSecret or not ShouldUnitAuraInstanceBeSecret(aUnit, tAuraInstanceId) then
								tCachedAura = VUHDO_UNIT_AURA_CACHE[aUnit] and VUHDO_UNIT_AURA_CACHE[aUnit][tAuraInstanceId];

								if tCachedAura and VUHDO_auraSourceMatchesFilter(tCachedAura, tEntry) and not VUHDO_isAuraIgnored(tCachedAura, anAnchorConfig["groupId"]) then
									tSlotData = sSlotDataPool:get();

									tSlotData["icon"] = tCachedAura["icon"];
									tSlotData["expirationTime"] = tCachedAura["expirationTime"];
									tSlotData["stacks"] = tCachedAura["applications"];
									tSlotData["duration"] = tCachedAura["duration"];
									tSlotData["name"] = tCachedAura["name"];
									tSlotData["spellId"] = tCachedAura["spellId"];
									tSlotData["auraInstanceID"] = tAuraInstanceId;
									tSlotData["entryType"] = VUHDO_AURA_LIST_ENTRY_SPELL;
									tSlotData["isActive"] = true;
									tSlotData["groupId"] = anAnchorConfig["groupId"];
									tSlotData["entryIndex"] = tEntryIndex;
									tSlotData["isAliveTime"] = tEntry["durationMode"] == VUHDO_SPELL_DURATION_MODE_ALIVE;

									VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][aPanelNum][anAnchorIndex][tEntryIndex] = tSlotData;

									break;
								end
							end
						end
					end
				end
			end
		end

		tEntryCount = #tEntries;

		for tClearIndex, tClearSlot in pairs(VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][aPanelNum][anAnchorIndex]) do
			if tClearIndex > tEntryCount then
				if tClearSlot then
					sSlotDataPool:release(tClearSlot);
				end

				VUHDO_UNIT_AURA_LIST_SLOTS[aUnit][aPanelNum][anAnchorIndex][tClearIndex] = nil;
			end
		end

		if not VUHDO_UNIT_AURA_SLOTS[aUnit] then
			VUHDO_UNIT_AURA_SLOTS[aUnit] = { };
		end

		if not VUHDO_UNIT_AURA_SLOTS[aUnit][aPanelNum] then
			VUHDO_UNIT_AURA_SLOTS[aUnit][aPanelNum] = { };
		end

		VUHDO_UNIT_AURA_SLOTS[aUnit][aPanelNum][anAnchorIndex] = VUHDO_UNIT_AURA_SLOTS[aUnit][aPanelNum][anAnchorIndex] or { };

		return;

	end
end



do
	--
	local tAnchorConfig;
	local tGroup;
	local tAuras;
	local tSlotIndex;
	local tMaxSlots;
	function VUHDO_queryAndCacheAurasForAnchor(aUnit, aPanelNum, anAnchorIndex)

		if not aUnit or not aPanelNum or not anAnchorIndex then
			return;
		end

		tAnchorConfig = VUHDO_PANEL_SETUP[aPanelNum] and VUHDO_PANEL_SETUP[aPanelNum]["AURA_ANCHORS"] and VUHDO_PANEL_SETUP[aPanelNum]["AURA_ANCHORS"][anAnchorIndex];

		if not tAnchorConfig then
			return;
		end

		if tAnchorConfig["enabled"] == false then
			VUHDO_clearAurasForAnchor(aUnit, aPanelNum, anAnchorIndex, tAnchorConfig);

			return;
		end

		tGroup = VUHDO_getAuraGroupForUnit(tAnchorConfig["groupId"], aUnit);

		if not tGroup then
			tMaxSlots = tAnchorConfig["maxDisplay"] or 5;

			for tSlotIndex = 1, tMaxSlots do
				VUHDO_setAnchorSlotAuraId(aUnit, aPanelNum, anAnchorIndex, tSlotIndex, nil);
			end

			return;
		end

		if tGroup["type"] == VUHDO_AURA_GROUP_TYPE_LIST then
			VUHDO_updateListSlotsForAnchor(aUnit, aPanelNum, anAnchorIndex, tAnchorConfig);

			return;
		end

		tAuras = VUHDO_getFilteredAuras(aUnit, tGroup["resolvedFilter"], tAnchorConfig["maxDisplay"], tAnchorConfig["sortRule"], tAnchorConfig["sortDir"]);

		twipe(sFilteredAuras);

		for _, tAura in ipairs(tAuras) do
			if VUHDO_isAuraMatchingGroupFilters(aUnit, tAnchorConfig["groupId"], tGroup, tAura) then
				tinsert(sFilteredAuras, tAura);
			end
		end

		tAuras = sFilteredAuras;

		tSlotIndex = 0;
		tMaxSlots = tAnchorConfig["maxDisplay"] or 5;

		for _, tAura in ipairs(tAuras) do
			tSlotIndex = tSlotIndex + 1;

			if tSlotIndex <= tMaxSlots then
				VUHDO_setAnchorSlotAuraId(aUnit, aPanelNum, anAnchorIndex, tSlotIndex, tAura["auraInstanceID"]);
			end
		end

		for tSlotIndex = tSlotIndex + 1, tMaxSlots do
			VUHDO_setAnchorSlotAuraId(aUnit, aPanelNum, anAnchorIndex, tSlotIndex, nil);
		end

		return;

	end
end



do
	--
	local tSlotCfg;
	local tSlots;
	local tSlotVal;
	local tScale;
	local tMaxCount;
	local tMostCommonScale;
	function VUHDO_getMostCommonSlotScale(aHots)

		tSlotCfg = aHots and aHots["SLOTCFG"];
		tSlots = aHots and aHots["SLOTS"];

		if not tSlotCfg then
			return 1;
		end

		twipe(sScaleCounts);

		tMostCommonScale = 1;
		tMaxCount = 0;

		for tSlotNum = 1, 12 do
			tSlotVal = tSlots and tSlots[tSlotNum];

			if tSlotVal and tSlotVal ~= "" and tSlotVal ~= "OTHER" and tSlotVal ~= "CLUSTER" then
				tScale = tSlotCfg["" .. tSlotNum] and tSlotCfg["" .. tSlotNum]["scale"] or 1;

				sScaleCounts[tScale] = (sScaleCounts[tScale] or 0) + 1;

				if sScaleCounts[tScale] > tMaxCount then
					tMaxCount = sScaleCounts[tScale];
					tMostCommonScale = tScale;
				end
			end
		end

		return tMostCommonScale;

	end
end



do
	--
	local tPanelSetup;
	local tHots;
	local tSlots;
	local tSlotCfg;
	local tCfg;
	local tVal;
	local tParts;
	function VUHDO_getIconSlotSignature(aPanelNum)

		tPanelSetup = _G["VUHDO_PANEL_SETUP"];
		tHots = tPanelSetup and tPanelSetup[aPanelNum] and tPanelSetup[aPanelNum]["HOTS"];

		if not tHots then
			return "";
		end

		tSlots = tHots["SLOTS"];
		tSlotCfg = tHots["SLOTCFG"];

		tParts = { };

		for _, tSlotNum in ipairs({ 1, 2, 3, 4, 5, 9, 10, 11, 12 }) do
			tVal = tSlots and tSlots[tSlotNum];
			tCfg = tSlotCfg and tSlotCfg["" .. tSlotNum];

			tinsert(tParts, format("%s;%s;%s", tVal or "", tCfg and tCfg["mine"] and "1" or "0", tCfg and tCfg["others"] and "1" or "0"));
		end

		return table.concat(tParts, "|");

	end



	--
	local tPanelSetup;
	local tHots;
	local tSlots;
	local tSlotCfg;
	local tParts;
	local tVal;
	local tCfg;
	function VUHDO_getBarSlotSignature(aPanelNum)

		tPanelSetup = _G["VUHDO_PANEL_SETUP"];
		tHots = tPanelSetup and tPanelSetup[aPanelNum] and tPanelSetup[aPanelNum]["HOTS"];

		if not tHots then
			return "";
		end

		tSlots = tHots["SLOTS"];
		tSlotCfg = tHots["SLOTCFG"];

		tParts = { };

		for _, tSlotNum in ipairs({ 6, 7, 8 }) do
			tVal = tSlots and tSlots[tSlotNum];
			tCfg = tSlotCfg and tSlotCfg["" .. tSlotNum];

			tinsert(tParts, format("%s;%s;%s", tVal or "", tCfg and tCfg["mine"] and "1" or "0", tCfg and tCfg["others"] and "1" or "0"));
		end

		return table.concat(tParts, "|");

	end
end



do
	--
	local tPanelSetup;
	local tHots;
	local tSlots;
	local tSlotCfg;
	local tParts;
	local tVal;
	local tCfg;
	local tEntry;
	local tNumVal;
	local tBouquetName;
	function VUHDO_buildListGroupFromHotSlots(aPanelNum, anIconSlots)

		tPanelSetup = _G["VUHDO_PANEL_SETUP"];
		tHots = tPanelSetup and tPanelSetup[aPanelNum] and tPanelSetup[aPanelNum]["HOTS"];

		if not tHots then
			return nil;
		end

		tSlots = tHots["SLOTS"];
		tSlotCfg = tHots["SLOTCFG"];

		if not tSlots then
			return nil;
		end

		tParts = { };

		if anIconSlots then
			for _, tSlotNum in ipairs({ 1, 2, 3, 4, 5, 9, 10, 11, 12 }) do
				tVal = tSlots[tSlotNum];
				tCfg = tSlotCfg and tSlotCfg["" .. tSlotNum];
				tEntry = nil;

				if not tVal or tVal == "" or tVal == "OTHER" or tVal == "CLUSTER" then
					tEntry = { ["entryType"] = VUHDO_AURA_LIST_ENTRY_EMPTY };
				elseif strfind(tVal or "", "^BOUQUET_") then
					tBouquetName = strsub(tVal, 9);

					if VUHDO_strempty(tBouquetName) then
						tEntry = { ["entryType"] = VUHDO_AURA_LIST_ENTRY_EMPTY };
					else
						tEntry = { ["entryType"] = VUHDO_AURA_LIST_ENTRY_BOUQUET, ["value"] = tBouquetName };
					end
				else
					tNumVal = tonumber(tVal);

					tEntry = {
						["entryType"] = VUHDO_AURA_LIST_ENTRY_SPELL,
						["value"] = (tNumVal and tNumVal or tVal),
						["mine"] = tCfg and tCfg["mine"],
						["others"] = tCfg and tCfg["others"],
					};
				end

				tinsert(tParts, tEntry);
			end
		else
			for _, tSlotNum in ipairs({ 6, 7, 8 }) do
				tVal = tSlots[tSlotNum];
				tCfg = tSlotCfg and tSlotCfg["" .. tSlotNum];
				tEntry = nil;

				if not tVal or tVal == "" or tVal == "OTHER" or tVal == "CLUSTER" then
					tEntry = { ["entryType"] = VUHDO_AURA_LIST_ENTRY_EMPTY };
				elseif strfind(tVal or "", "^BOUQUET_") then
					tBouquetName = strsub(tVal, 9);

					if VUHDO_strempty(tBouquetName) then
						tEntry = { ["entryType"] = VUHDO_AURA_LIST_ENTRY_EMPTY };
					else
						tEntry = { ["entryType"] = VUHDO_AURA_LIST_ENTRY_BOUQUET, ["value"] = tBouquetName };
					end
				else
					tNumVal = tonumber(tVal);

					tEntry = {
						["entryType"] = VUHDO_AURA_LIST_ENTRY_SPELL,
						["value"] = (tNumVal and tNumVal or tVal),
						["mine"] = tCfg and tCfg["mine"],
						["others"] = tCfg and tCfg["others"],
					};
				end

				tinsert(tParts, tEntry);
			end
		end

		return {
			["type"] = VUHDO_AURA_GROUP_TYPE_LIST,
			["entries"] = tParts,
			["displayName"] = nil,
			["enabled"] = true,
			["priority"] = 50,
			["colorType"] = VUHDO_AURA_GROUP_COLOR_OFF,
			["canColorBar"] = false,
			["canColorText"] = false,
			["unitScope"] = VUHDO_AURA_GROUP_UNIT_SCOPE_FRIENDLY,
		};

	end
end



do
	--
	local tHots;
	local tAuraAnchors;
	local tRadioValue;
	local tPanelSetup;
	local tOriginalRadioValue;
	local tMostCommonScale;
	local tSizePct;
	local tIconSlotCount;
	local tBarSlotCount;
	local tSlots;
	local tBarsConfig;
	local tIconRadioValue;
	local tStacksRadioValue;
	local tBarColors;
	local tHotsColors;
	local tHotBarsConfig;
	local tIsVertical;
	local tBarsRadioValue;
	function VUHDO_migrateHotsToAuraAnchors(aPanelNum)

		tPanelSetup = _G["VUHDO_PANEL_SETUP"];

		tHots = tPanelSetup and tPanelSetup[aPanelNum] and tPanelSetup[aPanelNum]["HOTS"];
		tAuraAnchors = tPanelSetup and tPanelSetup[aPanelNum] and tPanelSetup[aPanelNum]["AURA_ANCHORS"];

		if not tHots or not tAuraAnchors or not tAuraAnchors["1"] then
			return;
		end

		tRadioValue = tHots["radioValue"];

		if 20 == tRadioValue then
			tRadioValue = 30;
		elseif 21 == tRadioValue then
			tRadioValue = 31;
		end

		tAuraAnchors["1"]["radioValue"] = tRadioValue;
		tAuraAnchors["1"]["fixedSlots"] = true;

		tOriginalRadioValue = tHots["radioValue"];
		tMostCommonScale = VUHDO_getMostCommonSlotScale(tHots);
		tSizePct = (tHots["size"] or 40) * tMostCommonScale;

		if 20 == tOriginalRadioValue or 21 == tOriginalRadioValue then
			tSizePct = tSizePct * 0.5;
		end

		tAuraAnchors["1"]["size"] = floor(tSizePct);

		if tRadioValue <= 14 then
			tAuraAnchors["1"]["growthDir"] = VUHDO_HOTS_RADIOVALUE_GROWTH[tRadioValue] or "RIGHT";
			tAuraAnchors["1"]["wrapDir"] = VUHDO_HOTS_RADIOVALUE_WRAP[tRadioValue] or "DOWN";
		end

		tAuraAnchors["1"]["maxColumns"] = 9;
		tAuraAnchors["1"]["maxRows"] = 1;
		tAuraAnchors["1"]["spacing"] = 0;
		tAuraAnchors["1"]["sortRule"] = 3;

		if tHots["TIMER_TEXT"] then
			tAuraAnchors["1"]["TIMER_TEXT"] = VUHDO_deepCopyTable(tHots["TIMER_TEXT"]);

			if not tAuraAnchors["1"]["TIMER_TEXT"]["COLOR"] then
				tAuraAnchors["1"]["TIMER_TEXT"]["COLOR"] = VUHDO_makeFullColor(0, 0, 0, 1, 1, 1, 1, 1);
			end
		end

		if tHots["COUNTER_TEXT"] then
			tAuraAnchors["1"]["COUNTER_TEXT"] = VUHDO_deepCopyTable(tHots["COUNTER_TEXT"]);

			if not tAuraAnchors["1"]["COUNTER_TEXT"]["COLOR"] then
				tAuraAnchors["1"]["COUNTER_TEXT"]["COLOR"] = VUHDO_makeFullColor(0, 0, 0, 1, 0, 1, 0, 1);
			end
		end

		tIconRadioValue = tHots["iconRadioValue"];

		if tIconRadioValue then
			if tIconRadioValue == 1 then
				tAuraAnchors["1"]["iconType"] = 1;
			elseif tIconRadioValue == 2 then
				tAuraAnchors["1"]["iconType"] = 3;
			elseif tIconRadioValue == 3 then
				tAuraAnchors["1"]["iconType"] = 2;
			elseif tIconRadioValue == 4 then
				tAuraAnchors["1"]["iconType"] = 4;
			end
		end

		tStacksRadioValue = tHots["stacksRadioValue"];

		if tStacksRadioValue then
			if tStacksRadioValue == 1 then
				tAuraAnchors["1"]["showStacks"] = 3;
				tAuraAnchors["1"]["stackType"] = 1;
			elseif tStacksRadioValue == 2 then
				tAuraAnchors["1"]["showStacks"] = 1;
				tAuraAnchors["1"]["stackType"] = 1;
			elseif tStacksRadioValue == 3 then
				tAuraAnchors["1"]["showStacks"] = 1;
				tAuraAnchors["1"]["stackType"] = 2;
			end
		end

		tBarColors = tPanelSetup["BAR_COLORS"];
		tHotsColors = tBarColors and tBarColors["HOTS"];

		if tHotsColors then
			if tHotsColors["isFadeOut"] == true then
				tAuraAnchors["1"]["fadeOnLow"] = 1;
			elseif tHotsColors["isFadeOut"] == false then
				tAuraAnchors["1"]["fadeOnLow"] = 3;
			end

			if tHotsColors["isFlashWhenLow"] == true then
				tAuraAnchors["1"]["flashOnLow"] = 1;
			elseif tHotsColors["isFlashWhenLow"] == false then
				tAuraAnchors["1"]["flashOnLow"] = 3;
			end
		end

		tSlots = tHots["SLOTS"];
		tIconSlotCount = 0;
		tBarSlotCount = 0;

		if tSlots then
			for tSlotNum = 1, 5 do
				if tSlots[tSlotNum] and tSlots[tSlotNum] ~= "" then
					tIconSlotCount = tIconSlotCount + 1;
				end
			end

			for tSlotNum = 6, 8 do
				if tSlots[tSlotNum] and tSlots[tSlotNum] ~= "" then
					tBarSlotCount = tBarSlotCount + 1;
				end
			end
		end

		if tBarSlotCount > tIconSlotCount then
			tAuraAnchors["1"]["style"] = "bars";

			tBarsConfig = tHots["BARS"];

			if tBarsConfig then
				tAuraAnchors["1"]["barWidth"] = 100;
				tAuraAnchors["1"]["barHeight"] = tBarsConfig["width"] or 25;
			end

			tHotBarsConfig = VUHDO_INDICATOR_CONFIG and
				VUHDO_INDICATOR_CONFIG[aPanelNum] and
				VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"] and
				VUHDO_INDICATOR_CONFIG[aPanelNum]["CUSTOM"]["HOT_BARS"];

			tIsVertical = tHotBarsConfig and tHotBarsConfig["vertical"] or false;
			tBarsRadioValue = tBarsConfig and tBarsConfig["radioValue"] or 1;

			if tIsVertical then
				if tBarsRadioValue == 4 then
					tAuraAnchors["1"]["radioValue"] = 21;
					tAuraAnchors["1"]["growthDir"] = "LEFT";
				else
					tAuraAnchors["1"]["radioValue"] = 20;
					tAuraAnchors["1"]["growthDir"] = "RIGHT";
				end
				tAuraAnchors["1"]["maxColumns"] = 1;
				tAuraAnchors["1"]["maxRows"] = 3;
			else
				if tBarsRadioValue == 4 then
					tAuraAnchors["1"]["radioValue"] = 31;
					tAuraAnchors["1"]["growthDir"] = "UP";
				else
					tAuraAnchors["1"]["radioValue"] = 30;
					tAuraAnchors["1"]["growthDir"] = "DOWN";
				end
				tAuraAnchors["1"]["maxColumns"] = 3;
				tAuraAnchors["1"]["maxRows"] = 1;
			end

			tAuraAnchors["1"]["maxDisplay"] = 3;
			tAuraAnchors["1"]["spacing"] = 0;
			tAuraAnchors["1"]["wrapDir"] = tIsVertical and "DOWN" or "RIGHT";

			if tHotBarsConfig then
				tAuraAnchors["1"]["barVertical"] = tHotBarsConfig["vertical"] or false;
				tAuraAnchors["1"]["barTurnAxis"] = tHotBarsConfig["turnAxis"] or false;
				tAuraAnchors["1"]["barInvertGrowth"] = tHotBarsConfig["invertGrowth"] or false;
			end
		else
			tAuraAnchors["1"]["style"] = "icons";
		end

		return;

	end
end



do
	--
	local tDebuff;
	local tAuraAnchors;
	local tPoint;
	local tGrowthDir;
	local tWrapDir;
	local tTranslation;
	local tConfig;
	local tPanelSetup;
	function VUHDO_migrateCustomDebuffsToAuraAnchors(aPanelNum)

		tConfig = _G["VUHDO_CONFIG"];
		tPanelSetup = _G["VUHDO_PANEL_SETUP"];

		tDebuff = tConfig and tConfig["CUSTOM_DEBUFF"];
		tAuraAnchors = tPanelSetup and tPanelSetup[aPanelNum] and tPanelSetup[aPanelNum]["AURA_ANCHORS"];

		if not tDebuff or not tAuraAnchors or not tAuraAnchors["2"] then
			return;
		end

		tPoint = tDebuff["point"];
		tGrowthDir = ("TOPLEFT" == tPoint or "BOTTOMLEFT" == tPoint) and "RIGHT" or "LEFT";
		tWrapDir = ("TOPLEFT" == tPoint or "TOPRIGHT" == tPoint) and "DOWN" or "UP";

		tAuraAnchors["2"]["radioValue"] = VUHDO_POINT_TO_RADIOVALUE[tPoint];
		tAuraAnchors["2"]["fixedSlots"] = true;

		tAuraAnchors["2"]["size"] = tDebuff["scale"] and floor(tDebuff["scale"] * 70) or 40;

		tTranslation = VUHDO_DEBUFF_OFFSET_TRANSLATION[tPoint] or sEmpty;
		tAuraAnchors["2"]["offsetX"] = (tDebuff["xAdjust"] or -2) + (tTranslation["x"] or 0);
		tAuraAnchors["2"]["offsetY"] = (tDebuff["yAdjust"] or -34) + (tTranslation["y"] or 0);

		tAuraAnchors["2"]["maxDisplay"] = tDebuff["max_num"] or 3;
		tAuraAnchors["2"]["growthDir"] = tGrowthDir;
		tAuraAnchors["2"]["wrapDir"] = tWrapDir;
		tAuraAnchors["2"]["maxColumns"] = tDebuff["max_num"] or 3;
		tAuraAnchors["2"]["maxRows"] = 1;
		tAuraAnchors["2"]["spacing"] = 0;

		if tDebuff["TIMER_TEXT"] then
			tAuraAnchors["2"]["TIMER_TEXT"] = VUHDO_deepCopyTable(tDebuff["TIMER_TEXT"]);

			if not tAuraAnchors["2"]["TIMER_TEXT"]["COLOR"] then
				tAuraAnchors["2"]["TIMER_TEXT"]["COLOR"] = VUHDO_makeFullColor(0, 0, 0, 1, 1, 1, 1, 1);
			end
		end

		if tDebuff["COUNTER_TEXT"] then
			tAuraAnchors["2"]["COUNTER_TEXT"] = VUHDO_deepCopyTable(tDebuff["COUNTER_TEXT"]);

			if not tAuraAnchors["2"]["COUNTER_TEXT"]["COLOR"] then
				tAuraAnchors["2"]["COUNTER_TEXT"]["COLOR"] = VUHDO_makeFullColor(0, 0, 0, 1, 0, 1, 0, 1);
			end
		end

		return;

	end



	--
	local tPanelSetup;
	local tAnchors;
	function VUHDO_migrateAuraAnchorTextColors()

		tPanelSetup = _G["VUHDO_PANEL_SETUP"];

		if not tPanelSetup then
			return;
		end

		for tPanelNum = 1, VUHDO_MAX_PANELS do
			tAnchors = tPanelSetup[tPanelNum] and tPanelSetup[tPanelNum]["AURA_ANCHORS"];

			if tAnchors then
				for _, tAnchor in pairs(tAnchors) do
					if tAnchor["TIMER_TEXT"] and not tAnchor["TIMER_TEXT"]["COLOR"] then
						tAnchor["TIMER_TEXT"]["COLOR"] = VUHDO_makeFullColor(0, 0, 0, 1, 1, 1, 1, 1);
					end

					if tAnchor["COUNTER_TEXT"] and not tAnchor["COUNTER_TEXT"]["COLOR"] then
						tAnchor["COUNTER_TEXT"]["COLOR"] = VUHDO_makeFullColor(0, 0, 0, 1, 0, 1, 0, 1);
					end
				end
			end
		end

		return;

	end



	do
		--
		local tConfig;
		local tAuraIgnoreList;
		local tIconSigToPanels;
		local tBarSigToPanels;
		local tIconSig;
		local tBarSig;
		local tGroup;
		local tHasNonEmpty;
		local tIconSigToGroupId;
		local tBarSigToGroupId;
		local tIconGroupIdToPanels;
		local tBarGroupIdToPanels;
		local tGroupId;
		local tIconGroupCount;
		local tBarGroupCount;
		local tTotalGroupCount;
		local tBaseName;
		local tPanelList;
		local tDisplayName;
		local tAnchors;
		local tInIconPanels;
		local tInBarPanels;
		local tIconGroupId;
		local tBarGroupId;
		local tPanelSetup;
		local tHots;
		local tDebuffIgnoreList;
		local tSpellId;
		function VUHDO_migrateHotsToAuraAnchorsV2()

			tPanelSetup = _G["VUHDO_PANEL_SETUP"];
			tConfig = _G["VUHDO_CONFIG"];
			tAuraIgnoreList = _G["VUHDO_AURA_IGNORE_LIST"];

			tIconSigToPanels = { };
			tBarSigToPanels = { };

			tIconGroupCount = 0;
			tBarGroupCount = 0;

			tIconSigToGroupId = { };
			tBarSigToGroupId = { };
			tIconGroupIdToPanels = { };
			tBarGroupIdToPanels = { };

			if not tPanelSetup or not tConfig then
				return;
			end

			tConfig["AURA_GROUPS"] = tConfig["AURA_GROUPS"] or { };

			tDebuffIgnoreList = VUHDO_DEBUFF_BLACKLIST;

			if tDebuffIgnoreList then
				for tKey, _ in pairs(tDebuffIgnoreList) do
					tSpellId = tonumber(tKey);

					if tSpellId then
						tAuraIgnoreList[tSpellId] = true;
					elseif tKey ~= "!" then
						tAuraIgnoreList[tKey] = true;
					end
				end
			end

			for tPanelNum = 1, 10 do
				tHots = tPanelSetup[tPanelNum] and tPanelSetup[tPanelNum]["HOTS"];
				tAnchors = tPanelSetup[tPanelNum] and tPanelSetup[tPanelNum]["AURA_ANCHORS"];

				if tHots and tAnchors and tAnchors["1"] then
					tIconSig = VUHDO_getIconSlotSignature(tPanelNum);
					tGroup = VUHDO_buildListGroupFromHotSlots(tPanelNum, true);

					if tGroup then
						tHasNonEmpty = false;

						for tIdx, tEntry in ipairs(tGroup["entries"]) do
							if tEntry["entryType"] ~= VUHDO_AURA_LIST_ENTRY_EMPTY then
								tHasNonEmpty = true;

								break;
							end
						end

						if tHasNonEmpty then
							tIconSigToPanels[tIconSig] = tIconSigToPanels[tIconSig] or { };

							tinsert(tIconSigToPanels[tIconSig], tPanelNum);
						end
					end

					tBarSig = VUHDO_getBarSlotSignature(tPanelNum);
					tGroup = VUHDO_buildListGroupFromHotSlots(tPanelNum, false);

					if tGroup then
						tHasNonEmpty = false;

						for tIdx, tEntry in ipairs(tGroup["entries"]) do
							if tEntry["entryType"] ~= VUHDO_AURA_LIST_ENTRY_EMPTY then
								tHasNonEmpty = true;

								break;
							end
						end

						if tHasNonEmpty then
							tBarSigToPanels[tBarSig] = tBarSigToPanels[tBarSig] or { };

							tinsert(tBarSigToPanels[tBarSig], tPanelNum);
						end
					end
				end
			end

			for tIconSig, tPanels in pairs(tIconSigToPanels) do
				tGroup = VUHDO_buildListGroupFromHotSlots(tPanels[1], true);

				if tGroup then
					-- migration runs before burst cache init
					tGroupId = _G["VUHDO_generateUUID"]("MIGRATED_HOTS_", 8);

					tConfig["AURA_GROUPS"][tGroupId] = tGroup;

					tIconSigToGroupId[tIconSig] = tGroupId;
					tIconGroupIdToPanels[tGroupId] = tPanels;
				end
			end

			for tBarSig, tPanels in pairs(tBarSigToPanels) do
				tGroup = VUHDO_buildListGroupFromHotSlots(tPanels[1], false);

				if tGroup then
					-- migration runs before burst cache init
					tGroupId = _G["VUHDO_generateUUID"]("MIGRATED_HOT_BARS_", 8);

					tConfig["AURA_GROUPS"][tGroupId] = tGroup;

					tBarSigToGroupId[tBarSig] = tGroupId;
					tBarGroupIdToPanels[tGroupId] = tPanels;
				end
			end

			for _ in pairs(tIconSigToGroupId) do
				tIconGroupCount = tIconGroupCount + 1;
			end

			for _ in pairs(tBarSigToGroupId) do
				tBarGroupCount = tBarGroupCount + 1;
			end

			tTotalGroupCount = tIconGroupCount + tBarGroupCount;

			for tGroupId, tPanels in pairs(tIconGroupIdToPanels) do
				tGroup = tConfig["AURA_GROUPS"][tGroupId];

				if tGroup then
					if tTotalGroupCount == 1 then
						tBaseName = VUHDO_I18N_AURA_GROUP_MIGRATED_HOTS;
					elseif tIconGroupCount > 0 and tBarGroupCount > 0 then
						tBaseName = VUHDO_I18N_AURA_GROUP_MIGRATED_HOT_ICONS;
					else
						tBaseName = VUHDO_I18N_AURA_GROUP_MIGRATED_HOTS;
					end

					if tIconGroupCount > 1 then
						tPanelList = table.concat(tPanels, ", ");

						tDisplayName = tBaseName .. " (Panel " .. tPanelList .. ")";
					else
						tDisplayName = tBaseName;
					end

					tGroup["displayName"] = VUHDO_ensureUniqueAuraGroupDisplayName(tDisplayName);
				end
			end

			for tGroupId, tPanels in pairs(tBarGroupIdToPanels) do
				tGroup = tConfig["AURA_GROUPS"][tGroupId];

				if tGroup then
					if tTotalGroupCount == 1 then
						tBaseName = VUHDO_I18N_AURA_GROUP_MIGRATED_HOTS;
					elseif tIconGroupCount > 0 and tBarGroupCount > 0 then
						tBaseName = VUHDO_I18N_AURA_GROUP_MIGRATED_HOT_BARS;
					else
						tBaseName = VUHDO_I18N_AURA_GROUP_MIGRATED_HOTS;
					end

					if tBarGroupCount > 1 then
						tPanelList = table.concat(tPanels, ", ");

						tDisplayName = tBaseName .. " (Panel " .. tPanelList .. ")";
					else
						tDisplayName = tBaseName;
					end

					tGroup["displayName"] = VUHDO_ensureUniqueAuraGroupDisplayName(tDisplayName);
				end
			end

			for tPanelNum = 1, 10 do
				tAnchors = tPanelSetup[tPanelNum] and tPanelSetup[tPanelNum]["AURA_ANCHORS"];

				if tAnchors and tAnchors["1"] then
					tInIconPanels = false;
					tInBarPanels = false;
					tIconGroupId = nil;
					tBarGroupId = nil;

					for tSig, tPanels in pairs(tIconSigToPanels) do
						for tIdx, tPanelIdx in ipairs(tPanels) do
							if tPanelIdx == tPanelNum then
								tInIconPanels = true;
								tIconGroupId = tIconSigToGroupId[tSig];

								break;
							end
						end

						if tInIconPanels then
							break;
						end
					end

					for tSig, tPanels in pairs(tBarSigToPanels) do
						for tIdx, tPanelIdx in ipairs(tPanels) do
							if tPanelIdx == tPanelNum then
								tInBarPanels = true;
								tBarGroupId = tBarSigToGroupId[tSig];

								break;
							end
						end

						if tInBarPanels then
							break;
						end
					end

					if tInIconPanels and tInBarPanels then
						tAnchors["1"]["groupId"] = tIconGroupId;
						tAnchors["1"]["fixedSlots"] = true;
						tAnchors["1"]["style"] = "icons";
						tAnchors["1"]["maxDisplay"] = 9;

						tAnchors["4"] = VUHDO_deepCopyTable(tAnchors["1"]);
						tAnchors["4"]["groupId"] = tBarGroupId;
						tAnchors["4"]["style"] = "bars";
						tAnchors["4"]["maxDisplay"] = 3;
					elseif tInIconPanels then
						tAnchors["1"]["groupId"] = tIconGroupId;
						tAnchors["1"]["fixedSlots"] = true;
						tAnchors["1"]["style"] = "icons";
						tAnchors["1"]["maxDisplay"] = 9;
					elseif tInBarPanels then
						tAnchors["1"]["groupId"] = tBarGroupId;
						tAnchors["1"]["fixedSlots"] = true;
						tAnchors["1"]["style"] = "bars";
						tAnchors["1"]["maxDisplay"] = 3;
					end
				end
			end

			return;

		end
	end



	--
	local tConfig;
	local tIgnoreList;
	local tKeysToConvert;
	local function VUHDO_migrateAuraGroupIgnoreListKeys()

		tConfig = _G["VUHDO_CONFIG"];

		if not tConfig or not tConfig["AURA_GROUPS"] then
			return;
		end

		for _, tGroup in pairs(tConfig["AURA_GROUPS"]) do
			tIgnoreList = tGroup and tGroup["ignoreList"];

			if tIgnoreList then
				tKeysToConvert = tKeysToConvert or { };
				twipe(tKeysToConvert);

				for tKey, _ in pairs(tIgnoreList) do
					if type(tKey) == "string" and tonumber(tKey) then
						tinsert(tKeysToConvert, tKey);
					end
				end

				for _, tKey in ipairs(tKeysToConvert) do
					tIgnoreList[tonumber(tKey)] = true;
					tIgnoreList[tKey] = nil;
				end
			end
		end

		return;

	end



	--
	local tConfig;
	function VUHDO_migrateAuraGroupGlowBarStyle()

		tConfig = _G["VUHDO_CONFIG"];

		if not tConfig or not tConfig["AURA_GROUPS"] then
			return;
		end

		for _, tGroup in pairs(tConfig["AURA_GROUPS"]) do
			if tGroup then
				if tGroup["canGlowBar"] and not tGroup["glowBarStyle"] then
					tGroup["glowBarStyle"] = VUHDO_DEFAULT_AURA_GLOW_STYLE;
				elseif not tGroup["canGlowBar"] then
					tGroup["glowBarStyle"] = nil;
				end
			end
		end

		return;

	end



	--
	local tPanelSetup;
	function VUHDO_migrateAuraDefaultsRangeFade()

		tPanelSetup = _G["VUHDO_PANEL_SETUP"];

		if not tPanelSetup then
			return;
		end

		if not tPanelSetup["AURA_DEFAULTS"] then
			tPanelSetup["AURA_DEFAULTS"] = { };
		end

		if tPanelSetup["AURA_DEFAULTS"]["rangeFade"] == nil then
			tPanelSetup["AURA_DEFAULTS"]["rangeFade"] = true;
		end

		if tPanelSetup["AURA_DEFAULTS"]["colorOnPandemic"] == nil then
			tPanelSetup["AURA_DEFAULTS"]["colorOnPandemic"] = false;
		end

		if tPanelSetup["AURA_DEFAULTS"]["flashOnPandemic"] == nil then
			tPanelSetup["AURA_DEFAULTS"]["flashOnPandemic"] = false;
		end

		return;

	end



	--
	local tPanelSetup;
	local tDefaultAuraDefaults;
	function VUHDO_migrateAuraDefaultsMissingKeys()

		tPanelSetup = _G["VUHDO_PANEL_SETUP"];
		tDefaultAuraDefaults = _G["VUHDO_DEFAULT_AURA_DEFAULTS"];

		if not tPanelSetup or not tDefaultAuraDefaults then
			return;
		end

		if not tPanelSetup["AURA_DEFAULTS"] then
			tPanelSetup["AURA_DEFAULTS"] = { };
		end

		for tKey, tDefaultValue in pairs(tDefaultAuraDefaults) do
			if tPanelSetup["AURA_DEFAULTS"][tKey] == nil then
				tPanelSetup["AURA_DEFAULTS"][tKey] = tDefaultValue;
			end
		end

		return;

	end



	--
	local tAuraIgnoreList;
	local tDebuffBlacklist;
	function VUHDO_migrateAuraIgnoreListInvalidKeys()

		tAuraIgnoreList = _G["VUHDO_AURA_IGNORE_LIST"];
		tDebuffBlacklist = _G["VUHDO_DEBUFF_BLACKLIST"];

		if tAuraIgnoreList then
			tAuraIgnoreList["!"] = nil;
		end

		if tDebuffBlacklist then
			tDebuffBlacklist["!"] = nil;
		end

		return;

	end



	--
	local tPanelSetup;
	local tCurrentMigrationVersion;
	function VUHDO_migrateOldConfigsToAuraAnchors()

		tPanelSetup = _G["VUHDO_PANEL_SETUP"];
		tCurrentMigrationVersion = tPanelSetup["AURA_MIGRATION_VERSION"] or 0;

		if tCurrentMigrationVersion >= VUHDO_AURA_MIGRATION_VERSION then
			return;
		end

		if tCurrentMigrationVersion == 0 then
			for tPanelNum = 1, 10 do
				if tPanelSetup[tPanelNum] and (not tPanelSetup[tPanelNum]["AURA_ANCHORS"] or not next(tPanelSetup[tPanelNum]["AURA_ANCHORS"])) then
					tPanelSetup[tPanelNum]["AURA_ANCHORS"] = VUHDO_deepCopyTable(VUHDO_DEFAULT_AURA_ANCHORS);
				end

				VUHDO_migrateHotsToAuraAnchors(tPanelNum);
				VUHDO_migrateCustomDebuffsToAuraAnchors(tPanelNum);
			end

			VUHDO_migrateHotsToAuraAnchorsV2();
		end

		if tCurrentMigrationVersion >= 0 then
			VUHDO_migrateAuraAnchorTextColors();
		end

		if tCurrentMigrationVersion < 4 then
			VUHDO_migrateAuraAnchorDefaults();
		end

		if tCurrentMigrationVersion < 5 then
			VUHDO_migrateAuraGroupIgnoreListKeys();
		end

		if tCurrentMigrationVersion < 6 then
			VUHDO_migrateAuraGroupGlowBarStyle();
		end

		if tCurrentMigrationVersion < 7 then
			VUHDO_migrateAuraGroupFilterTokens();
		end

		if tCurrentMigrationVersion < 8 then
			VUHDO_migrateAuraDefaultsRangeFade();
		end

		if tCurrentMigrationVersion < 9 then
			VUHDO_migrateAllAuraGroupConditions();
		end

		if tCurrentMigrationVersion < 10 then
			VUHDO_migrateAuraGroupListFilters();
		end

		if tCurrentMigrationVersion < 11 then
			VUHDO_migrateAuraIgnoreListInvalidKeys();
		end

		if tCurrentMigrationVersion < 12 then
			VUHDO_migrateAuraDefaultsMissingKeys();
		end

		tPanelSetup["AURA_MIGRATION_VERSION"] = VUHDO_AURA_MIGRATION_VERSION;

		return;

	end



	--
	local tConfig;
	local tDefaultGroups;
	function VUHDO_migrateAllAuraGroupConditions()

		tConfig = _G["VUHDO_CONFIG"];
		tDefaultGroups = _G["VUHDO_DEFAULT_AURA_GROUPS"];

		if tConfig and tConfig["AURA_GROUPS"] then
			for _, tGroup in pairs(tConfig["AURA_GROUPS"]) do
				if tGroup and (tGroup["type"] or VUHDO_AURA_GROUP_TYPE_FILTER) == VUHDO_AURA_GROUP_TYPE_FILTER then
					VUHDO_migrateAuraGroupConditions(tGroup);

					if tGroup["hasDuration"] and tGroup["maxDurationSeconds"] == nil then
						tGroup["maxDurationSeconds"] = 0;
						tGroup["hasDuration"] = nil;
					end

					tGroup["resolvedFilter"] = nil;
				end
			end
		end

		if tDefaultGroups then
			for _, tGroup in pairs(tDefaultGroups) do
				if tGroup and (tGroup["type"] or VUHDO_AURA_GROUP_TYPE_FILTER) == VUHDO_AURA_GROUP_TYPE_FILTER then
					VUHDO_migrateAuraGroupConditions(tGroup);

					if tGroup["hasDuration"] and tGroup["maxDurationSeconds"] == nil then
						tGroup["maxDurationSeconds"] = 0;
						tGroup["hasDuration"] = nil;
					end

					tGroup["resolvedFilter"] = nil;
				end
			end
		end

		VUHDO_invalidateAuraGroupFilterCache();
		VUHDO_resolveAllAuraGroupFilters();

		return;

	end



	--
	local tConfig;
	local tFilterParts;
	local tFilterUpper;
	function VUHDO_migrateAuraGroupListFilters()

		tConfig = _G["VUHDO_CONFIG"];

		if not tConfig or not tConfig["AURA_GROUPS"] then
			return;
		end

		local function VUHDO_migrateOneAuraGroupListFilter(aGroup)

			if not aGroup or (aGroup["type"] or VUHDO_AURA_GROUP_TYPE_FILTER) ~= VUHDO_AURA_GROUP_TYPE_LIST then
				return;
			end

			if aGroup["filter"] then
				tFilterParts = { };

				for tFilterToken in gmatch(aGroup["filter"], "[^|]+") do
					tFilterUpper = strupper(tFilterToken);

					if tFilterUpper == "HARMFUL" then
						tinsert(tFilterParts, "HELPFUL");
					else
						tinsert(tFilterParts, tFilterToken);
					end
				end

				if #tFilterParts > 0 then
					aGroup["filter"] = table.concat(tFilterParts, "|");
				else
					aGroup["filter"] = "HELPFUL";
				end
			end

			aGroup["isHarmful"] = nil;
			aGroup["resolvedFilter"] = nil;

			return;

		end

		for _, tGroup in pairs(tConfig["AURA_GROUPS"]) do
			VUHDO_migrateOneAuraGroupListFilter(tGroup);
		end

		VUHDO_invalidateAuraGroupFilterCache();
		VUHDO_resolveAllAuraGroupFilters();

		return;

	end



	--
	local tConfig;
	function VUHDO_migrateAuraGroupFilterTokens()

		tConfig = _G["VUHDO_CONFIG"];

		if not tConfig or not tConfig["AURA_GROUPS"] then
			return;
		end

		for _, tGroup in pairs(tConfig["AURA_GROUPS"]) do
			if tGroup["filter"] then
				tGroup["filter"] = gsub(tGroup["filter"], "NOT_CANCELABLE", "!CANCELABLE");
				tGroup["filter"] = gsub(tGroup["filter"], VUHDO_ALL_DISPELLABLE_TOKEN, "DISPELLABLE");
			end

			if tGroup["excludeFilter"] then
				tGroup["excludeFilter"] = gsub(tGroup["excludeFilter"], "NOT_CANCELABLE", "!CANCELABLE");
			end

			tGroup["resolvedFilter"] = nil;
		end

		VUHDO_invalidateAuraGroupFilterCache();
		VUHDO_resolveAllAuraGroupFilters();

		return;

	end



	--
	local tPanelSetup;
	local tAnchors;
	function VUHDO_migrateAuraAnchorDefaults()

		tPanelSetup = _G["VUHDO_PANEL_SETUP"];

		if not tPanelSetup then
			return;
		end

		for tPanelNum = 1, VUHDO_MAX_PANELS do
			tAnchors = tPanelSetup[tPanelNum] and tPanelSetup[tPanelNum]["AURA_ANCHORS"];

			if tAnchors then
				for tAnchorKey, tAnchorData in pairs(tAnchors) do
					if tAnchorData["size"] == nil then
						tAnchorData["size"] = 20;
					end

					if tAnchorData["barWidth"] == nil then
						tAnchorData["barWidth"] = 100;
					end

					if tAnchorData["barHeight"] == nil then
						tAnchorData["barHeight"] = 12;
					end

					if tAnchorData["spacing"] == nil then
						tAnchorData["spacing"] = 2;
					end
				end
			end
		end

		return;

	end



	--
	function VUHDO_resetAndRemigrateAuras()

		tPanelSetup = _G["VUHDO_PANEL_SETUP"];

		for tPanelNum = 1, VUHDO_MAX_PANELS do
			tPanelSetup[tPanelNum]["AURA_ANCHORS"] = nil;
		end

		tPanelSetup["AURA_MIGRATION_VERSION"] = nil;

		VUHDO_loadDefaultPanelSetup();
		VUHDO_reloadUI(false);

		VUHDO_Msg("Aura taşıma işlemi tamamlandı.");

		return;

	end



	--
	local tPanelSetup;
	local tConfig;
	function VUHDO_migrateKeyLayoutToAuras(aLayout)

		if not aLayout or aLayout["AURAS"] then
			return;
		end

		if not aLayout["HOTS"] then
			return;
		end

		tPanelSetup = _G["VUHDO_PANEL_SETUP"];
		tConfig = _G["VUHDO_CONFIG"];

		aLayout["AURAS"] = { };

		for tPanelNum = 1, VUHDO_MAX_PANELS do
			if tPanelSetup and tPanelSetup[tPanelNum] and tPanelSetup[tPanelNum]["AURA_ANCHORS"] then
				aLayout["AURAS"][tPanelNum] = VUHDO_compressTable(tPanelSetup[tPanelNum]["AURA_ANCHORS"]);
			end
		end

		if tConfig and tConfig["AURA_GROUPS"] then
			aLayout["AURA_GROUPS"] = VUHDO_compressTable(tConfig["AURA_GROUPS"]);
		end

		if tConfig and tConfig["AURA_GROUP_DISABLED"] then
			aLayout["AURA_GROUP_DISABLED"] = VUHDO_compressTable(tConfig["AURA_GROUP_DISABLED"]);
		end

		aLayout["HOTS"] = nil;

		return;

	end



	--
	function VUHDO_auraHelp()

		VUHDO_Msg("|cffFFD100--- Aura Commands ---|r");
		VUHDO_Msg("  |cffB0E0E6/vd aura migrate|r - Re-run aura configuration migration");
		VUHDO_Msg("  |cffB0E0E6/vd aura restrict on|off|auto|r - Force AuraContainer mode on/off and reload UI");
		VUHDO_Msg("  |cffB0E0E6/vd aura restrict|r - Show current aura mode (on/off) and data state");
		VUHDO_Msg("  |cffB0E0E6/vd aura dump [unit] [indicator] [-v]|r - Dump compact aura container diagnostics");
		VUHDO_Msg("  |cffB0E0E6/vd aura rebuild|r - Release and rebuild all aura overlay containers");
		VUHDO_Msg("  |cffB0E0E6/vd aura|r - Show this help");
		VUHDO_Msg("|cffFFD100--- End of Aura Commands ---|r");

		return;

	end
end