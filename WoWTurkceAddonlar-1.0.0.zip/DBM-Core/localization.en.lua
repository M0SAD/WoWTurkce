---@class DBMLocale
local L = {}
L.AURA_FONT_RESET = "Geçersiz aura yazı tipi ayarları bulundu ve varsayılanlara döndürüldü."

DBM_CORE_L = L
-- SpellItemEnchantment.Name_lang: 5401, 5400, 6498 (wago.tools).
L.CONSUMABLES_SHAMAN_IMBUES = {"Windfury", "Flametongue", "Earthliving"}
-- SpellItemEnchantment.Name_lang: 7143, 7144 (wago.tools).
L.CONSUMABLES_PALADIN_IMBUES = {"Rite of Sanctification", "Rite of Adjuration"}

L.DEADLY_BOSS_MODS						= "Deadly Boss Mods" -- NO TRANSLATE
L.DBM									= "DBM" -- NO TRANSLATE

local dateTable = date("*t")
if dateTable.day and dateTable.month and dateTable.day == 1 and dateTable.month == 4 then
	L.DEADLY_BOSS_MODS					= "Harmless Minion Mods"
	L.DBM								= "HMM"
end

L.HOW_TO_USE_MOD						= "Welcome to " .. L.DBM .. ". Type /dbm help for a list of supported commands. To access options type /dbm in your chat to begin configuration. Load specific zones manually to configure any boss specific settings to your liking as well. " .. L.DBM .. " will setup defaults for your spec, but you may want to fine tune these."
L.SILENT_REMINDER						= "Reminder: " .. L.DBM .. " is still in silent mode."
L.NEWS_UPDATE							= "|h|c11ff1111Haber|r|h: DBM'ye yetenek yeniden adlandırma özelliği eklendi. /dbm yazıp mod kategorisine (Raid, zindan vb.) gidin ve yeteneklerini yeniden adlandırmak istediğiniz modu seçin."
L.NEWS_UPDATE_REPEAT					= "|h|c11ff1111Haber|r|h: DBM, classic ve mainline sürümlerinin ortak modülleri kullanabilmesi için yeniden düzenlendi. Bu yüzden Vanilla (SoD dahil), TBC, Wrath ve Cata Raid modülleri artık retail ile aynı paketlerden ayrıca indirilmeli. Şu an modülü eksik bir Raid'desin. Eksik Raid modülünü yükleyene kadar bu mesaj görünmeye devam edecek (ve bu bölgede uyarı çalışmayacak)."


L.COPY_URL_DIALOG_NEWS					= "Son haberleri okumak için aşağıdaki bağlantıyı ziyaret edin"

L.LOAD_MOD_ERROR						= "%s için boss modları yüklenirken hata: %s"
L.LOAD_MOD_SUCCESS						= "'%s' modları yüklendi. Özel uyarı sesleri ve kişisel uyarı notları gibi daha fazla seçenek için /dbm yazın."
L.LOAD_MOD_COMBAT						= "'%s' yüklemesi savaştan çıkana kadar ertelendi"
L.LOAD_GUI_ERROR						= "Arayüz yüklenemedi: %s"
L.LOAD_GUI_COMBAT						= "Arayüz savaşta açılamaz. Savaştan çıkınca tekrar deneyin."
L.BAD_LOAD								= L.DBM .. " has detected your mod for this instance failed to fully load correctly because of combat. As soon as you are out of combat, please do /console reloadui as soon as possible."
L.LOAD_MOD_VER_MISMATCH					= "%s yüklenemedi çünkü DBM-Core sürümünüz gereksinimleri karşılamıyor. Güncel bir sürüm gerekli"
L.LOAD_MOD_EXP_MISMATCH					= "%s yüklenemedi çünkü şu an mevcut olmayan bir WoW genişleme paketi için tasarlandı. Genişleme paketi açıldığında bu mod kendiliğinden çalışacak."
L.LOAD_MOD_TOC_MISMATCH					= "%s yüklenemedi çünkü şu an mevcut olmayan bir WoW yaması (%s) için tasarlandı. Yama açıldığında bu mod kendiliğinden çalışacak."
L.LOAD_MOD_DISABLED						= "%s kurulu ama şu an devre dışı. Etkinleştirmediğiniz sürece bu mod yüklenmeyecek."
L.LOAD_MOD_DISABLED_PLURAL				= "%s kurulu ama şu an devre dışı. Etkinleştirmediğiniz sürece bu modlar yüklenmeyecek."

L.COPY_URL_DIALOG						= "URL'yi Kopyala"
L.COPY_WA_DIALOG						= "Büyü Anahtarını Kopyala"

--Post Patch 7.1
L.TEXT_ONLY_RANGE						= "Blizzard bu bölgede bazı işlevleri kapattığı için menzil penceresi yalnızca yazıyla sınırlı."
L.NO_RANGE								= "Blizzard bu bölgede bu işlevi kapattığı için menzil penceresi kullanılamaz."
L.NO_ARROW								= "Ok zindanlarda kullanılamaz"
L.HUDMAP_NOT_INSTALLED					= "DBM-HudMap kurulu değil veya etkin değil."
L.NO_COMMS								= "Eklenti iletişimi boss savaşlarında veya etkin M+ zindanlarında kullanılamaz. Savaş veya zindan bitince bu komutu tekrar kullanın."--Midnight+

L.DYNAMIC_DIFFICULTY_CLUMP				= L.DBM .. " has disabled dynamic range frame on this fight do to insufficient information about number of players needed to affect clump check for a group of your size."
L.DYNAMIC_ADD_COUNT						= L.DBM .. " has disabled add count warnings on this fight do to insufficient information about number of adds that spawn for a group of your size."
L.DYNAMIC_MULTIPLE						= L.DBM .. " has disabled multiple features on this fight do to insufficient information about certain mechanics for a group of your size."

L.LOOT_SPEC_REMINDER					= "Şu anki uzmanlığınız %s. Şu anki ganimet seçiminiz %s."

L.BIGWIGS_ICON_CONFLICT					= L.DBM .. " has detected that you have raid icons turned on in both BigWigs and " .. L.DBM .. ". Please disable icons in one of them to avoid conflicts"

L.MOD_AVAILABLE							= "%s bu bölge için mevcut ama kurulu değil. Curse, Wago, WoWI veya GitHub Releases sayfasından indirebilirsiniz."
L.MOD_MISSING							= "Raid Modülü Yok"
L.NOT_INSTALLED							= "Kurulu Değil"

L.COMBAT_STARTED						= "%s başladı. Bol şans, iyi eğlenceler! :)"
L.COMBAT_STARTED_IN_PROGRESS			= "%s ile süren bir savaşa katıldınız. Bol şans, iyi eğlenceler! :)"
L.GUILD_COMBAT_STARTED					= "%s, %s loncasının grubuyla savaşa girdi"
L.SCENARIO_STARTED						= "%s başladı. Bol şans, iyi eğlenceler! :)"
L.SCENARIO_STARTED_IN_PROGRESS			= "Süren bir senaryoya katıldınız: %s. Bol şans, iyi eğlenceler! :)"
L.BOSS_DOWN								= "%s, %s sonra yenildi!"
L.BOSS_DOWN_I							= "%s yenildi! Toplam %d zaferiniz var."
L.BOSS_DOWN_L							= "%s, %s sonra yenildi! Son öldürmeniz %s, en hızlısı %s sürdü. Toplam %d zaferiniz var."
L.BOSS_DOWN_NR							= "%s, %s sonra yenildi! Bu yeni bir rekor! (Eski rekor: %s). Toplam %d zaferiniz var."
L.RAID_DOWN								= "%s cleared after %s!"
L.RAID_DOWN_L							= "%s cleared after %s! Your fastest clear took %s."
L.RAID_DOWN_NR							= "%s, %s sonra temizlendi! Bu yeni bir rekor! (Eski rekor: %s)."
L.GUILD_BOSS_DOWN						= "%s, %s loncasının grubu tarafından %s sonra yenildi!"
L.SCENARIO_COMPLETE						= "%s, %s sonra tamamlandı!"
L.SCENARIO_COMPLETE_I					= "%s tamamlandı! Toplam %d temizlemeniz var."
L.SCENARIO_COMPLETE_L					= "%s, %s sonra tamamlandı! Son temizlemeniz %s, en hızlısı %s sürdü. Toplam %d temizlemeniz var."
L.SCENARIO_COMPLETE_NR					= "%s, %s sonra tamamlandı! Bu yeni bir rekor! (Eski rekor: %s). Toplam %d temizlemeniz var."
L.COMBAT_ENDED_AT						= "%s (%s) ile savaş %s sonra bitti."--Health Included
L.COMBAT_ENDED							= "%s ile savaş %s sonra bitti."--No health (post midnight)
L.COMBAT_ENDED_AT_LONG					= "%s (%s) ile savaş %s sonra bitti. Bu zorlukta toplam %d kez yenildiniz."--Health Included
L.COMBAT_ENDED_LONG						= "%s ile savaş %s sonra bitti. Bu zorlukta toplam %d kez yenildiniz."--No health (post midnight)
L.GUILD_COMBAT_ENDED_AT					= "%s loncasının grubu %s (%s) karşısında %s sonra yenildi."--Health Included
L.GUILD_COMBAT_ENDED					= "%s loncasının grubu %s karşısında %s sonra yenildi."--No health (post midnight)
L.SCENARIO_ENDED_AT						= "%s, %s sonra bitti."
L.SCENARIO_ENDED_AT_LONG				= "%s, %s sonra bitti. Bu zorlukta toplam %d tamamlanmamış denemeniz var."
L.COMBAT_STATE_RECOVERED				= "%s ile savaş %s önce başlamış, zamanlayıcılar kurtarılıyor... "
L.TRANSCRIPTOR_LOG_START				= "Transcriptor kaydı başladı."
L.TRANSCRIPTOR_LOG_END					= "Transcriptor kaydı bitti."

L.MOVIE_SKIPPED							= L.DBM .. " has attempted to skip a cut scene automatically."
L.MOVIE_NOTSKIPPED						= L.DBM .. " has detected a skipable cut scene but has NOT skipped it due to a blizzard bug. When this bug is fixed, skipping will be re-enabled"
L.BONUS_SKIPPED							= L.DBM .. " has automatically closed bonus loot frame. If you need to get this frame back, type /dbmbonusroll within 3 minutes"

L.AFK_WARNING							= "Uzaktasınız (AFK) ve savaştasınız (canınızın yüzde %d kaldı), sesli uyarı çalınıyor. Uzakta değilseniz AFK durumunu kaldırın veya bu seçeneği 'ek özellikler' bölümünden kapatın."
L.LOWHEALTH_WARNING						= "Düşük can (canınızın yüzde %d kaldı), sesli uyarı çalınıyor. Bu seçeneği 'ek özellikler' bölümünden kapatabilirsiniz."
L.ENTERING_COMBAT						= "Savaşa giriliyor"
L.LEAVING_COMBAT						= "Savaştan çıkılıyor"

L.RAID_DIFFICULTY_CHANGED				= "Raid zorluğu %s olarak ayarlandı."
L.DUNGEON_DIFFICULTY_CHANGED			= "Zindan zorluğu %s olarak ayarlandı."

L.PROFILE_NOT_FOUND						= "<" .. L.DBM .. "> Your current profile is corrupted. " .. L.DBM .. " will load '%s' profile."
L.PROFILE_CREATED						= "'%s' profili oluşturuldu."
L.PROFILE_CREATE_ERROR					= "Profil oluşturulamadı. Geçersiz profil adı."
L.PROFILE_CREATE_ERROR_D				= "Profil oluşturulamadı. '%s' profili zaten var."
L.PROFILE_APPLIED						= "'%s' profili uygulandı."
L.PROFILE_APPLY_ERROR					= "Profil uygulanamadı. '%s' profili yok."
L.PROFILE_COPIED						= "'%s' profili kopyalandı."
L.PROFILE_COPY_ERROR					= "Profil kopyalanamadı. '%s' profili yok."
L.PROFILE_COPY_ERROR_SELF				= "Profil kendisine kopyalanamaz."
L.PROFILE_DELETED						= "'%s' profili silindi. '%s' profili uygulanacak."
L.PROFILE_DELETE_ERROR					= "Profil silinemedi. '%s' profili yok."
L.PROFILE_CANNOT_DELETE					= "'%s' profili silinemez."
L.MPROFILE_COPY_SUCCESS					= "%s (%d uzmanlık) mod ayarları kopyalandı."
L.MPROFILE_COPY_SELF_ERROR				= "Karakter ayarları kendisine kopyalanamaz"
L.MPROFILE_COPY_S_ERROR					= "Kaynak bozuk. Ayarlar kopyalanmadı veya kısmen kopyalandı. Kopyalama başarısız."
L.MPROFILE_COPYS_SUCCESS				= "%s (%d uzmanlık) mod ses veya not ayarları kopyalandı."
L.MPROFILE_COPYS_SELF_ERROR				= "Karakter ses veya not ayarları kendisine kopyalanamaz"
L.MPROFILE_COPYS_S_ERROR				= "Kaynak bozuk. Ses veya not ayarları kopyalanmadı veya kısmen kopyalandı. Kopyalama başarısız."
L.MPROFILE_DELETE_SUCCESS				= "%s (%d uzmanlık) mod ayarları silindi."
L.MPROFILE_DELETE_SELF_ERROR			= "Kullanımdaki mod ayarları silinemez."
L.MPROFILE_DELETE_S_ERROR				= "Kaynak bozuk. Ayarlar silinmedi veya kısmen silindi. Silme başarısız."

L.NOTE_SHARE_SUCCESS					= "%s, %s için notunu paylaştı"
L.NOTE_SHARE_LINK						= "Notu Açmak İçin Tıklayın"
L.NOTE_SHARE_FAIL						= "%s sizinle %s için not paylaşmaya çalıştı. Ancak bu yetenekle ilgili mod kurulu değil veya yüklenmemiş. Bu nota ihtiyacınız varsa ilgili modu yükleyin ve tekrar paylaşmasını isteyin"

L.NOTEHEADER							= "%s için not metninizi buraya girin. Bir oyuncu adını >< içine almak onu sınıf rengiyle gösterir. Birden çok sayımlı uyarılar için notları '/' ile ayırın"
L.NOTEFOOTER							= "Değişiklikleri kabul etmek için 'Tamam', reddetmek için 'İptal' düğmesine basın"
L.NOTESHAREDHEADER						= "%s, %s için aşağıdaki notu paylaştı. Kabul ederseniz mevcut notunuzun üzerine yazılacak"
L.NOTESHARED							= "Notunuz gruba gönderildi"
L.NOTESHAREERRORSOLO					= "Yalnız mısınız? Kendinize not göndermemelisiniz"
L.NOTESHAREERRORBLANK					= "Boş not paylaşılamaz"
L.NOTESHAREERRORGROUPFINDER				= "Notlar savaş alanlarında, LFR veya LFG'de paylaşılamaz"
L.NOTESHAREERRORALREADYOPEN				= "Not düzenleyici açıkken paylaşılan not bağlantısı açılamaz; böylece düzenlediğiniz notu kaybetmezsiniz"

L.ALLMOD_DEFAULT_LOADED					= "Bu zindandaki tüm modlar için varsayılan seçenekler yüklendi."
L.ALLMOD_STATS_RESETED					= "Tüm mod istatistikleri sıfırlandı."
L.MOD_DEFAULT_LOADED					= "Bu savaş için varsayılan seçenekler yüklendi."

L.WORLDBOSS_ENGAGED						= "%s sunucunuzda muhtemelen yüzde %s canla savaşa girdi. (Gönderen: %s)"
L.WORLDBOSS_DEFEATED					= "%s sunucunuzda muhtemelen yenildi (Gönderen: %s)."
L.WORLDBUFF_STARTED						= "%s güçlendirmesi sunucunuzda %s fraksiyonu için başladı (Gönderen: %s)."

L.TIMER_FORMAT_SECS						= "%.2f saniye"
L.TIMER_FORMAT_MINS						= "%d dakika"
L.TIMER_FORMAT							= "%d dakika %.2f saniye"

L.MIN									= "dk"
L.MIN_FMT								= "%d dk"
L.SEC									= "sn"
L.SEC_FMT								= "%s sn"

L.GENERIC_WARNING_OTHERS				= "ve bir kişi daha"
L.GENERIC_WARNING_OTHERS2				= "ve %d kişi daha"
L.GENERIC_TRASH_TARGET					= "%s: %s"
L.GENERIC_WARNING_BERSERK				= "%s %s içinde Öfkelenme"
L.GENERIC_TIMER_BERSERK					= "Öfkelenme"
L.OPTION_TIMER_BERSERK					= "$spell:26662 için zamanlayıcı göster"
L.BAD									= "Kötü"

L.OPTION_CATEGORY_TIMERS				= "Çubuklar"
--Sub cats for "announce" object
L.OPTION_CATEGORY_WARNINGS				= "Genel Duyurular"
L.OPTION_CATEGORY_WARNINGS_YOU			= "Kişisel Duyurular"
L.OPTION_CATEGORY_WARNINGS_OTHER		= "Hedef Duyuruları"
L.OPTION_CATEGORY_WARNINGS_ROLE			= "Rol Duyuruları"
L.OPTION_CATEGORY_SPECWARNINGS			= "Özel Duyurular"

L.OPTION_CATEGORY_SOUNDS				= "Sesler"
--Misc object broken down into sub cats
L.OPTION_CATEGORY_DROPDOWNS				= "Açılır Menüler"--Still put in MISC sub grooup, just used for line separators since multiple of these on a fight (or even having on of these at all) is rare.
L.OPTION_CATEGORY_YELLS					= "Yells"
L.OPTION_CATEGORY_NAMEPLATES			= "İsim Plakaları"
L.OPTION_CATEGORY_ICONS					= "Simgeler"
L.OPTION_CATEGORY_PAURAS				= "Özel\nAuralar"

L.AUTO_RESPONDED						= "Auto-responded."
L.STATUS_WHISPER						= "%s: %s, %d/%d people alive"
--Bosses
L.AUTO_RESPOND_WHISPER					= "%s is busy fighting against %s (%s, %d/%d people alive)"
L.WHISPER_COMBAT_END_KILL				= "%s has defeated %s!"
L.WHISPER_COMBAT_END_KILL_STATS			= "%s has defeated %s! They have %d total victories."
L.WHISPER_COMBAT_END_WIPE_AT			= "%s has wiped on %s at %s"
L.WHISPER_COMBAT_END_WIPE_STATS_AT		= "%s has wiped on %s at %s. They have %d total wipes on this difficulty."
--Scenarios (no percents. words like "fighting" or "wipe" changed to better fit scenarios)
L.AUTO_RESPOND_WHISPER_SCENARIO			= "%s is busy in %s (%d/%d people alive)"
L.WHISPER_SCENARIO_END_KILL				= "%s has completed %s!"
L.WHISPER_SCENARIO_END_KILL_STATS		= "%s has completed %s! They have %d total victories."
L.WHISPER_SCENARIO_END_WIPE				= "%s did not complete %s"
L.WHISPER_SCENARIO_END_WIPE_STATS		= "%s did not complete %s. They have %d total incompletes on this difficulty."

L.DUNGEONS								= "Zindanlar: "--prefix for dungeons version check
L.VERSIONCHECK_HEADER					= "Boss Modu - Sürümler"
L.VERSIONCHECK_ENTRY					= "%s: %s (%s) %s"--One Boss mod -- OPTIONAL
L.VERSIONCHECK_ENTRY_TWO				= "%s: %s (%s) & %s (%s)"--Two Boss mods -- OPTIONAL
L.VERSIONCHECK_ENTRY_NO_DBM				= "%s: No boss mod installed"
L.VERSIONCHECK_FOOTER					= "" .. L.DBM .. " kullanan %d oyuncu ve Bigwigs kullanan %d oyuncu bulundu"
L.VERSIONCHECK_OUTDATED					= "Şu %d oyuncunun boss modu sürümü eski: %s"
L.YOUR_VERSION_OUTDATED     			= "" .. L.DEADLY_BOSS_MODS .. " sürümünüz güncel değil. Lütfen en son sürümü Curse, Wago, WoWI ya da GitHub Releases sayfasından indirin."
L.VOICE_PACK_OUTDATED					= "Seçtiğiniz " .. L.DBM .. " ses paketinde, şu eklentinin desteklediği bazı sesler eksik: " .. L.DBM .. ". Bazı uyarılar hâlâ varsayılan sesleri çalacak. Lütfen ses paketinin yeni sürümünü indirin ya da eksik sesler için paket yazarıyla iletişime geçin"
L.VOICE_MISSING							= "Seçili bir " .. L.DBM .. " ses paketi bulunamadı. Bu bir hataysa ses paketinin doğru kurulduğundan ve eklentilerde açık olduğundan emin olun."
L.VOICE_DISABLED						= "En az bir " .. L.DBM .. " ses paketi yüklü ama hiçbiri açık değil. Ses paketi kullanacaksanız 'Sesli Uyarılar' bölümünde seçili olduğundan emin olun; aksi hâlde bu mesajı gizlemek için kullanılmayan ses paketlerini kaldırın"
L.VOICE_COUNT_MISSING					= "Geri sayım sesi %d bulunamayan veya şu an desteklenmeyen bir ses paketine ayarlı. Varsayılana döndürüldü: %s."
L.BIG_WIGS								= "BigWigs" -- OPTIONAL
L.WEAKAURA_KEY							= " (|cff359030ID:|r %s)"
L.RENAME								= " (|cff359030Yeni Ad:|r |cff71d5ff%s|r)"

L.UPDATEREMINDER_HEADER					= "" .. L.DEADLY_BOSS_MODS.. " sürümünüz güncel değil.\n%s (%s) sürümü Curse, Wago, WoWI ya da GitHub Releases sayfasından indirilebilir"
L.UPDATEREMINDER_HEADER_SUBMODULE		= "%s modülünüz güncel değil.\nSürüm %s Curse, Wago, WoWI veya GitHub Releases sayfasından indirilebilir"
L.UPDATEREMINDER_FOOTER					= "" .. (IsMacClient() and "Cmd-C" or "Ctrl-C")  ..  " tuşlarına basarak indirme bağlantısını panoya kopyala."
L.UPDATEREMINDER_FOOTER_GENERIC			= "" .. (IsMacClient() and "Cmd-C" or "Ctrl-C")  ..  " tuşlarına basarak panoya kopyala."
L.UPDATEREMINDER_DISABLE				= "UYARI: " .. L.DEADLY_BOSS_MODS.. " sürümünüz eski olduğu ve mevcut oyun sürümüyle ya da DBM'nin yeni sürümleriyle uyumsuz olduğu için zorla kapatıldı; güncellenene kadar kullanılamaz. Bu, uyumsuz modların sana ve grup arkadaşlarına kötü oyun deneyimi yaşatmaması içindir."
L.UPDATEREMINDER_DISABLETEST			= "UYARI: " .. L.DEADLY_BOSS_MODS.. " sürümünüz eski olduğu ve bu bir test/beta sunucusu olduğu için zorla kapatıldı; güncellenene kadar kullanılamaz. Bu, eski modlarla test geri bildirimi üretilmemesi içindir"
L.UPDATEREMINDER_HOTFIX					= L.DBM .. " sürümünüzde bu boss savaşında bilinen sorunlar var; en son sürüme güncellerseniz düzelir"
L.UPDATEREMINDER_HOTFIX_ALPHA			= L.DBM .. " sürümünüzde bu boss savaşında bilinen sorunlar var; gelecek sürümde (ya da en son alfa sürümünde) düzeltildi"
L.UPDATEREMINDER_MAJORPATCH				= "UYARI: " .. L.DEADLY_BOSS_MODS.. " sürümünüz eski olduğu için " .. L.DBM .. " büyük bir oyun yaması nedeniyle güncellenene kadar kapatıldı. Bu, eski ve uyumsuz kodun sana ve grup arkadaşlarına kötü oyun deneyimi yaşatmaması içindir. En kısa sürede Curse, Wago, WoWI ya da GitHub Releases sayfasından yeni sürümü indirin."
L.VEM									= "UYARI: Hem " .. L.DEADLY_BOSS_MODS.. " hem de Voice Encounter Mods çalışıyor. DBM bu yapılandırmada çalışmaz, bu yüzden yüklenmeyecek."
L.OUTDATEDPROFILES						= "UYARI: DBM-Profiles şu sürümle uyumlu değil: " .. L.DBM .. ". Çakışmayı önlemek için DBM devam etmeden önce kaldırılmalı."
L.OUTDATEDSPELLTIMERS					= "UYARI: DBM-SpellTimers şunu bozuyor: " .. L.DBM .. "; düzgün çalışması için kapatılmalı: " .. L.DBM .. "."
L.OUTDATEDRLT							= "UYARI: DBM-RaidLeadTools şunu bozuyor: " .. L.DBM .. ". DBM-RaidLeadTools artık desteklenmiyor; düzgün çalışması için kaldırılmalı: " .. L.DBM .. "."
L.VICTORYSOUND							= "UYARI: DBM-VictorySound şu sürümle uyumlu değil: " .. L.DBM .. ". Çakışmayı önlemek için devam etmeden önce kaldırılmalı: " .. L.DBM .. "."
L.DPMCORE								= "UYARI: Deadly PvP mods artık geliştirilmiyor ve şu sürümle uyumlu değil: " .. L.DBM .. ". Çakışmayı önlemek için devam etmeden önce kaldırılmalı: " .. L.DBM .. "."
L.DBMLDB								= "UYARI: DBM-LDB artık DBM-Core içinde yerleşik. Zararı olmasa da 'DBM-LDB' klasörünü eklentiler klasörünüzden kaldırmanız önerilir"
L.DBMLOOTREMINDER						= "UYARI: Üçüncü taraf DBM-LootReminder yüklü. Bu eklenti artık Retail WoW istemcisiyle uyumlu değil ve şunun bozulmasına yol açacak: " .. L.DBM .. " (çekiş sayaçları gönderilemez). Bu eklentiyi kaldırmanız önerilir"
L.UPDATE_REQUIRES_RELAUNCH				= "UYARI: Bu " .. L.DBM .. " güncellemesi oyunu tamamen yeniden başlatmazsanız düzgün çalışmaz. Bu güncelleme ReloadUI ile yüklenemeyen yeni dosyalar ya da .toc değişiklikleri içeriyor. Yeniden başlatmadan devam ederseniz hatalarla karşılaşabilirsiniz."
L.OUT_OF_DATE_NAG						= "" .. L.DBM.. " sürümünüz güncel değil ve bu savaş modunun yeni özellikleri ya da hata düzeltmeleri var. Bu savaş için güncellemeniz önerilir."
L.PLATER_NP_AURAS_MSG					= L.DBM .. " includes an advanced feature to show enemy cooldown timers using icons on nameplates. This is on by default for most users, but for Plater users it is off by default in Plater options unless you enable it. To get the most out of DBM (and Plater) it's recommended you enable this feature in Plater under 'Buff Special' section. If you don't want to see this message again, you can also just entirely disable 'Cooldown icons on nameplates' option in DBM global disable or nameplate options panels"
L.HARDCODED_FALLBACK					= L.DBM .. " bu sabit kodlu boss modunda beklenmeyen bir sonuç algıladı. " .. L.DBM .. " bu savaş için Blizzard sayaçlarına ve uyarılarına geri dönecek."

L.MOVABLE_BAR							= "Sürükle beni!"
L.MOVABLE_FRAMES						= "Pencereler Sürüklenebilir"

L.PIZZA_SYNC_INFO						= "|Hplayer:%1$s|h[%1$s]|h sana bir " .. L.DBM .. " sayacı gönderdi: '%2$s'\n|Haddon:DBM:cancel:%2$s:nil|h|cff3588ff[Bu sayacı iptal et]|r|h  |Haddon:DBM:ignore:%2$s:%1$s|h|cff3588ff[%1$s sayaçlarını yok say]|r|h"
--L.PIZZA_SYNC_INFO						= "|Hplayer:%1$s|h[%1$s]|h sana bir " .. L.DBM .. " timer"
L.PIZZA_CONFIRM_IGNORE					= "Bu oturum boyunca %s oyuncusundan gelen " .. L.DBM .. " sayaçlarını gerçekten yok saymak istiyor musun?"
L.PIZZA_ERROR_USAGE						= "Kullanım: /dbm [broadcast] timer <süre> <yazı>. <süre> 3 veya daha büyük olmalı."

L.MINIMAP_TOOLTIP_HEADER				= L.DEADLY_BOSS_MODS --Technically redundant -- OPTIONAL
L.MINIMAP_TOOLTIP_FOOTER				= "Taşımak için Shift'e basılı tutup sürükleyin"

L.RANGE_TEST_READY						= "Eşya menzil testi (%s): %d eşya için veri isteniyor. Birimi seçili tutun ve savaş dışında kalın."
L.RANGE_TEST_INVALID					= "Eşya menzil testi canlı, görünür dost veya düşman bir birim gerektirir ve savaş dışında yapılmalıdır."
L.RANGE_TEST_UNSUPPORTED				= "Eşya menzil testi: eşya menzili veya eşya önbelleği API'leri bu istemcide yok."
L.RANGE_TEST_ABORTED					= "Eşya menzil testi iptal edildi: birim değişti, kullanılamaz oldu veya savaş/yükleme başladı."
L.RANGE_TEST_PASS						= "%d metre: eşya %d (%s), IsItemInRange=%s%s"
L.RANGE_TEST_FAIL						= "%d metre: kullanılabilir eşya yok (önbellek nil: %d, önbellek hatası/zaman aşımı: %d)."
L.RANGE_TEST_INCOMPLETE					= "%d metre: eksik (önbellek nil: %d, önbellek hatası/zaman aşımı: %d)."
L.RANGE_TEST_PARTIAL					= " (önceki adaylar önbelleğe alınamadı)"
L.RANGE_TEST_HEADER						= "DBM eşya menzil sonuçları (%s). Bu metni kopyalayın; menzillere +3 metre dahildir."
L.RANGE_TEST_NODATA						= "Tamamlanmış eşya menzil testi yok. Önce DBM:TestRanges çalıştırın."
L.RANGE_TEST_DONE						= "Eşya menzil testi bitti: %d başarılı, %d başarısız, %d eksik. Sonuçları kopyalamak için DBM:ShowRangeTestResults() kullanın."
L.RANGE_TEST_SELF						= "Kendinizi test etmek bu eşyaların başka oyuncuda çalıştığını göstermez."
L.RANGE_DISTANCE_NOCANDIDATES			= "Mesafelerini ölçmeden önce DBM:TestRanges çalıştırın ve kullanılabilir eşyaları bekleyin."
L.RANGE_DISTANCE_INVALID				= "Mesafe ayarı savaş dışında, kısıtlamasız haritada başka bir canlı, görünür birim gerektirir. Açık alanda bir grup/Raid oyuncusu önerilir."
L.RANGE_DISTANCE_UNAVAILABLE			= "Mesafe ayarı: denetlenmiş, gizli olmayan UnitDistanceSquared okumaları veya eşya menzil API'leri yok. Açık alanda bir grup/Raid oyuncusuyla deneyin."
L.RANGE_DISTANCE_READY					= "%d eşya ölçülüyor (tolerans +/-0.5 metre). Diğer oyuncu yerinde dursun; sınırlardan yavaşça dışarı ve geri yürüyün. Durdurmak/dışa aktarmak için DBM:StopRangeDistances(true)."
L.RANGE_DISTANCE_REACQUIRE				= "Menzil ayarına devam etmek için asıl hedefinizi yeniden seçin."
L.RANGE_DISTANCE_ABORTED				= "Mesafe ayarı iptal edildi: birim, savaş, yükleme, kısıtlama veya mesafe durumu değişti. Kısmi veriler tutuldu; BAŞARILI sonuç yok."
L.RANGE_DISTANCE_NODATA					= "Durdurulmuş mesafe ayarı yok. DBM:TestRangeDistances ardından DBM:StopRangeDistances çalıştırın."
L.RANGE_DISTANCE_HEADER					= "DBM mesafe ayarı. Bu metni kopyalayın; beklenen menzillere +3 metre dahildir, +/-0.5 metre tolerans."
L.RANGE_DISTANCE_ROW					= "%d metre: eşya %d (%s), %s; en uzak doğru=%s, en yakın yanlış=%s; doğru/yanlış=%d/%d, uyuşmazlık=%d, kullanılamayan=%d%s"
L.RANGE_DISTANCE_PASS					= "BAŞARILI"
L.RANGE_DISTANCE_FAIL					= "BAŞARISIZ"
L.RANGE_DISTANCE_INCOMPLETE				= "EKSİK (yetersiz sınır kapsamı, çelişkili okumalar, kullanılamayan örnekler veya iptal edilen çalışma)"
L.RANGE_DISTANCE_DONE					= "Mesafe ayarı durdu: %d başarılı, %d başarısız, %d eksik. Sonuçları kopyalamak için DBM:ShowRangeDistanceResults() kullanın."

L.RANGECHECK_HEADER						= "Menzil Kontrolü (%dm)"
L.RANGECHECK_HEADERT					= "Menzil Kontrolü (%dm-%dO)"
L.RANGECHECK_RHEADER					= "T-Menzil Kontrolü (%dm)"
L.RANGECHECK_RHEADERT					= "T-Menzil Kontrolü (%dm-%dO)"
L.RANGECHECK_SETRANGE					= "Menzili ayarla"
L.RANGECHECK_SETTHRESHOLD				= "Oyuncu eşiğini ayarla"
L.RANGECHECK_SOUNDS						= "Sesler"
L.RANGECHECK_SOUND_OPTION_1				= "Bir oyuncu menzildeyken ses"
L.RANGECHECK_SOUND_OPTION_2				= "Birden fazla oyuncu menzildeyken ses"
L.RANGECHECK_SOUND_0					= "Ses yok"
L.RANGECHECK_SOUND_1					= "Varsayılan ses"
L.RANGECHECK_SOUND_2					= "Rahatsız edici bip"
L.RANGECHECK_SETRANGE_TO				= "%d y"
L.RANGECHECK_OPTION_FRAMES				= "Çerçeveler"
L.RANGECHECK_OPTION_RADAR				= "Radar penceresini göster"
L.RANGECHECK_OPTION_TEXT				= "Yazı penceresini göster"
L.RANGECHECK_OPTION_BOTH				= "İki pencereyi de göster"
L.RANGERADAR_HEADER						= "Menzil:%d Oyuncu:%d"
L.RANGERADAR_RHEADER					= "T-Mnz:%d Oyuncu:%d"
L.RANGERADAR_IN_RANGE_TEXT				= "%d menzilde (%0.1fm)"--Multi
L.RANGECHECK_IN_RANGE_TEXT				= "%d menzilde"--Text based doesn't need (%dyd), especially since it's not very accurate to the specific yard anyways
L.RANGERADAR_IN_RANGE_TEXTONE			= "%s (%0.1fm)"--One target

L.INFOFRAME_TITLE						= "DBM Bilgi Penceresi"
L.INFOFRAME_BOSS_DISTANCE				= "Boss Uzaklığı"
L.INFOFRAME_BOSS_DISTANCE_RANGE			= GetLocale() == "enUS" and "%dy - %dy" or "%dm - %dm"
L.INFOFRAME_BOSS_DISTANCE_OVER			= GetLocale() == "enUS" and "> %dy" or "> %dm"
L.INFOFRAME_SHOW_SELF					= "Gücünüzü her zaman göster"		-- Always show your own power value even if you are below the threshold
L.INFOFRAME_SETLINES					= "En fazla satırı ayarla"
L.INFOFRAME_SETCOLS						= "En fazla sütunu ayarla"
L.INFOFRAME_SETSTRATA					= "Pencere katmanını ayarla"
L.INFOFRAME_LINESDEFAULT				= "Boss modüllerince otomatik ayarla"
L.INFOFRAME_LINES_TO					= "%d satır"
L.INFOFRAME_COLS_TO						= "%d sütun"
L.INFOFRAME_POWER						= "Güç"
L.INFOFRAME_AGGRO						= "Tehdit"
L.INFOFRAME_MAIN						= "Ana:"--Main power
L.INFOFRAME_ALT							= "Alt:"--Alternate Power

L.LFG_INVITE							= "LFG Daveti"

--Common slash commands
L.SLASHCMD_HELP							= {
	"Available slash commands:",
	"-----------------",
	"/dbm unlock: Shows a movable status bar timer (alias: move).",
	"/dbm pull <sec>: Sends a pull timer for <sec> seconds to the raid (requires promoted. alias: pull).",
	"/dbm break <min>: Sends a break timer for <min> minutes to the raid (requires promoted. alias: break).",
	"/dbm midwizard: Shows midnight setup wizard again (retail only).",
	"/dbm timer: Starts a custom " .. L.DBM .. " timer, see '/dbm timer' for details.",
	"/dbm key: Performs M+ keystone and rating checks on party/guild and shortcuts to dungeon teleports. (alias: key, keys, keystone)",
	"/dbm lag: Performs a raid-wide latency check.",
	"/dbm durability: Performs a raid-wide durability check.",
	"/dbm consumables: Performs a raid-wide consumables check (alias: cons, consumes).",
	"/dbm brez: Shows the battle resurrection timer frame for positioning.",
	"/dbm help2: Shows additional slash commands"
}
L.SLASHCMD_HELP_CLASSIC							= {
	"Available slash commands:",
	"-----------------",
	"/dbm unlock: Shows a movable status bar timer (alias: move).",
	"/dbm pull <sec>: Sends a pull timer for <sec> seconds to the raid (requires promoted. alias: pull).",
	"/dbm break <min>: Sends a break timer for <min> minutes to the raid (requires promoted. alias: break).",
	"/dbm timer: Starts a custom " .. L.DBM .. " timer, see '/dbm timer' for details.",
	"/dbm lag: Performs a raid-wide latency check.",
	"/dbm durability: Performs a raid-wide durability check.",
	"/dbm help2: Shows additional slash commands"
}
--Less used slash commands
L.SLASHCMD_HELP2						= {
	"Available slash commands:",
	"-----------------",
	"/dbm version: Performs a boss mod version check (alias: ver).",
	"/dbm version2: Performs a boss mod version check that also whispers out of date users (alias: ver2).",
	"/range <number> or /distance <number>: Shows range frame. /rrange or /rdistance to reverse colors.",
	"/dbm arrow: Shows the " .. L.DBM .. " arrow, see '/dbm arrow help' for details.",
	"/dbm hud: Shows the " .. L.DBM .. " hud, see '/dbm hud' for details.",
	"/dbm dbtdebug: Shows sanitized status bar timer diagnostics for bug reports."
}
L.DBT_DEBUG_HEADER						= "DBT tanılama (temizlenmiş; savaş veya gizli metin yok)"
L.DBT_DEBUG_EMPTY						= "Bu arayüz yenilemesinden beri DBT stil yenilemesi yakalanmadı."
L.DBT_DEBUG_DISABLED					= "Yakalama kapalı. Sorunu tekrarlamadan önce DBM Hata Ayıklama Modunu açın."
L.DBT_DEBUG_NOTICE						= "Lütfen hata raporunuza bu sohbet çıktısını ekleyin."
L.TIMER_USAGE							= {
	L.DBM .. " timer commands:",
	"-----------------",
	"/dbm timer <sec> <text>: Starts a <sec> second timer with your <text>.",
	"/dbm ltimer <sec> <text>: Starts a timer that also automatically loops until canceled.",
	"('Broadcast' in front of the 'timer' or 'ltimer' also shares it with raid if leader/promoted)",
	"/dbm timer endloop: Stops any looping ltimer."
}

L.ERROR_NO_PERMISSION					= "Çekme/mola zamanlayıcısı göndermek için gerekli yetkiniz yok."
L.ERROR_NO_PERMISSION_COMBAT			= "Savaş sürerken Çekme/Mola zamanlayıcısı gönderilemez"
L.PULL_TIME_TOO_SHORT					= "Çekme zamanlayıcısı 3 saniyeden uzun olmalı."
L.PULL_TIME_TOO_LONG					= "Çekme zamanlayıcısı 60 saniyeden uzun olamaz. Onun yerine /break zamanlayıcısı kullanmayı düşünün."

L.BREAK_USAGE							= "Mola zamanlayıcısı 60 dakikadan uzun olamaz. Süreyi saniye değil dakika olarak girdiğinizden emin olun."
L.BREAK_START							= "Mola şimdi başlıyor -- %s süreniz var! (Gönderen: %s)"
L.BREAK_MIN								= "Mola %s dakika sonra bitiyor!"
L.BREAK_SEC								= "Mola %s saniye sonra bitiyor!"
L.TIMER_BREAK							= "Mola zamanı!"
L.ANNOUNCE_BREAK_OVER					= "Mola %s itibarıyla bitti"

L.TIMER_PULL							= "Çekiliyor"
L.ANNOUNCE_PULL							= "%d sn sonra çekiliyor. (Gönderen: %s)"
L.ANNOUNCE_PULL_NOW						= "Şimdi çek!"
L.ANNOUNCE_PULL_TARGET					= "%s %d sn sonra çekiliyor. (Gönderen: %s)"
L.ANNOUNCE_PULL_NOW_TARGET				= "%s şimdi çekiliyor!"
L.GEAR_WARNING							= "Uyarı: Ekipmanınızı kontrol edin. Kuşanılan eşya seviyeniz çantadakinden %d düşük"
L.GEAR_WARNING_WEAPON					= "Uyarı: Silahınızın doğru kuşanıldığını kontrol edin."
L.GEAR_FISHING_POLE						= "Olta"

L.ACHIEVEMENT_TIMER_SPEED_KILL			= "Başarım"--BATTLE_PET_SOURCE_6

-- Auto-generated Warning Localizations
L.AUTO_ANNOUNCE_TEXTS = {
	you									= "%s SENDE",
	target								= "%s >%%s< üzerinde",
	targetsource						= ">%%s<, >%%s< üzerine %s yaptı",
	targetcount							= "%s (%%s) >%%s< üzerinde",
	blizztarget							= "%s (%%s) %%s üzerinde",--Blizz target has class color preformated, so >< not needed
	spell								= "%s", -- OPTIONAL
	spellsource							= ">%%s< %s yapıyor",
	incoming							= "%s zayıflatması geliyor",
	incomingcount						= "%s zayıflatması geliyor (%%s)",
	ends 								= "%s bitti",
	endtarget							= "%s bitti: >%%s<",
	fades								= "%s kalktı",
	fadesoon							= "%s yakında kalkıyor",
	addsleft							= "%s kalan: %%d",
	cast								= "%s yapılıyor: %.1f sn",
	soon								= "%s yakında",
	sooncount							= "%s (%%s) yakında",
	countdown							= "%s %%ds içinde",
	prewarn								= "%s %s içinde",
	bait								= "%s yakında - şimdi yemle",
	stage								= "Aşama %s",
	prestage							= "Aşama %s yakında",
	count								= "%s (%%s)", -- OPTIONAL
	stack								= "%s >%%s< üzerinde (%%d)",
	moveto								= "%s - >%%s< yanına git"
}

local prewarnOption						= "$spell:%s için ön uyarı göster"
L.AUTO_ANNOUNCE_OPTIONS = {
	you									= "$spell:%s sende olunca duyur",
	target								= "$spell:%s hedeflerini duyur",
	targetNF							= "$spell:%s hedeflerini duyur (genel hedef süzgecini yok sayar)",
	targetsource						= "$spell:%s hedeflerini duyur (kaynakla)",
	targetcount							= "$spell:%s hedeflerini duyur (sayımla)",
	blizztarget							= "$spell:%s hedeflerini duyur (sayımla)",
	spell								= "$spell:%s yapıldığında duyur",
	spellsource							= "$spell:%s yapıldığında duyur (kaynakla)",
	incoming							= "$spell:%s zayıflatmaları gelirken duyur",
	incomingcount						= "$spell:%s zayıflatmaları gelirken duyur (sayımla)",
	ends								= "$spell:%s bittiğinde duyur",
	endtarget							= "$spell:%s bittiğinde duyur (hedefle)",
	fades								= "$spell:%s kalktığında duyur",
	fadesoon							= "$spell:%s yakında kalkacağında duyur",
	addsleft							= "Kaç $spell:%s kaldığını duyur",
	cast								= "$spell:%s yapılmaya başlandığında duyur",
	soon								= prewarnOption,
	sooncount							= "$spell:%s için ön uyarı göster (sayımla)",
	countdown							= "$spell:%s için ön uyarı geri sayımı göster",
	prewarn 							= prewarnOption,
	bait								= "$spell:%s için ön uyarı göster (yemleme)",
	stage								= "Aşama %s duyur",
	stagechange							= "Aşama değişikliklerini duyur",
	prestage							= "Aşama %s için ön uyarı göster",
	count								= "$spell:%s yapıldığında duyur (sayımla)",
	stack								= "$spell:%s yığınlarını duyur",
	moveto								= "$spell:%s için birinin yanına veya bir yere gitme zamanını duyur"
}

L.AUTO_SPEC_WARN_TEXTS = {
	spell								= "%s!", -- OPTIONAL
	ends								= "%s bitti",
	endtarget							= "%s bitti: >%%s<",
	fades								= "%s kalktı",
	soon								= "%s yakında",
	sooncount							= "%s (%%s) yakında",
	bait								= "%s yakında - şimdi yemle",
	prewarn								= "%s %s içinde",
	dispel								= "%s >%%s< üzerinde - şimdi arındır",
	interrupt							= "%s - >%%s< kes!",
	interruptcount						= "%s - >%%s< kes! (%%d)",
	you									= "%s sende",
	youcount							= "%s (%%s) sende",
	youpos								= "%s (Konum: %%s) sende",
	youposcount							= "%s (%%s) (Konum: %%s) sende",
	soakpos								= "%s (Emme Konumu: %%s)",
	target								= "%s >%%s< üzerinde",
	targetcount							= "%s (%%s) >%%s< üzerinde ",
	blizztarget							= "%s (%%s) >%%s< üzerinde ",
	blizzyou							= "%s (%%s) sende",
	link								= "%s, >%%s< ile bağlandı",
	defensive							= "%s - savunma",
	taunt								= "%s >%%s< üzerinde - şimdi kışkırt",
	close								= "%s yakınındaki >%%s< üzerinde",
	move								= "%s - uzaklaş",
	keepmove							= "%s - hareket etmeye devam et",
	stopmove							= "%s - hareketi durdur",
	dodge								= "%s - saldırıdan kaç",
	dodgecount							= "%s (%%s) - saldırıdan kaç",
	dodgeloc							= "%s - %%s yönünden kaç",
	moveaway							= "%s - diğerlerinden uzaklaş",
	moveawaycount						= "%s (%%s) - diğerlerinden uzaklaş",
	moveawaytarget						= "%s - %%s yanından uzaklaş",
	moveto								= "%s - >%%s< yanına git",
	soak								= "%s - üstüne gir",
	soakcount							= "%s - üstüne gir (%%s)",
	jump								= "%s - zıpla",
	run									= "%s - kaç",
	runcount							= "%s - kaç (%%s)",
	cast								= "%s - büyüyü durdur",
	lookaway							= "%s %%s üzerinde - başka yöne bak",
	reflect								= "%s >%%s< üzerinde - saldırıyı durdur",
	count								= "%s! (%%s)", -- OPTIONAL
	stack								= "Sende %%d yığın %s",
	switch								= "%s - hedef değiştir",
	switchcount							= "%s - hedef değiştir (%%s)",
	switchcustom						= "%s - hedef değiştir (%%s)",
	gtfo								= "%%s hasarı - uzaklaş",
	adds								= "Ek düşmanlar geliyor - hedef değiştir",--Basically a generic of switch
	addscount							= "Ek düşmanlar geliyor - hedef değiştir (%%s)",--Basically a generic of switch
	addscustom							= "Ek düşmanlar geliyor - %%s",--Same as above, but more info, pretty much made for like 3 boss mods, such as akama
	targetchange						= "Hedef Değişikliği - %%s hedefine geç"
}

-- Auto-generated Special Warning Localizations
L.AUTO_SPEC_WARN_OPTIONS = {
	spell 								= "$spell:%s için özel uyarı göster",
	ends 								= "$spell:%s bittiğinde özel uyarı göster",
	endtarget							= "$spell:%s bittiğinde özel uyarı göster (hedefle)",
	fades 								= "$spell:%s kalktığında özel uyarı göster",
	soon 								= "$spell:%s için özel ön uyarı göster",
	sooncount							= "$spell:%s için özel ön uyarı göster (sayımla)",
	bait								= "$spell:%s için özel ön uyarı göster (yemleme)",
	prewarn 							= "$spell:%s öncesinde %s saniye özel ön uyarı göster",
	dispel 								= "$spell:%s arındırmak için özel uyarı göster",
	interrupt							= "$spell:%s kesmek için özel uyarı göster",
	interruptcount						= "$spell:%s kesmek için özel uyarı göster (sayımla)",
	you 								= "$spell:%s sizi etkilediğinde özel uyarı göster",
	youcount							= "$spell:%s sizi etkilediğinde özel uyarı göster (sayımla)",
	youpos								= "$spell:%s sizi etkilediğinde özel uyarı göster (konumla)",
	youposcount							= "$spell:%s sizi etkilediğinde özel uyarı göster (konum ve sayımla)",
	soakpos								= "$spell:%s etkisindeki diğerlerine emme yardımı için özel uyarı göster (konumla)",
	target 								= "$spell:%s birini etkilediğinde özel uyarı göster",
	targetcount 						= "$spell:%s birini etkilediğinde özel uyarı göster (sayımla)",
	blizztarget							= "$spell:%s birini etkilediğinde özel uyarı göster (sayımla)",
	blizzyou							= "$spell:%s sizi etkilediğinde özel uyarı göster (sayımla)",
	link								= "$spell:%s sizi başka bir oyuncuya bağladığında özel uyarı göster",
	defensive 							= "$spell:%s için savunma yeteneği kullanma özel uyarısı göster",
	taunt 								= "Diğer tank $spell:%s etkisindeyken kışkırtma özel uyarısı göster (tank uzmanlığında)",
	close 								= "Yakınınızdaki biri $spell:%s etkisindeyken özel uyarı göster",
	move 								= "$spell:%s alanından çıkmak için özel uyarı göster",
	keepmove 							= "$spell:%s için hareket etmeye devam etme özel uyarısı göster",
	stopmove 							= "$spell:%s için hareketi durdurma özel uyarısı göster",
	dodge 								= "$spell:%s kaçınmak için özel uyarı göster",
	dodgecount							= "$spell:%s kaçınmak için özel uyarı göster (sayımla)",
	dodgeloc							= "$spell:%s kaçınmak için özel uyarı göster (konumla)",
	moveaway							= "$spell:%s için diğerlerinden uzaklaşma özel uyarısı göster",
	moveawaycount						= "$spell:%s için diğerlerinden uzaklaşma özel uyarısı göster (sayımla)",
	moveawaytarget						= "$spell:%s için diğerlerinden uzaklaşma özel uyarısı göster (hedefle)",
	moveto								= "$spell:%s için birinin yanına veya bir yere gitme özel uyarısı göster",
	soak								= "$spell:%s için üstüne girme özel uyarısı göster",
	soakcount							= "$spell:%s için üstüne girme özel uyarısı göster (sayımla)",
	jump								= "$spell:%s için zıplama özel uyarısı göster",
	run 								= "$spell:%s kaçmak için özel uyarı göster",
	runcount							= "$spell:%s kaçmak için özel uyarı göster (sayımla)",
	cast 								= "$spell:%s için büyüyü durdurma özel uyarısı göster",--Spell Interrupt
	lookaway							= "$spell:%s için başka yöne bakma özel uyarısı göster",
	reflect 							= "$spell:%s için saldırıyı durdurma özel uyarısı göster",--Spell Reflect
	count 								= "$spell:%s için özel uyarı göster (sayımla)",
	stack 								= "$spell:%s sizde >=%d yığın olduğunda özel uyarı göster",
	switch								= "$spell:%s için hedef değiştirme özel uyarısı göster",
	switchcount							= "$spell:%s için hedef değiştirme özel uyarısı göster (sayımla)",
	switchcustom						= "$spell:%s için hedef değiştirme özel uyarısı göster (bilgiyle)",
	gtfo 								= "Yerdeki kötü alanlardan çıkmak için özel uyarı göster",
	adds								= "Gelen ek düşmanlar için hedef değiştirme özel uyarısı göster",
	addscount							= "Gelen ek düşmanlar için hedef değiştirme özel uyarısı göster (sayımla)",
	addscustom							= "Gelen ek düşmanlar için özel uyarı göster",
	targetchange						= "Öncelikli hedef değişiklikleri için özel uyarı göster"
}

-- Auto-generated Timer Localizations
L.AUTO_TIMER_TEXTS = {
	target								= "%s: %%s", -- OPTIONAL
	targetcount							= "%s (%%2$s): %%1$s", -- OPTIONAL
	cast								= "%s", -- OPTIONAL
	castcount							= "%s (%%s)", -- OPTIONAL
	castsource							= "%s: %%s", -- OPTIONAL
	active								= "%s bitiyor",--Buff/Debuff/event on boss
	fades								= "%s kalkıyor",--Buff/Debuff on players
	ai									= "%s YZ",

	cd									= "%s",--Now same as next, as the ~ was moved to timer number -- OPTIONAL
	cdcount								= "%s (%%s)",--Now same as next, as the ~ was moved to timer number -- OPTIONAL
	cdsource							= "%s: >%%s<",--Now same as next, as the ~ was moved to timer number -- OPTIONAL
	cdspecial							= "Özel",--Now same as next, as the ~ was moved to timer number
	cdcombo								= "%%1$s + %%2$s",--Now same as next, as the ~ was moved to timer number -- OPTIONAL

	next								= "%s", -- OPTIONAL
	nextcount							= "%s (%%s)", -- OPTIONAL
	nextsource							= "%s: >%%s<", -- OPTIONAL
	nextspecial							= "Özel",
	nextcombo							= "%%1$s + %%2$s",--Now same as next, as the ~ was moved to timer number -- OPTIONAL

	var									= "%s",
	varcount							= "%s (%%s)",
	varsource							= "%s: >%%s<",--Now same as next, as the ~ was moved to timer number -- OPTIONAL
	varspecial							= "Özel",--Now same as next, as the ~ was moved to timer number
	varcombo							= "%%1$s + %%2$s",--Now same as next, as the ~ was moved to timer number -- OPTIONAL

	achievement							= "%s", -- OPTIONAL
	stage								= "Aşama",
	stagecount							= "Aşama %%s",--NOT BUGGED, stage is 2nd arg, spellID is ignored on purpose
	stagecountcycle						= "Aşama %%s (%%s)",--^^. Example: Stage 2 (3) for a fight that alternates stage 1 and stage 2, but also tracks total cycles
	stagecontext						= "%s", -- OPTIONAL
	stagecontextcount					= "%s (%%s)", -- OPTIONAL
	intermission						= "Ara Aşama",
	intermissioncount					= "Ara Aşama %%s",
	adds								= "Ek Düşmanlar",
	addscount							= "Ek Düşmanlar (%%s)",
	addscustom							= "Ek Düşmanlar (%%s)",
	roleplay							= GUILD_INTEREST_RP or "Roleplay",--Used mid fight, pre fight, or even post fight. Boss does NOT auto engage upon completion
	combat								= "Savaş başlıyor"--Only used if the boss auto engages upon completion (ie ragnaros type situation)
}
--This basically clones np only bar option and display text from regular counterparts
--TODO, cleanup lots of duplication here and above
L.AUTO_TIMER_TEXTS.cdnp					= L.AUTO_TIMER_TEXTS.cd -- OPTIONAL
L.AUTO_TIMER_TEXTS.nextnp				= L.AUTO_TIMER_TEXTS.next -- OPTIONAL
L.AUTO_TIMER_TEXTS.cdpnp				= L.AUTO_TIMER_TEXTS.cd -- OPTIONAL
L.AUTO_TIMER_TEXTS.nextpnp				= L.AUTO_TIMER_TEXTS.next -- OPTIONAL
L.AUTO_TIMER_TEXTS.castpnp				= L.AUTO_TIMER_TEXTS.cast -- OPTIONAL

L.AUTO_TIMER_OPTIONS = {
	target								= "$spell:%s zayıflatması için zamanlayıcı göster",
	targetcount							= "$spell:%s zayıflatması için zamanlayıcı göster (sayımla)",
	cast								= "$spell:%s büyüsü için zamanlayıcı göster",
	castpnp								= "$spell:%s büyüsü için yalnızca öncelikli isim plakası zamanlayıcısı göster",
	castcount							= "$spell:%s büyüsü için zamanlayıcı göster (sayımla)",
	castsource							= "$spell:%s büyüsü için zamanlayıcı göster (kaynakla)",
	active								= "$spell:%s süresi için zamanlayıcı göster",
	fades								= "$spell:%s oyunculardan kalktığında zamanlayıcı göster",
	ai									= "$spell:%s bekleme süresi için YZ zamanlayıcısı göster",

	cd									= "$spell:%s bekleme süresi için zamanlayıcı göster",
	cdcount								= "$spell:%s bekleme süresi için zamanlayıcı göster",
	cdnp								= "$spell:%s bekleme süresi için yalnızca isim plakası zamanlayıcısı göster",
	cdpnp								= "$spell:%s bekleme süresi için yalnızca öncelikli isim plakası zamanlayıcısı göster",
	cdsource							= "$spell:%s bekleme süresi için zamanlayıcı göster (kaynakla)",--Maybe better wording?
	cdspecial							= "Özel yetenek bekleme süresi için zamanlayıcı göster",
	cdcombo								= "Yetenek kombosu bekleme süresi için zamanlayıcı göster",--Used for combining 2 abilities into a single timer

	next								= "Sonraki $spell:%s için zamanlayıcı göster",
	nextcount							= "Sonraki $spell:%s için zamanlayıcı göster",
	nextnp								= "Sonraki $spell:%s için yalnızca isim plakası zamanlayıcısı göster",
	nextpnp								= "Sonraki $spell:%s için yalnızca öncelikli isim plakası zamanlayıcısı göster",
	nextsource							= "Sonraki $spell:%s için zamanlayıcı göster (kaynakla)",--Maybe better wording?
	nextspecial							= "Sonraki özel yetenek için zamanlayıcı göster",
	nextcombo							= "Sonraki yetenek kombosu için zamanlayıcı göster",--Used for combining 2 abilities into a single timer

	var									= "$spell:%s bekleme aralığı için zamanlayıcı göster (sapmayla)",
	varcount							= "$spell:%s bekleme aralığı için zamanlayıcı göster (sayım ve sapmayla)",
	varnp								= "$spell:%s bekleme aralığı için yalnızca isim plakası zamanlayıcısı göster (sapmayla)",
	varpnp								= "$spell:%s bekleme aralığı için yalnızca öncelikli isim plakası zamanlayıcısı göster (sapmayla)",
	varsource							= "$spell:%s bekleme aralığı için zamanlayıcı göster (kaynak ve sapmayla)",
	varspecial							= "Özel yetenek bekleme aralığı için zamanlayıcı göster (sapmayla)",
	varcombo							= "Yetenek kombosu bekleme aralığı için zamanlayıcı göster (sapmayla)",

	achievement							= "%s için zamanlayıcı göster",
	stage								= "Sonraki aşama için zamanlayıcı göster",
	stagecount							= "Sonraki aşama için zamanlayıcı göster (sayımla)",
	stagecountcycle						= "Sonraki aşama için zamanlayıcı göster (aşama ve döngü sayımıyla)",
	stagecontext						= "Sonraki $spell:%s aşaması için zamanlayıcı göster",
	stagecontextcount					= "Sonraki $spell:%s aşaması için zamanlayıcı göster (sayımla)",
	intermission						= "Sonraki ara aşama için zamanlayıcı göster",
	intermissioncount					= "Sonraki ara aşama için zamanlayıcı göster (sayımla)",
	adds								= "Gelen ek düşmanlar için zamanlayıcı göster",
	addscount							= "Gelen ek düşmanlar için zamanlayıcı göster (sayımla)",
	addscustom							= "Gelen ek düşmanlar için zamanlayıcı göster",
	roleplay							= "Hikâye (RP) süresi için zamanlayıcı göster",--This does need localizing though.
	combat								= "Savaş başlangıcı için zamanlayıcı göster"
}

L.AUTO_ICONS_OPTION_TARGETS				= "$spell:%s hedeflerine simge koy"--Usually used for player targets with no specific sorting
L.AUTO_ICONS_OPTION_TARGETS_TANK_A		= "$spell:%s hedeflerine simge koy (tank > yakın dövüş > uzak öncelik, alfabetik yedek)"
L.AUTO_ICONS_OPTION_TARGETS_TANK_R		= "$spell:%s hedeflerine simge koy (tank > yakın dövüş > uzak öncelik, Raid listesi yedek)"
L.AUTO_ICONS_OPTION_TARGETS_MELEE_A		= "$spell:%s hedeflerine simge koy (yakın dövüş ve alfabetik öncelik)"
L.AUTO_ICONS_OPTION_TARGETS_MELEE_R		= "$spell:%s hedeflerine simge koy (yakın dövüş ve Raid listesi önceliği)"
L.AUTO_ICONS_OPTION_TARGETS_RANGED_A	= "$spell:%s hedeflerine simge koy (uzak ve alfabetik öncelik)"
L.AUTO_ICONS_OPTION_TARGETS_RANGED_R	= "$spell:%s hedeflerine simge koy (uzak ve Raid listesi önceliği)"
L.AUTO_ICONS_OPTION_TARGETS_MRH			= "$spell:%s hedeflerine simge koy (yakın dövüş > uzak > şifacı öncelik, Raid listesi yedek)"
L.AUTO_ICONS_OPTION_TARGETS_TOH			= "$spell:%s hedeflerine simge koy (tank > dps > şifacı öncelik, Raid listesi yedek)"
L.AUTO_ICONS_OPTION_TARGETS_ALPHA		= "$spell:%s hedeflerine simge koy (alfabetik öncelik)"
L.AUTO_ICONS_OPTION_TARGETS_ROSTER		= "$spell:%s hedeflerine simge koy (Raid listesi önceliği)"
L.AUTO_ICONS_OPTION_NPCS				= "$spell:%s üzerine simge koy"--usually used for npcs/mobs
L.AUTO_ICONS_OPTION_CONFLICT			= " (Diğer seçeneklerle çakışabilir)"

L.AUTO_ARROW_OPTION_TEXT				= "Show " .. L.DBM .. " Arrow to move toward target affected by $spell:%s"
L.AUTO_ARROW_OPTION_TEXT2				= "Show " .. L.DBM .. " Arrow to move away from target affected by $spell:%s"
L.AUTO_ARROW_OPTION_TEXT3				= "Show " .. L.DBM .. " Arrow to move toward specific location for $spell:%s"

L.AUTO_YELL_OPTION_TEXT = {
	shortyell							= "$spell:%s sizi etkilediğinde bağır",
	yell								= "$spell:%s sizi etkilediğinde bağır (oyuncu adıyla)",
	count								= "$spell:%s sizi etkilediğinde bağır (sayımla)",
	fade								= "$spell:%s kalkarken bağır (geri sayım ve büyü adıyla)",
	shortfade							= "$spell:%s kalkarken bağır (geri sayımla)",
	iconfade							= "$spell:%s kalkarken bağır (geri sayım ve simgeyle)",
	position							= "$spell:%s sizi etkilediğinde bağır (konum ve oyuncu adıyla)",
	shortposition						= "$spell:%s sizi etkilediğinde bağır (konumla)",
	combo								= "$spell:%s ve başka büyüler aynı anda sizi etkilediğinde bağır (özel metinle)",
	repeatplayer						= "$spell:%s sizi etkilediğinde tekrar tekrar bağır (oyuncu adıyla)",
	repeaticon							= "$spell:%s sizi etkilediğinde tekrar tekrar bağır (simgeyle)",
	icontarget							= "$spell:%s sizi hedef aldığında diğerlerini uyarmak için simge bağır",
}
L.AUTO_YELL_ANNOUNCE_TEXT = {
	shortyell							= "%s", -- OPTIONAL
	yell								= "%s on " .. UnitName("player"),
	count								= "%s on " .. UnitName("player") .. " (%%d)",
	fade								= "%s %%d içinde bitiyor",
	shortfade							= "%%d", -- OPTIONAL
	iconfade							= "{rt%%2$d}%%1$d", -- OPTIONAL
	iconfadenoicon						= "%%1$d",
	position 							= "%s %%s on {rt%%d}" ..UnitName("player").. "{rt%%d}",
	positionnoIcon						= "%s %%s on " ..UnitName("player"),
	shortposition 						= "{rt%%1$d}%s",--Icon, Spellname -- OPTIONAL
	shortpositionnoicon					= "%s",--Spellname -- OPTIONAL
	combo								= "%s and %%s",--Spell name (from option, plus spellname given in arg)
	repeatplayer						= UnitName("player"),--Doesn't need translation, it's just player name spam -- OPTIONAL
	repeaticon							= "{rt%%1$d}",--Doesn't need translation. It's just icon spam -- OPTIONAL
	icontarget							= "{rt%%1$d}{rt%%1$d}{rt%%1$d}",--Doesn't need translation. It's just an icon repeated 3 times-- OPTIONAL
}
L.AUTO_YELL_CUSTOM_POSITION				= "{rt%d}%s"--Doesn't need translating. Has no strings (Used in niche situations such as icon repeat yells) -- OPTIONAL
L.AUTO_YELL_CUSTOM_FADE					= "%s faded"
L.AUTO_NAMEPLATE_OPTION_TEXT			= "$spell:%s için isim plakası auralarını uyumlu isim plakası eklentisiyle ya da şununla göster: "..L.DBM
L.AUTO_NAMEPLATE_OPTION_TEXT_FORCED		= "$spell:%s için isim plakası auralarını yalnızca şununla göster: "..L.DBM
L.AUTO_RANGE_OPTION_TEXT				= "$spell:%s için menzil penceresi (%s) göster"--string used for range so we can use things like "5/2" as a value for that field
L.AUTO_RANGE_OPTION_TEXT_SHORT			= "Menzil penceresi (%s) göster"--For when a range frame is just used for more than one thing
L.AUTO_RRANGE_OPTION_TEXT				= "$spell:%s için ters menzil penceresi (%s) göster"--Reverse range frame (green when players in range, red when not)
L.AUTO_RRANGE_OPTION_TEXT_SHORT			= "Ters menzil penceresi (%s) göster"
L.AUTO_INFO_FRAME_OPTION_TEXT			= "$spell:%s için bilgi penceresi göster"
L.AUTO_INFO_FRAME_OPTION_TEXT2			= "Savaş özeti için bilgi penceresi göster"
L.AUTO_INFO_FRAME_OPTION_TEXT3			= "$spell:%s için bilgi penceresi göster (%%s eşiğine ulaşınca)"
L.AUTO_READY_CHECK_OPTION_TEXT			= "Boss çekildiğinde hazır kontrolü sesi çal (hedefte olmasa bile)"
L.AUTO_SPEEDCLEAR_OPTION_TEXT			= "Bu bölgenin en hızlı temizlemesi için zamanlayıcı göster"
L.AUTO_PRIVATEAURA_OPTION_TEXT			= "Bu savaşta $spell:%s için DBM aura sesli uyarılarını çal."--Generic (most common)
L.AUTO_PRIVATEAURA_OPTION_TARGET_TEXT	= "$spell:%s sizi hedef aldığında DBM aura sesli uyarılarını çal."
L.AUTO_PRIVATEAURA_OPTION_GTFO_TEXT		= "$spell:%s alanından uzaklaşmanız gerektiğinde DBM aura sesli uyarılarını çal."
L.AUTO_PRIVATEAURA_OPTION_POST_TEXT		= "$spell:%s kalıcı etkileri için DBM aura sesli uyarılarını çal."
L.AUTO_CUSTOMTIMER_OPTION_TEXT			= "$spell:%s için zamanlayıcı göster"--Used for Midnight timeline timers (ie we have no context of what type of timer it is, just a generic timer)
L.AUTO_CUSTOMALERT_OPTION_TEXT			= "$spell:%s yapılmak üzereyken uyarı sesi ayarla"--Used for Midnight custom alerts (ie we have no context of what type of alert it is, just a generic alert)

L.AUTO_GOSSIP_BUFFS						= "NPC veya meslek güçlendirmeleri için konuşma seçeneklerini otomatik seç"
L.AUTO_GOSSIP_PERFORM_ACTION			= "Eylem yapmak için konuşma seçeneklerini otomatik seç (ulaşım kullanmak gibi)"
L.AUTO_GOSSIP_START_ENCOUNTER			= "Savaşı başlatmak için konuşma seçeneğini otomatik seç"--This will never need to be plural, since it won't be in a trash mod like other two

-- New special warnings
L.MOVE_WARNING_BAR						= "Duyuru taşınabilir"
L.MOVE_WARNING_MESSAGE					= "Kullandığın için teşekkürler: " .. L.DEADLY_BOSS_MODS
L.MOVE_SPECIAL_WARNING_BAR				= "Özel uyarı taşınabilir"
L.MOVE_SPECIAL_WARNING_TEXT				= "Özel Uyarı"

L.MOVE_PRIVATE_AURA_TEXT				= "<gizli değer> sizi <gizli değer> büyüsüyle hedef alıyor"
L.MOVE_PRIVATE_AURA_DISABLED			= "Aura Pencereleri seçeneklerde genel olarak kapalı olduğu için önizleme devre dışı."

L.ARROW_MOVABLE							= "Ok taşınabilir"
L.ARROW_WAY_USAGE						= "/dway <x> <y>: Belirli bir konumu gösteren ok oluşturur (bölge haritası koordinatlarıyla)"
L.ARROW_WAY_SUCCESS						= "Oku gizlemek için '/dbm arrow hide' yazın veya oka ulaşın"
L.ARROW_ERROR_USAGE						= {
	L.DBM .. "-Arrow usage:",
	"-----------------",
	"/dbm arrow <x> <y>: Creates an arrow that points to a specific location (using world coordinates)",
	"/dbm arrow map <x> <y>: Creates an arrow that points to a specific location (using zone map coordinates)",
	"/dbm arrow <player>: Creates and arrow that points to a specific player in your party or raid (case sensitive!)",
	"/dbm arrow hide: Hides the arrow",
	"/dbm arrow move: Makes the arrow movable"
}

L.SPEED_KILL_TIMER_TEXT					= "Zafer Rekoru"
L.SPEED_CLEAR_TIMER_TEXT				= "En İyi Temizleme"
L.TIMER_RESPAWN							= "%s Yeniden Doğma"

L.LAG_HEADER							= L.DBM.. " - Latency Results"
L.DUR_HEADER							= L.DBM.. " - Durability Results"
L.KEYSTONES_HEADER						= L.DBM.. " - Keystones"
L.GEAR_HEADER							= L.DBM.. " - Gear Check Results"
L.GEAR_MISSING_GEMS						= "Eksik Taşlar"
L.GEAR_MISSING_ENCHANTS					= "Eksik Efsunlar"
L.GEAR_DURABILITY						= "Dayanıklılık %"
L.GEAR_BROKEN							= "Kırık"
L.RAIDCHECKS_TAB_CONSUMABLES			= "Tüketilebilirler"
L.RAIDCHECKS_TAB_GEAR					= "Ekipman"
L.RAIDCHECKS_TAB_LATENCY				= "Gecikme"
L.CONSUMABLES_HEADER					= L.DBM.. " - Consumables Check"
L.CONSUMABLES_FLASK						= "Şişe"
L.CONSUMABLES_FOOD						= "Yiyecek"
L.CONSUMABLES_WEAPON					= "Silah"
L.CONSUMABLES_HS						= "HS"
L.CONSUMABLES_RUNE						= "Rün"
L.CONSUMABLES_NA						= "N/A"
L.BREZ_HEADER							= "Savaş Diriltmesi"

L.OVERRIDE_ACTIVATED					= "Bu savaş için yapılandırma geçersiz kılmaları Raid lideri tarafından etkinleştirildi"

--LDB
L.LDB_TOOLTIP_HELP1						= "Açmak için tıkla: " .. L.DBM
L.LDB_TOOLTIP_HELP2						= "Sessiz Modu açıp kapatmak için Alt+sağ tık"
L.SILENTMODE_IS							= "Sessiz Mod: "

L.WORLD_BUFFS = {
	hordeOny							= "People of the Horde, citizens of Orgrimmar, come, gather round and celebrate a hero of the Horde",
	allianceOny							= "Citizens and allies of Stormwind, on this day, history has been made.",
	hordeNef							= "NEFARIAN IS SLAIN! People of Orgrimmar",
	allianceNef							= "Citizens of the Alliance, the Lord of Blackrock is slain!",
	zgHeart								= "Now, only one step remains to rid us of the Soulflayer's threat",
	zgHeartBooty						= "The Blood God, the Soulflayer, has been defeated!  We are imperiled no longer!",
	zgHeartYojamba						= "Begin the ritual, my servants.  We must banish the heart of Hakkar back into the void!",
	rendHead							= "The false Warchief, Rend Blackhand, has fallen!",
	blackfathomBoon						= "boon of Blackfathom"
}

-- Annoying popup, especially for classic players
L.DBM_INSTALL_REMINDER_HEADER	= "Eksik DBM kurulumu algılandı!"
L.DBM_INSTALL_REMINDER_EXPLAIN	= "%s bölgesine hoş geldiniz. Buradaki bosslar için DBM modları %s içinde, ama kurulu değil. %s kurmadıkça DBM bu bölgede zamanlayıcı veya uyarı göstermeyecek!"
L.DBM_INSTALL_REMINDER_DISABLE	= "Bu bölgede tüm DBM uyarılarını ve zamanlayıcılarını kapat." -- Used when we believe it's a user error that the mod isn't installed (i.e., current raids)
L.DBM_INSTALL_REMINDER_DISABLE2 = "Bu paket için bu mesajı bir daha gösterme." -- Used for unimportant mods, i.e., dungeons
L.DBM_INSTALL_REMINDER_DL_WAGO	= "" .. (IsMacClient() and "Cmd-C" or "Ctrl-C")  ..  " to copy the Wago.io link to your clipboard."
L.DBM_INSTALL_REMINDER_DL_CURSE	= "" .. (IsMacClient() and "Cmd-C" or "Ctrl-C")  ..  " to copy the Curseforge link to your clipboard."
--"" .. (IsMacClient() and "Cmd-C" or "Ctrl-C")  ..  "
L.DBM_INSTALL_PACKAGE_VANILLA	= "Vanilla ve Season of Discovery paketi"
L.DBM_INSTALL_PACKAGE_BCC		= "Burning Crusade paketi"
L.DBM_INSTALL_PACKAGE_WRATH		= "Wrath paketi"
L.DBM_INSTALL_PACKAGE_CATA		= "Cataclysm paketi"
L.DBM_INSTALL_PACKAGE_MOP		= "Mists of Pandaria paketi"
L.DBM_INSTALL_PACKAGE_DUNGEON	= "Zindanlar, Delves, Challenges ve Etkinlikler paketi"

-- Tests

-- Boss tooltip
L.TOOLTIP_DBM					= L.DBM .. " info"
L.TOOLTIP_ENRAGE_TIMER			= "Öfkelenme zamanlayıcısı"
L.TOOLTIP_KILLS					= "Öldürme (%s)"
L.TOOLTIP_WIPES					= "Yenilgi (%s)"
L.TOOLTIP_FASTEST				= "En hızlı öldürme (%s)"

-- Difficulty info not found in normal globals, used by both GUI and tooltip
L.FOLLOWER						= "Yardımcı"--i.e. the new dungeon type in 10.2.5. I haven't found a translated string yet
L.STORY					    	= PLAYER_DIFFICULTY_STORY_RAID or "Story"--i.e. the new dungeon type in 11.0.0. I haven't found a translated string yet
L.DUOS							= "İkili"

-- Keystone dungeon names (keep to a max of 6 characters)
-- See https://wago.tools/db2/MapChallengeMode for ID => Dungeon Names
L.KEYSTONE_NAMES = {
	[197] = 'EOA', -- Eye of Azshara
	[198] = 'DHT', -- Darkheart Thicket
	[199] = 'BRH', -- Black Rook Hold
	[200] = 'HOV', -- Halls of Valor
	[206] = 'NL', -- Neltharion's Lair
	[207] = 'VOTW', -- Vault of the Wardens
	[208] = 'MOS', -- Maw of Souls
	[209] = 'ARC', -- The Arcway
	[210] = 'COS', -- Court of Stars
	[227] = 'LKARA', -- Return to Karazhan: Lower
	[233] = 'COEN', -- Cathedral of Eternal Night
	[234] = 'UKARA', -- Return to Karazhan: Upper
	[239] = 'SEAT', -- Seat of the Triumvirate

	[378] = 'HOA', -- Halls of Atonement
	[391] = 'STREET', -- Tazavesh: Streets of Wonder
	[392] = 'GAMBIT', -- Tazavesh: So'leah's Gambit
	[499] = 'PRIORY', -- Priority of the Sacred Flame
	[503] = 'ARAK', -- Ara-Kara, City of Echoes
	[505] = 'DAWN', -- The Dawnbreaker
	[525] = 'FLOOD', -- Operation Floodgate
	[542] = 'DOME', -- Eco-Dome Al'dani

	[161] = 'SKY', -- Skyreach
	[402] = 'AA', -- Algeth'ar Academy
	[556] = 'POS', -- Pit of Saron
	[557] = 'WRS', -- Windrunner Spire
	[558] = 'MT', -- Magister's Terrace
	[559] = 'NPX', -- Nexus-Point Xenas
	[560] = 'MC', -- Maisara Caverns
	[583] = 'SEAT', -- Seat of the Triumvirate

	[249] = 'REST', -- King's Rest
	[250] = 'TEMPLE', -- Temple of Sethraliss
	[399] = 'POOLS', -- Ruby Life Pools
	[584] = 'VALE', -- The Blinding Vale
	[585] = 'ARENA', -- Voidscar Arena
	[586] = 'DEN', -- Den of Nalorakk
	[587] = 'MURDER', -- Murder Row
	[588] = 'ALTAR', -- Altar of Fangs
}

-- Midnight jazz
L.MN_TIMELINE_HEADER	= "Blizzard Zaman Çizelgesini mi, DBM Çubuklarını mı kullanmak istersiniz?"
L.MN_BLIZZARD_TIMELINE	= "Blizzard Zaman Çizelgesi"
L.MN_DBM_TIMELINE		= "DBM Çubukları"
L.MN_WARNIGS_HEADER		= "Blizzard Savaş Uyarılarını mı, DBM Savaş Uyarılarını mı kullanmak istersiniz?"
L.MN_BLIZZARD_WARNINGS	= "Blizzard Uyarıları"
L.MN_DBM_WARNINGS		= "DBM Uyarıları"
L.MN_TEXT_TIMERS_HEADER	= "Zamanlayıcı yazısı kullanmak ister misiniz?\n(Gösterilmese bile DBM çubuk verisini kullanır)"
