-- WotLK genel görevler
-- b=başlık, a=açıklama, h=hedef, i=ilerleme, t=tamamlama
-- k = çevrilen İngilizce metnin parmak izi (metin değişirse çeviri gösterilmez, yeniden kaydedilir)
local V = WoWTurkce.Veri

V[11994] = { b="Juno'nun Bayrak Testi", k={b=3664032357} }
V[12186] = { b="BAYRAK: Kazanan", k={b=2437127314} }
V[12187] = { b="BAYRAK: Katılımcı", k={b=3131850622} }
V[12494] = { b="BAYRAK: Binicilik Eğitmeni İlanı (20)", k={b=2974578318} }
V[12600] = { b="Upper Deck Promosyonu - Ayı Bineği", k={b=2565218530} }
V[12693] = { b="Wolvar Taraf Seçimi Takibi", k={b=1977572187} }
V[12694] = { b="Oracle Taraf Seçimi Takibi", k={b=281957302} }
V[12845] = { b="Dalaran Işınlanma Kristali Bayrağı", k={b=1846675555} }
V[13123] = { b="WotLK Koleksiyoncu Sürümü: - DEM - E - BAYRAK", k={b=1055219569} }
V[13210] = { b="Blizzard Hesabı: - DEM - E - BAYRAK", k={b=1095781193} }
V[13807] = { b="BAYRAK: Turnuva Davetiyesi", k={b=450123281} }
V[13990] = { b="Upper Deck Promosyonu - Tavuk Bineği", k={b=3968891133} }
V[14106] = { b="Na Kada'nın Görev Testi", k={b=32587114} }
V[14185] = { b="BAYRAK: Binicilik Eğitmeni İlanı (40)", k={b=2974578384} }
V[14186] = { b="BAYRAK: Binicilik Eğitmeni İlanı (60)", k={b=2974578450} }
V[14187] = { b="BAYRAK: Binicilik Eğitmeni İlanı (70)", k={b=2974578483} }
V[24508] = { b="Geçici Görev Kaydı", k={b=3957364684} }
V[24509] = { b="Geçici Görev Kaydı", k={b=3957364684} }
V[24788] = { b="Günlük Rastgele Kahramanlık (1.)", k={b=3146076843} }
V[24789] = { b="Günlük Rastgele Kahramanlık (N.)", k={b=3146143293} }
V[24790] = { b="Günlük Rastgele Normal (1.)", k={b=2001132250} }
V[24791] = { b="Günlük Rastgele Normal (N.)", k={b=2001198700} }
V[24881] = { b="Klasik Rastgele 5-15 (1.)", k={b=3387886331} }
V[24882] = { b="Klasik Rastgele 15-25 (1.)", k={b=3708217709} }
V[24883] = { b="Klasik Rastgele 24-34 (1.)", k={b=666732973} }
V[24884] = { b="Klasik Rastgele 35-45 (1.)", k={b=1998558193} }
V[24885] = { b="Klasik Rastgele 46-55 (1.)", k={b=3330347476} }
V[24886] = { b="Klasik Rastgele 56-60 (1.)", k={b=327854385} }
V[24887] = { b="Klasik Rastgele 60-64 (1.)", k={b=1384653744} }
V[24888] = { b="Klasik Rastgele 65-70 (1.)", k={b=1581372882} }
V[24889] = { b="Klasik Rastgele 5-15 (N.)", k={b=3387952781} }
V[24890] = { b="Klasik Rastgele 15-25 (N.)", k={b=3708284159} }
V[24891] = { b="Klasik Rastgele 24-34 (N.)", k={b=666799423} }
V[24892] = { b="Klasik Rastgele 35-45 (N.)", k={b=1998624643} }
V[24893] = { b="Klasik Rastgele 46-55 (N.)", k={b=3330413926} }
V[24894] = { b="Klasik Rastgele 56-60 (N.)", k={b=327920835} }
V[24895] = { b="Klasik Rastgele 60-64 (N.)", k={b=1384720194} }
V[24896] = { b="Klasik Rastgele 65-70 (N.)", k={b=1581439332} }
V[24922] = { b="Klasik Rastgele Kahramanlık (1.)", k={b=1463883578} }
V[24923] = { b="Burning Crusade Rastgele Kahramanlık (N.)", k={b=2472171206} }
V[25306] = { b="Artık Ordudasın, Gnome!", a="[ph] Savaş!", h="[ph] Kayıt Açıklaması", k={b=2942568677, a=270845735, h=730835043} }
V[25482] = { b="Dünya Etkinliği Zindanı - Headless Horseman", k={b=3441793477} }
V[25483] = { b="Dünya Etkinliği Zindanı - Coren Direbrew", k={b=1481822026} }
V[25484] = { b="Dünya Etkinliği Zindanı - Ahune", k={b=4219705936} }
V[25485] = { b="Dünya Etkinliği Zindanı - Hummel", k={b=2100418663} }
