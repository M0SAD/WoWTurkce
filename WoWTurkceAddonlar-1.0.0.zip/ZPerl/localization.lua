-- X-Perl UnitFrames
-- Author: Resike
-- License: GNU GPL v3, 29 June 2007 (see LICENSE.txt)

XPerl_ProductName		= "|cFFD00000Z-Perl|r UnitFrames"
XPerl_ShortProductName	= "|cFFD00000Z-Perl|r"
XPerl_Author			= "|cFFFF8080Resike|r"
XPerl_Description		= "Forever çatallaması: "..XPerl_Author.."'s "..XPerl_ProductName
XPerl_VersionNumber		= C_AddOns.GetAddOnMetadata and C_AddOns.GetAddOnMetadata("ZPerl", "Version") or "8.0.0"
XPerl_Version			= XPerl_Description.." - Based on "..XPerl_VersionNumber
XPerl_LongDescription	= "UnitFrame replacement for new look Player, Pet, Party, Target, Target's Target, Focus, Raid"
XPerl_ModMenuIcon		= "Interface\\Icons\\INV_Misc_Gem_Pearl_02"

XPERL_MINIMAP_HELP1		= "|c00FFFFFFSol tık|r Seçenekler için (ve |c0000FF00çerçeveleri kilidi açmak|r için)"
XPERL_MINIMAP_HELP2		= "|c00FFFFFFSağ tık|r bu simgeyi sürüklemek için"
XPERL_MINIMAP_HELP3		= "\rGerçek Raid Üyeleri: |c00FFFF80%d|r\rGerçek Grup Üyeleri: |c00FFFF80%d|r"
XPERL_MINIMAP_HELP4		= "\rGerçek grubun/raidin liderisin"
XPERL_MINIMAP_HELP5		= "|c00FFFFFFAlt|r Z-Perl bellek kullanımı için"
XPERL_MINIMAP_HELP6		= "|c00FFFFFF+Shift|r Z-Perl'ün başlangıçtan beri bellek kullanımı için"

XPERL_MINIMENU_OPTIONS	= "Seçenekler"
XPERL_MINIMENU_ASSIST	= "Çerçeve Yardımcısını Göster"
XPERL_MINIMENU_CASTMON	= "Büyü Takipçisini Göster"
XPERL_MINIMENU_RAIDAD	= "Raid Yönetimini Göster"
XPERL_MINIMENU_ITEMCHK	= "Eşya Denetleyicisini Göster"
XPERL_MINIMENU_RAIDBUFF	= "Raid Buffları"
XPERL_MINIMENU_ROSTERTEXT="Liste Yazısı"
XPERL_MINIMENU_RAIDSORT	= "Raid Sıralaması"
XPERL_MINIMENU_RAIDSORT_GROUP = "Gruba Göre Sırala"
XPERL_MINIMENU_RAIDSORT_CLASS = "Sınıfa Göre Sırala"

XPERL_TYPE_NOT_SPECIFIED	= "Belirtilmemiş"
XPERL_TYPE_PET				= PET
XPERL_TYPE_BOSS				= "Boss"
XPERL_TYPE_RAREPLUS 		= "Rare+"
XPERL_TYPE_ELITE			= "Elite"
XPERL_TYPE_RARE				= "Nadir"

-- Zones
XPERL_LOC_ZONE_ANTORUS				= "Antorus"
XPERL_LOC_ZONE_BARADIN_HOLD 		= "Baradin Hold"
XPERL_LOC_ZONE_BASTION_OF_TWILIGHT	= "Basion of Twilight"
XPERL_LOC_ZONE_BLACK_TEMPLE			= "Black Temple"
XPERL_LOC_ZONE_BLACKWING_DECENT		= "Blackwing Decent"
XPERL_LOC_ZONE_DRAGONSOUL			= "Dragonsoul"
XPERL_LOC_ZONE_EMERALD_NIGHTMARE	= "Emerald Nightmare"
XPERL_LOC_ZONE_EYE_OF_ETERNITY		= "The Eye of Eternity"
XPERL_LOC_ZONE_FIRELANDS			= "Firelands"
XPERL_LOC_ZONE_HYJAL_SUMMIT			= "Hyjal Summit"
XPERL_LOC_ZONE_ICECROWN_CITADEL		= "Icecrown Citadel"
XPERL_LOC_ZONE_KARAZHAN				= "Karazhan"
XPERL_LOC_ZONE_NAXXRAMAS			= "Naxxramas"
XPERL_LOC_ZONE_NIGHTHOLD			= "Nighthold"
XPERL_LOC_ZONE_OBSIDIAN_SANCTUM		= "The Obsidian Sanctum"
XPERL_LOC_ZONE_RUBY_SANCTUM			= "The Ruby Sanctum"
XPERL_LOC_ZONE_SERPENTSHRINE_CAVERN	= "Serpentshrine Cavern"
XPERL_LOC_ZONE_SUNWELL_PLATEAU		= "Sunwell Plateau"
XPERL_LOC_ZONE_THRONE_OF_FOUR_WINDS = "Throne of Four Winds"
XPERL_LOC_ZONE_TOMB_OF_SARGERAS		= "Tomb of Sargeras"
XPERL_LOC_ZONE_TRIAL_OF_THE_CRUSADER= "Trial of the Crusader"
XPERL_LOC_ZONE_TRIAL_OF_VALOR		= "Trial of Valor"
XPERL_LOC_ZONE_ULDUAR				= "Ulduar"
-- Any zones 4.x and higher can all be localized from EJ, in 5.0, even these above zones are in EJ which means the rest can go bye bye too

-- Status
XPERL_LOC_DEAD		= DEAD -- "Dead"
XPERL_LOC_GHOST 	= "Hayalet"
XPERL_LOC_FEIGNDEATH	= "Feign Death"
XPERL_LOC_FEIGNDEATHSHORT	= "FD"
XPERL_LOC_OFFLINE	= PLAYER_OFFLINE -- "Offline"
XPERL_LOC_RESURRECTED	= "Diriltildi"
XPERL_LOC_SS_AVAILABLE	= "Ruh Taşı Hazır"
XPERL_LOC_UPDATING	= "Updating"
XPERL_LOC_ACCEPTEDRES	= "Accepted" -- Res accepted
XPERL_RAID_GROUP	= "Grup %d"
XPERL_RAID_GROUPSHORT	= "G%d"

XPERL_LOC_NONEWATCHED	= "izlenen yok"

XPERL_LOC_STATUSTIP = "Durum Vurguları: " -- Tooltip explanation of status highlight on unit
XPERL_LOC_STATUSTIPLIST = {
	HOT = "Heal over Time",
	AGGRO = "Aggro",
	MISSING = "Sınıfının buff'ı eksik",
	HEAL = "Being healed",
	SHIELD = "Shielded"
}

XPERL_OK		= "OK"
XPERL_CANCEL	= "İptal"

XPERL_LOC_LARGENUMTAG		= "K"
XPERL_LOC_HUGENUMTAG		= "M"
XPERL_LOC_VERYHUGENUMTAG	= "G"

BINDING_HEADER_ZPERL = XPerl_ProductName
BINDING_NAME_ZPERL_TOGGLERAID = "Raid Pencerelerini Aç/Kapat"
BINDING_NAME_ZPERL_TOGGLERAIDSORT = "Raid Sıralamasını Sınıf/Grup Arasında Değiştir"
BINDING_NAME_ZPERL_TOGGLERAIDPETS = "Raid Evcil Hayvanlarını Aç/Kapat"
BINDING_NAME_ZPERL_TOGGLEOPTIONS = "Ayarlar Penceresini Aç/Kapat"
BINDING_NAME_ZPERL_TOGGLEBUFFTYPE = "Buff/Debuff/hiçbiri Arasında Değiştir"
BINDING_NAME_ZPERL_TOGGLEBUFFCASTABLE = "Büyü Yapılabilir/Tedavi Edilebilir Arasında Değiştir"
BINDING_NAME_ZPERL_TEAMSPEAKMONITOR = "Teamspeak İzleyicisi"
BINDING_NAME_ZPERL_TOGGLERANGEFINDER = "Menzil Bulucuyu Aç/Kapat"

XPERL_KEY_NOTICE_RAID_BUFFANY = "Tüm buff/debuff'lar gösteriliyor"
XPERL_KEY_NOTICE_RAID_BUFFCURECAST = "Yalnızca büyü yapılabilir/tedavi edilebilir buff veya debuff'lar gösteriliyor"
XPERL_KEY_NOTICE_RAID_BUFFS = "Raid Buff'ları gösteriliyor"
XPERL_KEY_NOTICE_RAID_DEBUFFS = "Raid Debuff'ları gösteriliyor"
XPERL_KEY_NOTICE_RAID_NOBUFFS = "Raid buff'ı gösterilmiyor"

XPERL_DRAGHINT1		= "|c00FFFFFFTık|r pencereyi ölçeklendirmek için"
XPERL_DRAGHINT2		= "|c00FFFFFFShift+Tık|r pencereyi yeniden boyutlandırmak için"

-- Usage
XPerlUsageNameList	= {XPerl = "Core", XPerl_Player = "Player", XPerl_PlayerPet = "Pet", XPerl_Target = "Target", XPerl_TargetTarget = "Target's Target", XPerl_Party = "Party", XPerl_PartyPet = "Party Pets", XPerl_RaidFrames = "Raid Frames", XPerl_RaidHelper = "Raid Helper", XPerl_RaidAdmin = "Raid Admin", XPerl_TeamSpeak = "TS Monitor", XPerl_RaidMonitor = "Raid Monitor", XPerl_RaidPets = "Raid Pets", XPerl_ArcaneBar = "Arcane Bar", XPerl_PlayerBuffs = "Player Buffs", XPerl_GrimReaper = "Grim Reaper"}
XPERL_USAGE_MEMMAX	= "Arayüz Bellek Azami: %d"
XPERL_USAGE_MODULES	= "Modüller: "
XPERL_USAGE_NEWVERSION	= "*Daha yeni sürüm"
XPERL_USAGE_AVAILABLE	= "%s |c00FFFFFF%s|r indirilebilir"

XPERL_CMD_MENU		= "menu"
XPERL_CMD_OPTIONS	= "options"
XPERL_CMD_LOCK		= "lock"
XPERL_CMD_UNLOCK	= "unlock"
XPERL_CMD_CONFIG	= "config"
XPERL_CMD_LIST		= "list"
XPERL_CMD_DELETE	= "delete"
XPERL_CMD_HELP		= "|c00FFFF80Kullanım: |c00FFFFFF/zperl menu | lock | unlock | config list | config delete <realm> <name>"
XPERL_CANNOT_DELETE_CURRENT = "Mevcut yapılandırma silinemez"
XPERL_CONFIG_DELETED		= "%s/%s için yapılandırma silindi"
XPERL_CANNOT_FIND_DELETE_TARGET = "Silinecek yapılandırma bulunamadı (%s/%s)"
XPERL_CANNOT_DELETE_BADARGS = "Lütfen realm adını ve oyuncu adını girin"
XPERL_CONFIG_LIST		= "Yapılandırma Listesi:"
XPERL_CONFIG_CURRENT		= " (Mevcut)"

XPERL_RAID_TOOLTIP_WITHBUFF	= "Buff ile: (%s)"
XPERL_RAID_TOOLTIP_WITHOUTBUFF	= "Büfü olmayanlar: (%s)"
XPERL_RAID_TOOLTIP_BUFFEXPIRING	= "%s'in %s büyüsü %s içinde bitiyor" -- Name, buff name, time to expire

XPERL_NEW_VERSION_DETECTED = "Yeni sürüm bulundu:"
XPERL_DOWNLOAD_LATEST = "En son sürümü şuradan indirebilirsin:"
XPERL_DOWNLOAD_LOCATION = "https://mods.curse.com/addons/wow/zperl"

-- Status highlight spells
XPERL_HIGHLIGHT_SPELLS = {
	hotSpells  = {
		[XPerl_SpellName(774)] = 12, -- Rejuvenation (old id 26982)
		[XPerl_SpellName(8936)] = 6, -- Regrowth (old id 26980)
		[XPerl_SpellName(139)] = 12, -- Renew (old id 25222)
	},
	shieldSpells = {
		[XPerl_SpellName(17)] = 15, -- Power Word: Shield
	},
}

-- Default spells for range checking in the healer visual out-of-range cues.
XPerl_DefaultRangeSpells = {
	DRUID	= {spell = GetSpellInfo(774)}, -- Rejuvenation
	PALADIN = {spell = GetSpellInfo(19750)}, -- Flash of Light
	PRIEST	= {spell = GetSpellInfo(2061)}, -- Flash Heal
	SHAMAN	= {spell = GetSpellInfo(8004)}, -- Healing Surge
	MAGE	= {spell = GetSpellInfo(475)}, -- Remove Lesser Curse
	ROGUE	= {spell = GetSpellInfo(57934)}, -- Trick of the Trade
	WARLOCK	= {spell = GetSpellInfo(5697)}, -- Unending Breath
	ANY		= {item = GetItemInfo(1251)} -- Linen Bandage
}

-- Don't highlight these magical debuffs
XPerl_ArcaneExclusions = {
	[XPerl_SpellName(710)] = true, -- Banish
	[XPerl_SpellName(25195)] = {ROGUE = true}, -- Curse of Tongues
}
