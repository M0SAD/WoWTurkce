-- WoWTürkçe - büyü ve yetenek (sınıf büyüleri, yetenek ağacı) adları ve açıklamaları
-- İpucu: 1. satır ad, sağdaki derece ("Rank 3"), mana/menzil/döküm satırları ve açıklama.
-- Büyü kitabı: düğme adları ve dereceleri. /wt buyudokum: bütün büyülerin ipucunu WoWTurkce_Dokum.buyu'ya döker.
local _, WT = ...

WT.BuyuAd    = WT.BuyuAd    or {}  -- ["Fireball"] = "Ateş Topu"
WT.BuyuAdID  = WT.BuyuAdID  or {}  -- [spellID] = "Türkçe ad" (aynı İngilizce adın farklı çevirisi gerekirse)
WT.BuyuAlt   = WT.BuyuAlt   or {}  -- ["Rank #"] = "Derece {1}", ["Passive"] = "Pasif"
WT.BuyuSatir = WT.BuyuSatir or {}  -- ["# Mana"] = "{1} Mana", ["Instant"] = "Anında"
WT.BuyuK     = WT.BuyuK     or {}  -- açıklama kalıpları: ["Hurls a fiery ball that causes # to # Fire damage..."] = "..."

local Ad, AdID, Alt, Satir, K = WT.BuyuAd, WT.BuyuAdID, WT.BuyuAlt, WT.BuyuSatir, WT.BuyuK

local function kalip(s) return WT.Kalip(s) end
local function doldur(t, n) return WT.Doldur(t, n) end

local onbellek, yok = {}, {}

-- Tek bir cümle ya da satır kalıbı
local function tek(s, tablo)
  local t = tablo[s]
  if t then return t end
  local k, n = kalip(s)
  t = tablo[k]
  return t and doldur(t, n)
end

-- Açıklama: önce bütünü, olmazsa cümle cümle (". " ve satır sonlarından bölünerek)
local function aciklama(g)
  local t = tek(g, K)
  if t then return t end
  local sonuc, i = {}, 1
  while i <= #g do
    local a1, b1 = g:find("[%.!]%s+", i)
    local a2, b2 = g:find("\n+", i)
    local kes, s1, s2
    if a1 and (not a2 or a1 < a2) then kes, s1, s2 = a1, a1 + 1, b1
    elseif a2 then kes, s1, s2 = a2 - 1, a2, b2 end
    local parca = kes and g:sub(i, kes) or g:sub(i)
    if parca ~= "" then
      local tr = tek(parca, K) or tek(parca, Satir)
      if not tr then return nil end
      sonuc[#sonuc + 1] = tr
    end
    if not kes then break end
    sonuc[#sonuc + 1] = g:sub(s1, s2)
    i = s2 + 1
  end
  return table.concat(sonuc)
end

-- Meslek önekleri: tarif ipuçları "Mining: Copper Bar", "Enchanting: Enchant Bracer - Minor Stamina"
WT.MeslekOnek = WT.MeslekOnek or {
  ["Alchemy"] = "Simya", ["Blacksmithing"] = "Demircilik", ["Enchanting"] = "Efsunculuk",
  ["Engineering"] = "Mühendislik", ["Leatherworking"] = "Dericilik", ["Tailoring"] = "Terzilik",
  ["Mining"] = "Madencilik", ["Cooking"] = "Aşçılık", ["First Aid"] = "İlk Yardım",
  ["Jewelcrafting"] = "Kuyumculuk", ["Herbalism"] = "Bitkicilik", ["Skinning"] = "Deri Yüzme",
  ["Fishing"] = "Balıkçılık", ["Poisons"] = "Zehirler", ["Survival"] = "Hayatta Kalma",
  ["Smelting"] = "Eritme", ["Inscription"] = "Yazıtçılık",
}
local function esyaVeyaAd(x)
  if not x or x == "" then return nil end
  return (WT.Esya and WT.Esya[x]) or Ad[x]
end
WT.BuyuEsyaVeyaAd = esyaVeyaAd
function WT.BuyuAdCevir(ad, id)
  local t = (id and AdID[id]) or Ad[ad]
  if t or not ad then return t end
  local m, govde = ad:match("^([%a ]-): (.+)$")
  local mt = m and WT.MeslekOnek[m]
  if mt then
    local g = esyaVeyaAd(govde)
    if g then return mt .. ": " .. g end
  end
end

-- Ad dışındaki herhangi bir ipucu satırı
function WT.BuyuSatirCevir(s)
  if not s or s == "" then return nil end
  local t = onbellek[s]
  if t then return t end
  if yok[s] then return nil end
  t = Ad[s] or tek(s, Satir) or tek(s, Alt)
  if not t then
    -- "Requires 5 points in Fire Talents" / "Requires 5 points in Improved Fireball"
    local n, neyi = s:match("^Requires (%d+) points? in (.+)$")
    if n then
      local agac = neyi:match("^(.+) Talents$")
      local A = WT.BuyuAgac or {}
      if agac and A[agac] then t = ("%s yeteneklerinde %s puan gerekir"):format(A[agac], n)
      elseif Ad[neyi] then t = ("%s yeteneğinde %s puan gerekir"):format(Ad[neyi], n) end
    end
  end
  if not t then
    -- "Next Rank:" ve "Reagents: X" gibi önekli satırlar
    local on, govde = s:match("^(%a[%a ]-:) (.+)$")
    if on and Satir[on] then
      local g = aciklama(govde) or Ad[govde] or (WT.Esya and WT.Esya[govde])
      if not g then
        -- "|n|cffff2020Copper Ore|r, |cffffffffLinen Cloth (2)|r" gibi renkli ve sayılı parçalar
        local bas, govde2 = govde:match("^(|n)(.*)$")
        govde2 = govde2 or govde
        local parca = {}
        for p in (govde2 .. ", "):gmatch("(.-), ") do
          local on2, ic, son2 = p:match("^(|c%x%x%x%x%x%x%x%x)(.-)(|r)$")
          if not on2 then on2, ic, son2 = "", p, "" end
          local ad2, sayi = ic:match("^(.+) (%(%d+%))$")
          ad2 = ad2 or ic
          local x = esyaVeyaAd(ad2)
          if not x then parca = nil; break end
          parca[#parca + 1] = on2 .. x .. (sayi and (" " .. sayi) or "") .. son2
        end
        if parca then g = (bas or "") .. table.concat(parca, ", ") end
      end
      if false then
        local parca
        g = parca and table.concat(parca, ", ")
      end
      if g then t = Satir[on] .. " " .. g end
    end
  end
  t = t or aciklama(s)
  if not t then
    -- tarif ipucundaki üretilen eşya satırı ("\nCopper Bar")
    local nl, govde = s:match("^(\n+)(.+)$")
    local g = govde and esyaVeyaAd(govde)
    if g then t = nl .. g end
  end
  if t then onbellek[s] = t else yok[s] = true end
  return t
end


------------------------------------------------------------------ ipucu
local function buyuIpucu(tt, data)
  if not WT.Acik("buyu") or not tt or not tt.GetName then return end
  local ad = tt:GetName()
  if not ad then return end
  local id = data and data.id
  for i = 1, tt:NumLines() do
    local s = _G[ad .. "TextLeft" .. i]
    local t = s and s:GetText()
    if t and t ~= "" then
      local tr
      if i == 1 then
        tr = WT.BuyuAdCevir(t, id)
        if not tr and id then WT.Kaydet("buyu", id, t) end
      else
        tr = WT.BuyuSatirCevir(t)
        if not tr and #t > 25 and id then WT.Kaydet("buyuaciklama", t, id) end
      end
      if tr then s:SetText(tr) end
    end
    local r = _G[ad .. "TextRight" .. i]
    local rt = r and r:IsShown() and r:GetText()
    if rt and rt ~= "" then
      local tr = WT.BuyuSatirCevir(rt)
      if tr then r:SetText(tr) end
    end
  end
  tt:Show() -- satır genişliği yeniden hesaplansın
end

if TooltipDataProcessor and Enum and Enum.TooltipDataType then
  if Enum.TooltipDataType.Spell then TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Spell, buyuIpucu) end
  if Enum.TooltipDataType.Talent then TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Talent, buyuIpucu) end
  -- Buff/debuff ipuçları: ad ve süre satırları (açıklamaları büyü açıklamasından farklı olabilir; eşleşenler çevrilir)
  if Enum.TooltipDataType.UnitAura then TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.UnitAura, buyuIpucu) end
end
-- Yetenek ağacı ipucu (eski istemcilerde TooltipDataProcessor'dan geçmeyebilir)
if GameTooltip and GameTooltip.SetTalent then
  hooksecurefunc(GameTooltip, "SetTalent", function(self) pcall(buyuIpucu, self, nil) end)
end

------------------------------------------------------------------ büyü kitabı
local function kitapDugme(btn)
  if not WT.Acik("buyu") or not btn or not btn.GetName then return end
  local n = btn:GetName()
  local ad = n and _G[n .. "SpellName"]
  local alt = n and _G[n .. "SubSpellName"]
  local t = ad and ad:GetText()
  if t and t ~= "" then
    local tr = Ad[t]
    if tr then ad:SetText(tr) end
  end
  local a = alt and alt:GetText()
  if a and a ~= "" then
    local tr = tek(a, Alt)
    if tr then alt:SetText(tr) end
  end
end

local function kitapGuncelle()
  for i = 1, 12 do
    local b = _G["SpellButton" .. i]
    if b then pcall(kitapDugme, b) end
  end
end

if SpellButton_UpdateButton then hooksecurefunc("SpellButton_UpdateButton", kitapDugme) end
if SpellBookFrame_Update then hooksecurefunc("SpellBookFrame_Update", kitapGuncelle) end

------------------------------------------------------------------ döküm aracı
-- Oyunun bildiği bütün büyüleri tarar; adı ve alt yazısı (Rank 3, Passive, Racial...) olanların
-- ipucu satırlarını kaydeder. Alt yazısı olmayan büyüler (çoğu NPC büyüsü) yalnızca adla saklanır.
local dokum = { aktif = false }

local AdBul   = (C_Spell and C_Spell.GetSpellName) or function(id)
  local f = (C_Spell and C_Spell.GetSpellInfo)
  if f then local i = f(id); return i and i.name end
  return GetSpellInfo and (GetSpellInfo(id))
end
local AltBul  = (C_Spell and C_Spell.GetSpellSubtext) or GetSpellSubtext
local Hazir   = C_Spell and C_Spell.IsSpellDataCached
local Iste    = C_Spell and C_Spell.RequestLoadSpellData
local IpucuV  = C_TooltipInfo and C_TooltipInfo.GetSpellByID

local gizli = CreateFrame("GameTooltip", "WoWTurkceBuyuDokumIpucu", UIParent, "GameTooltipTemplate")

local function satirlar(id)
  local t = {}
  if IpucuV then
    local ok, d = pcall(IpucuV, id)
    if ok and d and d.lines then
      for _, l in ipairs(d.lines) do
        local sol = l.leftText or ""
        local sag = l.rightText
        if sag and sag ~= "" then sol = sol .. "\t" .. sag end
        if sol ~= "" then t[#t + 1] = sol end
      end
      if t[1] then return t end
    end
  end
  gizli:SetOwner(UIParent, "ANCHOR_NONE")
  gizli:ClearLines()
  local ok = pcall(gizli.SetSpellByID, gizli, id)
  if not ok then ok = pcall(gizli.SetHyperlink, gizli, "spell:" .. id) end
  if ok then
    for i = 1, gizli:NumLines() do
      local s = _G["WoWTurkceBuyuDokumIpucuTextLeft" .. i]
      local r = _G["WoWTurkceBuyuDokumIpucuTextRight" .. i]
      local x = s and s:GetText() or ""
      local y = r and r:IsShown() and r:GetText()
      if y and y ~= "" then x = x .. "\t" .. y end
      if x ~= "" then t[#t + 1] = x end
    end
  end
  gizli:Hide()
  return t
end

local function kaydet(id)
  local ok, ad = pcall(AdBul, id)
  if not ok or not ad or ad == "" then return end
  local alt = AltBul and select(2, pcall(AltBul, id)) or nil
  if type(alt) ~= "string" then alt = "" end
  local D = WoWTurkce_Dokum.buyu
  if alt ~= "" then
    local t = satirlar(id)
    if t[1] then
      t.a = alt
      D[id] = t
    else
      D[id] = { ad, a = alt }
    end
  else
    WoWTurkce_Dokum.buyuAd[id] = ad
  end
  dokum.bulunan = dokum.bulunan + 1
end

local bekleyen, bekleyenSay = {}, 0
local olay = CreateFrame("Frame")
olay:SetScript("OnEvent", function(_, _, id, basarili)
  id = tonumber(id)
  if id and bekleyen[id] then
    bekleyen[id] = nil
    bekleyenSay = bekleyenSay - 1
    pcall(kaydet, id)
  end
end)

local function durdur(mesaj)
  dokum.aktif = false
  olay:UnregisterAllEvents()
  if mesaj then print("|cff33ff99WoWTürkçe:|r " .. mesaj) end
end

local cerceve = CreateFrame("Frame")
cerceve:Hide()

local function adim(self)
  local simdi = GetTime()
  for id, t in pairs(bekleyen) do
    if simdi - t > 10 then
      bekleyen[id] = nil
      bekleyenSay = bekleyenSay - 1
      pcall(kaydet, id)
    end
  end
  local tarama, yazilan = 0, 0
  while dokum.sira <= dokum.son and tarama < 4000 and yazilan < 60 and bekleyenSay < 60 do
    local id = dokum.sira
    dokum.sira = id + 1
    tarama = tarama + 1
    local ok, ad = pcall(AdBul, id)
    if ok and ad and ad ~= "" and not WoWTurkce_Dokum.buyu[id] then
      yazilan = yazilan + 1
      local hazir = true
      if Hazir then local ok2, h = pcall(Hazir, id); if ok2 then hazir = h end end
      if hazir or not Iste then
        kaydet(id)
      else
        bekleyen[id] = simdi
        bekleyenSay = bekleyenSay + 1
        pcall(Iste, id)
      end
    end
  end
  if dokum.sira > dokum.son and bekleyenSay <= 0 then
    self:Hide()
    durdur("Büyü dökümü bitti: " .. dokum.bulunan .. " büyü. /reload yap ya da oyundan çık; kayıt o zaman dosyaya yazılır.")
  elseif simdi - (dokum.sonBildirim or 0) > 10 then
    dokum.sonBildirim = simdi
    print(("|cff33ff99WoWTürkçe:|r Büyü dökümü: %d / %d, bulunan %d"):format(dokum.sira, dokum.son, dokum.bulunan))
  end
end

cerceve:SetScript("OnUpdate", function(self)
  local ok, hata = pcall(adim, self)
  if not ok then
    self:Hide()
    WoWTurkce_Dokum.hata = tostring(hata)
    durdur("Büyü dökümü hatası (kaydedildi, sıra " .. tostring(dokum.sira) .. "): " .. tostring(hata) ..
      " — /wt buyudokum " .. tostring(dokum.sira) .. " " .. tostring(dokum.son) .. " ile kaldığın yerden sürdürebilirsin.")
  end
end)

-- Oyuncunun kendi yetenek ağacı (ad + ipucu): döküm sırasında bir kez kaydedilir
local function yetenekleriKaydet()
  if not GetNumTalentTabs or not GetTalentInfo then return end
  local _, sinif = UnitClass("player")
  local Y = {}
  for sekme = 1, GetNumTalentTabs() do
    local sad = GetTalentTabInfo and GetTalentTabInfo(sekme)
    if type(sad) == "number" then sad = select(2, GetTalentTabInfo(sekme)) end
    local tab = { ad = sad }
    for i = 1, (GetNumTalents and GetNumTalents(sekme) or 0) do
      local ok, ad = pcall(GetTalentInfo, sekme, i)
      if ok and ad then
        local satir = {}
        gizli:SetOwner(UIParent, "ANCHOR_NONE")
        gizli:ClearLines()
        if pcall(gizli.SetTalent, gizli, sekme, i) then
          for j = 1, gizli:NumLines() do
            local s = _G["WoWTurkceBuyuDokumIpucuTextLeft" .. j]
            local x = s and s:GetText()
            if x and x ~= "" then satir[#satir + 1] = x end
          end
        end
        gizli:Hide()
        tab[#tab + 1] = { ad = ad, satir = satir }
      end
    end
    Y[sekme] = tab
  end
  WoWTurkce_Dokum.yetenek = WoWTurkce_Dokum.yetenek or {}
  WoWTurkce_Dokum.yetenek[sinif or "?"] = Y
end

function WT.BuyuDokumBaslat(bas, son)
  WoWTurkce_Dokum = WoWTurkce_Dokum or {}
  WoWTurkce_Dokum.buyu = WoWTurkce_Dokum.buyu or {}
  WoWTurkce_Dokum.buyuAd = WoWTurkce_Dokum.buyuAd or {}
  WoWTurkce_Dokum.surum = (GetBuildInfo())
  WoWTurkce_Dokum.hata = nil
  pcall(yetenekleriKaydet)
  wipe(bekleyen); bekleyenSay = 0
  dokum.sira, dokum.son, dokum.bulunan, dokum.aktif, dokum.sonBildirim = bas or 1, son or 1500000, 0, true, 0
  pcall(olay.RegisterEvent, olay, "SPELL_DATA_LOAD_RESULT")
  cerceve:Show()
  print(("|cff33ff99WoWTürkçe:|r Büyü dökümü başladı (%d-%d). Birkaç dakika sürebilir; oyunu kapatmadan bekle."):format(dokum.sira, dokum.son))
end

------------------------------------------------------------------ ikinci tarama: yetenekler
-- Forever'da yetenekler alt yazısız büyüler; ilk taramada yalnızca adları alındı.
-- /wt yetenekdokum: adı alınan her büyünün ipucunu kaydeder ve oyundaki yetenek API'lerini listeler.
local liste, lsira, lyazilan = nil, 1, 0
local ikinci = CreateFrame("Frame")
ikinci:Hide()

local function apiListesi()
  local api = {}
  for k, v in pairs(_G) do
    if type(k) == "string" then
      if type(v) == "function" and (k:find("Talent") or k:find("Trait") or k:find("Specializ")) then
        api[#api + 1] = k
      elseif type(v) == "table" and k:match("^C_") and (k:find("Talent") or k:find("Trait") or k:find("Spec")) then
        for f in pairs(v) do api[#api + 1] = k .. "." .. tostring(f) end
      end
    end
  end
  table.sort(api)
  WoWTurkce_Dokum.api = api
end

-- Toplu tarama: 1) bütün büyülerin verisi istenir, 2) 15 sn beklenir, 3) ipuçları okunur,
-- 4) açıklaması gelmeyenler için 10 sn sonra bir tur daha okunur.
local asama, abekle, tekrar = 0, 0, nil
local function aciklamaVar(t) return #t >= 2 and not (#t == 2 and (t[2] == "Passive" or t[2]:find("^Rank"))) end
local function lkaydet(id, son)
  local t = satirlar(id)
  if aciklamaVar(t) or (son and #t >= 2) then
    WoWTurkce_Dokum.buyu2[id] = t; lyazilan = lyazilan + 1
    return true
  end
end

ikinci:SetScript("OnUpdate", function(self)
  if not liste then self:Hide(); return end
  local ok, hata = pcall(function()
    local simdi = GetTime()
    if asama == 1 then -- veri iste
      local n = 0
      while lsira <= #liste and n < 1500 do
        if Iste then pcall(Iste, liste[lsira]) end
        lsira, n = lsira + 1, n + 1
      end
      if lsira > #liste then asama, abekle, lsira = 2, simdi + 15, 1
        print("|cff33ff99WoWTürkçe:|r Yetenek dökümü: veriler istendi, 15 sn bekleniyor...") end
    elseif asama == 2 or asama == 4 then
      if simdi >= abekle then asama = asama + 1 end
    elseif asama == 3 then -- oku
      local n = 0
      while lsira <= #liste and n < 150 do
        local id = liste[lsira]
        if not lkaydet(id, false) then tekrar[#tekrar + 1] = id; if Iste then pcall(Iste, id) end end
        lsira, n = lsira + 1, n + 1
      end
      if lsira > #liste then
        asama, abekle, lsira = 4, simdi + 10, 1
        print(("|cff33ff99WoWTürkçe:|r Yetenek dökümü: %d büyü okundu, %d büyü için 10 sn sonra yeniden denenecek."):format(lyazilan, #tekrar))
      end
    elseif asama == 5 then -- eksikleri son kez oku
      local n = 0
      while lsira <= #tekrar and n < 150 do
        lkaydet(tekrar[lsira], true)
        lsira, n = lsira + 1, n + 1
      end
      if lsira > #tekrar then
        self:Hide(); asama = 0
        print("|cff33ff99WoWTürkçe:|r Yetenek dökümü bitti: " .. lyazilan .. " büyü. Şimdi /reload yap (kayıt ancak o zaman dosyaya yazılır).")
        return
      end
    end
    if asama ~= 2 and asama ~= 4 and simdi - (self.son or 0) > 5 then
      self.son = simdi
      print(("|cff33ff99WoWTürkçe:|r Yetenek dökümü: aşama %d, %d / %d"):format(asama, lsira, asama == 5 and #tekrar or #liste))
    end
  end)
  if not ok then
    self:Hide()
    WoWTurkce_Dokum.hata = tostring(hata)
    print("|cff33ff99WoWTürkçe:|r Yetenek dökümü hatası: " .. tostring(hata))
  end
end)

-- Modern yetenek ağacı (C_ClassTalents / C_Traits): oyuncunun kendi sınıfının düğümleri ve büyüleri
local function agacKaydet()
  if not (C_ClassTalents and C_Traits and C_ClassTalents.GetActiveConfigID) then return end
  local cfg = C_ClassTalents.GetActiveConfigID()
  if not cfg then return end
  local info = C_Traits.GetConfigInfo(cfg)
  local _, sinif = UnitClass("player")
  local A = { sinif = sinif, agac = {} }
  for _, tree in ipairs((info and info.treeIDs) or {}) do
    for _, node in ipairs(C_Traits.GetTreeNodes(tree) or {}) do
      local ni = C_Traits.GetNodeInfo(cfg, node)
      for _, entry in ipairs((ni and ni.entryIDs) or {}) do
        local ei = C_Traits.GetEntryInfo(cfg, entry)
        local di = ei and ei.definitionID and C_Traits.GetDefinitionInfo(ei.definitionID)
        local sp = di and (di.spellID or di.overriddenSpellID)
        if sp then
          A.agac[#A.agac + 1] = { sp, ni.maxRanks, di.overrideName, di.overrideDescription }
        end
      end
    end
  end
  WoWTurkce_Dokum.agac = WoWTurkce_Dokum.agac or {}
  WoWTurkce_Dokum.agac[sinif or "?"] = A
end

function WT.YetenekDokumBaslat()
  WoWTurkce_Dokum = WoWTurkce_Dokum or {}
  if not WoWTurkce_Dokum.buyuAd then
    print("|cff33ff99WoWTürkçe:|r Önce /wt buyudokum yapılmalı.")
    return
  end
  WoWTurkce_Dokum.buyu2 = {}
  pcall(apiListesi)
  pcall(yetenekleriKaydet)
  local okA, hA = pcall(agacKaydet)
  if not okA then WoWTurkce_Dokum.agacHata = tostring(hA) end
  asama, tekrar = 1, {}
  liste = {}
  for id in pairs(WoWTurkce_Dokum.buyuAd) do liste[#liste + 1] = id end
  table.sort(liste)
  lsira, lyazilan = 1, 0
  ikinci.son = 0
  ikinci:Show()
  print(("|cff33ff99WoWTürkçe:|r Yetenek dökümü başladı (%d büyü). Birkaç dakika sürebilir; oyunu kapatmadan bekle."):format(#liste))
end

------------------------------------------------------------------ üçüncü tarama: açıklamalar
-- Alt yazısı olmayan büyülerde ipucu açıklamayı vermiyor; GetSpellDescription ile doğrudan okunur.
-- /wt aciklamadokum
local Aciklama = (C_Spell and C_Spell.GetSpellDescription) or GetSpellDescription
local ucuncu = CreateFrame("Frame")
ucuncu:Hide()
local ulist, usira, uasama, ubekle, uyazilan = nil, 1, 0, 0, 0
local function uoku(id)
  local ok, a = pcall(Aciklama, id)
  if ok and type(a) == "string" and a ~= "" then
    WoWTurkce_Dokum.buyuAciklama[id] = a
    uyazilan = uyazilan + 1
    return true
  end
end
-- Oyun büyü verisini yavaş yükler: 100'lük gruplar halinde iste, yüklenmelerini bekle (en fazla 4 sn), oku.
local grup, gbas = {}, 0
ucuncu:SetScript("OnUpdate", function(self)
  local ok, hata = pcall(function()
    local simdi = GetTime()
    if uasama == 1 then
      if usira > #ulist then
        self:Hide(); uasama = 0
        print("|cff33ff99WoWTürkçe:|r Açıklama dökümü bitti: " .. uyazilan .. " açıklama. Şimdi /reload yap (kayıt ancak o zaman dosyaya yazılır).")
        return
      end
      wipe(grup)
      while usira <= #ulist and #grup < 100 do
        local id = ulist[usira]
        grup[#grup + 1] = id
        if Iste then pcall(Iste, id) end
        usira = usira + 1
      end
      gbas, uasama = simdi, 2
    elseif uasama == 2 then
      local hepsi = true
      if Hazir then
        for _, id in ipairs(grup) do
          local ok2, h = pcall(Hazir, id)
          if ok2 and not h then hepsi = false; break end
        end
      end
      if hepsi or simdi - gbas > 4 then
        for _, id in ipairs(grup) do uoku(id) end
        uasama = 1
      end
    end
    if simdi - (self.son or 0) > 10 then
      self.son = simdi
      print(("|cff33ff99WoWTürkçe:|r Açıklama dökümü: %d / %d, bulunan %d"):format(usira, #ulist, uyazilan))
    end
  end)
  if not ok then
    self:Hide()
    WoWTurkce_Dokum.hata = tostring(hata)
    print("|cff33ff99WoWTürkçe:|r Açıklama dökümü hatası: " .. tostring(hata))
  end
end)

function WT.AciklamaDokumBaslat()
  WoWTurkce_Dokum = WoWTurkce_Dokum or {}
  if not Aciklama then print("|cff33ff99WoWTürkçe:|r Bu istemcide büyü açıklaması fonksiyonu yok.") return end
  WoWTurkce_Dokum.buyuAciklama = {}
  ulist = {}
  for id in pairs(WoWTurkce_Dokum.buyuAd or {}) do ulist[#ulist + 1] = id end
  for id in pairs(WoWTurkce_Dokum.buyu or {}) do ulist[#ulist + 1] = id end
  table.sort(ulist)
  usira, uasama, uyazilan = 1, 1, 0
  ucuncu.son = 0
  ucuncu:Show()
  print(("|cff33ff99WoWTürkçe:|r Açıklama dökümü başladı (%d büyü)."):format(#ulist))
end

------------------------------------------------------------------ dördüncü tarama: bütün sınıfların yetenek ağaçları
-- /wt agacdokum: C_Traits ile her sınıfın/uzmanlığın ağacındaki yeteneklerin adını ve her derecedeki açıklamasını kaydeder.
local function p(f, ...) if not f then return nil end local ok, a, b, c, d = pcall(f, ...); if ok then return a, b, c, d end end
function WT.AgacDokumBaslat(tur)
  tur = tur or 1
  WoWTurkce_Dokum = WoWTurkce_Dokum or {}
  local eski = {}
  if tur > 1 and WoWTurkce_Dokum.agac2 then
    for _, a in ipairs(WoWTurkce_Dokum.agac2.sinif or {}) do
      for _, y in ipairs(a.yetenek or {}) do if y.entry then eski[y.entry] = y.acik end end
    end
  end
  local T, S = C_Traits or {}, C_SpecializationInfo or {}
  local cfg = C_ClassTalents and p(C_ClassTalents.GetActiveConfigID)
  local sonuc = { cfg = cfg, sinif = {}, hata = {} }
  local agaclar, gorulen = {}, {}
  local function agacEkle(sinifID, specID, tree)
    if tree and not gorulen[tree] then gorulen[tree] = true; agaclar[#agaclar + 1] = { sinifID, specID, tree } end
  end
  for sinifID = 1, 13 do
    local n = p(S.GetNumSpecializationsForClassID, sinifID) or (GetNumSpecializationsForClassID and p(GetNumSpecializationsForClassID, sinifID)) or 0
    for i = 1, n do
      local specID = GetSpecializationInfoForClassID and p(GetSpecializationInfoForClassID, sinifID, i)
      if type(specID) == "table" then specID = specID.specID end
      local tree = specID and C_ClassTalents and p(C_ClassTalents.GetTraitTreeForSpec, specID)
      agacEkle(sinifID, specID, tree)
    end
  end
  if cfg then
    local info = p(T.GetConfigInfo, cfg)
    for _, tree in ipairs((info and info.treeIDs) or {}) do agacEkle(0, 0, tree) end
  end
  local toplam = 0
  for _, a in ipairs(agaclar) do
    local sinifID, specID, tree = a[1], a[2], a[3]
    local liste = {}
    for _, node in ipairs(p(T.GetTreeNodes, tree) or {}) do
      local ni = p(T.GetNodeInfo, cfg, node)
      for _, entry in ipairs((ni and ni.entryIDs) or {}) do
        local ei = p(T.GetEntryInfo, cfg, entry)
        local di = ei and ei.definitionID and p(T.GetDefinitionInfo, ei.definitionID)
        local sp = di and (di.spellID or di.overriddenSpellID)
        local ad = (di and di.overrideName) or (sp and p(AdBul, sp))
        local acik = {}
        local onceki = eski[entry] or {}
        for r = 1, math.max(1, (ni and ni.maxRanks) or 1) do
          local d = p(T.GetTraitDescription, entry, r)
          if type(d) == "string" and d ~= "" then acik[r] = d elseif onceki[r] then acik[r] = onceki[r] end
          if sp and Iste then p(Iste, sp) end
        end
        if next(acik) then sonuc.acikSay = (sonuc.acikSay or 0) + 1 end
        liste[#liste + 1] = { sp = sp, ad = ad, en = ni and ni.maxRanks, acik = acik, entry = entry }
        toplam = toplam + 1
      end
    end
    sonuc.sinif[#sonuc.sinif + 1] = { sinifID = sinifID, specID = specID, tree = tree, ad = specID and GetSpecializationInfoByID and p(GetSpecializationInfoByID, specID), yetenek = liste }
  end
  WoWTurkce_Dokum.agac2 = sonuc
  local say = sonuc.acikSay or 0
  if tur < 10 and say < toplam and C_Timer and C_Timer.After then
    print(("|cff33ff99WoWTürkçe:|r Ağaç dökümü tur %d: %d / %d yeteneğin açıklaması alındı, 4 sn sonra tekrar..."):format(tur, say, toplam))
    C_Timer.After(4, function() WT.AgacDokumBaslat(tur + 1) end)
  else
    print(("|cff33ff99WoWTürkçe:|r Ağaç dökümü bitti: %d ağaç, %d yetenek, %d açıklamalı. Şimdi /reload yap ve haber ver."):format(#agaclar, toplam, say))
  end
end
