---@type l10n
local l10n = QuestieLoader:ImportModule("l10n")

local questsByFactionLocales = {
    ["Quests by Faction"] = {
        ["enUS"] = "Fraksiyona Göre Görevler",
        ["deDE"] = "Quests pro Fraktion",
        ["esES"] = "Misiones por facción",
        ["esMX"] = "Misiones por facción",
        ["frFR"] = "Quêtes par faction",
        ["koKR"] = "진영별 퀘스트",
        ["ptBR"] = "Missões por facção",
        ["ruRU"] = "Задания по фракциям",
        ["zhCN"] = "按阵营查寻",
        ["zhTW"] = "依陣營查看",
    },
    ["Select Expansion and Faction"] = {
        ["enUS"] = "Genişleme ve Fraksiyon Seçin",
        ["deDE"] = "Erweiterung und Fraktion wählen",
        ["esES"] = "Selecciona expansión y facción",
        ["esMX"] = "Selecciona expansión y facción",
        ["frFR"] = "Sélectionne l’extension et la faction",
        ["koKR"] = "확장팩 및 진영 선택",
        ["ptBR"] = "Seleciona expansão e facção",
        ["ruRU"] = "Выберите дополнение и фракцию",
        ["zhCN"] = "选择资料片和阵营",
        ["zhTW"] = "選擇資料片和陣營",
    },
    ["Select Faction"] = {
        ["enUS"] = "Fraksiyon Seçin",
        ["deDE"] = "Fraktion wählen",
        ["esES"] = "Seleccionar facción",
        ["esMX"] = "Seleccionar facción",
        ["frFR"] = "Sélectionner la faction",
        ["koKR"] = "진영 선택",
        ["ptBR"] = "Selecionar facção",
        ["ruRU"] = "Выберите фракцию",
        ["zhCN"] = "选择阵营",
        ["zhTW"] = "選擇陣營",
    },
    ["Reputation Reward"] = {
        ["enUS"] = "İtibar Ödülü",
        ["deDE"] = "Rufbelohnung",
        ["esES"] = "Recompensa de reputación",
        ["esMX"] = "Recompensa de reputación",
        ["frFR"] = "Récompense de réputation",
        ["koKR"] = "관계 보상",
        ["ptBR"] = "Recompensa de reputação",
        ["ruRU"] = "Награда за репутацию",
        ["zhCN"] = "声望奖励",
        ["zhTW"] = "聲譽獎勵",
    },
}

for k, v in pairs(questsByFactionLocales) do
    l10n.translations[k] = v
end


