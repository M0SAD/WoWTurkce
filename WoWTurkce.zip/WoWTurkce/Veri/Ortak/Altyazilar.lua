-- Sinematik ve film altyazıları ([parmak izi] = Türkçe)
local G = WoWTurkce
do local function _()
local T = G.Altyazi
T[37540970] = "beni takip edin"
T[254705007] = "Yanarken."
T[274527774] = "Uyu..."
T[277190381] = "Uther..."
T[718554700] = "Buraya gelmeye"
T[1223328412] = "İmkânsız!"
T[2090299505] = "Hadi, hadi!"
T[2090299768] = "Hadi."
T[2090679556] = "öfke."
T[2090863769] = "Pekâlâ..."
T[2319755470] = "Savaş Şefi"
T[2693466514] = "Neredeyim... Neredeyim ben?"
T[3131621182] = "sonsuza dek."
T[3260671791] = "THRALL HOMURDANIR"
T[4069746958] = "Nihayet..."
T[4091488795] = "Sakının..."
T[5863686] = "Ya da..."
T[193500569] = "Artık"
T[261600587] = "Onur..."
T[480056025] = "Boyun eğ."
T[552630610] = "Herkesi!"
T[580928828] = "Hiç mi?"
T[619236724] = "Toprak lanetli olsa da Scarlet Crusade'in bağnaz insanları dağınık mevzilerine hâlâ tutunuyor; undead'leri yok etmeye ve vatanlarını geri almaya takıntılı."
T[1169092419] = "Yeni müttefiklerine hiçbir gerçek bağlılık duymayan forsaken'lar, karanlık planlarını gerçekleştirmek için her yolu deneyecek."
T[1189794185] = "Forsaken'lardan biri olarak, yeni düzene tehdit oluşturan herkesi katletmelisin: insan, undead ya da başka bir şey."
T[2062011043] = "Bu gizli Undercity, Tirisfal Glades'in perili ormanlarının altına uzanan dev bir labirent oluşturuyor."
T[2232350118] = "Horde'un ilkel ırklarının düşmanlarına karşı zafer kazanmalarına yardım ettiğine inanan forsaken'lar, çıkara dayalı bir ittifaka girdi."
T[2607344968] = "Banshee Sylvanas Windrunner'ın önderliğindeki bir grup asi Scourge'dan koptu ve kendilerini Lich King'in egemenliğinden kurtardı."
T[2773987702] = "Zalim Lich King'in demir iradesine bağlı Scourge'un uçsuz bucaksız undead orduları, Azeroth'taki tüm yaşamı yok etmeye çalışıyor."
T[2985081793] = "gücünü,"
T[3019202094] = "iblis avcısı?"
T[3615601755] = "yaralı,"
T[4038217135] = "Sire Denathrius"
T[4101802746] = "Bitti mi... artık?"
T[4108517759] = "Alliance mı?"
end _() end
do local function _()
local T = G.Altyazi2
end _() end
