-- Görev eşyaları: toplanan ve kullanılan görev eşyalarının adları ("Samuel's Remains" -> "Samuel'in Kalıntıları").
-- Eşya adı sözlüğüne eklenir; kimlikler Questie haritası ve ipuçları için tutulur.
local E, I = WoWTurkce.EsyaAdi, WoWTurkce.EsyaId
if E["500 Pound Chicken"] == nil then E["500 Pound Chicken"] = "500 Librelik Tavuk" end
if E["99-Year-Old Port"] == nil then E["99-Year-Old Port"] = "99 Yıllık Porto Şarabı" end
if E["A Bloodstained Envelope"] == nil then E["A Bloodstained Envelope"] = "Kana Bulanmış Bir Zarf" end
if E["A Bloodstained Journal Page"] == nil then E["A Bloodstained Journal Page"] = "Kana Bulanmış Bir Günlük Sayfası" end
if E["A Carefully-packed Crate"] == nil then E["A Carefully-packed Crate"] = "Özenle Paketlenmiş Bir Sandık" end
if E["A Careworn Note"] == nil then E["A Careworn Note"] = "Yıpranmış Bir Not" end
if E["A Clue to Sander's Treasure"] == nil then E["A Clue to Sander's Treasure"] = "Sander'ın Hazinesine Dair Bir İpucu" end
if E["A Crumpled Missive"] == nil then E["A Crumpled Missive"] = "Buruşmuş Bir Mektup" end
if E["A Crumpled Up Note"] == nil then E["A Crumpled Up Note"] = "Buruşturulmuş Bir Not" end
if E["A Dull and Flat Elven Blade"] == nil then E["A Dull and Flat Elven Blade"] = "Kör ve Yassı Bir Elf Kılıcı" end
if E["A Dusty Unsent Letter"] == nil then E["A Dusty Unsent Letter"] = "Tozlu, Gönderilmemiş Bir Mektup" end
if E["A Faded Journal Page"] == nil then E["A Faded Journal Page"] = "Solmuş Bir Günlük Sayfası" end
if E["A Letter from the Keeper of the Rolls"] == nil then E["A Letter from the Keeper of the Rolls"] = "Kayıtlar Bekçisi'nden Bir Mektup" end
if E["A Letter to Yvette"] == nil then E["A Letter to Yvette"] = "Yvette'e Bir Mektup" end
if E["A Mangled Journal"] == nil then E["A Mangled Journal"] = "Parçalanmış Bir Günlük" end
if E["A Mysterious Message"] == nil then E["A Mysterious Message"] = "Gizemli Bir Mesaj" end
if E["A Note to Magus Rimtori"] == nil then E["A Note to Magus Rimtori"] = "Magus Rimtori'ye Bir Not" end
if E["A Ragged Page"] == nil then E["A Ragged Page"] = "Yırtık Pırtık Bir Sayfa" end
if E["A Short Note"] == nil then E["A Short Note"] = "Kısa Bir Not" end
if E["A Shrunken Head"] == nil then E["A Shrunken Head"] = "Büzülmüş Bir Kafa" end
if E["A Simple Compass"] == nil then E["A Simple Compass"] = "Basit Bir Pusula" end
if E["A Small Pack"] == nil then E["A Small Pack"] = "Küçük Bir Çanta" end
if E["A Small Stave"] == nil then E["A Small Stave"] = "Küçük Bir Asa" end
if E["A Smudged Document"] == nil then E["A Smudged Document"] = "Lekelenmiş Bir Belge" end
if E["A Sparkling Stone"] == nil then E["A Sparkling Stone"] = "Parıldayan Bir Taş" end
if E["A Sycamore Branch"] == nil then E["A Sycamore Branch"] = "Bir Çınar Dalı" end
if E["A Torn Journal Page"] == nil then E["A Torn Journal Page"] = "Yırtık Bir Günlük Sayfası" end
if E["A Torn Letter"] == nil then E["A Torn Letter"] = "Yırtık Bir Mektup" end
if E["Abercrombie's Crate"] == nil then E["Abercrombie's Crate"] = "Abercrombie'nin Sandığı" end
if E["Abyssal Crest"] == nil then E["Abyssal Crest"] = "Abyssal Arması" end
if E["Abyssal Scepter"] == nil then E["Abyssal Scepter"] = "Abyssal Asası" end
if E["Abyssal Signet"] == nil then E["Abyssal Signet"] = "Abyssal Mühür Yüzüğü" end
if E["Acceptable Basilisk Sample"] == nil then E["Acceptable Basilisk Sample"] = "Kabul Edilebilir Basilisk Numunesi" end
if E["Acceptable Hyena Sample"] == nil then E["Acceptable Hyena Sample"] = "Kabul Edilebilir Sırtlan Numunesi" end
if E["Acceptable Scorpid Sample"] == nil then E["Acceptable Scorpid Sample"] = "Kabul Edilebilir Scorpid Numunesi" end
if E["Accurate Scope"] == nil then E["Accurate Scope"] = "Hassas Dürbün" end
if E["Acidic Venom Sac"] == nil then E["Acidic Venom Sac"] = "Asitli Zehir Kesesi" end
if E["Ados Fragment"] == nil then E["Ados Fragment"] = "Ados Parçası" end
if E["Advanced Target Dummy"] == nil then E["Advanced Target Dummy"] = "Gelişmiş Hedef Mankeni" end
if E["Agamand Family Axe"] == nil then E["Agamand Family Axe"] = "Agamand Ailesi Baltası" end
if E["Agamand Family Dagger"] == nil then E["Agamand Family Dagger"] = "Agamand Ailesi Hançeri" end
if E["Agamand Family Mace"] == nil then E["Agamand Family Mace"] = "Agamand Ailesi Gürzü" end
if E["Agamand Family Sword"] == nil then E["Agamand Family Sword"] = "Agamand Ailesi Kılıcı" end
if E["Aged Envelope"] == nil then E["Aged Envelope"] = "Eskimiş Zarf" end
if E["Aged Gorilla Sinew"] == nil then E["Aged Gorilla Sinew"] = "Yıllanmış Goril Siniri" end
if E["Aged Kodo Hide"] == nil then E["Aged Kodo Hide"] = "Yıllanmış Kodo Postu" end
if E["Agent of Nozdormu"] == nil then E["Agent of Nozdormu"] = "Nozdormu Ajanı" end
if E["Ahanu's Leather Goods"] == nil then E["Ahanu's Leather Goods"] = "Ahanu'nun Deri Eşyaları" end
if E["Akiris Reed"] == nil then E["Akiris Reed"] = "Akiris Kamışı" end
if E["Alabaster Idol"] == nil then E["Alabaster Idol"] = "Kaymaktaşı Put" end
if E["Alaric's Head"] == nil then E["Alaric's Head"] = "Alaric'in Kafası" end
if E["Alien Egg"] == nil then E["Alien Egg"] = "Yabancı Yumurta" end
if E["Alliance Commendation Signet"] == nil then E["Alliance Commendation Signet"] = "Alliance Takdir Mührü" end
if E["Alliance Gift Collection"] == nil then E["Alliance Gift Collection"] = "Alliance Hediye Koleksiyonu" end
if E["Alterac Granite"] == nil then E["Alterac Granite"] = "Alterac Graniti" end
if E["Alterac Ram Hide"] == nil then E["Alterac Ram Hide"] = "Alterac Koçu Postu" end
if E["Alterac Signet Ring"] == nil then E["Alterac Signet Ring"] = "Alterac Mühür Yüzüğü" end
if E["Alterac Swiss"] == nil then E["Alterac Swiss"] = "Alterac İsviçre Peyniri" end
if E["Alterac Valley Mark of Honor"] == nil then E["Alterac Valley Mark of Honor"] = "Alterac Valley Onur Nişanı" end
if E["Altered Black Dragonflight Molt"] == nil then E["Altered Black Dragonflight Molt"] = "Değiştirilmiş Kara Ejderha Soyu Pulu" end
if E["Ambassador Infernus' Bracer"] == nil then E["Ambassador Infernus' Bracer"] = "Elçi Infernus'un Bilekliği" end
if E["Ambassador Malcin's Head"] == nil then E["Ambassador Malcin's Head"] = "Elçi Malcin'in Kafası" end
if E["Ambassador's Satchel"] == nil then E["Ambassador's Satchel"] = "Elçinin Heybesi" end
if E["Amber Idol"] == nil then E["Amber Idol"] = "Kehribar Put" end
if E["Amber Voodoo Feather"] == nil then E["Amber Voodoo Feather"] = "Kehribar Vudu Tüyü" end
if E["Amethyst Runestone"] == nil then E["Amethyst Runestone"] = "Ametist Rün Taşı" end
if E["Amulet of Allistarj"] == nil then E["Amulet of Allistarj"] = "Allistarj Muskası" end
if E["Amulet of Draconic Subversion"] == nil then E["Amulet of Draconic Subversion"] = "Ejderha Yıkımı Muskası" end
if E["Amulet of Grol"] == nil then E["Amulet of Grol"] = "Grol Muskası" end
if E["Amulet of Sevine"] == nil then E["Amulet of Sevine"] = "Sevine Muskası" end
if E["Amulet of Spirits"] == nil then E["Amulet of Spirits"] = "Ruhlar Muskası" end
if E["Amulet of Union"] == nil then E["Amulet of Union"] = "Birlik Muskası" end
if E["An Old History Book"] == nil then E["An Old History Book"] = "Eski Bir Tarih Kitabı" end
if E["An Undelivered Letter"] == nil then E["An Undelivered Letter"] = "Teslim Edilmemiş Bir Mektup" end
if E["An Unsent Letter"] == nil then E["An Unsent Letter"] = "Gönderilmemiş Bir Mektup" end
if E["An'Alleum Power Stone"] == nil then E["An'Alleum Power Stone"] = "An'Alleum Güç Taşı" end
if E["Anaya's Pendant"] == nil then E["Anaya's Pendant"] = "Anaya'nın Kolyesi" end
if E["Ancient Egg"] == nil then E["Ancient Egg"] = "Kadim Yumurta" end
if E["Ancient Moonstone Seal"] == nil then E["Ancient Moonstone Seal"] = "Kadim Aytaşı Mühür" end
if E["Ancient Petrified Leaf"] == nil then E["Ancient Petrified Leaf"] = "Kadim Taşlaşmış Yaprak" end
if E["Ancient Qiraji Artifact"] == nil then E["Ancient Qiraji Artifact"] = "Kadim Qiraji Eseri" end
if E["Ancient Rune Etched Stave"] == nil then E["Ancient Rune Etched Stave"] = "Kadim Rün Kazılı Asa" end
if E["Ancient Statuette"] == nil then E["Ancient Statuette"] = "Kadim Heykelcik" end
if E["Andorhal Watch"] == nil then E["Andorhal Watch"] = "Andorhal Saati" end
if E["Andron's Ledger"] == nil then E["Andron's Ledger"] = "Andron'un Defteri" end
if E["Andron's Note"] == nil then E["Andron's Note"] = "Andron'un Notu" end
if E["Angerclaw Grizzly Hide"] == nil then E["Angerclaw Grizzly Hide"] = "Angerclaw Boz Ayı Postu" end
if E["Annals of Darrowshire"] == nil then E["Annals of Darrowshire"] = "Darrowshire Yıllıkları" end
if E["Another Clue to Sander's Treasure"] == nil then E["Another Clue to Sander's Treasure"] = "Sander'ın Hazinesine Dair Bir İpucu Daha" end
if E["Anthion's Holy Water"] == nil then E["Anthion's Holy Water"] = "Anthion'un Kutsal Suyu" end
if E["Aqual Quintessence"] == nil then E["Aqual Quintessence"] = "Su Özü" end
if E["Araj's Phylactery Shard"] == nil then E["Araj's Phylactery Shard"] = "Araj'ın Ruh Kabı Parçası" end
if E["Araj's Scarab"] == nil then E["Araj's Scarab"] = "Araj'ın Bok Böceği" end
if E["Arathi Basin Mark of Honor"] == nil then E["Arathi Basin Mark of Honor"] = "Arathi Basin Onur Nişanı" end
if E["Arathi Resource Crate"] == nil then E["Arathi Resource Crate"] = "Arathi Kaynak Sandığı" end
if E["Arcane Crystal"] == nil then E["Arcane Crystal"] = "Arkan Kristali" end
if E["Arcane Mantle of the Dawn"] == nil then E["Arcane Mantle of the Dawn"] = "Şafağın Arkan Pelerini" end
if E["Arcane Quickener"] == nil then E["Arcane Quickener"] = "Arkan Hızlandırıcı" end
if E["Arcane Shard"] == nil then E["Arcane Shard"] = "Arkan Parçası" end
if E["Arcane Sliver"] == nil then E["Arcane Sliver"] = "Arkan Kıymığı" end
if E["Arcanite Bar"] == nil then E["Arcanite Bar"] = "Arcanite Külçesi" end
if E["Arcanite Barding"] == nil then E["Arcanite Barding"] = "Arcanite At Zırhı" end
if E["Arcanite Buoy"] == nil then E["Arcanite Buoy"] = "Arcanite Şamandıra" end
if E["Arcanum of Focus"] == nil then E["Arcanum of Focus"] = "Odak Arcanumu" end
if E["Arcanum of Protection"] == nil then E["Arcanum of Protection"] = "Koruma Arcanumu" end
if E["Arcanum of Rapidity"] == nil then E["Arcanum of Rapidity"] = "Çeviklik Arcanumu" end
if E["Arena Master"] == nil then E["Arena Master"] = "Arena Ustası" end
if E["Argent Dawn Valor Token"] == nil then E["Argent Dawn Valor Token"] = "Argent Dawn Cesaret Nişanı" end
if E["Arikara Serpent Skin"] == nil then E["Arikara Serpent Skin"] = "Arikara Yılan Derisi" end
if E["Armor Scraps"] == nil then E["Armor Scraps"] = "Zırh Hurdaları" end
if E["Arnak's Hoof"] == nil then E["Arnak's Hoof"] = "Arnak'ın Toynağı" end
if E["Arthas' Tears"] == nil then E["Arthas' Tears"] = "Arthas'ın Gözyaşları" end
if E["Artorius's Head"] == nil then E["Artorius's Head"] = "Artorius'un Kafası" end
if E["Aspect of Neptulon"] == nil then E["Aspect of Neptulon"] = "Neptulon'un Sureti" end
if E["Assassin's Contract"] == nil then E["Assassin's Contract"] = "Suikastçının Sözleşmesi" end
if E["Assassination Note"] == nil then E["Assassination Note"] = "Suikast Notu" end
if E["Astor's Letter of Introduction"] == nil then E["Astor's Letter of Introduction"] = "Astor'un Tanıtım Mektubu" end
if E["Atal'ai Artifact"] == nil then E["Atal'ai Artifact"] = "Atal'ai Eseri" end
if E["Atal'ai Haze"] == nil then E["Atal'ai Haze"] = "Atal'ai Sisi" end
if E["Atal'ai Stone Circle"] == nil then E["Atal'ai Stone Circle"] = "Atal'ai Taş Çemberi" end
if E["Atal'ai Tablet"] == nil then E["Atal'ai Tablet"] = "Atal'ai Tableti" end
if E["Atal'ai Tablet Fragment"] == nil then E["Atal'ai Tablet Fragment"] = "Atal'ai Tablet Parçası" end
if E["Athrikus Narassin's Head"] == nil then E["Athrikus Narassin's Head"] = "Athrikus Narassin'in Kafası" end
if E["Atiesh, Greatstaff of the Guardian"] == nil then E["Atiesh, Greatstaff of the Guardian"] = "Atiesh, Muhafızın Büyük Asası" end
if E["Augustus' Receipt Book"] == nil then E["Augustus' Receipt Book"] = "Augustus'un Makbuz Defteri" end
if E["Awbee's Scale"] == nil then E["Awbee's Scale"] = "Awbee'nin Pulu" end
if E["Azerothian Diamond"] == nil then E["Azerothian Diamond"] = "Azeroth Elması" end
if E["Azure Agate"] == nil then E["Azure Agate"] = "Lacivert Akik" end
if E["Azure Feather"] == nil then E["Azure Feather"] = "Lacivert Tüy" end
if E["Azure Idol"] == nil then E["Azure Idol"] = "Lacivert Put" end
if E["Azure Key"] == nil then E["Azure Key"] = "Lacivert Anahtar" end
if E["Backus' Phat Lewt"] == nil then E["Backus' Phat Lewt"] = "Backus'un Şahane Ganimeti" end
if E["Bad Egg"] == nil then E["Bad Egg"] = "Çürük Yumurta" end
if E["Bag of Empty Ooze Containers"] == nil then E["Bag of Empty Ooze Containers"] = "Bir Torba Boş Balçık Kabı" end
if E["Bag of Gold"] == nil then E["Bag of Gold"] = "Bir Kese Altın" end
if E["Bag of Water Elemental Bracers"] == nil then E["Bag of Water Elemental Bracers"] = "Bir Torba Su Elementali Bilekliği" end
if E["Bait"] == nil then E["Bait"] = "Yem" end
if E["Baked Salmon"] == nil then E["Baked Salmon"] = "Fırında Somon" end
if E["Balia'mah Trophy"] == nil then E["Balia'mah Trophy"] = "Balia'mah Ganimeti" end
if E["Balloo's Memorial"] == nil then E["Balloo's Memorial"] = "Balloo'nun Anıtı" end
if E["Balnir Snapdragons"] == nil then E["Balnir Snapdragons"] = "Balnir Aslanağızları" end
if E["Bamboo Cage Key"] == nil then E["Bamboo Cage Key"] = "Bambu Kafes Anahtarı" end
if E["Bank Voucher"] == nil then E["Bank Voucher"] = "Banka Senedi" end
if E["Banner of Provocation"] == nil then E["Banner of Provocation"] = "Kışkırtma Sancağı" end
if E["Barak's Head"] == nil then E["Barak's Head"] = "Barak'ın Kafası" end
if E["Barbaric Harness"] == nil then E["Barbaric Harness"] = "Barbar Koşum Takımı" end
if E["Barbecued Buzzard Wing"] == nil then E["Barbecued Buzzard Wing"] = "Izgara Akbaba Kanadı" end
if E["Baron Longshore's Head"] == nil then E["Baron Longshore's Head"] = "Baron Longshore'un Kafası" end
if E["Barrow Key"] == nil then E["Barrow Key"] = "Mezar Höyüğü Anahtarı" end
if E["Bartleby's Mug"] == nil then E["Bartleby's Mug"] = "Bartleby'nin Kupası" end
if E["Base of Atiesh"] == nil then E["Base of Atiesh"] = "Atiesh'in Kaidesi" end
if E["Basilisk Brain"] == nil then E["Basilisk Brain"] = "Basilisk Beyni" end
if E["Bath'rah's Parchment"] == nil then E["Bath'rah's Parchment"] = "Bath'rah'ın Parşömeni" end
if E["Bathran's Hair"] == nil then E["Bathran's Hair"] = "Bathran'ın Saçı" end
if E["Battleworn Axe"] == nil then E["Battleworn Axe"] = "Savaş Yorgunu Balta" end
if E["Beacon Torch"] == nil then E["Beacon Torch"] = "İşaret Meşalesi" end
if E["Bear Meat"] == nil then E["Bear Meat"] = "Ayı Eti" end
if E["Beasts Deck"] == nil then E["Beasts Deck"] = "Canavarlar Destesi" end
if E["Beaststalker's Belt"] == nil then E["Beaststalker's Belt"] = "Canavar Avcısının Kemeri" end
if E["Beaststalker's Bindings"] == nil then E["Beaststalker's Bindings"] = "Canavar Avcısının Bilekleri" end
if E["Beaststalker's Boots"] == nil then E["Beaststalker's Boots"] = "Canavar Avcısının Çizmeleri" end
if E["Beaststalker's Cap"] == nil then E["Beaststalker's Cap"] = "Canavar Avcısının Başlığı" end
if E["Beaststalker's Gloves"] == nil then E["Beaststalker's Gloves"] = "Canavar Avcısının Eldivenleri" end
if E["Beaststalker's Mantle"] == nil then E["Beaststalker's Mantle"] = "Canavar Avcısının Omuzluğu" end
if E["Beaststalker's Pants"] == nil then E["Beaststalker's Pants"] = "Canavar Avcısının Pantolonu" end
if E["Beaststalker's Tunic"] == nil then E["Beaststalker's Tunic"] = "Canavar Avcısının Tuniği" end
if E["Befouled Bloodstone Orb"] == nil then E["Befouled Bloodstone Orb"] = "Kirletilmiş Kantaşı Küre" end
if E["Befouled Water Globe"] == nil then E["Befouled Water Globe"] = "Kirletilmiş Su Küresi" end
if E["Beginnings of the Undead Threat"] == nil then E["Beginnings of the Undead Threat"] = "Undead Tehdidinin Başlangıcı" end
if E["Bel'dugur's Note"] == nil then E["Bel'dugur's Note"] = "Bel'dugur'un Notu" end
if E["Belamoore's Research Journal"] == nil then E["Belamoore's Research Journal"] = "Belamoore'un Araştırma Günlüğü" end
if E["Belgrom's Sealed Note"] == nil then E["Belgrom's Sealed Note"] = "Belgrom'un Mühürlü Notu" end
if E["Bellygrub's Tusk"] == nil then E["Bellygrub's Tusk"] = "Bellygrub'un Dişi" end
if E["Belnistrasz's Oathstone"] == nil then E["Belnistrasz's Oathstone"] = "Belnistrasz'ın Yemin Taşı" end
if E["Belt of Valor"] == nil then E["Belt of Valor"] = "Cesaret Kemeri" end
if E["Besseleth's Fang"] == nil then E["Besseleth's Fang"] = "Besseleth'in Dişi" end
if E["Big Black Mace"] == nil then E["Big Black Mace"] = "Büyük Kara Gürz" end
if E["Big Iron Bomb"] == nil then E["Big Iron Bomb"] = "Büyük Demir Bomba" end
if E["Bijou's Belongings"] == nil then E["Bijou's Belongings"] = "Bijou'nun Eşyaları" end
if E["Bijou's Information"] == nil then E["Bijou's Information"] = "Bijou'nun Bilgileri" end
if E["Bijou's Reconnaissance Report"] == nil then E["Bijou's Reconnaissance Report"] = "Bijou'nun Keşif Raporu" end
if E["Bindings of Elements"] == nil then E["Bindings of Elements"] = "Elementlerin Bileklikleri" end
if E["Bindings of the Windseeker"] == nil then E["Bindings of the Windseeker"] = "Rüzgâr Arayıcının Bileklikleri" end
if E["Bingles' Blastencapper"] == nil then E["Bingles' Blastencapper"] = "Bingles'ın Patlatıcı Kapsülü" end
if E["Bingles' Cog Inverter"] == nil then E["Bingles' Cog Inverter"] = "Bingles'ın Dişli Çeviricisi" end
if E["Bingles' Hammer"] == nil then E["Bingles' Hammer"] = "Bingles'ın Çekici" end
if E["Bingles' Screwdriver"] == nil then E["Bingles' Screwdriver"] = "Bingles'ın Tornavidası" end
if E["Bingles' Wrench"] == nil then E["Bingles' Wrench"] = "Bingles'ın İngiliz Anahtarı" end
if E["Black Blood of the Tormented"] == nil then E["Black Blood of the Tormented"] = "Eziyet Çekenlerin Kara Kanı" end
if E["Black Claw Stout"] == nil then E["Black Claw Stout"] = "Black Claw Siyah Birası" end
if E["Black Diamond"] == nil then E["Black Diamond"] = "Kara Elmas" end
if E["Black Dragonflight Molt"] == nil then E["Black Dragonflight Molt"] = "Kara Ejderha Soyu Pulu" end
if E["Black Dragonscale"] == nil then E["Black Dragonscale"] = "Kara Ejderha Pulu" end
if E["Black Dragonspawn Eye"] == nil then E["Black Dragonspawn Eye"] = "Kara Ejderha Yavrusu Gözü" end
if E["Black Drake's Heart"] == nil then E["Black Drake's Heart"] = "Kara Drake'in Kalbi" end
if E["Black Lodestone"] == nil then E["Black Lodestone"] = "Kara Mıknatıs Taşı" end
if E["Black Moro'gai Gem"] == nil then E["Black Moro'gai Gem"] = "Kara Moro'gai Mücevheri" end
if E["Blackened Iron Shield"] == nil then E["Blackened Iron Shield"] = "Kararmış Demir Kalkan" end
if E["Blackhand's Command"] == nil then E["Blackhand's Command"] = "Blackhand'ın Emri" end
if E["Blacklash's Bindings"] == nil then E["Blacklash's Bindings"] = "Blacklash'ın Bileklikleri" end
if E["Blackrock Bracer"] == nil then E["Blackrock Bracer"] = "Blackrock Bilekliği" end
if E["Blackrock Medallion"] == nil then E["Blackrock Medallion"] = "Blackrock Madalyonu" end
if E["Blackwood Fruit Sample"] == nil then E["Blackwood Fruit Sample"] = "Blackwood Meyve Numunesi" end
if E["Blackwood Grain Sample"] == nil then E["Blackwood Grain Sample"] = "Blackwood Tahıl Numunesi" end
if E["Blackwood Nut Sample"] == nil then E["Blackwood Nut Sample"] = "Blackwood Kuruyemiş Numunesi" end
if E["Blasted Boar Lung"] == nil then E["Blasted Boar Lung"] = "Parçalanmış Yaban Domuzu Ciğeri" end
if E["Blessed Arcanite Barding"] == nil then E["Blessed Arcanite Barding"] = "Kutsanmış Arcanite At Zırhı" end
if E["Blood Amber"] == nil then E["Blood Amber"] = "Kan Kehribarı" end
if E["Blood Red Key"] == nil then E["Blood Red Key"] = "Kan Kırmızısı Anahtar" end
if E["Blood Shard"] == nil then E["Blood Shard"] = "Kan Parçası" end
if E["Blood Stained Pike"] == nil then E["Blood Stained Pike"] = "Kana Bulanmış Mızrak" end
if E["Blood of Anacondra"] == nil then E["Blood of Anacondra"] = "Anacondra'nın Kanı" end
if E["Blood of Cobrahn"] == nil then E["Blood of Cobrahn"] = "Cobrahn'ın Kanı" end
if E["Blood of Heroes"] == nil then E["Blood of Heroes"] = "Kahramanların Kanı" end
if E["Blood of Innocents"] == nil then E["Blood of Innocents"] = "Masumların Kanı" end
if E["Blood of Morphaz"] == nil then E["Blood of Morphaz"] = "Morphaz'ın Kanı" end
if E["Blood of Pythas"] == nil then E["Blood of Pythas"] = "Pythas'ın Kanı" end
if E["Blood of Serpentis"] == nil then E["Blood of Serpentis"] = "Serpentis'in Kanı" end
if E["Blood of the Black Dragon Champion"] == nil then E["Blood of the Black Dragon Champion"] = "Kara Ejderha Şampiyonunun Kanı" end
if E["Blood of the Mountain"] == nil then E["Blood of the Mountain"] = "Dağın Kanı" end
if E["Bloodbelly Fish"] == nil then E["Bloodbelly Fish"] = "Kanlı Karın Balığı" end
if E["Bloodcap"] == nil then E["Bloodcap"] = "Kan Mantarı" end
if E["Bloodfury Ripper's Remains"] == nil then E["Bloodfury Ripper's Remains"] = "Bloodfury Ripper'ın Kalıntıları" end
if E["Bloodkelp"] == nil then E["Bloodkelp"] = "Kan Yosunu" end
if E["Bloodpetal"] == nil then E["Bloodpetal"] = "Kan Yaprağı" end
if E["Bloodpetal Sprout"] == nil then E["Bloodpetal Sprout"] = "Kan Yaprağı Filizi" end
if E["Bloodpetal Zapper"] == nil then E["Bloodpetal Zapper"] = "Kan Yaprağı Çarpıcısı" end
if E["Bloodsail Charts"] == nil then E["Bloodsail Charts"] = "Bloodsail Haritaları" end
if E["Bloodsail Orders"] == nil then E["Bloodsail Orders"] = "Bloodsail Emirleri" end
if E["Bloodscalp Coin"] == nil then E["Bloodscalp Coin"] = "Bloodscalp Sikkesi" end
if E["Bloodscalp Ear"] == nil then E["Bloodscalp Ear"] = "Bloodscalp Kulağı" end
if E["Bloodscalp Scalp"] == nil then E["Bloodscalp Scalp"] = "Bloodscalp Kafa Derisi" end
if E["Bloodscalp Tusk"] == nil then E["Bloodscalp Tusk"] = "Bloodscalp Dişi" end
if E["Bloodshot Spider Eye"] == nil then E["Bloodshot Spider Eye"] = "Kanlanmış Örümcek Gözü" end
if E["Bloodstained Journal"] == nil then E["Bloodstained Journal"] = "Kana Bulanmış Günlük" end
if E["Bloodstone Amulet"] == nil then E["Bloodstone Amulet"] = "Kantaşı Muska" end
if E["Bloodstone Choker"] == nil then E["Bloodstone Choker"] = "Kantaşı Gerdanlık" end
if E["Bloodstone Marble"] == nil then E["Bloodstone Marble"] = "Kantaşı Bilye" end
if E["Bloodstone Oval"] == nil then E["Bloodstone Oval"] = "Oval Kantaşı" end
if E["Bloodstone Pendant"] == nil then E["Bloodstone Pendant"] = "Kantaşı Kolye" end
if E["Bloodstone Shard"] == nil then E["Bloodstone Shard"] = "Kantaşı Parçası" end
if E["Bloodstone Wedge"] == nil then E["Bloodstone Wedge"] = "Kantaşı Kama" end
if E["Bloodvenom Essence"] == nil then E["Bloodvenom Essence"] = "Kan Zehri Özü" end
if E["Bloody Bone Necklace"] == nil then E["Bloody Bone Necklace"] = "Kanlı Kemik Kolye" end
if E["Blue Hakkari Bijou"] == nil then E["Blue Hakkari Bijou"] = "Mavi Hakkari Biblosu" end
if E["Blue Moro'gai Gem"] == nil then E["Blue Moro'gai Gem"] = "Mavi Moro'gai Mücevheri" end
if E["Blue Pearl"] == nil then E["Blue Pearl"] = "Mavi İnci" end
if E["Blue Power Crystal"] == nil then E["Blue Power Crystal"] = "Mavi Güç Kristali" end
if E["Blue Punch Card"] == nil then E["Blue Punch Card"] = "Mavi Delikli Kart" end
if E["Blue Sapphire"] == nil then E["Blue Sapphire"] = "Mavi Safir" end
if E["Blue Scepter Shard"] == nil then E["Blue Scepter Shard"] = "Mavi Asa Parçası" end
if E["Blue Voodoo Feather"] == nil then E["Blue Voodoo Feather"] = "Mavi Vudu Tüyü" end
if E["Blue-feathered Amulet"] == nil then E["Blue-feathered Amulet"] = "Mavi Tüylü Muska" end
if E["Blue-feathered Necklace"] == nil then E["Blue-feathered Necklace"] = "Mavi Tüylü Kolye" end
if E["Blueleaf Tuber"] == nil then E["Blueleaf Tuber"] = "Mavi Yaprak Yumrusu" end
if E["Bolt Charged Bramble"] == nil then E["Bolt Charged Bramble"] = "Yıldırım Yüklü Böğürtlen Dalı" end
if E["Bolt of Runecloth"] == nil then E["Bolt of Runecloth"] = "Top Rün Kumaşı" end
if E["Bolt of Woolen Cloth"] == nil then E["Bolt of Woolen Cloth"] = "Top Yün Kumaş" end
if E["Bolvar's Decree"] == nil then E["Bolvar's Decree"] = "Bolvar'ın Fermanı" end
if E["Bone Dust"] == nil then E["Bone Dust"] = "Kemik Tozu" end
if E["Bone Fragments"] == nil then E["Bone Fragments"] = "Kemik Parçaları" end
if E["Bone Scarab"] == nil then E["Bone Scarab"] = "Kemik Bok Böceği" end
if E["Bonegrip's Note"] == nil then E["Bonegrip's Note"] = "Bonegrip'in Notu" end
if E["Book from Sven's Farm"] == nil then E["Book from Sven's Farm"] = "Sven'in Çiftliğinden Kitap" end
if E["Book of Aquor"] == nil then E["Book of Aquor"] = "Aquor'un Kitabı" end
if E["Book of Incantations"] == nil then E["Book of Incantations"] = "Büyü Sözleri Kitabı" end
if E["Book of the Ancients"] == nil then E["Book of the Ancients"] = "Kadimlerin Kitabı" end
if E["Book: Stresses of Iron"] == nil then E["Book: Stresses of Iron"] = "Kitap: Demirin Gerilimleri" end
if E["Book: The Powers Below"] == nil then E["Book: The Powers Below"] = "Kitap: Aşağıdaki Güçler" end
if E["Boots of Elements"] == nil then E["Boots of Elements"] = "Elementlerin Çizmeleri" end
if E["Boots of Valor"] == nil then E["Boots of Valor"] = "Cesaret Çizmeleri" end
if E["Bottle of Disease"] == nil then E["Bottle of Disease"] = "Bir Şişe Hastalık" end
if E["Bottle of Moonshine"] == nil then E["Bottle of Moonshine"] = "Bir Şişe Kaçak İçki" end
if E["Bottle of Zombie Juice"] == nil then E["Bottle of Zombie Juice"] = "Bir Şişe Zombi Suyu" end
if E["Bottom Half of Advanced Armorsmithing: Volume I"] == nil then E["Bottom Half of Advanced Armorsmithing: Volume I"] = "İleri Zırh Demirciliği: Cilt I'in Alt Yarısı" end
if E["Bottom Half of Advanced Armorsmithing: Volume II"] == nil then E["Bottom Half of Advanced Armorsmithing: Volume II"] = "İleri Zırh Demirciliği: Cilt II'nin Alt Yarısı" end
if E["Bottom Half of Advanced Armorsmithing: Volume III"] == nil then E["Bottom Half of Advanced Armorsmithing: Volume III"] = "İleri Zırh Demirciliği: Cilt III'ün Alt Yarısı" end
if E["Bottom of Gelkak's Key"] == nil then E["Bottom of Gelkak's Key"] = "Gelkak'ın Anahtarının Alt Kısmı" end
if E["Box of Empty Vials"] == nil then E["Box of Empty Vials"] = "Bir Kutu Boş Şişe" end
if E["Bracers of Earth Binding"] == nil then E["Bracers of Earth Binding"] = "Toprak Bağlama Bileklikleri" end
if E["Bracers of Rock Binding"] == nil then E["Bracers of Rock Binding"] = "Kaya Bağlama Bileklikleri" end
if E["Bracers of Valor"] == nil then E["Bracers of Valor"] = "Cesaret Bileklikleri" end
if E["Branch of Cenarius"] == nil then E["Branch of Cenarius"] = "Cenarius'un Dalı" end
if E["Brann Bronzebeard's Lost Letter"] == nil then E["Brann Bronzebeard's Lost Letter"] = "Brann Bronzebeard'ın Kayıp Mektubu" end
if E["Brazier of Beckoning"] == nil then E["Brazier of Beckoning"] = "Çağırma Mangalı" end
if E["Brazier of Invocation"] == nil then E["Brazier of Invocation"] = "Davet Mangalı" end
if E["Breastplate of Valor"] == nil then E["Breastplate of Valor"] = "Cesaret Göğüslüğü" end
if E["Breath of Wind"] == nil then E["Breath of Wind"] = "Rüzgârın Nefesi" end
if E["Brightcloth Pants"] == nil then E["Brightcloth Pants"] = "Parlak Kumaş Pantolon" end
if E["Brilliant Chromatic Scale"] == nil then E["Brilliant Chromatic Scale"] = "Parlak Kromatik Pul" end
if E["Brilliant Gold Ring"] == nil then E["Brilliant Gold Ring"] = "Parlak Altın Yüzük" end
if E["Brilliant Sword of Zealotry"] == nil then E["Brilliant Sword of Zealotry"] = "Parlak Bağnazlık Kılıcı" end
if E["Bristleback Quilboar Tusk"] == nil then E["Bristleback Quilboar Tusk"] = "Bristleback Quilboar Dişi" end
if E["Brock's List"] == nil then E["Brock's List"] = "Brock'un Listesi" end
if E["Broken Armor of Ana'thek"] == nil then E["Broken Armor of Ana'thek"] = "Ana'thek'in Kırık Zırhı" end
if E["Broken Elemental Bracer"] == nil then E["Broken Elemental Bracer"] = "Kırık Element Bilekliği" end
if E["Broken Samophlange"] == nil then E["Broken Samophlange"] = "Kırık Samophlange" end
if E["Broken Sprite Darter Egg"] == nil then E["Broken Sprite Darter Egg"] = "Kırık Sprite Darter Yumurtası" end
if E["Broken Tears"] == nil then E["Broken Tears"] = "Kırık Gözyaşları" end
if E["Broken and Battered Samophlange"] == nil then E["Broken and Battered Samophlange"] = "Kırık Dökük Samophlange" end
if E["Bronze Battle Axe"] == nil then E["Bronze Battle Axe"] = "Bronz Savaş Baltası" end
if E["Bronze Feather"] == nil then E["Bronze Feather"] = "Bronz Tüy" end
if E["Bronze Greatsword"] == nil then E["Bronze Greatsword"] = "Bronz Büyük Kılıç" end
if E["Bronze Hakkari Bijou"] == nil then E["Bronze Hakkari Bijou"] = "Bronz Hakkari Biblosu" end
if E["Bronze Scarab"] == nil then E["Bronze Scarab"] = "Bronz Bok Böceği" end
if E["Bronze Tube"] == nil then E["Bronze Tube"] = "Bronz Boru" end
if E["Bronze Warhammer"] == nil then E["Bronze Warhammer"] = "Bronz Savaş Çekici" end
if E["Broodling Essence"] == nil then E["Broodling Essence"] = "Yavru Özü" end
if E["Brownell's Blue Striped Racer"] == nil then E["Brownell's Blue Striped Racer"] = "Brownell'in Mavi Çizgili Yarışçısı" end
if E["Bundle of Akiris Reeds"] == nil then E["Bundle of Akiris Reeds"] = "Bir Demet Akiris Kamışı" end
if E["Bundle of Atal'ai Artifacts"] == nil then E["Bundle of Atal'ai Artifacts"] = "Bir Bohça Atal'ai Eseri" end
if E["Bundle of Charred Oak"] == nil then E["Bundle of Charred Oak"] = "Bir Demet Kömürleşmiş Meşe" end
if E["Bundle of Crocolisk Skins"] == nil then E["Bundle of Crocolisk Skins"] = "Bir Deste Crocolisk Derisi" end
if E["Bundle of Goods"] == nil then E["Bundle of Goods"] = "Bir Bohça Mal" end
if E["Bundle of Hides"] == nil then E["Bundle of Hides"] = "Bir Deste Post" end
if E["Bundle of Relics"] == nil then E["Bundle of Relics"] = "Bir Bohça Kalıntı" end
if E["Bundle of Reports"] == nil then E["Bundle of Reports"] = "Bir Deste Rapor" end
if E["Burning Blood"] == nil then E["Burning Blood"] = "Yanan Kan" end
if E["Burning Charm"] == nil then E["Burning Charm"] = "Yanan Tılsım" end
if E["Burning Essence"] == nil then E["Burning Essence"] = "Yanan Öz" end
if E["Burning Gem"] == nil then E["Burning Gem"] = "Yanan Mücevher" end
if E["Burning Key"] == nil then E["Burning Key"] = "Yanan Anahtar" end
if E["Burning Rock"] == nil then E["Burning Rock"] = "Yanan Kaya" end
if E["Burnished Gold Key"] == nil then E["Burnished Gold Key"] = "Cilalı Altın Anahtar" end
if E["Buzzard Gizzard"] == nil then E["Buzzard Gizzard"] = "Akbaba Taşlığı" end
if E["Buzzard Wing"] == nil then E["Buzzard Wing"] = "Akbaba Kanadı" end
if E["Byltan Essence"] == nil then E["Byltan Essence"] = "Byltan Özü" end
if E["CHU's QUEST ITEM"] == nil then E["CHU's QUEST ITEM"] = "CHU'nun GÖREV EŞYASI" end
if E["Cache of Mau'ari"] == nil then E["Cache of Mau'ari"] = "Mau'ari Zulası" end
if E["Cache of Zanzil's Altered Mixture"] == nil then E["Cache of Zanzil's Altered Mixture"] = "Zanzil'in Değiştirilmiş Karışımı Zulası" end
if E["Caged Worg Pup"] == nil then E["Caged Worg Pup"] = "Kafesteki Worg Yavrusu" end
if E["Cairne's Hoofprint"] == nil then E["Cairne's Hoofprint"] = "Cairne'in Toynak İzi" end
if E["Caliph Scorpidsting's Head"] == nil then E["Caliph Scorpidsting's Head"] = "Halife Scorpidsting'in Kafası" end
if E["Call to Arms Announcement"] == nil then E["Call to Arms Announcement"] = "Silah Başına Duyurusu" end
if E["Calor's Note"] == nil then E["Calor's Note"] = "Calor'un Notu" end
if E["Camp Mojache Zukk'ash Report"] == nil then E["Camp Mojache Zukk'ash Report"] = "Camp Mojache Zukk'ash Raporu" end
if E["Camp Narache Gift Voucher"] == nil then E["Camp Narache Gift Voucher"] = "Camp Narache Hediye Çeki" end
if E["Cantation of Manifestation"] == nil then E["Cantation of Manifestation"] = "Tezahür İlahisi" end
if E["Captain Sander's Treasure Map"] == nil then E["Captain Sander's Treasure Map"] = "Kaptan Sander'ın Hazine Haritası" end
if E["Captain's Documents"] == nil then E["Captain's Documents"] = "Kaptanın Belgeleri" end
if E["Carapace of the Old God"] == nil then E["Carapace of the Old God"] = "Kadim Tanrının Kabuğu" end
if E["Carefully Folded Note"] == nil then E["Carefully Folded Note"] = "Özenle Katlanmış Not" end
if E["Carefully Penned Note"] == nil then E["Carefully Penned Note"] = "Özenle Yazılmış Not" end
if E["Carefully Written Letter"] == nil then E["Carefully Written Letter"] = "Özenle Yazılmış Mektup" end
if E["Carton of Mystery Meat"] == nil then E["Carton of Mystery Meat"] = "Bir Kutu Gizemli Et" end
if E["Carved Stone Idol"] == nil then E["Carved Stone Idol"] = "Oyma Taş Put" end
if E["Carved Stone Urn"] == nil then E["Carved Stone Urn"] = "Oyma Taş Küp" end
if E["Case of Blood"] == nil then E["Case of Blood"] = "Bir Kasa Kan" end
if E["Case of Elunite"] == nil then E["Case of Elunite"] = "Bir Kasa Elunite" end
if E["Cask of Merlot"] == nil then E["Cask of Merlot"] = "Bir Fıçı Merlot" end
if E["Cask of Scalder"] == nil then E["Cask of Scalder"] = "Bir Fıçı Scalder" end
if E["Catelyn's Blade"] == nil then E["Catelyn's Blade"] = "Catelyn'in Kılıcı" end
if E["Cats Eye Emerald"] == nil then E["Cats Eye Emerald"] = "Kedi Gözü Zümrüt" end
if E["Celebrian Diamond"] == nil then E["Celebrian Diamond"] = "Celebrian Elması" end
if E["Celebrian Rod"] == nil then E["Celebrian Rod"] = "Celebrian Çubuğu" end
if E["Cenarion Beacon"] == nil then E["Cenarion Beacon"] = "Cenarion İşareti" end
if E["Cenarion Combat Badge"] == nil then E["Cenarion Combat Badge"] = "Cenarion Muharebe Rozeti" end
if E["Cenarion Logistics Badge"] == nil then E["Cenarion Logistics Badge"] = "Cenarion Lojistik Rozeti" end
if E["Cenarion Lunardust"] == nil then E["Cenarion Lunardust"] = "Cenarion Ay Tozu" end
if E["Cenarion Moondust"] == nil then E["Cenarion Moondust"] = "Cenarion Ay Pudrası" end
if E["Cenarion Plant Salve"] == nil then E["Cenarion Plant Salve"] = "Cenarion Bitki Merhemi" end
if E["Cenarion Tactical Badge"] == nil then E["Cenarion Tactical Badge"] = "Cenarion Taktik Rozeti" end
if E["Centaur Ear"] == nil then E["Centaur Ear"] = "Kentaur Kulağı" end
if E["Centipaar Insect Parts"] == nil then E["Centipaar Insect Parts"] = "Centipaar Böcek Parçaları" end
if E["Chained Essence of Eranikus"] == nil then E["Chained Essence of Eranikus"] = "Eranikus'un Zincirlenmiş Özü" end
if E["Chains of Hematus"] == nil then E["Chains of Hematus"] = "Hematus'un Zincirleri" end
if E["Chambermaid Pillaclencher's Pillow"] == nil then E["Chambermaid Pillaclencher's Pillow"] = "Oda Hizmetçisi Pillaclencher'ın Yastığı" end
if E["Channeler's Head"] == nil then E["Channeler's Head"] = "Kanalcının Kafası" end
if E["Charged Rift Gem"] == nil then E["Charged Rift Gem"] = "Yüklü Yarık Mücevheri" end
if E["Charger's Lost Soul"] == nil then E["Charger's Lost Soul"] = "Savaş Atının Kayıp Ruhu" end
if E["Charger's Redeemed Soul"] == nil then E["Charger's Redeemed Soul"] = "Savaş Atının Kurtarılmış Ruhu" end
if E["Charred Horn"] == nil then E["Charred Horn"] = "Kömürleşmiş Boynuz" end
if E["Charred Razormane Wand"] == nil then E["Charred Razormane Wand"] = "Kömürleşmiş Razormane Değneği" end
if E["Chen's Empty Keg"] == nil then E["Chen's Empty Keg"] = "Chen'in Boş Fıçısı" end
if E["Chest of Containment Coffers"] == nil then E["Chest of Containment Coffers"] = "Hapsetme Kutuları Sandığı" end
if E["Chilled Basilisk Haunch"] == nil then E["Chilled Basilisk Haunch"] = "Soğutulmuş Basilisk Budu" end
if E["Chillwind Meat"] == nil then E["Chillwind Meat"] = "Chillwind Eti" end
if E["Chimaerok Tenderloin"] == nil then E["Chimaerok Tenderloin"] = "Chimaerok Bonfilesi" end
if E["Chok'sul's Head"] == nil then E["Chok'sul's Head"] = "Chok'sul'un Kafası" end
if E["Chromatic Carapace"] == nil then E["Chromatic Carapace"] = "Kromatik Kabuk" end
if E["Chromatic Mantle of the Dawn"] == nil then E["Chromatic Mantle of the Dawn"] = "Şafağın Kromatik Pelerini" end
if E["Chucky's Huge Ring"] == nil then E["Chucky's Huge Ring"] = "Chucky'nin Kocaman Yüzüğü" end
if E["Cinder of Cynders"] == nil then E["Cinder of Cynders"] = "Cynders Közü" end
if E["Citrine"] == nil then E["Citrine"] = "Sitrin" end
if E["Clara's Fresh Apple"] == nil then E["Clara's Fresh Apple"] = "Clara'nın Taze Elması" end
if E["Clarice's Pendant"] == nil then E["Clarice's Pendant"] = "Clarice'in Kolyesi" end
if E["Claw Key"] == nil then E["Claw Key"] = "Pençe Anahtar" end
if E["Clay Scarab"] == nil then E["Clay Scarab"] = "Kil Bok Böceği" end
if E["Cleansed Infernal Orb"] == nil then E["Cleansed Infernal Orb"] = "Arındırılmış Infernal Küresi" end
if E["Cleverly Encrypted Letter"] == nil then E["Cleverly Encrypted Letter"] = "Ustaca Şifrelenmiş Mektup" end
if E["Cliffspring River Sample"] == nil then E["Cliffspring River Sample"] = "Cliffspring Nehri Numunesi" end
if E["Cliffwatcher Longhorn Report"] == nil then E["Cliffwatcher Longhorn Report"] = "Cliffwatcher Longhorn Raporu" end
if E["Cloth Request"] == nil then E["Cloth Request"] = "Kumaş Talebi" end
if E["Cloven Hoof"] == nil then E["Cloven Hoof"] = "Çatal Toynak" end
if E["Coagulated Rot"] == nil then E["Coagulated Rot"] = "Pıhtılaşmış Çürüme" end
if E["Coal"] == nil then E["Coal"] = "Kömür" end
if E["Coated Cerulean Vial"] == nil then E["Coated Cerulean Vial"] = "Kaplamalı Gök Mavisi Şişe" end
if E["Codex of Defense"] == nil then E["Codex of Defense"] = "Savunma Kodeksi" end
if E["Cog #5"] == nil then E["Cog #5"] = "5 Numaralı Dişli" end
if E["Coif of Elements"] == nil then E["Coif of Elements"] = "Elementlerin Başlığı" end
if E["Coin of Ancestry"] == nil then E["Coin of Ancestry"] = "Ataların Sikkesi" end
if E["Coldtooth Supplies"] == nil then E["Coldtooth Supplies"] = "Coldtooth Erzakı" end
if E["Collected Dragon Egg"] == nil then E["Collected Dragon Egg"] = "Toplanmış Ejderha Yumurtası" end
if E["Collectronic Module"] == nil then E["Collectronic Module"] = "Toplatronik Modül" end
if E["Cologne Bottle"] == nil then E["Cologne Bottle"] = "Kolonya Şişesi" end
if E["Colossus of Ashi's Husk"] == nil then E["Colossus of Ashi's Husk"] = "Colossus of Ashi'nin Kabuğu" end
if E["Colossus of Regal's Husk"] == nil then E["Colossus of Regal's Husk"] = "Colossus of Regal'in Kabuğu" end
if E["Colossus of Zora's Husk"] == nil then E["Colossus of Zora's Husk"] = "Colossus of Zora'nın Kabuğu" end
if E["Comar's Heart"] == nil then E["Comar's Heart"] = "Comar'ın Kalbi" end
if E["Combat Task Briefing I"] == nil then E["Combat Task Briefing I"] = "Muharebe Görevi Brifingi I" end
if E["Combat Task Briefing II"] == nil then E["Combat Task Briefing II"] = "Muharebe Görevi Brifingi II" end
if E["Combat Task Briefing III"] == nil then E["Combat Task Briefing III"] = "Muharebe Görevi Brifingi III" end
if E["Combat Task Briefing IV"] == nil then E["Combat Task Briefing IV"] = "Muharebe Görevi Brifingi IV" end
if E["Combat Task Briefing IX"] == nil then E["Combat Task Briefing IX"] = "Muharebe Görevi Brifingi IX" end
if E["Combat Task Briefing V"] == nil then E["Combat Task Briefing V"] = "Muharebe Görevi Brifingi V" end
if E["Combat Task Briefing VI"] == nil then E["Combat Task Briefing VI"] = "Muharebe Görevi Brifingi VI" end
if E["Combat Task Briefing VII"] == nil then E["Combat Task Briefing VII"] = "Muharebe Görevi Brifingi VII" end
if E["Combat Task Briefing VIII"] == nil then E["Combat Task Briefing VIII"] = "Muharebe Görevi Brifingi VIII" end
if E["Combat Task Briefing X"] == nil then E["Combat Task Briefing X"] = "Muharebe Görevi Brifingi X" end
if E["Combat Task Briefing XI"] == nil then E["Combat Task Briefing XI"] = "Muharebe Görevi Brifingi XI" end
if E["Combat Task Briefing XII"] == nil then E["Combat Task Briefing XII"] = "Muharebe Görevi Brifingi XII" end
if E["Commendation - Elwynn Forest"] == nil then E["Commendation - Elwynn Forest"] = "Takdirname - Elwynn Forest" end
if E["Compendium of the Fallen"] == nil then E["Compendium of the Fallen"] = "Düşmüşlerin Derlemesi" end
if E["Consecrated Letter"] == nil then E["Consecrated Letter"] = "Kutsanmış Mektup" end
if E["Consecrated Rune"] == nil then E["Consecrated Rune"] = "Kutsanmış Rün" end
if E["Console Key"] == nil then E["Console Key"] = "Konsol Anahtarı" end
if E["Control Console Operating Manual"] == nil then E["Control Console Operating Manual"] = "Kontrol Konsolu Kullanım Kılavuzu" end
if E["Copper Axe"] == nil then E["Copper Axe"] = "Bakır Balta" end
if E["Copper Chain Belt"] == nil then E["Copper Chain Belt"] = "Bakır Zincir Kemer" end
if E["Copper Modulator"] == nil then E["Copper Modulator"] = "Bakır Modülatör" end
if E["Cord of Elements"] == nil then E["Cord of Elements"] = "Elementlerin Kuşağı" end
if E["Core Fragment"] == nil then E["Core Fragment"] = "Çekirdek Parçası" end
if E["Core Leather"] == nil then E["Core Leather"] = "Çekirdek Derisi" end
if E["Core of Earth"] == nil then E["Core of Earth"] = "Toprağın Çekirdeği" end
if E["Core of Elements"] == nil then E["Core of Elements"] = "Elementlerin Çekirdeği" end
if E["Corroded Black Box"] == nil then E["Corroded Black Box"] = "Paslanmış Kara Kutu" end
if E["Corroded Shrapnel"] == nil then E["Corroded Shrapnel"] = "Paslanmış Şarapnel" end
if E["Corrosive Sap"] == nil then E["Corrosive Sap"] = "Aşındırıcı Özsu" end
if E["Corrupt Manifestation's Bracers"] == nil then E["Corrupt Manifestation's Bracers"] = "Yozlaşmış Tezahürün Bileklikleri" end
if E["Corrupt Moonwell Water"] == nil then E["Corrupt Moonwell Water"] = "Yozlaşmış Ay Kuyusu Suyu" end
if E["Corrupted Brain Stem"] == nil then E["Corrupted Brain Stem"] = "Yozlaşmış Beyin Sapı" end
if E["Corrupted Felwood Sample"] == nil then E["Corrupted Felwood Sample"] = "Yozlaşmış Felwood Numunesi" end
if E["Corrupted Furbolg Totem"] == nil then E["Corrupted Furbolg Totem"] = "Yozlaşmış Furbolg Totemi" end
if E["Corrupted Kor Gem"] == nil then E["Corrupted Kor Gem"] = "Yozlaşmış Kor Mücevheri" end
if E["Corrupted Soul Shard"] == nil then E["Corrupted Soul Shard"] = "Yozlaşmış Ruh Parçası" end
if E["Corruptor's Scourgestone"] == nil then E["Corruptor's Scourgestone"] = "Yozlaştırıcının Scourge Taşı" end
if E["Cortello's Riddle"] == nil then E["Cortello's Riddle"] = "Cortello'nun Bilmecesi" end
if E["Courser Eye"] == nil then E["Courser Eye"] = "Courser Gözü" end
if E["Covert Ops Pack"] == nil then E["Covert Ops Pack"] = "Gizli Operasyon Çantası" end
if E["Covert Ops Plans: Alpha & Beta"] == nil then E["Covert Ops Plans: Alpha & Beta"] = "Gizli Operasyon Planları: Alfa ve Beta" end
if E["Coyote Jawbone"] == nil then E["Coyote Jawbone"] = "Çakal Çene Kemiği" end
if E["Cozzle's Key"] == nil then E["Cozzle's Key"] = "Cozzle'ın Anahtarı" end
if E["Cracked Necrotic Crystal"] == nil then E["Cracked Necrotic Crystal"] = "Çatlak Nekrotik Kristal" end
if E["Cracked Silithid Carapace"] == nil then E["Cracked Silithid Carapace"] = "Çatlak Silithid Kabuğu" end
if E["Cracked Skull Mortar"] == nil then E["Cracked Skull Mortar"] = "Çatlak Kafatası Havanı" end
if E["Craftsman's Writ - Brightcloth Pants"] == nil then E["Craftsman's Writ - Brightcloth Pants"] = "Zanaatkâr Fermanı - Parlak Kumaş Pantolon" end
if E["Craftsman's Writ - Dense Weightstone"] == nil then E["Craftsman's Writ - Dense Weightstone"] = "Zanaatkâr Fermanı - Yoğun Ağırlık Taşı" end
if E["Craftsman's Writ - Flask of Petrification"] == nil then E["Craftsman's Writ - Flask of Petrification"] = "Zanaatkâr Fermanı - Taşlaşma Matarası" end
if E["Craftsman's Writ - Gnomish Battle Chicken"] == nil then E["Craftsman's Writ - Gnomish Battle Chicken"] = "Zanaatkâr Fermanı - Gnome Savaş Tavuğu" end
if E["Craftsman's Writ - Goblin Sapper Charge"] == nil then E["Craftsman's Writ - Goblin Sapper Charge"] = "Zanaatkâr Fermanı - Goblin İstihkâm Patlayıcısı" end
if E["Craftsman's Writ - Greater Arcane Protection Potion"] == nil then E["Craftsman's Writ - Greater Arcane Protection Potion"] = "Zanaatkâr Fermanı - Büyük Arkan Koruma İksiri" end
if E["Craftsman's Writ - Huge Thorium Battleaxe"] == nil then E["Craftsman's Writ - Huge Thorium Battleaxe"] = "Zanaatkâr Fermanı - Devasa Toryum Savaş Baltası" end
if E["Craftsman's Writ - Imperial Plate Chest"] == nil then E["Craftsman's Writ - Imperial Plate Chest"] = "Zanaatkâr Fermanı - İmparatorluk Plaka Göğüslüğü" end
if E["Craftsman's Writ - Lightning Eel"] == nil then E["Craftsman's Writ - Lightning Eel"] = "Zanaatkâr Fermanı - Şimşek Yılanbalığı" end
if E["Craftsman's Writ - Major Healing Potion"] == nil then E["Craftsman's Writ - Major Healing Potion"] = "Zanaatkâr Fermanı - Büyük Şifa İksiri" end
if E["Craftsman's Writ - Major Mana Potion"] == nil then E["Craftsman's Writ - Major Mana Potion"] = "Zanaatkâr Fermanı - Büyük Mana İksiri" end
if E["Craftsman's Writ - Plated Armorfish"] == nil then E["Craftsman's Writ - Plated Armorfish"] = "Zanaatkâr Fermanı - Plakalı Zırh Balığı" end
if E["Craftsman's Writ - Radiant Circlet"] == nil then E["Craftsman's Writ - Radiant Circlet"] = "Zanaatkâr Fermanı - Işıltılı Taç" end
if E["Craftsman's Writ - Rugged Armor Kit"] == nil then E["Craftsman's Writ - Rugged Armor Kit"] = "Zanaatkâr Fermanı - Sağlam Zırh Takımı" end
if E["Craftsman's Writ - Runecloth Bag"] == nil then E["Craftsman's Writ - Runecloth Bag"] = "Zanaatkâr Fermanı - Rün Kumaşı Çanta" end
if E["Craftsman's Writ - Runecloth Boots"] == nil then E["Craftsman's Writ - Runecloth Boots"] = "Zanaatkâr Fermanı - Rün Kumaşı Çizme" end
if E["Craftsman's Writ - Runecloth Robe"] == nil then E["Craftsman's Writ - Runecloth Robe"] = "Zanaatkâr Fermanı - Rün Kumaşı Cüppe" end
if E["Craftsman's Writ - Runic Leather Pants"] == nil then E["Craftsman's Writ - Runic Leather Pants"] = "Zanaatkâr Fermanı - Rünlü Deri Pantolon" end
if E["Craftsman's Writ - Stonescale Eel"] == nil then E["Craftsman's Writ - Stonescale Eel"] = "Zanaatkâr Fermanı - Taş Pullu Yılanbalığı" end
if E["Craftsman's Writ - Thorium Grenade"] == nil then E["Craftsman's Writ - Thorium Grenade"] = "Zanaatkâr Fermanı - Toryum El Bombası" end
if E["Craftsman's Writ - Thorium Tube"] == nil then E["Craftsman's Writ - Thorium Tube"] = "Zanaatkâr Fermanı - Toryum Boru" end
if E["Craftsman's Writ - Volcanic Hammer"] == nil then E["Craftsman's Writ - Volcanic Hammer"] = "Zanaatkâr Fermanı - Volkanik Çekiç" end
if E["Craftsman's Writ - Wicked Leather Belt"] == nil then E["Craftsman's Writ - Wicked Leather Belt"] = "Zanaatkâr Fermanı - Habis Deri Kemer" end
if E["Craftsman's Writ - Wicked Leather Headband"] == nil then E["Craftsman's Writ - Wicked Leather Headband"] = "Zanaatkâr Fermanı - Habis Deri Saç Bandı" end
if E["Crag Coyote Fang"] == nil then E["Crag Coyote Fang"] = "Kayalık Çakalı Dişi" end
if E["Crate With Holes"] == nil then E["Crate With Holes"] = "Delikli Sandık" end
if E["Crate of Crash Helmets"] == nil then E["Crate of Crash Helmets"] = "Bir Sandık Kask" end
if E["Crate of Foodstuffs"] == nil then E["Crate of Foodstuffs"] = "Bir Sandık Gıda" end
if E["Crate of Ghost Magnets"] == nil then E["Crate of Ghost Magnets"] = "Bir Sandık Hayalet Mıknatısı" end
if E["Crate of Grimtotem Horns"] == nil then E["Crate of Grimtotem Horns"] = "Bir Sandık Grimtotem Boynuzu" end
if E["Crate of Horseshoes"] == nil then E["Crate of Horseshoes"] = "Bir Sandık Nal" end
if E["Crate of Lightforge Ingots"] == nil then E["Crate of Lightforge Ingots"] = "Bir Sandık Lightforge Külçesi" end
if E["Crate of Power Stones"] == nil then E["Crate of Power Stones"] = "Bir Sandık Güç Taşı" end
if E["Crawler Leg"] == nil then E["Crawler Leg"] = "Sürüngen Bacağı" end
if E["Creased Letter"] == nil then E["Creased Letter"] = "Kırışık Mektup" end
if E["Creeper Ichor"] == nil then E["Creeper Ichor"] = "Sarmaşık Irini" end
if E["Cresting Charm"] == nil then E["Cresting Charm"] = "Kabaran Tılsım" end
if E["Cresting Key"] == nil then E["Cresting Key"] = "Kabaran Anahtar" end
if E["Crimson Hammersmith's Apron"] == nil then E["Crimson Hammersmith's Apron"] = "Crimson Çekiç Ustasının Önlüğü" end
if E["Crisp Spider Meat"] == nil then E["Crisp Spider Meat"] = "Gevrek Örümcek Eti" end
if E["Crocolisk Meat"] == nil then E["Crocolisk Meat"] = "Crocolisk Eti" end
if E["Crocolisk Skin"] == nil then E["Crocolisk Skin"] = "Crocolisk Derisi" end
if E["Crocolisk Tear"] == nil then E["Crocolisk Tear"] = "Crocolisk Gözyaşı" end
if E["Crown of Will"] == nil then E["Crown of Will"] = "İrade Tacı" end
if E["Crown of the Council"] == nil then E["Crown of the Council"] = "Konseyin Tacı" end
if E["Crude Charm"] == nil then E["Crude Charm"] = "Kaba Tılsım" end
if E["Crude Flint"] == nil then E["Crude Flint"] = "Kaba Çakmaktaşı" end
if E["Crudely Dried Meat"] == nil then E["Crudely Dried Meat"] = "Kabaca Kurutulmuş Et" end
if E["Crudely-written Log"] == nil then E["Crudely-written Log"] = "Özensizce Yazılmış Kayıt" end
if E["Crumpled Scroll Fragment"] == nil then E["Crumpled Scroll Fragment"] = "Buruşmuş Parşömen Parçası" end
if E["Crushed Elemental Bracer"] == nil then E["Crushed Elemental Bracer"] = "Ezilmiş Element Bilekliği" end
if E["Crypt Fiend Parts"] == nil then E["Crypt Fiend Parts"] = "Mahzen İblisi Parçaları" end
if E["Crystal Charge"] == nil then E["Crystal Charge"] = "Kristal Yükü" end
if E["Crystal Force"] == nil then E["Crystal Force"] = "Kristal Gücü" end
if E["Crystal Pylon User's Manual"] == nil then E["Crystal Pylon User's Manual"] = "Kristal Pilon Kullanım Kılavuzu" end
if E["Crystal Restore"] == nil then E["Crystal Restore"] = "Kristal Onarımı" end
if E["Crystal Scarab"] == nil then E["Crystal Scarab"] = "Kristal Bok Böceği" end
if E["Crystal Spire"] == nil then E["Crystal Spire"] = "Kristal Kule" end
if E["Crystal Unlocking Mechanism"] == nil then E["Crystal Unlocking Mechanism"] = "Kristal Kilit Açma Mekanizması" end
if E["Crystal Ward"] == nil then E["Crystal Ward"] = "Kristal Siper" end
if E["Crystal Yield"] == nil then E["Crystal Yield"] = "Kristal Verimi" end
if E["Crystal of Zin-Malor"] == nil then E["Crystal of Zin-Malor"] = "Zin-Malor Kristali" end
if E["Crystalized Scales"] == nil then E["Crystalized Scales"] = "Kristalleşmiş Pullar" end
if E["Crystallized Azsharite"] == nil then E["Crystallized Azsharite"] = "Kristalleşmiş Azsharite" end
if E["Cuely's Elixir"] == nil then E["Cuely's Elixir"] = "Cuely'nin İksiri" end
if E["Cuergo's Hidden Treasure"] == nil then E["Cuergo's Hidden Treasure"] = "Cuergo'nun Gizli Hazinesi" end
if E["Cuergo's Key"] == nil then E["Cuergo's Key"] = "Cuergo'nun Anahtarı" end
if E["Cuergo's Treasure Map"] == nil then E["Cuergo's Treasure Map"] = "Cuergo'nun Hazine Haritası" end
if E["Curative Animal Salve"] == nil then E["Curative Animal Salve"] = "İyileştirici Hayvan Merhemi" end
if E["Cured Rugged Hide"] == nil then E["Cured Rugged Hide"] = "Tabaklanmış Sert Post" end
if E["Curled Map Parchment"] == nil then E["Curled Map Parchment"] = "Kıvrılmış Harita Parşömeni" end
if E["Cursed Eye of Paleth"] == nil then E["Cursed Eye of Paleth"] = "Paleth'in Lanetli Gözü" end
if E["Cyrik's Head"] == nil then E["Cyrik's Head"] = "Cyrik'in Kafası" end
if E["DEBUG Samophlange Manual Cover"] == nil then E["DEBUG Samophlange Manual Cover"] = "DEBUG Samophlange Kılavuz Kapağı" end
if E["Daffodil Bouquet"] == nil then E["Daffodil Bouquet"] = "Nergis Buketi" end
if E["Daggerspine Scale"] == nil then E["Daggerspine Scale"] = "Daggerspine Pulu" end
if E["Dal Bloodclaw's Skull"] == nil then E["Dal Bloodclaw's Skull"] = "Dal Bloodclaw'un Kafatası" end
if E["Dalaran Mana Gem"] == nil then E["Dalaran Mana Gem"] = "Dalaran Mana Mücevheri" end
if E["Dalaran Status Report"] == nil then E["Dalaran Status Report"] = "Dalaran Durum Raporu" end
if E["Dalin's Heart"] == nil then E["Dalin's Heart"] = "Dalin'in Kalbi" end
if E["Dalson Cabinet Key"] == nil then E["Dalson Cabinet Key"] = "Dalson Dolap Anahtarı" end
if E["Dalson Outhouse Key"] == nil then E["Dalson Outhouse Key"] = "Dalson Dış Tuvalet Anahtarı" end
if E["Dalson's Tears Cauldron Key"] == nil then E["Dalson's Tears Cauldron Key"] = "Dalson's Tears Kazan Anahtarı" end
if E["Damaged Elemental Bracer"] == nil then E["Damaged Elemental Bracer"] = "Hasarlı Element Bilekliği" end
if E["Damp Note"] == nil then E["Damp Note"] = "Nemli Not" end
if E["Dark Iron Ale Mug"] == nil then E["Dark Iron Ale Mug"] = "Dark Iron Bira Kupası" end
if E["Dark Iron Bar"] == nil then E["Dark Iron Bar"] = "Dark Iron Külçesi" end
if E["Dark Iron Fanny Pack"] == nil then E["Dark Iron Fanny Pack"] = "Dark Iron Bel Çantası" end
if E["Dark Iron Ore"] == nil then E["Dark Iron Ore"] = "Dark Iron Cevheri" end
if E["Dark Iron Pillow"] == nil then E["Dark Iron Pillow"] = "Dark Iron Yastığı" end
if E["Dark Iron Residue"] == nil then E["Dark Iron Residue"] = "Dark Iron Kalıntısı" end
if E["Dark Iron Scraps"] == nil then E["Dark Iron Scraps"] = "Dark Iron Hurdaları" end
if E["Dark Iron Script"] == nil then E["Dark Iron Script"] = "Dark Iron Yazıtı" end
if E["Dark Parchment"] == nil then E["Dark Parchment"] = "Karanlık Parşömen" end
if E["Dark Rune"] == nil then E["Dark Rune"] = "Karanlık Rün" end
if E["Darkmoon Faire Prize Ticket"] == nil then E["Darkmoon Faire Prize Ticket"] = "Darkmoon Faire Ödül Bileti" end
if E["Darkreaver's Head"] == nil then E["Darkreaver's Head"] = "Darkreaver'ın Kafası" end
if E["Darkshore Grouper"] == nil then E["Darkshore Grouper"] = "Darkshore Orfozu" end
if E["Darkspear Gumdrop"] == nil then E["Darkspear Gumdrop"] = "Darkspear Jelibonu" end
if E["Darkspear Troll Mojo"] == nil then E["Darkspear Troll Mojo"] = "Darkspear Trol Mojosu" end
if E["Darkstone Tablet"] == nil then E["Darkstone Tablet"] = "Darkstone Tableti" end
if E["Darnassus Marzipan"] == nil then E["Darnassus Marzipan"] = "Darnassus Badem Ezmesi" end
if E["Darthalia's Sealed Commendation"] == nil then E["Darthalia's Sealed Commendation"] = "Darthalia'nın Mühürlü Takdirnamesi" end
if E["Dartol's Rod of Transformation"] == nil then E["Dartol's Rod of Transformation"] = "Dartol'un Dönüşüm Çubuğu" end
if E["Davil's Libram"] == nil then E["Davil's Libram"] = "Davil'in Libramı" end
if E["Dawn's Gambit"] == nil then E["Dawn's Gambit"] = "Şafağın Hamlesi" end
if E["Dead-tooth's Key"] == nil then E["Dead-tooth's Key"] = "Dead-tooth'un Anahtarı" end
if E["Deadly Blunderbuss"] == nil then E["Deadly Blunderbuss"] = "Ölümcül Alaybozan" end
if E["Deadmire's Tooth"] == nil then E["Deadmire's Tooth"] = "Deadmire'ın Dişi" end
if E["Deadwood Headdress Feather"] == nil then E["Deadwood Headdress Feather"] = "Deadwood Başlık Tüyü" end
if E["Deadwood Ritual Totem"] == nil then E["Deadwood Ritual Totem"] = "Deadwood Ayin Totemi" end
if E["Death Cap"] == nil then E["Death Cap"] = "Ölüm Mantarı" end
if E["Deathclasp's Pincer"] == nil then E["Deathclasp's Pincer"] = "Deathclasp'ın Kıskacı" end
if E["Decoded Tablet Transcription"] == nil then E["Decoded Tablet Transcription"] = "Çözülmüş Tablet Metni" end
if E["Decrypted Letter"] == nil then E["Decrypted Letter"] = "Şifresi Çözülmüş Mektup" end
if E["Deepfury's Orders"] == nil then E["Deepfury's Orders"] = "Deepfury'nin Emirleri" end
if E["Deepmoss Egg"] == nil then E["Deepmoss Egg"] = "Deepmoss Yumurtası" end
if E["Deeprock Salt"] == nil then E["Deeprock Salt"] = "Derin Kaya Tuzu" end
if E["Deepstrider Tumor"] == nil then E["Deepstrider Tumor"] = "Deepstrider Tümörü" end
if E["Defiant Orc Head"] == nil then E["Defiant Orc Head"] = "Asi Ork Kafası" end
if E["Defias Docket"] == nil then E["Defias Docket"] = "Defias Belgesi" end
if E["Defias Script"] == nil then E["Defias Script"] = "Defias Yazıtı" end
if E["Defias Shipping Schedule"] == nil then E["Defias Shipping Schedule"] = "Defias Sevkiyat Çizelgesi" end
if E["Defias Tower Key"] == nil then E["Defias Tower Key"] = "Defias Kule Anahtarı" end
if E["Deino's Flask"] == nil then E["Deino's Flask"] = "Deino'nun Matarası" end
if E["Delicate Arcanite Converter"] == nil then E["Delicate Arcanite Converter"] = "Hassas Arcanite Dönüştürücü" end
if E["Delicate Car Parts"] == nil then E["Delicate Car Parts"] = "Hassas Araba Parçaları" end
if E["Delivery to Mathias"] == nil then E["Delivery to Mathias"] = "Mathias'a Teslimat" end
if E["Demon Box"] == nil then E["Demon Box"] = "İblis Kutusu" end
if E["Demon Kissed Sack"] == nil then E["Demon Kissed Sack"] = "İblis Öpücüklü Çuval" end
if E["Demon Pick"] == nil then E["Demon Pick"] = "İblis Kazması" end
if E["Demon Summoning Torch"] == nil then E["Demon Summoning Torch"] = "İblis Çağırma Meşalesi" end
if E["Dense Blasting Powder"] == nil then E["Dense Blasting Powder"] = "Yoğun Patlayıcı Toz" end
if E["Dense Grinding Stone"] == nil then E["Dense Grinding Stone"] = "Yoğun Bileme Taşı" end
if E["Dense Weightstone"] == nil then E["Dense Weightstone"] = "Yoğun Ağırlık Taşı" end
if E["Dentrium Power Stone"] == nil then E["Dentrium Power Stone"] = "Dentrium Güç Taşı" end
if E["Desecrated Belt"] == nil then E["Desecrated Belt"] = "Kirletilmiş Kemer" end
if E["Desecrated Bindings"] == nil then E["Desecrated Bindings"] = "Kirletilmiş Bileklikler" end
if E["Desecrated Boots"] == nil then E["Desecrated Boots"] = "Kirletilmiş Çizmeler" end
if E["Desecrated Bracers"] == nil then E["Desecrated Bracers"] = "Kirletilmiş Kolluklar" end
if E["Desecrated Breastplate"] == nil then E["Desecrated Breastplate"] = "Kirletilmiş Göğüslük" end
if E["Desecrated Circlet"] == nil then E["Desecrated Circlet"] = "Kirletilmiş Taç" end
if E["Desecrated Gauntlets"] == nil then E["Desecrated Gauntlets"] = "Kirletilmiş Zırh Eldivenleri" end
if E["Desecrated Girdle"] == nil then E["Desecrated Girdle"] = "Kirletilmiş Kuşak" end
if E["Desecrated Gloves"] == nil then E["Desecrated Gloves"] = "Kirletilmiş Eldivenler" end
if E["Desecrated Handguards"] == nil then E["Desecrated Handguards"] = "Kirletilmiş El Korumaları" end
if E["Desecrated Headpiece"] == nil then E["Desecrated Headpiece"] = "Kirletilmiş Başlık" end
if E["Desecrated Helmet"] == nil then E["Desecrated Helmet"] = "Kirletilmiş Miğfer" end
if E["Desecrated Leggings"] == nil then E["Desecrated Leggings"] = "Kirletilmiş Tozluklar" end
if E["Desecrated Legguards"] == nil then E["Desecrated Legguards"] = "Kirletilmiş Bacak Korumaları" end
if E["Desecrated Legplates"] == nil then E["Desecrated Legplates"] = "Kirletilmiş Bacak Plakaları" end
if E["Desecrated Pauldrons"] == nil then E["Desecrated Pauldrons"] = "Kirletilmiş Omuz Plakaları" end
if E["Desecrated Robe"] == nil then E["Desecrated Robe"] = "Kirletilmiş Cüppe" end
if E["Desecrated Sabatons"] == nil then E["Desecrated Sabatons"] = "Kirletilmiş Zırh Çizmeleri" end
if E["Desecrated Sandals"] == nil then E["Desecrated Sandals"] = "Kirletilmiş Sandaletler" end
if E["Desecrated Shoulderpads"] == nil then E["Desecrated Shoulderpads"] = "Kirletilmiş Omuz Yastıkları" end
if E["Desecrated Spaulders"] == nil then E["Desecrated Spaulders"] = "Kirletilmiş Omuzluklar" end
if E["Desecrated Tunic"] == nil then E["Desecrated Tunic"] = "Kirletilmiş Tunik" end
if E["Desecrated Waistguard"] == nil then E["Desecrated Waistguard"] = "Kirletilmiş Bel Koruması" end
if E["Desecrated Wristguards"] == nil then E["Desecrated Wristguards"] = "Kirletilmiş Bilek Korumaları" end
if E["Detailed Parchment"] == nil then E["Detailed Parchment"] = "Ayrıntılı Parşömen" end
if E["Deviate Hide"] == nil then E["Deviate Hide"] = "Sapkın Post" end
if E["Devilsaur Barb"] == nil then E["Devilsaur Barb"] = "Devilsaur Dikeni" end
if E["Devout Belt"] == nil then E["Devout Belt"] = "Dindar Kemer" end
if E["Devout Bracers"] == nil then E["Devout Bracers"] = "Dindar Bileklikler" end
if E["Devout Crown"] == nil then E["Devout Crown"] = "Dindar Taç" end
if E["Devout Gloves"] == nil then E["Devout Gloves"] = "Dindar Eldivenler" end
if E["Devout Mantle"] == nil then E["Devout Mantle"] = "Dindar Omuzluk" end
if E["Devout Robe"] == nil then E["Devout Robe"] = "Dindar Cüppe" end
if E["Devout Sandals"] == nil then E["Devout Sandals"] = "Dindar Sandaletler" end
if E["Devout Skirt"] == nil then E["Devout Skirt"] = "Dindar Etek" end
if E["Dezian Queenfish"] == nil then E["Dezian Queenfish"] = "Dezian Kraliçe Balığı" end
if E["Diamond Runestone"] == nil then E["Diamond Runestone"] = "Elmas Rün Taşı" end
if E["Dig Rat"] == nil then E["Dig Rat"] = "Kazıcı Fare" end
if E["Digging Claw"] == nil then E["Digging Claw"] = "Kazma Pençesi" end
if E["Dim Necrotic Stone"] == nil then E["Dim Necrotic Stone"] = "Sönük Nekrotik Taş" end
if E["Dinosaur Bone"] == nil then E["Dinosaur Bone"] = "Dinozor Kemiği" end
if E["Dirt-caked Pendant"] == nil then E["Dirt-caked Pendant"] = "Toprağa Bulanmış Kolye" end
if E["Dirt-stained Map"] == nil then E["Dirt-stained Map"] = "Toprak Lekeli Harita" end
if E["Dirty Knucklebones"] == nil then E["Dirty Knucklebones"] = "Kirli Aşık Kemikleri" end
if E["Disarming Colloid"] == nil then E["Disarming Colloid"] = "Etkisizleştirici Koloit" end
if E["Disarming Mixture"] == nil then E["Disarming Mixture"] = "Etkisizleştirici Karışım" end
if E["Discarded Knife"] == nil then E["Discarded Knife"] = "Atılmış Bıçak" end
if E["Discordant Bracers"] == nil then E["Discordant Bracers"] = "Uyumsuz Bileklikler" end
if E["Divination Scryer"] == nil then E["Divination Scryer"] = "Kehanet Kristali" end
if E["Divined Scroll"] == nil then E["Divined Scroll"] = "Kehanetle Bulunmuş Parşömen" end
if E["Divining Scroll"] == nil then E["Divining Scroll"] = "Kehanet Parşömeni" end
if E["Divino-matic Rod"] == nil then E["Divino-matic Rod"] = "Kehanet-o-matik Çubuk" end
if E["Dizzy's Eye"] == nil then E["Dizzy's Eye"] = "Dizzy'nin Gözü" end
if E["Dogran's Pendant"] == nil then E["Dogran's Pendant"] = "Dogran'ın Kolyesi" end
if E["Doomrigger's Clasp"] == nil then E["Doomrigger's Clasp"] = "Doomrigger'ın Tokası" end
if E["Doomsday Flare"] == nil then E["Doomsday Flare"] = "Kıyamet İşaret Fişeği" end
if E["Doomwarder Blood"] == nil then E["Doomwarder Blood"] = "Doomwarder Kanı" end
if E["Dormant Wind Kissed Blade"] == nil then E["Dormant Wind Kissed Blade"] = "Uykudaki Rüzgâr Öpücüklü Kılıç" end
if E["Draconic For Dummies: Volume II"] == nil then E["Draconic For Dummies: Volume II"] = "Aptallar İçin Ejderhaca: Cilt II" end
if E["Draenethyst Crystal"] == nil then E["Draenethyst Crystal"] = "Draenethyst Kristali" end
if E["Draenethyst Shard"] == nil then E["Draenethyst Shard"] = "Draenethyst Parçası" end
if E["Dragonmaw Shinbone"] == nil then E["Dragonmaw Shinbone"] = "Dragonmaw İncik Kemiği" end
if E["Dragonmaw War Banner"] == nil then E["Dragonmaw War Banner"] = "Dragonmaw Savaş Sancağı" end
if E["Dran's Ripple Delivery"] == nil then E["Dran's Ripple Delivery"] = "Dran'ın Ripple Teslimatı" end
if E["Drawing Kit"] == nil then E["Drawing Kit"] = "Çizim Takımı" end
if E["Dreadmist Belt"] == nil then E["Dreadmist Belt"] = "Korku Sisi Kemeri" end
if E["Dreadmist Bracers"] == nil then E["Dreadmist Bracers"] = "Korku Sisi Bileklikleri" end
if E["Dreadmist Leggings"] == nil then E["Dreadmist Leggings"] = "Korku Sisi Tozlukları" end
if E["Dreadmist Mantle"] == nil then E["Dreadmist Mantle"] = "Korku Sisi Omuzluğu" end
if E["Dreadmist Mask"] == nil then E["Dreadmist Mask"] = "Korku Sisi Maskesi" end
if E["Dreadmist Robe"] == nil then E["Dreadmist Robe"] = "Korku Sisi Cüppesi" end
if E["Dreadmist Sandals"] == nil then E["Dreadmist Sandals"] = "Korku Sisi Sandaletleri" end
if E["Dreadmist Wraps"] == nil then E["Dreadmist Wraps"] = "Korku Sisi Sargıları" end
if E["Druidical Remains"] == nil then E["Druidical Remains"] = "Druid Kalıntıları" end
if E["Duke's Seal"] == nil then E["Duke's Seal"] = "Dükün Mührü" end
if E["Dull Drakefire Amulet"] == nil then E["Dull Drakefire Amulet"] = "Sönük Drakefire Muskası" end
if E["Dull Iron Key"] == nil then E["Dull Iron Key"] = "Mat Demir Anahtar" end
if E["Dusky Crab Cakes"] == nil then E["Dusky Crab Cakes"] = "Alacakaranlık Yengeç Köftesi" end
if E["Dust Devil Debris"] == nil then E["Dust Devil Debris"] = "Toz Hortumu Enkazı" end
if E["Dwarf Spine"] == nil then E["Dwarf Spine"] = "Cüce Omurgası" end
if E["Dwarven Tinder"] == nil then E["Dwarven Tinder"] = "Cüce Kavı" end
if E["Ear of Balgaras"] == nil then E["Ear of Balgaras"] = "Balgaras'ın Kulağı" end
if E["Earth Sapta"] == nil then E["Earth Sapta"] = "Toprak Saptası" end
if E["Ebonlocke's Response to Solomon"] == nil then E["Ebonlocke's Response to Solomon"] = "Ebonlocke'un Solomon'a Yanıtı" end
if E["Ectoplasmic Distiller"] == nil then E["Ectoplasmic Distiller"] = "Ektoplazmik Damıtıcı" end
if E["Ectoplasmic Resonator"] == nil then E["Ectoplasmic Resonator"] = "Ektoplazmik Rezonatör" end
if E["Edana's Dark Heart"] == nil then E["Edana's Dark Heart"] = "Edana'nın Kara Kalbi" end
if E["Egalin's Grimoire"] == nil then E["Egalin's Grimoire"] = "Egalin'in Büyü Kitabı" end
if E["Egan's Blaster"] == nil then E["Egan's Blaster"] = "Egan'ın Patlatıcısı" end
if E["Egg Crate"] == nil then E["Egg Crate"] = "Yumurta Kasası" end
if E["Egg of Hakkar"] == nil then E["Egg of Hakkar"] = "Hakkar Yumurtası" end
if E["Eggscilloscope Prototype"] == nil then E["Eggscilloscope Prototype"] = "Yumurtaskop Prototipi" end
if E["Elaborate Parchment"] == nil then E["Elaborate Parchment"] = "Süslü Parşömen" end
if E["Elder Crocolisk Skin"] == nil then E["Elder Crocolisk Skin"] = "Yaşlı Crocolisk Derisi" end
if E["Eldritch Shackles"] == nil then E["Eldritch Shackles"] = "Ürkünç Prangalar" end
if E["Electropeller"] == nil then E["Electropeller"] = "Elektropervane" end
if E["Elegant Letter"] == nil then E["Elegant Letter"] = "Zarif Mektup" end
if E["Elemental Air"] == nil then E["Elemental Air"] = "Elemental Hava" end
if E["Elemental Earth"] == nil then E["Elemental Earth"] = "Elemental Toprak" end
if E["Elemental Fire"] == nil then E["Elemental Fire"] = "Elemental Ateş" end
if E["Elemental Shard Sample"] == nil then E["Elemental Shard Sample"] = "Elemental Kırık Örneği" end
if E["Elemental Water"] == nil then E["Elemental Water"] = "Elemental Su" end
if E["Elementals Deck"] == nil then E["Elementals Deck"] = "Elementaller Destesi" end
if E["Elementium Bar"] == nil then E["Elementium Bar"] = "Elementium Külçesi" end
if E["Elementium Ore"] == nil then E["Elementium Ore"] = "Elementium Cevheri" end
if E["Elixir of Fortitude"] == nil then E["Elixir of Fortitude"] = "Metanet İksiri" end
if E["Elixir of Minor Defense"] == nil then E["Elixir of Minor Defense"] = "Küçük Savunma İksiri" end
if E["Elixir of Pain"] == nil then E["Elixir of Pain"] = "Acı İksiri" end
if E["Elixir of Shadow Power"] == nil then E["Elixir of Shadow Power"] = "Gölge Gücü İksiri" end
if E["Elixir of Suffering"] == nil then E["Elixir of Suffering"] = "Izdırap İksiri" end
if E["Elune's Tear"] == nil then E["Elune's Tear"] = "Elune'un Gözyaşı" end
if E["Elunite Ore"] == nil then E["Elunite Ore"] = "Elunite Cevheri" end
if E["Elura's Medallion"] == nil then E["Elura's Medallion"] = "Elura'nın Madalyonu" end
if E["Elven Cup Relic"] == nil then E["Elven Cup Relic"] = "Elf Kadehi Kalıntısı" end
if E["Elven Gem"] == nil then E["Elven Gem"] = "Elf Mücevheri" end
if E["Elven Gems"] == nil then E["Elven Gems"] = "Elf Mücevherleri" end
if E["Ember of Emberseer"] == nil then E["Ember of Emberseer"] = "Emberseer'ın Közü" end
if E["Embossed Leather Boots"] == nil then E["Embossed Leather Boots"] = "Kabartmalı Deri Çizme" end
if E["Embossed Leather Cloak"] == nil then E["Embossed Leather Cloak"] = "Kabartmalı Deri Pelerin" end
if E["Embossed Leather Gloves"] == nil then E["Embossed Leather Gloves"] = "Kabartmalı Deri Eldiven" end
if E["Empty Blue Waterskin"] == nil then E["Empty Blue Waterskin"] = "Boş Mavi Su Tulumu" end
if E["Empty Brown Waterskin"] == nil then E["Empty Brown Waterskin"] = "Boş Kahverengi Su Tulumu" end
if E["Empty Canteen"] == nil then E["Empty Canteen"] = "Boş Matara" end
if E["Empty Cleansing Bowl"] == nil then E["Empty Cleansing Bowl"] = "Boş Arındırma Kâsesi" end
if E["Empty Cliffspring Falls Sampler"] == nil then E["Empty Cliffspring Falls Sampler"] = "Boş Cliffspring Falls Numune Kabı" end
if E["Empty Dalson's Tears Bottle"] == nil then E["Empty Dalson's Tears Bottle"] = "Boş Dalson's Tears Şişesi" end
if E["Empty Dreadmist Peak Sampler"] == nil then E["Empty Dreadmist Peak Sampler"] = "Boş Dreadmist Peak Numune Kabı" end
if E["Empty Felstone Field Bottle"] == nil then E["Empty Felstone Field Bottle"] = "Boş Felstone Field Şişesi" end
if E["Empty Firewater Flask"] == nil then E["Empty Firewater Flask"] = "Boş Ateşsuyu Matarası" end
if E["Empty Gahrron's Withering Bottle"] == nil then E["Empty Gahrron's Withering Bottle"] = "Boş Gahrron's Withering Şişesi" end
if E["Empty Leaden Collection Phial"] == nil then E["Empty Leaden Collection Phial"] = "Boş Kurşun Toplama Şişesi" end
if E["Empty Red Waterskin"] == nil then E["Empty Red Waterskin"] = "Boş Kırmızı Su Tulumu" end
if E["Empty Sampling Tube"] == nil then E["Empty Sampling Tube"] = "Boş Numune Tüpü" end
if E["Empty Thaumaturgy Vessel"] == nil then E["Empty Thaumaturgy Vessel"] = "Boş Taumaturji Kabı" end
if E["Empty Vial"] == nil then E["Empty Vial"] = "Boş Şişe" end
if E["Empty Water Tube"] == nil then E["Empty Water Tube"] = "Boş Su Tüpü" end
if E["Empty Water Vial"] == nil then E["Empty Water Vial"] = "Boş Su Şişesi" end
if E["Empty Worg Pup Cage"] == nil then E["Empty Worg Pup Cage"] = "Boş Worg Yavrusu Kafesi" end
if E["Empty Writhing Haunt Bottle"] == nil then E["Empty Writhing Haunt Bottle"] = "Boş Writhing Haunt Şişesi" end
if E["Encased Corrupt Ooze"] == nil then E["Encased Corrupt Ooze"] = "Kaplanmış Bozulmuş Balçık" end
if E["Encased Fiery Essence"] == nil then E["Encased Fiery Essence"] = "Kaplanmış Ateşli Öz" end
if E["Enchanted Agate"] == nil then E["Enchanted Agate"] = "Efsunlu Akik" end
if E["Enchanted Black Dragon Sinew"] == nil then E["Enchanted Black Dragon Sinew"] = "Efsunlu Kara Ejderha Siniri" end
if E["Enchanted Coral"] == nil then E["Enchanted Coral"] = "Efsunlu Mercan" end
if E["Enchanted Gaea Seeds"] == nil then E["Enchanted Gaea Seeds"] = "Efsunlu Gaea Tohumları" end
if E["Enchanted Leather"] == nil then E["Enchanted Leather"] = "Efsunlu Deri" end
if E["Enchanted Moonstalker Cloak"] == nil then E["Enchanted Moonstalker Cloak"] = "Efsunlu Moonstalker Pelerini" end
if E["Enchanted Resonite Crystal"] == nil then E["Enchanted Resonite Crystal"] = "Efsunlu Resonite Kristali" end
if E["Enchanted Scarlet Thread"] == nil then E["Enchanted Scarlet Thread"] = "Efsunlu Kızıl İplik" end
if E["Enchanted Sea Kelp"] == nil then E["Enchanted Sea Kelp"] = "Efsunlu Deniz Yosunu" end
if E["Enchanted South Seas Kelp"] == nil then E["Enchanted South Seas Kelp"] = "Efsunlu Güney Denizleri Yosunu" end
if E["Enchanted Thorium Bar"] == nil then E["Enchanted Thorium Bar"] = "Efsunlu Toryum Külçesi" end
if E["Enchanted Thorium Platemail"] == nil then E["Enchanted Thorium Platemail"] = "Efsunlu Toryum Plaka Zırh" end
if E["Encoded Fragment"] == nil then E["Encoded Fragment"] = "Kodlanmış Parça" end
if E["Encrusted Crystal Fragment"] == nil then E["Encrusted Crystal Fragment"] = "Kabuklanmış Kristal Parçası" end
if E["Encrusted Minerals"] == nil then E["Encrusted Minerals"] = "Kabuklanmış Mineraller" end
if E["Encrusted Silithid Object"] == nil then E["Encrusted Silithid Object"] = "Kabuklanmış Silithid Nesnesi" end
if E["Encrusted Tail Fin"] == nil then E["Encrusted Tail Fin"] = "Kabuklanmış Kuyruk Yüzgeci" end
if E["Encrypted Letter"] == nil then E["Encrypted Letter"] = "Şifreli Mektup" end
if E["Encrypted Memorandum"] == nil then E["Encrypted Memorandum"] = "Şifreli Not" end
if E["Encrypted Parchment"] == nil then E["Encrypted Parchment"] = "Şifreli Parşömen" end
if E["Encrypted Rune"] == nil then E["Encrypted Rune"] = "Şifreli Rün" end
if E["Encrypted Scroll"] == nil then E["Encrypted Scroll"] = "Şifreli Tomar" end
if E["Encrypted Sigil"] == nil then E["Encrypted Sigil"] = "Şifreli Mühür" end
if E["Encrypted Tablet"] == nil then E["Encrypted Tablet"] = "Şifreli Tablet" end
if E["Encrypted Twilight Text"] == nil then E["Encrypted Twilight Text"] = "Şifreli Twilight Metni" end
if E["Enriched Manna Biscuit"] == nil then E["Enriched Manna Biscuit"] = "Zenginleştirilmiş Manna Bisküvisi" end
if E["Ensorcelled Parchment"] == nil then E["Ensorcelled Parchment"] = "Büyülenmiş Parşömen" end
if E["Eridan's Supplies"] == nil then E["Eridan's Supplies"] = "Eridan'ın Erzakı" end
if E["Eridan's Vial"] == nil then E["Eridan's Vial"] = "Eridan'ın Şişesi" end
if E["Essence of Eranikus"] == nil then E["Essence of Eranikus"] = "Eranikus'un Özü" end
if E["Essence of Fire"] == nil then E["Essence of Fire"] = "Ateş Özü" end
if E["Essence of Hakkar"] == nil then E["Essence of Hakkar"] = "Hakkar'ın Özü" end
if E["Essence of Water"] == nil then E["Essence of Water"] = "Su Özü" end
if E["Essence of Xandivious"] == nil then E["Essence of Xandivious"] = "Xandivious'un Özü" end
if E["Essence of the Elements"] == nil then E["Essence of the Elements"] = "Elementlerin Özü" end
if E["Essence of the Exile"] == nil then E["Essence of the Exile"] = "Sürgünün Özü" end
if E["Essence of the Firelord"] == nil then E["Essence of the Firelord"] = "Ateş Lordu'nun Özü" end
if E["Essential Artificial"] == nil then E["Essential Artificial"] = "Temel Yapay Madde" end
if E["Etched Note"] == nil then E["Etched Note"] = "Kazınmış Not" end
if E["Etched Parchment"] == nil then E["Etched Parchment"] = "Kazınmış Parşömen" end
if E["Etched Phial"] == nil then E["Etched Phial"] = "Kazınmış Şişe" end
if E["Etched Rune"] == nil then E["Etched Rune"] = "Kazınmış Rün" end
if E["Etched Sigil"] == nil then E["Etched Sigil"] = "Kazınmış Mühür" end
if E["Etched Tablet"] == nil then E["Etched Tablet"] = "Kazınmış Tablet" end
if E["Eternal Quintessence"] == nil then E["Eternal Quintessence"] = "Ebedi Öz" end
if E["Evergreen Herb Casing"] == nil then E["Evergreen Herb Casing"] = "Yaprakdökmez Ot Kılıfı" end
if E["Evergreen Pouch"] == nil then E["Evergreen Pouch"] = "Yaprakdökmez Kese" end
if E["Everlook Report"] == nil then E["Everlook Report"] = "Everlook Raporu" end
if E["Evil Bat Eye"] == nil then E["Evil Bat Eye"] = "Kötü Yarasa Gözü" end
if E["Exorcism Censer"] == nil then E["Exorcism Censer"] = "Şeytan Kovma Buhurdanı" end
if E["Explosive Sheep"] == nil then E["Explosive Sheep"] = "Patlayıcı Koyun" end
if E["Explosive Stick of Gann"] == nil then E["Explosive Stick of Gann"] = "Gann'ın Patlayıcı Çubuğu" end
if E["Extended Annals of Darrowshire"] == nil then E["Extended Annals of Darrowshire"] = "Darrowshire'ın Genişletilmiş Yıllıkları" end
if E["Extra-Dimensional Ghost Revealer"] == nil then E["Extra-Dimensional Ghost Revealer"] = "Boyutlar Ötesi Hayalet Gösterici" end
if E["Extraordinary Egg"] == nil then E["Extraordinary Egg"] = "Olağanüstü Yumurta" end
if E["Eye of C'Thun"] == nil then E["Eye of C'Thun"] = "C'Thun'un Gözü" end
if E["Eye of Kajal"] == nil then E["Eye of Kajal"] = "Kajal'ın Gözü" end
if E["Eye of the Emberseer"] == nil then E["Eye of the Emberseer"] = "Emberseer'ın Gözü" end
if E["Faded Photograph"] == nil then E["Faded Photograph"] = "Solmuş Fotoğraf" end
if E["Faded Shadowhide Pendant"] == nil then E["Faded Shadowhide Pendant"] = "Solmuş Shadowhide Kolyesi" end
if E["Faerie Dragon Muisek"] == nil then E["Faerie Dragon Muisek"] = "Peri Ejderhası Muisek'i" end
if E["Faerie Dragon Muisek Vessel"] == nil then E["Faerie Dragon Muisek Vessel"] = "Peri Ejderhası Muisek Kabı" end
if E["Faint Necrotic Crystal"] == nil then E["Faint Necrotic Crystal"] = "Soluk Nekrotik Kristal" end
if E["Falconcrest's Head"] == nil then E["Falconcrest's Head"] = "Falconcrest'in Kafası" end
if E["Fallen Moonstone"] == nil then E["Fallen Moonstone"] = "Düşmüş Ay Taşı" end
if E["Fandral's Message"] == nil then E["Fandral's Message"] = "Fandral'ın Mesajı" end
if E["Fang of Bhag'thera"] == nil then E["Fang of Bhag'thera"] = "Bhag'thera'nın Dişi" end
if E["Fangore's Paw"] == nil then E["Fangore's Paw"] = "Fangore'un Pençesi" end
if E["Faranell's Parcel"] == nil then E["Faranell's Parcel"] = "Faranell'in Paketi" end
if E["Fardel's Head"] == nil then E["Fardel's Head"] = "Fardel'in Kafası" end
if E["Farren's Report"] == nil then E["Farren's Report"] = "Farren'in Raporu" end
if E["Fast-growing Flower"] == nil then E["Fast-growing Flower"] = "Hızlı Büyüyen Çiçek" end
if E["Fate of Ramaladni"] == nil then E["Fate of Ramaladni"] = "Ramaladni'nin Kaderi" end
if E["Fathom Core"] == nil then E["Fathom Core"] = "Derinlik Çekirdeği" end
if E["Faustin's Truth Serum"] == nil then E["Faustin's Truth Serum"] = "Faustin'in Doğruluk Serumu" end
if E["Feather Charm"] == nil then E["Feather Charm"] = "Tüy Tılsımı" end
if E["Fel Creep"] == nil then E["Fel Creep"] = "Fel Sarmaşığı" end
if E["Fel Elemental Rod"] == nil then E["Fel Elemental Rod"] = "Fel Elemental Asası" end
if E["Fel Fire"] == nil then E["Fel Fire"] = "Fel Ateşi" end
if E["Fel Iron"] == nil then E["Fel Iron"] = "Fel Demiri" end
if E["Fel Orb"] == nil then E["Fel Orb"] = "Fel Küresi" end
if E["Fel Tracker Owner's Manual"] == nil then E["Fel Tracker Owner's Manual"] = "Fel İzci Kullanım Kılavuzu" end
if E["Felcloth"] == nil then E["Felcloth"] = "Fel Kumaşı" end
if E["Felhas Ruby"] == nil then E["Felhas Ruby"] = "Felhas Yakutu" end
if E["Felhound Brain"] == nil then E["Felhound Brain"] = "Felhound Beyni" end
if E["Felhound Tracker Kit"] == nil then E["Felhound Tracker Kit"] = "Felhound İzleme Takımı" end
if E["Felhunter Summoning Scroll"] == nil then E["Felhunter Summoning Scroll"] = "Felhunter Çağırma Tomarı" end
if E["Felnok's Package"] == nil then E["Felnok's Package"] = "Felnok'un Paketi" end
if E["Felstalker Hoof"] == nil then E["Felstalker Hoof"] = "Felstalker Toynağı" end
if E["Felstone Field Cauldron Key"] == nil then E["Felstone Field Cauldron Key"] = "Felstone Field Kazanı Anahtarı" end
if E["Felvine Shard"] == nil then E["Felvine Shard"] = "Felvine Kırığı" end
if E["Felwood Slime Sample"] == nil then E["Felwood Slime Sample"] = "Felwood Balçık Örneği" end
if E["Fenwick's Head"] == nil then E["Fenwick's Head"] = "Fenwick'in Kafası" end
if E["Feralas Ahi"] == nil then E["Feralas Ahi"] = "Feralas Ton Balığı" end
if E["Feralas: A History"] == nil then E["Feralas: A History"] = "Feralas: Bir Tarih" end
if E["Fetid Skull"] == nil then E["Fetid Skull"] = "Kokuşmuş Kafatası" end
if E["Fetish of Hakkar"] == nil then E["Fetish of Hakkar"] = "Hakkar Fetişi" end
if E["Fey Dragon Scale"] == nil then E["Fey Dragon Scale"] = "Peri Ejderhası Pulu" end
if E["Fiery Core"] == nil then E["Fiery Core"] = "Ateşli Çekirdek" end
if E["Fiery Flux"] == nil then E["Fiery Flux"] = "Ateşli Eritken" end
if E["Fifth Mosh'aru Tablet"] == nil then E["Fifth Mosh'aru Tablet"] = "Beşinci Mosh'aru Tableti" end
if E["Filled Blue Waterskin"] == nil then E["Filled Blue Waterskin"] = "Dolu Mavi Su Tulumu" end
if E["Filled Brown Waterskin"] == nil then E["Filled Brown Waterskin"] = "Dolu Kahverengi Su Tulumu" end
if E["Filled Cerulean Vial"] == nil then E["Filled Cerulean Vial"] = "Dolu Gök Mavisi Şişe" end
if E["Filled Cleansing Bowl"] == nil then E["Filled Cleansing Bowl"] = "Dolu Arındırma Kâsesi" end
if E["Filled Cliffspring Falls Sampler"] == nil then E["Filled Cliffspring Falls Sampler"] = "Dolu Cliffspring Falls Numune Kabı" end
if E["Filled Containment Coffer"] == nil then E["Filled Containment Coffer"] = "Dolu Muhafaza Sandığı" end
if E["Filled Cursed Ooze Jar"] == nil then E["Filled Cursed Ooze Jar"] = "Dolu Lanetli Balçık Kavanozu" end
if E["Filled Dalson's Tears Bottle"] == nil then E["Filled Dalson's Tears Bottle"] = "Dolu Dalson's Tears Şişesi" end
if E["Filled Dreadmist Peak Sampler"] == nil then E["Filled Dreadmist Peak Sampler"] = "Dolu Dreadmist Peak Numune Kabı" end
if E["Filled Egg of Hakkar"] == nil then E["Filled Egg of Hakkar"] = "Dolu Hakkar Yumurtası" end
if E["Filled Etched Phial"] == nil then E["Filled Etched Phial"] = "Dolu Kazınmış Şişe" end
if E["Filled Felstone Field Bottle"] == nil then E["Filled Felstone Field Bottle"] = "Dolu Felstone Field Şişesi" end
if E["Filled Flasket"] == nil then E["Filled Flasket"] = "Dolu Küçük Matara" end
if E["Filled Gahrron's Withering Bottle"] == nil then E["Filled Gahrron's Withering Bottle"] = "Dolu Gahrron's Withering Şişesi" end
if E["Filled Pure Sample Jar"] == nil then E["Filled Pure Sample Jar"] = "Dolu Saf Numune Kavanozu" end
if E["Filled Red Waterskin"] == nil then E["Filled Red Waterskin"] = "Dolu Kırmızı Su Tulumu" end
if E["Filled Soul Gem"] == nil then E["Filled Soul Gem"] = "Dolu Ruh Taşı" end
if E["Filled Tainted Ooze Jar"] == nil then E["Filled Tainted Ooze Jar"] = "Dolu Bozulmuş Balçık Kavanozu" end
if E["Filled Vial Labeled #1"] == nil then E["Filled Vial Labeled #1"] = "#1 Etiketli Dolu Şişe" end
if E["Filled Vial Labeled #2"] == nil then E["Filled Vial Labeled #2"] = "#2 Etiketli Dolu Şişe" end
if E["Filled Vial Labeled #3"] == nil then E["Filled Vial Labeled #3"] = "#3 Etiketli Dolu Şişe" end
if E["Filled Vial Labeled #4"] == nil then E["Filled Vial Labeled #4"] = "#4 Etiketli Dolu Şişe" end
if E["Filled Writhing Haunt Bottle"] == nil then E["Filled Writhing Haunt Bottle"] = "Dolu Writhing Haunt Şişesi" end
if E["Final Clue to Sander's Treasure"] == nil then E["Final Clue to Sander's Treasure"] = "Sander'ın Hazinesine Son İpucu" end
if E["Final Message to the Wildhammer"] == nil then E["Final Message to the Wildhammer"] = "Wildhammer'a Son Mesaj" end
if E["Fine Crab Chunks"] == nil then E["Fine Crab Chunks"] = "Kaliteli Yengeç Parçaları" end
if E["Fine Egg"] == nil then E["Fine Egg"] = "Kaliteli Yumurta" end
if E["Fine Gold Thread"] == nil then E["Fine Gold Thread"] = "İnce Altın İplik" end
if E["Fine Moonstalker Pelt"] == nil then E["Fine Moonstalker Pelt"] = "Kaliteli Moonstalker Postu" end
if E["Fine Thread"] == nil then E["Fine Thread"] = "İnce İplik" end
if E["Fire Tar"] == nil then E["Fire Tar"] = "Ateş Katranı" end
if E["Firebeard's Head"] == nil then E["Firebeard's Head"] = "Firebeard'ın Kafası" end
if E["Firebloom"] == nil then E["Firebloom"] = "Ateş Çiçeği" end
if E["First Mosh'aru Tablet"] == nil then E["First Mosh'aru Tablet"] = "Birinci Mosh'aru Tableti" end
if E["First Relic Fragment"] == nil then E["First Relic Fragment"] = "Birinci Kalıntı Parçası" end
if E["Fizzle Brassbolts' Letter"] == nil then E["Fizzle Brassbolts' Letter"] = "Fizzle Brassbolts'un Mektubu" end
if E["Fizzule's Whistle"] == nil then E["Fizzule's Whistle"] = "Fizzule'ün Düdüğü" end
if E["Flagon of Mead"] == nil then E["Flagon of Mead"] = "Bir Testi Bal Likörü" end
if E["Flagongut's Fossil"] == nil then E["Flagongut's Fossil"] = "Flagongut'ın Fosili" end
if E["Flame Mantle of the Dawn"] == nil then E["Flame Mantle of the Dawn"] = "Şafağın Alev Örtüsü" end
if E["Flame in a Bottle"] == nil then E["Flame in a Bottle"] = "Şişede Alev" end
if E["Flame of Darnassus"] == nil then E["Flame of Darnassus"] = "Darnassus Alevi" end
if E["Flame of Ironforge"] == nil then E["Flame of Ironforge"] = "Ironforge Alevi" end
if E["Flame of Orgrimmar"] == nil then E["Flame of Orgrimmar"] = "Orgrimmar Alevi" end
if E["Flame of Stormwind"] == nil then E["Flame of Stormwind"] = "Stormwind Alevi" end
if E["Flame of Thunder Bluff"] == nil then E["Flame of Thunder Bluff"] = "Thunder Bluff Alevi" end
if E["Flame of the Undercity"] == nil then E["Flame of the Undercity"] = "Undercity Alevi" end
if E["Flare Gun"] == nil then E["Flare Gun"] = "İşaret Fişeği Tabancası" end
if E["Flask of Big Mojo"] == nil then E["Flask of Big Mojo"] = "Büyük Mojo Matarası" end
if E["Flask of Mystery Goo"] == nil then E["Flask of Mystery Goo"] = "Gizemli Sıvı Matarası" end
if E["Flask of Oil"] == nil then E["Flask of Oil"] = "Yağ Matarası" end
if E["Flask of Petrification"] == nil then E["Flask of Petrification"] = "Taşlaşma Matarası" end
if E["Flask of Supreme Power"] == nil then E["Flask of Supreme Power"] = "Üstün Güç Matarası" end
if E["Flawless Draenethyst Sphere"] == nil then E["Flawless Draenethyst Sphere"] = "Kusursuz Draenethyst Küresi" end
if E["Flawless Fel Essence (Azshara)"] == nil then E["Flawless Fel Essence (Azshara)"] = "Kusursuz Fel Özü (Azshara)" end
if E["Flawless Fel Essence (Dark Portal)"] == nil then E["Flawless Fel Essence (Dark Portal)"] = "Kusursuz Fel Özü (Dark Portal)" end
if E["Flawless Fel Essence (Jaedenar)"] == nil then E["Flawless Fel Essence (Jaedenar)"] = "Kusursuz Fel Özü (Jaedenar)" end
if E["Flawless Ivory Tusk"] == nil then E["Flawless Ivory Tusk"] = "Kusursuz Fildişi Dişi" end
if E["Flayed Demon Skin"] == nil then E["Flayed Demon Skin"] = "Yüzülmüş İblis Derisi" end
if E["Flayed Demon Skin (old)"] == nil then E["Flayed Demon Skin (old)"] = "Yüzülmüş İblis Derisi (eski)" end
if E["Flayed Demon Skin (old2)"] == nil then E["Flayed Demon Skin (old2)"] = "Yüzülmüş İblis Derisi (eski2)" end
if E["Flute of Xavaric"] == nil then E["Flute of Xavaric"] = "Xavaric'in Flütü" end
if E["Flute of the Ancients"] == nil then E["Flute of the Ancients"] = "Kadimlerin Flütü" end
if E["Fool's Stout"] == nil then E["Fool's Stout"] = "Budala Birası" end
if E["Fool's Stout Report"] == nil then E["Fool's Stout Report"] = "Budala Birası Raporu" end
if E["Foreboding Plans"] == nil then E["Foreboding Plans"] = "Uğursuz Planlar" end
if E["Forged Seal of Ascension"] == nil then E["Forged Seal of Ascension"] = "Dövülmüş Yükseliş Mührü" end
if E["Forged Steel Bars"] == nil then E["Forged Steel Bars"] = "Dövülmüş Çelik Külçeler" end
if E["Forked Mudrock Tongue"] == nil then E["Forked Mudrock Tongue"] = "Çatallı Mudrock Dili" end
if E["Foror's Compendium of Dragon Slaying"] == nil then E["Foror's Compendium of Dragon Slaying"] = "Foror'un Ejderha Avcılığı Derlemesi" end
if E["Forsaken Heart"] == nil then E["Forsaken Heart"] = "Forsaken Kalbi" end
if E["Forsaken Stink Bomb Cluster"] == nil then E["Forsaken Stink Bomb Cluster"] = "Forsaken Pis Koku Bombası Demeti" end
if E["Fortitude of the Scourge"] == nil then E["Fortitude of the Scourge"] = "Scourge'un Metaneti" end
if E["Fourth Mosh'aru Tablet"] == nil then E["Fourth Mosh'aru Tablet"] = "Dördüncü Mosh'aru Tableti" end
if E["Fourth Relic Fragment"] == nil then E["Fourth Relic Fragment"] = "Dördüncü Kalıntı Parçası" end
if E["Fractured Elemental Bracer"] == nil then E["Fractured Elemental Bracer"] = "Çatlak Elemental Bileklik" end
if E["Fractured Elemental Shard"] == nil then E["Fractured Elemental Shard"] = "Çatlak Elemental Kırığı" end
if E["Fragile Sprite Darter Egg"] == nil then E["Fragile Sprite Darter Egg"] = "Kırılgan Sprite Darter Yumurtası" end
if E["Fragment of the Dragon's Eye"] == nil then E["Fragment of the Dragon's Eye"] = "Ejderha Gözü Parçası" end
if E["Fragment of the Nightmare's Corruption"] == nil then E["Fragment of the Nightmare's Corruption"] = "Kâbusun Yozlaşmasından Parça" end
if E["Fragments of Rok'Alim"] == nil then E["Fragments of Rok'Alim"] = "Rok'Alim Parçaları" end
if E["Frame of Atiesh"] == nil then E["Frame of Atiesh"] = "Atiesh'in Çerçevesi" end
if E["Frayed Abomination Stitching"] == nil then E["Frayed Abomination Stitching"] = "Yıpranmış Abomination Dikişi" end
if E["Free Ticket Voucher"] == nil then E["Free Ticket Voucher"] = "Bedava Bilet Kuponu" end
if E["Fresh Carcass"] == nil then E["Fresh Carcass"] = "Taze Leş" end
if E["Fresh Zhevra Carcass"] == nil then E["Fresh Zhevra Carcass"] = "Taze Zhevra Leşi" end
if E["Frost Mantle of the Dawn"] == nil then E["Frost Mantle of the Dawn"] = "Şafağın Ayaz Örtüsü" end
if E["Frost Oil"] == nil then E["Frost Oil"] = "Ayaz Yağı" end
if E["Frost Shock and You"] == nil then E["Frost Shock and You"] = "Ayaz Şoku ve Sen" end
if E["Frostmaul E'ko"] == nil then E["Frostmaul E'ko"] = "Frostmaul E'ko'su" end
if E["Frostmaul Shards"] == nil then E["Frostmaul Shards"] = "Frostmaul Kırıkları" end
if E["Frostmaw's Mane"] == nil then E["Frostmaw's Mane"] = "Frostmaw'ın Yelesi" end
if E["Frostsaber E'ko"] == nil then E["Frostsaber E'ko"] = "Frostsaber E'ko'su" end
if E["Frostwhisper's Embalming Fluid"] == nil then E["Frostwhisper's Embalming Fluid"] = "Frostwhisper'ın Tahnit Sıvısı" end
if E["Frostwolf Assault Orders"] == nil then E["Frostwolf Assault Orders"] = "Frostwolf Saldırı Emirleri" end
if E["Frostwolf Banner"] == nil then E["Frostwolf Banner"] = "Frostwolf Sancağı" end
if E["Frostwolf Commander's Medal"] == nil then E["Frostwolf Commander's Medal"] = "Frostwolf Komutan Madalyası" end
if E["Frostwolf Hide"] == nil then E["Frostwolf Hide"] = "Frostwolf Postu" end
if E["Frostwolf Insignia Rank 1"] == nil then E["Frostwolf Insignia Rank 1"] = "Frostwolf Nişanı Rütbe 1" end
if E["Frostwolf Insignia Rank 2"] == nil then E["Frostwolf Insignia Rank 2"] = "Frostwolf Nişanı Rütbe 2" end
if E["Frostwolf Insignia Rank 3"] == nil then E["Frostwolf Insignia Rank 3"] = "Frostwolf Nişanı Rütbe 3" end
if E["Frostwolf Insignia Rank 4"] == nil then E["Frostwolf Insignia Rank 4"] = "Frostwolf Nişanı Rütbe 4" end
if E["Frostwolf Insignia Rank 5"] == nil then E["Frostwolf Insignia Rank 5"] = "Frostwolf Nişanı Rütbe 5" end
if E["Frostwolf Lieutenant's Medal"] == nil then E["Frostwolf Lieutenant's Medal"] = "Frostwolf Teğmen Madalyası" end
if E["Frostwolf Maps"] == nil then E["Frostwolf Maps"] = "Frostwolf Haritaları" end
if E["Frostwolf Muzzle"] == nil then E["Frostwolf Muzzle"] = "Frostwolf Burnu" end
if E["Frostwolf Soldier's Medal"] == nil then E["Frostwolf Soldier's Medal"] = "Frostwolf Asker Madalyası" end
if E["Frozen Ectoplasm"] == nil then E["Frozen Ectoplasm"] = "Donmuş Ektoplazma" end
if E["Frozen Eggs"] == nil then E["Frozen Eggs"] = "Donmuş Yumurtalar" end
if E["Frozen Rune"] == nil then E["Frozen Rune"] = "Donmuş Rün" end
if E["Fuel Regulator Blueprints"] == nil then E["Fuel Regulator Blueprints"] = "Yakıt Regülatörü Planları" end
if E["Full Leaden Collection Phial"] == nil then E["Full Leaden Collection Phial"] = "Dolu Kurşun Toplama Şişesi" end
if E["Furen's Instructions"] == nil then E["Furen's Instructions"] = "Furen'in Talimatları" end
if E["Furen's Notes"] == nil then E["Furen's Notes"] = "Furen'in Notları" end
if E["Furlbrow's Deed"] == nil then E["Furlbrow's Deed"] = "Furlbrow'un Tapusu" end
if E["Furlbrow's Pocket Watch"] == nil then E["Furlbrow's Pocket Watch"] = "Furlbrow'un Cep Saati" end
if E["Gadrin's Parchment"] == nil then E["Gadrin's Parchment"] = "Gadrin'in Parşömeni" end
if E["Gaea Seed"] == nil then E["Gaea Seed"] = "Gaea Tohumu" end
if E["Gahrron's Withering Cauldron Key"] == nil then E["Gahrron's Withering Cauldron Key"] = "Gahrron's Withering Kazanı Anahtarı" end
if E["Gahz'ridian Detector"] == nil then E["Gahz'ridian Detector"] = "Gahz'ridian Dedektörü" end
if E["Gahz'ridian Ornament"] == nil then E["Gahz'ridian Ornament"] = "Gahz'ridian Süsü" end
if E["Gahz'rilla's Electrified Scale"] == nil then E["Gahz'rilla's Electrified Scale"] = "Gahz'rilla'nın Elektrikli Pulu" end
if E["Galen's Journal"] == nil then E["Galen's Journal"] = "Galen'in Günlüğü" end
if E["Gallywix's Head"] == nil then E["Gallywix's Head"] = "Gallywix'in Kafası" end
if E["Galvanized Horn"] == nil then E["Galvanized Horn"] = "Galvanizli Boynuz" end
if E["Gan'zulah's Head"] == nil then E["Gan'zulah's Head"] = "Gan'zulah'ın Kafası" end
if E["Garona: A Study on Stealth and Treachery"] == nil then E["Garona: A Study on Stealth and Treachery"] = "Garona: Gizlilik ve İhanet Üzerine Bir İnceleme" end
if E["Garrett Family Treasure"] == nil then E["Garrett Family Treasure"] = "Garrett Ailesi Hazinesi" end
if E["Gatekeeper's Key"] == nil then E["Gatekeeper's Key"] = "Kapı Bekçisinin Anahtarı" end
if E["Gauntlet of Gordok Might"] == nil then E["Gauntlet of Gordok Might"] = "Gordok Kudreti Eldiveni" end
if E["Gauntlets of Elements"] == nil then E["Gauntlets of Elements"] = "Elementlerin Eldivenleri" end
if E["Gauntlets of Valor"] == nil then E["Gauntlets of Valor"] = "Yiğitlik Eldivenleri" end
if E["Gem of Anacondra"] == nil then E["Gem of Anacondra"] = "Anacondra'nın Mücevheri" end
if E["Gem of Cobrahn"] == nil then E["Gem of Cobrahn"] = "Cobrahn'ın Mücevheri" end
if E["Gem of Pythas"] == nil then E["Gem of Pythas"] = "Pythas'ın Mücevheri" end
if E["Gem of Serpentis"] == nil then E["Gem of Serpentis"] = "Serpentis'in Mücevheri" end
if E["Gem of the Fifth Kahn"] == nil then E["Gem of the Fifth Kahn"] = "Beşinci Kahn'ın Mücevheri" end
if E["Gem of the First Khan"] == nil then E["Gem of the First Khan"] = "Birinci Khan'ın Mücevheri" end
if E["Gem of the Fourth Kahn"] == nil then E["Gem of the Fourth Kahn"] = "Dördüncü Kahn'ın Mücevheri" end
if E["Gem of the Second Kahn"] == nil then E["Gem of the Second Kahn"] = "İkinci Kahn'ın Mücevheri" end
if E["Gem of the Serpent"] == nil then E["Gem of the Serpent"] = "Yılanın Mücevheri" end
if E["Gem of the Third Kahn"] == nil then E["Gem of the Third Kahn"] = "Üçüncü Kahn'ın Mücevheri" end
if E["Gemstone of Bloodaxe"] == nil then E["Gemstone of Bloodaxe"] = "Bloodaxe Mücevher Taşı" end
if E["Gemstone of Smolderthorn"] == nil then E["Gemstone of Smolderthorn"] = "Smolderthorn Mücevher Taşı" end
if E["Gemstone of Spirestone"] == nil then E["Gemstone of Spirestone"] = "Spirestone Mücevher Taşı" end
if E["General Drakkisath's Command"] == nil then E["General Drakkisath's Command"] = "General Drakkisath'ın Emri" end
if E["Geologist's Transcription Kit"] == nil then E["Geologist's Transcription Kit"] = "Jeoloğun Kopyalama Takımı" end
if E["Gerenzo's Mechanical Arm"] == nil then E["Gerenzo's Mechanical Arm"] = "Gerenzo'nun Mekanik Kolu" end
if E["Ghost Hair Comb"] == nil then E["Ghost Hair Comb"] = "Hayalet Saçı Tarağı" end
if E["Ghost Hair Thread"] == nil then E["Ghost Hair Thread"] = "Hayalet Saçı İpliği" end
if E["Ghost-o-plasm"] == nil then E["Ghost-o-plasm"] = "Hayalet-o-plazma" end
if E["Ghoul Fang"] == nil then E["Ghoul Fang"] = "Ghoul Dişi" end
if E["Ghoul Rib"] == nil then E["Ghoul Rib"] = "Ghoul Kaburgası" end
if E["Giant Crocolisk Skin"] == nil then E["Giant Crocolisk Skin"] = "Dev Crocolisk Derisi" end
if E["Giant Egg"] == nil then E["Giant Egg"] = "Dev Yumurta" end
if E["Giant Silver Vein"] == nil then E["Giant Silver Vein"] = "Dev Gümüş Damarı" end
if E["Gingerbread Cookie"] == nil then E["Gingerbread Cookie"] = "Zencefilli Kurabiye" end
if E["Gizzard Gum"] == nil then E["Gizzard Gum"] = "Taşlık Sakızı" end
if E["Glimmering Mithril Insignia"] == nil then E["Glimmering Mithril Insignia"] = "Parıldayan Mithril Nişan" end
if E["Glittering Dust"] == nil then E["Glittering Dust"] = "Parıltılı Toz" end
if E["Globe of Water"] == nil then E["Globe of Water"] = "Su Küresi" end
if E["Glommus's Head"] == nil then E["Glommus's Head"] = "Glommus'un Kafası" end
if E["Glowing Crystal Prison"] == nil then E["Glowing Crystal Prison"] = "Parlayan Kristal Hapishane" end
if E["Glowing Ember"] == nil then E["Glowing Ember"] = "Parlayan Köz" end
if E["Glowing Gem"] == nil then E["Glowing Gem"] = "Parlayan Mücevher" end
if E["Glowing Hunk of the Beast's Flesh"] == nil then E["Glowing Hunk of the Beast's Flesh"] = "Canavarın Etinden Parlayan Parça" end
if E["Glowing Scorpid Blood"] == nil then E["Glowing Scorpid Blood"] = "Parlayan Scorpid Kanı" end
if E["Glowing Shadowhide Pendant"] == nil then E["Glowing Shadowhide Pendant"] = "Parlayan Shadowhide Kolyesi" end
if E["Glowing Shard"] == nil then E["Glowing Shard"] = "Parlayan Kırık" end
if E["Glowing Soul Gem"] == nil then E["Glowing Soul Gem"] = "Parlayan Ruh Taşı" end
if E["Glyph of Azora"] == nil then E["Glyph of Azora"] = "Azora Glifi" end
if E["Glyphed Crystal Prism"] == nil then E["Glyphed Crystal Prism"] = "Glifli Kristal Prizma" end
if E["Glyphed Oaken Branch"] == nil then E["Glyphed Oaken Branch"] = "Glifli Meşe Dalı" end
if E["Glyphic Letter"] == nil then E["Glyphic Letter"] = "Glifli Mektup" end
if E["Glyphic Memorandum"] == nil then E["Glyphic Memorandum"] = "Glifli Not" end
if E["Glyphic Rune"] == nil then E["Glyphic Rune"] = "Glifli Rün" end
if E["Glyphic Scroll"] == nil then E["Glyphic Scroll"] = "Glifli Tomar" end
if E["Glyphic Tablet"] == nil then E["Glyphic Tablet"] = "Glifli Tablet" end
if E["Glyphs of Calling"] == nil then E["Glyphs of Calling"] = "Çağrı Glifleri" end
if E["Glyphs of Summoning"] == nil then E["Glyphs of Summoning"] = "Çağırma Glifleri" end
if E["Gnarlpine Fang"] == nil then E["Gnarlpine Fang"] = "Gnarlpine Dişi" end
if E["Gnarlpine Necklace"] == nil then E["Gnarlpine Necklace"] = "Gnarlpine Kolyesi" end
if E["Gni'kiv Medallion"] == nil then E["Gni'kiv Medallion"] = "Gni'kiv Madalyonu" end
if E["Gnoll Paw"] == nil then E["Gnoll Paw"] = "Gnoll Pençesi" end
if E["Gnome Engineer Membership Card"] == nil then E["Gnome Engineer Membership Card"] = "Gnom Mühendis Üyelik Kartı" end
if E["Gnome Prize Box"] == nil then E["Gnome Prize Box"] = "Gnom Ödül Kutusu" end
if E["Gnome Race Ticket"] == nil then E["Gnome Race Ticket"] = "Gnom Yarış Bileti" end
if E["Gnomeregan Gumdrop"] == nil then E["Gnomeregan Gumdrop"] = "Gnomeregan Jelibonu" end
if E["Gnomish Battle Chicken"] == nil then E["Gnomish Battle Chicken"] = "Gnom Savaş Tavuğu" end
if E["Gobbler's Head"] == nil then E["Gobbler's Head"] = "Gobbler'ın Kafası" end
if E["Goblin Engineer Membership Card"] == nil then E["Goblin Engineer Membership Card"] = "Goblin Mühendis Üyelik Kartı" end
if E["Goblin Prize Box"] == nil then E["Goblin Prize Box"] = "Goblin Ödül Kutusu" end
if E["Goblin Race Ticket"] == nil then E["Goblin Race Ticket"] = "Goblin Yarış Bileti" end
if E["Goblin Rocket Fuel"] == nil then E["Goblin Rocket Fuel"] = "Goblin Roket Yakıtı" end
if E["Goblin Rumors"] == nil then E["Goblin Rumors"] = "Goblin Söylentileri" end
if E["Goblin Sapper Charge"] == nil then E["Goblin Sapper Charge"] = "Goblin Lağımcı Patlayıcısı" end
if E["Goblin Transponder"] == nil then E["Goblin Transponder"] = "Goblin Transponderi" end
if E["Goggles of Gem Hunting"] == nil then E["Goggles of Gem Hunting"] = "Mücevher Avcılığı Gözlüğü" end
if E["Gold Bar"] == nil then E["Gold Bar"] = "Altın Külçe" end
if E["Gold Hakkari Bijou"] == nil then E["Gold Hakkari Bijou"] = "Altın Hakkari Biblosu" end
if E["Gold Moro'gai Gem"] == nil then E["Gold Moro'gai Gem"] = "Altın Moro'gai Mücevheri" end
if E["Gold Pickup Schedule"] == nil then E["Gold Pickup Schedule"] = "Altın Teslim Alma Çizelgesi" end
if E["Gold Pirate Earring"] == nil then E["Gold Pirate Earring"] = "Altın Korsan Küpesi" end
if E["Gold Scarab"] == nil then E["Gold Scarab"] = "Altın Skarabe" end
if E["Golden Flame"] == nil then E["Golden Flame"] = "Altın Alev" end
if E["Golden Rod"] == nil then E["Golden Rod"] = "Altın Çubuk" end
if E["Golden Scale Bracers"] == nil then E["Golden Scale Bracers"] = "Altın Pullu Bileklikler" end
if E["Golden Token"] == nil then E["Golden Token"] = "Altın Jeton" end
if E["Golem Oil"] == nil then E["Golem Oil"] = "Golem Yağı" end
if E["Golm Fragment"] == nil then E["Golm Fragment"] = "Golm Parçası" end
if E["Gong of Dethmoora"] == nil then E["Gong of Dethmoora"] = "Dethmoora Gongu" end
if E["Good Luck Charm"] == nil then E["Good Luck Charm"] = "Uğur Tılsımı" end
if E["Good Luck Half-Charm"] == nil then E["Good Luck Half-Charm"] = "Uğur Tılsımının Yarısı" end
if E["Good Luck Other-Half-Charm"] == nil then E["Good Luck Other-Half-Charm"] = "Uğur Tılsımının Diğer Yarısı" end
if E["Goodsteel Ledger"] == nil then E["Goodsteel Ledger"] = "Goodsteel Defteri" end
if E["Goodsteel's Balanced Flameberge"] == nil then E["Goodsteel's Balanced Flameberge"] = "Goodsteel'in Dengeli Alevkılıcı" end
if E["Gor'tesh's Lopped Off Head"] == nil then E["Gor'tesh's Lopped Off Head"] = "Gor'tesh'in Kesik Kafası" end
if E["Gordok Shackle Key"] == nil then E["Gordok Shackle Key"] = "Gordok Pranga Anahtarı" end
if E["Gordunni Cobalt"] == nil then E["Gordunni Cobalt"] = "Gordunni Kobaltı" end
if E["Gordunni Orb"] == nil then E["Gordunni Orb"] = "Gordunni Küresi" end
if E["Gordunni Scroll"] == nil then E["Gordunni Scroll"] = "Gordunni Tomarı" end
if E["Goretusk Liver"] == nil then E["Goretusk Liver"] = "Goretusk Ciğeri" end
if E["Goretusk Snout"] == nil then E["Goretusk Snout"] = "Goretusk Burnu" end
if E["Gorilla Fang"] == nil then E["Gorilla Fang"] = "Goril Dişi" end
if E["Gorishi Queen Brain"] == nil then E["Gorishi Queen Brain"] = "Gorishi Kraliçesi Beyni" end
if E["Gorishi Queen Lure"] == nil then E["Gorishi Queen Lure"] = "Gorishi Kraliçesi Yemi" end
if E["Gorishi Scent Gland"] == nil then E["Gorishi Scent Gland"] = "Gorishi Koku Bezi" end
if E["Gorishi Sting"] == nil then E["Gorishi Sting"] = "Gorishi İğnesi" end
if E["Gray Bear Tongue"] == nil then E["Gray Bear Tongue"] = "Boz Ayı Dili" end
if E["Great Goretusk Snout"] == nil then E["Great Goretusk Snout"] = "Büyük Goretusk Burnu" end
if E["Greater Arcane Protection Potion"] == nil then E["Greater Arcane Protection Potion"] = "Büyük Arkan Koruma İksiri" end
if E["Greater Eternal Essence"] == nil then E["Greater Eternal Essence"] = "Büyük Ebedi Öz" end
if E["Green Firework"] == nil then E["Green Firework"] = "Yeşil Havai Fişek" end
if E["Green Hakkari Bijou"] == nil then E["Green Hakkari Bijou"] = "Yeşil Hakkari Biblosu" end
if E["Green Hills of Stranglethorn"] == nil then E["Green Hills of Stranglethorn"] = "Stranglethorn'un Yeşil Tepeleri" end
if E["Green Hills of Stranglethorn - Chapter I"] == nil then E["Green Hills of Stranglethorn - Chapter I"] = "Stranglethorn'un Yeşil Tepeleri - Bölüm I" end
if E["Green Hills of Stranglethorn - Chapter II"] == nil then E["Green Hills of Stranglethorn - Chapter II"] = "Stranglethorn'un Yeşil Tepeleri - Bölüm II" end
if E["Green Hills of Stranglethorn - Chapter III"] == nil then E["Green Hills of Stranglethorn - Chapter III"] = "Stranglethorn'un Yeşil Tepeleri - Bölüm III" end
if E["Green Hills of Stranglethorn - Chapter IV"] == nil then E["Green Hills of Stranglethorn - Chapter IV"] = "Stranglethorn'un Yeşil Tepeleri - Bölüm IV" end
if E["Green Hills of Stranglethorn - Page 1"] == nil then E["Green Hills of Stranglethorn - Page 1"] = "Stranglethorn'un Yeşil Tepeleri - Sayfa 1" end
if E["Green Hills of Stranglethorn - Page 10"] == nil then E["Green Hills of Stranglethorn - Page 10"] = "Stranglethorn'un Yeşil Tepeleri - Sayfa 10" end
if E["Green Hills of Stranglethorn - Page 11"] == nil then E["Green Hills of Stranglethorn - Page 11"] = "Stranglethorn'un Yeşil Tepeleri - Sayfa 11" end
if E["Green Hills of Stranglethorn - Page 14"] == nil then E["Green Hills of Stranglethorn - Page 14"] = "Stranglethorn'un Yeşil Tepeleri - Sayfa 14" end
if E["Green Hills of Stranglethorn - Page 16"] == nil then E["Green Hills of Stranglethorn - Page 16"] = "Stranglethorn'un Yeşil Tepeleri - Sayfa 16" end
if E["Green Hills of Stranglethorn - Page 18"] == nil then E["Green Hills of Stranglethorn - Page 18"] = "Stranglethorn'un Yeşil Tepeleri - Sayfa 18" end
if E["Green Hills of Stranglethorn - Page 20"] == nil then E["Green Hills of Stranglethorn - Page 20"] = "Stranglethorn'un Yeşil Tepeleri - Sayfa 20" end
if E["Green Hills of Stranglethorn - Page 21"] == nil then E["Green Hills of Stranglethorn - Page 21"] = "Stranglethorn'un Yeşil Tepeleri - Sayfa 21" end
if E["Green Hills of Stranglethorn - Page 24"] == nil then E["Green Hills of Stranglethorn - Page 24"] = "Stranglethorn'un Yeşil Tepeleri - Sayfa 24" end
if E["Green Hills of Stranglethorn - Page 25"] == nil then E["Green Hills of Stranglethorn - Page 25"] = "Stranglethorn'un Yeşil Tepeleri - Sayfa 25" end
if E["Green Hills of Stranglethorn - Page 26"] == nil then E["Green Hills of Stranglethorn - Page 26"] = "Stranglethorn'un Yeşil Tepeleri - Sayfa 26" end
if E["Green Hills of Stranglethorn - Page 27"] == nil then E["Green Hills of Stranglethorn - Page 27"] = "Stranglethorn'un Yeşil Tepeleri - Sayfa 27" end
if E["Green Hills of Stranglethorn - Page 4"] == nil then E["Green Hills of Stranglethorn - Page 4"] = "Stranglethorn'un Yeşil Tepeleri - Sayfa 4" end
if E["Green Hills of Stranglethorn - Page 6"] == nil then E["Green Hills of Stranglethorn - Page 6"] = "Stranglethorn'un Yeşil Tepeleri - Sayfa 6" end
if E["Green Hills of Stranglethorn - Page 8"] == nil then E["Green Hills of Stranglethorn - Page 8"] = "Stranglethorn'un Yeşil Tepeleri - Sayfa 8" end
if E["Green Iron Bracers"] == nil then E["Green Iron Bracers"] = "Yeşil Demir Bileklikler" end
if E["Green Iron Helm"] == nil then E["Green Iron Helm"] = "Yeşil Demir Miğfer" end
if E["Green Iron Leggings"] == nil then E["Green Iron Leggings"] = "Yeşil Demir Tozluk" end
if E["Green Kodo"] == nil then E["Green Kodo"] = "Yeşil Kodo" end
if E["Green Moro'gai Gem"] == nil then E["Green Moro'gai Gem"] = "Yeşil Moro'gai Mücevheri" end
if E["Green Power Crystal"] == nil then E["Green Power Crystal"] = "Yeşil Güç Kristali" end
if E["Green Scepter Shard"] == nil then E["Green Scepter Shard"] = "Yeşil Asa Kırığı" end
if E["Green Voodoo Feather"] == nil then E["Green Voodoo Feather"] = "Yeşil Vudu Tüyü" end
if E["Grell Earring"] == nil then E["Grell Earring"] = "Grell Küpesi" end
if E["Grenka's Claw"] == nil then E["Grenka's Claw"] = "Grenka'nın Pençesi" end
if E["Gri'lek's Blood"] == nil then E["Gri'lek's Blood"] = "Gri'lek'in Kanı" end
if E["Grime-Encrusted Object"] == nil then E["Grime-Encrusted Object"] = "Kir Tutmuş Nesne" end
if E["Grime-Encrusted Ring"] == nil then E["Grime-Encrusted Ring"] = "Kir Tutmuş Yüzük" end
if E["Grimesilt Outhouse Key"] == nil then E["Grimesilt Outhouse Key"] = "Grimesilt Tuvalet Anahtarı" end
if E["Grimtotem Horn"] == nil then E["Grimtotem Horn"] = "Grimtotem Boynuzu" end
if E["Grimtotem Satchel"] == nil then E["Grimtotem Satchel"] = "Grimtotem Heybesi" end
if E["Grizzled Scalp"] == nil then E["Grizzled Scalp"] = "Kır Saçlı Kafa Derisi" end
if E["Groddoc Liver"] == nil then E["Groddoc Liver"] = "Groddoc Ciğeri" end
if E["Grom's Tribute"] == nil then E["Grom's Tribute"] = "Grom'un Haracı" end
if E["Gryshka's Letter"] == nil then E["Gryshka's Letter"] = "Gryshka'nın Mektubu" end
if E["Guardian's Moldy Card"] == nil then E["Guardian's Moldy Card"] = "Muhafızın Küflü Kartı" end
if E["Gurubashi Coin"] == nil then E["Gurubashi Coin"] = "Gurubashi Sikkesi" end
if E["Gurubashi Head Collection"] == nil then E["Gurubashi Head Collection"] = "Gurubashi Kafa Koleksiyonu" end
if E["Gurubashi Mojo Madness"] == nil then E["Gurubashi Mojo Madness"] = "Gurubashi Mojo Çılgınlığı" end
if E["Guse's Beacon"] == nil then E["Guse's Beacon"] = "Guse'un İşaret Feneri" end
if E["Gyrochronatom"] == nil then E["Gyrochronatom"] = "Jirokronatom" end
if E["Gyromast's Key"] == nil then E["Gyromast's Key"] = "Gyromast'ın Anahtarı" end
if E["Hakkari Coin"] == nil then E["Hakkari Coin"] = "Hakkari Sikkesi" end
if E["Half Pendant of Aquatic Agility"] == nil then E["Half Pendant of Aquatic Agility"] = "Su Çevikliği Kolyesinin Yarısı" end
if E["Half Pendant of Aquatic Endurance"] == nil then E["Half Pendant of Aquatic Endurance"] = "Su Dayanıklılığı Kolyesinin Yarısı" end
if E["Hallow's End Medallion"] == nil then E["Hallow's End Medallion"] = "Hallow's End Madalyonu" end
if E["Hallowed Brazier"] == nil then E["Hallowed Brazier"] = "Kutsanmış Mangal" end
if E["Hallowed Letter"] == nil then E["Hallowed Letter"] = "Kutsanmış Mektup" end
if E["Hallowed Rune"] == nil then E["Hallowed Rune"] = "Kutsanmış Rün" end
if E["Hallowed Sigil"] == nil then E["Hallowed Sigil"] = "Kutsanmış Mühür" end
if E["Hallowed Tablet"] == nil then E["Hallowed Tablet"] = "Kutsanmış Tablet" end
if E["Hameya's Key"] == nil then E["Hameya's Key"] = "Hameya'nın Anahtarı" end
if E["Hammertoe's Amulet"] == nil then E["Hammertoe's Amulet"] = "Hammertoe'nun Muskası" end
if E["Hand of Dagun"] == nil then E["Hand of Dagun"] = "Dagun'un Eli" end
if E["Hand of Dextren Ward"] == nil then E["Hand of Dextren Ward"] = "Dextren Ward'ın Eli" end
if E["Hand of Gehennas"] == nil then E["Hand of Gehennas"] = "Gehennas'ın Eli" end
if E["Hand of Iruxos"] == nil then E["Hand of Iruxos"] = "Iruxos'un Eli" end
if E["Hand of Lucifron"] == nil then E["Hand of Lucifron"] = "Lucifron'un Eli" end
if E["Hand of Shazzrah"] == nil then E["Hand of Shazzrah"] = "Shazzrah'ın Eli" end
if E["Hand of Sulfuron"] == nil then E["Hand of Sulfuron"] = "Sulfuron'un Eli" end
if E["Handful of Oats"] == nil then E["Handful of Oats"] = "Bir Avuç Yulaf" end
if E["Handful of Stardust"] == nil then E["Handful of Stardust"] = "Bir Avuç Yıldız Tozu" end
if E["Hardened Flasket"] == nil then E["Hardened Flasket"] = "Sertleştirilmiş Küçük Matara" end
if E["Hardened Tortoise Shell"] == nil then E["Hardened Tortoise Shell"] = "Sertleşmiş Kaplumbağa Kabuğu" end
if E["Harnessing Shadows"] == nil then E["Harnessing Shadows"] = "Gölgeleri Dizginlemek" end
if E["Harpy Lieutenant Ring"] == nil then E["Harpy Lieutenant Ring"] = "Harpi Teğmen Yüzüğü" end
if E["Harvester's Head"] == nil then E["Harvester's Head"] = "Hasatçının Kafası" end
if E["Hatecrest Naga Scale"] == nil then E["Hatecrest Naga Scale"] = "Hatecrest Naga Pulu" end
if E["Hatefury Claw"] == nil then E["Hatefury Claw"] = "Hatefury Pençesi" end
if E["Hatefury Horn"] == nil then E["Hatefury Horn"] = "Hatefury Boynuzu" end
if E["Hazza'rah's Dream Thread"] == nil then E["Hazza'rah's Dream Thread"] = "Hazza'rah'ın Rüya İpliği" end
if E["Head of Alexi Barov"] == nil then E["Head of Alexi Barov"] = "Alexi Barov'un Kafası" end
if E["Head of Argelmach"] == nil then E["Head of Argelmach"] = "Argelmach'ın Kafası" end
if E["Head of Arugal"] == nil then E["Head of Arugal"] = "Arugal'ın Kafası" end
if E["Head of Balnazzar"] == nil then E["Head of Balnazzar"] = "Balnazzar'ın Kafası" end
if E["Head of Bangalash"] == nil then E["Head of Bangalash"] = "Bangalash'ın Kafası" end
if E["Head of Baron Rivendare"] == nil then E["Head of Baron Rivendare"] = "Baron Rivendare'in Kafası" end
if E["Head of Baron Vardus"] == nil then E["Head of Baron Vardus"] = "Baron Vardus'un Kafası" end
if E["Head of Bazil Thredd"] == nil then E["Head of Bazil Thredd"] = "Bazil Thredd'in Kafası" end
if E["Head of Deepfury"] == nil then E["Head of Deepfury"] = "Deepfury'nin Kafası" end
if E["Head of Gath'Ilzogg"] == nil then E["Head of Gath'Ilzogg"] = "Gath'Ilzogg'un Kafası" end
if E["Head of Instructor Razuvious"] == nil then E["Head of Instructor Razuvious"] = "Eğitmen Razuvious'un Kafası" end
if E["Head of Instructor Razuvious DEP"] == nil then E["Head of Instructor Razuvious DEP"] = "Eğitmen Razuvious'un Kafası DEP" end
if E["Head of Jammal'an"] == nil then E["Head of Jammal'an"] = "Jammal'an'ın Kafası" end
if E["Head of Kelris"] == nil then E["Head of Kelris"] = "Kelris'in Kafası" end
if E["Head of Krom'zar"] == nil then E["Head of Krom'zar"] = "Krom'zar'ın Kafası" end
if E["Head of Lathoric the Black"] == nil then E["Head of Lathoric the Black"] = "Kara Lathoric'in Kafası" end
if E["Head of Magus Rimtori"] == nil then E["Head of Magus Rimtori"] = "Magus Rimtori'nin Kafası" end
if E["Head of Nagaz"] == nil then E["Head of Nagaz"] = "Nagaz'ın Kafası" end
if E["Head of Nefarian"] == nil then E["Head of Nefarian"] = "Nefarian'ın Kafası" end
if E["Head of Onyxia"] == nil then E["Head of Onyxia"] = "Onyxia'nın Kafası" end
if E["Head of Ossirian the Unscarred"] == nil then E["Head of Ossirian the Unscarred"] = "Yarasız Ossirian'ın Kafası" end
if E["Head of Overseer Maltorius"] == nil then E["Head of Overseer Maltorius"] = "Gözetmen Maltorius'un Kafası" end
if E["Head of Ramstein the Gorger"] == nil then E["Head of Ramstein the Gorger"] = "Obur Ramstein'ın Kafası" end
if E["Head of Rend Blackhand"] == nil then E["Head of Rend Blackhand"] = "Rend Blackhand'in Kafası" end
if E["Head of Targorr"] == nil then E["Head of Targorr"] = "Targorr'un Kafası" end
if E["Head of VanCleef"] == nil then E["Head of VanCleef"] = "VanCleef'in Kafası" end
if E["Head of Weldon Barov"] == nil then E["Head of Weldon Barov"] = "Weldon Barov'un Kafası" end
if E["Head of the Broodlord Lashlayer"] == nil then E["Head of the Broodlord Lashlayer"] = "Kuluçka Lordu Lashlayer'ın Kafası" end
if E["Healing Stream Totem Scroll"] == nil then E["Healing Stream Totem Scroll"] = "Şifa Akıntısı Totemi Tomarı" end
if E["Healthy Courser Gland"] == nil then E["Healthy Courser Gland"] = "Sağlıklı Courser Bezi" end
if E["Healthy Dragon Scale"] == nil then E["Healthy Dragon Scale"] = "Sağlıklı Ejderha Pulu" end
if E["Heart of Anub'Rekhan"] == nil then E["Heart of Anub'Rekhan"] = "Anub'Rekhan'ın Kalbi" end
if E["Heart of Fire"] == nil then E["Heart of Fire"] = "Ateşin Kalbi" end
if E["Heart of Flame"] == nil then E["Heart of Flame"] = "Alevin Kalbi" end
if E["Heart of Hakkar"] == nil then E["Heart of Hakkar"] = "Hakkar'ın Kalbi" end
if E["Heart of Mokk"] == nil then E["Heart of Mokk"] = "Mokk'un Kalbi" end
if E["Heart of Obsidion"] == nil then E["Heart of Obsidion"] = "Obsidion'un Kalbi" end
if E["Heart of Zeal"] == nil then E["Heart of Zeal"] = "Şevkin Kalbi" end
if E["Heartswood"] == nil then E["Heartswood"] = "Özağaç" end
if E["Heartswood Core"] == nil then E["Heartswood Core"] = "Özağaç Çekirdeği" end
if E["Heated Ancient Blade"] == nil then E["Heated Ancient Blade"] = "Isıtılmış Kadim Kılıç" end
if E["Heathen's Brand"] == nil then E["Heathen's Brand"] = "Kâfirin Damgası" end
if E["Heavy Armor Kit"] == nil then E["Heavy Armor Kit"] = "Ağır Zırh Takımı" end
if E["Heavy Copper Maul"] == nil then E["Heavy Copper Maul"] = "Ağır Bakır Gürz" end
if E["Heavy Grinding Stone"] == nil then E["Heavy Grinding Stone"] = "Ağır Bileme Taşı" end
if E["Heavy Junkbox"] == nil then E["Heavy Junkbox"] = "Ağır Hurda Kutusu" end
if E["Heavy Leaden Collection Phial"] == nil then E["Heavy Leaden Collection Phial"] = "Ağır Kurşun Toplama Şişesi" end
if E["Heavy Leather"] == nil then E["Heavy Leather"] = "Ağır Deri" end
if E["Heavy Mageweave Bandage"] == nil then E["Heavy Mageweave Bandage"] = "Ağır Büyü Kumaşı Sargısı" end
if E["Heavy Mithril Axe"] == nil then E["Heavy Mithril Axe"] = "Ağır Mithril Balta" end
if E["Heavy Mithril Boots"] == nil then E["Heavy Mithril Boots"] = "Ağır Mithril Çizme" end
if E["Heavy Mithril Breastplate"] == nil then E["Heavy Mithril Breastplate"] = "Ağır Mithril Göğüslük" end
if E["Heavy Parchment"] == nil then E["Heavy Parchment"] = "Kalın Parşömen" end
if E["Heavy Runecloth Bandage"] == nil then E["Heavy Runecloth Bandage"] = "Ağır Rün Kumaşı Sargısı" end
if E["Heavy Scorpid Scale"] == nil then E["Heavy Scorpid Scale"] = "Ağır Scorpid Pulu" end
if E["Heavy Silk Bandage"] == nil then E["Heavy Silk Bandage"] = "Ağır İpek Sargı" end
if E["Helcular's Rod"] == nil then E["Helcular's Rod"] = "Helcular'ın Asası" end
if E["Helendis Riverhorn's Letter"] == nil then E["Helendis Riverhorn's Letter"] = "Helendis Riverhorn'un Mektubu" end
if E["Helm of Valor"] == nil then E["Helm of Valor"] = "Yiğitlik Miğferi" end
if E["Henrig Lonebrow's Journal"] == nil then E["Henrig Lonebrow's Journal"] = "Henrig Lonebrow'un Günlüğü" end
if E["Hetaera's Beaten Head"] == nil then E["Hetaera's Beaten Head"] = "Hetaera'nın Dövülmüş Kafası" end
if E["Hetaera's Blood"] == nil then E["Hetaera's Blood"] = "Hetaera'nın Kanı" end
if E["Hetaera's Bloodied Head"] == nil then E["Hetaera's Bloodied Head"] = "Hetaera'nın Kanlı Kafası" end
if E["Hetaera's Bruised Head"] == nil then E["Hetaera's Bruised Head"] = "Hetaera'nın Morarmış Kafası" end
if E["Hexx's Key"] == nil then E["Hexx's Key"] = "Hexx'in Anahtarı" end
if E["Hezrul's Head"] == nil then E["Hezrul's Head"] = "Hezrul'un Kafası" end
if E["Hi-Explosive Bomb"] == nil then E["Hi-Explosive Bomb"] = "Yüksek Patlayıcılı Bomba" end
if E["High Potency Radioactive Fallout"] == nil then E["High Potency Radioactive Fallout"] = "Yüksek Etkili Radyoaktif Serpinti" end
if E["Highborne Relic"] == nil then E["Highborne Relic"] = "Highborne Kalıntısı" end
if E["Highland Raptor Eye"] == nil then E["Highland Raptor Eye"] = "Yayla Raptor Gözü" end
if E["Highperch Venom Sac"] == nil then E["Highperch Venom Sac"] = "Highperch Zehir Kesesi" end
if E["Highperch Wyvern Egg"] == nil then E["Highperch Wyvern Egg"] = "Highperch Wyvern Yumurtası" end
if E["Hilary's Necklace"] == nil then E["Hilary's Necklace"] = "Hilary'nin Kolyesi" end
if E["Hillman's Cloak"] == nil then E["Hillman's Cloak"] = "Hillman'ın Pelerini" end
if E["Hillsbrad Human Skull"] == nil then E["Hillsbrad Human Skull"] = "Hillsbrad İnsan Kafatası" end
if E["Hillsbrad Town Registry"] == nil then E["Hillsbrad Town Registry"] = "Hillsbrad Kasaba Sicili" end
if E["Hinterlands Honey Ripple"] == nil then E["Hinterlands Honey Ripple"] = "Hinterlands Ballı Dalgası" end
if E["Hippogryph Egg"] == nil then E["Hippogryph Egg"] = "Hipogrif Yumurtası" end
if E["Hippogryph Muisek"] == nil then E["Hippogryph Muisek"] = "Hipogrif Muisek'i" end
if E["Hippogryph Muisek Vessel"] == nil then E["Hippogryph Muisek Vessel"] = "Hipogrif Muisek Kabı" end
if E["Hive Wall Sample"] == nil then E["Hive Wall Sample"] = "Kovan Duvarı Örneği" end
if E["Hive'Ashi Rubbing"] == nil then E["Hive'Ashi Rubbing"] = "Hive'Ashi Kopyası" end
if E["Hive'Ashi Scout Report"] == nil then E["Hive'Ashi Scout Report"] = "Hive'Ashi Keşif Raporu" end
if E["Hive'Ashi Silithid Brain"] == nil then E["Hive'Ashi Silithid Brain"] = "Hive'Ashi Silithid Beyni" end
if E["Hive'Regal Rubbing"] == nil then E["Hive'Regal Rubbing"] = "Hive'Regal Kopyası" end
if E["Hive'Regal Scout Report"] == nil then E["Hive'Regal Scout Report"] = "Hive'Regal Keşif Raporu" end
if E["Hive'Regal Silithid Brain"] == nil then E["Hive'Regal Silithid Brain"] = "Hive'Regal Silithid Beyni" end
if E["Hive'Zora Rubbing"] == nil then E["Hive'Zora Rubbing"] = "Hive'Zora Kopyası" end
if E["Hive'Zora Scout Orders"] == nil then E["Hive'Zora Scout Orders"] = "Hive'Zora Keşif Emirleri" end
if E["Hive'Zora Scout Report"] == nil then E["Hive'Zora Scout Report"] = "Hive'Zora Keşif Raporu" end
if E["Hive'Zora Silithid Brain"] == nil then E["Hive'Zora Silithid Brain"] = "Hive'Zora Silithid Beyni" end
if E["Hollow Vulture Bone"] == nil then E["Hollow Vulture Bone"] = "Oyuk Akbaba Kemiği" end
if E["Holy Bologna: What the Light Won't Tell You"] == nil then E["Holy Bologna: What the Light Won't Tell You"] = "Kutsal Saçmalık: Işık'ın Sana Söylemeyecekleri" end
if E["Holy Spring Water"] == nil then E["Holy Spring Water"] = "Kutsal Kaynak Suyu" end
if E["Honorary Picks"] == nil then E["Honorary Picks"] = "Onursal Kazmalar" end
if E["Hops"] == nil then E["Hops"] = "Şerbetçiotu" end
if E["Horde Commendation Signet"] == nil then E["Horde Commendation Signet"] = "Horde Takdir Mührü" end
if E["Horde Gift Collection"] == nil then E["Horde Gift Collection"] = "Horde Hediye Koleksiyonu" end
if E["Horn of Awakening"] == nil then E["Horn of Awakening"] = "Uyanış Boynuzu" end
if E["Horn of Hatetalon"] == nil then E["Horn of Hatetalon"] = "Hatetalon Boynuzu" end
if E["Horn of Vorlus"] == nil then E["Horn of Vorlus"] = "Vorlus'un Boynuzu" end
if E["Horn of the Arctic Wolf"] == nil then E["Horn of the Arctic Wolf"] = "Kutup Kurdu Boynuzu" end
if E["Horn of the Red Wolf"] == nil then E["Horn of the Red Wolf"] = "Kızıl Kurt Boynuzu" end
if E["Horns of Nez'ra"] == nil then E["Horns of Nez'ra"] = "Nez'ra'nın Boynuzları" end
if E["Huge Emerald"] == nil then E["Huge Emerald"] = "Kocaman Zümrüt" end
if E["Huge Thorium Battleaxe"] == nil then E["Huge Thorium Battleaxe"] = "Kocaman Toryum Savaş Baltası" end
if E["Human Bone Chip"] == nil then E["Human Bone Chip"] = "İnsan Kemiği Kırıntısı" end
if E["Human Head of Ras Frostwhisper"] == nil then E["Human Head of Ras Frostwhisper"] = "Ras Frostwhisper'ın İnsan Kafası" end
if E["Human Orphan Whistle"] == nil then E["Human Orphan Whistle"] = "İnsan Yetim Düdüğü" end
if E["Humbert's Sword"] == nil then E["Humbert's Sword"] = "Humbert'in Kılıcı" end
if E["Huntsman Malkhor's Bones"] == nil then E["Huntsman Malkhor's Bones"] = "Avcı Malkhor'un Kemikleri" end
if E["Huntsman Malkhor's Skull"] == nil then E["Huntsman Malkhor's Skull"] = "Avcı Malkhor'un Kafatası" end
if E["Husk of the Old God"] == nil then E["Husk of the Old God"] = "Kadim Tanrı'nın Kabuğu" end
if E["Hydrospawn Essence"] == nil then E["Hydrospawn Essence"] = "Hydrospawn Özü" end
if E["Hypercapacitor Gizmo"] == nil then E["Hypercapacitor Gizmo"] = "Hiperkapasitör Aleti" end
if E["Ice Thistle E'ko"] == nil then E["Ice Thistle E'ko"] = "Ice Thistle E'ko'su" end
if E["Ichman's Beacon"] == nil then E["Ichman's Beacon"] = "Ichman'ın İşaret Feneri" end
if E["Ichor of Undeath"] == nil then E["Ichor of Undeath"] = "Ölümsüzlük İrini" end
if E["Idol of Death"] == nil then E["Idol of Death"] = "Ölüm Putu" end
if E["Idol of Life"] == nil then E["Idol of Life"] = "Yaşam Putu" end
if E["Idol of Night"] == nil then E["Idol of Night"] = "Gece Putu" end
if E["Idol of Rebirth"] == nil then E["Idol of Rebirth"] = "Yeniden Doğuş Putu" end
if E["Idol of Strife"] == nil then E["Idol of Strife"] = "Çekişme Putu" end
if E["Idol of War"] == nil then E["Idol of War"] = "Savaş Putu" end
if E["Idol of the Sage"] == nil then E["Idol of the Sage"] = "Bilge Putu" end
if E["Idol of the Sun"] == nil then E["Idol of the Sun"] = "Güneş Putu" end
if E["Ignition Key"] == nil then E["Ignition Key"] = "Kontak Anahtarı" end
if E["Ilkrud Magthrull's Tome"] == nil then E["Ilkrud Magthrull's Tome"] = "Ilkrud Magthrull'un Cildi" end
if E["Imbel Essence"] == nil then E["Imbel Essence"] = "Imbel Özü" end
if E["Imbued Skeletal Fragments"] == nil then E["Imbued Skeletal Fragments"] = "Güç Aşılanmış İskelet Parçaları" end
if E["Immaculate Letter"] == nil then E["Immaculate Letter"] = "Kusursuz Mektup" end
if E["Imp Summoning Scroll"] == nil then E["Imp Summoning Scroll"] = "Imp Çağırma Tomarı" end
if E["Imp in a Jar"] == nil then E["Imp in a Jar"] = "Kavanozda Imp" end
if E["Imperfect Draenethyst Fragment"] == nil then E["Imperfect Draenethyst Fragment"] = "Kusurlu Draenethyst Parçası" end
if E["Imperial Plate Chest"] == nil then E["Imperial Plate Chest"] = "İmparatorluk Plaka Göğüslüğü" end
if E["Imperial Qiraji Armaments"] == nil then E["Imperial Qiraji Armaments"] = "İmparatorluk Qiraji Silahları" end
if E["Imperial Qiraji Regalia"] == nil then E["Imperial Qiraji Regalia"] = "İmparatorluk Qiraji Nişanları" end
if E["Important Blackrock Documents"] == nil then E["Important Blackrock Documents"] = "Önemli Blackrock Belgeleri" end
if E["Imprisoned Doomguard"] == nil then E["Imprisoned Doomguard"] = "Hapsedilmiş Doomguard" end
if E["Imprisoned Felhound Spirit"] == nil then E["Imprisoned Felhound Spirit"] = "Hapsedilmiş Felhound Ruhu" end
if E["Imprisoned Infernal Spirit"] == nil then E["Imprisoned Infernal Spirit"] = "Hapsedilmiş Infernal Ruhu" end
if E["Incantations from the Nether"] == nil then E["Incantations from the Nether"] = "Nether'dan Büyü Sözleri" end
if E["Incendia Agave"] == nil then E["Incendia Agave"] = "Incendia Agavı" end
if E["Incendia Powder"] == nil then E["Incendia Powder"] = "Incendia Tozu" end
if E["Incendicite of Incendius"] == nil then E["Incendicite of Incendius"] = "Incendius'un Incendicite'i" end
if E["Incendosaur Scale"] == nil then E["Incendosaur Scale"] = "Incendosaur Pulu" end
if E["Incendrites"] == nil then E["Incendrites"] = "Incendrite'ler" end
if E["Incomplete Banner of Provocation"] == nil then E["Incomplete Banner of Provocation"] = "Tamamlanmamış Kışkırtma Sancağı" end
if E["Indurium Flake"] == nil then E["Indurium Flake"] = "Indurium Pulu" end
if E["Indurium Ore"] == nil then E["Indurium Ore"] = "Indurium Cevheri" end
if E["Inert Scourgestone"] == nil then E["Inert Scourgestone"] = "Etkisiz Scourgestone" end
if E["Infernal Orb"] == nil then E["Infernal Orb"] = "Infernal Küresi" end
if E["Infus Emerald"] == nil then E["Infus Emerald"] = "Infus Zümrüdü" end
if E["Infused Burning Gem"] == nil then E["Infused Burning Gem"] = "Güç Aşılanmış Yanan Mücevher" end
if E["Insane Scribbles"] == nil then E["Insane Scribbles"] = "Delice Karalamalar" end
if E["Inscribed Kodo Leather"] == nil then E["Inscribed Kodo Leather"] = "Yazılı Kodo Derisi" end
if E["Insect Analysis Report"] == nil then E["Insect Analysis Report"] = "Böcek Analiz Raporu" end
if E["Insignia of the Black Guard"] == nil then E["Insignia of the Black Guard"] = "Kara Muhafız Nişanı" end
if E["Insignia of the Crusade"] == nil then E["Insignia of the Crusade"] = "Haçlı Seferi Nişanı" end
if E["Insignia of the Dawn"] == nil then E["Insignia of the Dawn"] = "Şafak Nişanı" end
if E["Intact Elemental Bracer"] == nil then E["Intact Elemental Bracer"] = "Sağlam Elemental Bileklik" end
if E["Intact Elemental Core"] == nil then E["Intact Elemental Core"] = "Sağlam Elemental Çekirdek" end
if E["Intact Raptor Horn"] == nil then E["Intact Raptor Horn"] = "Sağlam Raptor Boynuzu" end
if E["Intact Silithid Carapace"] == nil then E["Intact Silithid Carapace"] = "Sağlam Silithid Kabuğu" end
if E["Intrepid Strongbox Key"] == nil then E["Intrepid Strongbox Key"] = "Gözüpek Kasa Anahtarı" end
if E["Invader's Scourgestone"] == nil then E["Invader's Scourgestone"] = "İstilacının Scourgestone'u" end
if E["Iridescent Sprite Darter Wing"] == nil then E["Iridescent Sprite Darter Wing"] = "Yanardöner Sprite Darter Kanadı" end
if E["Iron Bar"] == nil then E["Iron Bar"] = "Demir Külçe" end
if E["Iron Pike"] == nil then E["Iron Pike"] = "Demir Mızrak" end
if E["Iron Pommel"] == nil then E["Iron Pommel"] = "Demir Kabza Gürzü" end
if E["Iron Rivet"] == nil then E["Iron Rivet"] = "Demir Perçin" end
if E["Iron Shaft"] == nil then E["Iron Shaft"] = "Demir Sap" end
if E["Ironband's Progress Report"] == nil then E["Ironband's Progress Report"] = "Ironband'in İlerleme Raporu" end
if E["Irondeep Supplies"] == nil then E["Irondeep Supplies"] = "Irondeep Erzakı" end
if E["Ironforge Mint"] == nil then E["Ironforge Mint"] = "Ironforge Darphanesi" end
if E["Ironfur Liver"] == nil then E["Ironfur Liver"] = "Ironfur Ciğeri" end
if E["Irontree Heart"] == nil then E["Irontree Heart"] = "Irontree Kalbi" end
if E["Ironweb Spider Silk"] == nil then E["Ironweb Spider Silk"] = "Ironweb Örümcek İpeği" end
if E["Ivory Scarab"] == nil then E["Ivory Scarab"] = "Fildişi Skarabe" end
if E["J'eevee's Jar"] == nil then E["J'eevee's Jar"] = "J'eevee'nin Kavanozu" end
if E["Jade"] == nil then E["Jade"] = "Yeşim" end
if E["Jadefire Felbind"] == nil then E["Jadefire Felbind"] = "Jadefire Fel Bağı" end
if E["Jadespine Basilisk Scale"] == nil then E["Jadespine Basilisk Scale"] = "Jadespine Basilisk Pulu" end
if E["Jaina's Autograph"] == nil then E["Jaina's Autograph"] = "Jaina'nın İmzası" end
if E["Jangdor's Letter"] == nil then E["Jangdor's Letter"] = "Jangdor'un Mektubu" end
if E["Janice's Parcel"] == nil then E["Janice's Parcel"] = "Janice'in Paketi" end
if E["Jannok's Rose"] == nil then E["Jannok's Rose"] = "Jannok'un Gülü" end
if E["Jaron's Pick"] == nil then E["Jaron's Pick"] = "Jaron'un Kazması" end
if E["Jaron's Supplies"] == nil then E["Jaron's Supplies"] = "Jaron'un Erzakı" end
if E["Jasper Idol"] == nil then E["Jasper Idol"] = "Jasper Putu" end
if E["Jeering Spectre's Essence"] == nil then E["Jeering Spectre's Essence"] = "Alaycı Hayaletin Özü" end
if E["Jennea's Flask"] == nil then E["Jennea's Flask"] = "Jennea'nın Matarası" end
if E["Jer'kai's Signet Ring"] == nil then E["Jer'kai's Signet Ring"] = "Jer'kai'nin Mühür Yüzüğü" end
if E["Jes'rimon's Note"] == nil then E["Jes'rimon's Note"] = "Jes'rimon'un Notu" end
if E["Jeweled Pendant"] == nil then E["Jeweled Pendant"] = "Mücevherli Kolye" end
if E["Jeztor's Beacon"] == nil then E["Jeztor's Beacon"] = "Jeztor'un İşaret Feneri" end
if E["Jitters' Completed Journal"] == nil then E["Jitters' Completed Journal"] = "Jitters'ın Tamamlanmış Günlüğü" end
if E["Jon-Jon's Golden Spyglass"] == nil then E["Jon-Jon's Golden Spyglass"] = "Jon-Jon'un Altın Dürbünü" end
if E["Jordan's Ore Shipment"] == nil then E["Jordan's Ore Shipment"] = "Jordan'ın Cevher Sevkiyatı" end
if E["Jordan's Refined Ore Shipment"] == nil then E["Jordan's Refined Ore Shipment"] = "Jordan'ın Arıtılmış Cevher Sevkiyatı" end
if E["Jordan's Smithing Hammer"] == nil then E["Jordan's Smithing Hammer"] = "Jordan'ın Demirci Çekici" end
if E["Jordan's Weapon Notes"] == nil then E["Jordan's Weapon Notes"] = "Jordan'ın Silah Notları" end
if E["Joseph's Key"] == nil then E["Joseph's Key"] = "Joseph'in Anahtarı" end
if E["Joseph's Wedding Ring"] == nil then E["Joseph's Wedding Ring"] = "Joseph'in Alyansı" end
if E["Juju Chill"] == nil then E["Juju Chill"] = "Juju Ayazı" end
if E["Juju Ember"] == nil then E["Juju Ember"] = "Juju Közü" end
if E["Juju Escape"] == nil then E["Juju Escape"] = "Juju Kaçışı" end
if E["Juju Flurry"] == nil then E["Juju Flurry"] = "Juju Sağanağı" end
if E["Juju Guile"] == nil then E["Juju Guile"] = "Juju Kurnazlığı" end
if E["Juju Might"] == nil then E["Juju Might"] = "Juju Kudreti" end
if E["Juju Power"] == nil then E["Juju Power"] = "Juju Gücü" end
if E["Jungle Remedy"] == nil then E["Jungle Remedy"] = "Orman Devası" end
if E["Jungle Stalker Feather"] == nil then E["Jungle Stalker Feather"] = "Orman Avcısı Tüyü" end
if E["Junglevine Wine"] == nil then E["Junglevine Wine"] = "Orman Asması Şarabı" end
if E["Kadrak's Flag"] == nil then E["Kadrak's Flag"] = "Kadrak'ın Bayrağı" end
if E["Karang's Banner"] == nil then E["Karang's Banner"] = "Karang'ın Sancağı" end
if E["Karnitol's Satchel"] == nil then E["Karnitol's Satchel"] = "Karnitol'ün Heybesi" end
if E["Katoom's Best Lure"] == nil then E["Katoom's Best Lure"] = "Katoom'un En İyi Yemi" end
if E["Kearnen's Journal"] == nil then E["Kearnen's Journal"] = "Kearnen'in Günlüğü" end
if E["Keefer's Angelfish"] == nil then E["Keefer's Angelfish"] = "Keefer'ın Melek Balığı" end
if E["Keepsake of Remembrance"] == nil then E["Keepsake of Remembrance"] = "Anma Hatırası" end
if E["Keg of Shindigger Stout"] == nil then E["Keg of Shindigger Stout"] = "Bir Fıçı Shindigger Stout" end
if E["Keg of Thunderbrew Lager"] == nil then E["Keg of Thunderbrew Lager"] = "Bir Fıçı Thunderbrew Lager" end
if E["Ken'zigla's Draught"] == nil then E["Ken'zigla's Draught"] = "Ken'zigla'nın İksiri" end
if E["Kenata's Head"] == nil then E["Kenata's Head"] = "Kenata'nın Kafası" end
if E["Kezan's Taint"] == nil then E["Kezan's Taint"] = "Kezan'ın Lekesi" end
if E["Khadgar's Essays on Dimensional Convergence"] == nil then E["Khadgar's Essays on Dimensional Convergence"] = "Khadgar'ın Boyutsal Yakınsama Üzerine Denemeleri" end
if E["Khan Dez'hepah's Head"] == nil then E["Khan Dez'hepah's Head"] = "Khan Dez'hepah'ın Kafası" end
if E["Khan Hratha's Head"] == nil then E["Khan Hratha's Head"] = "Khan Hratha'nın Kafası" end
if E["Khan Jehn's Head"] == nil then E["Khan Jehn's Head"] = "Khan Jehn'in Kafası" end
if E["Khan Shaka's Head"] == nil then E["Khan Shaka's Head"] = "Khan Shaka'nın Kafası" end
if E["Khazgorm's Journal"] == nil then E["Khazgorm's Journal"] = "Khazgorm'un Günlüğü" end
if E["Kilt of Elements"] == nil then E["Kilt of Elements"] = "Elementler Eteği" end
if E["Kim'Jael's Compass"] == nil then E["Kim'Jael's Compass"] = "Kim'Jael'in Pusulası" end
if E["Kim'Jael's Scope"] == nil then E["Kim'Jael's Scope"] = "Kim'Jael'in Dürbünü" end
if E["Kim'Jael's Stuffed Chicken"] == nil then E["Kim'Jael's Stuffed Chicken"] = "Kim'Jael'in Doldurulmuş Tavuğu" end
if E["Kim'Jael's Wizzlegoober"] == nil then E["Kim'Jael's Wizzlegoober"] = "Kim'Jael'in Wizzlegoober'ı" end
if E["Kingsblood"] == nil then E["Kingsblood"] = "Kral Kanı" end
if E["Klaven Mortwake's Journal"] == nil then E["Klaven Mortwake's Journal"] = "Klaven Mortwake'in Günlüğü" end
if E["Klinfran's Head"] == nil then E["Klinfran's Head"] = "Klinfran'ın Kafası" end
if E["Kodo Bone"] == nil then E["Kodo Bone"] = "Kodo Kemiği" end
if E["Kodo Horn"] == nil then E["Kodo Horn"] = "Kodo Boynuzu" end
if E["Kodo Kombobulator"] == nil then E["Kodo Kombobulator"] = "Kodo Kombobulatörü" end
if E["Kodo Liver"] == nil then E["Kodo Liver"] = "Kodo Ciğeri" end
if E["Kodo Skin Scroll"] == nil then E["Kodo Skin Scroll"] = "Kodo Derisi Parşömen" end
if E["Korran's Sealed Note"] == nil then E["Korran's Sealed Note"] = "Korran'ın Mühürlü Notu" end
if E["Krakle's Thermometer"] == nil then E["Krakle's Thermometer"] = "Krakle'ın Termometresi" end
if E["Krastinov's Bag of Horrors"] == nil then E["Krastinov's Bag of Horrors"] = "Krastinov'un Dehşet Çantası" end
if E["Kraul Guano"] == nil then E["Kraul Guano"] = "Kraul Gübresi" end
if E["Kravel's Crate"] == nil then E["Kravel's Crate"] = "Kravel'in Sandığı" end
if E["Kravel's Parts"] == nil then E["Kravel's Parts"] = "Kravel'in Parçaları" end
if E["Kravel's Parts Order"] == nil then E["Kravel's Parts Order"] = "Kravel'in Parça Siparişi" end
if E["Kravel's Scheme"] == nil then E["Kravel's Scheme"] = "Kravel'in Planı" end
if E["Krazek's Crock Pot"] == nil then E["Krazek's Crock Pot"] = "Krazek'in Güveci" end
if E["Krazek's Fixed Pot"] == nil then E["Krazek's Fixed Pot"] = "Krazek'in Tamir Edilmiş Güveci" end
if E["Krom Stoutarm's Treasure"] == nil then E["Krom Stoutarm's Treasure"] = "Krom Stoutarm'ın Hazinesi" end
if E["Kroshius' Infernal Core"] == nil then E["Kroshius' Infernal Core"] = "Kroshius'un İnfernal Çekirdeği" end
if E["Kurinnaxx's Venom Sac"] == nil then E["Kurinnaxx's Venom Sac"] = "Kurinnaxx'in Zehir Kesesi" end
if E["Kurzen's Head"] == nil then E["Kurzen's Head"] = "Kurzen'in Kafası" end
if E["Kuz's Skull"] == nil then E["Kuz's Skull"] = "Kuz'un Kafatası" end
if E["Laden Dew Gland"] == nil then E["Laden Dew Gland"] = "Dolu Çiy Bezi" end
if E["Lahassa Essence"] == nil then E["Lahassa Essence"] = "Lahassa Özü" end
if E["Laird's Response"] == nil then E["Laird's Response"] = "Laird'in Yanıtı" end
if E["Lakmaeran's Carcass"] == nil then E["Lakmaeran's Carcass"] = "Lakmaeran'ın Leşi" end
if E["Lambent Idol"] == nil then E["Lambent Idol"] = "Işıldayan Put" end
if E["Lar'korwi's Head"] == nil then E["Lar'korwi's Head"] = "Lar'korwi'nin Kafası" end
if E["Lard's Lunch"] == nil then E["Lard's Lunch"] = "Lard'ın Öğle Yemeği" end
if E["Large Brilliant Shard"] == nil then E["Large Brilliant Shard"] = "Büyük Parlak Kırıntı" end
if E["Large Compass"] == nil then E["Large Compass"] = "Büyük Pusula" end
if E["Large Radiant Shard"] == nil then E["Large Radiant Shard"] = "Büyük Işıltılı Kırıntı" end
if E["Large River Crocolisk Skin"] == nil then E["Large River Crocolisk Skin"] = "Büyük Nehir Crocolisk Derisi" end
if E["Large Soran'ruk Fragment"] == nil then E["Large Soran'ruk Fragment"] = "Büyük Soran'ruk Parçası" end
if E["Large Stone Slab"] == nil then E["Large Stone Slab"] = "Büyük Taş Levha" end
if E["Laughing Sister's Hair"] == nil then E["Laughing Sister's Hair"] = "Gülen Kız Kardeşin Saçı" end
if E["Lava Core"] == nil then E["Lava Core"] = "Lav Çekirdeği" end
if E["LeCraft Rabbit Pelt"] == nil then E["LeCraft Rabbit Pelt"] = "LeCraft Tavşan Postu" end
if E["Leaded Vial"] == nil then E["Leaded Vial"] = "Kurşunlu Şişe" end
if E["Lean Wolf Flank"] == nil then E["Lean Wolf Flank"] = "Yağsız Kurt Böğrü" end
if E["Lean Wolf Steak"] == nil then E["Lean Wolf Steak"] = "Yağsız Kurt Bifteği" end
if E["Left Piece of Lord Valthalak's Amulet"] == nil then E["Left Piece of Lord Valthalak's Amulet"] = "Lord Valthalak'ın Muskasının Sol Parçası" end
if E["Leftwitch's Package"] == nil then E["Leftwitch's Package"] = "Leftwitch'in Paketi" end
if E["Legacy of the Aspects"] == nil then E["Legacy of the Aspects"] = "Aspect'lerin Mirası" end
if E["Legplates of Valor"] == nil then E["Legplates of Valor"] = "Yiğitlik Bacak Zırhı" end
if E["Lescovar's Head"] == nil then E["Lescovar's Head"] = "Lescovar'ın Kafası" end
if E["Lesser Arcanum of Constitution"] == nil then E["Lesser Arcanum of Constitution"] = "Küçük Bünye Arkanumu" end
if E["Lesser Arcanum of Resilience"] == nil then E["Lesser Arcanum of Resilience"] = "Küçük Direnç Arkanumu" end
if E["Lesser Arcanum of Rumination"] == nil then E["Lesser Arcanum of Rumination"] = "Küçük Tefekkür Arkanumu" end
if E["Lesser Arcanum of Tenacity"] == nil then E["Lesser Arcanum of Tenacity"] = "Küçük Azim Arkanumu" end
if E["Lesser Arcanum of Voracity"] == nil then E["Lesser Arcanum of Voracity"] = "Küçük Açgözlülük Arkanumu" end
if E["Lesser Bloodstone Ore"] == nil then E["Lesser Bloodstone Ore"] = "Küçük Kantaşı Cevheri" end
if E["Lesser Infernal Stone"] == nil then E["Lesser Infernal Stone"] = "Küçük İnfernal Taş" end
if E["Lesser Invisibility Potion"] == nil then E["Lesser Invisibility Potion"] = "Küçük Görünmezlik İksiri" end
if E["Lesser Nether Essence"] == nil then E["Lesser Nether Essence"] = "Küçük Nether Özü" end
if E["Lethtendris's Web"] == nil then E["Lethtendris's Web"] = "Lethtendris'in Ağı" end
if E["Letter of Commendation"] == nil then E["Letter of Commendation"] = "Takdir Mektubu" end
if E["Letter to Delgren"] == nil then E["Letter to Delgren"] = "Delgren'e Mektup" end
if E["Letter to Ello"] == nil then E["Letter to Ello"] = "Ello'ya Mektup" end
if E["Letter to Jin'Zil"] == nil then E["Letter to Jin'Zil"] = "Jin'Zil'e Mektup" end
if E["Letter to Jorgen"] == nil then E["Letter to Jorgen"] = "Jorgen'a Mektup" end
if E["Letter to the City Architect"] == nil then E["Letter to the City Architect"] = "Şehir Mimarına Mektup" end
if E["Lewis' Note"] == nil then E["Lewis' Note"] = "Lewis'in Notu" end
if E["Libram of Constitution"] == nil then E["Libram of Constitution"] = "Bünye Libramı" end
if E["Libram of Focus"] == nil then E["Libram of Focus"] = "Odak Libramı" end
if E["Libram of Protection"] == nil then E["Libram of Protection"] = "Koruma Libramı" end
if E["Libram of Rapidity"] == nil then E["Libram of Rapidity"] = "Sürat Libramı" end
if E["Libram of Resilience"] == nil then E["Libram of Resilience"] = "Direnç Libramı" end
if E["Libram of Rumination"] == nil then E["Libram of Rumination"] = "Tefekkür Libramı" end
if E["Libram of Tenacity"] == nil then E["Libram of Tenacity"] = "Azim Libramı" end
if E["Libram of Voracity"] == nil then E["Libram of Voracity"] = "Açgözlülük Libramı" end
if E["Library Scrip"] == nil then E["Library Scrip"] = "Kütüphane Senedi" end
if E["Lieutenant's Insignia"] == nil then E["Lieutenant's Insignia"] = "Teğmen Nişanı" end
if E["Liferoot"] == nil then E["Liferoot"] = "Hayatkökü" end
if E["Lightforge Belt"] == nil then E["Lightforge Belt"] = "Lightforge Kemeri" end
if E["Lightforge Boots"] == nil then E["Lightforge Boots"] = "Lightforge Çizmeleri" end
if E["Lightforge Bracers"] == nil then E["Lightforge Bracers"] = "Lightforge Bileklikleri" end
if E["Lightforge Breastplate"] == nil then E["Lightforge Breastplate"] = "Lightforge Göğüslüğü" end
if E["Lightforge Gauntlets"] == nil then E["Lightforge Gauntlets"] = "Lightforge Eldivenleri" end
if E["Lightforge Helm"] == nil then E["Lightforge Helm"] = "Lightforge Miğferi" end
if E["Lightforge Ingot"] == nil then E["Lightforge Ingot"] = "Lightforge Külçesi" end
if E["Lightforge Legplates"] == nil then E["Lightforge Legplates"] = "Lightforge Bacak Zırhı" end
if E["Lightforge Spaulders"] == nil then E["Lightforge Spaulders"] = "Lightforge Omurlukları" end
if E["Lightning Eel"] == nil then E["Lightning Eel"] = "Yıldırım Yılan Balığı" end
if E["Lightning Gland"] == nil then E["Lightning Gland"] = "Yıldırım Bezi" end
if E["Lillith's Remains"] == nil then E["Lillith's Remains"] = "Lillith'in Kalıntıları" end
if E["Linken's Superior Sword"] == nil then E["Linken's Superior Sword"] = "Linken'in Üstün Kılıcı" end
if E["Linken's Tempered Sword"] == nil then E["Linken's Tempered Sword"] = "Linken'in Su Verilmiş Kılıcı" end
if E["Linken's Training Sword"] == nil then E["Linken's Training Sword"] = "Linken'in Talim Kılıcı" end
if E["Lion-headed Key"] == nil then E["Lion-headed Key"] = "Aslan Başlı Anahtar" end
if E["Living Rot"] == nil then E["Living Rot"] = "Canlı Çürük" end
if E["Logging Rope"] == nil then E["Logging Rope"] = "Kereste Halatı" end
if E["Logistics Task Briefing I"] == nil then E["Logistics Task Briefing I"] = "Lojistik Görev Brifingi I" end
if E["Logistics Task Briefing II"] == nil then E["Logistics Task Briefing II"] = "Lojistik Görev Brifingi II" end
if E["Logistics Task Briefing III"] == nil then E["Logistics Task Briefing III"] = "Lojistik Görev Brifingi III" end
if E["Logistics Task Briefing IV"] == nil then E["Logistics Task Briefing IV"] = "Lojistik Görev Brifingi IV" end
if E["Logistics Task Briefing IX"] == nil then E["Logistics Task Briefing IX"] = "Lojistik Görev Brifingi IX" end
if E["Logistics Task Briefing V"] == nil then E["Logistics Task Briefing V"] = "Lojistik Görev Brifingi V" end
if E["Logistics Task Briefing VI"] == nil then E["Logistics Task Briefing VI"] = "Lojistik Görev Brifingi VI" end
if E["Logistics Task Briefing VII"] == nil then E["Logistics Task Briefing VII"] = "Lojistik Görev Brifingi VII" end
if E["Logistics Task Briefing VIII"] == nil then E["Logistics Task Briefing VIII"] = "Lojistik Görev Brifingi VIII" end
if E["Logistics Task Briefing X"] == nil then E["Logistics Task Briefing X"] = "Lojistik Görev Brifingi X" end
if E["Logistics Task Briefing XI"] == nil then E["Logistics Task Briefing XI"] = "Lojistik Görev Brifingi XI" end
if E["Lok's Skull"] == nil then E["Lok's Skull"] = "Lok'un Kafatası" end
if E["Lonebrow's Journal"] == nil then E["Lonebrow's Journal"] = "Lonebrow'un Günlüğü" end
if E["Long Elegant Feather"] == nil then E["Long Elegant Feather"] = "Uzun Zarif Tüy" end
if E["Lookout's Spyglass"] == nil then E["Lookout's Spyglass"] = "Gözcünün Dürbünü" end
if E["Lord Grayson's Satchel"] == nil then E["Lord Grayson's Satchel"] = "Lord Grayson'ın Heybesi" end
if E["Lord Valthalak's Amulet"] == nil then E["Lord Valthalak's Amulet"] = "Lord Valthalak'ın Muskası" end
if E["Lorgalis Manuscript"] == nil then E["Lorgalis Manuscript"] = "Lorgalis Elyazması" end
if E["Lost Supplies"] == nil then E["Lost Supplies"] = "Kayıp Erzak" end
if E["Lost Thunderbrew Recipe"] == nil then E["Lost Thunderbrew Recipe"] = "Kayıp Thunderbrew Tarifi" end
if E["Lotwil's Shackles of Elemental Binding"] == nil then E["Lotwil's Shackles of Elemental Binding"] = "Lotwil'in Element Bağlama Prangaları" end
if E["Lovingly Composed Letter"] == nil then E["Lovingly Composed Letter"] = "Sevgiyle Yazılmış Mektup" end
if E["Lower Map Fragment"] == nil then E["Lower Map Fragment"] = "Alt Harita Parçası" end
if E["Lunar Fungus"] == nil then E["Lunar Fungus"] = "Ay Mantarı" end
if E["Lung Juice Cocktail"] == nil then E["Lung Juice Cocktail"] = "Ciğer Suyu Kokteyli" end
if E["Lurker Venom"] == nil then E["Lurker Venom"] = "Pusucu Zehri" end
if E["Lydon's Toxin"] == nil then E["Lydon's Toxin"] = "Lydon'ın Toksini" end
if E["MacKreel's Moonshine"] == nil then E["MacKreel's Moonshine"] = "MacKreel'in Kaçak İçkisi" end
if E["Maelstrom's Tendril"] == nil then E["Maelstrom's Tendril"] = "Girdap Dalı" end
if E["Magatha's Note"] == nil then E["Magatha's Note"] = "Magatha'nın Notu" end
if E["Mage-tastic Gizmonitor"] == nil then E["Mage-tastic Gizmonitor"] = "Büyücüştik Gizmonitör" end
if E["Magenta Fungus Cap"] == nil then E["Magenta Fungus Cap"] = "Eflatun Mantar Şapkası" end
if E["Mageweave Bandage"] == nil then E["Mageweave Bandage"] = "Büyü Kumaşı Sargı" end
if E["Mageweave Cloth"] == nil then E["Mageweave Cloth"] = "Büyü Kumaşı" end
if E["Maggran's Reserve Letter"] == nil then E["Maggran's Reserve Letter"] = "Maggran'ın Yedek Mektubu" end
if E["Magic Beans"] == nil then E["Magic Beans"] = "Sihirli Fasulyeler" end
if E["Magical Book Binding"] == nil then E["Magical Book Binding"] = "Büyülü Kitap Cildi" end
if E["Magical Ledger"] == nil then E["Magical Ledger"] = "Büyülü Defter" end
if E["Magister's Belt"] == nil then E["Magister's Belt"] = "Magister's Kemeri" end
if E["Magister's Bindings"] == nil then E["Magister's Bindings"] = "Magister's Bileklikleri" end
if E["Magister's Boots"] == nil then E["Magister's Boots"] = "Magister's Çizmeleri" end
if E["Magister's Crown"] == nil then E["Magister's Crown"] = "Magister's Tacı" end
if E["Magister's Gloves"] == nil then E["Magister's Gloves"] = "Magister's Eldivenleri" end
if E["Magister's Leggings"] == nil then E["Magister's Leggings"] = "Magister's Tozlukları" end
if E["Magister's Mantle"] == nil then E["Magister's Mantle"] = "Magister's Pelerini" end
if E["Magister's Robes"] == nil then E["Magister's Robes"] = "Magister's Cübbesi" end
if E["Magma Core"] == nil then E["Magma Core"] = "Magma Çekirdeği" end
if E["Maiden's Folly Charts"] == nil then E["Maiden's Folly Charts"] = "Maiden's Folly Haritaları" end
if E["Maiden's Folly Log"] == nil then E["Maiden's Folly Log"] = "Maiden's Folly Seyir Defteri" end
if E["Major Healing Potion"] == nil then E["Major Healing Potion"] = "Büyük Şifa İksiri" end
if E["Major Mana Potion"] == nil then E["Major Mana Potion"] = "Büyük Mana İksiri" end
if E["Malem Pendant"] == nil then E["Malem Pendant"] = "Malem Kolyesi" end
if E["Mallet of Zul'Farrak"] == nil then E["Mallet of Zul'Farrak"] = "Zul'Farrak Tokmağı" end
if E["Mana Potion"] == nil then E["Mana Potion"] = "Mana İksiri" end
if E["Manna-Enriched Horse Feed"] == nil then E["Manna-Enriched Horse Feed"] = "Manna Katkılı At Yemi" end
if E["Manual of Engineering Disciplines"] == nil then E["Manual of Engineering Disciplines"] = "Mühendislik Disiplinleri El Kitabı" end
if E["Maraudine Key Fragment"] == nil then E["Maraudine Key Fragment"] = "Maraudine Anahtar Parçası" end
if E["Marcel's Head"] == nil then E["Marcel's Head"] = "Marcel'in Kafası" end
if E["Marez's Head"] == nil then E["Marez's Head"] = "Marez'in Kafası" end
if E["Margol's Gigantic Horn"] == nil then E["Margol's Gigantic Horn"] = "Margol'ün Devasa Boynuzu" end
if E["Margol's Horn"] == nil then E["Margol's Horn"] = "Margol'ün Boynuzu" end
if E["Mark of Cenarius"] == nil then E["Mark of Cenarius"] = "Cenarius'un Nişanı" end
if E["Mark of Remulos"] == nil then E["Mark of Remulos"] = "Remulos'un Nişanı" end
if E["Marshal Haggard's Badge"] == nil then E["Marshal Haggard's Badge"] = "Mareşal Haggard'ın Rozeti" end
if E["Marshal Windsor's Lost Information"] == nil then E["Marshal Windsor's Lost Information"] = "Mareşal Windsor'ın Kayıp Bilgileri" end
if E["Mary's Looking Glass"] == nil then E["Mary's Looking Glass"] = "Mary'nin Aynası" end
if E["Massive Iron Axe"] == nil then E["Massive Iron Axe"] = "Devasa Demir Balta" end
if E["Master Ryson's All Seeing Eye"] == nil then E["Master Ryson's All Seeing Eye"] = "Usta Ryson'ın Her Şeyi Gören Gözü" end
if E["Mathystra Relic"] == nil then E["Mathystra Relic"] = "Mathystra Kalıntısı" end
if E["Mature Black Dragon Sinew"] == nil then E["Mature Black Dragon Sinew"] = "Yetişkin Kara Ejderha Siniri" end
if E["Mature Blue Dragon Sinew"] == nil then E["Mature Blue Dragon Sinew"] = "Yetişkin Mavi Ejderha Siniri" end
if E["Maury's Clubbed Foot"] == nil then E["Maury's Clubbed Foot"] = "Maury'nin Çarpık Ayağı" end
if E["Maury's Key"] == nil then E["Maury's Key"] = "Maury'nin Anahtarı" end
if E["Maury's Loot"] == nil then E["Maury's Loot"] = "Maury'nin Ganimeti" end
if E["Mazzranache's Head"] == nil then E["Mazzranache's Head"] = "Mazzranache'nin Kafası" end
if E["Mechanical Repair Kit"] == nil then E["Mechanical Repair Kit"] = "Mekanik Tamir Takımı" end
if E["Medallion of Faith"] == nil then E["Medallion of Faith"] = "İnanç Madalyonu" end
if E["Medium Leather"] == nil then E["Medium Leather"] = "Orta Deri" end
if E["Menethil Statuette"] == nil then E["Menethil Statuette"] = "Menethil Heykelciği" end
if E["Merged Ooze Sample"] == nil then E["Merged Ooze Sample"] = "Birleşmiş Balçık Örneği" end
if E["Meridith's Love Letter"] == nil then E["Meridith's Love Letter"] = "Meridith'in Aşk Mektubu" end
if E["Merrin's Letter"] == nil then E["Merrin's Letter"] = "Merrin'in Mektubu" end
if E["Message for Elissa Starbreeze"] == nil then E["Message for Elissa Starbreeze"] = "Elissa Starbreeze İçin Mesaj" end
if E["Metallic Fragments"] == nil then E["Metallic Fragments"] = "Metal Parçaları" end
if E["Middle Map Fragment"] == nil then E["Middle Map Fragment"] = "Orta Harita Parçası" end
if E["Middle of Gelkak's Key"] == nil then E["Middle of Gelkak's Key"] = "Gelkak'ın Anahtarının Orta Parçası" end
if E["Midnight Orb"] == nil then E["Midnight Orb"] = "Gece Yarısı Küresi" end
if E["Might of the Scourge"] == nil then E["Might of the Scourge"] = "Scourge'un Kudreti" end
if E["Mind's Eye"] == nil then E["Mind's Eye"] = "Zihin Gözü" end
if E["Miners' Gear"] == nil then E["Miners' Gear"] = "Madenci Teçhizatı" end
if E["Miners' Union Card"] == nil then E["Miners' Union Card"] = "Madenciler Birliği Kartı" end
if E["Miniature Platinum Discs"] == nil then E["Miniature Platinum Discs"] = "Minyatür Platin Diskler" end
if E["Miniaturization Residue"] == nil then E["Miniaturization Residue"] = "Minyatürleştirme Kalıntısı" end
if E["Minion's Scourgestone"] == nil then E["Minion's Scourgestone"] = "Uşak Scourgestone'u" end
if E["Mire Lord Fungus"] == nil then E["Mire Lord Fungus"] = "Bataklık Lordu Mantarı" end
if E["Mirefin Head"] == nil then E["Mirefin Head"] = "Mirefin Kafası" end
if E["Mirror Lake Water Sample"] == nil then E["Mirror Lake Water Sample"] = "Mirror Lake Su Örneği" end
if E["Miscellaneous Goblin Supplies"] == nil then E["Miscellaneous Goblin Supplies"] = "Çeşitli Goblin Malzemeleri" end
if E["Mist Veil's Lockbox"] == nil then E["Mist Veil's Lockbox"] = "Mist Veil'in Kilitli Kutusu" end
if E["Mistmantle Family Ring"] == nil then E["Mistmantle Family Ring"] = "Mistmantle Aile Yüzüğü" end
if E["Mistvale Giblets"] == nil then E["Mistvale Giblets"] = "Mistvale Sakatatı" end
if E["Misty Reed Mahi Mahi"] == nil then E["Misty Reed Mahi Mahi"] = "Misty Reed Mahi Mahi'si" end
if E["Mithril Bar"] == nil then E["Mithril Bar"] = "Mithril Külçe" end
if E["Mithril Casing"] == nil then E["Mithril Casing"] = "Mithril Kasa" end
if E["Mithril Coif"] == nil then E["Mithril Coif"] = "Mithril Başlık" end
if E["Mithril Insignia"] == nil then E["Mithril Insignia"] = "Mithril Nişan" end
if E["Mithril Pendant"] == nil then E["Mithril Pendant"] = "Mithril Kolye" end
if E["Mithril Tube"] == nil then E["Mithril Tube"] = "Mithril Tüp" end
if E["Mo'grosh Crystal"] == nil then E["Mo'grosh Crystal"] = "Mo'grosh Kristali" end
if E["Model 4711-FTZ Power Source"] == nil then E["Model 4711-FTZ Power Source"] = "Model 4711-FTZ Güç Kaynağı" end
if E["Modified Seaforium Booster"] == nil then E["Modified Seaforium Booster"] = "Değiştirilmiş Seaforium Güçlendirici" end
if E["Modr Fragment"] == nil then E["Modr Fragment"] = "Modr Parçası" end
if E["Mok'Morokk's Grog"] == nil then E["Mok'Morokk's Grog"] = "Mok'Morokk'un Grogu" end
if E["Mok'Morokk's Snuff"] == nil then E["Mok'Morokk's Snuff"] = "Mok'Morokk'un Enfiyesi" end
if E["Mok'Morokk's Strongbox"] == nil then E["Mok'Morokk's Strongbox"] = "Mok'Morokk'un Kasası" end
if E["Moldy Tome"] == nil then E["Moldy Tome"] = "Küflü Cilt" end
if E["Monogrammed Sash"] == nil then E["Monogrammed Sash"] = "Monogramlı Kuşak" end
if E["Monstrous Crawler Leg"] == nil then E["Monstrous Crawler Leg"] = "Devasa Sürüngen Bacağı" end
if E["Mooncloth"] == nil then E["Mooncloth"] = "Ay Kumaşı" end
if E["Moonstalker Fang"] == nil then E["Moonstalker Fang"] = "Moonstalker Dişi" end
if E["Moonsteel Broadsword"] == nil then E["Moonsteel Broadsword"] = "Ay Çeliği Geniş Kılıç" end
if E["Moontouched Feather"] == nil then E["Moontouched Feather"] = "Ay Değmiş Tüy" end
if E["Moonwell Water Tube"] == nil then E["Moonwell Water Tube"] = "Ay Kuyusu Su Tüpü" end
if E["Mor'Ladim's Skull"] == nil then E["Mor'Ladim's Skull"] = "Mor'Ladim'in Kafatası" end
if E["Mor'zul's Instructions"] == nil then E["Mor'zul's Instructions"] = "Mor'zul'un Talimatları" end
if E["Morbent's Bane"] == nil then E["Morbent's Bane"] = "Morbent'in Belası" end
if E["Mortar and Pestle"] == nil then E["Mortar and Pestle"] = "Havan ve Havaneli" end
if E["Moss Agate"] == nil then E["Moss Agate"] = "Yosun Akiki" end
if E["Mote of Myzrael"] == nil then E["Mote of Myzrael"] = "Myzrael Zerresi" end
if E["Mountain Giant Muisek"] == nil then E["Mountain Giant Muisek"] = "Dağ Devi Muisek'i" end
if E["Mountain Giant Muisek Vessel"] == nil then E["Mountain Giant Muisek Vessel"] = "Dağ Devi Muisek Kabı" end
if E["Mountain Lion Blood"] == nil then E["Mountain Lion Blood"] = "Dağ Aslanı Kanı" end
if E["Muckrake's Head"] == nil then E["Muckrake's Head"] = "Muckrake'in Kafası" end
if E["Muddy Journal Pages"] == nil then E["Muddy Journal Pages"] = "Çamurlu Günlük Sayfaları" end
if E["Muddy Note"] == nil then E["Muddy Note"] = "Çamurlu Not" end
if E["Mudskunk Lure"] == nil then E["Mudskunk Lure"] = "Mudskunk Yemi" end
if E["Mudsnout Blossoms"] == nil then E["Mudsnout Blossoms"] = "Mudsnout Çiçekleri" end
if E["Mudsnout Composite"] == nil then E["Mudsnout Composite"] = "Mudsnout Bileşimi" end
if E["Mudsnout Mixture"] == nil then E["Mudsnout Mixture"] = "Mudsnout Karışımı" end
if E["Mug'thol's Head"] == nil then E["Mug'thol's Head"] = "Mug'thol'ün Kafası" end
if E["Mulverick's Beacon"] == nil then E["Mulverick's Beacon"] = "Mulverick'in İşaret Feneri" end
if E["Murgut's Totem"] == nil then E["Murgut's Totem"] = "Murgut'un Totemi" end
if E["Murloc Eye"] == nil then E["Murloc Eye"] = "Murloc Gözü" end
if E["Murloc Fin"] == nil then E["Murloc Fin"] = "Murloc Yüzgeci" end
if E["Murloc Head"] == nil then E["Murloc Head"] = "Murloc Kafası" end
if E["Musquash Root"] == nil then E["Musquash Root"] = "Musquash Kökü" end
if E["Musty Letter"] == nil then E["Musty Letter"] = "Küf Kokulu Mektup" end
if E["Musty Missive"] == nil then E["Musty Missive"] = "Küf Kokulu Mesaj" end
if E["Musty Note"] == nil then E["Musty Note"] = "Küf Kokulu Not" end
if E["Musty Parchment"] == nil then E["Musty Parchment"] = "Küf Kokulu Parşömen" end
if E["Musty Scroll"] == nil then E["Musty Scroll"] = "Küf Kokulu Tomar" end
if E["Mysterious Artifact"] == nil then E["Mysterious Artifact"] = "Gizemli Eser" end
if E["Mysterious Envelope"] == nil then E["Mysterious Envelope"] = "Gizemli Zarf" end
if E["Mysterious Fossil"] == nil then E["Mysterious Fossil"] = "Gizemli Fosil" end
if E["Mysterious Relic"] == nil then E["Mysterious Relic"] = "Gizemli Kalıntı" end
if E["Mystic Crystal"] == nil then E["Mystic Crystal"] = "Mistik Kristal" end
if E["Mythology of the Titans"] == nil then E["Mythology of the Titans"] = "Titanların Mitolojisi" end
if E["NG-5 Explosives (Blue)"] == nil then E["NG-5 Explosives (Blue)"] = "NG-5 Patlayıcı (Mavi)" end
if E["NG-5 Explosives (Red)"] == nil then E["NG-5 Explosives (Red)"] = "NG-5 Patlayıcı (Kırmızı)" end
if E["Nagaz Parchment"] == nil then E["Nagaz Parchment"] = "Nagaz Parşömeni" end
if E["Nagmara's Filled Vial"] == nil then E["Nagmara's Filled Vial"] = "Nagmara'nın Dolu Şişesi" end
if E["Nagmara's Vial"] == nil then E["Nagmara's Vial"] = "Nagmara'nın Şişesi" end
if E["Nak's Skull"] == nil then E["Nak's Skull"] = "Nak'ın Kafatası" end
if E["Narain's Scrying Goggles"] == nil then E["Narain's Scrying Goggles"] = "Narain'in Kehanet Gözlüğü" end
if E["Narain's Special Kit"] == nil then E["Narain's Special Kit"] = "Narain'in Özel Takımı" end
if E["Nat's Measuring Tape"] == nil then E["Nat's Measuring Tape"] = "Nat'in Mezurası" end
if E["Nathanos' Chest"] == nil then E["Nathanos' Chest"] = "Nathanos'un Sandığı" end
if E["Nature Mantle of the Dawn"] == nil then E["Nature Mantle of the Dawn"] = "Şafağın Doğa Pelerini" end
if E["Necklace and Gem Salvage"] == nil then E["Necklace and Gem Salvage"] = "Kurtarılmış Kolye ve Mücevherler" end
if E["Necrotic Rune"] == nil then E["Necrotic Rune"] = "Nekrotik Rün" end
if E["Neeka's Report"] == nil then E["Neeka's Report"] = "Neeka'nın Raporu" end
if E["Neeru's Herb Pouch"] == nil then E["Neeru's Herb Pouch"] = "Neeru'nun Ot Kesesi" end
if E["Nek'rosh's Head"] == nil then E["Nek'rosh's Head"] = "Nek'rosh'un Kafası" end
if E["Nekrum's Medallion"] == nil then E["Nekrum's Medallion"] = "Nekrum'un Madalyonu" end
if E["Neru Fragment"] == nil then E["Neru Fragment"] = "Neru Parçası" end
if E["Nessa's Collection"] == nil then E["Nessa's Collection"] = "Nessa'nın Koleksiyonu" end
if E["Nether Wing"] == nil then E["Nether Wing"] = "Nether Kanadı" end
if E["Nexus Crystal"] == nil then E["Nexus Crystal"] = "Nexus Kristali" end
if E["Nezzliok's Head"] == nil then E["Nezzliok's Head"] = "Nezzliok'un Kafası" end
if E["Night Dragon's Breath"] == nil then E["Night Dragon's Breath"] = "Gece Ejderhası Nefesi" end
if E["Nightmare Engulfed Object"] == nil then E["Nightmare Engulfed Object"] = "Kâbusa Gömülmüş Nesne" end
if E["Nightmare Shard"] == nil then E["Nightmare Shard"] = "Kâbus Parçası" end
if E["Nightscape Boots"] == nil then E["Nightscape Boots"] = "Nightscape Çizmeleri" end
if E["Nightscape Headband"] == nil then E["Nightscape Headband"] = "Nightscape Saç Bandı" end
if E["Nightscape Pants"] == nil then E["Nightscape Pants"] = "Nightscape Pantolonu" end
if E["Nightscape Tunic"] == nil then E["Nightscape Tunic"] = "Nightscape Tuniği" end
if E["Nimboya's Pike"] == nil then E["Nimboya's Pike"] = "Nimboya'nın Mızrağı" end
if E["Nitroglycerin"] == nil then E["Nitroglycerin"] = "Nitrogliserin" end
if E["Nixx's Pledge of Secrecy"] == nil then E["Nixx's Pledge of Secrecy"] = "Nixx'in Gizlilik Taahhüdü" end
if E["Nixx's Signed Pledge"] == nil then E["Nixx's Signed Pledge"] = "Nixx'in İmzalı Taahhüdü" end
if E["Noggle's Satchel"] == nil then E["Noggle's Satchel"] = "Noggle'ın Heybesi" end
if E["Northshire Gift Voucher"] == nil then E["Northshire Gift Voucher"] = "Northshire Hediye Çeki" end
if E["Note from Neeru"] == nil then E["Note from Neeru"] = "Neeru'dan Not" end
if E["Nugget Slug"] == nil then E["Nugget Slug"] = "Külçe Sümüklüböceği" end
if E["OLDNoboru's Cudgel"] == nil then E["OLDNoboru's Cudgel"] = "OLDNoboru'nun Sopası" end
if E["OLDPlague Vials"] == nil then E["OLDPlague Vials"] = "OLDVeba Şişeleri" end
if E["OOX-09/HL Distress Beacon"] == nil then E["OOX-09/HL Distress Beacon"] = "OOX-09/HL İmdat İşareti" end
if E["OOX-17/TN Distress Beacon"] == nil then E["OOX-17/TN Distress Beacon"] = "OOX-17/TN İmdat İşareti" end
if E["OOX-22/FE Distress Beacon"] == nil then E["OOX-22/FE Distress Beacon"] = "OOX-22/FE İmdat İşareti" end
if E["Oathstone of Ysera's Dragonflight"] == nil then E["Oathstone of Ysera's Dragonflight"] = "Ysera'nın Ejderha Soyunun Yemin Taşı" end
if E["Obsidian Golem Shard"] == nil then E["Obsidian Golem Shard"] = "Obsidyen Golem Parçası" end
if E["Obsidian Idol"] == nil then E["Obsidian Idol"] = "Obsidyen Put" end
if E["Obsidian Power Source"] == nil then E["Obsidian Power Source"] = "Obsidyen Güç Kaynağı" end
if E["Of Love and Family"] == nil then E["Of Love and Family"] = "Aşk ve Aile Üzerine" end
if E["Oglethorpe's Pledge of Secrecy"] == nil then E["Oglethorpe's Pledge of Secrecy"] = "Oglethorpe'un Gizlilik Taahhüdü" end
if E["Oglethorpe's Signed Pledge"] == nil then E["Oglethorpe's Signed Pledge"] = "Oglethorpe'un İmzalı Taahhüdü" end
if E["Ogre Tannin"] == nil then E["Ogre Tannin"] = "Ogre Taneni" end
if E["Ogre Warbeads"] == nil then E["Ogre Warbeads"] = "Ogre Savaş Boncukları" end
if E["Ogre's Monocle"] == nil then E["Ogre's Monocle"] = "Ogre'nin Tek Gözlüğü" end
if E["Oil of Immolation"] == nil then E["Oil of Immolation"] = "Yakma Yağı" end
if E["Okra"] == nil then E["Okra"] = "Bamya" end
if E["Ol' Sooty's Head"] == nil then E["Ol' Sooty's Head"] = "Ol' Sooty'nin Kafası" end
if E["Omarion's Handbook"] == nil then E["Omarion's Handbook"] = "Omarion'un El Kitabı" end
if E["Omokk's Head"] == nil then E["Omokk's Head"] = "Omokk'un Kafası" end
if E["Onin's Report"] == nil then E["Onin's Report"] = "Onin'in Raporu" end
if E["Onyx Idol"] == nil then E["Onyx Idol"] = "Oniks Put" end
if E["Opal Runestone"] == nil then E["Opal Runestone"] = "Opal Rün Taşı" end
if E["Or'Kalar's Head"] == nil then E["Or'Kalar's Head"] = "Or'Kalar'ın Kafası" end
if E["Oracle Crystal"] == nil then E["Oracle Crystal"] = "Kâhin Kristali" end
if E["Orange Hakkari Bijou"] == nil then E["Orange Hakkari Bijou"] = "Turuncu Hakkari Biblosu" end
if E["Orb of Draconic Energy"] == nil then E["Orb of Draconic Energy"] = "Ejder Enerjisi Küresi" end
if E["Orc Tooth"] == nil then E["Orc Tooth"] = "Ork Dişi" end
if E["Orcish Orphan Whistle"] == nil then E["Orcish Orphan Whistle"] = "Ork Yetim Düdüğü" end
if E["Ordanus' Head"] == nil then E["Ordanus' Head"] = "Ordanus'un Kafası" end
if E["Ordinary Egg"] == nil then E["Ordinary Egg"] = "Sıradan Yumurta" end
if E["Orendil's Cure"] == nil then E["Orendil's Cure"] = "Orendil'in İlacı" end
if E["Orgrimmar Nougat"] == nil then E["Orgrimmar Nougat"] = "Orgrimmar Nugası" end
if E["Ornate Mirror"] == nil then E["Ornate Mirror"] = "Süslü Ayna" end
if E["Ornate Mithril Boots"] == nil then E["Ornate Mithril Boots"] = "Süslü Mithril Çizmeler" end
if E["Ornate Mithril Breastplate"] == nil then E["Ornate Mithril Breastplate"] = "Süslü Mithril Göğüslük" end
if E["Ornate Mithril Gloves"] == nil then E["Ornate Mithril Gloves"] = "Süslü Mithril Eldivenler" end
if E["Ornate Mithril Helm"] == nil then E["Ornate Mithril Helm"] = "Süslü Mithril Miğfer" end
if E["Ornate Mithril Pants"] == nil then E["Ornate Mithril Pants"] = "Süslü Mithril Pantolon" end
if E["Ornate Mithril Shoulder"] == nil then E["Ornate Mithril Shoulder"] = "Süslü Mithril Omurluk" end
if E["Orwin's Shovel"] == nil then E["Orwin's Shovel"] = "Orwin'in Küreği" end
if E["Oslow's Toolbox"] == nil then E["Oslow's Toolbox"] = "Oslow'un Alet Kutusu" end
if E["Osric's Crate"] == nil then E["Osric's Crate"] = "Osric'in Sandığı" end
if E["Osseous Agitator"] == nil then E["Osseous Agitator"] = "Kemik Karıştırıcı" end
if E["Otto's Head"] == nil then E["Otto's Head"] = "Otto'nun Kafası" end
if E["Ouro's Intact Hide"] == nil then E["Ouro's Intact Hide"] = "Ouro'nun Sağlam Derisi" end
if E["Overdue Package"] == nil then E["Overdue Package"] = "Gecikmiş Paket" end
if E["Overlord Ror's Claw"] == nil then E["Overlord Ror's Claw"] = "Derebeyi Ror'un Pençesi" end
if E["Overseer's Whistle"] == nil then E["Overseer's Whistle"] = "Gözetmenin Düdüğü" end
if E["Overspark's Pledge of Secrecy"] == nil then E["Overspark's Pledge of Secrecy"] = "Overspark'ın Gizlilik Taahhüdü" end
if E["Overspark's Signed Pledge"] == nil then E["Overspark's Signed Pledge"] = "Overspark'ın İmzalı Taahhüdü" end
if E["Package for Stormpike"] == nil then E["Package for Stormpike"] = "Stormpike İçin Paket" end
if E["Package of Empty Ooze Containers"] == nil then E["Package of Empty Ooze Containers"] = "Boş Balçık Kapları Paketi" end
if E["Packet of Tharlendris Seeds"] == nil then E["Packet of Tharlendris Seeds"] = "Bir Paket Tharlendris Tohumu" end
if E["Pamela's Doll"] == nil then E["Pamela's Doll"] = "Pamela'nın Bebeği" end
if E["Pamela's Doll's Head"] == nil then E["Pamela's Doll's Head"] = "Pamela'nın Bebeğinin Kafası" end
if E["Pamela's Doll's Left Side"] == nil then E["Pamela's Doll's Left Side"] = "Pamela'nın Bebeğinin Sol Yarısı" end
if E["Pamela's Doll's Right Side"] == nil then E["Pamela's Doll's Right Side"] = "Pamela'nın Bebeğinin Sağ Yarısı" end
if E["Panther Cage Key"] == nil then E["Panther Cage Key"] = "Panter Kafesi Anahtarı" end
if E["Parker's Lunch"] == nil then E["Parker's Lunch"] = "Parker'ın Öğle Yemeği" end
if E["Patch of Duskwing's Fur"] == nil then E["Patch of Duskwing's Fur"] = "Duskwing'in Kürkünden Bir Parça" end
if E["Patch of Tainted Skin"] == nil then E["Patch of Tainted Skin"] = "Bir Parça Lekeli Deri" end
if E["Patterned Bronze Bracers"] == nil then E["Patterned Bronze Bracers"] = "Desenli Bronz Bileklikler" end
if E["Pauldrons of Elements"] == nil then E["Pauldrons of Elements"] = "Elementler Omuzlukları" end
if E["Paw of Sin'Dall"] == nil then E["Paw of Sin'Dall"] = "Sin'Dall'ın Pençesi" end
if E["Pebble of Kajaro"] == nil then E["Pebble of Kajaro"] = "Kajaro Çakıl Taşı" end
if E["Pendant of Myzrael"] == nil then E["Pendant of Myzrael"] = "Myzrael Kolyesi" end
if E["Pendant of Shadow"] == nil then E["Pendant of Shadow"] = "Gölge Kolyesi" end
if E["Pendant of the Sea Lion"] == nil then E["Pendant of the Sea Lion"] = "Deniz Aslanı Kolyesi" end
if E["Perenolde Tiara"] == nil then E["Perenolde Tiara"] = "Perenolde Tacı" end
if E["Perfect Courser Antler"] == nil then E["Perfect Courser Antler"] = "Kusursuz Courser Boynuzu" end
if E["Perfect Yeti Hide"] == nil then E["Perfect Yeti Hide"] = "Kusursuz Yeti Postu" end
if E["Perfume Bottle"] == nil then E["Perfume Bottle"] = "Parfüm Şişesi" end
if E["Pestlezugg's Un'Goro Report"] == nil then E["Pestlezugg's Un'Goro Report"] = "Pestlezugg'ın Un'Goro Raporu" end
if E["Petrified Bark"] == nil then E["Petrified Bark"] = "Taşlaşmış Ağaç Kabuğu" end
if E["Phial of Scrying"] == nil then E["Phial of Scrying"] = "Kehanet Şişesi" end
if E["Piece of Krom'zar's Banner"] == nil then E["Piece of Krom'zar's Banner"] = "Krom'zar'ın Sancağından Bir Parça" end
if E["Piece of Threshadon Carcass"] == nil then E["Piece of Threshadon Carcass"] = "Threshadon Leşinden Bir Parça" end
if E["Plague-Infested Quilboar Mane"] == nil then E["Plague-Infested Quilboar Mane"] = "Veba Bulaşmış Quilboar Yelesi" end
if E["Plagued Flesh Sample"] == nil then E["Plagued Flesh Sample"] = "Vebalı Et Örneği" end
if E["Plainstrider Kidney"] == nil then E["Plainstrider Kidney"] = "Plainstrider Böbreği" end
if E["Plated Armorfish"] == nil then E["Plated Armorfish"] = "Pullu Zırhbalığı" end
if E["Pocked Black Box"] == nil then E["Pocked Black Box"] = "Çukurlu Kara Kutu" end
if E["Portals Deck"] == nil then E["Portals Deck"] = "Geçitler Destesi" end
if E["Pouch of Reindeer Dust"] == nil then E["Pouch of Reindeer Dust"] = "Bir Kese Ren Geyiği Tozu" end
if E["Powdered Azurite"] == nil then E["Powdered Azurite"] = "Toz Azurit" end
if E["Power of the Scourge"] == nil then E["Power of the Scourge"] = "Scourge'un Gücü" end
if E["Powerful Anti-Venom"] == nil then E["Powerful Anti-Venom"] = "Güçlü Panzehir" end
if E["Powerful Mojo"] == nil then E["Powerful Mojo"] = "Güçlü Mojo" end
if E["Powers of the Void"] == nil then E["Powers of the Void"] = "Boşluğun Güçleri" end
if E["Pratt's Letter"] == nil then E["Pratt's Letter"] = "Pratt'in Mektubu" end
if E["Prayer to Elune"] == nil then E["Prayer to Elune"] = "Elune'a Dua" end
if E["Prepared Field Duty Papers"] == nil then E["Prepared Field Duty Papers"] = "Hazırlanmış Saha Görevi Belgeleri" end
if E["Preserved Pheromone Mixture"] == nil then E["Preserved Pheromone Mixture"] = "Korunmuş Feromon Karışımı" end
if E["Preserved Threshadon Meat"] == nil then E["Preserved Threshadon Meat"] = "Korunmuş Threshadon Eti" end
if E["Pridewing Venom Sac"] == nil then E["Pridewing Venom Sac"] = "Pridewing Zehir Kesesi" end
if E["Primal Hakkari Aegis"] == nil then E["Primal Hakkari Aegis"] = "İlkel Hakkari Siperi" end
if E["Primal Hakkari Armsplint"] == nil then E["Primal Hakkari Armsplint"] = "İlkel Hakkari Kol Ateli" end
if E["Primal Hakkari Bindings"] == nil then E["Primal Hakkari Bindings"] = "İlkel Hakkari Bileklikleri" end
if E["Primal Hakkari Girdle"] == nil then E["Primal Hakkari Girdle"] = "İlkel Hakkari Kemeri" end
if E["Primal Hakkari Idol"] == nil then E["Primal Hakkari Idol"] = "İlkel Hakkari Putu" end
if E["Primal Hakkari Kossack"] == nil then E["Primal Hakkari Kossack"] = "İlkel Hakkari Kosağı" end
if E["Primal Hakkari Sash"] == nil then E["Primal Hakkari Sash"] = "İlkel Hakkari Kuşağı" end
if E["Primal Hakkari Shawl"] == nil then E["Primal Hakkari Shawl"] = "İlkel Hakkari Şalı" end
if E["Primal Hakkari Stanchion"] == nil then E["Primal Hakkari Stanchion"] = "İlkel Hakkari Payandası" end
if E["Primal Hakkari Tabard"] == nil then E["Primal Hakkari Tabard"] = "İlkel Hakkari Tabardı" end
if E["Prismatic Punch Card"] == nil then E["Prismatic Punch Card"] = "Prizmatik Delikli Kart" end
if E["Prismatic Shell"] == nil then E["Prismatic Shell"] = "Prizmatik Kabuk" end
if E["Pristine Black Diamond"] == nil then E["Pristine Black Diamond"] = "Kusursuz Kara Elmas" end
if E["Pristine Crawler Leg"] == nil then E["Pristine Crawler Leg"] = "Kusursuz Sürüngen Bacağı" end
if E["Pristine Hide of the Beast"] == nil then E["Pristine Hide of the Beast"] = "Canavarın Kusursuz Postu" end
if E["Pristine Spider Silk"] == nil then E["Pristine Spider Silk"] = "Kusursuz Örümcek İpeği" end
if E["Pristine Tigress Fang"] == nil then E["Pristine Tigress Fang"] = "Kusursuz Dişi Kaplan Dişi" end
if E["Pristine Yeti Hide"] == nil then E["Pristine Yeti Hide"] = "Kusursuz Yeti Postu" end
if E["Pristine Yeti Horn"] == nil then E["Pristine Yeti Horn"] = "Kusursuz Yeti Boynuzu" end
if E["Proof of Deed"] == nil then E["Proof of Deed"] = "Tapu Belgesi" end
if E["Prospector's Pick"] == nil then E["Prospector's Pick"] = "Maden Arayıcısının Kazması" end
if E["Prowler Claws"] == nil then E["Prowler Claws"] = "Sinsi Avcı Pençeleri" end
if E["Pulsing Blue Shard"] == nil then E["Pulsing Blue Shard"] = "Atan Mavi Kırıntı" end
if E["Punctured Voodoo Doll"] == nil then E["Punctured Voodoo Doll"] = "Delinmiş Vudu Bebeği" end
if E["Pupellyverbos Port"] == nil then E["Pupellyverbos Port"] = "Pupellyverbos Porto Şarabı" end
if E["Pure Hearts"] == nil then E["Pure Hearts"] = "Saf Kalpler" end
if E["Pure Un'Goro Sample"] == nil then E["Pure Un'Goro Sample"] = "Saf Un'Goro Örneği" end
if E["Purified Kor Gem"] == nil then E["Purified Kor Gem"] = "Arındırılmış Kor Taşı" end
if E["Purified Moonwell Water"] == nil then E["Purified Moonwell Water"] = "Arındırılmış Ay Kuyusu Suyu" end
if E["Purple Hakkari Bijou"] == nil then E["Purple Hakkari Bijou"] = "Mor Hakkari Biblosu" end
if E["Purple Lotus"] == nil then E["Purple Lotus"] = "Mor Lotus" end
if E["Putrid Bile Duct"] == nil then E["Putrid Bile Duct"] = "Kokuşmuş Safra Kanalı" end
if E["Putrid Vine"] == nil then E["Putrid Vine"] = "Kokuşmuş Sarmaşık" end
if E["Qiraji Bindings of Command"] == nil then E["Qiraji Bindings of Command"] = "Qiraji Komuta Bileklikleri" end
if E["Qiraji Bindings of Dominance"] == nil then E["Qiraji Bindings of Dominance"] = "Qiraji Hâkimiyet Bileklikleri" end
if E["Qiraji Blessed Jewel"] == nil then E["Qiraji Blessed Jewel"] = "Qiraji Kutsanmış Mücevheri" end
if E["Qiraji Ceremonial Ring"] == nil then E["Qiraji Ceremonial Ring"] = "Qiraji Tören Yüzüğü" end
if E["Qiraji Encased Jewel"] == nil then E["Qiraji Encased Jewel"] = "Qiraji Kaplanmış Mücevheri" end
if E["Qiraji Engraved Jewel"] == nil then E["Qiraji Engraved Jewel"] = "Qiraji Oymalı Mücevheri" end
if E["Qiraji Glyphed Jewel"] == nil then E["Qiraji Glyphed Jewel"] = "Qiraji Glifli Mücevheri" end
if E["Qiraji Lord's Insignia"] == nil then E["Qiraji Lord's Insignia"] = "Qiraji Lordunun Nişanı" end
if E["Qiraji Magisterial Ring"] == nil then E["Qiraji Magisterial Ring"] = "Qiraji Hâkim Yüzüğü" end
if E["Qiraji Martial Drape"] == nil then E["Qiraji Martial Drape"] = "Qiraji Savaş Pelerini" end
if E["Qiraji Ornate Hilt"] == nil then E["Qiraji Ornate Hilt"] = "Qiraji Süslü Kabzası" end
if E["Qiraji Regal Drape"] == nil then E["Qiraji Regal Drape"] = "Qiraji Asil Pelerini" end
if E["Qiraji Spiked Hilt"] == nil then E["Qiraji Spiked Hilt"] = "Qiraji Dikenli Kabzası" end
if E["Quel'Thalas Registry"] == nil then E["Quel'Thalas Registry"] = "Quel'Thalas Sicili" end
if E["Rabine's Letter"] == nil then E["Rabine's Letter"] = "Rabine'in Mektubu" end
if E["Rackmore's Golden Key"] == nil then E["Rackmore's Golden Key"] = "Rackmore'un Altın Anahtarı" end
if E["Rackmore's Silver Key"] == nil then E["Rackmore's Silver Key"] = "Rackmore'un Gümüş Anahtarı" end
if E["Radiant Circlet"] == nil then E["Radiant Circlet"] = "Işıltılı Taç" end
if E["Rage Scar Yeti Hide"] == nil then E["Rage Scar Yeti Hide"] = "Rage Scar Yeti Postu" end
if E["Raging Beast's Blood"] == nil then E["Raging Beast's Blood"] = "Kudurmuş Canavar Kanı" end
if E["Rainbow Fin Albacore"] == nil then E["Rainbow Fin Albacore"] = "Gökkuşağı Yüzgeçli Ton Balığı" end
if E["Ran Bloodtooth's Skull"] == nil then E["Ran Bloodtooth's Skull"] = "Ran Bloodtooth'un Kafatası" end
if E["Ransom Letter"] == nil then E["Ransom Letter"] = "Fidye Mektubu" end
if E["Raptor Heart"] == nil then E["Raptor Heart"] = "Raptor Kalbi" end
if E["Raptor Talon Amulet"] == nil then E["Raptor Talon Amulet"] = "Raptor Pençesi Muskası" end
if E["Raschal's Report"] == nil then E["Raschal's Report"] = "Raschal'ın Raporu" end
if E["Rat Catcher's Flute"] == nil then E["Rat Catcher's Flute"] = "Fare Avcısının Flütü" end
if E["Rattlecage Skull"] == nil then E["Rattlecage Skull"] = "Rattlecage Kafatası" end
if E["Ravager's Skull"] == nil then E["Ravager's Skull"] = "Yağmacının Kafatası" end
if E["Ravasaur Pheromone Gland"] == nil then E["Ravasaur Pheromone Gland"] = "Ravasaur Feromon Bezi" end
if E["Razorflank's Heart"] == nil then E["Razorflank's Heart"] = "Razorflank'in Kalbi" end
if E["Razorflank's Medallion"] == nil then E["Razorflank's Medallion"] = "Razorflank'in Madalyonu" end
if E["Razormane Backstabber"] == nil then E["Razormane Backstabber"] = "Razormane Sırttan Bıçaklayıcısı" end
if E["Razormane War Shield"] == nil then E["Razormane War Shield"] = "Razormane Savaş Kalkanı" end
if E["Razzashi Coin"] == nil then E["Razzashi Coin"] = "Razzashi Sikkesi" end
if E["Reagent Pouch"] == nil then E["Reagent Pouch"] = "Bileşen Kesesi" end
if E["Reconstructed Rod"] == nil then E["Reconstructed Rod"] = "Yeniden Yapılmış Asa" end
if E["Reconstructed Tome"] == nil then E["Reconstructed Tome"] = "Yeniden Yapılmış Cilt" end
if E["Recovered Tome"] == nil then E["Recovered Tome"] = "Kurtarılmış Cilt" end
if E["Red Dye"] == nil then E["Red Dye"] = "Kırmızı Boya" end
if E["Red Hakkari Bijou"] == nil then E["Red Hakkari Bijou"] = "Kırmızı Hakkari Biblosu" end
if E["Red Leather Bandana"] == nil then E["Red Leather Bandana"] = "Kırmızı Deri Bandana" end
if E["Red Moro'gai Gem"] == nil then E["Red Moro'gai Gem"] = "Kırmızı Moro'gai Taşı" end
if E["Red Power Crystal"] == nil then E["Red Power Crystal"] = "Kırmızı Güç Kristali" end
if E["Red Punch Card"] == nil then E["Red Punch Card"] = "Kırmızı Delikli Kart" end
if E["Red Scepter Shard"] == nil then E["Red Scepter Shard"] = "Kırmızı Asa Parçası" end
if E["Red Silk Bandana"] == nil then E["Red Silk Bandana"] = "Kırmızı İpek Bandana" end
if E["Red Wool Bandana"] == nil then E["Red Wool Bandana"] = "Kırmızı Yün Bandana" end
if E["Redhorn Well Water"] == nil then E["Redhorn Well Water"] = "Redhorn Kuyu Suyu" end
if E["Redpath's Shield"] == nil then E["Redpath's Shield"] = "Redpath'in Kalkanı" end
if E["Reethe's Badge"] == nil then E["Reethe's Badge"] = "Reethe'in Rozeti" end
if E["Reins of the Frostsaber"] == nil then E["Reins of the Frostsaber"] = "Frostsaber Dizginleri" end
if E["Reins of the Nightsaber"] == nil then E["Reins of the Nightsaber"] = "Nightsaber Dizginleri" end
if E["Relic Bundle"] == nil then E["Relic Bundle"] = "Kalıntı Demeti" end
if E["Reliquary of Purity"] == nil then E["Reliquary of Purity"] = "Saflık Röliker Kutusu" end
if E["Remaining Drops of Purest Water"] == nil then E["Remaining Drops of Purest Water"] = "En Saf Suyun Kalan Damlaları" end
if E["Remains of Trey Lightforge"] == nil then E["Remains of Trey Lightforge"] = "Trey Lightforge'un Kalıntıları" end
if E["Remote Detonator (Blue)"] == nil then E["Remote Detonator (Blue)"] = "Uzaktan Fünye (Mavi)" end
if E["Remote Detonator (Red)"] == nil then E["Remote Detonator (Red)"] = "Uzaktan Fünye (Kırmızı)" end
if E["Renataki's Tooth"] == nil then E["Renataki's Tooth"] = "Renataki'nin Dişi" end
if E["Report on the Defias Brotherhood"] == nil then E["Report on the Defias Brotherhood"] = "Defias Kardeşliği Hakkında Rapor" end
if E["Research Equipment"] == nil then E["Research Equipment"] = "Araştırma Ekipmanı" end
if E["Resilience of the Scourge"] == nil then E["Resilience of the Scourge"] = "Scourge'un Direnci" end
if E["Resilient Sinew"] == nil then E["Resilient Sinew"] = "Dayanıklı Sinir" end
if E["Resonating Skull"] == nil then E["Resonating Skull"] = "Yankılanan Kafatası" end
if E["Resonite Crystal"] == nil then E["Resonite Crystal"] = "Resonit Kristali" end
if E["Restored Twilight Tablet"] == nil then E["Restored Twilight Tablet"] = "Onarılmış Twilight Tableti" end
if E["Rethban Ore"] == nil then E["Rethban Ore"] = "Rethban Cevheri" end
if E["Reward Voucher"] == nil then E["Reward Voucher"] = "Ödül Çeki" end
if E["Ribbly's Head"] == nil then E["Ribbly's Head"] = "Ribbly'nin Kafası" end
if E["Ridgewell's Crate"] == nil then E["Ridgewell's Crate"] = "Ridgewell'in Sandığı" end
if E["Rig Blueprints"] == nil then E["Rig Blueprints"] = "Teçhizat Planları" end
if E["Right Piece of Lord Valthalak's Amulet"] == nil then E["Right Piece of Lord Valthalak's Amulet"] = "Lord Valthalak'ın Muskasının Sağ Parçası" end
if E["Righteous Orb"] == nil then E["Righteous Orb"] = "Adil Küre" end
if E["Rin'ji's Secret"] == nil then E["Rin'ji's Secret"] = "Rin'ji'nin Sırrı" end
if E["Ring of Zoram"] == nil then E["Ring of Zoram"] = "Zoram Yüzüğü" end
if E["Ritual Salve"] == nil then E["Ritual Salve"] = "Ayin Merhemi" end
if E["Rituals of Power"] == nil then E["Rituals of Power"] = "Gücün Ayinleri" end
if E["Roast Raptor"] == nil then E["Roast Raptor"] = "Kızarmış Raptor" end
if E["Robes of Arcana"] == nil then E["Robes of Arcana"] = "Arkana Cübbesi" end
if E["Robo-mechanical Guts"] == nil then E["Robo-mechanical Guts"] = "Robomekanik Bağırsaklar" end
if E["Roc Gizzard"] == nil then E["Roc Gizzard"] = "Roc Taşlığı" end
if E["Rock Elemental Shard"] == nil then E["Rock Elemental Shard"] = "Kaya Elementali Parçası" end
if E["Rock Stalker Fang"] == nil then E["Rock Stalker Fang"] = "Kaya Avcısı Dişi" end
if E["Rocket Car Parts"] == nil then E["Rocket Car Parts"] = "Roket Araba Parçaları" end
if E["Rod of Channeling"] == nil then E["Rod of Channeling"] = "Kanalize Etme Asası" end
if E["Rod of Helcular"] == nil then E["Rod of Helcular"] = "Helcular'ın Asası" end
if E["Rod of Order"] == nil then E["Rod of Order"] = "Düzen Asası" end
if E["Rohan's Exorcism Censer"] == nil then E["Rohan's Exorcism Censer"] = "Rohan'ın Şeytan Kovma Buhurdanı" end
if E["Roland's Mana Gem"] == nil then E["Roland's Mana Gem"] = "Roland'ın Mana Taşı" end
if E["Roon's Kodo Horn"] == nil then E["Roon's Kodo Horn"] = "Roon'un Kodo Boynuzu" end
if E["Root Sample"] == nil then E["Root Sample"] = "Kök Örneği" end
if E["Rot Blossom"] == nil then E["Rot Blossom"] = "Çürük Çiçeği" end
if E["Rotten Apple"] == nil then E["Rotten Apple"] = "Çürük Elma" end
if E["Rotten Eggs"] == nil then E["Rotten Eggs"] = "Çürük Yumurtalar" end
if E["Rotting Flesh"] == nil then E["Rotting Flesh"] = "Çürüyen Et" end
if E["Rotting Wood"] == nil then E["Rotting Wood"] = "Çürüyen Odun" end
if E["Rough Quartz"] == nil then E["Rough Quartz"] = "Ham Kuvars" end
if E["Rubbing: Rune of Beth'Amara"] == nil then E["Rubbing: Rune of Beth'Amara"] = "Kopya: Beth'Amara Rünü" end
if E["Rubbing: Rune of Jin'yael"] == nil then E["Rubbing: Rune of Jin'yael"] = "Kopya: Jin'yael Rünü" end
if E["Rubbing: Rune of Markri"] == nil then E["Rubbing: Rune of Markri"] = "Kopya: Markri Rünü" end
if E["Rubbing: Rune of Sael'hai"] == nil then E["Rubbing: Rune of Sael'hai"] = "Kopya: Sael'hai Rünü" end
if E["Rugged Armor Kit"] == nil then E["Rugged Armor Kit"] = "Sağlam Zırh Takımı" end
if E["Rugged Leather"] == nil then E["Rugged Leather"] = "Sağlam Deri" end
if E["Ruined Tome"] == nil then E["Ruined Tome"] = "Harap Cilt" end
if E["Rune Thread"] == nil then E["Rune Thread"] = "Rün İpliği" end
if E["Rune of Escape"] == nil then E["Rune of Escape"] = "Kaçış Rünü" end
if E["Rune of Opening"] == nil then E["Rune of Opening"] = "Açılış Rünü" end
if E["Rune of Recall"] == nil then E["Rune of Recall"] = "Geri Çağırma Rünü" end
if E["Rune-Inscribed Note"] == nil then E["Rune-Inscribed Note"] = "Rün Yazılı Not" end
if E["Rune-Inscribed Parchment"] == nil then E["Rune-Inscribed Parchment"] = "Rün Yazılı Parşömen" end
if E["Rune-Inscribed Tablet"] == nil then E["Rune-Inscribed Tablet"] = "Rün Yazılı Tablet" end
if E["Runecloth"] == nil then E["Runecloth"] = "Rün Kumaşı" end
if E["Runecloth Bag"] == nil then E["Runecloth Bag"] = "Rün Kumaşı Çanta" end
if E["Runecloth Bandage"] == nil then E["Runecloth Bandage"] = "Rün Kumaşı Sargı" end
if E["Runecloth Boots"] == nil then E["Runecloth Boots"] = "Rün Kumaşı Çizmeler" end
if E["Runecloth Robe"] == nil then E["Runecloth Robe"] = "Rün Kumaşı Cübbe" end
if E["Runed Copper Belt"] == nil then E["Runed Copper Belt"] = "Rünlü Bakır Kemer" end
if E["Runed Scroll"] == nil then E["Runed Scroll"] = "Rünlü Parşömen" end
if E["Runes of Summoning"] == nil then E["Runes of Summoning"] = "Çağırma Rünleri" end
if E["Runic Leather Pants"] == nil then E["Runic Leather Pants"] = "Rünik Deri Pantolon" end
if E["Rusted Iron Key"] == nil then E["Rusted Iron Key"] = "Paslı Demir Anahtar" end
if E["Ryedol's Lucky Pick"] == nil then E["Ryedol's Lucky Pick"] = "Ryedol'ün Şanslı Kazması" end
if E["Ryson's Beacon"] == nil then E["Ryson's Beacon"] = "Ryson'ın İşaret Feneri" end
if E["SI:7 Insignia (Fredo)"] == nil then E["SI:7 Insignia (Fredo)"] = "SI:7 Nişanı (Fredo)" end
if E["SI:7 Insignia (Rutger)"] == nil then E["SI:7 Insignia (Rutger)"] = "SI:7 Nişanı (Rutger)" end
if E["SI:7 Insignia (Turyen)"] == nil then E["SI:7 Insignia (Turyen)"] = "SI:7 Nişanı (Turyen)" end
if E["Sack of Barley"] == nil then E["Sack of Barley"] = "Bir Çuval Arpa" end
if E["Sack of Corn"] == nil then E["Sack of Corn"] = "Bir Çuval Mısır" end
if E["Sack of Murloc Heads"] == nil then E["Sack of Murloc Heads"] = "Bir Çuval Murloc Kafası" end
if E["Sack of Rye"] == nil then E["Sack of Rye"] = "Bir Çuval Çavdar" end
if E["Sacred Cord"] == nil then E["Sacred Cord"] = "Kutsal Kordon" end
if E["Sacred Frostsaber Meat"] == nil then E["Sacred Frostsaber Meat"] = "Kutsal Frostsaber Eti" end
if E["Sacred Highborne Writings"] == nil then E["Sacred Highborne Writings"] = "Kutsal Highborne Yazıtları" end
if E["Sacred Mallet"] == nil then E["Sacred Mallet"] = "Kutsal Tokmak" end
if E["Salty Scorpid Venom"] == nil then E["Salty Scorpid Venom"] = "Tuzlu Scorpid Zehri" end
if E["Samha Essence"] == nil then E["Samha Essence"] = "Samha Özü" end
if E["Samophlange Manual"] == nil then E["Samophlange Manual"] = "Samophlange Kılavuzu" end
if E["Samophlange Manual Cover"] == nil then E["Samophlange Manual Cover"] = "Samophlange Kılavuzu Kapağı" end
if E["Samophlange Manual Page"] == nil then E["Samophlange Manual Page"] = "Samophlange Kılavuzu Sayfası" end
if E["Sample Elven Gem"] == nil then E["Sample Elven Gem"] = "Örnek Elf Mücevheri" end
if E["Sample Snapjaw Shell"] == nil then E["Sample Snapjaw Shell"] = "Örnek Snapjaw Kabuğu" end
if E["Sample of Indurium Ore"] == nil then E["Sample of Indurium Ore"] = "Indurium Cevheri Örneği" end
if E["Sample of Zanzil's Altered Mixture"] == nil then E["Sample of Zanzil's Altered Mixture"] = "Zanzil'in Değiştirilmiş Karışımından Örnek" end
if E["Samuel's Remains"] == nil then E["Samuel's Remains"] = "Samuel'in Kalıntıları" end
if E["Sand Skitterer Fang"] == nil then E["Sand Skitterer Fang"] = "Kum Koşucusu Dişi" end
if E["Sandfury Coin"] == nil then E["Sandfury Coin"] = "Sandfury Sikkesi" end
if E["Sapphire of Aku'Mai"] == nil then E["Sapphire of Aku'Mai"] = "Aku'Mai Safiri" end
if E["Sar'theris Striker"] == nil then E["Sar'theris Striker"] = "Sar'theris Vurucusu" end
if E["Sara Balloo's Plea"] == nil then E["Sara Balloo's Plea"] = "Sara Balloo'nun Yakarışı" end
if E["Sarah's Ring"] == nil then E["Sarah's Ring"] = "Sarah'nın Yüzüğü" end
if E["Sarilus Foulborne's Head"] == nil then E["Sarilus Foulborne's Head"] = "Sarilus Foulborne'un Kafası" end
if E["Sarltooth's Talon"] == nil then E["Sarltooth's Talon"] = "Sarltooth'un Pençesi" end
if E["Sathrah's Sacrifice"] == nil then E["Sathrah's Sacrifice"] = "Sathrah'nın Kurbanı" end
if E["Satyr Blood"] == nil then E["Satyr Blood"] = "Satir Kanı" end
if E["Satyr Horns"] == nil then E["Satyr Horns"] = "Satir Boynuzları" end
if E["Savage Coast Blue Sailfin"] == nil then E["Savage Coast Blue Sailfin"] = "Savage Coast Mavi Yelken Balığı" end
if E["Savage Frond"] == nil then E["Savage Frond"] = "Vahşi Yaprak" end
if E["Savannah Lion Tusk"] == nil then E["Savannah Lion Tusk"] = "Savan Aslanı Dişi" end
if E["Sawtooth Snapper Claw"] == nil then E["Sawtooth Snapper Claw"] = "Testere Dişli Kıskaç" end
if E["Sayge's Fortune #23"] == nil then E["Sayge's Fortune #23"] = "Sayge'in Falı #23" end
if E["Sayge's Fortune #24"] == nil then E["Sayge's Fortune #24"] = "Sayge'in Falı #24" end
if E["Sayge's Fortune #25"] == nil then E["Sayge's Fortune #25"] = "Sayge'in Falı #25" end
if E["Sayge's Fortune #27"] == nil then E["Sayge's Fortune #27"] = "Sayge'in Falı #27" end
if E["Scaber Stalk"] == nil then E["Scaber Stalk"] = "Scaber Sapı" end
if E["Scale of Old Murk-Eye"] == nil then E["Scale of Old Murk-Eye"] = "Yaşlı Murk-Eye'ın Pulu" end
if E["Scepter of Celebras"] == nil then E["Scepter of Celebras"] = "Celebras'ın Asası" end
if E["Scepter of Vectus"] == nil then E["Scepter of Vectus"] = "Vectus'un Asası" end
if E["Sceptre of Light"] == nil then E["Sceptre of Light"] = "Işık Asası" end
if E["Scorched Ectoplasm"] == nil then E["Scorched Ectoplasm"] = "Kavrulmuş Ektoplazma" end
if E["Scorched Spider Fang"] == nil then E["Scorched Spider Fang"] = "Kavrulmuş Örümcek Dişi" end
if E["Scorpashi Venom"] == nil then E["Scorpashi Venom"] = "Scorpashi Zehri" end
if E["Scorpok Pincer"] == nil then E["Scorpok Pincer"] = "Scorpok Kıskacı" end
if E["Scourge Banner"] == nil then E["Scourge Banner"] = "Scourge Sancağı" end
if E["Scourge Data"] == nil then E["Scourge Data"] = "Scourge Verileri" end
if E["Scrap Metal"] == nil then E["Scrap Metal"] = "Hurda Metal" end
if E["Scrap of Paper"] == nil then E["Scrap of Paper"] = "Kâğıt Parçası" end
if E["Scrawled Parchment"] == nil then E["Scrawled Parchment"] = "Karalanmış Parşömen" end
if E["Scrimshank's Surveying Gear"] == nil then E["Scrimshank's Surveying Gear"] = "Scrimshank'in Ölçüm Teçhizatı" end
if E["Scroll of Celebras"] == nil then E["Scroll of Celebras"] = "Celebras'ın Parşömeni" end
if E["Scroll of Messaging"] == nil then E["Scroll of Messaging"] = "Haberleşme Parşömeni" end
if E["Scroll of Myzrael"] == nil then E["Scroll of Myzrael"] = "Myzrael Parşömeni" end
if E["Scrying Scope"] == nil then E["Scrying Scope"] = "Kehanet Dürbünü" end
if E["Sea Creature Bones"] == nil then E["Sea Creature Bones"] = "Deniz Yaratığı Kemikleri" end
if E["Sea Turtle Remains"] == nil then E["Sea Turtle Remains"] = "Deniz Kaplumbağası Kalıntıları" end
if E["Seaforium Booster"] == nil then E["Seaforium Booster"] = "Seaforium Güçlendirici" end
if E["Seahorn's Sealed Letter"] == nil then E["Seahorn's Sealed Letter"] = "Seahorn'un Mühürlü Mektubu" end
if E["Seal of Ravenholdt"] == nil then E["Seal of Ravenholdt"] = "Ravenholdt Mührü" end
if E["Sealed Azure Bag"] == nil then E["Sealed Azure Bag"] = "Mühürlü Lacivert Çanta" end
if E["Sealed Blood Container"] == nil then E["Sealed Blood Container"] = "Mühürlü Kan Kabı" end
if E["Sealed Description of Thredd's Visitor"] == nil then E["Sealed Description of Thredd's Visitor"] = "Thredd'in Ziyaretçisinin Mühürlü Tarifi" end
if E["Sealed Envelope"] == nil then E["Sealed Envelope"] = "Mühürlü Zarf" end
if E["Sealed Folder"] == nil then E["Sealed Folder"] = "Mühürlü Dosya" end
if E["Sealed Letter to Ag'tor"] == nil then E["Sealed Letter to Ag'tor"] = "Ag'tor'a Mühürlü Mektup" end
if E["Sealed Letter to Archmage Malin"] == nil then E["Sealed Letter to Archmage Malin"] = "Başbüyücü Malin'e Mühürlü Mektup" end
if E["Sealed Letter to Balthule"] == nil then E["Sealed Letter to Balthule"] = "Balthule'a Mühürlü Mektup" end
if E["Sealed Letter to Elissa"] == nil then E["Sealed Letter to Elissa"] = "Elissa'ya Mühürlü Mektup" end
if E["Sealed Note to Advisor Belgrum"] == nil then E["Sealed Note to Advisor Belgrum"] = "Danışman Belgrum'a Mühürlü Not" end
if E["Sealed Note to Elling"] == nil then E["Sealed Note to Elling"] = "Elling'e Mühürlü Not" end
if E["Sealed Note to Watcher Backus"] == nil then E["Sealed Note to Watcher Backus"] = "Gözcü Backus'a Mühürlü Not" end
if E["Sealed Reliquary of Purity"] == nil then E["Sealed Reliquary of Purity"] = "Mühürlü Saflık Röliker Kutusu" end
if E["Sealed Research Report"] == nil then E["Sealed Research Report"] = "Mühürlü Araştırma Raporu" end
if E["Sealed Venom Container"] == nil then E["Sealed Venom Container"] = "Mühürlü Zehir Kabı" end
if E["Searing Coral"] == nil then E["Searing Coral"] = "Yakıcı Mercan" end
if E["Searing Heart"] == nil then E["Searing Heart"] = "Yakıcı Kalp" end
if E["Searing Tongue"] == nil then E["Searing Tongue"] = "Yakıcı Dil" end
if E["Searing Totem Scroll"] == nil then E["Searing Totem Scroll"] = "Yakıcı Totem Parşömeni" end
if E["Second Mosh'aru Tablet"] == nil then E["Second Mosh'aru Tablet"] = "İkinci Mosh'aru Tableti" end
if E["Second Relic Fragment"] == nil then E["Second Relic Fragment"] = "İkinci Kalıntı Parçası" end
if E["Secret Note #1"] == nil then E["Secret Note #1"] = "Gizli Not #1" end
if E["Secret Note #2"] == nil then E["Secret Note #2"] = "Gizli Not #2" end
if E["Secret Note #3"] == nil then E["Secret Note #3"] = "Gizli Not #3" end
if E["Secret Plans: Fiery Flux"] == nil then E["Secret Plans: Fiery Flux"] = "Gizli Planlar: Ateşli Eritken" end
if E["Seed Voucher"] == nil then E["Seed Voucher"] = "Tohum Çeki" end
if E["Seed of Life"] == nil then E["Seed of Life"] = "Hayat Tohumu" end
if E["Serena's Head"] == nil then E["Serena's Head"] = "Serena'nın Kafası" end
if E["Serpentbloom"] == nil then E["Serpentbloom"] = "Yılançiçeği" end
if E["Sethir's Journal"] == nil then E["Sethir's Journal"] = "Sethir'in Günlüğü" end
if E["Severed Horn of the Defiler"] == nil then E["Severed Horn of the Defiler"] = "Defiler'ın Kesik Boynuzu" end
if E["Severed Night Elf Head"] == nil then E["Severed Night Elf Head"] = "Kesik Gece Elfi Kafası" end
if E["Sha'ni's Nose-Ring"] == nil then E["Sha'ni's Nose-Ring"] = "Sha'ni'nin Burun Halkası" end
if E["Shackle Key"] == nil then E["Shackle Key"] = "Pranga Anahtarı" end
if E["Shadow Hunter Knife"] == nil then E["Shadow Hunter Knife"] = "Gölge Avcısı Bıçağı" end
if E["Shadow Lord Fel'dan's Head"] == nil then E["Shadow Lord Fel'dan's Head"] = "Gölge Lordu Fel'dan'ın Kafası" end
if E["Shadow Mantle of the Dawn"] == nil then E["Shadow Mantle of the Dawn"] = "Şafağın Gölge Pelerini" end
if E["Shadow Panther Heart"] == nil then E["Shadow Panther Heart"] = "Gölge Panteri Kalbi" end
if E["Shadowcraft Belt"] == nil then E["Shadowcraft Belt"] = "Shadowcraft Kemeri" end
if E["Shadowcraft Boots"] == nil then E["Shadowcraft Boots"] = "Shadowcraft Çizmeleri" end
if E["Shadowcraft Bracers"] == nil then E["Shadowcraft Bracers"] = "Shadowcraft Bileklikleri" end
if E["Shadowcraft Cap"] == nil then E["Shadowcraft Cap"] = "Shadowcraft Başlığı" end
if E["Shadowcraft Gloves"] == nil then E["Shadowcraft Gloves"] = "Shadowcraft Eldivenleri" end
if E["Shadowcraft Pants"] == nil then E["Shadowcraft Pants"] = "Shadowcraft Pantolonu" end
if E["Shadowcraft Spaulders"] == nil then E["Shadowcraft Spaulders"] = "Shadowcraft Omuzlukları" end
if E["Shadowcraft Tunic"] == nil then E["Shadowcraft Tunic"] = "Shadowcraft Tuniği" end
if E["Shadowhide Pendant"] == nil then E["Shadowhide Pendant"] = "Shadowhide Kolyesi" end
if E["Shadowmaw Claw"] == nil then E["Shadowmaw Claw"] = "Shadowmaw Pençesi" end
if E["Shadowshard Fragment"] == nil then E["Shadowshard Fragment"] = "Gölge Kırığı Parçası" end
if E["Shadowstalker Scalp"] == nil then E["Shadowstalker Scalp"] = "Gölge Avcısı Kafa Derisi" end
if E["Shadowy Potion"] == nil then E["Shadowy Potion"] = "Gölgeli İksir" end
if E["Shadowy Potion OLD"] == nil then E["Shadowy Potion OLD"] = "Gölgeli İksir ESKİ" end
if E["Shadra's Venom"] == nil then E["Shadra's Venom"] = "Shadra'nın Zehri" end
if E["Shadumbra's Head"] == nil then E["Shadumbra's Head"] = "Shadumbra'nın Kafası" end
if E["Shaky's Payment"] == nil then E["Shaky's Payment"] = "Shaky'nin Ödemesi" end
if E["Shard of Water"] == nil then E["Shard of Water"] = "Su Kırığı" end
if E["Shardtooth Meat"] == nil then E["Shardtooth Meat"] = "Shardtooth Eti" end
if E["Sharp Claw"] == nil then E["Sharp Claw"] = "Keskin Pençe" end
if E["Sharpbeak's Feather"] == nil then E["Sharpbeak's Feather"] = "Sharpbeak'in Tüyü" end
if E["Sharptalon's Claw"] == nil then E["Sharptalon's Claw"] = "Sharptalon'un Pençesi" end
if E["Shattered Necklace"] == nil then E["Shattered Necklace"] = "Parçalanmış Kolye" end
if E["Shattered Necklace Power Source"] == nil then E["Shattered Necklace Power Source"] = "Parçalanmış Kolye Güç Kaynağı" end
if E["Shattered Necklace Ruby"] == nil then E["Shattered Necklace Ruby"] = "Parçalanmış Kolye Yakutu" end
if E["Shattered Necklace Sapphire"] == nil then E["Shattered Necklace Sapphire"] = "Parçalanmış Kolye Safiri" end
if E["Shattered Necklace Topaz"] == nil then E["Shattered Necklace Topaz"] = "Parçalanmış Kolye Topazı" end
if E["Shattered Sword of Marduk"] == nil then E["Shattered Sword of Marduk"] = "Marduk'un Parçalanmış Kılıcı" end
if E["Shaw's Report"] == nil then E["Shaw's Report"] = "Shaw'ın Raporu" end
if E["Shay's Bell"] == nil then E["Shay's Bell"] = "Shay'in Çanı" end
if E["Sheathed Trol'kalar"] == nil then E["Sheathed Trol'kalar"] = "Kınındaki Trol'kalar" end
if E["Shellfish"] == nil then E["Shellfish"] = "Kabuklu Deniz Ürünü" end
if E["Shindrell's Note"] == nil then E["Shindrell's Note"] = "Shindrell'in Notu" end
if E["Ship Schedule"] == nil then E["Ship Schedule"] = "Gemi Tarifesi" end
if E["Shipment of Iron"] == nil then E["Shipment of Iron"] = "Demir Sevkiyatı" end
if E["Shipment to Galvan"] == nil then E["Shipment to Galvan"] = "Galvan'a Sevkiyat" end
if E["Shipment to Nethergarde"] == nil then E["Shipment to Nethergarde"] = "Nethergarde'a Sevkiyat" end
if E["Shredder Operating Manual - Chapter 1"] == nil then E["Shredder Operating Manual - Chapter 1"] = "Shredder Kullanım Kılavuzu - Bölüm 1" end
if E["Shredder Operating Manual - Chapter 2"] == nil then E["Shredder Operating Manual - Chapter 2"] = "Shredder Kullanım Kılavuzu - Bölüm 2" end
if E["Shredder Operating Manual - Chapter 3"] == nil then E["Shredder Operating Manual - Chapter 3"] = "Shredder Kullanım Kılavuzu - Bölüm 3" end
if E["Shrike Bat Fang"] == nil then E["Shrike Bat Fang"] = "Örümcekkuşu Yarasası Dişi" end
if E["Shrine Bauble"] == nil then E["Shrine Bauble"] = "Tapınak Süsü" end
if E["Shrunken Head"] == nil then E["Shrunken Head"] = "Büzülmüş Kafa" end
if E["Siabi's Premium Tobacco"] == nil then E["Siabi's Premium Tobacco"] = "Siabi'nin Seçkin Tütünü" end
if E["Sida's Bag"] == nil then E["Sida's Bag"] = "Sida'nın Çantası" end
if E["Sigil Fragment"] == nil then E["Sigil Fragment"] = "Mühür Parçası" end
if E["Sigil of Arathor"] == nil then E["Sigil of Arathor"] = "Arathor Mührü" end
if E["Sigil of Ignaeus"] == nil then E["Sigil of Ignaeus"] = "Ignaeus Mührü" end
if E["Sigil of Strom"] == nil then E["Sigil of Strom"] = "Strom Mührü" end
if E["Sigil of Thoradin"] == nil then E["Sigil of Thoradin"] = "Thoradin Mührü" end
if E["Sigil of Trollbane"] == nil then E["Sigil of Trollbane"] = "Trollbane Mührü" end
if E["Sigil of the Hammer"] == nil then E["Sigil of the Hammer"] = "Çekiç Mührü" end
if E["Sign of the Earth"] == nil then E["Sign of the Earth"] = "Toprağın İşareti" end
if E["Signed Field Duty Papers"] == nil then E["Signed Field Duty Papers"] = "İmzalı Saha Görevi Belgeleri" end
if E["Signet Ring of the Bronze Dragonflight"] == nil then E["Signet Ring of the Bronze Dragonflight"] = "Bronz Ejderha Soyu Mühür Yüzüğü" end
if E["Signet of Expertise"] == nil then E["Signet of Expertise"] = "Uzmanlık Mührü" end
if E["Silithid Carapace Fragment"] == nil then E["Silithid Carapace Fragment"] = "Silithid Kabuğu Parçası" end
if E["Silithid Egg"] == nil then E["Silithid Egg"] = "Silithid Yumurtası" end
if E["Silithid Goo"] == nil then E["Silithid Goo"] = "Silithid Balçığı" end
if E["Silithid Heart"] == nil then E["Silithid Heart"] = "Silithid Kalbi" end
if E["Silithid Talon"] == nil then E["Silithid Talon"] = "Silithid Pençesi" end
if E["Silithus Venom Sample"] == nil then E["Silithus Venom Sample"] = "Silithus Zehir Örneği" end
if E["Silixiz's Tower Key"] == nil then E["Silixiz's Tower Key"] = "Silixiz'in Kule Anahtarı" end
if E["Silk Bandage"] == nil then E["Silk Bandage"] = "İpek Sargı" end
if E["Silk Cloth"] == nil then E["Silk Cloth"] = "İpek Kumaş" end
if E["Silver Bar"] == nil then E["Silver Bar"] = "Gümüş Külçe" end
if E["Silver Dawning's Lockbox"] == nil then E["Silver Dawning's Lockbox"] = "Silver Dawning'in Kilitli Kutusu" end
if E["Silver Hakkari Bijou"] == nil then E["Silver Hakkari Bijou"] = "Gümüş Hakkari Mücevheri" end
if E["Silver Scarab"] == nil then E["Silver Scarab"] = "Gümüş Skarabe" end
if E["Silver Totem of Aquementas"] == nil then E["Silver Totem of Aquementas"] = "Aquementas'ın Gümüş Totemi" end
if E["Silvered Bronze Boots"] == nil then E["Silvered Bronze Boots"] = "Gümüş Kaplama Bronz Çizmeler" end
if E["Silvered Bronze Gauntlets"] == nil then E["Silvered Bronze Gauntlets"] = "Gümüş Kaplama Bronz Eldivenler" end
if E["Silvermane Stalker Flank"] == nil then E["Silvermane Stalker Flank"] = "Silvermane Avcısı Böğrü" end
if E["Silverwing Talisman of Merit"] == nil then E["Silverwing Talisman of Merit"] = "Silverwing Liyakat Tılsımı" end
if E["Silvery Claws"] == nil then E["Silvery Claws"] = "Gümüşi Pençeler" end
if E["Silvery Spinnerets"] == nil then E["Silvery Spinnerets"] = "Gümüşi Ağ Bezleri" end
if E["Simone's Head"] == nil then E["Simone's Head"] = "Simone'un Kafası" end
if E["Simple Letter"] == nil then E["Simple Letter"] = "Sade Mektup" end
if E["Simple Memorandum"] == nil then E["Simple Memorandum"] = "Sade Muhtıra" end
if E["Simple Note"] == nil then E["Simple Note"] = "Sade Not" end
if E["Simple Parchment"] == nil then E["Simple Parchment"] = "Sade Parşömen" end
if E["Simple Rune"] == nil then E["Simple Rune"] = "Sade Rün" end
if E["Simple Scroll"] == nil then E["Simple Scroll"] = "Sade Tomar" end
if E["Simple Sigil"] == nil then E["Simple Sigil"] = "Sade Mühür" end
if E["Simple Tablet"] == nil then E["Simple Tablet"] = "Sade Tablet" end
if E["Simple Wildflowers"] == nil then E["Simple Wildflowers"] = "Sade Kır Çiçekleri" end
if E["Singed Letter"] == nil then E["Singed Letter"] = "Kavrulmuş Mektup" end
if E["Singed Scale"] == nil then E["Singed Scale"] = "Kavrulmuş Pul" end
if E["Singed Scroll Fragment"] == nil then E["Singed Scroll Fragment"] = "Kavrulmuş Tomar Parçası" end
if E["Singing Blue Crystal"] == nil then E["Singing Blue Crystal"] = "Şarkı Söyleyen Mavi Kristal" end
if E["Singing Crystal Shard"] == nil then E["Singing Crystal Shard"] = "Şarkı Söyleyen Kristal Kırığı" end
if E["Sixth Mosh'aru Tablet"] == nil then E["Sixth Mosh'aru Tablet"] = "Altıncı Mosh'aru Tableti" end
if E["Skeletal Fragments"] == nil then E["Skeletal Fragments"] = "İskelet Parçaları" end
if E["Skeleton Finger"] == nil then E["Skeleton Finger"] = "İskelet Parmağı" end
if E["Skeleton Key Mold"] == nil then E["Skeleton Key Mold"] = "Maymuncuk Kalıbı" end
if E["Skin of Shadow"] == nil then E["Skin of Shadow"] = "Gölge Derisi" end
if E["Skin of Sweet Rum"] == nil then E["Skin of Sweet Rum"] = "Bir Tulum Tatlı Rom" end
if E["Skin of the Great Sandworm"] == nil then E["Skin of the Great Sandworm"] = "Büyük Kum Solucanının Derisi" end
if E["Skull of Horgus"] == nil then E["Skull of Horgus"] = "Horgus'un Kafatası" end
if E["Skull of Korrak"] == nil then E["Skull of Korrak"] = "Korrak'ın Kafatası" end
if E["Skull of the Coldbringer"] == nil then E["Skull of the Coldbringer"] = "Soğukgetiren'in Kafatası" end
if E["Skullsplitter Coin"] == nil then E["Skullsplitter Coin"] = "Skullsplitter Sikkesi" end
if E["Skullsplitter Fetish"] == nil then E["Skullsplitter Fetish"] = "Skullsplitter Fetişi" end
if E["Skullsplitter Tusk"] == nil then E["Skullsplitter Tusk"] = "Skullsplitter Fildişi" end
if E["Skylord Plume"] == nil then E["Skylord Plume"] = "Gök Lordu Tüyü" end
if E["Slab of Carrion Worm Meat"] == nil then E["Slab of Carrion Worm Meat"] = "Bir Dilim Leş Solucanı Eti" end
if E["Slagtree's Lost Tools"] == nil then E["Slagtree's Lost Tools"] = "Slagtree'nin Kayıp Aletleri" end
if E["Sleepers' Key"] == nil then E["Sleepers' Key"] = "Uyuyanların Anahtarı" end
if E["Slidore's Beacon"] == nil then E["Slidore's Beacon"] = "Slidore'un İşaret Feneri" end
if E["Slightly Creased Note"] == nil then E["Slightly Creased Note"] = "Hafif Buruşuk Not" end
if E["Small Brass Key"] == nil then E["Small Brass Key"] = "Küçük Pirinç Anahtar" end
if E["Small Furry Paw"] == nil then E["Small Furry Paw"] = "Küçük Tüylü Pati" end
if E["Small Scroll"] == nil then E["Small Scroll"] = "Küçük Tomar" end
if E["Small Spider Leg"] == nil then E["Small Spider Leg"] = "Küçük Örümcek Bacağı" end
if E["Small Stone Shard"] == nil then E["Small Stone Shard"] = "Küçük Taş Kırığı" end
if E["Smithing Tuyere"] == nil then E["Smithing Tuyere"] = "Demirci Körük Borusu" end
if E["Smoked Desert Dumplings"] == nil then E["Smoked Desert Dumplings"] = "Tütsülenmiş Çöl Mantısı" end
if E["Smokey's Special Compound"] == nil then E["Smokey's Special Compound"] = "Smokey'nin Özel Karışımı" end
if E["Smoky Iron Ingot"] == nil then E["Smoky Iron Ingot"] = "İsli Demir Külçe" end
if E["Smokywood Satchel"] == nil then E["Smokywood Satchel"] = "Smokywood Heybesi" end
if E["Smokywood Supplies"] == nil then E["Smokywood Supplies"] = "Smokywood Malzemeleri" end
if E["Smoldering Coal"] == nil then E["Smoldering Coal"] = "İçin İçin Yanan Kömür" end
if E["Smoldering Embers"] == nil then E["Smoldering Embers"] = "İçin İçin Yanan Közler" end
if E["Smotts' Chest"] == nil then E["Smotts' Chest"] = "Smotts'un Sandığı" end
if E["Smotts' Cutlass"] == nil then E["Smotts' Cutlass"] = "Smotts'un Palası" end
if E["Snapjaw Crocolisk Skin"] == nil then E["Snapjaw Crocolisk Skin"] = "Snapjaw Krokolisk Derisi" end
if E["Snapshot of Gammerita"] == nil then E["Snapshot of Gammerita"] = "Gammerita'nın Fotoğrafı" end
if E["Snellig's Snuffbox"] == nil then E["Snellig's Snuffbox"] = "Snellig'in Enfiye Kutusu" end
if E["Snickerfang Jowl"] == nil then E["Snickerfang Jowl"] = "Snickerfang Gerdanı" end
if E["Snuff"] == nil then E["Snuff"] = "Enfiye" end
if E["Snufflenose Command Stick"] == nil then E["Snufflenose Command Stick"] = "Snufflenose Komuta Çubuğu" end
if E["Snufflenose Owner's Manual"] == nil then E["Snufflenose Owner's Manual"] = "Snufflenose Kullanım Kılavuzu" end
if E["Sodium Nitrate"] == nil then E["Sodium Nitrate"] = "Sodyum Nitrat" end
if E["Soft Bushy Tail"] == nil then E["Soft Bushy Tail"] = "Yumuşak Gür Kuyruk" end
if E["Soft-shelled Clam"] == nil then E["Soft-shelled Clam"] = "Yumuşak Kabuklu Midye" end
if E["Soft-shelled Clam Meat"] == nil then E["Soft-shelled Clam Meat"] = "Yumuşak Kabuklu Midye Eti" end
if E["Solenor's Head"] == nil then E["Solenor's Head"] = "Solenor'un Kafası" end
if E["Solid Crystal Leg Shaft"] == nil then E["Solid Crystal Leg Shaft"] = "Som Kristal Bacak Şaftı" end
if E["Solid Dynamite"] == nil then E["Solid Dynamite"] = "Sağlam Dinamit" end
if E["Solid Grinding Stone"] == nil then E["Solid Grinding Stone"] = "Sağlam Bileği Taşı" end
if E["Solid Iron Maul"] == nil then E["Solid Iron Maul"] = "Sağlam Demir Gürz" end
if E["Solomon's Plea to Bolvar"] == nil then E["Solomon's Plea to Bolvar"] = "Solomon'un Bolvar'a Yakarışı" end
if E["Solomon's Plea to Darkshire"] == nil then E["Solomon's Plea to Darkshire"] = "Solomon'un Darkshire'a Yakarışı" end
if E["Solomon's Plea to Westfall"] == nil then E["Solomon's Plea to Westfall"] = "Solomon'un Westfall'a Yakarışı" end
if E["Somatic Intensifier"] == nil then E["Somatic Intensifier"] = "Somatik Yoğunlaştırıcı" end
if E["Some Rune"] == nil then E["Some Rune"] = "Bir Rün" end
if E["Soothing Spices"] == nil then E["Soothing Spices"] = "Yatıştırıcı Baharatlar" end
if E["Sooty Parchment"] == nil then E["Sooty Parchment"] = "İsli Parşömen" end
if E["Soran'ruk Fragment"] == nil then E["Soran'ruk Fragment"] = "Soran'ruk Parçası" end
if E["Soul Ashes of the Banished"] == nil then E["Soul Ashes of the Banished"] = "Sürgünlerin Ruh Külleri" end
if E["Soul Gem"] == nil then E["Soul Gem"] = "Ruh Taşı" end
if E["Soul Shard"] == nil then E["Soul Shard"] = "Ruh Kırığı" end
if E["Soul Stained Pike"] == nil then E["Soul Stained Pike"] = "Ruh Lekeli Mızrak" end
if E["Soulbound Keepsake"] == nil then E["Soulbound Keepsake"] = "Ruha Bağlı Hatıra" end
if E["Southsea Pirate Hat"] == nil then E["Southsea Pirate Hat"] = "Southsea Korsan Şapkası" end
if E["Southsea Treasure"] == nil then E["Southsea Treasure"] = "Southsea Hazinesi" end
if E["Southshore Stout"] == nil then E["Southshore Stout"] = "Southshore Birası" end
if E["Spaulders of Valor"] == nil then E["Spaulders of Valor"] = "Yiğitlik Omuzlukları" end
if E["Special Chicken Feed"] == nil then E["Special Chicken Feed"] = "Özel Tavuk Yemi" end
if E["Speck of Dream Dust"] == nil then E["Speck of Dream Dust"] = "Bir Zerre Rüya Tozu" end
if E["Speckled Tastyfish"] == nil then E["Speckled Tastyfish"] = "Benekli Lezzetli Balık" end
if E["Spectral Comb"] == nil then E["Spectral Comb"] = "Hayalet Tarak" end
if E["Spells of Shadow"] == nil then E["Spells of Shadow"] = "Gölge Büyüleri" end
if E["Spider Ichor"] == nil then E["Spider Ichor"] = "Örümcek İrini" end
if E["Spire Spider Egg"] == nil then E["Spire Spider Egg"] = "Spire Örümceği Yumurtası" end
if E["Spirit of Silverpine Charts"] == nil then E["Spirit of Silverpine Charts"] = "Spirit of Silverpine Haritaları" end
if E["Spirit of Silverpine Log"] == nil then E["Spirit of Silverpine Log"] = "Spirit of Silverpine Seyir Defteri" end
if E["Splinter of Nordrassil"] == nil then E["Splinter of Nordrassil"] = "Nordrassil Kıymığı" end
if E["Splintered Log"] == nil then E["Splintered Log"] = "Kıymık Kıymık Kütük" end
if E["Split Bone Necklace"] == nil then E["Split Bone Necklace"] = "Yarık Kemik Kolye" end
if E["Spool of Light Chartreuse Silk Thread"] == nil then E["Spool of Light Chartreuse Silk Thread"] = "Bir Makara Açık Fıstık Yeşili İpek İplik" end
if E["Spotted Hyena Pelt"] == nil then E["Spotted Hyena Pelt"] = "Benekli Sırtlan Postu" end
if E["Spotted Sunfish"] == nil then E["Spotted Sunfish"] = "Benekli Güneş Balığı" end
if E["Spotted Yellowtail"] == nil then E["Spotted Yellowtail"] = "Benekli Sarıkuyruk" end
if E["Spraggle's Canteen"] == nil then E["Spraggle's Canteen"] = "Spraggle'ın Matarası" end
if E["Spy's Report"] == nil then E["Spy's Report"] = "Casus Raporu" end
if E["Squirrel Token"] == nil then E["Squirrel Token"] = "Sincap Jetonu" end
if E["Stable Ectoplasm"] == nil then E["Stable Ectoplasm"] = "Kararlı Ektoplazma" end
if E["Staff Head of Atiesh"] == nil then E["Staff Head of Atiesh"] = "Atiesh Asa Başlığı" end
if E["Staff of Command"] == nil then E["Staff of Command"] = "Komuta Asası" end
if E["Staff of Prehistoria"] == nil then E["Staff of Prehistoria"] = "Prehistoria Asası" end
if E["Standard Issue Flare Gun"] == nil then E["Standard Issue Flare Gun"] = "Standart Tip İşaret Fişeği Tabancası" end
if E["Star Ruby"] == nil then E["Star Ruby"] = "Yıldız Yakutu" end
if E["Star of Xil'yeh"] == nil then E["Star of Xil'yeh"] = "Xil'yeh Yıldızı" end
if E["Starbreeze Village Relic"] == nil then E["Starbreeze Village Relic"] = "Starbreeze Köyü Kalıntısı" end
if E["Stave of Equinex"] == nil then E["Stave of Equinex"] = "Equinex Asası" end
if E["Steamsaw"] == nil then E["Steamsaw"] = "Buharlı Testere" end
if E["Steel Breastplate"] == nil then E["Steel Breastplate"] = "Çelik Göğüslük" end
if E["Steel Plate Helm"] == nil then E["Steel Plate Helm"] = "Çelik Plaka Miğfer" end
if E["Steelsnap's Rib"] == nil then E["Steelsnap's Rib"] = "Steelsnap'in Kaburgası" end
if E["Stinglasher's Glands"] == nil then E["Stinglasher's Glands"] = "Stinglasher'ın Bezleri" end
if E["Stink Bomb Cleaner"] == nil then E["Stink Bomb Cleaner"] = "Kokarca Bombası Temizleyici" end
if E["Stolen Treats"] == nil then E["Stolen Treats"] = "Çalınmış İkramlar" end
if E["Stoley's Bottle"] == nil then E["Stoley's Bottle"] = "Stoley'nin Şişesi" end
if E["Stoley's Shipment"] == nil then E["Stoley's Shipment"] = "Stoley'nin Sevkiyatı" end
if E["Stone Circle"] == nil then E["Stone Circle"] = "Taş Çember" end
if E["Stone Scarab"] == nil then E["Stone Scarab"] = "Taş Skarabe" end
if E["Stone of Relu"] == nil then E["Stone of Relu"] = "Relu Taşı" end
if E["Stone of the Tides"] == nil then E["Stone of the Tides"] = "Gelgitlerin Taşı" end
if E["Stonelash Flayer Stinger"] == nil then E["Stonelash Flayer Stinger"] = "Stonelash Yüzücü İğnesi" end
if E["Stonelash Pincer Stinger"] == nil then E["Stonelash Pincer Stinger"] = "Stonelash Kıskaçlı İğnesi" end
if E["Stonelash Scorpid Stinger"] == nil then E["Stonelash Scorpid Stinger"] = "Stonelash Akrep İğnesi" end
if E["Stonescale Eel"] == nil then E["Stonescale Eel"] = "Taşpul Yılanbalığı" end
if E["Stonescale Oil"] == nil then E["Stonescale Oil"] = "Taşpul Yağı" end
if E["Stoneskin Totem Scroll"] == nil then E["Stoneskin Totem Scroll"] = "Taş Deri Totemi Tomarı" end
if E["Stonetalon Sap"] == nil then E["Stonetalon Sap"] = "Stonetalon Özsuyu" end
if E["Storm Crystal"] == nil then E["Storm Crystal"] = "Fırtına Kristali" end
if E["Stormbull Well Water"] == nil then E["Stormbull Well Water"] = "Stormbull Kuyusu Suyu" end
if E["Stormpike Assault Orders"] == nil then E["Stormpike Assault Orders"] = "Stormpike Saldırı Emirleri" end
if E["Stormpike Banner"] == nil then E["Stormpike Banner"] = "Stormpike Sancağı" end
if E["Stormpike Battle Plans"] == nil then E["Stormpike Battle Plans"] = "Stormpike Savaş Planları" end
if E["Stormpike Commander's Flesh"] == nil then E["Stormpike Commander's Flesh"] = "Stormpike Komutanının Eti" end
if E["Stormpike Insignia Rank 1"] == nil then E["Stormpike Insignia Rank 1"] = "Stormpike Nişanı Rütbe 1" end
if E["Stormpike Insignia Rank 2"] == nil then E["Stormpike Insignia Rank 2"] = "Stormpike Nişanı Rütbe 2" end
if E["Stormpike Insignia Rank 3"] == nil then E["Stormpike Insignia Rank 3"] = "Stormpike Nişanı Rütbe 3" end
if E["Stormpike Insignia Rank 4"] == nil then E["Stormpike Insignia Rank 4"] = "Stormpike Nişanı Rütbe 4" end
if E["Stormpike Insignia Rank 5"] == nil then E["Stormpike Insignia Rank 5"] = "Stormpike Nişanı Rütbe 5" end
if E["Stormpike Lieutenant's Flesh"] == nil then E["Stormpike Lieutenant's Flesh"] = "Stormpike Teğmeninin Eti" end
if E["Stormpike Soldier's Blood"] == nil then E["Stormpike Soldier's Blood"] = "Stormpike Askerinin Kanı" end
if E["Stormpike Soldier's Flesh"] == nil then E["Stormpike Soldier's Flesh"] = "Stormpike Askerinin Eti" end
if E["Stormpike Training Collar"] == nil then E["Stormpike Training Collar"] = "Stormpike Eğitim Tasması" end
if E["Stormpike's Request"] == nil then E["Stormpike's Request"] = "Stormpike'ın Talebi" end
if E["Stormwind Deputy Kit"] == nil then E["Stormwind Deputy Kit"] = "Stormwind Yardımcı Muhafız Takımı" end
if E["Stormwind Guard's Card"] == nil then E["Stormwind Guard's Card"] = "Stormwind Muhafız Kartı" end
if E["Stormwind Nougat"] == nil then E["Stormwind Nougat"] = "Stormwind Nugası" end
if E["Stormwind Seasoning Herbs"] == nil then E["Stormwind Seasoning Herbs"] = "Stormwind Baharat Otları" end
if E["Stoutmantle's Response to Solomon"] == nil then E["Stoutmantle's Response to Solomon"] = "Stoutmantle'ın Solomon'a Yanıtı" end
if E["Strange Smelling Powder"] == nil then E["Strange Smelling Powder"] = "Tuhaf Kokulu Toz" end
if E["Strange Water Globe"] == nil then E["Strange Water Globe"] = "Tuhaf Su Küresi" end
if E["Strangely Marked Box"] == nil then E["Strangely Marked Box"] = "Tuhaf İşaretli Kutu" end
if E["Stranglekelp"] == nil then E["Stranglekelp"] = "Boğan Yosun" end
if E["Stratholme Courier's Pouch"] == nil then E["Stratholme Courier's Pouch"] = "Stratholme Kuryesinin Kesesi" end
if E["Stratholme Holy Water"] == nil then E["Stratholme Holy Water"] = "Stratholme Kutsal Suyu" end
if E["Strength of Mugamba"] == nil then E["Strength of Mugamba"] = "Mugamba'nın Gücü" end
if E["Strider Meat"] == nil then E["Strider Meat"] = "Strider Eti" end
if E["Stringy Vulture Meat"] == nil then E["Stringy Vulture Meat"] = "Lifli Akbaba Eti" end
if E["Stromgarde Badge"] == nil then E["Stromgarde Badge"] = "Stromgarde Rozeti" end
if E["Strong Flux"] == nil then E["Strong Flux"] = "Güçlü Eritken" end
if E["Strong Troll's Blood Potion"] == nil then E["Strong Troll's Blood Potion"] = "Güçlü Trol Kanı İksiri" end
if E["Studies in Spirit Speaking"] == nil then E["Studies in Spirit Speaking"] = "Ruhlarla Konuşma Üzerine İncelemeler" end
if E["Sturdy Dragonmaw Shinbone"] == nil then E["Sturdy Dragonmaw Shinbone"] = "Sağlam Dragonmaw İncik Kemiği" end
if E["Succubus Summoning Scroll"] == nil then E["Succubus Summoning Scroll"] = "Succubus Çağırma Tomarı" end
if E["Sulfuron Ingot"] == nil then E["Sulfuron Ingot"] = "Sulfuron Külçesi" end
if E["Sully Balloo's Letter"] == nil then E["Sully Balloo's Letter"] = "Sully Balloo'nun Mektubu" end
if E["Sundried Driftwood"] == nil then E["Sundried Driftwood"] = "Güneşte Kurumuş Dalgaodunu" end
if E["Sunscale Feather"] == nil then E["Sunscale Feather"] = "Sunscale Tüyü" end
if E["Sunscorched Shell"] == nil then E["Sunscorched Shell"] = "Güneşte Kavrulmuş Kabuk" end
if E["Super Reaper 6000 Blueprints"] == nil then E["Super Reaper 6000 Blueprints"] = "Süper Biçer 6000 Planları" end
if E["Super Sticky Tar"] == nil then E["Super Sticky Tar"] = "Süper Yapışkan Katran" end
if E["Supplies for Sven"] == nil then E["Supplies for Sven"] = "Sven İçin Erzak" end
if E["Supply Crate"] == nil then E["Supply Crate"] = "Erzak Sandığı" end
if E["Surena's Choker"] == nil then E["Surena's Choker"] = "Surena'nın Gerdanlığı" end
if E["Sweet Nectar"] == nil then E["Sweet Nectar"] = "Tatlı Nektar" end
if E["Symbol of Life"] == nil then E["Symbol of Life"] = "Yaşam Sembolü" end
if E["Symbol of Lost Honor"] == nil then E["Symbol of Lost Honor"] = "Kayıp Onur Sembolü" end
if E["Symbol of Ragnaros"] == nil then E["Symbol of Ragnaros"] = "Ragnaros Sembolü" end
if E["Syndicate Emblem"] == nil then E["Syndicate Emblem"] = "Syndicate Amblemi" end
if E["Syndicate Man Tracker (MURP)"] == nil then E["Syndicate Man Tracker (MURP)"] = "Syndicate Adam İzleyici (MURP)" end
if E["Syndicate Missive"] == nil then E["Syndicate Missive"] = "Syndicate Mektubu" end
if E["Tabetha's Instructions"] == nil then E["Tabetha's Instructions"] = "Tabetha'nın Talimatları" end
if E["Tablet Shard"] == nil then E["Tablet Shard"] = "Tablet Kırığı" end
if E["Tablet Transcript"] == nil then E["Tablet Transcript"] = "Tablet Dökümü" end
if E["Tablet of Beth'Amara"] == nil then E["Tablet of Beth'Amara"] = "Beth'Amara Tableti" end
if E["Tablet of Jin'yael"] == nil then E["Tablet of Jin'yael"] = "Jin'yael Tableti" end
if E["Tablet of Kurniya"] == nil then E["Tablet of Kurniya"] = "Kurniya Tableti" end
if E["Tablet of Markri"] == nil then E["Tablet of Markri"] = "Markri Tableti" end
if E["Tablet of Ryun'eh"] == nil then E["Tablet of Ryun'eh"] = "Ryun'eh Tableti" end
if E["Tablet of Sael'hai"] == nil then E["Tablet of Sael'hai"] = "Sael'hai Tableti" end
if E["Tablet of Verga"] == nil then E["Tablet of Verga"] = "Verga Tableti" end
if E["Tablet of Will"] == nil then E["Tablet of Will"] = "İrade Tableti" end
if E["Tactical Task Briefing I"] == nil then E["Tactical Task Briefing I"] = "Taktik Görev Brifingi I" end
if E["Tactical Task Briefing II"] == nil then E["Tactical Task Briefing II"] = "Taktik Görev Brifingi II" end
if E["Tactical Task Briefing III"] == nil then E["Tactical Task Briefing III"] = "Taktik Görev Brifingi III" end
if E["Tactical Task Briefing IV"] == nil then E["Tactical Task Briefing IV"] = "Taktik Görev Brifingi IV" end
if E["Tactical Task Briefing IX"] == nil then E["Tactical Task Briefing IX"] = "Taktik Görev Brifingi IX" end
if E["Tactical Task Briefing V"] == nil then E["Tactical Task Briefing V"] = "Taktik Görev Brifingi V" end
if E["Tactical Task Briefing VI"] == nil then E["Tactical Task Briefing VI"] = "Taktik Görev Brifingi VI" end
if E["Tactical Task Briefing VII"] == nil then E["Tactical Task Briefing VII"] = "Taktik Görev Brifingi VII" end
if E["Tactical Task Briefing VIII"] == nil then E["Tactical Task Briefing VIII"] = "Taktik Görev Brifingi VIII" end
if E["Tactical Task Briefing X"] == nil then E["Tactical Task Briefing X"] = "Taktik Görev Brifingi X" end
if E["Taelan's Hammer"] == nil then E["Taelan's Hammer"] = "Taelan'ın Çekici" end
if E["Tainted Keg"] == nil then E["Tainted Keg"] = "Bozulmuş Fıçı" end
if E["Tainted Letter"] == nil then E["Tainted Letter"] = "Bozulmuş Mektup" end
if E["Tainted Memorandum"] == nil then E["Tainted Memorandum"] = "Bozulmuş Muhtıra" end
if E["Tainted Parchment"] == nil then E["Tainted Parchment"] = "Bozulmuş Parşömen" end
if E["Tainted Scroll"] == nil then E["Tainted Scroll"] = "Bozulmuş Tomar" end
if E["Tainted Vitriol"] == nil then E["Tainted Vitriol"] = "Bozulmuş Vitriol" end
if E["Talisman of Corruption"] == nil then E["Talisman of Corruption"] = "Yozlaşma Tılsımı" end
if E["Talon of Tethis"] == nil then E["Talon of Tethis"] = "Tethis'in Pençesi" end
if E["Talvash's Phial of Scrying"] == nil then E["Talvash's Phial of Scrying"] = "Talvash'ın Kehanet Şişesi" end
if E["Taming Rod"] == nil then E["Taming Rod"] = "Evcilleştirme Çubuğu" end
if E["Tapped Dowsing Widget"] == nil then E["Tapped Dowsing Widget"] = "Kullanılmış Arama Aleti" end
if E["Taragaman the Hungerer's Heart"] == nil then E["Taragaman the Hungerer's Heart"] = "Aç Gözlü Taragaman'ın Kalbi" end
if E["Taretha's Necklace"] == nil then E["Taretha's Necklace"] = "Taretha'nın Kolyesi" end
if E["Targ's Head"] == nil then E["Targ's Head"] = "Targ'ın Kafası" end
if E["Tattered Manuscript"] == nil then E["Tattered Manuscript"] = "Yırtık Pırtık El Yazması" end
if E["Tattered Parchment"] == nil then E["Tattered Parchment"] = "Yırtık Pırtık Parşömen" end
if E["Tauren Hoof"] == nil then E["Tauren Hoof"] = "Tauren Toynağı" end
if E["Tazan's Key"] == nil then E["Tazan's Key"] = "Tazan'ın Anahtarı" end
if E["Tazan's Logbook"] == nil then E["Tazan's Logbook"] = "Tazan'ın Seyir Defteri" end
if E["Tazan's Satchel"] == nil then E["Tazan's Satchel"] = "Tazan'ın Heybesi" end
if E["Teal Kodo"] == nil then E["Teal Kodo"] = "Camgöbeği Kodo" end
if E["Tear of Tilloa"] == nil then E["Tear of Tilloa"] = "Tilloa'nın Gözyaşı" end
if E["Tear of the Moons"] == nil then E["Tear of the Moons"] = "Ayların Gözyaşı" end
if E["Tears of the Hederine"] == nil then E["Tears of the Hederine"] = "Hederine'in Gözyaşları" end
if E["Techbot's Memory Core"] == nil then E["Techbot's Memory Core"] = "Techbot'un Bellek Çekirdeği" end
if E["Temporal Displacer"] == nil then E["Temporal Displacer"] = "Zamansal Yer Değiştirici" end
if E["Teronis' Journal"] == nil then E["Teronis' Journal"] = "Teronis'in Günlüğü" end
if E["Tharil'zun's Head"] == nil then E["Tharil'zun's Head"] = "Tharil'zun'un Kafası" end
if E["Tharnariun's Hope"] == nil then E["Tharnariun's Hope"] = "Tharnariun'un Umudu" end
if E["Thaumaturgy Vessel Lockbox"] == nil then E["Thaumaturgy Vessel Lockbox"] = "Taumaturji Kabı Kilitli Kutusu" end
if E["The Agamaggan Scrolls"] == nil then E["The Agamaggan Scrolls"] = "Agamaggan Tomarları" end
if E["The Arcanist's Cookbook"] == nil then E["The Arcanist's Cookbook"] = "Arkanistin Yemek Kitabı" end
if E["The Book of Ur"] == nil then E["The Book of Ur"] = "Ur'un Kitabı" end
if E["The Deed to Brill"] == nil then E["The Deed to Brill"] = "Brill Tapusu" end
if E["The Deed to Caer Darrow"] == nil then E["The Deed to Caer Darrow"] = "Caer Darrow Tapusu" end
if E["The Deed to Southshore"] == nil then E["The Deed to Southshore"] = "Southshore Tapusu" end
if E["The Deed to Tarren Mill"] == nil then E["The Deed to Tarren Mill"] = "Tarren Mill Tapusu" end
if E["The Embalmer's Heart"] == nil then E["The Embalmer's Heart"] = "Mumyacının Kalbi" end
if E["The Emerald Dream"] == nil then E["The Emerald Dream"] = "Zümrüt Rüya" end
if E["The Eye of Zuldazar"] == nil then E["The Eye of Zuldazar"] = "Zuldazar'ın Gözü" end
if E["The Feast of Winter Veil"] == nil then E["The Feast of Winter Veil"] = "Winter Veil Ziyafeti" end
if E["The First Troll Legend"] == nil then E["The First Troll Legend"] = "Birinci Trol Efsanesi" end
if E["The Fourth Troll Legend"] == nil then E["The Fourth Troll Legend"] = "Dördüncü Trol Efsanesi" end
if E["The General's Response"] == nil then E["The General's Response"] = "Generalin Yanıtı" end
if E["The Grand Crusader's Command"] == nil then E["The Grand Crusader's Command"] = "Büyük Haçlının Emri" end
if E["The Heart of the Mountain"] == nil then E["The Heart of the Mountain"] = "Dağın Kalbi" end
if E["The Hexxer's Head"] == nil then E["The Hexxer's Head"] = "Lanetçinin Kafası" end
if E["The Legacy Heart"] == nil then E["The Legacy Heart"] = "Miras Kalp" end
if E["The Lich's Spellbook"] == nil then E["The Lich's Spellbook"] = "Lich'in Büyü Kitabı" end
if E["The Light and How to Swing It"] == nil then E["The Light and How to Swing It"] = "Işık ve Nasıl Savrulur" end
if E["The Nightmare's Corruption"] == nil then E["The Nightmare's Corruption"] = "Kâbusun Yozlaşması" end
if E["The Pariah's Instructions"] == nil then E["The Pariah's Instructions"] = "Dışlanmışın Talimatları" end
if E["The Phylactery of Kel'Thuzad"] == nil then E["The Phylactery of Kel'Thuzad"] = "Kel'Thuzad'ın Filakteri" end
if E["The Scepter of the Shifting Sands"] == nil then E["The Scepter of the Shifting Sands"] = "Kayan Kumların Asası" end
if E["The Second Troll Legend"] == nil then E["The Second Troll Legend"] = "İkinci Trol Efsanesi" end
if E["The Shaft of Tsol"] == nil then E["The Shaft of Tsol"] = "Tsol'un Sapı" end
if E["The Skull of Axtroz"] == nil then E["The Skull of Axtroz"] = "Axtroz'un Kafatası" end
if E["The Skull of Chronalis"] == nil then E["The Skull of Chronalis"] = "Chronalis'in Kafatası" end
if E["The Skull of Scryer"] == nil then E["The Skull of Scryer"] = "Scryer'ın Kafatası" end
if E["The Skull of Somnus"] == nil then E["The Skull of Somnus"] = "Somnus'un Kafatası" end
if E["The State of Lakeshire"] == nil then E["The State of Lakeshire"] = "Lakeshire'ın Durumu" end
if E["The Third Troll Legend"] == nil then E["The Third Troll Legend"] = "Üçüncü Trol Efsanesi" end
if E["The Traitor's Heart"] == nil then E["The Traitor's Heart"] = "Hainin Kalbi" end
if E["The War of the Shifting Sands"] == nil then E["The War of the Shifting Sands"] = "Kayan Kumlar Savaşı" end
if E["Theradric Crystal Carving"] == nil then E["Theradric Crystal Carving"] = "Theradric Kristal Oyması" end
if E["Theramore Medal"] == nil then E["Theramore Medal"] = "Theramore Madalyası" end
if E["Thermaplugg's Safe Combination"] == nil then E["Thermaplugg's Safe Combination"] = "Thermaplugg'ın Kasa Şifresi" end
if E["Thick Armor Kit"] == nil then E["Thick Armor Kit"] = "Kalın Zırh Takımı" end
if E["Thick Black Claw"] == nil then E["Thick Black Claw"] = "Kalın Kara Pençe" end
if E["Thick Leather"] == nil then E["Thick Leather"] = "Kalın Deri" end
if E["Thick Yeti Fur"] == nil then E["Thick Yeti Fur"] = "Kalın Yeti Kürkü" end
if E["Thick Yeti Hide"] == nil then E["Thick Yeti Hide"] = "Kalın Yeti Postu" end
if E["Thieves' Tools"] == nil then E["Thieves' Tools"] = "Hırsız Aletleri" end
if E["Third Mosh'aru Tablet"] == nil then E["Third Mosh'aru Tablet"] = "Üçüncü Mosh'aru Tableti" end
if E["Third Relic Fragment"] == nil then E["Third Relic Fragment"] = "Üçüncü Kalıntı Parçası" end
if E["Thistlenettle's Badge"] == nil then E["Thistlenettle's Badge"] = "Thistlenettle'ın Rozeti" end
if E["Thistleshrub Dew"] == nil then E["Thistleshrub Dew"] = "Thistleshrub Çiyi" end
if E["Thorium Bar"] == nil then E["Thorium Bar"] = "Toryum Külçe" end
if E["Thorium Brotherhood Contract"] == nil then E["Thorium Brotherhood Contract"] = "Thorium Brotherhood Sözleşmesi" end
if E["Thorium Brotherhood Contract (OLD)"] == nil then E["Thorium Brotherhood Contract (OLD)"] = "Thorium Brotherhood Sözleşmesi (ESKİ)" end
if E["Thorium Grenade"] == nil then E["Thorium Grenade"] = "Toryum El Bombası" end
if E["Thorium Plated Dagger"] == nil then E["Thorium Plated Dagger"] = "Toryum Kaplama Hançer" end
if E["Thorium Shackles"] == nil then E["Thorium Shackles"] = "Toryum Prangalar" end
if E["Thorium Shells"] == nil then E["Thorium Shells"] = "Toryum Mermiler" end
if E["Thorium Tube"] == nil then E["Thorium Tube"] = "Toryum Boru" end
if E["Thorium Widget"] == nil then E["Thorium Widget"] = "Toryum Düzenek" end
if E["Threshadon Claw"] == nil then E["Threshadon Claw"] = "Threshadon Pençesi" end
if E["Threshadon Tooth"] == nil then E["Threshadon Tooth"] = "Threshadon Dişi" end
if E["Thresher Eye"] == nil then E["Thresher Eye"] = "Thresher Gözü" end
if E["Thun'grim's Instructions"] == nil then E["Thun'grim's Instructions"] = "Thun'grim'in Talimatları" end
if E["Thunder Bluff Marzipan"] == nil then E["Thunder Bluff Marzipan"] = "Thunder Bluff Marzipanı" end
if E["Thunder Lizard Blood"] == nil then E["Thunder Lizard Blood"] = "Gök Gürültüsü Kertenkelesi Kanı" end
if E["Thunder Lizard Horn"] == nil then E["Thunder Lizard Horn"] = "Gök Gürültüsü Kertenkelesi Boynuzu" end
if E["Thunderhawk Saliva Gland"] == nil then E["Thunderhawk Saliva Gland"] = "Thunderhawk Tükürük Bezi" end
if E["Thunderhawk Wings"] == nil then E["Thunderhawk Wings"] = "Thunderhawk Kanatları" end
if E["Thundering Charm"] == nil then E["Thundering Charm"] = "Gürleyen Tılsım" end
if E["Thundering Key"] == nil then E["Thundering Key"] = "Gürleyen Anahtar" end
if E["Thurman's Sewing Kit"] == nil then E["Thurman's Sewing Kit"] = "Thurman'ın Dikiş Takımı" end
if E["Tiara of the Deep"] == nil then E["Tiara of the Deep"] = "Derinliklerin Tacı" end
if E["Tigule and Foror's Strawberry Ice Cream"] == nil then E["Tigule and Foror's Strawberry Ice Cream"] = "Tigule ve Foror'un Çilekli Dondurması" end
if E["Timbermaw Offering of Peace"] == nil then E["Timbermaw Offering of Peace"] = "Timbermaw Barış Sunusu" end
if E["Timolain's Phylactery"] == nil then E["Timolain's Phylactery"] = "Timolain'in Filakteri" end
if E["Tin Bar"] == nil then E["Tin Bar"] = "Kalay Külçe" end
if E["Tinkee's Letter"] == nil then E["Tinkee's Letter"] = "Tinkee'nin Mektubu" end
if E["Tirion's Gift"] == nil then E["Tirion's Gift"] = "Tirion'un Hediyesi" end
if E["Token of Thievery"] == nil then E["Token of Thievery"] = "Hırsızlık Nişanı" end
if E["Tome of Divinity"] == nil then E["Tome of Divinity"] = "Kutsallık Kitabı" end
if E["Tome of Justice"] == nil then E["Tome of Justice"] = "Adalet Kitabı" end
if E["Tome of Nobility"] == nil then E["Tome of Nobility"] = "Asalet Kitabı" end
if E["Tome of Righteousness"] == nil then E["Tome of Righteousness"] = "Doğruluk Kitabı" end
if E["Tome of Valor"] == nil then E["Tome of Valor"] = "Yiğitlik Kitabı" end
if E["Tome of the Cabal"] == nil then E["Tome of the Cabal"] = "Kabalın Kitabı" end
if E["Tomes of Alterac"] == nil then E["Tomes of Alterac"] = "Alterac Kitapları" end
if E["Tooth of Morphaz"] == nil then E["Tooth of Morphaz"] = "Morphaz'ın Dişi" end
if E["Top Half of Advanced Armorsmithing: Volume I"] == nil then E["Top Half of Advanced Armorsmithing: Volume I"] = "İleri Zırh Demirciliği: Cilt I - Üst Yarı" end
if E["Top Half of Advanced Armorsmithing: Volume II"] == nil then E["Top Half of Advanced Armorsmithing: Volume II"] = "İleri Zırh Demirciliği: Cilt II - Üst Yarı" end
if E["Top Half of Advanced Armorsmithing: Volume III"] == nil then E["Top Half of Advanced Armorsmithing: Volume III"] = "İleri Zırh Demirciliği: Cilt III - Üst Yarı" end
if E["Top Piece of Lord Valthalak's Amulet"] == nil then E["Top Piece of Lord Valthalak's Amulet"] = "Lord Valthalak'ın Muskasının Üst Parçası" end
if E["Top of Gelkak's Key"] == nil then E["Top of Gelkak's Key"] = "Gelkak'ın Anahtarının Üst Kısmı" end
if E["Tor'gan's Orb"] == nil then E["Tor'gan's Orb"] = "Tor'gan'ın Küresi" end
if E["Torch of Retribution"] == nil then E["Torch of Retribution"] = "İntikam Meşalesi" end
if E["Torch of the Dormant Flame"] == nil then E["Torch of the Dormant Flame"] = "Uyuyan Alevin Meşalesi" end
if E["Torch of the Eternal Flame"] == nil then E["Torch of the Eternal Flame"] = "Ebedi Alevin Meşalesi" end
if E["Torn Fin Eye"] == nil then E["Torn Fin Eye"] = "Torn Fin Gözü" end
if E["Torn Recipe Page"] == nil then E["Torn Recipe Page"] = "Yırtık Tarif Sayfası" end
if E["Torn Scroll Fragment"] == nil then E["Torn Scroll Fragment"] = "Yırtık Tomar Parçası" end
if E["Torwa's Pouch"] == nil then E["Torwa's Pouch"] = "Torwa'nın Kesesi" end
if E["Tough Condor Meat"] == nil then E["Tough Condor Meat"] = "Sert Akbaba Eti" end
if E["Tough Scorpid Breastplate"] == nil then E["Tough Scorpid Breastplate"] = "Sert Akrep Göğüslüğü" end
if E["Tough Scorpid Gloves"] == nil then E["Tough Scorpid Gloves"] = "Sert Akrep Eldivenleri" end
if E["Toughened Leather Armor"] == nil then E["Toughened Leather Armor"] = "Sertleştirilmiş Deri Zırh" end
if E["Toxic Fogger"] == nil then E["Toxic Fogger"] = "Zehirli Sisleyici" end
if E["Toxic Horror Droplet"] == nil then E["Toxic Horror Droplet"] = "Zehirli Dehşet Damlası" end
if E["Trader's Satchel"] == nil then E["Trader's Satchel"] = "Tüccar Heybesi" end
if E["Translated Letter"] == nil then E["Translated Letter"] = "Çevrilmiş Mektup" end
if E["Translated Letter from The Embalmer"] == nil then E["Translated Letter from The Embalmer"] = "Mumyacıdan Çevrilmiş Mektup" end
if E["Treant Muisek Vessel"] == nil then E["Treant Muisek Vessel"] = "Treant Muisek Kabı" end
if E["Treated Ancient Blade"] == nil then E["Treated Ancient Blade"] = "İşlenmiş Kadim Kılıç" end
if E["Trelane's Ember Agate"] == nil then E["Trelane's Ember Agate"] = "Trelane'in Kor Akiği" end
if E["Trelane's Orb"] == nil then E["Trelane's Orb"] = "Trelane'in Küresi" end
if E["Trelane's Phylactery"] == nil then E["Trelane's Phylactery"] = "Trelane'in Filakteri" end
if E["Trelane's Wand of Invocation"] == nil then E["Trelane's Wand of Invocation"] = "Trelane'in Yakarış Değneği" end
if E["Treshala's Pendant"] == nil then E["Treshala's Pendant"] = "Treshala'nın Kolyesi" end
if E["Triage Bandage"] == nil then E["Triage Bandage"] = "Triyaj Sargısı" end
if E["Trogg Stone Tooth"] == nil then E["Trogg Stone Tooth"] = "Trogg Taş Dişi" end
if E["Troll Charm"] == nil then E["Troll Charm"] = "Trol Tılsımı" end
if E["Troll Temper"] == nil then E["Troll Temper"] = "Trol Öfkesi" end
if E["Troll Tribal Necklace"] == nil then E["Troll Tribal Necklace"] = "Trol Kabile Kolyesi" end
if E["Troyas' Stave"] == nil then E["Troyas' Stave"] = "Troyas'ın Asası" end
if E["Truesilver Bar"] == nil then E["Truesilver Bar"] = "Gerçekgümüş Külçe" end
if E["Tuft of Gnome Hair"] == nil then E["Tuft of Gnome Hair"] = "Bir Tutam Gnom Saçı" end
if E["Tumbled Crystal"] == nil then E["Tumbled Crystal"] = "Cilalanmış Kristal" end
if E["Tunnel Rat Ear"] == nil then E["Tunnel Rat Ear"] = "Tünel Faresi Kulağı" end
if E["Turtle Meat"] == nil then E["Turtle Meat"] = "Kaplumbağa Eti" end
if E["Turtle Scale Bracers"] == nil then E["Turtle Scale Bracers"] = "Kaplumbağa Pulu Bileklikleri" end
if E["Turtle Scale Breastplate"] == nil then E["Turtle Scale Breastplate"] = "Kaplumbağa Pulu Göğüslüğü" end
if E["Turtle Scale Gloves"] == nil then E["Turtle Scale Gloves"] = "Kaplumbağa Pulu Eldivenleri" end
if E["Turtle Scale Helm"] == nil then E["Turtle Scale Helm"] = "Kaplumbağa Pulu Miğferi" end
if E["Turtle Scale Leggings"] == nil then E["Turtle Scale Leggings"] = "Kaplumbağa Pulu Bacaklıkları" end
if E["Twilight Battle Orders"] == nil then E["Twilight Battle Orders"] = "Twilight Savaş Emirleri" end
if E["Twilight Cultist Robe"] == nil then E["Twilight Cultist Robe"] = "Twilight Tarikatçısı Cübbesi" end
if E["Twilight Lexicon - Chapter 1"] == nil then E["Twilight Lexicon - Chapter 1"] = "Twilight Sözlüğü - Bölüm 1" end
if E["Twilight Lexicon - Chapter 2"] == nil then E["Twilight Lexicon - Chapter 2"] = "Twilight Sözlüğü - Bölüm 2" end
if E["Twilight Lexicon - Chapter 3"] == nil then E["Twilight Lexicon - Chapter 3"] = "Twilight Sözlüğü - Bölüm 3" end
if E["Twilight Pendant"] == nil then E["Twilight Pendant"] = "Twilight Kolyesi" end
if E["Twilight Tablet Fragment"] == nil then E["Twilight Tablet Fragment"] = "Twilight Tablet Parçası" end
if E["Twilight Whisker"] == nil then E["Twilight Whisker"] = "Twilight Bıyığı" end
if E["Twitching Antenna"] == nil then E["Twitching Antenna"] = "Seğiren Anten" end
if E["Tyranis' Pendant"] == nil then E["Tyranis' Pendant"] = "Tyranis'in Kolyesi" end
if E["Tyranis' Pendant (old)"] == nil then E["Tyranis' Pendant (old)"] = "Tyranis'in Kolyesi (eski)" end
if E["U'cha's Pelt"] == nil then E["U'cha's Pelt"] = "U'cha'nın Postu" end
if E["Umbral Ore"] == nil then E["Umbral Ore"] = "Gölgeli Cevher" end
if E["Umi's Mechanical Yeti"] == nil then E["Umi's Mechanical Yeti"] = "Umi'nin Mekanik Yetisi" end
if E["Un'Goro Ash"] == nil then E["Un'Goro Ash"] = "Un'Goro Külü" end
if E["Un'Goro Gorilla Pelt"] == nil then E["Un'Goro Gorilla Pelt"] = "Un'Goro Goril Postu" end
if E["Un'Goro Slime Sample"] == nil then E["Un'Goro Slime Sample"] = "Un'Goro Balçık Örneği" end
if E["Un'Goro Soil"] == nil then E["Un'Goro Soil"] = "Un'Goro Toprağı" end
if E["Un'Goro Stomper Pelt"] == nil then E["Un'Goro Stomper Pelt"] = "Un'Goro Ezici Postu" end
if E["Un'Goro Thunderer Pelt"] == nil then E["Un'Goro Thunderer Pelt"] = "Un'Goro Gürleyen Postu" end
if E["Unadorned Seal of Ascension"] == nil then E["Unadorned Seal of Ascension"] = "Süssüz Yükseliş Mührü" end
if E["Uncloven Satyr Hoof"] == nil then E["Uncloven Satyr Hoof"] = "Yarılmamış Satir Toynağı" end
if E["Uncracked Chillwind Horn"] == nil then E["Uncracked Chillwind Horn"] = "Çatlamamış Chillwind Boynuzu" end
if E["Uncracked Scarab Shell"] == nil then E["Uncracked Scarab Shell"] = "Çatlamamış Skarabe Kabuğu" end
if E["Undamaged Hippogryph Feather"] == nil then E["Undamaged Hippogryph Feather"] = "Hasarsız Hipogrif Tüyü" end
if E["Undamaged Venom Sac"] == nil then E["Undamaged Venom Sac"] = "Hasarsız Zehir Kesesi" end
if E["Undelivered Parcel"] == nil then E["Undelivered Parcel"] = "Teslim Edilmemiş Paket" end
if E["Underbelly Whelp Scale"] == nil then E["Underbelly Whelp Scale"] = "Karın Altı Yavru Ejder Pulu" end
if E["Undercity Mint"] == nil then E["Undercity Mint"] = "Undercity Nanesi" end
if E["Unfinished Skeleton Key"] == nil then E["Unfinished Skeleton Key"] = "Bitmemiş Maymuncuk" end
if E["Unfired Ancient Blade"] == nil then E["Unfired Ancient Blade"] = "Fırınlanmamış Kadim Kılıç" end
if E["Unfired Plate Gauntlets"] == nil then E["Unfired Plate Gauntlets"] = "Fırınlanmamış Plaka Eldivenler" end
if E["Unforged Rune Covered Breastplate"] == nil then E["Unforged Rune Covered Breastplate"] = "Dövülmemiş Rün Kaplı Göğüslük" end
if E["Unforged Seal of Ascension"] == nil then E["Unforged Seal of Ascension"] = "Dövülmemiş Yükseliş Mührü" end
if E["Unhatched Sprite Darter Egg"] == nil then E["Unhatched Sprite Darter Egg"] = "Çatlamamış Sprite Darter Yumurtası" end
if E["Unidentified Ore"] == nil then E["Unidentified Ore"] = "Tanımlanmamış Cevher" end
if E["Unknown Reward"] == nil then E["Unknown Reward"] = "Bilinmeyen Ödül" end
if E["Unloaded Zapper"] == nil then E["Unloaded Zapper"] = "Boş Şoklayıcı" end
if E["Unpopped Darkmist Eye"] == nil then E["Unpopped Darkmist Eye"] = "Patlamamış Darkmist Gözü" end
if E["Unprepared Sawtooth Flank"] == nil then E["Unprepared Sawtooth Flank"] = "Hazırlanmamış Sawtooth Böğrü" end
if E["Unrefined Ore Sample"] == nil then E["Unrefined Ore Sample"] = "İşlenmemiş Cevher Örneği" end
if E["Unsigned Field Duty Papers"] == nil then E["Unsigned Field Duty Papers"] = "İmzasız Saha Görevi Belgeleri" end
if E["Unstable Trigger"] == nil then E["Unstable Trigger"] = "Kararsız Tetik" end
if E["Untapped Dowsing Widget"] == nil then E["Untapped Dowsing Widget"] = "Kullanılmamış Arama Aleti" end
if E["Untranslated Journal"] == nil then E["Untranslated Journal"] = "Çevrilmemiş Günlük" end
if E["Upper Map Fragment"] == nil then E["Upper Map Fragment"] = "Üst Harita Parçası" end
if E["Ur's Treatise on Shadow Magic"] == nil then E["Ur's Treatise on Shadow Magic"] = "Ur'un Gölge Büyüsü Üzerine İncelemesi" end
if E["Urgent Message"] == nil then E["Urgent Message"] = "Acil Mesaj" end
if E["Ursangous's Paw"] == nil then E["Ursangous's Paw"] = "Ursangous'un Pençesi" end
if E["Uther's Tribute"] == nil then E["Uther's Tribute"] = "Uther'e Saygı" end
if E["Vaelan's Gift"] == nil then E["Vaelan's Gift"] = "Vaelan'ın Hediyesi" end
if E["Vejrek's Head"] == nil then E["Vejrek's Head"] = "Vejrek'in Kafası" end
if E["Vek'lor's Diadem"] == nil then E["Vek'lor's Diadem"] = "Vek'lor'un Diademi" end
if E["Vek'nilash's Circlet"] == nil then E["Vek'nilash's Circlet"] = "Vek'nilash'ın Tacı" end
if E["Velinde's Journal"] == nil then E["Velinde's Journal"] = "Velinde'nin Günlüğü" end
if E["Velinde's Key"] == nil then E["Velinde's Key"] = "Velinde'nin Anahtarı" end
if E["Venom Bottle"] == nil then E["Venom Bottle"] = "Zehir Şişesi" end
if E["Venom Fern Extract"] == nil then E["Venom Fern Extract"] = "Zehirli Eğrelti Özü" end
if E["Venoxis's Venom Sac"] == nil then E["Venoxis's Venom Sac"] = "Venoxis'in Zehir Kesesi" end
if E["Venture Co. Engineering Plans"] == nil then E["Venture Co. Engineering Plans"] = "Venture Co. Mühendislik Planları" end
if E["Venture Co. Ledger"] == nil then E["Venture Co. Ledger"] = "Venture Co. Hesap Defteri" end
if E["Venture Co. Letters"] == nil then E["Venture Co. Letters"] = "Venture Co. Mektupları" end
if E["Verdant Note"] == nil then E["Verdant Note"] = "Yeşil Not" end
if E["Verdant Sigil"] == nil then E["Verdant Sigil"] = "Yeşil Mühür" end
if E["Vermillion Idol"] == nil then E["Vermillion Idol"] = "Al Put" end
if E["Verna's Westfall Stew Recipe"] == nil then E["Verna's Westfall Stew Recipe"] = "Verna'nın Westfall Yahnisi Tarifi" end
if E["Verner's Note"] == nil then E["Verner's Note"] = "Verner'in Notu" end
if E["Verog's Head"] == nil then E["Verog's Head"] = "Verog'un Kafası" end
if E["Vessel of Dragon's Blood"] == nil then E["Vessel of Dragon's Blood"] = "Ejderha Kanı Kabı" end
if E["Vessel of Rebirth"] == nil then E["Vessel of Rebirth"] = "Yeniden Doğuş Kabı" end
if E["Vessel of Tainted Blood"] == nil then E["Vessel of Tainted Blood"] = "Bozulmuş Kan Kabı" end
if E["Vest of Elements"] == nil then E["Vest of Elements"] = "Elementler Yeleği" end
if E["Vial of Dire Water"] == nil then E["Vial of Dire Water"] = "Bir Şişe Uğursuz Su" end
if E["Vial of Hatefury Blood"] == nil then E["Vial of Hatefury Blood"] = "Bir Şişe Hatefury Kanı" end
if E["Vial of Innocent Blood"] == nil then E["Vial of Innocent Blood"] = "Bir Şişe Masum Kanı" end
if E["Vial of Phlogiston"] == nil then E["Vial of Phlogiston"] = "Bir Şişe Flojiston" end
if E["Vial of Purest Water"] == nil then E["Vial of Purest Water"] = "Bir Şişe En Saf Su" end
if E["Vial of Spider Venom"] == nil then E["Vial of Spider Venom"] = "Bir Şişe Örümcek Zehri" end
if E["Vibrant Plume"] == nil then E["Vibrant Plume"] = "Canlı Tüy" end
if E["Videre Elixir"] == nil then E["Videre Elixir"] = "Videre İksiri" end
if E["Vile Familiar Head"] == nil then E["Vile Familiar Head"] = "İğrenç Familiar Kafası" end
if E["Vilebranch Coin"] == nil then E["Vilebranch Coin"] = "Vilebranch Sikkesi" end
if E["Vimes's Report"] == nil then E["Vimes's Report"] = "Vimes'in Raporu" end
if E["Violet Powder"] == nil then E["Violet Powder"] = "Menekşe Tozu" end
if E["Violet Tragan"] == nil then E["Violet Tragan"] = "Menekşe Tragan" end
if E["Vipore's Beacon"] == nil then E["Vipore's Beacon"] = "Vipore'un İşaret Feneri" end
if E["Vision of Voodress"] == nil then E["Vision of Voodress"] = "Voodress'in Görüsü" end
if E["Vitreous Focuser"] == nil then E["Vitreous Focuser"] = "Camsı Odaklayıcı" end
if E["Voidwalker Summoning Scroll"] == nil then E["Voidwalker Summoning Scroll"] = "Voidwalker Çağırma Tomarı" end
if E["Volcanic Ash"] == nil then E["Volcanic Ash"] = "Volkanik Kül" end
if E["Volcanic Hammer"] == nil then E["Volcanic Hammer"] = "Volkanik Çekiç" end
if E["Vorrel's Wedding Ring"] == nil then E["Vorrel's Wedding Ring"] = "Vorrel'in Alyansı" end
if E["Vosh'gajin's Snakestone"] == nil then E["Vosh'gajin's Snakestone"] = "Vosh'gajin'in Yılan Taşı" end
if E["Vulture Gizzard"] == nil then E["Vulture Gizzard"] = "Akbaba Taşlığı" end
if E["Vyral's Signet Ring"] == nil then E["Vyral's Signet Ring"] = "Vyral'ın Mühür Yüzüğü" end
if E["Wailing Essence"] == nil then E["Wailing Essence"] = "Feryat Özü" end
if E["War Horn Mouthpiece"] == nil then E["War Horn Mouthpiece"] = "Savaş Borusu Ağızlığı" end
if E["Warchief's Orders"] == nil then E["Warchief's Orders"] = "Savaş Şefinin Emirleri" end
if E["Ward of the Defiler"] == nil then E["Ward of the Defiler"] = "Kirleticinin Muskası" end
if E["Warlord Goretooth's Command"] == nil then E["Warlord Goretooth's Command"] = "Savaş Lordu Goretooth'un Emri" end
if E["Warlords Deck"] == nil then E["Warlords Deck"] = "Savaş Lordları Destesi" end
if E["Warosh's Mojo"] == nil then E["Warosh's Mojo"] = "Warosh'un Mojosu" end
if E["Warosh's Scroll"] == nil then E["Warosh's Scroll"] = "Warosh'un Tomarı" end
if E["Warsong Axe Shipment"] == nil then E["Warsong Axe Shipment"] = "Warsong Balta Sevkiyatı" end
if E["Warsong Gulch Mark of Honor"] == nil then E["Warsong Gulch Mark of Honor"] = "Warsong Gulch Onur Nişanı" end
if E["Warsong Gulch Ribbon of Sacrifice"] == nil then E["Warsong Gulch Ribbon of Sacrifice"] = "Warsong Gulch Fedakârlık Kurdelesi" end
if E["Warsong Mark of Honor"] == nil then E["Warsong Mark of Honor"] = "Warsong Onur Nişanı" end
if E["Warsong Oil"] == nil then E["Warsong Oil"] = "Warsong Yağı" end
if E["Warsong Outrider Update"] == nil then E["Warsong Outrider Update"] = "Warsong Öncü Raporu" end
if E["Warsong Report"] == nil then E["Warsong Report"] = "Warsong Raporu" end
if E["Warsong Runner Update"] == nil then E["Warsong Runner Update"] = "Warsong Ulak Raporu" end
if E["Warsong Saw Blades"] == nil then E["Warsong Saw Blades"] = "Warsong Testere Bıçakları" end
if E["Warsong Scout Update"] == nil then E["Warsong Scout Update"] = "Warsong İzci Raporu" end
if E["Wartorn Chain Scrap"] == nil then E["Wartorn Chain Scrap"] = "Savaş Yıpranmış Zincir Parçası" end
if E["Wartorn Cloth Scrap"] == nil then E["Wartorn Cloth Scrap"] = "Savaş Yıpranmış Kumaş Parçası" end
if E["Wartorn Leather Scrap"] == nil then E["Wartorn Leather Scrap"] = "Savaş Yıpranmış Deri Parçası" end
if E["Wartorn Plate Scrap"] == nil then E["Wartorn Plate Scrap"] = "Savaş Yıpranmış Plaka Parçası" end
if E["Washte Pawne's Feather"] == nil then E["Washte Pawne's Feather"] = "Washte Pawne'ın Tüyü" end
if E["Wastewander Water Pouch"] == nil then E["Wastewander Water Pouch"] = "Wastewander Su Kesesi" end
if E["Water Elemental Bracers"] == nil then E["Water Elemental Bracers"] = "Su Elementali Bileklikleri" end
if E["Water Elemental Core"] == nil then E["Water Elemental Core"] = "Su Elementali Çekirdeği" end
if E["Water Sapta"] == nil then E["Water Sapta"] = "Su Saptası" end
if E["Waterlogged Envelope"] == nil then E["Waterlogged Envelope"] = "Islanmış Zarf" end
if E["Wavethrasher Scales"] == nil then E["Wavethrasher Scales"] = "Wavethrasher Pulları" end
if E["Weatherbeaten Parchment"] == nil then E["Weatherbeaten Parchment"] = "Hava Görmüş Parşömen" end
if E["Weatherworn Parchment"] == nil then E["Weatherworn Parchment"] = "Havadan Yıpranmış Parşömen" end
if E["Webbed Diemetradon Scale"] == nil then E["Webbed Diemetradon Scale"] = "Perdeli Diemetradon Pulu" end
if E["Webbed Pterrordax Scale"] == nil then E["Webbed Pterrordax Scale"] = "Perdeli Pterrordax Pulu" end
if E["Westfall Deed"] == nil then E["Westfall Deed"] = "Westfall Tapusu" end
if E["Whipper Root Tuber"] == nil then E["Whipper Root Tuber"] = "Whipper Kökü Yumrusu" end
if E["Whirlwind Heart"] == nil then E["Whirlwind Heart"] = "Kasırga Kalbi" end
if E["Whirring Bronze Gizmo"] == nil then E["Whirring Bronze Gizmo"] = "Vızıldayan Bronz Zımbırtı" end
if E["White Moro'gai Gem"] == nil then E["White Moro'gai Gem"] = "Beyaz Moro'gai Taşı" end
if E["White Punch Card"] == nil then E["White Punch Card"] = "Beyaz Delikli Kart" end
if E["White Ravasaur Claw"] == nil then E["White Ravasaur Claw"] = "Beyaz Ravasaur Pençesi" end
if E["Wicked Leather Belt"] == nil then E["Wicked Leather Belt"] = "Kötücül Deri Kemer" end
if E["Wicked Leather Headband"] == nil then E["Wicked Leather Headband"] = "Kötücül Deri Saç Bandı" end
if E["Wild Leather Helmet"] == nil then E["Wild Leather Helmet"] = "Yabani Deri Miğfer" end
if E["Wild Leather Vest"] == nil then E["Wild Leather Vest"] = "Yabani Deri Yelek" end
if E["Wildheart Belt"] == nil then E["Wildheart Belt"] = "Wildheart Kemeri" end
if E["Wildheart Boots"] == nil then E["Wildheart Boots"] = "Wildheart Çizmeleri" end
if E["Wildheart Bracers"] == nil then E["Wildheart Bracers"] = "Wildheart Bileklikleri" end
if E["Wildheart Cowl"] == nil then E["Wildheart Cowl"] = "Wildheart Kukuletası" end
if E["Wildheart Gloves"] == nil then E["Wildheart Gloves"] = "Wildheart Eldivenleri" end
if E["Wildheart Kilt"] == nil then E["Wildheart Kilt"] = "Wildheart Eteği" end
if E["Wildheart Spaulders"] == nil then E["Wildheart Spaulders"] = "Wildheart Omuzlukları" end
if E["Wildheart Vest"] == nil then E["Wildheart Vest"] = "Wildheart Yeleği" end
if E["Wildkin Feather"] == nil then E["Wildkin Feather"] = "Wildkin Tüyü" end
if E["Wildkin Muisek Vessel"] == nil then E["Wildkin Muisek Vessel"] = "Wildkin Muisek Kabı" end
if E["Wildmane Well Water"] == nil then E["Wildmane Well Water"] = "Wildmane Kuyusu Suyu" end
if E["Wildvine"] == nil then E["Wildvine"] = "Yabani Asma" end
if E["Wiley's Note"] == nil then E["Wiley's Note"] = "Wiley'nin Notu" end
if E["Wine Ticket"] == nil then E["Wine Ticket"] = "Şarap Fişi" end
if E["Winna's Kitten Carrier"] == nil then E["Winna's Kitten Carrier"] = "Winna'nın Kedi Taşıma Kafesi" end
if E["Winterfall Crate"] == nil then E["Winterfall Crate"] = "Winterfall Sandığı" end
if E["Winterfall Ritual Totem"] == nil then E["Winterfall Ritual Totem"] = "Winterfall Ritüel Totemi" end
if E["Winterfall Spirit Beads"] == nil then E["Winterfall Spirit Beads"] = "Winterfall Ruh Boncukları" end
if E["Winterspring Blood Sample"] == nil then E["Winterspring Blood Sample"] = "Winterspring Kan Örneği" end
if E["Witchwing Talon"] == nil then E["Witchwing Talon"] = "Witchwing Pençesi" end
if E["Witherbark Coin"] == nil then E["Witherbark Coin"] = "Witherbark Sikkesi" end
if E["Witherbark Medicine Pouch"] == nil then E["Witherbark Medicine Pouch"] = "Witherbark İlaç Kesesi" end
if E["Witherbark Skull"] == nil then E["Witherbark Skull"] = "Witherbark Kafatası" end
if E["Witherbark Totem Stick"] == nil then E["Witherbark Totem Stick"] = "Witherbark Totem Çubuğu" end
if E["Witherbark Tusk"] == nil then E["Witherbark Tusk"] = "Witherbark Fildişi" end
if E["Wizards' Reagents"] == nil then E["Wizards' Reagents"] = "Büyücülerin Reaktifleri" end
if E["Wolf Heart Sample"] == nil then E["Wolf Heart Sample"] = "Kurt Kalbi Örneği" end
if E["Wolf Heart Samples"] == nil then E["Wolf Heart Samples"] = "Kurt Kalbi Örnekleri" end
if E["Wood Pulp"] == nil then E["Wood Pulp"] = "Odun Hamuru" end
if E["Woodpaw Battle Plans"] == nil then E["Woodpaw Battle Plans"] = "Woodpaw Savaş Planları" end
if E["Woodpaw Gnoll Mane"] == nil then E["Woodpaw Gnoll Mane"] = "Woodpaw Gnoll Yelesi" end
if E["Wool Bandage"] == nil then E["Wool Bandage"] = "Yün Sargı" end
if E["Wool Cloth"] == nil then E["Wool Cloth"] = "Yün Kumaş" end
if E["Words of the High Chief"] == nil then E["Words of the High Chief"] = "Yüce Şefin Sözleri" end
if E["Worgen Fang"] == nil then E["Worgen Fang"] = "Worgen Dişi" end
if E["Worgen Skull"] == nil then E["Worgen Skull"] = "Worgen Kafatası" end
if E["Worn Dragonscale"] == nil then E["Worn Dragonscale"] = "Yıpranmış Ejderha Pulu" end
if E["Worn Leather Book"] == nil then E["Worn Leather Book"] = "Yıpranmış Deri Kitap" end
if E["Worn Parchment"] == nil then E["Worn Parchment"] = "Yıpranmış Parşömen" end
if E["Worn Stone Token"] == nil then E["Worn Stone Token"] = "Yıpranmış Taş Nişan" end
if E["Wrathtail Head"] == nil then E["Wrathtail Head"] = "Wrathtail Kafası" end
if E["Writ of Safe Passage"] == nil then E["Writ of Safe Passage"] = "Güvenli Geçiş Belgesi" end
if E["Writhing Haunt Cauldron Key"] == nil then E["Writhing Haunt Cauldron Key"] = "Writhing Haunt Kazanı Anahtarı" end
if E["Wushoolay's Mane"] == nil then E["Wushoolay's Mane"] = "Wushoolay'in Yelesi" end
if E["Xavian Water Sample"] == nil then E["Xavian Water Sample"] = "Xavian Su Örneği" end
if E["Xorothian Glyphs"] == nil then E["Xorothian Glyphs"] = "Xorothian Glifleri" end
if E["Xorothian Stardust"] == nil then E["Xorothian Stardust"] = "Xorothian Yıldız Tozu" end
if E["Xylem's Note"] == nil then E["Xylem's Note"] = "Xylem'in Notu" end
if E["Yagyin's Digest"] == nil then E["Yagyin's Digest"] = "Yagyin'in Özeti" end
if E["Yeh'kinya's Bramble"] == nil then E["Yeh'kinya's Bramble"] = "Yeh'kinya'nın Böğürtleni" end
if E["Yeh'kinya's Scroll"] == nil then E["Yeh'kinya's Scroll"] = "Yeh'kinya'nın Tomarı" end
if E["Yellow Hakkari Bijou"] == nil then E["Yellow Hakkari Bijou"] = "Sarı Hakkari Mücevheri" end
if E["Yellow Power Crystal"] == nil then E["Yellow Power Crystal"] = "Sarı Güç Kristali" end
if E["Yellow Punch Card"] == nil then E["Yellow Punch Card"] = "Sarı Delikli Kart" end
if E["Yeti Fur"] == nil then E["Yeti Fur"] = "Yeti Kürkü" end
if E["Young Crocolisk Skin"] == nil then E["Young Crocolisk Skin"] = "Genç Krokolisk Derisi" end
if E["Yowler's Paw"] == nil then E["Yowler's Paw"] = "Yowler'ın Pençesi" end
if E["Ysida's Locket"] == nil then E["Ysida's Locket"] = "Ysida'nın Madalyonu" end
if E["Zaeldarr's Head"] == nil then E["Zaeldarr's Head"] = "Zaeldarr'ın Kafası" end
if E["Zamah's Note"] == nil then E["Zamah's Note"] = "Zamah'ın Notu" end
if E["Zandalar Honor Token"] == nil then E["Zandalar Honor Token"] = "Zandalar Onur Nişanı" end
if E["Zandalar Signet of Might"] == nil then E["Zandalar Signet of Might"] = "Zandalar Kudret Mührü" end
if E["Zandalar Signet of Mojo"] == nil then E["Zandalar Signet of Mojo"] = "Zandalar Mojo Mührü" end
if E["Zandalar Signet of Serenity"] == nil then E["Zandalar Signet of Serenity"] = "Zandalar Dinginlik Mührü" end
if E["Zandalarian Shadow Talisman"] == nil then E["Zandalarian Shadow Talisman"] = "Zandalar Gölge Tılsımı" end
if E["Zanzil's Mixture"] == nil then E["Zanzil's Mixture"] = "Zanzil'in Karışımı" end
if E["Zargh's Meats"] == nil then E["Zargh's Meats"] = "Zargh'ın Etleri" end
if E["Zesty Clam Meat"] == nil then E["Zesty Clam Meat"] = "Baharatlı Midye Eti" end
if E["Ziata'jai Trophy"] == nil then E["Ziata'jai Trophy"] = "Ziata'jai Ganimeti" end
if E["Zinfizzlex's Portable Shredder Unit"] == nil then E["Zinfizzlex's Portable Shredder Unit"] = "Zinfizzlex'in Taşınabilir Shredder Ünitesi" end
if E["Zinge's Purchase Order"] == nil then E["Zinge's Purchase Order"] = "Zinge'nin Satın Alma Siparişi" end
if E["Zorbin's Ultra-Shrinker"] == nil then E["Zorbin's Ultra-Shrinker"] = "Zorbin'in Ultra Küçültücüsü" end
if E["Zraedus's Brew"] == nil then E["Zraedus's Brew"] = "Zraedus'un Demlemesi" end
if E["Zukk'ash Carapace"] == nil then E["Zukk'ash Carapace"] = "Zukk'ash Kabuğu" end
if E["Zul'Mamwe Trophy"] == nil then E["Zul'Mamwe Trophy"] = "Zul'Mamwe Ganimeti" end
if E["Zulian Coin"] == nil then E["Zulian Coin"] = "Zulian Sikkesi" end
if E["Zulian Mudskunk"] == nil then E["Zulian Mudskunk"] = "Zulian Çamur Kokarcası" end
if E["iCoke Gift Box Voucher"] == nil then E["iCoke Gift Box Voucher"] = "iCoke Hediye Kutusu Kuponu" end
if E["iCoke Prize Voucher"] == nil then E["iCoke Prize Voucher"] = "iCoke Ödül Kuponu" end
for _, i in ipairs({21028}) do I[i] = "500 Pound Chicken" end
for _, i in ipairs({5334}) do I[i] = "99-Year-Old Port" end
for _, i in ipairs({22930,22970}) do I[i] = "A Bloodstained Envelope" end
for _, i in ipairs({939}) do I[i] = "A Bloodstained Journal Page" end
for _, i in ipairs({9507}) do I[i] = "A Carefully-packed Crate" end
for _, i in ipairs({22945,22972}) do I[i] = "A Careworn Note" end
for _, i in ipairs({1358}) do I[i] = "A Clue to Sander's Treasure" end
for _, i in ipairs({22944,22973}) do I[i] = "A Crumpled Missive" end
for _, i in ipairs({11446}) do I[i] = "A Crumpled Up Note" end
for _, i in ipairs({18513}) do I[i] = "A Dull and Flat Elven Blade" end
for _, i in ipairs({889}) do I[i] = "A Dusty Unsent Letter" end
for _, i in ipairs({921}) do I[i] = "A Faded Journal Page" end
for _, i in ipairs({22723}) do I[i] = "A Letter from the Keeper of the Rolls" end
for _, i in ipairs({2188}) do I[i] = "A Letter to Grelin Whitebeard" end
for _, i in ipairs({2839}) do I[i] = "A Letter to Yvette" end
for _, i in ipairs({11116}) do I[i] = "A Mangled Journal" end
for _, i in ipairs({1381}) do I[i] = "A Mysterious Message" end
for _, i in ipairs({10664}) do I[i] = "A Note to Magus Rimtori" end
for _, i in ipairs({22946,22974}) do I[i] = "A Ragged Page" end
for _, i in ipairs({9329}) do I[i] = "A Short Note" end
for _, i in ipairs({9629}) do I[i] = "A Shrunken Head" end
for _, i in ipairs({2998}) do I[i] = "A Simple Compass" end
for _, i in ipairs({11107}) do I[i] = "A Small Pack" end
for _, i in ipairs({9325}) do I[i] = "A Small Stave" end
for _, i in ipairs({22948,22975}) do I[i] = "A Smudged Document" end
for _, i in ipairs({9307}) do I[i] = "A Sparkling Stone" end
for _, i in ipairs({2187}) do I[i] = "A Stack of Letters" end
for _, i in ipairs({742}) do I[i] = "A Sycamore Branch" end
for _, i in ipairs({3317}) do I[i] = "A Talking Head" end
for _, i in ipairs({916}) do I[i] = "A Torn Journal Page" end
for _, i in ipairs({22932,22977}) do I[i] = "A Torn Letter" end
for _, i in ipairs({1349}) do I[i] = "Abercrombie's Crate" end
for _, i in ipairs({20513}) do I[i] = "Abyssal Crest" end
for _, i in ipairs({20515}) do I[i] = "Abyssal Scepter" end
for _, i in ipairs({20514}) do I[i] = "Abyssal Signet" end
for _, i in ipairs({9440}) do I[i] = "Acceptable Basilisk Sample" end
for _, i in ipairs({9441}) do I[i] = "Acceptable Hyena Sample" end
for _, i in ipairs({9438}) do I[i] = "Acceptable Scorpid Sample" end
for _, i in ipairs({4407}) do I[i] = "Accurate Scope" end
for _, i in ipairs({5959}) do I[i] = "Acidic Venom Sac" end
for _, i in ipairs({4883}) do I[i] = "Admiral Proudmoore's Orders" end
for _, i in ipairs({2658}) do I[i] = "Ados Fragment" end
for _, i in ipairs({4392}) do I[i] = "Advanced Target Dummy" end
for _, i in ipairs({7567}) do I[i] = "Agamand Family Axe" end
for _, i in ipairs({7568}) do I[i] = "Agamand Family Dagger" end
for _, i in ipairs({7569}) do I[i] = "Agamand Family Mace" end
for _, i in ipairs({7566}) do I[i] = "Agamand Family Sword" end
for _, i in ipairs({4881}) do I[i] = "Aged Envelope" end
for _, i in ipairs({3862}) do I[i] = "Aged Gorilla Sinew" end
for _, i in ipairs({6249}) do I[i] = "Aged Kodo Hide" end
for _, i in ipairs({20402}) do I[i] = "Agent of Nozdormu" end
for _, i in ipairs({16283}) do I[i] = "Ahanu's Leather Goods" end
for _, i in ipairs({4029}) do I[i] = "Akiris Reed" end
for _, i in ipairs({20873}) do I[i] = "Alabaster Idol" end
for _, i in ipairs({3316}) do I[i] = "Alaric's Head" end
for _, i in ipairs({3318}) do I[i] = "Alaric's Remains" end
for _, i in ipairs({12467}) do I[i] = "Alien Egg" end
for _, i in ipairs({21436}) do I[i] = "Alliance Commendation Signet" end
for _, i in ipairs({22262}) do I[i] = "Alliance Gift Collection" end
for _, i in ipairs({4521}) do I[i] = "Alterac Granite" end
for _, i in ipairs({17642}) do I[i] = "Alterac Ram Hide" end
for _, i in ipairs({3505}) do I[i] = "Alterac Signet Ring" end
for _, i in ipairs({8932}) do I[i] = "Alterac Swiss" end
for _, i in ipairs({20560}) do I[i] = "Alterac Valley Mark of Honor" end
for _, i in ipairs({11231,11609}) do I[i] = "Altered Black Dragonflight Molt" end
for _, i in ipairs({5098}) do I[i] = "Altered Snapjaw Shell" end
for _, i in ipairs({4621}) do I[i] = "Ambassador Infernus' Bracer" end
for _, i in ipairs({17009}) do I[i] = "Ambassador Malcin's Head" end
for _, i in ipairs({1923}) do I[i] = "Ambassador's Satchel" end
for _, i in ipairs({20869}) do I[i] = "Amber Idol" end
for _, i in ipairs({20606}) do I[i] = "Amber Voodoo Feather" end
for _, i in ipairs({4809}) do I[i] = "Ambercorn" end
for _, i in ipairs({5623,18152}) do I[i] = "Amethyst Phial" end
for _, i in ipairs({4843}) do I[i] = "Amethyst Runestone" end
for _, i in ipairs({10755}) do I[i] = "Amulet of Allistarj" end
for _, i in ipairs({16787}) do I[i] = "Amulet of Draconic Subversion" end
for _, i in ipairs({10753}) do I[i] = "Amulet of Grol" end
for _, i in ipairs({10754}) do I[i] = "Amulet of Sevine" end
for _, i in ipairs({17757}) do I[i] = "Amulet of Spirits" end
for _, i in ipairs({17758}) do I[i] = "Amulet of Union" end
for _, i in ipairs({2794}) do I[i] = "An Old History Book" end
for _, i in ipairs({910}) do I[i] = "An Undelivered Letter" end
for _, i in ipairs({2874}) do I[i] = "An Unsent Letter" end
for _, i in ipairs({8052}) do I[i] = "An'Alleum Power Stone" end
for _, i in ipairs({5382}) do I[i] = "Anaya's Pendant" end
for _, i in ipairs({12402}) do I[i] = "Ancient Egg" end
for _, i in ipairs({5338}) do I[i] = "Ancient Moonstone Seal" end
for _, i in ipairs({18703}) do I[i] = "Ancient Petrified Leaf" end
for _, i in ipairs({21230}) do I[i] = "Ancient Qiraji Artifact" end
for _, i in ipairs({18707}) do I[i] = "Ancient Rune Etched Stave" end
for _, i in ipairs({5424}) do I[i] = "Ancient Statuette" end
for _, i in ipairs({12638}) do I[i] = "Andorhal Watch" end
for _, i in ipairs({7294}) do I[i] = "Andron's Ledger" end
for _, i in ipairs({10679}) do I[i] = "Andron's Note" end
for _, i in ipairs({20018}) do I[i] = "Angerclaw Grizzly Hide" end
for _, i in ipairs({12900}) do I[i] = "Annals of Darrowshire" end
for _, i in ipairs({1361}) do I[i] = "Another Clue to Sander's Treasure" end
for _, i in ipairs({22151}) do I[i] = "Anthion's Holy Water" end
for _, i in ipairs({17333}) do I[i] = "Aqual Quintessence" end
for _, i in ipairs({17114}) do I[i] = "Araj's Phylactery Shard" end
for _, i in ipairs({14610}) do I[i] = "Araj's Scarab" end
for _, i in ipairs({20559}) do I[i] = "Arathi Basin Mark of Honor" end
for _, i in ipairs({19725}) do I[i] = "Arathi Resource Crate" end
for _, i in ipairs({12363}) do I[i] = "Arkan Crystal" end
for _, i in ipairs({18171}) do I[i] = "Arkan Mantle of the Dawn" end
for _, i in ipairs({13320}) do I[i] = "Arkan Quickener" end
for _, i in ipairs({20085}) do I[i] = "Arkan Shard" end
for _, i in ipairs({20482}) do I[i] = "Arkan Sliver" end
for _, i in ipairs({12360}) do I[i] = "Arcanite Bar" end
for _, i in ipairs({18753}) do I[i] = "Arcanite Barding" end
for _, i in ipairs({21136}) do I[i] = "Arcanite Buoy" end
for _, i in ipairs({18330}) do I[i] = "Arcanum of Focus" end
for _, i in ipairs({18331}) do I[i] = "Arcanum of Protection" end
for _, i in ipairs({18329}) do I[i] = "Arcanum of Rapidity" end
for _, i in ipairs({18706}) do I[i] = "Arena Master" end
for _, i in ipairs({12844}) do I[i] = "Argent Dawn Valor Token" end
for _, i in ipairs({12925}) do I[i] = "Arikara Serpent Skin" end
for _, i in ipairs({17422}) do I[i] = "Armor Scraps" end
for _, i in ipairs({12884}) do I[i] = "Arnak's Hoof" end
for _, i in ipairs({8836}) do I[i] = "Arthas' Tears" end
for _, i in ipairs({18955}) do I[i] = "Artorius's Head" end
for _, i in ipairs({17310}) do I[i] = "Aspect of Neptulon" end
for _, i in ipairs({3668}) do I[i] = "Assassin's Contract" end
for _, i in ipairs({12564}) do I[i] = "Assassination Note" end
for _, i in ipairs({7231}) do I[i] = "Astor's Letter of Introduction" end
for _, i in ipairs({3515}) do I[i] = "Ataeric's Staff" end
for _, i in ipairs({6175}) do I[i] = "Atal'ai Artifact" end
for _, i in ipairs({11318}) do I[i] = "Atal'ai Haze" end
for _, i in ipairs({10466}) do I[i] = "Atal'ai Stone Circle" end
for _, i in ipairs({6288}) do I[i] = "Atal'ai Tablet" end
for _, i in ipairs({6287}) do I[i] = "Atal'ai Tablet Fragment" end
for _, i in ipairs({5383}) do I[i] = "Athrikus Narassin's Head" end
for _, i in ipairs({22737}) do I[i] = "Atiesh, Greatstaff of the Guardian" end
for _, i in ipairs({15884}) do I[i] = "Augustus' Receipt Book" end
for _, i in ipairs({12923}) do I[i] = "Awbee's Scale" end
for _, i in ipairs({12800}) do I[i] = "Azerothian Diamond" end
for _, i in ipairs({4527}) do I[i] = "Azure Agate" end
for _, i in ipairs({4752}) do I[i] = "Azure Feather" end
for _, i in ipairs({20866}) do I[i] = "Azure Idol" end
for _, i in ipairs({20022}) do I[i] = "Azure Key" end
for _, i in ipairs({7007}) do I[i] = "Backus' Phat Lewt" end
for _, i in ipairs({8646}) do I[i] = "Bad Egg" end
for _, i in ipairs({11955}) do I[i] = "Bag of Empty Ooze Containers" end
for _, i in ipairs({21041}) do I[i] = "Bag of Gold" end
for _, i in ipairs({3960}) do I[i] = "Bag of Water Elemental Bracers" end
for _, i in ipairs({11141}) do I[i] = "Bait" end
for _, i in ipairs({13935}) do I[i] = "Baked Salmon" end
for _, i in ipairs({3906}) do I[i] = "Balia'mah Trophy" end
for _, i in ipairs({4524}) do I[i] = "Balloo's Memorial" end
for _, i in ipairs({7227}) do I[i] = "Balnir Snapdragons" end
for _, i in ipairs({12301}) do I[i] = "Bamboo Cage Key" end
for _, i in ipairs({11843}) do I[i] = "Bank Voucher" end
for _, i in ipairs({21986}) do I[i] = "Banner of Provocation" end
for _, i in ipairs({5022}) do I[i] = "Barak's Head" end
for _, i in ipairs({5739}) do I[i] = "Barbaric Harness" end
for _, i in ipairs({4457}) do I[i] = "Barbecued Buzzard Wing" end
for _, i in ipairs({5084}) do I[i] = "Baron Longshore's Head" end
for _, i in ipairs({2548}) do I[i] = "Barrel of Barleybrew Scalder" end
for _, i in ipairs({15044}) do I[i] = "Barrel of Plagueland Termites" end
for _, i in ipairs({3085}) do I[i] = "Barrel of Shimmer Stout" end
for _, i in ipairs({2666}) do I[i] = "Barrel of Thunder Ale" end
for _, i in ipairs({5691}) do I[i] = "Barrow Key" end
for _, i in ipairs({6781}) do I[i] = "Bartleby's Mug" end
for _, i in ipairs({22734}) do I[i] = "Base of Atiesh" end
for _, i in ipairs({8394}) do I[i] = "Basilisk Brain" end
for _, i in ipairs({6929}) do I[i] = "Bath'rah's Parchment" end
for _, i in ipairs({5437}) do I[i] = "Bathran's Hair" end
for _, i in ipairs({4849}) do I[i] = "Battleboar Flank" end
for _, i in ipairs({4848}) do I[i] = "Battleboar Snout" end
for _, i in ipairs({3014}) do I[i] = "Battleworn Axe" end
for _, i in ipairs({12815}) do I[i] = "Beacon Torch" end
for _, i in ipairs({3173}) do I[i] = "Bear Meat" end
for _, i in ipairs({19228}) do I[i] = "Beasts Deck" end
for _, i in ipairs({16680}) do I[i] = "Beaststalker's Belt" end
for _, i in ipairs({16681}) do I[i] = "Beaststalker's Bindings" end
for _, i in ipairs({16675}) do I[i] = "Beaststalker's Boots" end
for _, i in ipairs({16677}) do I[i] = "Beaststalker's Cap" end
for _, i in ipairs({16676}) do I[i] = "Beaststalker's Gloves" end
for _, i in ipairs({16679}) do I[i] = "Beaststalker's Mantle" end
for _, i in ipairs({16678}) do I[i] = "Beaststalker's Pants" end
for _, i in ipairs({16674}) do I[i] = "Beaststalker's Tunic" end
for _, i in ipairs({4510}) do I[i] = "Befouled Bloodstone Orb" end
for _, i in ipairs({16408}) do I[i] = "Befouled Water Globe" end
for _, i in ipairs({5861}) do I[i] = "Beginnings of the Undead Threat" end
for _, i in ipairs({4650}) do I[i] = "Bel'dugur's Note" end
for _, i in ipairs({3711}) do I[i] = "Belamoore's Research Journal" end
for _, i in ipairs({5850}) do I[i] = "Belgrom's Sealed Note" end
for _, i in ipairs({3631}) do I[i] = "Bellygrub's Tusk" end
for _, i in ipairs({10682}) do I[i] = "Belnistrasz's Oathstone" end
for _, i in ipairs({16736}) do I[i] = "Belt of Valor" end
for _, i in ipairs({3255}) do I[i] = "Berard's Journal" end
for _, i in ipairs({981}) do I[i] = "Bernice's Necklace" end
for _, i in ipairs({16192}) do I[i] = "Besseleth's Fang" end
for _, i in ipairs({3251}) do I[i] = "Bethor's Potion" end
for _, i in ipairs({3250}) do I[i] = "Bethor's Scroll" end
for _, i in ipairs({7945}) do I[i] = "Big Black Mace" end
for _, i in ipairs({4394}) do I[i] = "Big Iron Bomb" end
for _, i in ipairs({12345}) do I[i] = "Bijou's Belongings" end
for _, i in ipairs({12770}) do I[i] = "Bijou's Information" end
for _, i in ipairs({12652}) do I[i] = "Bijou's Reconnaissance Report" end
for _, i in ipairs({16671}) do I[i] = "Bindings of Elements" end
for _, i in ipairs({18563,18564}) do I[i] = "Bindings of the Windseeker" end
for _, i in ipairs({7376}) do I[i] = "Bingles' Blastencapper" end
for _, i in ipairs({7347}) do I[i] = "Bingles' Cog Inverter" end
for _, i in ipairs({7346}) do I[i] = "Bingles' Hammer" end
for _, i in ipairs({7345}) do I[i] = "Bingles' Screwdriver" end
for _, i in ipairs({7343}) do I[i] = "Bingles' Wrench" end
for _, i in ipairs({11752}) do I[i] = "Black Blood of the Tormented" end
for _, i in ipairs({2788}) do I[i] = "Black Claw Stout" end
for _, i in ipairs({11754}) do I[i] = "Black Diamond" end
for _, i in ipairs({10575}) do I[i] = "Black Dragonflight Molt" end
for _, i in ipairs({15416}) do I[i] = "Black Dragonscale" end
for _, i in ipairs({16786}) do I[i] = "Black Dragonspawn Eye" end
for _, i in ipairs({4612}) do I[i] = "Black Drake's Heart" end
for _, i in ipairs({3406}) do I[i] = "Black Feather Quill" end
for _, i in ipairs({18629}) do I[i] = "Black Lodestone" end
for _, i in ipairs({18157}) do I[i] = "Black Moro'gai Gem" end
for _, i in ipairs({13328}) do I[i] = "Black Ram" end
for _, i in ipairs({5919}) do I[i] = "Blackened Iron Shield" end
for _, i in ipairs({3163}) do I[i] = "Blackened Skull" end
for _, i in ipairs({18987}) do I[i] = "Blackhand's Command" end
for _, i in ipairs({4615}) do I[i] = "Blacklash's Bindings" end
for _, i in ipairs({22138}) do I[i] = "Blackrock Bracer" end
for _, i in ipairs({11467}) do I[i] = "Blackrock Medallion" end
for _, i in ipairs({12341}) do I[i] = "Blackwood Fruit Sample" end
for _, i in ipairs({12342}) do I[i] = "Blackwood Grain Sample" end
for _, i in ipairs({12343}) do I[i] = "Blackwood Nut Sample" end
for _, i in ipairs({8392}) do I[i] = "Blasted Boar Lung" end
for _, i in ipairs({18792}) do I[i] = "Blessed Arcanite Barding" end
for _, i in ipairs({11503}) do I[i] = "Blood Amber" end
for _, i in ipairs({13140}) do I[i] = "Blood Red Key" end
for _, i in ipairs({5075}) do I[i] = "Blood Shard" end
for _, i in ipairs({12848}) do I[i] = "Blood Stained Pike" end
for _, i in ipairs({5402}) do I[i] = "Blood of Anacondra" end
for _, i in ipairs({5400}) do I[i] = "Blood of Cobrahn" end
for _, i in ipairs({12938}) do I[i] = "Blood of Heroes" end
for _, i in ipairs({13523}) do I[i] = "Blood of Innocents" end
for _, i in ipairs({20025}) do I[i] = "Blood of Morphaz" end
for _, i in ipairs({5401}) do I[i] = "Blood of Pythas" end
for _, i in ipairs({5403}) do I[i] = "Blood of Serpentis" end
for _, i in ipairs({16663}) do I[i] = "Blood of the Black Dragon Champion" end
for _, i in ipairs({11382}) do I[i] = "Blood of the Mountain" end
for _, i in ipairs({13546}) do I[i] = "Bloodbelly Fish" end
for _, i in ipairs({22434}) do I[i] = "Bloodcap" end
for _, i in ipairs({5204}) do I[i] = "Bloodfeather Belt" end
for _, i in ipairs({16190}) do I[i] = "Bloodfury Ripper's Remains" end
for _, i in ipairs({22094}) do I[i] = "Bloodkelp" end
for _, i in ipairs({11316}) do I[i] = "Bloodpetal" end
for _, i in ipairs({11315}) do I[i] = "Bloodpetal Sprout" end
for _, i in ipairs({11320}) do I[i] = "Bloodpetal Zapper" end
for _, i in ipairs({3920}) do I[i] = "Bloodsail Charts" end
for _, i in ipairs({3921}) do I[i] = "Bloodsail Orders" end
for _, i in ipairs({19706}) do I[i] = "Bloodscalp Coin" end
for _, i in ipairs({1519}) do I[i] = "Bloodscalp Ear" end
for _, i in ipairs({6850}) do I[i] = "Bloodscalp Scalp" end
for _, i in ipairs({3901}) do I[i] = "Bloodscalp Tusk" end
for _, i in ipairs({20610}) do I[i] = "Bloodshot Spider Eye" end
for _, i in ipairs({7668}) do I[i] = "Bloodstained Journal" end
for _, i in ipairs({4495}) do I[i] = "Bloodstone Amulet" end
for _, i in ipairs({6928}) do I[i] = "Bloodstone Choker" end
for _, i in ipairs({3689}) do I[i] = "Bloodstone Marble" end
for _, i in ipairs({3688}) do I[i] = "Bloodstone Oval" end
for _, i in ipairs({3744}) do I[i] = "Bloodstone Pendant" end
for _, i in ipairs({3690}) do I[i] = "Bloodstone Shard" end
for _, i in ipairs({3691}) do I[i] = "Bloodstone Wedge" end
for _, i in ipairs({20614}) do I[i] = "Bloodvenom Essence" end
for _, i in ipairs({3915}) do I[i] = "Bloody Bone Necklace" end
for _, i in ipairs({19708}) do I[i] = "Blue Hakkari Bijou" end
for _, i in ipairs({18155}) do I[i] = "Blue Moro'gai Gem" end
for _, i in ipairs({4611}) do I[i] = "Blue Pearl" end
for _, i in ipairs({11184}) do I[i] = "Blue Power Crystal" end
for _, i in ipairs({9282}) do I[i] = "Blue Punch Card" end
for _, i in ipairs({12361}) do I[i] = "Blue Sapphire" end
for _, i in ipairs({21137}) do I[i] = "Blue Scepter Shard" end
for _, i in ipairs({20607}) do I[i] = "Blue Voodoo Feather" end
for _, i in ipairs({12524}) do I[i] = "Blue-feathered Amulet" end
for _, i in ipairs({12558}) do I[i] = "Blue-feathered Necklace" end
for _, i in ipairs({5876}) do I[i] = "Blueleaf Tuber" end
for _, i in ipairs({7272}) do I[i] = "Bolt Charged Bramble" end
for _, i in ipairs({14048}) do I[i] = "Bolt of Runecloth" end
for _, i in ipairs({2997}) do I[i] = "Bolt of Woolen Cloth" end
for _, i in ipairs({11368}) do I[i] = "Bolvar's Decree" end
for _, i in ipairs({13159}) do I[i] = "Bone Dust" end
for _, i in ipairs({22526}) do I[i] = "Bone Fragments" end
for _, i in ipairs({20864}) do I[i] = "Bone Scarab" end
for _, i in ipairs({4649}) do I[i] = "Bonegrip's Note" end
for _, i in ipairs({2161}) do I[i] = "Book from Sven's Farm" end
for _, i in ipairs({11169}) do I[i] = "Book of Aquor" end
for _, i in ipairs({18261}) do I[i] = "Book of Incantations" end
for _, i in ipairs({15803}) do I[i] = "Book of the Ancients" end
for _, i in ipairs({2795}) do I[i] = "Book: Stresses of Iron" end
for _, i in ipairs({5352}) do I[i] = "Book: The Powers Below" end
for _, i in ipairs({16670}) do I[i] = "Boots of Elements" end
for _, i in ipairs({16734}) do I[i] = "Boots of Valor" end
for _, i in ipairs({5440}) do I[i] = "Bottle of Disease" end
for _, i in ipairs({1942}) do I[i] = "Bottle of Moonshine" end
for _, i in ipairs({1451}) do I[i] = "Bottle of Zombie Juice" end
for _, i in ipairs({18779}) do I[i] = "Bottom Half of Advanced Armorsmithing: Volume I" end
for _, i in ipairs({18781}) do I[i] = "Bottom Half of Advanced Armorsmithing: Volume II" end
for _, i in ipairs({18783}) do I[i] = "Bottom Half of Advanced Armorsmithing: Volume III" end
for _, i in ipairs({7500}) do I[i] = "Bottom of Gelkak's Key" end
for _, i in ipairs({10695}) do I[i] = "Box of Empty Vials" end
for _, i in ipairs({3715}) do I[i] = "Bracers of Earth Binding" end
for _, i in ipairs({4628}) do I[i] = "Bracers of Rock Binding" end
for _, i in ipairs({16735}) do I[i] = "Bracers of Valor" end
for _, i in ipairs({5461}) do I[i] = "Branch of Cenarius" end
for _, i in ipairs({20461}) do I[i] = "Brann Bronzebeard's Lost Letter" end
for _, i in ipairs({1006}) do I[i] = "Brass Collar" end
for _, i in ipairs({22049,22050,22051,22052,22056}) do I[i] = "Brazier of Beckoning" end
for _, i in ipairs({22057}) do I[i] = "Brazier of Invocation" end
for _, i in ipairs({16730}) do I[i] = "Breastplate of Valor" end
for _, i in ipairs({7081}) do I[i] = "Breath of Wind" end
for _, i in ipairs({14104}) do I[i] = "Brightcloth Pants" end
for _, i in ipairs({12607}) do I[i] = "Brilliant Chromatic Scale" end
for _, i in ipairs({9362}) do I[i] = "Brilliant Gold Ring" end
for _, i in ipairs({22228}) do I[i] = "Brilliant Sword of Zealotry" end
for _, i in ipairs({4850}) do I[i] = "Bristleback Attack Plans" end
for _, i in ipairs({4770}) do I[i] = "Bristleback Belt" end
for _, i in ipairs({5085}) do I[i] = "Bristleback Quilboar Tusk" end
for _, i in ipairs({16310}) do I[i] = "Brock's List" end
for _, i in ipairs({3909}) do I[i] = "Broken Armor of Ana'thek" end
for _, i in ipairs({5446}) do I[i] = "Broken Elemental Bracer" end
for _, i in ipairs({11142}) do I[i] = "Broken Samophlange" end
for _, i in ipairs({11111}) do I[i] = "Broken Sprite Darter Egg" end
for _, i in ipairs({6083}) do I[i] = "Broken Tears" end
for _, i in ipairs({4703}) do I[i] = "Broken Tools" end
for _, i in ipairs({11146}) do I[i] = "Broken and Battered Samophlange" end
for _, i in ipairs({7958}) do I[i] = "Bronze Battle Axe" end
for _, i in ipairs({4753}) do I[i] = "Bronze Feather" end
for _, i in ipairs({7957}) do I[i] = "Bronze Greatsword" end
for _, i in ipairs({19713}) do I[i] = "Bronze Hakkari Bijou" end
for _, i in ipairs({20861}) do I[i] = "Bronze Scarab" end
for _, i in ipairs({4371}) do I[i] = "Bronze Tube" end
for _, i in ipairs({7956}) do I[i] = "Bronze Warhammer" end
for _, i in ipairs({12283}) do I[i] = "Broodling Essence" end
for _, i in ipairs({19803}) do I[i] = "Brownell's Blue Striped Racer" end
for _, i in ipairs({4028}) do I[i] = "Bundle of Akiris Reeds" end
for _, i in ipairs({6193}) do I[i] = "Bundle of Atal'ai Artifacts" end
for _, i in ipairs({743}) do I[i] = "Bundle of Charred Oak" end
for _, i in ipairs({3347}) do I[i] = "Bundle of Crocolisk Skins" end
for _, i in ipairs({7626}) do I[i] = "Bundle of Furs" end
for _, i in ipairs({20020}) do I[i] = "Bundle of Goods" end
for _, i in ipairs({16282}) do I[i] = "Bundle of Hides" end
for _, i in ipairs({15314}) do I[i] = "Bundle of Relics" end
for _, i in ipairs({16783}) do I[i] = "Bundle of Reports" end
for _, i in ipairs({13872}) do I[i] = "Bundle of Wood" end
for _, i in ipairs({4859}) do I[i] = "Burning Blade Medallion" end
for _, i in ipairs({6844}) do I[i] = "Burning Blood" end
for _, i in ipairs({4479}) do I[i] = "Burning Charm" end
for _, i in ipairs({11751}) do I[i] = "Burning Essence" end
for _, i in ipairs({6436}) do I[i] = "Burning Gem" end
for _, i in ipairs({4483}) do I[i] = "Burning Key" end
for _, i in ipairs({6845}) do I[i] = "Burning Rock" end
for _, i in ipairs({3499}) do I[i] = "Burnished Gold Key" end
for _, i in ipairs({7847}) do I[i] = "Buzzard Gizzard" end
for _, i in ipairs({3404}) do I[i] = "Buzzard Wing" end
for _, i in ipairs({9258}) do I[i] = "Byltan Essence" end
for _, i in ipairs({4559}) do I[i] = "CHU's QUEST ITEM" end
for _, i in ipairs({12384}) do I[i] = "Cache of Mau'ari" end
for _, i in ipairs({8073}) do I[i] = "Cache of Zanzil's Altered Mixture" end
for _, i in ipairs({11583}) do I[i] = "Cactus Apple" end
for _, i in ipairs({12263}) do I[i] = "Caged Worg Pup" end
for _, i in ipairs({18643}) do I[i] = "Cairne's Hoofprint" end
for _, i in ipairs({8723}) do I[i] = "Caliph Scorpidsting's Head" end
for _, i in ipairs({22595}) do I[i] = "Call to Arms Announcement" end
for _, i in ipairs({2113}) do I[i] = "Calor's Note" end
for _, i in ipairs({19020}) do I[i] = "Camp Mojache Zukk'ash Report" end
for _, i in ipairs({14650}) do I[i] = "Camp Narache Gift Voucher" end
for _, i in ipairs({3080}) do I[i] = "Candle of Beckoning" end
for _, i in ipairs({7308}) do I[i] = "Cantation of Manifestation" end
for _, i in ipairs({4870}) do I[i] = "Canvas Scraps" end
for _, i in ipairs({1357}) do I[i] = "Captain Sander's Treasure Map" end
for _, i in ipairs({5882}) do I[i] = "Captain's Documents" end
for _, i in ipairs({20929}) do I[i] = "Carapace of the Old God" end
for _, i in ipairs({4098}) do I[i] = "Carefully Folded Note" end
for _, i in ipairs({21921}) do I[i] = "Carefully Penned Note" end
for _, i in ipairs({22264}) do I[i] = "Carefully Written Letter" end
for _, i in ipairs({17118}) do I[i] = "Carton of Mystery Meat" end
for _, i in ipairs({2636}) do I[i] = "Carved Stone Idol" end
for _, i in ipairs({4610}) do I[i] = "Carved Stone Urn" end
for _, i in ipairs({18591}) do I[i] = "Case of Blood" end
for _, i in ipairs({6812}) do I[i] = "Case of Elunite" end
for _, i in ipairs({2696}) do I[i] = "Cask of Evershine" end
for _, i in ipairs({1941}) do I[i] = "Cask of Merlot" end
for _, i in ipairs({6843}) do I[i] = "Cask of Scalder" end
for _, i in ipairs({3086}) do I[i] = "Cask of Shimmer Stout" end
for _, i in ipairs({4027}) do I[i] = "Catelyn's Blade" end
for _, i in ipairs({5097}) do I[i] = "Cats Eye Emerald" end
for _, i in ipairs({17703}) do I[i] = "Celebrian Diamond" end
for _, i in ipairs({17702}) do I[i] = "Celebrian Rod" end
for _, i in ipairs({11511}) do I[i] = "Cenarion Beacon" end
for _, i in ipairs({20802}) do I[i] = "Cenarion Combat Badge" end
for _, i in ipairs({20800}) do I[i] = "Cenarion Logistics Badge" end
for _, i in ipairs({15710}) do I[i] = "Cenarion Lunardust" end
for _, i in ipairs({15208}) do I[i] = "Cenarion Moondust" end
for _, i in ipairs({11516}) do I[i] = "Cenarion Plant Salve" end
for _, i in ipairs({20801}) do I[i] = "Cenarion Tactical Badge" end
for _, i in ipairs({5030}) do I[i] = "Centaur Bracers" end
for _, i in ipairs({6067}) do I[i] = "Centaur Ear" end
for _, i in ipairs({8587}) do I[i] = "Centipaar Insect Parts" end
for _, i in ipairs({10455}) do I[i] = "Chained Essence of Eranikus" end
for _, i in ipairs({4645}) do I[i] = "Chains of Hematus" end
for _, i in ipairs({18950}) do I[i] = "Chambermaid Pillaclencher's Pillow" end
for _, i in ipairs({19881}) do I[i] = "Channeler's Head" end
for _, i in ipairs({7249}) do I[i] = "Charged Rift Gem" end
for _, i in ipairs({18749}) do I[i] = "Charger's Lost Soul" end
for _, i in ipairs({18799}) do I[i] = "Charger's Redeemed Soul" end
for _, i in ipairs({6839}) do I[i] = "Charred Horn" end
for _, i in ipairs({5092}) do I[i] = "Charred Razormane Wand" end
for _, i in ipairs({4926}) do I[i] = "Chen's Empty Keg" end
for _, i in ipairs({7247}) do I[i] = "Chest of Containment Coffers" end
for _, i in ipairs({10459}) do I[i] = "Chief Sharptusk Thornmantle's Head" end
for _, i in ipairs({2476}) do I[i] = "Chilled Basilisk Haunch" end
for _, i in ipairs({12623}) do I[i] = "Chillwind Meat" end
for _, i in ipairs({21024}) do I[i] = "Chimaerok Tenderloin" end
for _, i in ipairs({2561}) do I[i] = "Chok'sul's Head" end
for _, i in ipairs({12871}) do I[i] = "Chromatic Carapace" end
for _, i in ipairs({18182}) do I[i] = "Chromatic Mantle of the Dawn" end
for _, i in ipairs({3926}) do I[i] = "Chucky's Huge Ring" end
for _, i in ipairs({769}) do I[i] = "Chunk of Boar Meat" end
for _, i in ipairs({21989}) do I[i] = "Cinder of Cynders" end
for _, i in ipairs({3864}) do I[i] = "Citrine" end
for _, i in ipairs({8683}) do I[i] = "Clara's Fresh Apple" end
for _, i in ipairs({6145}) do I[i] = "Clarice's Pendant" end
for _, i in ipairs({5690}) do I[i] = "Claw Key" end
for _, i in ipairs({20863}) do I[i] = "Clay Scarab" end
for _, i in ipairs({12642}) do I[i] = "Cleansed Infernal Orb" end
for _, i in ipairs({5218}) do I[i] = "Cleansed Timberling Heart" end
for _, i in ipairs({3521}) do I[i] = "Cleverly Encrypted Letter" end
for _, i in ipairs({12349}) do I[i] = "Cliffspring River Sample" end
for _, i in ipairs({13507}) do I[i] = "Cliffwatcher Longhorn Report" end
for _, i in ipairs({2724}) do I[i] = "Cloth Request" end
for _, i in ipairs({5869}) do I[i] = "Cloven Hoof" end
for _, i in ipairs({15448}) do I[i] = "Coagulated Rot" end
for _, i in ipairs({3857}) do I[i] = "Coal" end
for _, i in ipairs({2320}) do I[i] = "Coarse Thread" end
for _, i in ipairs({3240}) do I[i] = "Coarse Weightstone" end
for _, i in ipairs({17693}) do I[i] = "Coated Cerulean Vial" end
for _, i in ipairs({18357}) do I[i] = "Codex of Defense" end
for _, i in ipairs({4846}) do I[i] = "Cog #5" end
for _, i in ipairs({16667}) do I[i] = "Coif of Elements" end
for _, i in ipairs({21100}) do I[i] = "Coin of Ancestry" end
for _, i in ipairs({14647}) do I[i] = "Coldridge Valley Gift Voucher" end
for _, i in ipairs({17542}) do I[i] = "Coldtooth Supplies" end
for _, i in ipairs({12241}) do I[i] = "Collected Dragon Egg" end
for _, i in ipairs({12287}) do I[i] = "Collectronic Module" end
for _, i in ipairs({21833}) do I[i] = "Cologne Bottle" end
for _, i in ipairs({21534}) do I[i] = "Colossus of Ashi's Husk" end
for _, i in ipairs({21535}) do I[i] = "Colossus of Regal's Husk" end
for _, i in ipairs({21533}) do I[i] = "Colossus of Zora's Husk" end
for _, i in ipairs({6313}) do I[i] = "Comar's Heart" end
for _, i in ipairs({21246,21749}) do I[i] = "Combat Task Briefing I" end
for _, i in ipairs({21247,21750}) do I[i] = "Combat Task Briefing II" end
for _, i in ipairs({20942}) do I[i] = "Combat Task Briefing III" end
for _, i in ipairs({21248}) do I[i] = "Combat Task Briefing IV" end
for _, i in ipairs({21253}) do I[i] = "Combat Task Briefing IX" end
for _, i in ipairs({21249}) do I[i] = "Combat Task Briefing V" end
for _, i in ipairs({21250}) do I[i] = "Combat Task Briefing VI" end
for _, i in ipairs({21251}) do I[i] = "Combat Task Briefing VII" end
for _, i in ipairs({21252}) do I[i] = "Combat Task Briefing VIII" end
for _, i in ipairs({21255}) do I[i] = "Combat Task Briefing X" end
for _, i in ipairs({21256}) do I[i] = "Combat Task Briefing XI" end
for _, i in ipairs({20941}) do I[i] = "Combat Task Briefing XII" end
for _, i in ipairs({1356}) do I[i] = "Commendation - Elwynn Forest" end
for _, i in ipairs({5535}) do I[i] = "Compendium of the Fallen" end
for _, i in ipairs({9570}) do I[i] = "Consecrated Letter" end
for _, i in ipairs({9563}) do I[i] = "Consecrated Rune" end
for _, i in ipairs({5089}) do I[i] = "Console Key" end
for _, i in ipairs({5088}) do I[i] = "Control Console Operating Manual" end
for _, i in ipairs({2845}) do I[i] = "Copper Axe" end
for _, i in ipairs({2840}) do I[i] = "Copper Bar" end
for _, i in ipairs({2851}) do I[i] = "Copper Chain Belt" end
for _, i in ipairs({4363}) do I[i] = "Copper Modulator" end
for _, i in ipairs({16673}) do I[i] = "Cord of Elements" end
for _, i in ipairs({18412}) do I[i] = "Core Fragment" end
for _, i in ipairs({17012}) do I[i] = "Core Leather" end
for _, i in ipairs({7075}) do I[i] = "Core of Earth" end
for _, i in ipairs({22527}) do I[i] = "Core of Elements" end
for _, i in ipairs({4613}) do I[i] = "Corroded Black Box" end
for _, i in ipairs({5664}) do I[i] = "Corroded Shrapnel" end
for _, i in ipairs({5681}) do I[i] = "Corrosive Sap" end
for _, i in ipairs({7812}) do I[i] = "Corrupt Manifestation's Bracers" end
for _, i in ipairs({12907}) do I[i] = "Corrupt Moonwell Water" end
for _, i in ipairs({5952}) do I[i] = "Corrupted Brain Stem" end
for _, i in ipairs({12234}) do I[i] = "Corrupted Felwood Sample" end
for _, i in ipairs({5389}) do I[i] = "Corrupted Furbolg Totem" end
for _, i in ipairs({6995}) do I[i] = "Corrupted Kor Gem" end
for _, i in ipairs({11515}) do I[i] = "Corrupted Soul Shard" end
for _, i in ipairs({12843}) do I[i] = "Corruptor's Scourgestone" end
for _, i in ipairs({4056}) do I[i] = "Cortello's Riddle" end
for _, i in ipairs({4802}) do I[i] = "Cougar Claws" end
for _, i in ipairs({5585}) do I[i] = "Courser Eye" end
for _, i in ipairs({5738}) do I[i] = "Covert Ops Pack" end
for _, i in ipairs({5737}) do I[i] = "Covert Ops Plans: Alpha & Beta" end
for _, i in ipairs({6166}) do I[i] = "Coyote Jawbone" end
for _, i in ipairs({5851}) do I[i] = "Cozzle's Key" end
for _, i in ipairs({10651}) do I[i] = "Cracked Arkan Focusing Crystal" end
for _, i in ipairs({22949}) do I[i] = "Cracked Necrotic Crystal" end
for _, i in ipairs({5877}) do I[i] = "Cracked Silithid Carapace" end
for _, i in ipairs({1352}) do I[i] = "Cracked Skull Mortar" end
for _, i in ipairs({22609}) do I[i] = "Craftsman's Writ - Brightcloth Pants" end
for _, i in ipairs({22600}) do I[i] = "Craftsman's Writ - Dense Weightstone" end
for _, i in ipairs({22621}) do I[i] = "Craftsman's Writ - Flask of Petrification" end
for _, i in ipairs({22615}) do I[i] = "Craftsman's Writ - Gnomish Battle Chicken" end
for _, i in ipairs({22613}) do I[i] = "Craftsman's Writ - Goblin Sapper Charge" end
for _, i in ipairs({22620}) do I[i] = "Craftsman's Writ - Greater Arkan Protection Potion" end
for _, i in ipairs({22603}) do I[i] = "Craftsman's Writ - Huge Thorium Battleaxe" end
for _, i in ipairs({22601}) do I[i] = "Craftsman's Writ - Imperial Plate Chest" end
for _, i in ipairs({22624}) do I[i] = "Craftsman's Writ - Lightning Eel" end
for _, i in ipairs({22618}) do I[i] = "Craftsman's Writ - Major Healing Potion" end
for _, i in ipairs({22617}) do I[i] = "Craftsman's Writ - Major Mana Potion" end
for _, i in ipairs({22623}) do I[i] = "Craftsman's Writ - Plated Armorfish" end
for _, i in ipairs({22604}) do I[i] = "Craftsman's Writ - Radiant Circlet" end
for _, i in ipairs({22606}) do I[i] = "Craftsman's Writ - Rugged Armor Kit" end
for _, i in ipairs({22611}) do I[i] = "Craftsman's Writ - Runecloth Bag" end
for _, i in ipairs({22610}) do I[i] = "Craftsman's Writ - Runecloth Boots" end
for _, i in ipairs({22612}) do I[i] = "Craftsman's Writ - Runecloth Robe" end
for _, i in ipairs({22608}) do I[i] = "Craftsman's Writ - Runic Leather Pants" end
for _, i in ipairs({22622}) do I[i] = "Craftsman's Writ - Stonescale Eel" end
for _, i in ipairs({22614}) do I[i] = "Craftsman's Writ - Thorium Grenade" end
for _, i in ipairs({22616}) do I[i] = "Craftsman's Writ - Thorium Tube" end
for _, i in ipairs({22602}) do I[i] = "Craftsman's Writ - Volcanic Hammer" end
for _, i in ipairs({22607}) do I[i] = "Craftsman's Writ - Wicked Leather Belt" end
for _, i in ipairs({22605}) do I[i] = "Craftsman's Writ - Wicked Leather Headband" end
for _, i in ipairs({2886}) do I[i] = "Crag Boar Rib" end
for _, i in ipairs({7846}) do I[i] = "Crag Coyote Fang" end
for _, i in ipairs({5880}) do I[i] = "Crate With Holes" end
for _, i in ipairs({5849}) do I[i] = "Crate of Crash Helmets" end
for _, i in ipairs({11113}) do I[i] = "Crate of Foodstuffs" end
for _, i in ipairs({15848}) do I[i] = "Crate of Ghost Magnets" end
for _, i in ipairs({9462}) do I[i] = "Crate of Grimtotem Horns" end
for _, i in ipairs({1284}) do I[i] = "Crate of Horseshoes" end
for _, i in ipairs({7646}) do I[i] = "Crate of Inn Supplies" end
for _, i in ipairs({2712}) do I[i] = "Crate of Lightforge Ingots" end
for _, i in ipairs({6091}) do I[i] = "Crate of Power Stones" end
for _, i in ipairs({5385}) do I[i] = "Crawler Leg" end
for _, i in ipairs({4888}) do I[i] = "Crawler Mucus" end
for _, i in ipairs({21920}) do I[i] = "Creased Letter" end
for _, i in ipairs({3477}) do I[i] = "Creeper Ichor" end
for _, i in ipairs({4481}) do I[i] = "Cresting Charm" end
for _, i in ipairs({4484}) do I[i] = "Cresting Key" end
for _, i in ipairs({13351}) do I[i] = "Crimson Hammersmith's Apron" end
for _, i in ipairs({1081}) do I[i] = "Crisp Spider Meat" end
for _, i in ipairs({2924}) do I[i] = "Crocolisk Meat" end
for _, i in ipairs({2925}) do I[i] = "Crocolisk Skin" end
for _, i in ipairs({2939}) do I[i] = "Crocolisk Tear" end
for _, i in ipairs({12708}) do I[i] = "Crossroads' Supply Crates" end
for _, i in ipairs({3554}) do I[i] = "Crown of Will" end
for _, i in ipairs({20489}) do I[i] = "Crown of the Council" end
for _, i in ipairs({6079}) do I[i] = "Crude Charm" end
for _, i in ipairs({2611}) do I[i] = "Crude Flint" end
for _, i in ipairs({6069}) do I[i] = "Crudely Dried Meat" end
for _, i in ipairs({12842}) do I[i] = "Crudely-written Log" end
for _, i in ipairs({4519}) do I[i] = "Crumpled Scroll Fragment" end
for _, i in ipairs({5451}) do I[i] = "Crushed Elemental Bracer" end
for _, i in ipairs({22525}) do I[i] = "Crypt Fiend Parts" end
for _, i in ipairs({11566}) do I[i] = "Crystal Charge" end
for _, i in ipairs({11563}) do I[i] = "Crystal Force" end
for _, i in ipairs({1256}) do I[i] = "Crystal Kelp Frond" end
for _, i in ipairs({5185}) do I[i] = "Crystal Phial" end
for _, i in ipairs({11482}) do I[i] = "Crystal Pylon User's Manual" end
for _, i in ipairs({11562}) do I[i] = "Crystal Restore" end
for _, i in ipairs({20862}) do I[i] = "Crystal Scarab" end
for _, i in ipairs({11567}) do I[i] = "Crystal Spire" end
for _, i in ipairs({20465}) do I[i] = "Crystal Unlocking Mechanism" end
for _, i in ipairs({11564}) do I[i] = "Crystal Ward" end
for _, i in ipairs({11565}) do I[i] = "Crystal Yield" end
for _, i in ipairs({13347}) do I[i] = "Crystal of Zin-Malor" end
for _, i in ipairs({5675}) do I[i] = "Crystalized Scales" end
for _, i in ipairs({10714}) do I[i] = "Crystallized Azsharite" end
for _, i in ipairs({10712}) do I[i] = "Cuely's Elixir" end
for _, i in ipairs({9265}) do I[i] = "Cuergo's Hidden Treasure" end
for _, i in ipairs({9275}) do I[i] = "Cuergo's Key" end
for _, i in ipairs({9254}) do I[i] = "Cuergo's Treasure Map" end
for _, i in ipairs({15826}) do I[i] = "Curative Animal Salve" end
for _, i in ipairs({15407}) do I[i] = "Cured Rugged Hide" end
for _, i in ipairs({11105}) do I[i] = "Curled Map Parchment" end
for _, i in ipairs({2944}) do I[i] = "Cursed Eye of Paleth" end
for _, i in ipairs({7425}) do I[i] = "Cyrik's Head" end
for _, i in ipairs({11613}) do I[i] = "DEBUG Samophlange Manual Cover" end
for _, i in ipairs({1325}) do I[i] = "Daffodil Bouquet" end
for _, i in ipairs({3509}) do I[i] = "Daggerspine Scale" end
for _, i in ipairs({5544}) do I[i] = "Dal Bloodclaw's Skull" end
for _, i in ipairs({7293}) do I[i] = "Dalaran Mana Gem" end
for _, i in ipairs({3354}) do I[i] = "Dalaran Pendant" end
for _, i in ipairs({7309}) do I[i] = "Dalaran Status Report" end
for _, i in ipairs({6312}) do I[i] = "Dalin's Heart" end
for _, i in ipairs({12739}) do I[i] = "Dalson Cabinet Key" end
for _, i in ipairs({12738}) do I[i] = "Dalson Outhouse Key" end
for _, i in ipairs({13195}) do I[i] = "Dalson's Tears Cauldron Key" end
for _, i in ipairs({5447}) do I[i] = "Damaged Elemental Bracer" end
for _, i in ipairs({16790}) do I[i] = "Damp Note" end
for _, i in ipairs({3082}) do I[i] = "Dargol's Skull" end
for _, i in ipairs({11325}) do I[i] = "Dark Iron Ale Mug" end
for _, i in ipairs({11371}) do I[i] = "Dark Iron Bar" end
for _, i in ipairs({11468}) do I[i] = "Dark Iron Fanny Pack" end
for _, i in ipairs({11370}) do I[i] = "Dark Iron Ore" end
for _, i in ipairs({18943}) do I[i] = "Dark Iron Pillow" end
for _, i in ipairs({18945}) do I[i] = "Dark Iron Residue" end
for _, i in ipairs({22528}) do I[i] = "Dark Iron Scraps" end
for _, i in ipairs({6847}) do I[i] = "Dark Iron Script" end
for _, i in ipairs({6490}) do I[i] = "Dark Parchment" end
for _, i in ipairs({20520}) do I[i] = "Dark Rune" end
for _, i in ipairs({2858}) do I[i] = "Darkhound Blood" end
for _, i in ipairs({19182}) do I[i] = "Darkmoon Faire Prize Ticket" end
for _, i in ipairs({18880}) do I[i] = "Darkreaver's Head" end
for _, i in ipairs({12238}) do I[i] = "Darkshore Grouper" end
for _, i in ipairs({3157}) do I[i] = "Darksoul Shackle" end
for _, i in ipairs({20495}) do I[i] = "Darkspear Gumdrop" end
for _, i in ipairs({18146}) do I[i] = "Darkspear Troll Mojo" end
for _, i in ipairs({12358}) do I[i] = "Darkstone Tablet" end
for _, i in ipairs({20496}) do I[i] = "Darnassus Marzipan" end
for _, i in ipairs({3701}) do I[i] = "Darthalia's Sealed Commendation" end
for _, i in ipairs({5462}) do I[i] = "Dartol's Rod of Transformation" end
for _, i in ipairs({12954}) do I[i] = "Davil's Libram" end
for _, i in ipairs({12368}) do I[i] = "Dawn's Gambit" end
for _, i in ipairs({6783}) do I[i] = "Dead-tooth's Key" end
for _, i in ipairs({4369}) do I[i] = "Deadly Blunderbuss" end
for _, i in ipairs({5945}) do I[i] = "Deadmire's Tooth" end
for _, i in ipairs({21377}) do I[i] = "Deadwood Headdress Feather" end
for _, i in ipairs({20741}) do I[i] = "Deadwood Ritual Totem" end
for _, i in ipairs({5270}) do I[i] = "Death Cap" end
for _, i in ipairs({20385}) do I[i] = "Deathclasp's Pincer" end
for _, i in ipairs({14651}) do I[i] = "Deathknell Gift Voucher" end
for _, i in ipairs({3252}) do I[i] = "Deathstalker Report" end
for _, i in ipairs({20405}) do I[i] = "Decoded Tablet Transcription" end
for _, i in ipairs({3518}) do I[i] = "Decrypted Letter" end
for _, i in ipairs({4429}) do I[i] = "Deepfury's Orders" end
for _, i in ipairs({5570}) do I[i] = "Deepmoss Egg" end
for _, i in ipairs({8150}) do I[i] = "Deeprock Salt" end
for _, i in ipairs({6082}) do I[i] = "Deepstrider Tumor" end
for _, i in ipairs({5918}) do I[i] = "Defiant Orc Head" end
for _, i in ipairs({5947}) do I[i] = "Defias Docket" end
for _, i in ipairs({6846}) do I[i] = "Defias Script" end
for _, i in ipairs({7675}) do I[i] = "Defias Shipping Schedule" end
for _, i in ipairs({7923}) do I[i] = "Defias Tower Key" end
for _, i in ipairs({7269}) do I[i] = "Deino's Flask" end
for _, i in ipairs({3234}) do I[i] = "Deliah's Ring" end
for _, i in ipairs({16006}) do I[i] = "Delicate Arcanite Converter" end
for _, i in ipairs({5802}) do I[i] = "Delicate Car Parts" end
for _, i in ipairs({7674}) do I[i] = "Delivery to Mathias" end
for _, i in ipairs({13542}) do I[i] = "Demon Box" end
for _, i in ipairs({12849}) do I[i] = "Demon Kissed Sack" end
for _, i in ipairs({14523}) do I[i] = "Demon Pick" end
for _, i in ipairs({4854}) do I[i] = "Demon Scarred Cloak" end
for _, i in ipairs({21144}) do I[i] = "Demon Summoning Torch" end
for _, i in ipairs({15992}) do I[i] = "Dense Blasting Powder" end
for _, i in ipairs({12644}) do I[i] = "Dense Grinding Stone" end
for _, i in ipairs({12643}) do I[i] = "Dense Weightstone" end
for _, i in ipairs({8009}) do I[i] = "Dentrium Power Stone" end
for _, i in ipairs({22370}) do I[i] = "Desecrated Belt" end
for _, i in ipairs({22369}) do I[i] = "Desecrated Bindings" end
for _, i in ipairs({22365}) do I[i] = "Desecrated Boots" end
for _, i in ipairs({22355}) do I[i] = "Desecrated Bracers" end
for _, i in ipairs({22349}) do I[i] = "Desecrated Breastplate" end
for _, i in ipairs({22367}) do I[i] = "Desecrated Circlet" end
for _, i in ipairs({22357}) do I[i] = "Desecrated Gauntlets" end
for _, i in ipairs({22363}) do I[i] = "Desecrated Girdle" end
for _, i in ipairs({22371}) do I[i] = "Desecrated Gloves" end
for _, i in ipairs({22364}) do I[i] = "Desecrated Handguards" end
for _, i in ipairs({22360}) do I[i] = "Desecrated Headpiece" end
for _, i in ipairs({22353}) do I[i] = "Desecrated Helmet" end
for _, i in ipairs({22366}) do I[i] = "Desecrated Leggings" end
for _, i in ipairs({22359}) do I[i] = "Desecrated Legguards" end
for _, i in ipairs({22352}) do I[i] = "Desecrated Legplates" end
for _, i in ipairs({22354}) do I[i] = "Desecrated Pauldrons" end
for _, i in ipairs({22351}) do I[i] = "Desecrated Robe" end
for _, i in ipairs({22358}) do I[i] = "Desecrated Sabatons" end
for _, i in ipairs({22372}) do I[i] = "Desecrated Sandals" end
for _, i in ipairs({22368}) do I[i] = "Desecrated Shoulderpads" end
for _, i in ipairs({22361}) do I[i] = "Desecrated Spaulders" end
for _, i in ipairs({22350}) do I[i] = "Desecrated Tunic" end
for _, i in ipairs({22356}) do I[i] = "Desecrated Waistguard" end
for _, i in ipairs({22362}) do I[i] = "Desecrated Wristguards" end
for _, i in ipairs({21141}) do I[i] = "Destroyed Red Scepter Shard" end
for _, i in ipairs({6496}) do I[i] = "Detailed Parchment" end
for _, i in ipairs({6443}) do I[i] = "Deviate Hide" end
for _, i in ipairs({22432}) do I[i] = "Devilsaur Barb" end
for _, i in ipairs({2831}) do I[i] = "Devlin's Remains" end
for _, i in ipairs({16696}) do I[i] = "Devout Belt" end
for _, i in ipairs({16697}) do I[i] = "Devout Bracers" end
for _, i in ipairs({16693}) do I[i] = "Devout Crown" end
for _, i in ipairs({16692}) do I[i] = "Devout Gloves" end
for _, i in ipairs({16695}) do I[i] = "Devout Mantle" end
for _, i in ipairs({16690}) do I[i] = "Devout Robe" end
for _, i in ipairs({16691}) do I[i] = "Devout Sandals" end
for _, i in ipairs({16694}) do I[i] = "Devout Skirt" end
for _, i in ipairs({19806}) do I[i] = "Dezian Queenfish" end
for _, i in ipairs({4845}) do I[i] = "Diamond Runestone" end
for _, i in ipairs({5051}) do I[i] = "Dig Rat" end
for _, i in ipairs({5059}) do I[i] = "Digging Claw" end
for _, i in ipairs({22892}) do I[i] = "Dim Necrotic Stone" end
for _, i in ipairs({11114}) do I[i] = "Dinosaur Bone" end
for _, i in ipairs({6625}) do I[i] = "Dirt-caked Pendant" end
for _, i in ipairs({4851}) do I[i] = "Dirt-stained Map" end
for _, i in ipairs({2843}) do I[i] = "Dirty Knucklebones" end
for _, i in ipairs({2609}) do I[i] = "Disarming Colloid" end
for _, i in ipairs({2610}) do I[i] = "Disarming Mixture" end
for _, i in ipairs({11462}) do I[i] = "Discarded Knife" end
for _, i in ipairs({3164}) do I[i] = "Discolored Worg Heart" end
for _, i in ipairs({17309}) do I[i] = "Discordant Bracers" end
for _, i in ipairs({18746}) do I[i] = "Divination Scryer" end
for _, i in ipairs({5455}) do I[i] = "Divined Scroll" end
for _, i in ipairs({5456}) do I[i] = "Divining Scroll" end
for _, i in ipairs({8548}) do I[i] = "Divino-matic Rod" end
for _, i in ipairs({3897}) do I[i] = "Dizzy's Eye" end
for _, i in ipairs({6626}) do I[i] = "Dogran's Pendant" end
for _, i in ipairs({7627}) do I[i] = "Dolanaar Delivery" end
for _, i in ipairs({13702}) do I[i] = "Doom Weed" end
for _, i in ipairs({12352}) do I[i] = "Doomrigger's Clasp" end
for _, i in ipairs({18630}) do I[i] = "Doomsday Flare" end
for _, i in ipairs({6252}) do I[i] = "Doomwarder Blood" end
for _, i in ipairs({19018}) do I[i] = "Dormant Wind Kissed Blade" end
for _, i in ipairs({21111}) do I[i] = "Draconic For Dummies: Volume II" end
for _, i in ipairs({6071}) do I[i] = "Draenethyst Crystal" end
for _, i in ipairs({6190}) do I[i] = "Draenethyst Shard" end
for _, i in ipairs({7131}) do I[i] = "Dragonmaw Shinbone" end
for _, i in ipairs({3337}) do I[i] = "Dragonmaw War Banner" end
for _, i in ipairs({8685}) do I[i] = "Dran's Ripple Delivery" end
for _, i in ipairs({10445}) do I[i] = "Drawing Kit" end
for _, i in ipairs({16702}) do I[i] = "Dreadmist Belt" end
for _, i in ipairs({16703}) do I[i] = "Dreadmist Bracers" end
for _, i in ipairs({16699}) do I[i] = "Dreadmist Leggings" end
for _, i in ipairs({16701}) do I[i] = "Dreadmist Mantle" end
for _, i in ipairs({16698}) do I[i] = "Dreadmist Mask" end
for _, i in ipairs({16700}) do I[i] = "Dreadmist Robe" end
for _, i in ipairs({16704}) do I[i] = "Dreadmist Sandals" end
for _, i in ipairs({16705}) do I[i] = "Dreadmist Wraps" end
for _, i in ipairs({5068}) do I[i] = "Dried Seeds" end
for _, i in ipairs({22226}) do I[i] = "Druidical Remains" end
for _, i in ipairs({20485}) do I[i] = "Duke's Seal" end
for _, i in ipairs({16888}) do I[i] = "Dull Drakefire Amulet" end
for _, i in ipairs({3467}) do I[i] = "Dull Iron Key" end
for _, i in ipairs({10439}) do I[i] = "Durnan's Scalding Mornbrew" end
for _, i in ipairs({4892}) do I[i] = "Durotar Tiger Fur" end
for _, i in ipairs({2876}) do I[i] = "Duskbat Pelt" end
for _, i in ipairs({3264}) do I[i] = "Duskbat Wing" end
for _, i in ipairs({2250}) do I[i] = "Dusky Crab Cakes" end
for _, i in ipairs({5669}) do I[i] = "Dust Devil Debris" end
for _, i in ipairs({18206}) do I[i] = "Dwarf Spine" end
for _, i in ipairs({3339}) do I[i] = "Dwarven Tinder" end
for _, i in ipairs({3639}) do I[i] = "Ear of Balgaras" end
for _, i in ipairs({6635}) do I[i] = "Earth Sapta" end
for _, i in ipairs({2449}) do I[i] = "Earthroot" end
for _, i in ipairs({1410}) do I[i] = "Ebonlocke's Response to Solomon" end
for _, i in ipairs({5100}) do I[i] = "Echeyakee's Hide" end
for _, i in ipairs({21946}) do I[i] = "Ectoplasmic Distiller" end
for _, i in ipairs({13354}) do I[i] = "Ectoplasmic Resonator" end
for _, i in ipairs({9528}) do I[i] = "Edana's Dark Heart" end
for _, i in ipairs({6285}) do I[i] = "Egalin's Grimoire" end
for _, i in ipairs({13256,13289}) do I[i] = "Egan's Blaster" end
for _, i in ipairs({8647}) do I[i] = "Egg Crate" end
for _, i in ipairs({10465}) do I[i] = "Egg of Hakkar" end
for _, i in ipairs({12286}) do I[i] = "Eggscilloscope Prototype" end
for _, i in ipairs({6620}) do I[i] = "Elaborate Parchment" end
for _, i in ipairs({4105}) do I[i] = "Elder Crocolisk Skin" end
for _, i in ipairs({4473}) do I[i] = "Eldritch Shackles" end
for _, i in ipairs({6718}) do I[i] = "Electropeller" end
for _, i in ipairs({17126}) do I[i] = "Elegant Letter" end
for _, i in ipairs({7069}) do I[i] = "Elemental Air" end
for _, i in ipairs({7067}) do I[i] = "Elemental Earth" end
for _, i in ipairs({7068}) do I[i] = "Elemental Fire" end
for _, i in ipairs({11267}) do I[i] = "Elemental Shard Sample" end
for _, i in ipairs({7070}) do I[i] = "Elemental Water" end
for _, i in ipairs({19267}) do I[i] = "Elementals Deck" end
for _, i in ipairs({17771}) do I[i] = "Elementium Bar" end
for _, i in ipairs({18562}) do I[i] = "Elementium Ore" end
for _, i in ipairs({3825}) do I[i] = "Elixir of Fortitude" end
for _, i in ipairs({2454}) do I[i] = "Elixir of Lion's Strength" end
for _, i in ipairs({5997}) do I[i] = "Elixir of Minor Defense" end
for _, i in ipairs({2458}) do I[i] = "Elixir of Minor Fortitude" end
for _, i in ipairs({3497}) do I[i] = "Elixir of Pain" end
for _, i in ipairs({9264}) do I[i] = "Elixir of Shadow Power" end
for _, i in ipairs({3495}) do I[i] = "Elixir of Suffering" end
for _, i in ipairs({5493}) do I[i] = "Elune's Tear" end
for _, i in ipairs({6808}) do I[i] = "Elunite Ore" end
for _, i in ipairs({6809}) do I[i] = "Elura's Medallion" end
for _, i in ipairs({5330}) do I[i] = "Elven Cup Relic" end
for _, i in ipairs({4492}) do I[i] = "Elven Gem" end
for _, i in ipairs({4493}) do I[i] = "Elven Gems" end
for _, i in ipairs({2834}) do I[i] = "Embalming Ichor" end
for _, i in ipairs({21988}) do I[i] = "Ember of Emberseer" end
for _, i in ipairs({2309}) do I[i] = "Embossed Leather Boots" end
for _, i in ipairs({2310}) do I[i] = "Embossed Leather Cloak" end
for _, i in ipairs({4239}) do I[i] = "Embossed Leather Gloves" end
for _, i in ipairs({8048}) do I[i] = "Emerald Dreamcatcher" end
for _, i in ipairs({7767}) do I[i] = "Empty Blue Waterskin" end
for _, i in ipairs({7766}) do I[i] = "Empty Brown Waterskin" end
for _, i in ipairs({12922}) do I[i] = "Empty Canteen" end
for _, i in ipairs({12346}) do I[i] = "Empty Cleansing Bowl" end
for _, i in ipairs({15844}) do I[i] = "Empty Cliffspring Falls Sampler" end
for _, i in ipairs({13187}) do I[i] = "Empty Dalson's Tears Bottle" end
for _, i in ipairs({15842}) do I[i] = "Empty Dreadmist Peak Sampler" end
for _, i in ipairs({13186}) do I[i] = "Empty Felstone Field Bottle" end
for _, i in ipairs({12771}) do I[i] = "Empty Firewater Flask" end
for _, i in ipairs({13189}) do I[i] = "Empty Gahrron's Withering Bottle" end
for _, i in ipairs({9283}) do I[i] = "Empty Leaden Collection Phial" end
for _, i in ipairs({7768}) do I[i] = "Empty Red Waterskin" end
for _, i in ipairs({12350}) do I[i] = "Empty Sampling Tube" end
for _, i in ipairs({15042}) do I[i] = "Empty Termite Jar" end
for _, i in ipairs({7866}) do I[i] = "Empty Thaumaturgy Vessel" end
for _, i in ipairs({3371}) do I[i] = "Empty Vial" end
for _, i in ipairs({14338}) do I[i] = "Empty Water Tube" end
for _, i in ipairs({16974}) do I[i] = "Empty Water Vial" end
for _, i in ipairs({12262}) do I[i] = "Empty Worg Pup Cage" end
for _, i in ipairs({13188}) do I[i] = "Empty Writhing Haunt Bottle" end
for _, i in ipairs({12288}) do I[i] = "Encased Corrupt Ooze" end
for _, i in ipairs({11230}) do I[i] = "Encased Fiery Essence" end
for _, i in ipairs({4529}) do I[i] = "Enchanted Agate" end
for _, i in ipairs({18724}) do I[i] = "Enchanted Black Dragon Sinew" end
for _, i in ipairs({20029}) do I[i] = "Enchanted Coral" end
for _, i in ipairs({16208}) do I[i] = "Enchanted Gaea Seeds" end
for _, i in ipairs({12810}) do I[i] = "Enchanted Leather" end
for _, i in ipairs({5387}) do I[i] = "Enchanted Moonstalker Cloak" end
for _, i in ipairs({16603}) do I[i] = "Enchanted Resonite Crystal" end
for _, i in ipairs({12734}) do I[i] = "Enchanted Scarlet Thread" end
for _, i in ipairs({4639}) do I[i] = "Enchanted Sea Kelp" end
for _, i in ipairs({19610,19611,19612}) do I[i] = "Enchanted South Seas Kelp" end
for _, i in ipairs({12655}) do I[i] = "Enchanted Thorium Bar" end
for _, i in ipairs({18769,18770,18771}) do I[i] = "Enchanted Thorium Platemail" end
for _, i in ipairs({20023}) do I[i] = "Encoded Fragment" end
for _, i in ipairs({17409}) do I[i] = "Encrusted Crystal Fragment" end
for _, i in ipairs({9589}) do I[i] = "Encrusted Minerals" end
for _, i in ipairs({17346}) do I[i] = "Encrusted Silithid Object" end
for _, i in ipairs({5796}) do I[i] = "Encrusted Tail Fin" end
for _, i in ipairs({9555}) do I[i] = "Encrypted Letter" end
for _, i in ipairs({9558}) do I[i] = "Encrypted Memorandum" end
for _, i in ipairs({9560}) do I[i] = "Encrypted Parchment" end
for _, i in ipairs({9550}) do I[i] = "Encrypted Rune" end
for _, i in ipairs({9559}) do I[i] = "Encrypted Scroll" end
for _, i in ipairs({9551}) do I[i] = "Encrypted Sigil" end
for _, i in ipairs({9554}) do I[i] = "Encrypted Tablet" end
for _, i in ipairs({20404}) do I[i] = "Encrypted Twilight Text" end
for _, i in ipairs({13724}) do I[i] = "Enriched Manna Biscuit" end
for _, i in ipairs({3706}) do I[i] = "Ensorcelled Parchment" end
for _, i in ipairs({11617}) do I[i] = "Eridan's Supplies" end
for _, i in ipairs({11682}) do I[i] = "Eridan's Vial" end
for _, i in ipairs({10454}) do I[i] = "Essence of Eranikus" end
for _, i in ipairs({7078}) do I[i] = "Essence of Fire" end
for _, i in ipairs({10663}) do I[i] = "Essence of Hakkar" end
for _, i in ipairs({3622}) do I[i] = "Essence of Nightlash" end
for _, i in ipairs({7080}) do I[i] = "Essence of Water" end
for _, i in ipairs({21145}) do I[i] = "Essence of Xandivious" end
for _, i in ipairs({11129}) do I[i] = "Essence of the Elements" end
for _, i in ipairs({6851}) do I[i] = "Essence of the Exile" end
for _, i in ipairs({18566,19017}) do I[i] = "Essence of the Firelord" end
for _, i in ipairs({9278}) do I[i] = "Essential Artificial" end
for _, i in ipairs({9565}) do I[i] = "Etched Note" end
for _, i in ipairs({9553}) do I[i] = "Etched Parchment" end
for _, i in ipairs({5867}) do I[i] = "Etched Phial" end
for _, i in ipairs({9566}) do I[i] = "Etched Rune" end
for _, i in ipairs({9567}) do I[i] = "Etched Sigil" end
for _, i in ipairs({9564}) do I[i] = "Etched Tablet" end
for _, i in ipairs({22754}) do I[i] = "Eternal Quintessence" end
for _, i in ipairs({11024}) do I[i] = "Evergreen Herb Casing" end
for _, i in ipairs({11020}) do I[i] = "Evergreen Pouch" end
for _, i in ipairs({15788}) do I[i] = "Everlook Report" end
for _, i in ipairs({11404}) do I[i] = "Evil Bat Eye" end
for _, i in ipairs({6658}) do I[i] = "Example Collar" end
for _, i in ipairs({18752}) do I[i] = "Exorcism Censer" end
for _, i in ipairs({4384}) do I[i] = "Explosive Sheep" end
for _, i in ipairs({5021}) do I[i] = "Explosive Stick of Gann" end
for _, i in ipairs({13202}) do I[i] = "Extended Annals of Darrowshire" end
for _, i in ipairs({22115}) do I[i] = "Extra-Dimensional Ghost Revealer" end
for _, i in ipairs({8643}) do I[i] = "Extraordinary Egg" end
for _, i in ipairs({4903}) do I[i] = "Eye of Burning Shadow" end
for _, i in ipairs({21221}) do I[i] = "Eye of C'Thun" end
for _, i in ipairs({11753}) do I[i] = "Eye of Kajal" end
for _, i in ipairs({17322}) do I[i] = "Eye of the Emberseer" end
for _, i in ipairs({11108}) do I[i] = "Faded Photograph" end
for _, i in ipairs({1956}) do I[i] = "Faded Shadowhide Pendant" end
for _, i in ipairs({9596}) do I[i] = "Faerie Dragon Muisek" end
for _, i in ipairs({9620}) do I[i] = "Faerie Dragon Muisek Vessel" end
for _, i in ipairs({22950}) do I[i] = "Faint Necrotic Crystal" end
for _, i in ipairs({4517}) do I[i] = "Falconcrest's Head" end
for _, i in ipairs({5508}) do I[i] = "Fallen Moonstone" end
for _, i in ipairs({5390}) do I[i] = "Fandral's Message" end
for _, i in ipairs({3876}) do I[i] = "Fang of Bhag'thera" end
for _, i in ipairs({3627}) do I[i] = "Fang of Vagash" end
for _, i in ipairs({3632}) do I[i] = "Fangore's Paw" end
for _, i in ipairs({9436}) do I[i] = "Faranell's Parcel" end
for _, i in ipairs({5831}) do I[i] = "Fardel's Head" end
for _, i in ipairs({3721}) do I[i] = "Farren's Report" end
for _, i in ipairs({15586}) do I[i] = "Fast-growing Flower" end
for _, i in ipairs({22708}) do I[i] = "Fate of Ramaladni" end
for _, i in ipairs({16762}) do I[i] = "Fathom Core" end
for _, i in ipairs({6086}) do I[i] = "Faustin's Truth Serum" end
for _, i in ipairs({6753}) do I[i] = "Feather Charm" end
for _, i in ipairs({3418}) do I[i] = "Fel Cone" end
for _, i in ipairs({11514}) do I[i] = "Fel Creep" end
for _, i in ipairs({21939}) do I[i] = "Fel Elemental Rod" end
for _, i in ipairs({18626}) do I[i] = "Fel Fire" end
for _, i in ipairs({11171}) do I[i] = "Fel Iron" end
for _, i in ipairs({3297}) do I[i] = "Fel Moss" end
for _, i in ipairs({10831}) do I[i] = "Fel Orb" end
for _, i in ipairs({10832}) do I[i] = "Fel Tracker Owner's Manual" end
for _, i in ipairs({14256}) do I[i] = "Felcloth" end
for _, i in ipairs({12647}) do I[i] = "Felhas Ruby" end
for _, i in ipairs({6250}) do I[i] = "Felhound Brain" end
for _, i in ipairs({10834}) do I[i] = "Felhound Tracker Kit" end
for _, i in ipairs({6988}) do I[i] = "Felhunter Summoning Scroll" end
for _, i in ipairs({10438}) do I[i] = "Felix's Box" end
for _, i in ipairs({16314}) do I[i] = "Felix's Bucket of Bolts" end
for _, i in ipairs({16313}) do I[i] = "Felix's Chest" end
for _, i in ipairs({12445}) do I[i] = "Felnok's Package" end
for _, i in ipairs({6640}) do I[i] = "Felstalker Hoof" end
for _, i in ipairs({13194}) do I[i] = "Felstone Field Cauldron Key" end
for _, i in ipairs({18501}) do I[i] = "Felvine Shard" end
for _, i in ipairs({12230}) do I[i] = "Felwood Slime Sample" end
for _, i in ipairs({7306}) do I[i] = "Fenwick's Head" end
for _, i in ipairs({16967}) do I[i] = "Feralas Ahi" end
for _, i in ipairs({9331}) do I[i] = "Feralas: A History" end
for _, i in ipairs({13157}) do I[i] = "Fetid Skull" end
for _, i in ipairs({6181}) do I[i] = "Fetish of Hakkar" end
for _, i in ipairs({5583}) do I[i] = "Fey Dragon Scale" end
for _, i in ipairs({17010}) do I[i] = "Fiery Core" end
for _, i in ipairs({18942}) do I[i] = "Fiery Flux" end
for _, i in ipairs({12740}) do I[i] = "Fifth Mosh'aru Tablet" end
for _, i in ipairs({18151}) do I[i] = "Filled Amethyst Phial" end
for _, i in ipairs({7770}) do I[i] = "Filled Blue Waterskin" end
for _, i in ipairs({7769}) do I[i] = "Filled Brown Waterskin" end
for _, i in ipairs({17696}) do I[i] = "Filled Cerulean Vial" end
for _, i in ipairs({12347}) do I[i] = "Filled Cleansing Bowl" end
for _, i in ipairs({15845}) do I[i] = "Filled Cliffspring Falls Sampler" end
for _, i in ipairs({7292}) do I[i] = "Filled Containment Coffer" end
for _, i in ipairs({5184}) do I[i] = "Filled Crystal Phial" end
for _, i in ipairs({11947}) do I[i] = "Filled Cursed Ooze Jar" end
for _, i in ipairs({13191}) do I[i] = "Filled Dalson's Tears Bottle" end
for _, i in ipairs({15843}) do I[i] = "Filled Dreadmist Peak Sampler" end
for _, i in ipairs({10662}) do I[i] = "Filled Egg of Hakkar" end
for _, i in ipairs({5868}) do I[i] = "Filled Etched Phial" end
for _, i in ipairs({13190}) do I[i] = "Filled Felstone Field Bottle" end
for _, i in ipairs({12567}) do I[i] = "Filled Flasket" end
for _, i in ipairs({13193}) do I[i] = "Filled Gahrron's Withering Bottle" end
for _, i in ipairs({5639}) do I[i] = "Filled Jade Phial" end
for _, i in ipairs({11954}) do I[i] = "Filled Pure Sample Jar" end
for _, i in ipairs({7771}) do I[i] = "Filled Red Waterskin" end
for _, i in ipairs({3913}) do I[i] = "Filled Soul Gem" end
for _, i in ipairs({11949}) do I[i] = "Filled Tainted Ooze Jar" end
for _, i in ipairs({5645}) do I[i] = "Filled Tourmaline Phial" end
for _, i in ipairs({5188}) do I[i] = "Filled Vessel" end
for _, i in ipairs({10691}) do I[i] = "Filled Vial Labeled #1" end
for _, i in ipairs({10692}) do I[i] = "Filled Vial Labeled #2" end
for _, i in ipairs({10693}) do I[i] = "Filled Vial Labeled #3" end
for _, i in ipairs({10694}) do I[i] = "Filled Vial Labeled #4" end
for _, i in ipairs({13192}) do I[i] = "Filled Writhing Haunt Bottle" end
for _, i in ipairs({1362}) do I[i] = "Final Clue to Sander's Treasure" end
for _, i in ipairs({19036}) do I[i] = "Final Message to the Wildhammer" end
for _, i in ipairs({12237}) do I[i] = "Fine Crab Chunks" end
for _, i in ipairs({8644}) do I[i] = "Fine Egg" end
for _, i in ipairs({12293}) do I[i] = "Fine Gold Thread" end
for _, i in ipairs({5386}) do I[i] = "Fine Moonstalker Pelt" end
for _, i in ipairs({2321}) do I[i] = "Fine Thread" end
for _, i in ipairs({5026}) do I[i] = "Fire Tar" end
for _, i in ipairs({9246}) do I[i] = "Firebeard's Head" end
for _, i in ipairs({4625}) do I[i] = "Firebloom" end
for _, i in ipairs({10660}) do I[i] = "First Mosh'aru Tablet" end
for _, i in ipairs({12896}) do I[i] = "First Relic Fragment" end
for _, i in ipairs({4819}) do I[i] = "Fizsprocket's Clipboard" end
for _, i in ipairs({5827}) do I[i] = "Fizzle Brassbolts' Letter" end
for _, i in ipairs({4869}) do I[i] = "Fizzle's Claw" end
for _, i in ipairs({8066}) do I[i] = "Fizzule's Whistle" end
for _, i in ipairs({2594}) do I[i] = "Flagon of Mead" end
for _, i in ipairs({5234}) do I[i] = "Flagongut's Fossil" end
for _, i in ipairs({18169}) do I[i] = "Flame Mantle of the Dawn" end
for _, i in ipairs({12814}) do I[i] = "Flame in a Bottle" end
for _, i in ipairs({23184}) do I[i] = "Flame of Darnassus" end
for _, i in ipairs({23183}) do I[i] = "Flame of Ironforge" end
for _, i in ipairs({23179}) do I[i] = "Flame of Orgrimmar" end
for _, i in ipairs({23182}) do I[i] = "Flame of Stormwind" end
for _, i in ipairs({23180}) do I[i] = "Flame of Thunder Bluff" end
for _, i in ipairs({23181}) do I[i] = "Flame of the Undercity" end
for _, i in ipairs({8051}) do I[i] = "Flare Gun" end
for _, i in ipairs({8152}) do I[i] = "Flask of Big Mojo" end
for _, i in ipairs({12813}) do I[i] = "Flask of Mystery Goo" end
for _, i in ipairs({814}) do I[i] = "Flask of Oil" end
for _, i in ipairs({13506}) do I[i] = "Flask of Petrification" end
for _, i in ipairs({13512}) do I[i] = "Flask of Supreme Power" end
for _, i in ipairs({4805}) do I[i] = "Flatland Cougar Femur" end
for _, i in ipairs({5203}) do I[i] = "Flatland Prowler Claw" end
for _, i in ipairs({4986}) do I[i] = "Flawed Power Stone" end
for _, i in ipairs({8244}) do I[i] = "Flawless Draenethyst Sphere" end
for _, i in ipairs({18624}) do I[i] = "Flawless Fel Essence (Azshara)" end
for _, i in ipairs({18623}) do I[i] = "Flawless Fel Essence (Dark Portal)" end
for _, i in ipairs({18622}) do I[i] = "Flawless Fel Essence (Jaedenar)" end
for _, i in ipairs({7271}) do I[i] = "Flawless Ivory Tusk" end
for _, i in ipairs({20310}) do I[i] = "Flayed Demon Skin" end
for _, i in ipairs({6437}) do I[i] = "Flayed Demon Skin (old)" end
for _, i in ipairs({6766}) do I[i] = "Flayed Demon Skin (old2)" end
for _, i in ipairs({11668}) do I[i] = "Flute of Xavaric" end
for _, i in ipairs({11445}) do I[i] = "Flute of the Ancients" end
for _, i in ipairs({5806}) do I[i] = "Fool's Stout" end
for _, i in ipairs({5807}) do I[i] = "Fool's Stout Report" end
for _, i in ipairs({3718}) do I[i] = "Foreboding Plans" end
for _, i in ipairs({16114}) do I[i] = "Foreman's Blackjack" end
for _, i in ipairs({12324}) do I[i] = "Forged Seal of Ascension" end
for _, i in ipairs({6534}) do I[i] = "Forged Steel Bars" end
for _, i in ipairs({5883}) do I[i] = "Forked Mudrock Tongue" end
for _, i in ipairs({18401}) do I[i] = "Foror's Compendium of Dragon Slaying" end
for _, i in ipairs({18147}) do I[i] = "Forsaken Heart" end
for _, i in ipairs({20387}) do I[i] = "Forsaken Stink Bomb Cluster" end
for _, i in ipairs({23549}) do I[i] = "Fortitude of the Scourge" end
for _, i in ipairs({12412}) do I[i] = "Fourth Mosh'aru Tablet" end
for _, i in ipairs({12899}) do I[i] = "Fourth Relic Fragment" end
for _, i in ipairs({5448}) do I[i] = "Fractured Elemental Bracer" end
for _, i in ipairs({11266}) do I[i] = "Fractured Elemental Shard" end
for _, i in ipairs({11471}) do I[i] = "Fragile Sprite Darter Egg" end
for _, i in ipairs({16662}) do I[i] = "Fragment of the Dragon's Eye" end
for _, i in ipairs({21146,21147,21148,21149}) do I[i] = "Fragment of the Nightmare's Corruption" end
for _, i in ipairs({5844}) do I[i] = "Fragments of Rok'Alim" end
for _, i in ipairs({22727}) do I[i] = "Frame of Atiesh" end
for _, i in ipairs({12735}) do I[i] = "Frayed Abomination Stitching" end
for _, i in ipairs({19338}) do I[i] = "Free Ticket Voucher" end
for _, i in ipairs({5810}) do I[i] = "Fresh Carcass" end
for _, i in ipairs({10338}) do I[i] = "Fresh Zhevra Carcass" end
for _, i in ipairs({18170}) do I[i] = "Frost Mantle of the Dawn" end
for _, i in ipairs({3829}) do I[i] = "Frost Oil" end
for _, i in ipairs({13329}) do I[i] = "Frost Ram" end
for _, i in ipairs({18363}) do I[i] = "Frost Shock and You" end
for _, i in ipairs({12436}) do I[i] = "Frostmaul E'ko" end
for _, i in ipairs({12334}) do I[i] = "Frostmaul Shards" end
for _, i in ipairs({5811}) do I[i] = "Frostmaw's Mane" end
for _, i in ipairs({12430}) do I[i] = "Frostsaber E'ko" end
for _, i in ipairs({12736}) do I[i] = "Frostwhisper's Embalming Fluid" end
for _, i in ipairs({17442}) do I[i] = "Frostwolf Assault Orders" end
for _, i in ipairs({17850}) do I[i] = "Frostwolf Banner" end
for _, i in ipairs({17504}) do I[i] = "Frostwolf Commander's Medal" end
for _, i in ipairs({17643}) do I[i] = "Frostwolf Hide" end
for _, i in ipairs({17690}) do I[i] = "Frostwolf Insignia Rank 1" end
for _, i in ipairs({17905}) do I[i] = "Frostwolf Insignia Rank 2" end
for _, i in ipairs({17906}) do I[i] = "Frostwolf Insignia Rank 3" end
for _, i in ipairs({17907}) do I[i] = "Frostwolf Insignia Rank 4" end
for _, i in ipairs({17908}) do I[i] = "Frostwolf Insignia Rank 5" end
for _, i in ipairs({17503}) do I[i] = "Frostwolf Lieutenant's Medal" end
for _, i in ipairs({17822}) do I[i] = "Frostwolf Maps" end
for _, i in ipairs({17626}) do I[i] = "Frostwolf Muzzle" end
for _, i in ipairs({17502}) do I[i] = "Frostwolf Soldier's Medal" end
for _, i in ipairs({21936}) do I[i] = "Frozen Ectoplasm" end
for _, i in ipairs({13761}) do I[i] = "Frozen Eggs" end
for _, i in ipairs({22682}) do I[i] = "Frozen Rune" end
for _, i in ipairs({5852}) do I[i] = "Fuel Regulator Blueprints" end
for _, i in ipairs({9284}) do I[i] = "Full Leaden Collection Phial" end
for _, i in ipairs({5012}) do I[i] = "Fungal Spores" end
for _, i in ipairs({6842}) do I[i] = "Furen's Instructions" end
for _, i in ipairs({6926}) do I[i] = "Furen's Notes" end
for _, i in ipairs({1971}) do I[i] = "Furlbrow's Deed" end
for _, i in ipairs({841}) do I[i] = "Furlbrow's Pocket Watch" end
for _, i in ipairs({9323}) do I[i] = "Gadrin's Parchment" end
for _, i in ipairs({16205}) do I[i] = "Gaea Seed" end
for _, i in ipairs({13196}) do I[i] = "Gahrron's Withering Cauldron Key" end
for _, i in ipairs({9978}) do I[i] = "Gahz'ridian Detector" end
for _, i in ipairs({8443}) do I[i] = "Gahz'ridian Ornament" end
for _, i in ipairs({8707}) do I[i] = "Gahz'rilla's Electrified Scale" end
for _, i in ipairs({6262}) do I[i] = "Galen's Journal" end
for _, i in ipairs({8074}) do I[i] = "Gallywix's Head" end
for _, i in ipairs({6840}) do I[i] = "Galvanized Horn" end
for _, i in ipairs({3904}) do I[i] = "Gan'zulah's Head" end
for _, i in ipairs({8136}) do I[i] = "Gargantuan Tumor" end
for _, i in ipairs({18356}) do I[i] = "Garona: A Study on Stealth and Treachery" end
for _, i in ipairs({8026}) do I[i] = "Garrett Family Treasure" end
for _, i in ipairs({182}) do I[i] = "Garrick's Head" end
for _, i in ipairs({5687}) do I[i] = "Gatekeeper's Key" end
for _, i in ipairs({18336}) do I[i] = "Gauntlet of Gordok Might" end
for _, i in ipairs({16672}) do I[i] = "Gauntlets of Elements" end
for _, i in ipairs({16737}) do I[i] = "Gauntlets of Valor" end
for _, i in ipairs({5080}) do I[i] = "Gazlowe's Ledger" end
for _, i in ipairs({9739}) do I[i] = "Gem of Anacondra" end
for _, i in ipairs({9738}) do I[i] = "Gem of Cobrahn" end
for _, i in ipairs({9740}) do I[i] = "Gem of Pythas" end
for _, i in ipairs({9741}) do I[i] = "Gem of Serpentis" end
for _, i in ipairs({17765}) do I[i] = "Gem of the Fifth Kahn" end
for _, i in ipairs({17761}) do I[i] = "Gem of the First Khan" end
for _, i in ipairs({17764}) do I[i] = "Gem of the Fourth Kahn" end
for _, i in ipairs({17762}) do I[i] = "Gem of the Second Kahn" end
for _, i in ipairs({15766}) do I[i] = "Gem of the Serpent" end
for _, i in ipairs({17763}) do I[i] = "Gem of the Third Kahn" end
for _, i in ipairs({12337}) do I[i] = "Gemstone of Bloodaxe" end
for _, i in ipairs({12335}) do I[i] = "Gemstone of Smolderthorn" end
for _, i in ipairs({12336}) do I[i] = "Gemstone of Spirestone" end
for _, i in ipairs({12780}) do I[i] = "General Drakkisath's Command" end
for _, i in ipairs({20453}) do I[i] = "Geologist's Transcription Kit" end
for _, i in ipairs({5736}) do I[i] = "Gerenzo's Mechanical Arm" end
for _, i in ipairs({1518}) do I[i] = "Ghost Hair Comb" end
for _, i in ipairs({1596}) do I[i] = "Ghost Hair Thread" end
for _, i in ipairs({15849}) do I[i] = "Ghost-o-plasm" end
for _, i in ipairs({1129}) do I[i] = "Ghoul Fang" end
for _, i in ipairs({884}) do I[i] = "Ghoul Rib" end
for _, i in ipairs({3348}) do I[i] = "Giant Crocolisk Skin" end
for _, i in ipairs({12207}) do I[i] = "Giant Egg" end
for _, i in ipairs({11405}) do I[i] = "Giant Silver Vein" end
for _, i in ipairs({17197}) do I[i] = "Gingerbread Cookie" end
for _, i in ipairs({8424}) do I[i] = "Gizzard Gum" end
for _, i in ipairs({10418}) do I[i] = "Glimmering Mithril Insignia" end
for _, i in ipairs({20028}) do I[i] = "Glittering Dust" end
for _, i in ipairs({7079}) do I[i] = "Globe of Water" end
for _, i in ipairs({3552}) do I[i] = "Glommus's Head" end
for _, i in ipairs({12737}) do I[i] = "Gloom Weed" end
for _, i in ipairs({18601}) do I[i] = "Glowing Crystal Prison" end
for _, i in ipairs({6655}) do I[i] = "Glowing Ember" end
for _, i in ipairs({5189}) do I[i] = "Glowing Fruit" end
for _, i in ipairs({5463}) do I[i] = "Glowing Gem" end
for _, i in ipairs({12710}) do I[i] = "Glowing Hunk of the Beast's Flesh" end
for _, i in ipairs({19933}) do I[i] = "Glowing Scorpid Blood" end
for _, i in ipairs({1962}) do I[i] = "Glowing Shadowhide Pendant" end
for _, i in ipairs({10441}) do I[i] = "Glowing Shard" end
for _, i in ipairs({5366}) do I[i] = "Glowing Soul Gem" end
for _, i in ipairs({3156}) do I[i] = "Glutton Shackle" end
for _, i in ipairs({1083}) do I[i] = "Glyph of Azora" end
for _, i in ipairs({20463}) do I[i] = "Glyphed Crystal Prism" end
for _, i in ipairs({12663}) do I[i] = "Glyphed Oaken Branch" end
for _, i in ipairs({9571}) do I[i] = "Glyphic Letter" end
for _, i in ipairs({9573}) do I[i] = "Glyphic Memorandum" end
for _, i in ipairs({9572}) do I[i] = "Glyphic Rune" end
for _, i in ipairs({9574}) do I[i] = "Glyphic Scroll" end
for _, i in ipairs({9575}) do I[i] = "Glyphic Tablet" end
for _, i in ipairs({20464}) do I[i] = "Glyphs of Calling" end
for _, i in ipairs({7464}) do I[i] = "Glyphs of Summoning" end
for _, i in ipairs({5220}) do I[i] = "Gnarlpine Fang" end
for _, i in ipairs({8049}) do I[i] = "Gnarlpine Necklace" end
for _, i in ipairs({7740}) do I[i] = "Gni'kiv Medallion" end
for _, i in ipairs({725}) do I[i] = "Gnoll Paw" end
for _, i in ipairs({10790}) do I[i] = "Gnome Engineer Membership Card" end
for _, i in ipairs({5857}) do I[i] = "Gnome Prize Box" end
for _, i in ipairs({5768}) do I[i] = "Gnome Race Ticket" end
for _, i in ipairs({20494}) do I[i] = "Gnomeregan Gumdrop" end
for _, i in ipairs({10725}) do I[i] = "Gnomish Battle Chicken" end
for _, i in ipairs({4863}) do I[i] = "Gnomish Tools" end
for _, i in ipairs({3618}) do I[i] = "Gobbler's Head" end
for _, i in ipairs({10791}) do I[i] = "Goblin Engineer Membership Card" end
for _, i in ipairs({5858}) do I[i] = "Goblin Prize Box" end
for _, i in ipairs({5769}) do I[i] = "Goblin Race Ticket" end
for _, i in ipairs({9061}) do I[i] = "Goblin Rocket Fuel" end
for _, i in ipairs({5804}) do I[i] = "Goblin Rumors" end
for _, i in ipairs({10646}) do I[i] = "Goblin Sapper Charge" end
for _, i in ipairs({9173}) do I[i] = "Goblin Transponder" end
for _, i in ipairs({4491}) do I[i] = "Goggles of Gem Hunting" end
for _, i in ipairs({3577}) do I[i] = "Gold Bar" end
for _, i in ipairs({773}) do I[i] = "Gold Dust" end
for _, i in ipairs({19715}) do I[i] = "Gold Hakkari Bijou" end
for _, i in ipairs({18158}) do I[i] = "Gold Moro'gai Gem" end
for _, i in ipairs({1307}) do I[i] = "Gold Pickup Schedule" end
for _, i in ipairs({20021}) do I[i] = "Gold Pirate Earring" end
for _, i in ipairs({20859}) do I[i] = "Gold Scarab" end
for _, i in ipairs({11179}) do I[i] = "Golden Flame" end
for _, i in ipairs({11128}) do I[i] = "Golden Rod" end
for _, i in ipairs({6040}) do I[i] = "Golden Scale Bracers" end
for _, i in ipairs({20880}) do I[i] = "Golden Token" end
for _, i in ipairs({10511}) do I[i] = "Golem Oil" end
for _, i in ipairs({2660}) do I[i] = "Golm Fragment" end
for _, i in ipairs({18627}) do I[i] = "Gong of Dethmoora" end
for _, i in ipairs({12723}) do I[i] = "Good Luck Charm" end
for _, i in ipairs({12721}) do I[i] = "Good Luck Half-Charm" end
for _, i in ipairs({12722}) do I[i] = "Good Luck Other-Half-Charm" end
for _, i in ipairs({11727}) do I[i] = "Goodsteel Ledger" end
for _, i in ipairs({11723}) do I[i] = "Goodsteel's Balanced Flameberge" end
for _, i in ipairs({2251}) do I[i] = "Gooey Spider Leg" end
for _, i in ipairs({11079,11080}) do I[i] = "Gor'tesh's Lopped Off Head" end
for _, i in ipairs({18250}) do I[i] = "Gordok Shackle Key" end
for _, i in ipairs({16210}) do I[i] = "Gordon's Crate" end
for _, i in ipairs({9463}) do I[i] = "Gordunni Cobalt" end
for _, i in ipairs({9371}) do I[i] = "Gordunni Orb" end
for _, i in ipairs({9370}) do I[i] = "Gordunni Scroll" end
for _, i in ipairs({723}) do I[i] = "Goretusk Liver" end
for _, i in ipairs({731}) do I[i] = "Goretusk Snout" end
for _, i in ipairs({2799}) do I[i] = "Gorilla Fang" end
for _, i in ipairs({11835}) do I[i] = "Gorishi Queen Brain" end
for _, i in ipairs({11833}) do I[i] = "Gorishi Queen Lure" end
for _, i in ipairs({11837}) do I[i] = "Gorishi Scent Gland" end
for _, i in ipairs({22435}) do I[i] = "Gorishi Sting" end
for _, i in ipairs({1252}) do I[i] = "Gramma Stonefield's Note" end
for _, i in ipairs({11125}) do I[i] = "Grape Manifest" end
for _, i in ipairs({3476}) do I[i] = "Gray Bear Tongue" end
for _, i in ipairs({2296}) do I[i] = "Great Goretusk Snout" end
for _, i in ipairs({13461}) do I[i] = "Greater Arkan Protection Potion" end
for _, i in ipairs({16203}) do I[i] = "Greater Eternal Essence" end
for _, i in ipairs({9313}) do I[i] = "Green Firework" end
for _, i in ipairs({19711}) do I[i] = "Green Hakkari Bijou" end
for _, i in ipairs({2755}) do I[i] = "Green Hills of Stranglethorn" end
for _, i in ipairs({2756}) do I[i] = "Green Hills of Stranglethorn - Chapter I" end
for _, i in ipairs({2757}) do I[i] = "Green Hills of Stranglethorn - Chapter II" end
for _, i in ipairs({2758}) do I[i] = "Green Hills of Stranglethorn - Chapter III" end
for _, i in ipairs({2759}) do I[i] = "Green Hills of Stranglethorn - Chapter IV" end
for _, i in ipairs({2725}) do I[i] = "Green Hills of Stranglethorn - Page 1" end
for _, i in ipairs({2734}) do I[i] = "Green Hills of Stranglethorn - Page 10" end
for _, i in ipairs({2735}) do I[i] = "Green Hills of Stranglethorn - Page 11" end
for _, i in ipairs({2738}) do I[i] = "Green Hills of Stranglethorn - Page 14" end
for _, i in ipairs({2740}) do I[i] = "Green Hills of Stranglethorn - Page 16" end
for _, i in ipairs({2742}) do I[i] = "Green Hills of Stranglethorn - Page 18" end
for _, i in ipairs({2744}) do I[i] = "Green Hills of Stranglethorn - Page 20" end
for _, i in ipairs({2745}) do I[i] = "Green Hills of Stranglethorn - Page 21" end
for _, i in ipairs({2748}) do I[i] = "Green Hills of Stranglethorn - Page 24" end
for _, i in ipairs({2749}) do I[i] = "Green Hills of Stranglethorn - Page 25" end
for _, i in ipairs({2750}) do I[i] = "Green Hills of Stranglethorn - Page 26" end
for _, i in ipairs({2751}) do I[i] = "Green Hills of Stranglethorn - Page 27" end
for _, i in ipairs({2728}) do I[i] = "Green Hills of Stranglethorn - Page 4" end
for _, i in ipairs({2730}) do I[i] = "Green Hills of Stranglethorn - Page 6" end
for _, i in ipairs({2732}) do I[i] = "Green Hills of Stranglethorn - Page 8" end
for _, i in ipairs({3835}) do I[i] = "Green Iron Bracers" end
for _, i in ipairs({3836}) do I[i] = "Green Iron Helm" end
for _, i in ipairs({3842}) do I[i] = "Green Iron Leggings" end
for _, i in ipairs({15292}) do I[i] = "Green Kodo" end
for _, i in ipairs({18156}) do I[i] = "Green Moro'gai Gem" end
for _, i in ipairs({11185}) do I[i] = "Green Power Crystal" end
for _, i in ipairs({21139}) do I[i] = "Green Scepter Shard" end
for _, i in ipairs({20608}) do I[i] = "Green Voodoo Feather" end
for _, i in ipairs({2829}) do I[i] = "Gregor's Remains" end
for _, i in ipairs({2004}) do I[i] = "Grelin Whitebeard's Journal" end
for _, i in ipairs({2619}) do I[i] = "Grelin's Report" end
for _, i in ipairs({5336}) do I[i] = "Grell Earring" end
for _, i in ipairs({5843}) do I[i] = "Grenka's Claw" end
for _, i in ipairs({19939}) do I[i] = "Gri'lek's Blood" end
for _, i in ipairs({9308}) do I[i] = "Grime-Encrusted Object" end
for _, i in ipairs({9326}) do I[i] = "Grime-Encrusted Ring" end
for _, i in ipairs({11818}) do I[i] = "Grimesilt Outhouse Key" end
for _, i in ipairs({9460}) do I[i] = "Grimtotem Horn" end
for _, i in ipairs({14381}) do I[i] = "Grimtotem Satchel" end
for _, i in ipairs({3253}) do I[i] = "Grizzled Bear Heart" end
for _, i in ipairs({5414}) do I[i] = "Grizzled Scalp" end
for _, i in ipairs({6259}) do I[i] = "Groddoc Liver" end
for _, i in ipairs({19851}) do I[i] = "Grom's Tribute" end
for _, i in ipairs({16307}) do I[i] = "Gryshka's Letter" end
for _, i in ipairs({22145}) do I[i] = "Guardian's Moldy Card" end
for _, i in ipairs({3016}) do I[i] = "Gunther's Spellbook" end
for _, i in ipairs({19701}) do I[i] = "Gurubashi Coin" end
for _, i in ipairs({19880}) do I[i] = "Gurubashi Head Collection" end
for _, i in ipairs({19931}) do I[i] = "Gurubashi Mojo Madness" end
for _, i in ipairs({17324}) do I[i] = "Guse's Beacon" end
for _, i in ipairs({4389}) do I[i] = "Gyrochronatom" end
for _, i in ipairs({7442}) do I[i] = "Gyromast's Key" end
for _, i in ipairs({3084}) do I[i] = "Gyromechanic Gear" end
for _, i in ipairs({19700}) do I[i] = "Hakkari Coin" end
for _, i in ipairs({15883}) do I[i] = "Half Pendant of Aquatic Agility" end
for _, i in ipairs({15882}) do I[i] = "Half Pendant of Aquatic Endurance" end
for _, i in ipairs({20462}) do I[i] = "Hallow's End Medallion" end
for _, i in ipairs({22014}) do I[i] = "Hallowed Brazier" end
for _, i in ipairs({9548}) do I[i] = "Hallowed Letter" end
for _, i in ipairs({9556}) do I[i] = "Hallowed Rune" end
for _, i in ipairs({9569}) do I[i] = "Hallowed Scroll" end
for _, i in ipairs({9557}) do I[i] = "Hallowed Sigil" end
for _, i in ipairs({9561}) do I[i] = "Hallowed Tablet" end
for _, i in ipairs({15767}) do I[i] = "Hameya's Key" end
for _, i in ipairs({4635}) do I[i] = "Hammertoe's Amulet" end
for _, i in ipairs({4641}) do I[i] = "Hand of Dagun" end
for _, i in ipairs({3628}) do I[i] = "Hand of Dextren Ward" end
for _, i in ipairs({17331}) do I[i] = "Hand of Gehennas" end
for _, i in ipairs({14547}) do I[i] = "Hand of Iruxos" end
for _, i in ipairs({17329}) do I[i] = "Hand of Lucifron" end
for _, i in ipairs({17332}) do I[i] = "Hand of Shazzrah" end
for _, i in ipairs({17330}) do I[i] = "Hand of Sulfuron" end
for _, i in ipairs({1528}) do I[i] = "Handful of Oats" end
for _, i in ipairs({5494}) do I[i] = "Handful of Stardust" end
for _, i in ipairs({12566}) do I[i] = "Hardened Flasket" end
for _, i in ipairs({5795}) do I[i] = "Hardened Tortoise Shell" end
for _, i in ipairs({3258}) do I[i] = "Hardened Tumor" end
for _, i in ipairs({18360}) do I[i] = "Harnessing Shadows" end
for _, i in ipairs({5065}) do I[i] = "Harpy Lieutenant Ring" end
for _, i in ipairs({5138}) do I[i] = "Harvester's Head" end
for _, i in ipairs({9247}) do I[i] = "Hatecrest Naga Scale" end
for _, i in ipairs({6246}) do I[i] = "Hatefury Claw" end
for _, i in ipairs({6247}) do I[i] = "Hatefury Horn" end
for _, i in ipairs({19942}) do I[i] = "Hazza'rah's Dream Thread" end
for _, i in ipairs({13470}) do I[i] = "Head of Alexi Barov" end
for _, i in ipairs({11268}) do I[i] = "Head of Argelmach" end
for _, i in ipairs({5442}) do I[i] = "Head of Arugal" end
for _, i in ipairs({13250}) do I[i] = "Head of Balnazzar" end
for _, i in ipairs({3880}) do I[i] = "Head of Bangalash" end
for _, i in ipairs({13251}) do I[i] = "Head of Baron Rivendare" end
for _, i in ipairs({3626}) do I[i] = "Head of Baron Vardus" end
for _, i in ipairs({2926}) do I[i] = "Head of Bazil Thredd" end
for _, i in ipairs({3640}) do I[i] = "Head of Deepfury" end
for _, i in ipairs({3633}) do I[i] = "Head of Gath'Ilzogg" end
for _, i in ipairs({3634}) do I[i] = "Head of Grimson" end
for _, i in ipairs({23360}) do I[i] = "Head of Instructor Razuvious" end
for _, i in ipairs({22386}) do I[i] = "Head of Instructor Razuvious DEP" end
for _, i in ipairs({6212}) do I[i] = "Head of Jammal'an" end
for _, i in ipairs({5881}) do I[i] = "Head of Kelris" end
for _, i in ipairs({11222}) do I[i] = "Head of Krom'zar" end
for _, i in ipairs({10447}) do I[i] = "Head of Lathoric the Black" end
for _, i in ipairs({10597}) do I[i] = "Head of Magus Rimtori" end
for _, i in ipairs({3672}) do I[i] = "Head of Nagaz" end
for _, i in ipairs({19002,19003}) do I[i] = "Head of Nefarian" end
for _, i in ipairs({18422,18423}) do I[i] = "Head of Onyxia" end
for _, i in ipairs({21220}) do I[i] = "Head of Ossirian the Unscarred" end
for _, i in ipairs({18946}) do I[i] = "Head of Overseer Maltorius" end
for _, i in ipairs({15880}) do I[i] = "Head of Ramstein the Gorger" end
for _, i in ipairs({12630}) do I[i] = "Head of Rend Blackhand" end
for _, i in ipairs({3630}) do I[i] = "Head of Targorr" end
for _, i in ipairs({3637}) do I[i] = "Head of VanCleef" end
for _, i in ipairs({13469}) do I[i] = "Head of Weldon Barov" end
for _, i in ipairs({20383}) do I[i] = "Head of the Broodlord Lashlayer" end
for _, i in ipairs({929}) do I[i] = "Healing Potion" end
for _, i in ipairs({6650}) do I[i] = "Healing Stream Totem Scroll" end
for _, i in ipairs({20027}) do I[i] = "Healthy Courser Gland" end
for _, i in ipairs({13920}) do I[i] = "Healthy Dragon Scale" end
for _, i in ipairs({22387}) do I[i] = "Heart of Anub'Rekhan" end
for _, i in ipairs({7077}) do I[i] = "Heart of Fire" end
for _, i in ipairs({10509}) do I[i] = "Heart of Flame" end
for _, i in ipairs({19802}) do I[i] = "Heart of Hakkar" end
for _, i in ipairs({5104}) do I[i] = "Heart of Isha Awak" end
for _, i in ipairs({2797}) do I[i] = "Heart of Mokk" end
for _, i in ipairs({10446}) do I[i] = "Heart of Obsidion" end
for _, i in ipairs({5805}) do I[i] = "Heart of Zeal" end
for _, i in ipairs({6912}) do I[i] = "Heartswood" end
for _, i in ipairs({6913}) do I[i] = "Heartswood Core" end
for _, i in ipairs({18488}) do I[i] = "Heated Ancient Blade" end
for _, i in ipairs({19579,19585,19586}) do I[i] = "Heathen's Brand" end
for _, i in ipairs({4265}) do I[i] = "Heavy Armor Kit" end
for _, i in ipairs({6214}) do I[i] = "Heavy Copper Maul" end
for _, i in ipairs({3486}) do I[i] = "Heavy Grinding Stone" end
for _, i in ipairs({16885}) do I[i] = "Heavy Junkbox" end
for _, i in ipairs({9364}) do I[i] = "Heavy Leaden Collection Phial" end
for _, i in ipairs({4234}) do I[i] = "Heavy Leather" end
for _, i in ipairs({8545}) do I[i] = "Heavy Mageweave Bandage" end
for _, i in ipairs({7941}) do I[i] = "Heavy Mithril Axe" end
for _, i in ipairs({7933}) do I[i] = "Heavy Mithril Boots" end
for _, i in ipairs({7930}) do I[i] = "Heavy Mithril Breastplate" end
for _, i in ipairs({6491}) do I[i] = "Heavy Parchment" end
for _, i in ipairs({14530}) do I[i] = "Heavy Runecloth Bandage" end
for _, i in ipairs({15408}) do I[i] = "Heavy Scorpid Scale" end
for _, i in ipairs({6451}) do I[i] = "Heavy Silk Bandage" end
for _, i in ipairs({3708}) do I[i] = "Helcular's Rod" end
for _, i in ipairs({11366}) do I[i] = "Helendis Riverhorn's Letter" end
for _, i in ipairs({16731}) do I[i] = "Helm of Valor" end
for _, i in ipairs({5791}) do I[i] = "Henrig Lonebrow's Journal" end
for _, i in ipairs({10599}) do I[i] = "Hetaera's Beaten Head" end
for _, i in ipairs({10610}) do I[i] = "Hetaera's Blood" end
for _, i in ipairs({10598}) do I[i] = "Hetaera's Bloodied Head" end
for _, i in ipairs({10600}) do I[i] = "Hetaera's Bruised Head" end
for _, i in ipairs({9472}) do I[i] = "Hexx's Key" end
for _, i in ipairs({5025}) do I[i] = "Hezrul's Head" end
for _, i in ipairs({10562}) do I[i] = "Hi-Explosive Bomb" end
for _, i in ipairs({9365}) do I[i] = "High Potency Radioactive Fallout" end
for _, i in ipairs({5360}) do I[i] = "Highborne Relic" end
for _, i in ipairs({4512}) do I[i] = "Highland Raptor Eye" end
for _, i in ipairs({5809}) do I[i] = "Highperch Venom Sac" end
for _, i in ipairs({12356}) do I[i] = "Highperch Wyvern Egg" end
for _, i in ipairs({10958}) do I[i] = "Hilary's Necklace" end
for _, i in ipairs({3117}) do I[i] = "Hildelve's Journal" end
for _, i in ipairs({3719}) do I[i] = "Hillman's Cloak" end
for _, i in ipairs({3692}) do I[i] = "Hillsbrad Human Skull" end
for _, i in ipairs({3657}) do I[i] = "Hillsbrad Town Registry" end
for _, i in ipairs({8684}) do I[i] = "Hinterlands Honey Ripple" end
for _, i in ipairs({8564}) do I[i] = "Hippogryph Egg" end
for _, i in ipairs({9595}) do I[i] = "Hippogryph Muisek" end
for _, i in ipairs({9619}) do I[i] = "Hippogryph Muisek Vessel" end
for _, i in ipairs({11131}) do I[i] = "Hive Wall Sample" end
for _, i in ipairs({20455}) do I[i] = "Hive'Ashi Rubbing" end
for _, i in ipairs({21161}) do I[i] = "Hive'Ashi Scout Report" end
for _, i in ipairs({20457}) do I[i] = "Hive'Ashi Silithid Brain" end
for _, i in ipairs({20456}) do I[i] = "Hive'Regal Rubbing" end
for _, i in ipairs({21160}) do I[i] = "Hive'Regal Scout Report" end
for _, i in ipairs({20459}) do I[i] = "Hive'Regal Silithid Brain" end
for _, i in ipairs({20454}) do I[i] = "Hive'Zora Rubbing" end
for _, i in ipairs({21159}) do I[i] = "Hive'Zora Scout Orders" end
for _, i in ipairs({21158}) do I[i] = "Hive'Zora Scout Report" end
for _, i in ipairs({20458}) do I[i] = "Hive'Zora Silithid Brain" end
for _, i in ipairs({5848}) do I[i] = "Hollow Vulture Bone" end
for _, i in ipairs({18362}) do I[i] = "Holy Bologna: What the Light Won't Tell You" end
for _, i in ipairs({737}) do I[i] = "Holy Spring Water" end
for _, i in ipairs({16311}) do I[i] = "Honorary Picks" end
for _, i in ipairs({5099}) do I[i] = "Hoof of Lakota'mani" end
for _, i in ipairs({1274}) do I[i] = "Hops" end
for _, i in ipairs({21438}) do I[i] = "Horde Commendation Signet" end
for _, i in ipairs({22263}) do I[i] = "Horde Gift Collection" end
for _, i in ipairs({4841}) do I[i] = "Horn of Arra'chea" end
for _, i in ipairs({13536}) do I[i] = "Horn of Awakening" end
for _, i in ipairs({10327}) do I[i] = "Horn of Echeyakee" end
for _, i in ipairs({9530}) do I[i] = "Horn of Hatetalon" end
for _, i in ipairs({6805}) do I[i] = "Horn of Vorlus" end
for _, i in ipairs({12351}) do I[i] = "Horn of the Arctic Wolf" end
for _, i in ipairs({12330}) do I[i] = "Horn of the Red Wolf" end
for _, i in ipairs({7906}) do I[i] = "Horns of Nez'ra" end
for _, i in ipairs({12364}) do I[i] = "Huge Emerald" end
for _, i in ipairs({1931}) do I[i] = "Huge Gnoll Claw" end
for _, i in ipairs({12775}) do I[i] = "Huge Thorium Battleaxe" end
for _, i in ipairs({18144}) do I[i] = "Human Bone Chip" end
for _, i in ipairs({13626}) do I[i] = "Human Head of Ras Frostwhisper" end
for _, i in ipairs({18598}) do I[i] = "Human Orphan Whistle" end
for _, i in ipairs({3693}) do I[i] = "Humbert's Sword" end
for _, i in ipairs({19070}) do I[i] = "Huntsman Malkhor's Bones" end
for _, i in ipairs({19069}) do I[i] = "Huntsman Malkhor's Skull" end
for _, i in ipairs({20933}) do I[i] = "Husk of the Old God" end
for _, i in ipairs({10639}) do I[i] = "Hyacinth Mushroom" end
for _, i in ipairs({18299}) do I[i] = "Hydrospawn Essence" end
for _, i in ipairs({12946}) do I[i] = "Hypercapacitor Gizmo" end
for _, i in ipairs({1179}) do I[i] = "Ice Cold Milk" end
for _, i in ipairs({12435}) do I[i] = "Ice Thistle E'ko" end
for _, i in ipairs({17505}) do I[i] = "Ichman's Beacon" end
for _, i in ipairs({7972}) do I[i] = "Ichor of Undeath" end
for _, i in ipairs({13327}) do I[i] = "Icy Blue Mechanostrider Mod A" end
for _, i in ipairs({20876}) do I[i] = "Idol of Death" end
for _, i in ipairs({20879}) do I[i] = "Idol of Life" end
for _, i in ipairs({20875}) do I[i] = "Idol of Night" end
for _, i in ipairs({20878}) do I[i] = "Idol of Rebirth" end
for _, i in ipairs({20881}) do I[i] = "Idol of Strife" end
for _, i in ipairs({20882}) do I[i] = "Idol of War" end
for _, i in ipairs({20877}) do I[i] = "Idol of the Sage" end
for _, i in ipairs({20874}) do I[i] = "Idol of the Sun" end
for _, i in ipairs({5050}) do I[i] = "Ignition Key" end
for _, i in ipairs({5533}) do I[i] = "Ilkrud Magthrull's Tome" end
for _, i in ipairs({9256}) do I[i] = "Imbel Essence" end
for _, i in ipairs({14628}) do I[i] = "Imbued Skeletal Fragments" end
for _, i in ipairs({21925}) do I[i] = "Immaculate Letter" end
for _, i in ipairs({6516}) do I[i] = "Imp Summoning Scroll" end
for _, i in ipairs({18688}) do I[i] = "Imp in a Jar" end
for _, i in ipairs({10593}) do I[i] = "Imperfect Draenethyst Fragment" end
for _, i in ipairs({12422}) do I[i] = "Imperial Plate Chest" end
for _, i in ipairs({21232}) do I[i] = "Imperial Qiraji Armaments" end
for _, i in ipairs({21237}) do I[i] = "Imperial Qiraji Regalia" end
for _, i in ipairs({12562}) do I[i] = "Important Blackrock Documents" end
for _, i in ipairs({18605}) do I[i] = "Imprisoned Doomguard" end
for _, i in ipairs({12648}) do I[i] = "Imprisoned Felhound Spirit" end
for _, i in ipairs({12649}) do I[i] = "Imprisoned Infernal Spirit" end
for _, i in ipairs({14396}) do I[i] = "Incantations from the Nether" end
for _, i in ipairs({12732}) do I[i] = "Incendia Agave" end
for _, i in ipairs({12785}) do I[i] = "Incendia Powder" end
for _, i in ipairs({3340}) do I[i] = "Incendicite Ore" end
for _, i in ipairs({21987}) do I[i] = "Incendicite of Incendius" end
for _, i in ipairs({18944}) do I[i] = "Incendosaur Scale" end
for _, i in ipairs({16312}) do I[i] = "Incendrites" end
for _, i in ipairs({21983}) do I[i] = "Incomplete Banner of Provocation" end
for _, i in ipairs({5797}) do I[i] = "Indurium Flake" end
for _, i in ipairs({5833}) do I[i] = "Indurium Ore" end
for _, i in ipairs({20612}) do I[i] = "Inert Scourgestone" end
for _, i in ipairs({7291}) do I[i] = "Infernal Orb" end
for _, i in ipairs({12646}) do I[i] = "Infus Emerald" end
for _, i in ipairs({6435}) do I[i] = "Infused Burning Gem" end
for _, i in ipairs({5272}) do I[i] = "Insane Scribbles" end
for _, i in ipairs({5219}) do I[i] = "Inscribed Bark" end
for _, i in ipairs({6498,6499,6500,6501}) do I[i] = "Inscribed Kodo Leather" end
for _, i in ipairs({8594}) do I[i] = "Insect Analysis Report" end
for _, i in ipairs({13350}) do I[i] = "Insignia of the Black Guard" end
for _, i in ipairs({22524}) do I[i] = "Insignia of the Crusade" end
for _, i in ipairs({22523}) do I[i] = "Insignia of the Dawn" end
for _, i in ipairs({12220}) do I[i] = "Intact Elemental Bracer" end
for _, i in ipairs({11269}) do I[i] = "Intact Elemental Core" end
for _, i in ipairs({4887}) do I[i] = "Intact Makrura Eye" end
for _, i in ipairs({5055}) do I[i] = "Intact Raptor Horn" end
for _, i in ipairs({5853}) do I[i] = "Intact Silithid Carapace" end
for _, i in ipairs({2629}) do I[i] = "Intrepid Strongbox Key" end
for _, i in ipairs({12841}) do I[i] = "Invader's Scourgestone" end
for _, i in ipairs({1257}) do I[i] = "Invisibility Liquor" end
for _, i in ipairs({9369}) do I[i] = "Iridescent Sprite Darter Wing" end
for _, i in ipairs({3575}) do I[i] = "Iron Bar" end
for _, i in ipairs({2856}) do I[i] = "Iron Pike" end
for _, i in ipairs({5519}) do I[i] = "Iron Pommel" end
for _, i in ipairs({1013}) do I[i] = "Iron Rivet" end
for _, i in ipairs({5464}) do I[i] = "Iron Shaft" end
for _, i in ipairs({2637}) do I[i] = "Ironband's Progress Report" end
for _, i in ipairs({17522}) do I[i] = "Irondeep Supplies" end
for _, i in ipairs({20490}) do I[i] = "Ironforge Mint" end
for _, i in ipairs({6258}) do I[i] = "Ironfur Liver" end
for _, i in ipairs({11173}) do I[i] = "Irontree Heart" end
for _, i in ipairs({14227}) do I[i] = "Ironweb Spider Silk" end
for _, i in ipairs({5101}) do I[i] = "Ishamuhale's Fang" end
for _, i in ipairs({3621}) do I[i] = "Ivar's Head" end
for _, i in ipairs({10642}) do I[i] = "Iverron's Antidote" end
for _, i in ipairs({20865}) do I[i] = "Ivory Scarab" end
for _, i in ipairs({18663}) do I[i] = "J'eevee's Jar" end
for _, i in ipairs({1529}) do I[i] = "Jade" end
for _, i in ipairs({5619}) do I[i] = "Jade Phial" end
for _, i in ipairs({11674}) do I[i] = "Jadefire Felbind" end
for _, i in ipairs({7680}) do I[i] = "Jadespine Basilisk Scale" end
for _, i in ipairs({18642}) do I[i] = "Jaina's Autograph" end
for _, i in ipairs({9236}) do I[i] = "Jangdor's Letter" end
for _, i in ipairs({12724}) do I[i] = "Janice's Parcel" end
for _, i in ipairs({7735}) do I[i] = "Jannok's Rose" end
for _, i in ipairs({12891}) do I[i] = "Jaron's Pick" end
for _, i in ipairs({12525}) do I[i] = "Jaron's Supplies" end
for _, i in ipairs({20870}) do I[i] = "Jasper Idol" end
for _, i in ipairs({22224}) do I[i] = "Jeering Spectre's Essence" end
for _, i in ipairs({7207}) do I[i] = "Jennea's Flask" end
for _, i in ipairs({9368}) do I[i] = "Jer'kai's Signet Ring" end
for _, i in ipairs({10680}) do I[i] = "Jes'rimon's Note" end
for _, i in ipairs({5942}) do I[i] = "Jeweled Pendant" end
for _, i in ipairs({17325}) do I[i] = "Jeztor's Beacon" end
for _, i in ipairs({2560}) do I[i] = "Jitters' Completed Journal" end
for _, i in ipairs({3238}) do I[i] = "Johaan's Findings" end
for _, i in ipairs({3460}) do I[i] = "Johaan's Special Drink" end
for _, i in ipairs({3925}) do I[i] = "Jon-Jon's Golden Spyglass" end
for _, i in ipairs({6992}) do I[i] = "Jordan's Ore Shipment" end
for _, i in ipairs({6993}) do I[i] = "Jordan's Refined Ore Shipment" end
for _, i in ipairs({6895}) do I[i] = "Jordan's Smithing Hammer" end
for _, i in ipairs({6996}) do I[i] = "Jordan's Weapon Notes" end
for _, i in ipairs({15328}) do I[i] = "Joseph's Key" end
for _, i in ipairs({12894}) do I[i] = "Joseph's Wedding Ring" end
for _, i in ipairs({12457}) do I[i] = "Juju Chill" end
for _, i in ipairs({12455}) do I[i] = "Juju Ember" end
for _, i in ipairs({12459}) do I[i] = "Juju Escape" end
for _, i in ipairs({12450}) do I[i] = "Juju Flurry" end
for _, i in ipairs({12458}) do I[i] = "Juju Guile" end
for _, i in ipairs({12460}) do I[i] = "Juju Might" end
for _, i in ipairs({12451}) do I[i] = "Juju Power" end
for _, i in ipairs({2633}) do I[i] = "Jungle Remedy" end
for _, i in ipairs({3863}) do I[i] = "Jungle Stalker Feather" end
for _, i in ipairs({4595}) do I[i] = "Junglevine Wine" end
for _, i in ipairs({10622}) do I[i] = "Kadrak's Flag" end
for _, i in ipairs({16972}) do I[i] = "Karang's Banner" end
for _, i in ipairs({6245}) do I[i] = "Karnitol's Satchel" end
for _, i in ipairs({19023}) do I[i] = "Katoom's Best Lure" end
for _, i in ipairs({8046}) do I[i] = "Kearnen's Journal" end
for _, i in ipairs({19805}) do I[i] = "Keefer's Angelfish" end
for _, i in ipairs({13585}) do I[i] = "Keepsake of Remembrance" end
for _, i in ipairs({3517}) do I[i] = "Keg of Shindigger Stout" end
for _, i in ipairs({1262}) do I[i] = "Keg of Thunderbrew Lager" end
for _, i in ipairs({6624}) do I[i] = "Ken'zigla's Draught" end
for _, i in ipairs({5830}) do I[i] = "Kenata's Head" end
for _, i in ipairs({19602,19603,19604}) do I[i] = "Kezan's Taint" end
for _, i in ipairs({6065}) do I[i] = "Khadgar's Essays on Dimensional Convergence" end
for _, i in ipairs({6066}) do I[i] = "Khan Dez'hepah's Head" end
for _, i in ipairs({6192}) do I[i] = "Khan Hratha's Head" end
for _, i in ipairs({6072}) do I[i] = "Khan Jehn's Head" end
for _, i in ipairs({6073}) do I[i] = "Khan Shaka's Head" end
for _, i in ipairs({5006}) do I[i] = "Khazgorm's Journal" end
for _, i in ipairs({16668}) do I[i] = "Kilt of Elements" end
for _, i in ipairs({10717}) do I[i] = "Kim'Jael's Compass" end
for _, i in ipairs({10715}) do I[i] = "Kim'Jael's Scope" end
for _, i in ipairs({10722}) do I[i] = "Kim'Jael's Stuffed Chicken" end
for _, i in ipairs({10718}) do I[i] = "Kim'Jael's Wizzlegoober" end
for _, i in ipairs({3356}) do I[i] = "Kingsblood" end
for _, i in ipairs({7908}) do I[i] = "Klaven Mortwake's Journal" end
for _, i in ipairs({18953}) do I[i] = "Klinfran's Head" end
for _, i in ipairs({13703}) do I[i] = "Kodo Bone" end
for _, i in ipairs({15852}) do I[i] = "Kodo Horn" end
for _, i in ipairs({13892}) do I[i] = "Kodo Kombobulator" end
for _, i in ipairs({4896}) do I[i] = "Kodo Liver" end
for _, i in ipairs({5838}) do I[i] = "Kodo Skin Scroll" end
for _, i in ipairs({5846}) do I[i] = "Korran's Sealed Note" end
for _, i in ipairs({12472}) do I[i] = "Krakle's Thermometer" end
for _, i in ipairs({13725}) do I[i] = "Krastinov's Bag of Horrors" end
for _, i in ipairs({5801}) do I[i] = "Kraul Guano" end
for _, i in ipairs({14542}) do I[i] = "Kravel's Crate" end
for _, i in ipairs({5800}) do I[i] = "Kravel's Parts" end
for _, i in ipairs({5799}) do I[i] = "Kravel's Parts Order" end
for _, i in ipairs({5826}) do I[i] = "Kravel's Scheme" end
for _, i in ipairs({4085}) do I[i] = "Krazek's Crock Pot" end
for _, i in ipairs({1987}) do I[i] = "Krazek's Fixed Pot" end
for _, i in ipairs({5063}) do I[i] = "Kreenig Snarlsnout's Tusk" end
for _, i in ipairs({8027}) do I[i] = "Krom Stoutarm's Treasure" end
for _, i in ipairs({4891}) do I[i] = "Kron's Amulet" end
for _, i in ipairs({18625}) do I[i] = "Kroshius' Infernal Core" end
for _, i in ipairs({22217}) do I[i] = "Kurinnaxx's Venom Sac" end
for _, i in ipairs({3615}) do I[i] = "Kurzen's Head" end
for _, i in ipairs({5074}) do I[i] = "Kuz's Skull" end
for _, i in ipairs({3035}) do I[i] = "Laced Pumpkin" end
for _, i in ipairs({8428}) do I[i] = "Laden Dew Gland" end
for _, i in ipairs({9255}) do I[i] = "Lahassa Essence" end
for _, i in ipairs({16263}) do I[i] = "Laird's Response" end
for _, i in ipairs({3257}) do I[i] = "Lake Creeper Moss" end
for _, i in ipairs({3256}) do I[i] = "Lake Skulker Moss" end
for _, i in ipairs({21027}) do I[i] = "Lakmaeran's Carcass" end
for _, i in ipairs({20868}) do I[i] = "Lambent Idol" end
for _, i in ipairs({11510}) do I[i] = "Lar'korwi's Head" end
for _, i in ipairs({19034}) do I[i] = "Lard's Lunch" end
for _, i in ipairs({14344}) do I[i] = "Large Brilliant Shard" end
for _, i in ipairs({772}) do I[i] = "Large Candle" end
for _, i in ipairs({11104}) do I[i] = "Large Compass" end
for _, i in ipairs({11178}) do I[i] = "Large Radiant Shard" end
for _, i in ipairs({4053}) do I[i] = "Large River Crocolisk Skin" end
for _, i in ipairs({6915}) do I[i] = "Large Soran'ruk Fragment" end
for _, i in ipairs({4627}) do I[i] = "Large Stone Slab" end
for _, i in ipairs({7270}) do I[i] = "Laughing Sister's Hair" end
for _, i in ipairs({17011}) do I[i] = "Lava Core" end
for _, i in ipairs({19482}) do I[i] = "LeCraft Rabbit Pelt" end
for _, i in ipairs({3372}) do I[i] = "Leaded Vial" end
for _, i in ipairs({1015}) do I[i] = "Lean Wolf Flank" end
for _, i in ipairs({12209}) do I[i] = "Lean Wolf Steak" end
for _, i in ipairs({21984}) do I[i] = "Left Piece of Lord Valthalak's Amulet" end
for _, i in ipairs({6253}) do I[i] = "Leftwitch's Package" end
for _, i in ipairs({5860}) do I[i] = "Legacy of the Aspects" end
for _, i in ipairs({16732}) do I[i] = "Legplates of Valor" end
for _, i in ipairs({3516}) do I[i] = "Lescovar's Head" end
for _, i in ipairs({11642}) do I[i] = "Lesser Arcanum of Constitution" end
for _, i in ipairs({11644}) do I[i] = "Lesser Arcanum of Resilience" end
for _, i in ipairs({11622}) do I[i] = "Lesser Arcanum of Rumination" end
for _, i in ipairs({11643}) do I[i] = "Lesser Arcanum of Tenacity" end
for _, i in ipairs({11645,11646,11647,11648,11649}) do I[i] = "Lesser Arcanum of Voracity" end
for _, i in ipairs({4278}) do I[i] = "Lesser Bloodstone Ore" end
for _, i in ipairs({6990}) do I[i] = "Lesser Infernal Stone" end
for _, i in ipairs({3823}) do I[i] = "Lesser Invisibility Potion" end
for _, i in ipairs({11174}) do I[i] = "Lesser Nether Essence" end
for _, i in ipairs({18426}) do I[i] = "Lethtendris's Web" end
for _, i in ipairs({5539}) do I[i] = "Letter of Commendation" end
for _, i in ipairs({5354}) do I[i] = "Letter to Delgren" end
for _, i in ipairs({1637}) do I[i] = "Letter to Ello" end
for _, i in ipairs({5594}) do I[i] = "Letter to Jin'Zil" end
for _, i in ipairs({5948}) do I[i] = "Letter to Jorgen" end
for _, i in ipairs({2891}) do I[i] = "Letter to the City Architect" end
for _, i in ipairs({15998}) do I[i] = "Lewis' Note" end
for _, i in ipairs({11733}) do I[i] = "Libram of Constitution" end
for _, i in ipairs({18333}) do I[i] = "Libram of Focus" end
for _, i in ipairs({18334}) do I[i] = "Libram of Protection" end
for _, i in ipairs({18332}) do I[i] = "Libram of Rapidity" end
for _, i in ipairs({11736}) do I[i] = "Libram of Resilience" end
for _, i in ipairs({11732}) do I[i] = "Libram of Rumination" end
for _, i in ipairs({11734}) do I[i] = "Libram of Tenacity" end
for _, i in ipairs({11737}) do I[i] = "Libram of Voracity" end
for _, i in ipairs({3898}) do I[i] = "Library Scrip" end
for _, i in ipairs({14544}) do I[i] = "Lieutenant's Insignia" end
for _, i in ipairs({3357}) do I[i] = "Liferoot" end
for _, i in ipairs({2318}) do I[i] = "Light Leather" end
for _, i in ipairs({16723}) do I[i] = "Lightforge Belt" end
for _, i in ipairs({16725}) do I[i] = "Lightforge Boots" end
for _, i in ipairs({16722}) do I[i] = "Lightforge Bracers" end
for _, i in ipairs({16726}) do I[i] = "Lightforge Breastplate" end
for _, i in ipairs({16724}) do I[i] = "Lightforge Gauntlets" end
for _, i in ipairs({16727}) do I[i] = "Lightforge Helm" end
for _, i in ipairs({2702}) do I[i] = "Lightforge Ingot" end
for _, i in ipairs({16728}) do I[i] = "Lightforge Legplates" end
for _, i in ipairs({16729}) do I[i] = "Lightforge Spaulders" end
for _, i in ipairs({13757}) do I[i] = "Lightning Eel" end
for _, i in ipairs({4898}) do I[i] = "Lightning Gland" end
for _, i in ipairs({3620}) do I[i] = "Lillith's Remains" end
for _, i in ipairs({1251}) do I[i] = "Linen Bandage" end
for _, i in ipairs({2589}) do I[i] = "Linen Cloth" end
for _, i in ipairs({11162}) do I[i] = "Linken's Superior Sword" end
for _, i in ipairs({11136}) do I[i] = "Linken's Tempered Sword" end
for _, i in ipairs({11133}) do I[i] = "Linken's Training Sword" end
for _, i in ipairs({11106}) do I[i] = "Lion-headed Key" end
for _, i in ipairs({15447}) do I[i] = "Living Rot" end
for _, i in ipairs({16743}) do I[i] = "Logging Rope" end
for _, i in ipairs({20807,21378}) do I[i] = "Logistics Task Briefing I" end
for _, i in ipairs({20939,21379}) do I[i] = "Logistics Task Briefing II" end
for _, i in ipairs({20940,21380}) do I[i] = "Logistics Task Briefing III" end
for _, i in ipairs({21257,21258}) do I[i] = "Logistics Task Briefing IV" end
for _, i in ipairs({21265,21381}) do I[i] = "Logistics Task Briefing IX" end
for _, i in ipairs({21259,21382}) do I[i] = "Logistics Task Briefing V" end
for _, i in ipairs({21260,21261}) do I[i] = "Logistics Task Briefing VI" end
for _, i in ipairs({21263,21264}) do I[i] = "Logistics Task Briefing VII" end
for _, i in ipairs({21262,21384}) do I[i] = "Logistics Task Briefing VIII" end
for _, i in ipairs({20806,21385}) do I[i] = "Logistics Task Briefing X" end
for _, i in ipairs({21514}) do I[i] = "Logistics Task Briefing XI" end
for _, i in ipairs({5072}) do I[i] = "Lok's Skull" end
for _, i in ipairs({5790}) do I[i] = "Lonebrow's Journal" end
for _, i in ipairs({4589}) do I[i] = "Long Elegant Feather" end
for _, i in ipairs({18960}) do I[i] = "Lookout's Spyglass" end
for _, i in ipairs({18804}) do I[i] = "Lord Grayson's Satchel" end
for _, i in ipairs({22048}) do I[i] = "Lord Valthalak's Amulet" end
for _, i in ipairs({5359}) do I[i] = "Lorgalis Manuscript" end
for _, i in ipairs({6172}) do I[i] = "Lost Supplies" end
for _, i in ipairs({11312}) do I[i] = "Lost Thunderbrew Recipe" end
for _, i in ipairs({4847}) do I[i] = "Lotwil's Shackles of Elemental Binding" end
for _, i in ipairs({22265}) do I[i] = "Lovingly Composed Letter" end
for _, i in ipairs({9252}) do I[i] = "Lower Map Fragment" end
for _, i in ipairs({15851}) do I[i] = "Lunar Fungus" end
for _, i in ipairs({8411}) do I[i] = "Lung Juice Cocktail" end
for _, i in ipairs({2606}) do I[i] = "Lurker Venom" end
for _, i in ipairs({5588}) do I[i] = "Lydon's Toxin" end
for _, i in ipairs({2667}) do I[i] = "MacGrann's Dried Meats" end
for _, i in ipairs({4441}) do I[i] = "MacKreel's Moonshine" end
for _, i in ipairs({19618,19619,19620}) do I[i] = "Maelstrom's Tendril" end
for _, i in ipairs({10678}) do I[i] = "Magatha's Note" end
for _, i in ipairs({7226}) do I[i] = "Mage-tastic Gizmonitor" end
for _, i in ipairs({8047}) do I[i] = "Magenta Fungus Cap" end
for _, i in ipairs({8544}) do I[i] = "Mageweave Bandage" end
for _, i in ipairs({4338}) do I[i] = "Mageweave Cloth" end
for _, i in ipairs({3635}) do I[i] = "Maggot Eye's Paw" end
for _, i in ipairs({16189}) do I[i] = "Maggran's Reserve Letter" end
for _, i in ipairs({15688}) do I[i] = "Magic Beans" end
for _, i in ipairs({21112}) do I[i] = "Magical Book Binding" end
for _, i in ipairs({20949}) do I[i] = "Magical Ledger" end
for _, i in ipairs({16685}) do I[i] = "Magister's Belt" end
for _, i in ipairs({16683}) do I[i] = "Magister's Bindings" end
for _, i in ipairs({16682}) do I[i] = "Magister's Boots" end
for _, i in ipairs({16686}) do I[i] = "Magister's Crown" end
for _, i in ipairs({16684}) do I[i] = "Magister's Gloves" end
for _, i in ipairs({16687}) do I[i] = "Magister's Leggings" end
for _, i in ipairs({16689}) do I[i] = "Magister's Mantle" end
for _, i in ipairs({16688}) do I[i] = "Magister's Robes" end
for _, i in ipairs({21938}) do I[i] = "Magma Core" end
for _, i in ipairs({4487}) do I[i] = "Maiden's Folly Charts" end
for _, i in ipairs({4489}) do I[i] = "Maiden's Folly Log" end
for _, i in ipairs({13446}) do I[i] = "Major Healing Potion" end
for _, i in ipairs({13444}) do I[i] = "Major Mana Potion" end
for _, i in ipairs({6479}) do I[i] = "Malem Pendant" end
for _, i in ipairs({9240}) do I[i] = "Mallet of Zul'Farrak" end
for _, i in ipairs({3827}) do I[i] = "Mana Potion" end
for _, i in ipairs({3183}) do I[i] = "Mangy Claw" end
for _, i in ipairs({18775}) do I[i] = "Manna-Enriched Horse Feed" end
for _, i in ipairs({10789}) do I[i] = "Manual of Engineering Disciplines" end
for _, i in ipairs({6077}) do I[i] = "Maraudine Key Fragment" end
for _, i in ipairs({5832}) do I[i] = "Marcel's Head" end
for _, i in ipairs({4515}) do I[i] = "Marez's Head" end
for _, i in ipairs({10005}) do I[i] = "Margol's Gigantic Horn" end
for _, i in ipairs({10000}) do I[i] = "Margol's Horn" end
for _, i in ipairs({21508}) do I[i] = "Mark of Cenarius" end
for _, i in ipairs({21515}) do I[i] = "Mark of Remulos" end
for _, i in ipairs({6782}) do I[i] = "Marshal Haggard's Badge" end
for _, i in ipairs({745}) do I[i] = "Marshal McBride's Documents" end
for _, i in ipairs({11464,11465}) do I[i] = "Marshal Windsor's Lost Information" end
for _, i in ipairs({1946}) do I[i] = "Mary's Looking Glass" end
for _, i in ipairs({3855}) do I[i] = "Massive Iron Axe" end
for _, i in ipairs({17354}) do I[i] = "Master Ryson's All Seeing Eye" end
for _, i in ipairs({5273}) do I[i] = "Mathystra Relic" end
for _, i in ipairs({18705}) do I[i] = "Mature Black Dragon Sinew" end
for _, i in ipairs({18704}) do I[i] = "Mature Blue Dragon Sinew" end
for _, i in ipairs({3924}) do I[i] = "Maury's Clubbed Foot" end
for _, i in ipairs({3930}) do I[i] = "Maury's Key" end
for _, i in ipairs({3929}) do I[i] = "Maury's Loot" end
for _, i in ipairs({1208}) do I[i] = "Maybell's Love Letter" end
for _, i in ipairs({4966}) do I[i] = "Mazzranache's Head" end
for _, i in ipairs({11590}) do I[i] = "Mechanical Repair Kit" end
for _, i in ipairs({12845}) do I[i] = "Medallion of Faith" end
for _, i in ipairs({2319}) do I[i] = "Medium Leather" end
for _, i in ipairs({5221}) do I[i] = "Melenas' Head" end
for _, i in ipairs({2625}) do I[i] = "Menethil Statuette" end
for _, i in ipairs({12291}) do I[i] = "Merged Ooze Sample" end
for _, i in ipairs({21032}) do I[i] = "Meridith's Love Letter" end
for _, i in ipairs({2639}) do I[i] = "Merrin's Letter" end
for _, i in ipairs({5353}) do I[i] = "Message for Elissa Starbreeze" end
for _, i in ipairs({9592}) do I[i] = "Metallic Fragments" end
for _, i in ipairs({9253}) do I[i] = "Middle Map Fragment" end
for _, i in ipairs({7499}) do I[i] = "Middle of Gelkak's Key" end
for _, i in ipairs({1261}) do I[i] = "Midnight Orb" end
for _, i in ipairs({23548}) do I[i] = "Might of the Scourge" end
for _, i in ipairs({11119}) do I[i] = "Milly's Harvest" end
for _, i in ipairs({3616}) do I[i] = "Mind's Eye" end
for _, i in ipairs({2640}) do I[i] = "Miners' Gear" end
for _, i in ipairs({1894}) do I[i] = "Miners' Union Card" end
for _, i in ipairs({6064}) do I[i] = "Miniature Platinum Discs" end
for _, i in ipairs({18956}) do I[i] = "Miniaturization Residue" end
for _, i in ipairs({12840}) do I[i] = "Minion's Scourgestone" end
for _, i in ipairs({2455}) do I[i] = "Minor Mana Potion" end
for _, i in ipairs({4864}) do I[i] = "Minshina's Skull" end
for _, i in ipairs({6081}) do I[i] = "Mire Lord Fungus" end
for _, i in ipairs({5847}) do I[i] = "Mirefin Head" end
for _, i in ipairs({7206}) do I[i] = "Mirror Lake Water Sample" end
for _, i in ipairs({2252}) do I[i] = "Miscellaneous Goblin Supplies" end
for _, i in ipairs({12192}) do I[i] = "Mist Veil's Lockbox" end
for _, i in ipairs({3629}) do I[i] = "Mistmantle Family Ring" end
for _, i in ipairs({3919}) do I[i] = "Mistvale Giblets" end
for _, i in ipairs({16970}) do I[i] = "Misty Reed Mahi Mahi" end
for _, i in ipairs({3860}) do I[i] = "Mithril Bar" end
for _, i in ipairs({10561}) do I[i] = "Mithril Casing" end
for _, i in ipairs({7931}) do I[i] = "Mithril Coif" end
for _, i in ipairs({8663}) do I[i] = "Mithril Insignia" end
for _, i in ipairs({8686}) do I[i] = "Mithril Pendant" end
for _, i in ipairs({10559}) do I[i] = "Mithril Tube" end
for _, i in ipairs({2607}) do I[i] = "Mo'grosh Crystal" end
for _, i in ipairs({8524}) do I[i] = "Model 4711-FTZ Power Source" end
for _, i in ipairs({5865}) do I[i] = "Modified Seaforium Booster" end
for _, i in ipairs({2659}) do I[i] = "Modr Fragment" end
for _, i in ipairs({5835}) do I[i] = "Mok'Morokk's Grog" end
for _, i in ipairs({5834}) do I[i] = "Mok'Morokk's Snuff" end
for _, i in ipairs({5836}) do I[i] = "Mok'Morokk's Strongbox" end
for _, i in ipairs({6931}) do I[i] = "Moldy Tome" end
for _, i in ipairs({3985}) do I[i] = "Monogrammed Sash" end
for _, i in ipairs({6184}) do I[i] = "Monstrous Crawler Leg" end
for _, i in ipairs({14342}) do I[i] = "Mooncloth" end
for _, i in ipairs({10641}) do I[i] = "Moonpetal Lily" end
for _, i in ipairs({5413}) do I[i] = "Moonstalker Fang" end
for _, i in ipairs({3853}) do I[i] = "Moonsteel Broadsword" end
for _, i in ipairs({12383}) do I[i] = "Moontouched Feather" end
for _, i in ipairs({14339}) do I[i] = "Moonwell Water Tube" end
for _, i in ipairs({3514}) do I[i] = "Mor'Ladim's Skull" end
for _, i in ipairs({18818}) do I[i] = "Mor'zul's Instructions" end
for _, i in ipairs({7297}) do I[i] = "Morbent's Bane" end
for _, i in ipairs({15454}) do I[i] = "Mortar and Pestle" end
for _, i in ipairs({1206}) do I[i] = "Moss Agate" end
for _, i in ipairs({5179}) do I[i] = "Moss-twined Heart" end
for _, i in ipairs({5170}) do I[i] = "Mossy Tumor" end
for _, i in ipairs({4435}) do I[i] = "Mote of Myzrael" end
for _, i in ipairs({4742}) do I[i] = "Mountain Cougar Pelt" end
for _, i in ipairs({9597}) do I[i] = "Mountain Giant Muisek" end
for _, i in ipairs({9621}) do I[i] = "Mountain Giant Muisek Vessel" end
for _, i in ipairs({3496}) do I[i] = "Mountain Lion Blood" end
for _, i in ipairs({3551}) do I[i] = "Muckrake's Head" end
for _, i in ipairs({938}) do I[i] = "Muddy Journal Pages" end
for _, i in ipairs({2720}) do I[i] = "Muddy Note" end
for _, i in ipairs({19974}) do I[i] = "Mudskunk Lure" end
for _, i in ipairs({3502}) do I[i] = "Mudsnout Blossoms" end
for _, i in ipairs({3506}) do I[i] = "Mudsnout Composite" end
for _, i in ipairs({3508}) do I[i] = "Mudsnout Mixture" end
for _, i in ipairs({3553}) do I[i] = "Mug'thol's Head" end
for _, i in ipairs({17323}) do I[i] = "Mulverick's Beacon" end
for _, i in ipairs({16976}) do I[i] = "Murgut's Totem" end
for _, i in ipairs({730}) do I[i] = "Murloc Eye" end
for _, i in ipairs({1468}) do I[i] = "Murloc Fin" end
for _, i in ipairs({3716}) do I[i] = "Murloc Head" end
for _, i in ipairs({2784}) do I[i] = "Musquash Root" end
for _, i in ipairs({6279}) do I[i] = "Musty Letter" end
for _, i in ipairs({6280}) do I[i] = "Musty Missive" end
for _, i in ipairs({6276}) do I[i] = "Musty Note" end
for _, i in ipairs({6277}) do I[i] = "Musty Parchment" end
for _, i in ipairs({6278}) do I[i] = "Musty Scroll" end
for _, i in ipairs({10442}) do I[i] = "Mysterious Artifact" end
for _, i in ipairs({21043}) do I[i] = "Mysterious Envelope" end
for _, i in ipairs({4654}) do I[i] = "Mysterious Fossil" end
for _, i in ipairs({9248}) do I[i] = "Mysterious Relic" end
for _, i in ipairs({13156}) do I[i] = "Mystic Crystal" end
for _, i in ipairs({5536}) do I[i] = "Mythology of the Titans" end
for _, i in ipairs({5695}) do I[i] = "NG-5 Explosives (Blue)" end
for _, i in ipairs({5694}) do I[i] = "NG-5 Explosives (Red)" end
for _, i in ipairs({3707}) do I[i] = "Nagaz Parchment" end
for _, i in ipairs({11413}) do I[i] = "Nagmara's Filled Vial" end
for _, i in ipairs({11412}) do I[i] = "Nagmara's Vial" end
for _, i in ipairs({5073}) do I[i] = "Nak's Skull" end
for _, i in ipairs({20951}) do I[i] = "Narain's Scrying Goggles" end
for _, i in ipairs({21042}) do I[i] = "Narain's Special Kit" end
for _, i in ipairs({19973}) do I[i] = "Nat's Measuring Tape" end
for _, i in ipairs({15876}) do I[i] = "Nathanos' Chest" end
for _, i in ipairs({18172}) do I[i] = "Nature Mantle of the Dawn" end
for _, i in ipairs({7887}) do I[i] = "Necklace and Gem Salvage" end
for _, i in ipairs({22484}) do I[i] = "Necrotic Rune" end
for _, i in ipairs({6167}) do I[i] = "Neeka's Report" end
for _, i in ipairs({9628}) do I[i] = "Neeru's Herb Pouch" end
for _, i in ipairs({3625}) do I[i] = "Nek'rosh's Head" end
for _, i in ipairs({9471}) do I[i] = "Nekrum's Medallion" end
for _, i in ipairs({2661}) do I[i] = "Neru Fragment" end
for _, i in ipairs({16262}) do I[i] = "Nessa's Collection" end
for _, i in ipairs({3081}) do I[i] = "Nether Gem" end
for _, i in ipairs({6251}) do I[i] = "Nether Wing" end
for _, i in ipairs({20725}) do I[i] = "Nexus Crystal" end
for _, i in ipairs({3905}) do I[i] = "Nezzliok's Head" end
for _, i in ipairs({11952}) do I[i] = "Night Dragon's Breath" end
for _, i in ipairs({20644}) do I[i] = "Nightmare Engulfed Object" end
for _, i in ipairs({10649}) do I[i] = "Nightmare Shard" end
for _, i in ipairs({3409}) do I[i] = "Nightsaber Fang" end
for _, i in ipairs({8197}) do I[i] = "Nightscape Boots" end
for _, i in ipairs({8176}) do I[i] = "Nightscape Headband" end
for _, i in ipairs({8193}) do I[i] = "Nightscape Pants" end
for _, i in ipairs({8175}) do I[i] = "Nightscape Tunic" end
for _, i in ipairs({15002}) do I[i] = "Nimboya's Pike" end
for _, i in ipairs({2828}) do I[i] = "Nissa's Remains" end
for _, i in ipairs({5017}) do I[i] = "Nitroglycerin" end
for _, i in ipairs({10792}) do I[i] = "Nixx's Pledge of Secrecy" end
for _, i in ipairs({11270}) do I[i] = "Nixx's Signed Pledge" end
for _, i in ipairs({6196}) do I[i] = "Noboru's Cudgel" end
for _, i in ipairs({20379}) do I[i] = "Noggle's Satchel" end
for _, i in ipairs({7628}) do I[i] = "Nondescript Letter" end
for _, i in ipairs({10440}) do I[i] = "Nori's Mug" end
for _, i in ipairs({14646}) do I[i] = "Northshire Gift Voucher" end
for _, i in ipairs({3162}) do I[i] = "Notched Rib" end
for _, i in ipairs({5174}) do I[i] = "Note from Neeru" end
for _, i in ipairs({11143}) do I[i] = "Nugget Slug" end
for _, i in ipairs({6090}) do I[i] = "OLDNoboru's Cudgel" end
for _, i in ipairs({5438}) do I[i] = "OLDPlague Vials" end
for _, i in ipairs({8704}) do I[i] = "OOX-09/HL Distress Beacon" end
for _, i in ipairs({8623}) do I[i] = "OOX-17/TN Distress Beacon" end
for _, i in ipairs({8705}) do I[i] = "OOX-22/FE Distress Beacon" end
for _, i in ipairs({10589}) do I[i] = "Oathstone of Ysera's Dragonflight" end
for _, i in ipairs({7681}) do I[i] = "Obsidian Golem Shard" end
for _, i in ipairs({20871}) do I[i] = "Obsidian Idol" end
for _, i in ipairs({8053}) do I[i] = "Obsidian Power Source" end
for _, i in ipairs({14679}) do I[i] = "Of Love and Family" end
for _, i in ipairs({10794}) do I[i] = "Oglethorpe's Pledge of Secrecy" end
for _, i in ipairs({11282}) do I[i] = "Oglethorpe's Signed Pledge" end
for _, i in ipairs({18240}) do I[i] = "Ogre Tannin" end
for _, i in ipairs({21982}) do I[i] = "Ogre Warbeads" end
for _, i in ipairs({1968}) do I[i] = "Ogre's Monocle" end
for _, i in ipairs({8956}) do I[i] = "Oil of Immolation" end
for _, i in ipairs({732}) do I[i] = "Okra" end
for _, i in ipairs({2713}) do I[i] = "Ol' Sooty's Head" end
for _, i in ipairs({22719}) do I[i] = "Omarion's Handbook" end
for _, i in ipairs({12534}) do I[i] = "Omokk's Head" end
for _, i in ipairs({7715}) do I[i] = "Onin's Report" end
for _, i in ipairs({20867}) do I[i] = "Onyx Idol" end
for _, i in ipairs({4844}) do I[i] = "Opal Runestone" end
for _, i in ipairs({4551}) do I[i] = "Or'Kalar's Head" end
for _, i in ipairs({6442}) do I[i] = "Oracle Crystal" end
for _, i in ipairs({19710}) do I[i] = "Orange Hakkari Bijou" end
for _, i in ipairs({12300}) do I[i] = "Orb of Draconic Energy" end
for _, i in ipairs({18207}) do I[i] = "Orc Tooth" end
for _, i in ipairs({18597}) do I[i] = "Orcish Orphan Whistle" end
for _, i in ipairs({5686}) do I[i] = "Ordanus' Head" end
for _, i in ipairs({8645}) do I[i] = "Ordinary Egg" end
for _, i in ipairs({5460}) do I[i] = "Orendil's Cure" end
for _, i in ipairs({20493}) do I[i] = "Orgrimmar Nougat" end
for _, i in ipairs({16191}) do I[i] = "Ornate Mirror" end
for _, i in ipairs({7936}) do I[i] = "Ornate Mithril Boots" end
for _, i in ipairs({7935}) do I[i] = "Ornate Mithril Breastplate" end
for _, i in ipairs({7927}) do I[i] = "Ornate Mithril Gloves" end
for _, i in ipairs({7937}) do I[i] = "Ornate Mithril Helm" end
for _, i in ipairs({7926}) do I[i] = "Ornate Mithril Pants" end
for _, i in ipairs({7928}) do I[i] = "Ornate Mithril Shoulder" end
for _, i in ipairs({9466}) do I[i] = "Orwin's Shovel" end
for _, i in ipairs({1309}) do I[i] = "Oslow's Toolbox" end
for _, i in ipairs({16115}) do I[i] = "Osric's Crate" end
for _, i in ipairs({13357}) do I[i] = "Osseous Agitator" end
for _, i in ipairs({4516}) do I[i] = "Otto's Head" end
for _, i in ipairs({20927}) do I[i] = "Ouro's Intact Hide" end
for _, i in ipairs({11724}) do I[i] = "Overdue Package" end
for _, i in ipairs({15879}) do I[i] = "Overlord Ror's Claw" end
for _, i in ipairs({7333}) do I[i] = "Overseer's Whistle" end
for _, i in ipairs({10793}) do I[i] = "Overspark's Pledge of Secrecy" end
for _, i in ipairs({11283}) do I[i] = "Overspark's Signed Pledge" end
for _, i in ipairs({5102}) do I[i] = "Owatanka's Tailspike" end
for _, i in ipairs({2806}) do I[i] = "Package for Stormpike" end
for _, i in ipairs({11912}) do I[i] = "Package of Empty Ooze Containers" end
for _, i in ipairs({11022}) do I[i] = "Packet of Tharlendris Seeds" end
for _, i in ipairs({782}) do I[i] = "Painted Gnoll Armband" end
for _, i in ipairs({12354}) do I[i] = "Palomino Bridle" end
for _, i in ipairs({12885}) do I[i] = "Pamela's Doll" end
for _, i in ipairs({12886}) do I[i] = "Pamela's Doll's Head" end
for _, i in ipairs({12887}) do I[i] = "Pamela's Doll's Left Side" end
for _, i in ipairs({12888}) do I[i] = "Pamela's Doll's Right Side" end
for _, i in ipairs({12942}) do I[i] = "Panther Cage Key" end
for _, i in ipairs({5534}) do I[i] = "Parker's Lunch" end
for _, i in ipairs({5186}) do I[i] = "Partially Filled Vessel" end
for _, i in ipairs({15850}) do I[i] = "Patch of Duskwing's Fur" end
for _, i in ipairs({11512}) do I[i] = "Patch of Tainted Skin" end
for _, i in ipairs({2868}) do I[i] = "Patterned Bronze Bracers" end
for _, i in ipairs({16669}) do I[i] = "Pauldrons of Elements" end
for _, i in ipairs({3879}) do I[i] = "Paw of Sin'Dall" end
for _, i in ipairs({2447}) do I[i] = "Peacebloom" end
for _, i in ipairs({19598,19599,19600}) do I[i] = "Pebble of Kajaro" end
for _, i in ipairs({4614}) do I[i] = "Pendant of Myzrael" end
for _, i in ipairs({3617}) do I[i] = "Pendant of Shadow" end
for _, i in ipairs({15885}) do I[i] = "Pendant of the Sea Lion" end
for _, i in ipairs({3684}) do I[i] = "Perenolde Tiara" end
for _, i in ipairs({20017}) do I[i] = "Perfect Courser Antler" end
for _, i in ipairs({18972}) do I[i] = "Perfect Yeti Hide" end
for _, i in ipairs({21829}) do I[i] = "Perfume Bottle" end
for _, i in ipairs({11844}) do I[i] = "Pestlezugg's Un'Goro Report" end
for _, i in ipairs({18708}) do I[i] = "Petrified Bark" end
for _, i in ipairs({5251}) do I[i] = "Phial of Scrying" end
for _, i in ipairs({11227}) do I[i] = "Piece of Krom'zar's Banner" end
for _, i in ipairs({11504}) do I[i] = "Piece of Threshadon Carcass" end
for _, i in ipairs({10650}) do I[i] = "Plague-Infested Quilboar Mane" end
for _, i in ipairs({13174}) do I[i] = "Plagued Flesh Sample" end
for _, i in ipairs({15043}) do I[i] = "Plagueland Termites" end
for _, i in ipairs({5087}) do I[i] = "Plainstrider Beak" end
for _, i in ipairs({4740}) do I[i] = "Plainstrider Feather" end
for _, i in ipairs({4894}) do I[i] = "Plainstrider Kidney" end
for _, i in ipairs({4739}) do I[i] = "Plainstrider Meat" end
for _, i in ipairs({4806}) do I[i] = "Plainstrider Scale" end
for _, i in ipairs({4759}) do I[i] = "Plainstrider Talon" end
for _, i in ipairs({13890}) do I[i] = "Plated Armorfish" end
for _, i in ipairs({10590}) do I[i] = "Pocked Black Box" end
for _, i in ipairs({16209}) do I[i] = "Podrig's Order" end
for _, i in ipairs({962}) do I[i] = "Pork Belly Pie" end
for _, i in ipairs({19277}) do I[i] = "Portals Deck" end
for _, i in ipairs({21211}) do I[i] = "Pouch of Reindeer Dust" end
for _, i in ipairs({7127}) do I[i] = "Powdered Azurite" end
for _, i in ipairs({23545}) do I[i] = "Power of the Scourge" end
for _, i in ipairs({19440}) do I[i] = "Powerful Anti-Venom" end
for _, i in ipairs({12804}) do I[i] = "Powerful Mojo" end
for _, i in ipairs({6785}) do I[i] = "Powers of the Void" end
for _, i in ipairs({4803}) do I[i] = "Prairie Alpha Tooth" end
for _, i in ipairs({4804}) do I[i] = "Prairie Wolf Heart" end
for _, i in ipairs({4758}) do I[i] = "Prairie Wolf Paw" end
for _, i in ipairs({9235}) do I[i] = "Pratt's Letter" end
for _, i in ipairs({10458}) do I[i] = "Prayer to Elune" end
for _, i in ipairs({23024}) do I[i] = "Prepared Field Duty Papers" end
for _, i in ipairs({11570}) do I[i] = "Preserved Pheromone Mixture" end
for _, i in ipairs({11569}) do I[i] = "Preserved Threshadon Meat" end
for _, i in ipairs({5808}) do I[i] = "Pridewing Venom Sac" end
for _, i in ipairs({19724}) do I[i] = "Primal Hakkari Aegis" end
for _, i in ipairs({19717}) do I[i] = "Primal Hakkari Armsplint" end
for _, i in ipairs({19716}) do I[i] = "Primal Hakkari Bindings" end
for _, i in ipairs({19719}) do I[i] = "Primal Hakkari Girdle" end
for _, i in ipairs({22637}) do I[i] = "Primal Hakkari Idol" end
for _, i in ipairs({19723}) do I[i] = "Primal Hakkari Kossack" end
for _, i in ipairs({19720}) do I[i] = "Primal Hakkari Sash" end
for _, i in ipairs({19721}) do I[i] = "Primal Hakkari Shawl" end
for _, i in ipairs({19718}) do I[i] = "Primal Hakkari Stanchion" end
for _, i in ipairs({19722}) do I[i] = "Primal Hakkari Tabard" end
for _, i in ipairs({9316}) do I[i] = "Prismatic Punch Card" end
for _, i in ipairs({23250}) do I[i] = "Prismatic Shell" end
for _, i in ipairs({18335}) do I[i] = "Pristine Black Diamond" end
for _, i in ipairs({5938}) do I[i] = "Pristine Crawler Leg" end
for _, i in ipairs({12731}) do I[i] = "Pristine Hide of the Beast" end
for _, i in ipairs({7267}) do I[i] = "Pristine Spider Silk" end
for _, i in ipairs({3839}) do I[i] = "Pristine Tigress Fang" end
for _, i in ipairs({18969}) do I[i] = "Pristine Yeti Hide" end
for _, i in ipairs({12367}) do I[i] = "Pristine Yeti Horn" end
for _, i in ipairs({10022}) do I[i] = "Proof of Deed" end
for _, i in ipairs({4702}) do I[i] = "Prospector's Pick" end
for _, i in ipairs({5096}) do I[i] = "Prowler Claws" end
for _, i in ipairs({3911}) do I[i] = "Pulsing Blue Shard" end
for _, i in ipairs({19813,19814,19815,19816,19817,19818,19819,19820,19821}) do I[i] = "Punctured Voodoo Doll" end
for _, i in ipairs({3900}) do I[i] = "Pupellyverbos Port" end
for _, i in ipairs({6286}) do I[i] = "Pure Hearts" end
for _, i in ipairs({12236}) do I[i] = "Pure Un'Goro Sample" end
for _, i in ipairs({7083}) do I[i] = "Purified Kor Gem" end
for _, i in ipairs({12906}) do I[i] = "Purified Moonwell Water" end
for _, i in ipairs({19712}) do I[i] = "Purple Hakkari Bijou" end
for _, i in ipairs({8831}) do I[i] = "Purple Lotus" end
for _, i in ipairs({20024}) do I[i] = "Putrid Bile Duct" end
for _, i in ipairs({2855}) do I[i] = "Putrid Claw" end
for _, i in ipairs({22444}) do I[i] = "Putrid Vine" end
for _, i in ipairs({3218}) do I[i] = "Pyrewood Shackle" end
for _, i in ipairs({20928}) do I[i] = "Qiraji Bindings of Command" end
for _, i in ipairs({20932}) do I[i] = "Qiraji Bindings of Dominance" end
for _, i in ipairs({20936}) do I[i] = "Qiraji Blessed Jewel" end
for _, i in ipairs({20888}) do I[i] = "Qiraji Ceremonial Ring" end
for _, i in ipairs({20937}) do I[i] = "Qiraji Encased Jewel" end
for _, i in ipairs({20887}) do I[i] = "Qiraji Engraved Jewel" end
for _, i in ipairs({20883}) do I[i] = "Qiraji Glyphed Jewel" end
for _, i in ipairs({21229}) do I[i] = "Qiraji Lord's Insignia" end
for _, i in ipairs({20884}) do I[i] = "Qiraji Magisterial Ring" end
for _, i in ipairs({20885}) do I[i] = "Qiraji Martial Drape" end
for _, i in ipairs({20890}) do I[i] = "Qiraji Ornate Hilt" end
for _, i in ipairs({20889}) do I[i] = "Qiraji Regal Drape" end
for _, i in ipairs({20886}) do I[i] = "Qiraji Spiked Hilt" end
for _, i in ipairs({15847}) do I[i] = "Quel'Thalas Registry" end
for _, i in ipairs({3165}) do I[i] = "Quinn's Potion" end
for _, i in ipairs({17355}) do I[i] = "Rabine's Letter" end
for _, i in ipairs({15881}) do I[i] = "Rackmore's Golden Key" end
for _, i in ipairs({15878}) do I[i] = "Rackmore's Silver Key" end
for _, i in ipairs({12417}) do I[i] = "Radiant Circlet" end
for _, i in ipairs({18947}) do I[i] = "Rage Scar Yeti Hide" end
for _, i in ipairs({18590}) do I[i] = "Raging Beast's Blood" end
for _, i in ipairs({5095}) do I[i] = "Rainbow Fin Albacore" end
for _, i in ipairs({5388}) do I[i] = "Ran Bloodtooth's Skull" end
for _, i in ipairs({21029}) do I[i] = "Ransom Letter" end
for _, i in ipairs({5062}) do I[i] = "Raptor Head" end
for _, i in ipairs({4513}) do I[i] = "Raptor Heart" end
for _, i in ipairs({4526}) do I[i] = "Raptor Talon Amulet" end
for _, i in ipairs({5391}) do I[i] = "Rare Earth" end
for _, i in ipairs({11466}) do I[i] = "Raschal's Report" end
for _, i in ipairs({17117}) do I[i] = "Rat Catcher's Flute" end
for _, i in ipairs({6281}) do I[i] = "Rattlecage Skull" end
for _, i in ipairs({2477}) do I[i] = "Ravager's Skull" end
for _, i in ipairs({11509}) do I[i] = "Ravasaur Pheromone Gland" end
for _, i in ipairs({3405}) do I[i] = "Raven Claw Talisman" end
for _, i in ipairs({5793}) do I[i] = "Razorflank's Heart" end
for _, i in ipairs({5792}) do I[i] = "Razorflank's Medallion" end
for _, i in ipairs({5093}) do I[i] = "Razormane Backstabber" end
for _, i in ipairs({5094}) do I[i] = "Razormane War Shield" end
for _, i in ipairs({19699}) do I[i] = "Razzashi Coin" end
for _, i in ipairs({6652}) do I[i] = "Reagent Pouch" end
for _, i in ipairs({5547}) do I[i] = "Reconstructed Rod" end
for _, i in ipairs({7006}) do I[i] = "Reconstructed Tome" end
for _, i in ipairs({3658}) do I[i] = "Recovered Tome" end
for _, i in ipairs({4992}) do I[i] = "Recruitment Letter" end
for _, i in ipairs({752}) do I[i] = "Red Burlap Bandana" end
for _, i in ipairs({2604}) do I[i] = "Red Dye" end
for _, i in ipairs({19707}) do I[i] = "Red Hakkari Bijou" end
for _, i in ipairs({829}) do I[i] = "Red Leather Bandana" end
for _, i in ipairs({1019}) do I[i] = "Red Linen Bandana" end
for _, i in ipairs({18153}) do I[i] = "Red Moro'gai Gem" end
for _, i in ipairs({11186}) do I[i] = "Red Power Crystal" end
for _, i in ipairs({9281}) do I[i] = "Red Punch Card" end
for _, i in ipairs({21138}) do I[i] = "Red Scepter Shard" end
for _, i in ipairs({915}) do I[i] = "Red Silk Bandana" end
for _, i in ipairs({2909}) do I[i] = "Red Wool Bandana" end
for _, i in ipairs({4748}) do I[i] = "Redhorn Well Water" end
for _, i in ipairs({12955}) do I[i] = "Redpath's Shield" end
for _, i in ipairs({5950}) do I[i] = "Reethe's Badge" end
for _, i in ipairs({159}) do I[i] = "Refreshing Spring Water" end
for _, i in ipairs({12302}) do I[i] = "Reins of the Frostsaber" end
for _, i in ipairs({12303}) do I[i] = "Reins of the Nightsaber" end
for _, i in ipairs({15209}) do I[i] = "Relic Bundle" end
for _, i in ipairs({18539,22201}) do I[i] = "Reliquary of Purity" end
for _, i in ipairs({7811}) do I[i] = "Remaining Drops of Purest Water" end
for _, i in ipairs({13562}) do I[i] = "Remains of Trey Lightforge" end
for _, i in ipairs({3155}) do I[i] = "Remedy of Arugal" end
for _, i in ipairs({5693}) do I[i] = "Remote Detonator (Blue)" end
for _, i in ipairs({5692}) do I[i] = "Remote Detonator (Red)" end
for _, i in ipairs({19940}) do I[i] = "Renataki's Tooth" end
for _, i in ipairs({5027}) do I[i] = "Rendered Spores" end
for _, i in ipairs({3468}) do I[i] = "Renferrel's Findings" end
for _, i in ipairs({2956}) do I[i] = "Report on the Defias Brotherhood" end
for _, i in ipairs({11112}) do I[i] = "Research Equipment" end
for _, i in ipairs({23547}) do I[i] = "Resilience of the Scourge" end
for _, i in ipairs({9591}) do I[i] = "Resilient Sinew" end
for _, i in ipairs({13155}) do I[i] = "Resonating Skull" end
for _, i in ipairs({16581}) do I[i] = "Resonite Crystal" end
for _, i in ipairs({3083}) do I[i] = "Restabilization Cog" end
for _, i in ipairs({20401}) do I[i] = "Restored Twilight Tablet" end
for _, i in ipairs({2798}) do I[i] = "Rethban Ore" end
for _, i in ipairs({8070}) do I[i] = "Reward Voucher" end
for _, i in ipairs({2894}) do I[i] = "Rhapsody Malt" end
for _, i in ipairs({11313}) do I[i] = "Ribbly's Head" end
for _, i in ipairs({12437}) do I[i] = "Ridgewell's Crate" end
for _, i in ipairs({9153}) do I[i] = "Rig Blueprints" end
for _, i in ipairs({22046}) do I[i] = "Right Piece of Lord Valthalak's Amulet" end
for _, i in ipairs({12811}) do I[i] = "Righteous Orb" end
for _, i in ipairs({8724}) do I[i] = "Rin'ji's Secret" end
for _, i in ipairs({5445}) do I[i] = "Ring of Zoram" end
for _, i in ipairs({6634}) do I[i] = "Ritual Salve" end
for _, i in ipairs({7274}) do I[i] = "Rituals of Power" end
for _, i in ipairs({12210}) do I[i] = "Roast Raptor" end
for _, i in ipairs({5770}) do I[i] = "Robes of Arcana" end
for _, i in ipairs({9309}) do I[i] = "Robo-mechanical Guts" end
for _, i in ipairs({6257}) do I[i] = "Roc Gizzard" end
for _, i in ipairs({7848}) do I[i] = "Rock Elemental Shard" end
for _, i in ipairs({20377}) do I[i] = "Rock Stalker Fang" end
for _, i in ipairs({5798}) do I[i] = "Rocket Car Parts" end
for _, i in ipairs({6930}) do I[i] = "Rod of Channeling" end
for _, i in ipairs({3710}) do I[i] = "Rod of Helcular" end
for _, i in ipairs({4469}) do I[i] = "Rod of Order" end
for _, i in ipairs({18819}) do I[i] = "Rohan's Exorcism Censer" end
for _, i in ipairs({10478}) do I[i] = "Roland's Mana Gem" end
for _, i in ipairs({735}) do I[i] = "Rolf and Malakai's Medallions" end
for _, i in ipairs({14546}) do I[i] = "Roon's Kodo Horn" end
for _, i in ipairs({5056}) do I[i] = "Root Sample" end
for _, i in ipairs({1598}) do I[i] = "Rot Blossom" end
for _, i in ipairs({3236}) do I[i] = "Rot Hide Ichor" end
for _, i in ipairs({15875}) do I[i] = "Rotten Apple" end
for _, i in ipairs({20605}) do I[i] = "Rotten Eggs" end
for _, i in ipairs({20026}) do I[i] = "Rotting Flesh" end
for _, i in ipairs({20613}) do I[i] = "Rotting Wood" end
for _, i in ipairs({6656}) do I[i] = "Rough Quartz" end
for _, i in ipairs({10563}) do I[i] = "Rubbing: Rune of Beth'Amara" end
for _, i in ipairs({10564}) do I[i] = "Rubbing: Rune of Jin'yael" end
for _, i in ipairs({10565}) do I[i] = "Rubbing: Rune of Markri" end
for _, i in ipairs({10566}) do I[i] = "Rubbing: Rune of Sael'hai" end
for _, i in ipairs({15564}) do I[i] = "Rugged Armor Kit" end
for _, i in ipairs({8170}) do I[i] = "Rugged Leather" end
for _, i in ipairs({15696}) do I[i] = "Ruined Tome" end
for _, i in ipairs({13850}) do I[i] = "Rumbleshot's Ammo" end
for _, i in ipairs({14341}) do I[i] = "Rune Thread" end
for _, i in ipairs({11198}) do I[i] = "Rune of Escape" end
for _, i in ipairs({3408}) do I[i] = "Rune of Nesting" end
for _, i in ipairs({3745}) do I[i] = "Rune of Opening" end
for _, i in ipairs({18149,18150}) do I[i] = "Rune of Recall" end
for _, i in ipairs({9552}) do I[i] = "Rune-Inscribed Note" end
for _, i in ipairs({9568}) do I[i] = "Rune-Inscribed Parchment" end
for _, i in ipairs({9562}) do I[i] = "Rune-Inscribed Tablet" end
for _, i in ipairs({3353}) do I[i] = "Rune-inscribed Pendant" end
for _, i in ipairs({14047}) do I[i] = "Runecloth" end
for _, i in ipairs({14046}) do I[i] = "Runecloth Bag" end
for _, i in ipairs({14529}) do I[i] = "Runecloth Bandage" end
for _, i in ipairs({13864}) do I[i] = "Runecloth Boots" end
for _, i in ipairs({13858}) do I[i] = "Runecloth Robe" end
for _, i in ipairs({2857}) do I[i] = "Runed Copper Belt" end
for _, i in ipairs({10621}) do I[i] = "Runed Scroll" end
for _, i in ipairs({6284}) do I[i] = "Runes of Summoning" end
for _, i in ipairs({15095}) do I[i] = "Runic Leather Pants" end
for _, i in ipairs({3704}) do I[i] = "Rusted Iron Key" end
for _, i in ipairs({4616}) do I[i] = "Ryedol's Lucky Pick" end
for _, i in ipairs({17362,17363}) do I[i] = "Ryson's Beacon" end
for _, i in ipairs({16001}) do I[i] = "SI:7 Insignia (Fredo)" end
for _, i in ipairs({16003}) do I[i] = "SI:7 Insignia (Rutger)" end
for _, i in ipairs({16002}) do I[i] = "SI:7 Insignia (Turyen)" end
for _, i in ipairs({738}) do I[i] = "Sack of Barley" end
for _, i in ipairs({739}) do I[i] = "Sack of Corn" end
for _, i in ipairs({3717}) do I[i] = "Sack of Murloc Heads" end
for _, i in ipairs({740}) do I[i] = "Sack of Rye" end
for _, i in ipairs({4918}) do I[i] = "Sack of Supplies" end
for _, i in ipairs({19883}) do I[i] = "Sacred Cord" end
for _, i in ipairs({12733}) do I[i] = "Sacred Frostsaber Meat" end
for _, i in ipairs({13313}) do I[i] = "Sacred Highborne Writings" end
for _, i in ipairs({9241}) do I[i] = "Sacred Mallet" end
for _, i in ipairs({5794}) do I[i] = "Salty Scorpid Venom" end
for _, i in ipairs({9257}) do I[i] = "Samha Essence" end
for _, i in ipairs({11149}) do I[i] = "Samophlange Manual" end
for _, i in ipairs({11147}) do I[i] = "Samophlange Manual Cover" end
for _, i in ipairs({11148}) do I[i] = "Samophlange Manual Page" end
for _, i in ipairs({4502}) do I[i] = "Sample Elven Gem" end
for _, i in ipairs({3237}) do I[i] = "Sample Ichor" end
for _, i in ipairs({10414}) do I[i] = "Sample Snapjaw Shell" end
for _, i in ipairs({5866}) do I[i] = "Sample of Indurium Ore" end
for _, i in ipairs({8087}) do I[i] = "Sample of Zanzil's Altered Mixture" end
for _, i in ipairs({16333}) do I[i] = "Samuel's Remains" end
for _, i in ipairs({20376}) do I[i] = "Sand Skitterer Fang" end
for _, i in ipairs({19704}) do I[i] = "Sandfury Coin" end
for _, i in ipairs({16784}) do I[i] = "Sapphire of Aku'Mai" end
for _, i in ipairs({3407}) do I[i] = "Sapphire of Sky" end
for _, i in ipairs({16968}) do I[i] = "Sar'theris Striker" end
for _, i in ipairs({4514}) do I[i] = "Sara Balloo's Plea" end
for _, i in ipairs({2162}) do I[i] = "Sarah's Ring" end
for _, i in ipairs({5537}) do I[i] = "Sarilus Foulborne's Head" end
for _, i in ipairs({4905}) do I[i] = "Sarkoth's Mangled Claw" end
for _, i in ipairs({3638}) do I[i] = "Sarltooth's Talon" end
for _, i in ipairs({8155}) do I[i] = "Sathrah's Sacrifice" end
for _, i in ipairs({18603}) do I[i] = "Satyr Blood" end
for _, i in ipairs({5481}) do I[i] = "Satyr Horns" end
for _, i in ipairs({16969}) do I[i] = "Savage Coast Blue Sailfin" end
for _, i in ipairs({22529}) do I[i] = "Savage Frond" end
for _, i in ipairs({4893}) do I[i] = "Savannah Lion Tusk" end
for _, i in ipairs({6168}) do I[i] = "Sawtooth Snapper Claw" end
for _, i in ipairs({19423}) do I[i] = "Sayge's Fortune #23" end
for _, i in ipairs({19424}) do I[i] = "Sayge's Fortune #24" end
for _, i in ipairs({19443}) do I[i] = "Sayge's Fortune #25" end
for _, i in ipairs({19452}) do I[i] = "Sayge's Fortune #27" end
for _, i in ipairs({5271}) do I[i] = "Scaber Stalk" end
for _, i in ipairs({3636}) do I[i] = "Scale of Old Murk-Eye" end
for _, i in ipairs({3266}) do I[i] = "Scarlet Armband" end
for _, i in ipairs({2885}) do I[i] = "Scarlet Crusade Documents" end
for _, i in ipairs({2875}) do I[i] = "Scarlet Insignia Ring" end
for _, i in ipairs({11127}) do I[i] = "Scavenged Goods" end
for _, i in ipairs({3265}) do I[i] = "Scavenger Paw" end
for _, i in ipairs({17191}) do I[i] = "Scepter of Celebras" end
for _, i in ipairs({12369}) do I[i] = "Scepter of Vectus" end
for _, i in ipairs({15750}) do I[i] = "Sceptre of Light" end
for _, i in ipairs({21937}) do I[i] = "Scorched Ectoplasm" end
for _, i in ipairs({6838}) do I[i] = "Scorched Spider Fang" end
for _, i in ipairs({6248}) do I[i] = "Scorpashi Venom" end
for _, i in ipairs({4862}) do I[i] = "Scorpid Worker Tail" end
for _, i in ipairs({8393}) do I[i] = "Scorpok Pincer" end
for _, i in ipairs({12807}) do I[i] = "Scourge Banner" end
for _, i in ipairs({13176}) do I[i] = "Scourge Data" end
for _, i in ipairs({4630}) do I[i] = "Scrap Metal" end
for _, i in ipairs({5949}) do I[i] = "Scrap of Paper" end
for _, i in ipairs({6494}) do I[i] = "Scrawled Parchment" end
for _, i in ipairs({8593}) do I[i] = "Scrimshank's Surveying Gear" end
for _, i in ipairs({17731}) do I[i] = "Scroll of Celebras" end
for _, i in ipairs({5731}) do I[i] = "Scroll of Messaging" end
for _, i in ipairs({4472}) do I[i] = "Scroll of Myzrael" end
for _, i in ipairs({17224,17364}) do I[i] = "Scrying Scope" end
for _, i in ipairs({12242}) do I[i] = "Sea Creature Bones" end
for _, i in ipairs({12289}) do I[i] = "Sea Turtle Remains" end
for _, i in ipairs({5862}) do I[i] = "Seaforium Booster" end
for _, i in ipairs({4494}) do I[i] = "Seahorn's Sealed Letter" end
for _, i in ipairs({17125}) do I[i] = "Seal of Ravenholdt" end
for _, i in ipairs({19775}) do I[i] = "Sealed Azure Bag" end
for _, i in ipairs({21985}) do I[i] = "Sealed Blood Container" end
for _, i in ipairs({8687}) do I[i] = "Sealed Description of Thredd's Visitor" end
for _, i in ipairs({5735}) do I[i] = "Sealed Envelope" end
for _, i in ipairs({4482}) do I[i] = "Sealed Folder" end
for _, i in ipairs({10643}) do I[i] = "Sealed Letter to Ag'tor" end
for _, i in ipairs({4533}) do I[i] = "Sealed Letter to Archmage Malin" end
for _, i in ipairs({5381}) do I[i] = "Sealed Letter to Balthule" end
for _, i in ipairs({5380}) do I[i] = "Sealed Letter to Elissa" end
for _, i in ipairs({4622}) do I[i] = "Sealed Note to Advisor Belgrum" end
for _, i in ipairs({5946}) do I[i] = "Sealed Note to Elling" end
for _, i in ipairs({5960}) do I[i] = "Sealed Note to Watcher Backus" end
for _, i in ipairs({18540}) do I[i] = "Sealed Reliquary of Purity" end
for _, i in ipairs({23008,23010,23011,23012,23013,23016}) do I[i] = "Sealed Research Report" end
for _, i in ipairs({22382}) do I[i] = "Sealed Venom Container" end
for _, i in ipairs({4871}) do I[i] = "Searing Collar" end
for _, i in ipairs({6848}) do I[i] = "Searing Coral" end
for _, i in ipairs({5841}) do I[i] = "Searing Heart" end
for _, i in ipairs({5840}) do I[i] = "Searing Tongue" end
for _, i in ipairs({6649}) do I[i] = "Searing Totem Scroll" end
for _, i in ipairs({10661}) do I[i] = "Second Mosh'aru Tablet" end
for _, i in ipairs({12897}) do I[i] = "Second Relic Fragment" end
for _, i in ipairs({12765}) do I[i] = "Secret Note #1" end
for _, i in ipairs({12766}) do I[i] = "Secret Note #2" end
for _, i in ipairs({12768}) do I[i] = "Secret Note #3" end
for _, i in ipairs({18922}) do I[i] = "Secret Plans: Fiery Flux" end
for _, i in ipairs({6462}) do I[i] = "Secure Crate" end
for _, i in ipairs({11103}) do I[i] = "Seed Voucher" end
for _, i in ipairs({17760}) do I[i] = "Seed of Life" end
for _, i in ipairs({2628}) do I[i] = "Senir's Report" end
for _, i in ipairs({5067}) do I[i] = "Serena's Head" end
for _, i in ipairs({5339}) do I[i] = "Serpentbloom" end
for _, i in ipairs({7737}) do I[i] = "Sethir's Journal" end
for _, i in ipairs({10759}) do I[i] = "Severed Horn of the Defiler" end
for _, i in ipairs({18142}) do I[i] = "Severed Night Elf Head" end
for _, i in ipairs({3017}) do I[i] = "Sevren's Orders" end
for _, i in ipairs({11058}) do I[i] = "Sha'ni's Nose-Ring" end
for _, i in ipairs({4103,19064}) do I[i] = "Shackle Key" end
for _, i in ipairs({5040}) do I[i] = "Shadow Hunter Knife" end
for _, i in ipairs({13207}) do I[i] = "Shadow Lord Fel'dan's Head" end
for _, i in ipairs({18173}) do I[i] = "Shadow Mantle of the Dawn" end
for _, i in ipairs({6080}) do I[i] = "Shadow Panther Heart" end
for _, i in ipairs({16713}) do I[i] = "Shadowcraft Belt" end
for _, i in ipairs({16711}) do I[i] = "Shadowcraft Boots" end
for _, i in ipairs({16710}) do I[i] = "Shadowcraft Bracers" end
for _, i in ipairs({16707}) do I[i] = "Shadowcraft Cap" end
for _, i in ipairs({16712}) do I[i] = "Shadowcraft Gloves" end
for _, i in ipairs({16709}) do I[i] = "Shadowcraft Pants" end
for _, i in ipairs({16708}) do I[i] = "Shadowcraft Spaulders" end
for _, i in ipairs({16721}) do I[i] = "Shadowcraft Tunic" end
for _, i in ipairs({14648}) do I[i] = "Shadowglen Gift Voucher" end
for _, i in ipairs({1075}) do I[i] = "Shadowhide Pendant" end
for _, i in ipairs({3838}) do I[i] = "Shadowmaw Claw" end
for _, i in ipairs({17756}) do I[i] = "Shadowshard Fragment" end
for _, i in ipairs({6441}) do I[i] = "Shadowstalker Scalp" end
for _, i in ipairs({18802}) do I[i] = "Shadowy Potion" end
for _, i in ipairs({18685}) do I[i] = "Shadowy Potion OLD" end
for _, i in ipairs({9324}) do I[i] = "Shadra's Venom" end
for _, i in ipairs({16304}) do I[i] = "Shadumbra's Head" end
for _, i in ipairs({3922}) do I[i] = "Shaky's Payment" end
for _, i in ipairs({8363}) do I[i] = "Shaman Voodoo Charm" end
for _, i in ipairs({7813}) do I[i] = "Shard of Water" end
for _, i in ipairs({12622}) do I[i] = "Shardtooth Meat" end
for _, i in ipairs({5635}) do I[i] = "Sharp Claw" end
for _, i in ipairs({9468}) do I[i] = "Sharpbeak's Feather" end
for _, i in ipairs({16305}) do I[i] = "Sharptalon's Claw" end
for _, i in ipairs({7666,7716}) do I[i] = "Shattered Necklace" end
for _, i in ipairs({7672}) do I[i] = "Shattered Necklace Power Source" end
for _, i in ipairs({7669}) do I[i] = "Shattered Necklace Ruby" end
for _, i in ipairs({7670}) do I[i] = "Shattered Necklace Sapphire" end
for _, i in ipairs({7671}) do I[i] = "Shattered Necklace Topaz" end
for _, i in ipairs({12957}) do I[i] = "Shattered Sword of Marduk" end
for _, i in ipairs({1353}) do I[i] = "Shaw's Report" end
for _, i in ipairs({9189}) do I[i] = "Shay's Bell" end
for _, i in ipairs({4468}) do I[i] = "Sheathed Trol'kalar" end
for _, i in ipairs({13545}) do I[i] = "Shellfish" end
for _, i in ipairs({5190}) do I[i] = "Shimmering Frond" end
for _, i in ipairs({2676}) do I[i] = "Shimmerweed" end
for _, i in ipairs({12060}) do I[i] = "Shindrell's Note" end
for _, i in ipairs({9250}) do I[i] = "Ship Schedule" end
for _, i in ipairs({5076}) do I[i] = "Shipment of Boots" end
for _, i in ipairs({3564}) do I[i] = "Shipment of Iron" end
for _, i in ipairs({10738}) do I[i] = "Shipment to Galvan" end
for _, i in ipairs({6178}) do I[i] = "Shipment to Nethergarde" end
for _, i in ipairs({16642}) do I[i] = "Shredder Operating Manual - Chapter 1" end
for _, i in ipairs({16643}) do I[i] = "Shredder Operating Manual - Chapter 2" end
for _, i in ipairs({16644}) do I[i] = "Shredder Operating Manual - Chapter 3" end
for _, i in ipairs({7679}) do I[i] = "Shrike Bat Fang" end
for _, i in ipairs({15877}) do I[i] = "Shrine Bauble" end
for _, i in ipairs({1532}) do I[i] = "Shrunken Head" end
for _, i in ipairs({13172}) do I[i] = "Siabi's Premium Tobacco" end
for _, i in ipairs({3349}) do I[i] = "Sida's Bag" end
for _, i in ipairs({4450}) do I[i] = "Sigil Fragment" end
for _, i in ipairs({4458}) do I[i] = "Sigil of Arathor" end
for _, i in ipairs({4467}) do I[i] = "Sigil of Ignaeus" end
for _, i in ipairs({4440}) do I[i] = "Sigil of Strom" end
for _, i in ipairs({4453}) do I[i] = "Sigil of Thoradin" end
for _, i in ipairs({4466}) do I[i] = "Sigil of Trollbane" end
for _, i in ipairs({4648}) do I[i] = "Sigil of the Hammer" end
for _, i in ipairs({4640}) do I[i] = "Sign of the Earth" end
for _, i in ipairs({20810}) do I[i] = "Signed Field Duty Papers" end
for _, i in ipairs({4995}) do I[i] = "Signed Recruitment Letter" end
for _, i in ipairs({21196,21197,21198,21199,21200,21201,21202,21203,21204,21205,21206,21207,21208,21209,21210}) do I[i] = "Signet Ring of the Bronze Dragonflight" end
for _, i in ipairs({8703}) do I[i] = "Signet of Expertise" end
for _, i in ipairs({20384}) do I[i] = "Silithid Carapace Fragment" end
for _, i in ipairs({5058}) do I[i] = "Silithid Egg" end
for _, i in ipairs({17345}) do I[i] = "Silithid Goo" end
for _, i in ipairs({5855}) do I[i] = "Silithid Heart" end
for _, i in ipairs({5854}) do I[i] = "Silithid Talon" end
for _, i in ipairs({22381}) do I[i] = "Silithus Venom Sample" end
for _, i in ipairs({8072}) do I[i] = "Silixiz's Tower Key" end
for _, i in ipairs({6450}) do I[i] = "Silk Bandage" end
for _, i in ipairs({4306}) do I[i] = "Silk Cloth" end
for _, i in ipairs({2842}) do I[i] = "Silver Bar" end
for _, i in ipairs({12191}) do I[i] = "Silver Dawning's Lockbox" end
for _, i in ipairs({19714}) do I[i] = "Silver Hakkari Bijou" end
for _, i in ipairs({20860}) do I[i] = "Silver Scarab" end
for _, i in ipairs({11522}) do I[i] = "Silver Totem of Aquementas" end
for _, i in ipairs({3482}) do I[i] = "Silvered Bronze Boots" end
for _, i in ipairs({3483}) do I[i] = "Silvered Bronze Gauntlets" end
for _, i in ipairs({11472}) do I[i] = "Silvermane Stalker Flank" end
for _, i in ipairs({19213}) do I[i] = "Silverwing Talisman of Merit" end
for _, i in ipairs({11172}) do I[i] = "Silvery Claws" end
for _, i in ipairs({8344}) do I[i] = "Silvery Spinnerets" end
for _, i in ipairs({18952}) do I[i] = "Simone's Head" end
for _, i in ipairs({9542}) do I[i] = "Simple Letter" end
for _, i in ipairs({9544}) do I[i] = "Simple Memorandum" end
for _, i in ipairs({9547}) do I[i] = "Simple Note" end
for _, i in ipairs({6497,12635}) do I[i] = "Simple Parchment" end
for _, i in ipairs({9543}) do I[i] = "Simple Rune" end
for _, i in ipairs({9546}) do I[i] = "Simple Scroll" end
for _, i in ipairs({9545}) do I[i] = "Simple Sigil" end
for _, i in ipairs({6488}) do I[i] = "Simple Tablet" end
for _, i in ipairs({3421}) do I[i] = "Simple Wildflowers" end
for _, i in ipairs({10443}) do I[i] = "Singed Letter" end
for _, i in ipairs({6486}) do I[i] = "Singed Scale" end
for _, i in ipairs({4520}) do I[i] = "Singed Scroll Fragment" end
for _, i in ipairs({3917}) do I[i] = "Singing Blue Crystal" end
for _, i in ipairs({3918}) do I[i] = "Singing Crystal Shard" end
for _, i in ipairs({12741}) do I[i] = "Sixth Mosh'aru Tablet" end
for _, i in ipairs({14619}) do I[i] = "Skeletal Fragments" end
for _, i in ipairs({2378}) do I[i] = "Skeleton Finger" end
for _, i in ipairs({14644}) do I[i] = "Skeleton Key Mold" end
for _, i in ipairs({12753}) do I[i] = "Skin of Shadow" end
for _, i in ipairs({1939}) do I[i] = "Skin of Sweet Rum" end
for _, i in ipairs({20931}) do I[i] = "Skin of the Great Sandworm" end
for _, i in ipairs({3254}) do I[i] = "Skittering Blood" end
for _, i in ipairs({12956}) do I[i] = "Skull of Horgus" end
for _, i in ipairs({18148}) do I[i] = "Skull of Korrak" end
for _, i in ipairs({10420}) do I[i] = "Skull of the Coldbringer" end
for _, i in ipairs({19705}) do I[i] = "Skullsplitter Coin" end
for _, i in ipairs({2466}) do I[i] = "Skullsplitter Fetish" end
for _, i in ipairs({1524}) do I[i] = "Skullsplitter Tusk" end
for _, i in ipairs({19025}) do I[i] = "Skylord Plume" end
for _, i in ipairs({13853}) do I[i] = "Slab of Carrion Worm Meat" end
for _, i in ipairs({19033}) do I[i] = "Slagtree's Lost Tools" end
for _, i in ipairs({5689}) do I[i] = "Sleepers' Key" end
for _, i in ipairs({17507}) do I[i] = "Slidore's Beacon" end
for _, i in ipairs({21926}) do I[i] = "Slightly Creased Note" end
for _, i in ipairs({2719}) do I[i] = "Small Brass Key" end
for _, i in ipairs({5134}) do I[i] = "Small Furry Paw" end
for _, i in ipairs({17008}) do I[i] = "Small Scroll" end
for _, i in ipairs({5465}) do I[i] = "Small Spider Leg" end
for _, i in ipairs({4626}) do I[i] = "Small Stone Shard" end
for _, i in ipairs({18959}) do I[i] = "Smithing Tuyere" end
for _, i in ipairs({20452}) do I[i] = "Smoked Desert Dumplings" end
for _, i in ipairs({15736}) do I[i] = "Smokey's Special Compound" end
for _, i in ipairs({7126}) do I[i] = "Smoky Iron Ingot" end
for _, i in ipairs({21315}) do I[i] = "Smokywood Satchel" end
for _, i in ipairs({21545}) do I[i] = "Smokywood Supplies" end
for _, i in ipairs({6991}) do I[i] = "Smoldering Coal" end
for _, i in ipairs({5659}) do I[i] = "Smoldering Embers" end
for _, i in ipairs({3932}) do I[i] = "Smotts' Chest" end
for _, i in ipairs({3935}) do I[i] = "Smotts' Cutlass" end
for _, i in ipairs({4104}) do I[i] = "Snapjaw Crocolisk Skin" end
for _, i in ipairs({9330}) do I[i] = "Snapshot of Gammerita" end
for _, i in ipairs({3619}) do I[i] = "Snellig's Snuffbox" end
for _, i in ipairs({8391}) do I[i] = "Snickerfang Jowl" end
for _, i in ipairs({3910}) do I[i] = "Snuff" end
for _, i in ipairs({6684}) do I[i] = "Snufflenose Command Stick" end
for _, i in ipairs({5897}) do I[i] = "Snufflenose Owner's Manual" end
for _, i in ipairs({5019}) do I[i] = "Sodium Nitrate" end
for _, i in ipairs({4582}) do I[i] = "Soft Bushy Tail" end
for _, i in ipairs({15874}) do I[i] = "Soft-shelled Clam" end
for _, i in ipairs({15924}) do I[i] = "Soft-shelled Clam Meat" end
for _, i in ipairs({18954}) do I[i] = "Solenor's Head" end
for _, i in ipairs({11725}) do I[i] = "Solid Crystal Leg Shaft" end
for _, i in ipairs({10507}) do I[i] = "Solid Dynamite" end
for _, i in ipairs({7966}) do I[i] = "Solid Grinding Stone" end
for _, i in ipairs({3851}) do I[i] = "Solid Iron Maul" end
for _, i in ipairs({11367}) do I[i] = "Solomon's Plea to Bolvar" end
for _, i in ipairs({1409}) do I[i] = "Solomon's Plea to Darkshire" end
for _, i in ipairs({1407}) do I[i] = "Solomon's Plea to Westfall" end
for _, i in ipairs({13356}) do I[i] = "Somatic Intensifier" end
for _, i in ipairs({13815}) do I[i] = "Some Rune" end
for _, i in ipairs({3713}) do I[i] = "Soothing Spices" end
for _, i in ipairs({6492}) do I[i] = "Sooty Parchment" end
for _, i in ipairs({6914}) do I[i] = "Soran'ruk Fragment" end
for _, i in ipairs({22229}) do I[i] = "Soul Ashes of the Banished" end
for _, i in ipairs({3912}) do I[i] = "Soul Gem" end
for _, i in ipairs({6265}) do I[i] = "Soul Shard" end
for _, i in ipairs({12847}) do I[i] = "Soul Stained Pike" end
for _, i in ipairs({13624,13752}) do I[i] = "Soulbound Keepsake" end
for _, i in ipairs({20519}) do I[i] = "Southsea Pirate Hat" end
for _, i in ipairs({7968}) do I[i] = "Southsea Treasure" end
for _, i in ipairs({3703}) do I[i] = "Southshore Stout" end
for _, i in ipairs({16733}) do I[i] = "Spaulders of Valor" end
for _, i in ipairs({11109}) do I[i] = "Special Chicken Feed" end
for _, i in ipairs({5803}) do I[i] = "Speck of Dream Dust" end
for _, i in ipairs({19807}) do I[i] = "Speckled Tastyfish" end
for _, i in ipairs({1453}) do I[i] = "Spectral Comb" end
for _, i in ipairs({14395}) do I[i] = "Spells of Shadow" end
for _, i in ipairs({3174}) do I[i] = "Spider Ichor" end
for _, i in ipairs({12530}) do I[i] = "Spire Spider Egg" end
for _, i in ipairs({4488}) do I[i] = "Spirit of Silverpine Charts" end
for _, i in ipairs({4490}) do I[i] = "Spirit of Silverpine Log" end
for _, i in ipairs({18659}) do I[i] = "Splinter of Nordrassil" end
for _, i in ipairs({9590}) do I[i] = "Splintered Log" end
for _, i in ipairs({3916}) do I[i] = "Split Bone Necklace" end
for _, i in ipairs({8431}) do I[i] = "Spool of Light Chartreuse Silk Thread" end
for _, i in ipairs({11507}) do I[i] = "Spotted Hyena Pelt" end
for _, i in ipairs({1467}) do I[i] = "Spotted Sunfish" end
for _, i in ipairs({6887}) do I[i] = "Spotted Yellowtail" end
for _, i in ipairs({11804,15722}) do I[i] = "Spraggle's Canteen" end
for _, i in ipairs({5917}) do I[i] = "Spy's Report" end
for _, i in ipairs({17115,17116}) do I[i] = "Squirrel Token" end
for _, i in ipairs({21935}) do I[i] = "Stable Ectoplasm" end
for _, i in ipairs({22733}) do I[i] = "Staff Head of Atiesh" end
for _, i in ipairs({10464}) do I[i] = "Staff of Command" end
for _, i in ipairs({7733}) do I[i] = "Staff of Prehistoria" end
for _, i in ipairs({4801}) do I[i] = "Stalker Claws" end
for _, i in ipairs({10444}) do I[i] = "Standard Issue Flare Gun" end
for _, i in ipairs({7910}) do I[i] = "Star Ruby" end
for _, i in ipairs({4646}) do I[i] = "Star of Xil'yeh" end
for _, i in ipairs({22227}) do I[i] = "Starbreeze Village Relic" end
for _, i in ipairs({9306}) do I[i] = "Stave of Equinex" end
for _, i in ipairs({17411}) do I[i] = "Steamsaw" end
for _, i in ipairs({7963}) do I[i] = "Steel Breastplate" end
for _, i in ipairs({7922}) do I[i] = "Steel Plate Helm" end
for _, i in ipairs({2999}) do I[i] = "Steelgrill's Tools" end
for _, i in ipairs({5837}) do I[i] = "Steelsnap's Rib" end
for _, i in ipairs({18962}) do I[i] = "Stinglasher's Glands" end
for _, i in ipairs({20604}) do I[i] = "Stink Bomb Cleaner" end
for _, i in ipairs({5061}) do I[i] = "Stolen Silver" end
for _, i in ipairs({17662}) do I[i] = "Stolen Treats" end
for _, i in ipairs({9245}) do I[i] = "Stoley's Bottle" end
for _, i in ipairs({9244}) do I[i] = "Stoley's Shipment" end
for _, i in ipairs({10556}) do I[i] = "Stone Circle" end
for _, i in ipairs({20858}) do I[i] = "Stone Scarab" end
for _, i in ipairs({5233}) do I[i] = "Stone of Relu" end
for _, i in ipairs({4034}) do I[i] = "Stone of the Tides" end
for _, i in ipairs({20375}) do I[i] = "Stonelash Flayer Stinger" end
for _, i in ipairs({20374}) do I[i] = "Stonelash Pincer Stinger" end
for _, i in ipairs({20373}) do I[i] = "Stonelash Scorpid Stinger" end
for _, i in ipairs({13422}) do I[i] = "Stonescale Eel" end
for _, i in ipairs({13423}) do I[i] = "Stonescale Oil" end
for _, i in ipairs({6648}) do I[i] = "Stoneskin Totem Scroll" end
for _, i in ipairs({5582}) do I[i] = "Stonetalon Sap" end
for _, i in ipairs({17423}) do I[i] = "Storm Crystal" end
for _, i in ipairs({4747}) do I[i] = "Stormbull Well Water" end
for _, i in ipairs({17353}) do I[i] = "Stormpike Assault Orders" end
for _, i in ipairs({17849}) do I[i] = "Stormpike Banner" end
for _, i in ipairs({17823}) do I[i] = "Stormpike Battle Plans" end
for _, i in ipairs({17328}) do I[i] = "Stormpike Commander's Flesh" end
for _, i in ipairs({17691}) do I[i] = "Stormpike Insignia Rank 1" end
for _, i in ipairs({17900}) do I[i] = "Stormpike Insignia Rank 2" end
for _, i in ipairs({17901}) do I[i] = "Stormpike Insignia Rank 3" end
for _, i in ipairs({17902}) do I[i] = "Stormpike Insignia Rank 4" end
for _, i in ipairs({17903}) do I[i] = "Stormpike Insignia Rank 5" end
for _, i in ipairs({17327}) do I[i] = "Stormpike Lieutenant's Flesh" end
for _, i in ipairs({17306}) do I[i] = "Stormpike Soldier's Blood" end
for _, i in ipairs({17326}) do I[i] = "Stormpike Soldier's Flesh" end
for _, i in ipairs({17689}) do I[i] = "Stormpike Training Collar" end
for _, i in ipairs({5998}) do I[i] = "Stormpike's Request" end
for _, i in ipairs({748}) do I[i] = "Stormwind Armor Marker" end
for _, i in ipairs({15446}) do I[i] = "Stormwind Deputy Kit" end
for _, i in ipairs({22143}) do I[i] = "Stormwind Guard's Card" end
for _, i in ipairs({20492}) do I[i] = "Stormwind Nougat" end
for _, i in ipairs({2665}) do I[i] = "Stormwind Seasoning Herbs" end
for _, i in ipairs({1408}) do I[i] = "Stoutmantle's Response to Solomon" end
for _, i in ipairs({2563}) do I[i] = "Strange Smelling Powder" end
for _, i in ipairs({16782}) do I[i] = "Strange Water Globe" end
for _, i in ipairs({12292}) do I[i] = "Strangely Marked Box" end
for _, i in ipairs({3820}) do I[i] = "Stranglekelp" end
for _, i in ipairs({13223}) do I[i] = "Stratholme Courier's Pouch" end
for _, i in ipairs({13180}) do I[i] = "Stratholme Holy Water" end
for _, i in ipairs({19574,19575,19576}) do I[i] = "Strength of Mugamba" end
for _, i in ipairs({5469}) do I[i] = "Strider Meat" end
for _, i in ipairs({3411}) do I[i] = "Strigid Owl Feather" end
for _, i in ipairs({729}) do I[i] = "Stringy Vulture Meat" end
for _, i in ipairs({4506}) do I[i] = "Stromgarde Badge" end
for _, i in ipairs({3466}) do I[i] = "Strong Flux" end
for _, i in ipairs({3388}) do I[i] = "Strong Troll's Blood Potion" end
for _, i in ipairs({15790}) do I[i] = "Studies in Spirit Speaking" end
for _, i in ipairs({7134}) do I[i] = "Sturdy Dragonmaw Shinbone" end
for _, i in ipairs({6623}) do I[i] = "Succubus Summoning Scroll" end
for _, i in ipairs({17203}) do I[i] = "Sulfuron Ingot" end
for _, i in ipairs({4432}) do I[i] = "Sully Balloo's Letter" end
for _, i in ipairs({6146}) do I[i] = "Sundried Driftwood" end
for _, i in ipairs({5165}) do I[i] = "Sunscale Feather" end
for _, i in ipairs({6849}) do I[i] = "Sunscorched Shell" end
for _, i in ipairs({5734}) do I[i] = "Super Reaper 6000 Blueprints" end
for _, i in ipairs({11834}) do I[i] = "Super Sticky Tar" end
for _, i in ipairs({1922}) do I[i] = "Supplies for Sven" end
for _, i in ipairs({4629}) do I[i] = "Supply Crate" end
for _, i in ipairs({6810}) do I[i] = "Surena's Choker" end
for _, i in ipairs({1708}) do I[i] = "Sweet Nectar" end
for _, i in ipairs({4807}) do I[i] = "Swoop Gizzard" end
for _, i in ipairs({6866}) do I[i] = "Symbol of Life" end
for _, i in ipairs({14625}) do I[i] = "Symbol of Lost Honor" end
for _, i in ipairs({10552}) do I[i] = "Symbol of Ragnaros" end
for _, i in ipairs({17124}) do I[i] = "Syndicate Emblem" end
for _, i in ipairs({17347}) do I[i] = "Syndicate Man Tracker (MURP)" end
for _, i in ipairs({3601}) do I[i] = "Syndicate Missive" end
for _, i in ipairs({7516}) do I[i] = "Tabetha's Instructions" end
for _, i in ipairs({4094}) do I[i] = "Tablet Shard" end
for _, i in ipairs({11470}) do I[i] = "Tablet Transcript" end
for _, i in ipairs({10538}) do I[i] = "Tablet of Beth'Amara" end
for _, i in ipairs({10539}) do I[i] = "Tablet of Jin'yael" end
for _, i in ipairs({11126}) do I[i] = "Tablet of Kurniya" end
for _, i in ipairs({10540}) do I[i] = "Tablet of Markri" end
for _, i in ipairs({4631}) do I[i] = "Tablet of Ryun'eh" end
for _, i in ipairs({10541}) do I[i] = "Tablet of Sael'hai" end
for _, i in ipairs({6535}) do I[i] = "Tablet of Verga" end
for _, i in ipairs({5824}) do I[i] = "Tablet of Will" end
for _, i in ipairs({21245}) do I[i] = "Tactical Task Briefing I" end
for _, i in ipairs({20945}) do I[i] = "Tactical Task Briefing II" end
for _, i in ipairs({20946,21751}) do I[i] = "Tactical Task Briefing III" end
for _, i in ipairs({20947}) do I[i] = "Tactical Task Briefing IV" end
for _, i in ipairs({20944}) do I[i] = "Tactical Task Briefing IX" end
for _, i in ipairs({20948}) do I[i] = "Tactical Task Briefing V" end
for _, i in ipairs({21165}) do I[i] = "Tactical Task Briefing VI" end
for _, i in ipairs({21166}) do I[i] = "Tactical Task Briefing VII" end
for _, i in ipairs({21167}) do I[i] = "Tactical Task Briefing VIII" end
for _, i in ipairs({20943}) do I[i] = "Tactical Task Briefing X" end
for _, i in ipairs({14613}) do I[i] = "Taelan's Hammer" end
for _, i in ipairs({4890}) do I[i] = "Taillasher Egg" end
for _, i in ipairs({5217}) do I[i] = "Tainted Heart" end
for _, i in ipairs({3520}) do I[i] = "Tainted Keg" end
for _, i in ipairs({9576}) do I[i] = "Tainted Letter" end
for _, i in ipairs({9577}) do I[i] = "Tainted Memorandum" end
for _, i in ipairs({9579}) do I[i] = "Tainted Parchment" end
for _, i in ipairs({9578}) do I[i] = "Tainted Scroll" end
for _, i in ipairs({11513}) do I[i] = "Tainted Vitriol" end
for _, i in ipairs({12355}) do I[i] = "Talisman of Corruption" end
for _, i in ipairs({8050}) do I[i] = "Tallonkai's Jewel" end
for _, i in ipairs({3877}) do I[i] = "Talon of Tethis" end
for _, i in ipairs({7667}) do I[i] = "Talvash's Phial of Scrying" end
for _, i in ipairs({15908,15911,15913,15914,15915,15916,15917,15919,15920,15921,15922,15923}) do I[i] = "Taming Rod" end
for _, i in ipairs({8585}) do I[i] = "Tapped Dowsing Widget" end
for _, i in ipairs({14540}) do I[i] = "Taragaman the Hungerer's Heart" end
for _, i in ipairs({3498}) do I[i] = "Taretha's Necklace" end
for _, i in ipairs({3550}) do I[i] = "Targ's Head" end
for _, i in ipairs({6997}) do I[i] = "Tattered Manuscript" end
for _, i in ipairs({6493}) do I[i] = "Tattered Parchment" end
for _, i in ipairs({18145}) do I[i] = "Tauren Hoof" end
for _, i in ipairs({7208}) do I[i] = "Tazan's Key" end
for _, i in ipairs({7295}) do I[i] = "Tazan's Logbook" end
for _, i in ipairs({7209}) do I[i] = "Tazan's Satchel" end
for _, i in ipairs({15293}) do I[i] = "Teal Kodo" end
for _, i in ipairs({2779}) do I[i] = "Tear of Tilloa" end
for _, i in ipairs({5038}) do I[i] = "Tear of the Moons" end
for _, i in ipairs({18604}) do I[i] = "Tears of the Hederine" end
for _, i in ipairs({9277}) do I[i] = "Techbot's Memory Core" end
for _, i in ipairs({5077}) do I[i] = "Telescopic Lens" end
for _, i in ipairs({12627}) do I[i] = "Temporal Displacer" end
for _, i in ipairs({5505}) do I[i] = "Teronis' Journal" end
for _, i in ipairs({1260}) do I[i] = "Tharil'zun's Head" end
for _, i in ipairs({7586}) do I[i] = "Tharnariun's Hope" end
for _, i in ipairs({7870}) do I[i] = "Thaumaturgy Vessel Lockbox" end
for _, i in ipairs({16332}) do I[i] = "Thazz'ril's Pick" end
for _, i in ipairs({7275}) do I[i] = "The Agamaggan Scrolls" end
for _, i in ipairs({18358}) do I[i] = "The Arcanist's Cookbook" end
for _, i in ipairs({6283}) do I[i] = "The Book of Ur" end
for _, i in ipairs({2239}) do I[i] = "The Collector's Ring" end
for _, i in ipairs({2223}) do I[i] = "The Collector's Schedule" end
for _, i in ipairs({13471}) do I[i] = "The Deed to Brill" end
for _, i in ipairs({13448}) do I[i] = "The Deed to Caer Darrow" end
for _, i in ipairs({13450}) do I[i] = "The Deed to Southshore" end
for _, i in ipairs({13451}) do I[i] = "The Deed to Tarren Mill" end
for _, i in ipairs({2382}) do I[i] = "The Embalmer's Heart" end
for _, i in ipairs({18364}) do I[i] = "The Emerald Dream" end
for _, i in ipairs({19591,19592,19593}) do I[i] = "The Eye of Zuldazar" end
for _, i in ipairs({17735}) do I[i] = "The Feast of Winter Veil" end
for _, i in ipairs({2005}) do I[i] = "The First Troll Legend" end
for _, i in ipairs({2008}) do I[i] = "The Fourth Troll Legend" end
for _, i in ipairs({1294}) do I[i] = "The General's Response" end
for _, i in ipairs({13852,15868}) do I[i] = "The Grand Crusader's Command" end
for _, i in ipairs({11309}) do I[i] = "The Heart of the Mountain" end
for _, i in ipairs({19882}) do I[i] = "The Hexxer's Head" end
for _, i in ipairs({4644}) do I[i] = "The Legacy Heart" end
for _, i in ipairs({2833}) do I[i] = "The Lich's Spellbook" end
for _, i in ipairs({18359}) do I[i] = "The Light and How to Swing It" end
for _, i in ipairs({21152}) do I[i] = "The Nightmare's Corruption" end
for _, i in ipairs({17781}) do I[i] = "The Pariah's Instructions" end
for _, i in ipairs({22520}) do I[i] = "The Phylactery of Kel'Thuzad" end
for _, i in ipairs({21175}) do I[i] = "The Scepter of the Shifting Sands" end
for _, i in ipairs({2006}) do I[i] = "The Second Troll Legend" end
for _, i in ipairs({7741}) do I[i] = "The Shaft of Tsol" end
for _, i in ipairs({16872}) do I[i] = "The Skull of Axtroz" end
for _, i in ipairs({16871}) do I[i] = "The Skull of Chronalis" end
for _, i in ipairs({16869}) do I[i] = "The Skull of Scryer" end
for _, i in ipairs({16870}) do I[i] = "The Skull of Somnus" end
for _, i in ipairs({1293}) do I[i] = "The State of Lakeshire" end
for _, i in ipairs({2007}) do I[i] = "The Third Troll Legend" end
for _, i in ipairs({18719}) do I[i] = "The Traitor's Heart" end
for _, i in ipairs({20415}) do I[i] = "The War of the Shifting Sands" end
for _, i in ipairs({17684}) do I[i] = "Theradric Crystal Carving" end
for _, i in ipairs({5078}) do I[i] = "Theramore Medal" end
for _, i in ipairs({9299}) do I[i] = "Thermaplugg's Safe Combination" end
for _, i in ipairs({8173}) do I[i] = "Thick Armor Kit" end
for _, i in ipairs({6952}) do I[i] = "Thick Bear Fur" end
for _, i in ipairs({20611}) do I[i] = "Thick Black Claw" end
for _, i in ipairs({4304}) do I[i] = "Thick Leather" end
for _, i in ipairs({12366}) do I[i] = "Thick Yeti Fur" end
for _, i in ipairs({8973}) do I[i] = "Thick Yeti Hide" end
for _, i in ipairs({5060}) do I[i] = "Thieves' Tools" end
for _, i in ipairs({12411}) do I[i] = "Third Mosh'aru Tablet" end
for _, i in ipairs({12898}) do I[i] = "Third Relic Fragment" end
for _, i in ipairs({1875}) do I[i] = "Thistlenettle's Badge" end
for _, i in ipairs({8603}) do I[i] = "Thistleshrub Dew" end
for _, i in ipairs({12359}) do I[i] = "Thorium Bar" end
for _, i in ipairs({18628}) do I[i] = "Thorium Brotherhood Contract" end
for _, i in ipairs({18593}) do I[i] = "Thorium Brotherhood Contract (OLD)" end
for _, i in ipairs({15993}) do I[i] = "Thorium Grenade" end
for _, i in ipairs({10551}) do I[i] = "Thorium Plated Dagger" end
for _, i in ipairs({11286}) do I[i] = "Thorium Shackles" end
for _, i in ipairs({15997}) do I[i] = "Thorium Shells" end
for _, i in ipairs({16000}) do I[i] = "Thorium Tube" end
for _, i in ipairs({15994}) do I[i] = "Thorium Widget" end
for _, i in ipairs({2669}) do I[i] = "Threshadon Claw" end
for _, i in ipairs({2668}) do I[i] = "Threshadon Tooth" end
for _, i in ipairs({5412}) do I[i] = "Thresher Eye" end
for _, i in ipairs({3623}) do I[i] = "Thule's Head" end
for _, i in ipairs({7587}) do I[i] = "Thun'grim's Instructions" end
for _, i in ipairs({2686}) do I[i] = "Thunder Ale" end
for _, i in ipairs({20497}) do I[i] = "Thunder Bluff Marzipan" end
for _, i in ipairs({5143}) do I[i] = "Thunder Lizard Blood" end
for _, i in ipairs({4895}) do I[i] = "Thunder Lizard Horn" end
for _, i in ipairs({4897}) do I[i] = "Thunderhawk Saliva Gland" end
for _, i in ipairs({5164}) do I[i] = "Thunderhawk Wings" end
for _, i in ipairs({5415}) do I[i] = "Thunderhorn Cleansing Totem" end
for _, i in ipairs({4480}) do I[i] = "Thundering Charm" end
for _, i in ipairs({4485}) do I[i] = "Thundering Key" end
for _, i in ipairs({2837}) do I[i] = "Thurman's Letter" end
for _, i in ipairs({2830}) do I[i] = "Thurman's Remains" end
for _, i in ipairs({2760}) do I[i] = "Thurman's Sewing Kit" end
for _, i in ipairs({9234}) do I[i] = "Tiara of the Deep" end
for _, i in ipairs({7228}) do I[i] = "Tigule and Foror's Strawberry Ice Cream" end
for _, i in ipairs({5168}) do I[i] = "Timberling Seed" end
for _, i in ipairs({5169}) do I[i] = "Timberling Sprout" end
for _, i in ipairs({21155}) do I[i] = "Timbermaw Offering of Peace" end
for _, i in ipairs({15886}) do I[i] = "Timolain's Phylactery" end
for _, i in ipairs({3576}) do I[i] = "Tin Bar" end
for _, i in ipairs({12438}) do I[i] = "Tinkee's Letter" end
for _, i in ipairs({14872}) do I[i] = "Tirion's Gift" end
for _, i in ipairs({2846}) do I[i] = "Tirisfal Pumpkin" end
for _, i in ipairs({7871}) do I[i] = "Token of Thievery" end
for _, i in ipairs({6775,6916}) do I[i] = "Tome of Divinity" end
for _, i in ipairs({6778}) do I[i] = "Tome of Justice" end
for _, i in ipairs({6779}) do I[i] = "Tome of Nobility" end
for _, i in ipairs({6777}) do I[i] = "Tome of Righteousness" end
for _, i in ipairs({6776}) do I[i] = "Tome of Valor" end
for _, i in ipairs({6999}) do I[i] = "Tome of the Cabal" end
for _, i in ipairs({3660}) do I[i] = "Tomes of Alterac" end
for _, i in ipairs({20019}) do I[i] = "Tooth of Morphaz" end
for _, i in ipairs({18780}) do I[i] = "Top Half of Advanced Armorsmithing: Volume I" end
for _, i in ipairs({18782}) do I[i] = "Top Half of Advanced Armorsmithing: Volume II" end
for _, i in ipairs({18784}) do I[i] = "Top Half of Advanced Armorsmithing: Volume III" end
for _, i in ipairs({22047}) do I[i] = "Top Piece of Lord Valthalak's Amulet" end
for _, i in ipairs({7498}) do I[i] = "Top of Gelkak's Key" end
for _, i in ipairs({4528}) do I[i] = "Tor'gan's Orb" end
for _, i in ipairs({10515}) do I[i] = "Torch of Retribution" end
for _, i in ipairs({6653}) do I[i] = "Torch of the Dormant Flame" end
for _, i in ipairs({6654}) do I[i] = "Torch of the Eternal Flame" end
for _, i in ipairs({11407}) do I[i] = "Torn Bear Pelt" end
for _, i in ipairs({3510}) do I[i] = "Torn Fin Eye" end
for _, i in ipairs({780}) do I[i] = "Torn Murloc Fin" end
for _, i in ipairs({20467}) do I[i] = "Torn Recipe Page" end
for _, i in ipairs({4518}) do I[i] = "Torn Scroll Fragment" end
for _, i in ipairs({11568}) do I[i] = "Torwa's Pouch" end
for _, i in ipairs({4783}) do I[i] = "Totem of Hawkwind" end
for _, i in ipairs({1080}) do I[i] = "Tough Condor Meat" end
for _, i in ipairs({8203}) do I[i] = "Tough Scorpid Breastplate" end
for _, i in ipairs({8204}) do I[i] = "Tough Scorpid Gloves" end
for _, i in ipairs({750}) do I[i] = "Tough Wolf Meat" end
for _, i in ipairs({2314}) do I[i] = "Toughened Leather Armor" end
for _, i in ipairs({5621}) do I[i] = "Tourmaline Phial" end
for _, i in ipairs({5638}) do I[i] = "Toxic Fogger" end
for _, i in ipairs({12822}) do I[i] = "Toxic Horror Droplet" end
for _, i in ipairs({10467}) do I[i] = "Trader's Satchel" end
for _, i in ipairs({1656}) do I[i] = "Translated Letter" end
for _, i in ipairs({3248}) do I[i] = "Translated Letter from The Embalmer" end
for _, i in ipairs({9606}) do I[i] = "Treant Muisek Vessel" end
for _, i in ipairs({18492}) do I[i] = "Treated Ancient Blade" end
for _, i in ipairs({4532}) do I[i] = "Trelane's Ember Agate" end
for _, i in ipairs({4531}) do I[i] = "Trelane's Orb" end
for _, i in ipairs({4530}) do I[i] = "Trelane's Phylactery" end
for _, i in ipairs({4525}) do I[i] = "Trelane's Wand of Invocation" end
for _, i in ipairs({5825}) do I[i] = "Treshala's Pendant" end
for _, i in ipairs({16991}) do I[i] = "Triage Bandage" end
for _, i in ipairs({2536}) do I[i] = "Trogg Stone Tooth" end
for _, i in ipairs({16602}) do I[i] = "Troll Charm" end
for _, i in ipairs({9523}) do I[i] = "Troll Temper" end
for _, i in ipairs({9259}) do I[i] = "Troll Tribal Necklace" end
for _, i in ipairs({4769}) do I[i] = "Trophy Swoop Quill" end
for _, i in ipairs({9263}) do I[i] = "Troyas' Stave" end
for _, i in ipairs({6037}) do I[i] = "Truesilver Bar" end
for _, i in ipairs({18143}) do I[i] = "Tuft of Gnome Hair" end
for _, i in ipairs({4106}) do I[i] = "Tumbled Crystal" end
for _, i in ipairs({3110}) do I[i] = "Tunnel Rat Ear" end
for _, i in ipairs({3712}) do I[i] = "Turtle Meat" end
for _, i in ipairs({8198}) do I[i] = "Turtle Scale Bracers" end
for _, i in ipairs({8189}) do I[i] = "Turtle Scale Breastplate" end
for _, i in ipairs({8187}) do I[i] = "Turtle Scale Gloves" end
for _, i in ipairs({8191}) do I[i] = "Turtle Scale Helm" end
for _, i in ipairs({8185}) do I[i] = "Turtle Scale Leggings" end
for _, i in ipairs({20803}) do I[i] = "Twilight Battle Orders" end
for _, i in ipairs({20407}) do I[i] = "Twilight Cultist Robe" end
for _, i in ipairs({20394}) do I[i] = "Twilight Lexicon - Chapter 1" end
for _, i in ipairs({20395}) do I[i] = "Twilight Lexicon - Chapter 2" end
for _, i in ipairs({20396}) do I[i] = "Twilight Lexicon - Chapter 3" end
for _, i in ipairs({5879}) do I[i] = "Twilight Pendant" end
for _, i in ipairs({20378}) do I[i] = "Twilight Tablet Fragment" end
for _, i in ipairs({5584}) do I[i] = "Twilight Whisker" end
for _, i in ipairs({7119}) do I[i] = "Twitching Antenna" end
for _, i in ipairs({6767}) do I[i] = "Tyranis' Pendant" end
for _, i in ipairs({6683}) do I[i] = "Tyranis' Pendant (old)" end
for _, i in ipairs({11476}) do I[i] = "U'cha's Pelt" end
for _, i in ipairs({7629}) do I[i] = "Ukor's Burden" end
for _, i in ipairs({6800}) do I[i] = "Umbral Ore" end
for _, i in ipairs({12928}) do I[i] = "Umi's Mechanical Yeti" end
for _, i in ipairs({11829}) do I[i] = "Un'Goro Ash" end
for _, i in ipairs({11478}) do I[i] = "Un'Goro Gorilla Pelt" end
for _, i in ipairs({12235}) do I[i] = "Un'Goro Slime Sample" end
for _, i in ipairs({11018}) do I[i] = "Un'Goro Soil" end
for _, i in ipairs({11479}) do I[i] = "Un'Goro Stomper Pelt" end
for _, i in ipairs({11480}) do I[i] = "Un'Goro Thunderer Pelt" end
for _, i in ipairs({12219}) do I[i] = "Unadorned Seal of Ascension" end
for _, i in ipairs({7128}) do I[i] = "Uncloven Satyr Hoof" end
for _, i in ipairs({12444}) do I[i] = "Uncracked Chillwind Horn" end
for _, i in ipairs({9238}) do I[i] = "Uncracked Scarab Shell" end
for _, i in ipairs({10450}) do I[i] = "Undamaged Hippogryph Feather" end
for _, i in ipairs({9322}) do I[i] = "Undamaged Venom Sac" end
for _, i in ipairs({11463}) do I[i] = "Undelivered Parcel" end
for _, i in ipairs({1221}) do I[i] = "Underbelly Whelp Scale" end
for _, i in ipairs({20491}) do I[i] = "Undercity Mint" end
for _, i in ipairs({14645}) do I[i] = "Unfinished Skeleton Key" end
for _, i in ipairs({18489}) do I[i] = "Unfired Ancient Blade" end
for _, i in ipairs({12812}) do I[i] = "Unfired Plate Gauntlets" end
for _, i in ipairs({12806}) do I[i] = "Unforged Rune Covered Breastplate" end
for _, i in ipairs({12323}) do I[i] = "Unforged Seal of Ascension" end
for _, i in ipairs({11102}) do I[i] = "Unhatched Sprite Darter Egg" end
for _, i in ipairs({5733}) do I[i] = "Unidentified Ore" end
for _, i in ipairs({1217}) do I[i] = "Unknown Reward" end
for _, i in ipairs({11319}) do I[i] = "Unloaded Zapper" end
for _, i in ipairs({5884}) do I[i] = "Unpopped Darkmist Eye" end
for _, i in ipairs({6169}) do I[i] = "Unprepared Sawtooth Flank" end
for _, i in ipairs({5842}) do I[i] = "Unrefined Ore Sample" end
for _, i in ipairs({21143}) do I[i] = "Unsigned Field Duty Papers" end
for _, i in ipairs({10560}) do I[i] = "Unstable Trigger" end
for _, i in ipairs({8584}) do I[i] = "Untapped Dowsing Widget" end
for _, i in ipairs({7886}) do I[i] = "Untranslated Journal" end
for _, i in ipairs({9251}) do I[i] = "Upper Map Fragment" end
for _, i in ipairs({7266}) do I[i] = "Ur's Treatise on Shadow Magic" end
for _, i in ipairs({11886}) do I[i] = "Urgent Message" end
for _, i in ipairs({16303}) do I[i] = "Ursangous's Paw" end
for _, i in ipairs({19850}) do I[i] = "Uther's Tribute" end
for _, i in ipairs({12339}) do I[i] = "Vaelan's Gift" end
for _, i in ipairs({3613}) do I[i] = "Valdred's Hands" end
for _, i in ipairs({14649}) do I[i] = "Valley of Trials Gift Voucher" end
for _, i in ipairs({6799}) do I[i] = "Vejrek's Head" end
for _, i in ipairs({20930}) do I[i] = "Vek'lor's Diadem" end
for _, i in ipairs({20926}) do I[i] = "Vek'nilash's Circlet" end
for _, i in ipairs({5520}) do I[i] = "Velinde's Journal" end
for _, i in ipairs({5521}) do I[i] = "Velinde's Key" end
for _, i in ipairs({9321}) do I[i] = "Venom Bottle" end
for _, i in ipairs({2634}) do I[i] = "Venom Fern Extract" end
for _, i in ipairs({4904}) do I[i] = "Venomtail Antidote" end
for _, i in ipairs({4886}) do I[i] = "Venomtail Poison Sac" end
for _, i in ipairs({22216}) do I[i] = "Venoxis's Venom Sac" end
for _, i in ipairs({4834}) do I[i] = "Venture Co. Documents" end
for _, i in ipairs({5718}) do I[i] = "Venture Co. Engineering Plans" end
for _, i in ipairs({7389}) do I[i] = "Venture Co. Ledger" end
for _, i in ipairs({5717}) do I[i] = "Venture Co. Letters" end
for _, i in ipairs({9581}) do I[i] = "Verdant Note" end
for _, i in ipairs({9580}) do I[i] = "Verdant Sigil" end
for _, i in ipairs({20872}) do I[i] = "Vermillion Idol" end
for _, i in ipairs({2832}) do I[i] = "Verna's Westfall Stew Recipe" end
for _, i in ipairs({1283}) do I[i] = "Verner's Note" end
for _, i in ipairs({5023}) do I[i] = "Verog's Head" end
for _, i in ipairs({7867}) do I[i] = "Vessel of Dragon's Blood" end
for _, i in ipairs({18565,19016}) do I[i] = "Vessel of Rebirth" end
for _, i in ipairs({19071}) do I[i] = "Vessel of Tainted Blood" end
for _, i in ipairs({16666}) do I[i] = "Vest of Elements" end
for _, i in ipairs({5646}) do I[i] = "Vial of Blessed Water" end
for _, i in ipairs({16973}) do I[i] = "Vial of Dire Water" end
for _, i in ipairs({6989}) do I[i] = "Vial of Hatefury Blood" end
for _, i in ipairs({5620}) do I[i] = "Vial of Innocent Blood" end
for _, i in ipairs({6841}) do I[i] = "Vial of Phlogiston" end
for _, i in ipairs({7810}) do I[i] = "Vial of Purest Water" end
for _, i in ipairs({1130}) do I[i] = "Vial of Spider Venom" end
for _, i in ipairs({5117}) do I[i] = "Vibrant Plume" end
for _, i in ipairs({2872}) do I[i] = "Vicious Night Web Spider Venom" end
for _, i in ipairs({11243}) do I[i] = "Videre Elixir" end
for _, i in ipairs({6487}) do I[i] = "Vile Familiar Head" end
for _, i in ipairs({2859}) do I[i] = "Vile Fin Scale" end
for _, i in ipairs({19702}) do I[i] = "Vilebranch Coin" end
for _, i in ipairs({6075}) do I[i] = "Vimes's Report" end
for _, i in ipairs({8528}) do I[i] = "Violet Powder" end
for _, i in ipairs({8526}) do I[i] = "Violet Tragan" end
for _, i in ipairs({17506}) do I[i] = "Vipore's Beacon" end
for _, i in ipairs({19606,19607,19608}) do I[i] = "Vision of Voodress" end
for _, i in ipairs({13370}) do I[i] = "Vitreous Focuser" end
for _, i in ipairs({6544}) do I[i] = "Voidwalker Summoning Scroll" end
for _, i in ipairs({22338}) do I[i] = "Volcanic Ash" end
for _, i in ipairs({12792}) do I[i] = "Volcanic Hammer" end
for _, i in ipairs({8149}) do I[i] = "Voodoo Charm" end
for _, i in ipairs({5538}) do I[i] = "Vorrel's Wedding Ring" end
for _, i in ipairs({13352}) do I[i] = "Vosh'gajin's Snakestone" end
for _, i in ipairs({8396}) do I[i] = "Vulture Gizzard" end
for _, i in ipairs({20466}) do I[i] = "Vyral's Signet Ring" end
for _, i in ipairs({6464}) do I[i] = "Wailing Essence" end
for _, i in ipairs({6074}) do I[i] = "War Horn Mouthpiece" end
for _, i in ipairs({8463}) do I[i] = "Warchief's Orders" end
for _, i in ipairs({10757}) do I[i] = "Ward of the Defiler" end
for _, i in ipairs({12563}) do I[i] = "Warlord Goretooth's Command" end
for _, i in ipairs({19257}) do I[i] = "Warlords Deck" end
for _, i in ipairs({12712}) do I[i] = "Warosh's Mojo" end
for _, i in ipairs({12730}) do I[i] = "Warosh's Scroll" end
for _, i in ipairs({16745}) do I[i] = "Warsong Axe Shipment" end
for _, i in ipairs({20558}) do I[i] = "Warsong Gulch Mark of Honor" end
for _, i in ipairs({20256}) do I[i] = "Warsong Gulch Ribbon of Sacrifice" end
for _, i in ipairs({19322}) do I[i] = "Warsong Mark of Honor" end
for _, i in ipairs({16744}) do I[i] = "Warsong Oil" end
for _, i in ipairs({16765}) do I[i] = "Warsong Outrider Update" end
for _, i in ipairs({16746}) do I[i] = "Warsong Report" end
for _, i in ipairs({16763}) do I[i] = "Warsong Runner Update" end
for _, i in ipairs({16742}) do I[i] = "Warsong Saw Blades" end
for _, i in ipairs({16764}) do I[i] = "Warsong Scout Update" end
for _, i in ipairs({22374}) do I[i] = "Wartorn Chain Scrap" end
for _, i in ipairs({22376}) do I[i] = "Wartorn Cloth Scrap" end
for _, i in ipairs({22373}) do I[i] = "Wartorn Leather Scrap" end
for _, i in ipairs({22375}) do I[i] = "Wartorn Plate Scrap" end
for _, i in ipairs({5103}) do I[i] = "Washte Pawne's Feather" end
for _, i in ipairs({8483}) do I[i] = "Wastewander Water Pouch" end
for _, i in ipairs({3923}) do I[i] = "Water Elemental Bracers" end
for _, i in ipairs({18958}) do I[i] = "Water Elemental Core" end
for _, i in ipairs({4755}) do I[i] = "Water Pitcher" end
for _, i in ipairs({6637}) do I[i] = "Water Sapta" end
for _, i in ipairs({4823}) do I[i] = "Water of the Seers" end
for _, i in ipairs({4433}) do I[i] = "Waterlogged Envelope" end
for _, i in ipairs({20087}) do I[i] = "Wavethrasher Scales" end
for _, i in ipairs({6495}) do I[i] = "Weatherbeaten Parchment" end
for _, i in ipairs({6489}) do I[i] = "Weatherworn Parchment" end
for _, i in ipairs({11830}) do I[i] = "Webbed Diemetradon Scale" end
for _, i in ipairs({11831}) do I[i] = "Webbed Pterrordax Scale" end
for _, i in ipairs({5167}) do I[i] = "Webwood Egg" end
for _, i in ipairs({10640}) do I[i] = "Webwood Ichor" end
for _, i in ipairs({3412}) do I[i] = "Webwood Spider Silk" end
for _, i in ipairs({5166}) do I[i] = "Webwood Venom Sac" end
for _, i in ipairs({4808}) do I[i] = "Well Stone" end
for _, i in ipairs({2671}) do I[i] = "Wendigo Mane" end
for _, i in ipairs({1972}) do I[i] = "Westfall Deed" end
for _, i in ipairs({11951}) do I[i] = "Whipper Root Tuber" end
for _, i in ipairs({6894}) do I[i] = "Whirlwind Heart" end
for _, i in ipairs({4375}) do I[i] = "Whirring Bronze Gizmo" end
for _, i in ipairs({13317}) do I[i] = "Whistle of the Ivory Raptor" end
for _, i in ipairs({8586}) do I[i] = "Whistle of the Mottled Red Raptor" end
for _, i in ipairs({13326}) do I[i] = "White Mechanostrider Mod A" end
for _, i in ipairs({18159}) do I[i] = "White Moro'gai Gem" end
for _, i in ipairs({9279}) do I[i] = "White Punch Card" end
for _, i in ipairs({11477}) do I[i] = "White Ravasaur Claw" end
for _, i in ipairs({12353}) do I[i] = "White Stallion Bridle" end
for _, i in ipairs({15088}) do I[i] = "Wicked Leather Belt" end
for _, i in ipairs({15086}) do I[i] = "Wicked Leather Headband" end
for _, i in ipairs({8214}) do I[i] = "Wild Leather Helmet" end
for _, i in ipairs({8211}) do I[i] = "Wild Leather Vest" end
for _, i in ipairs({16716}) do I[i] = "Wildheart Belt" end
for _, i in ipairs({16715}) do I[i] = "Wildheart Boots" end
for _, i in ipairs({16714}) do I[i] = "Wildheart Bracers" end
for _, i in ipairs({16720}) do I[i] = "Wildheart Cowl" end
for _, i in ipairs({16717}) do I[i] = "Wildheart Gloves" end
for _, i in ipairs({16719}) do I[i] = "Wildheart Kilt" end
for _, i in ipairs({16718}) do I[i] = "Wildheart Spaulders" end
for _, i in ipairs({16706}) do I[i] = "Wildheart Vest" end
for _, i in ipairs({10819}) do I[i] = "Wildkin Feather" end
for _, i in ipairs({9618}) do I[i] = "Wildkin Muisek Vessel" end
for _, i in ipairs({5416}) do I[i] = "Wildmane Cleansing Totem" end
for _, i in ipairs({4749}) do I[i] = "Wildmane Well Water" end
for _, i in ipairs({8153}) do I[i] = "Wildvine" end
for _, i in ipairs({1327}) do I[i] = "Wiley's Note" end
for _, i in ipairs({957}) do I[i] = "William's Shipment" end
for _, i in ipairs({4751}) do I[i] = "Windfury Talon" end
for _, i in ipairs({2722}) do I[i] = "Wine Ticket" end
for _, i in ipairs({12565}) do I[i] = "Winna's Kitten Carrier" end
for _, i in ipairs({12829}) do I[i] = "Winterfall Crate" end
for _, i in ipairs({20742}) do I[i] = "Winterfall Ritual Totem" end
for _, i in ipairs({21383}) do I[i] = "Winterfall Spirit Beads" end
for _, i in ipairs({5411}) do I[i] = "Winterhoof Cleansing Totem" end
for _, i in ipairs({21928}) do I[i] = "Winterspring Blood Sample" end
for _, i in ipairs({5064}) do I[i] = "Witchwing Talon" end
for _, i in ipairs({19703}) do I[i] = "Witherbark Coin" end
for _, i in ipairs({4522}) do I[i] = "Witherbark Medicine Pouch" end
for _, i in ipairs({9320}) do I[i] = "Witherbark Skull" end
for _, i in ipairs({7273}) do I[i] = "Witherbark Totem Stick" end
for _, i in ipairs({4503}) do I[i] = "Witherbark Tusk" end
for _, i in ipairs({6170}) do I[i] = "Wizards' Reagents" end
for _, i in ipairs({6016}) do I[i] = "Wolf Heart Sample" end
for _, i in ipairs({10283}) do I[i] = "Wolf Heart Samples" end
for _, i in ipairs({5018}) do I[i] = "Wood Pulp" end
for _, i in ipairs({9266}) do I[i] = "Woodpaw Battle Plans" end
for _, i in ipairs({9237}) do I[i] = "Woodpaw Gnoll Mane" end
for _, i in ipairs({3530}) do I[i] = "Wool Bandage" end
for _, i in ipairs({2592}) do I[i] = "Wool Cloth" end
for _, i in ipairs({13158}) do I[i] = "Words of the High Chief" end
for _, i in ipairs({896}) do I[i] = "Worgen Fang" end
for _, i in ipairs({895}) do I[i] = "Worgen Skull" end
for _, i in ipairs({8165}) do I[i] = "Worn Dragonscale" end
for _, i in ipairs({3659}) do I[i] = "Worn Leather Book" end
for _, i in ipairs({5348}) do I[i] = "Worn Parchment" end
for _, i in ipairs({3714}) do I[i] = "Worn Stone Token" end
for _, i in ipairs({3425}) do I[i] = "Woven Wand" end
for _, i in ipairs({5490}) do I[i] = "Wrathtail Head" end
for _, i in ipairs({22593}) do I[i] = "Writ of Safe Passage" end
for _, i in ipairs({13197}) do I[i] = "Writhing Haunt Cauldron Key" end
for _, i in ipairs({19941}) do I[i] = "Wushoolay's Mane" end
for _, i in ipairs({7268}) do I[i] = "Xavian Water Sample" end
for _, i in ipairs({18670}) do I[i] = "Xorothian Glyphs" end
for _, i in ipairs({18687}) do I[i] = "Xorothian Stardust" end
for _, i in ipairs({10681}) do I[i] = "Xylem's Note" end
for _, i in ipairs({4647}) do I[i] = "Yagyin's Digest" end
for _, i in ipairs({10699}) do I[i] = "Yeh'kinya's Bramble" end
for _, i in ipairs({10818}) do I[i] = "Yeh'kinya's Scroll" end
for _, i in ipairs({19709}) do I[i] = "Yellow Hakkari Bijou" end
for _, i in ipairs({11188}) do I[i] = "Yellow Power Crystal" end
for _, i in ipairs({9280}) do I[i] = "Yellow Punch Card" end
for _, i in ipairs({3720}) do I[i] = "Yeti Fur" end
for _, i in ipairs({3397}) do I[i] = "Young Crocolisk Skin" end
for _, i in ipairs({3614}) do I[i] = "Yowler's Paw" end
for _, i in ipairs({22139}) do I[i] = "Ysida's Locket" end
for _, i in ipairs({15785}) do I[i] = "Zaeldarr's Head" end
for _, i in ipairs({4866}) do I[i] = "Zalazane's Head" end
for _, i in ipairs({5628}) do I[i] = "Zamah's Note" end
for _, i in ipairs({19858}) do I[i] = "Zandalar Honor Token" end
for _, i in ipairs({20077}) do I[i] = "Zandalar Signet of Might" end
for _, i in ipairs({20076}) do I[i] = "Zandalar Signet of Mojo" end
for _, i in ipairs({20078}) do I[i] = "Zandalar Signet of Serenity" end
for _, i in ipairs({19614,19615,19616}) do I[i] = "Zandalarian Shadow Talisman" end
for _, i in ipairs({4016}) do I[i] = "Zanzil's Mixture" end
for _, i in ipairs({16306}) do I[i] = "Zargh's Meats" end
for _, i in ipairs({7974}) do I[i] = "Zesty Clam Meat" end
for _, i in ipairs({5086}) do I[i] = "Zhevra Hooves" end
for _, i in ipairs({3907}) do I[i] = "Ziata'jai Trophy" end
for _, i in ipairs({17384,17410}) do I[i] = "Zinfizzlex's Portable Shredder Unit" end
for _, i in ipairs({8525}) do I[i] = "Zinge's Purchase Order" end
for _, i in ipairs({18904}) do I[i] = "Zorbin's Ultra-Shrinker" end
for _, i in ipairs({6089}) do I[i] = "Zraedus's Brew" end
for _, i in ipairs({18961}) do I[i] = "Zukk'ash Carapace" end
for _, i in ipairs({3908}) do I[i] = "Zul'Mamwe Trophy" end
for _, i in ipairs({19698}) do I[i] = "Zulian Coin" end
for _, i in ipairs({19975}) do I[i] = "Zulian Mudskunk" end
for _, i in ipairs({23227}) do I[i] = "iCoke Gift Box Voucher" end
for _, i in ipairs({19642,22822}) do I[i] = "iCoke Prize Voucher" end
