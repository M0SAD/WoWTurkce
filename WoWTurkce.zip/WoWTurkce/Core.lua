-- WoWTürkçe - çekirdek
local ADDON, WT = ...
-- Bu tablo eklentiye özeldir; arayüz motoru (Arayuz/Cekirdek.lua) kendi "WoWTurkce" genel tablosunu kullanır.
-- Ayarlar paneli istatistik ve kayıt temizliği için buraya WoWTurkceYeni adıyla erişir.
_G.WoWTurkceYeni = WT

-- Bir bölüm açık mı? Genel "Türkçe çeviriyi aç" anahtarı ve Alt (geçici İngilizce) de hesaba katılır.
function WT.Acik(k)
  local a = WoWTurkce_Ayar
  if not a or a.acik == false or a[k] == false then return false end
  local G = _G.WoWTurkce
  if G and G._shiftEn then return false end
  return true
end

WT.Ad      = WT.Ad      or {}   -- ["English name"] = "Türkçe ad"
WT.Yaratik = WT.Yaratik or {}   -- [npcID] = "Türkçe ad" (aynı İngilizce adın farklı çevirisi gerekirse)
WT.Unvan   = WT.Unvan   or {}   -- ["English subname"] = "Türkçe unvan"

local strsplit, tonumber = strsplit, tonumber

-- GUID'den NPC ID: "Creature-0-sunucu-örnek-bölge-NPCID-spawn"
-- Gizli (secret) değerler: savaşta/zindanda bazı birim bilgileri eklentilere kapalı; dokunmadan atla
function WT.Gizli(v) if issecretvalue then return issecretvalue(v) == true end return false end
function WT.NpcID(guid)
  if guid == nil or WT.Gizli(guid) or type(guid) ~= "string" then return nil end
  local tur, _, _, _, _, id = strsplit("-", guid)
  if tur == "Creature" or tur == "Vehicle" or tur == "Pet" then
    return tonumber(id)
  end
end

function WT.UnitNpcID(unit)
  if unit == nil or WT.Gizli(unit) then return nil end
  local ok, guid = pcall(UnitGUID, unit)
  return ok and WT.NpcID(guid) or nil
end

-- Eksik çeviri kaydı: WoWTurkce_Kayit[kategori][anahtar] = değer
function WT.Kaydet(kategori, anahtar, deger)
  if not WoWTurkce_Ayar or WoWTurkce_Ayar.kayit == false then return end
  WoWTurkce_Kayit = WoWTurkce_Kayit or {}
  local k = WoWTurkce_Kayit[kategori]
  if not k then k = {}; WoWTurkce_Kayit[kategori] = k end
  if k[anahtar] == nil then k[anahtar] = deger end
end

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:SetScript("OnEvent", function(self, _, name)
  if name ~= ADDON then return end
  WoWTurkce_Kayit = WoWTurkce_Kayit or {}
  WoWTurkce_Ayar = WoWTurkce_Ayar or {}
  if WoWTurkce_Ayar.topla ~= nil then -- eski ad: artık ayarlar panelindeki "kayit"
    if WoWTurkce_Ayar.kayit == nil then WoWTurkce_Ayar.kayit = WoWTurkce_Ayar.topla end
    WoWTurkce_Ayar.topla = nil
  end
  if WoWTurkce_Ayar.yaratik == nil then WoWTurkce_Ayar.yaratik = true end
  if WoWTurkce_Ayar.esya == nil then WoWTurkce_Ayar.esya = true end
  -- Arayüz motoru (sohbet, ganimet mesajları vb.) eşya ve büyü adlarını bu projenin tablolarından bulsun
  local G = _G.WoWTurkce
  if type(G) == "table" then
    for ad, kaynak in pairs({ EsyaAdi = WT.Esya, BuyuAdi = WT.BuyuAd }) do
      if type(G[ad]) == "table" and not getmetatable(G[ad]) and kaynak then
        setmetatable(G[ad], { __index = kaynak })
      end
    end
  end
  self:UnregisterEvent("ADDON_LOADED")
  if WT.Yuklendi then WT.Yuklendi() end
end)

SLASH_WOWTURKCEYENI1 = "/wt"
SlashCmdList.WOWTURKCEYENI = function(msg)
  msg = (msg or ""):lower()
  if msg == "yaratik" then
    WoWTurkce_Ayar.yaratik = not WoWTurkce_Ayar.yaratik
    print("|cff33ff99WoWTürkçe:|r Yaratık adları " .. (WoWTurkce_Ayar.yaratik and "Türkçe" or "İngilizce") .. ". /reload önerilir.")
  elseif msg == "esya" then
    WoWTurkce_Ayar.esya = not WoWTurkce_Ayar.esya
    print("|cff33ff99WoWTürkçe:|r Eşya adları " .. (WoWTurkce_Ayar.esya and "Türkçe" or "İngilizce") .. ".")
  elseif msg:match("^esyadokum") then
    local a, b = msg:match("^esyadokum%s+(%d+)%s+(%d+)")
    WT.EsyaDokumBaslat(tonumber(a), tonumber(b))
  elseif msg:match("^buyudokum") then
    local a, b = msg:match("^buyudokum%s+(%d+)%s+(%d+)")
    if WT.BuyuDokumBaslat then
      WT.BuyuDokumBaslat(tonumber(a), tonumber(b))
    else
      print("|cff33ff99WoWTürkçe:|r Büyü modülü yüklenmemiş. Eklentiye yeni dosya eklendi: oyunu tamamen kapatıp yeniden aç (/reload yetmez).")
    end
  elseif msg == "agacdokum" then
    if WT.AgacDokumBaslat then WT.AgacDokumBaslat() end
  elseif msg == "aciklamadokum" then
    if WT.AciklamaDokumBaslat then WT.AciklamaDokumBaslat() end
  elseif msg == "basarimdokum" then
    if WT.BasarimDokumBaslat then WT.BasarimDokumBaslat() else print("|cff33ff99WoWTürkçe:|r Oyunu tamamen kapatıp yeniden aç (yeni dosya eklendi).") end
  elseif msg == "yetenekdokum" then
    if WT.YetenekDokumBaslat then WT.YetenekDokumBaslat() end
  elseif msg == "buyu" then
    WoWTurkce_Ayar.buyu = WoWTurkce_Ayar.buyu == false
    print("|cff33ff99WoWTürkçe:|r Büyü ve yetenek çevirisi " .. (WoWTurkce_Ayar.buyu and "açık" or "kapalı") .. ".")
  elseif msg == "topla" or msg == "kayit" then
    WoWTurkce_Ayar.kayit = WoWTurkce_Ayar.kayit == false
    print("|cff33ff99WoWTürkçe:|r Eksik çeviri kaydı " .. (WoWTurkce_Ayar.kayit and "açık" or "kapalı") .. ".")
  elseif msg ~= "" and SlashCmdList.WOWTR then
    SlashCmdList.WOWTR(msg) -- ayar, tr, en, paylas, sil... (Arayuz/Cekirdek.lua)
  else
    local n, e = 0, 0
    for _ in pairs(WT.Yaratik) do n = n + 1 end
    for _ in pairs((WoWTurkce_Kayit and WoWTurkce_Kayit.yaratik) or {}) do e = e + 1 end
    print("|cff33ff99WoWTürkçe:|r " .. n .. " yaratık adı çevrili, " .. e .. " eksik kaydedildi.")
    print("  /wt yaratik - yaratık adlarını aç/kapat")
    print("  /wt esya - eşya adlarını aç/kapat")
    print("  /wt esyadokum - oyundaki tüm eşyaların ipucu metinlerini döker (çeviri için)")
    print("  /wt buyu - büyü ve yetenek çevirisini aç/kapat")
    print("  /wt buyudokum - oyundaki tüm büyülerin ve yetenek ağacının metinlerini döker (çeviri için)")
    print("  /wt basarimdokum - oyundaki tüm başarımların metinlerini döker (çeviri için)")
    print("  /wt kayit - eksik çeviri kaydını aç/kapat")
    print("  /wt ayar - ayarlar paneli,  /wt tr | en - Türkçe aç/kapat,  /wt paylas - çevrilmemişleri gönder")
  end
end
