local _;

local huge = math.huge;
local strsub = strsub;
local InCombatLockdown = InCombatLockdown;
local twipe = table.wipe;
local tinsert = tinsert;
local strfind = strfind;
local strsplit = strsplit;
local strbyte = strbyte;
local floor = floor;
local tonumber = tonumber;
local select = select;
local strmatch = strmatch;
local IsInRaid = IsInRaid;
local IsInGroup = IsInGroup;
local UnitInRange = UnitInRange;
local GetRaidRosterInfo = GetRaidRosterInfo;
local IsInInstance = IsInInstance;
local GetTime = GetTime;
local GetRealZoneText = GetRealZoneText;
local UnitPowerBarID = UnitPowerBarID;
local GetUnitPowerBarInfoByID = GetUnitPowerBarInfoByID;
local WorldMapFrame = WorldMapFrame;
local GetPlayerFacing = GetPlayerFacing;
local GetSpellName = C_Spell.GetSpellName;
local CheckInteractDistance = CheckInteractDistance;
local UnitIsUnit = UnitIsUnit;
local UnitGUID = UnitGUID;
local UnitInRange = UnitInRange;
local UnitPlayerOrPetInParty = UnitPlayerOrPetInParty;
local UnitPlayerOrPetInRaid = UnitPlayerOrPetInRaid;
local UnitIsPlayer = UnitIsPlayer;
local UnitCanAttack = UnitCanAttack;
local IsAltKeyDown = IsAltKeyDown;
local IsControlKeyDown = IsControlKeyDown;
local IsShiftKeyDown = IsShiftKeyDown;
local VUHDO_atan2 = math.atan2;
local VUHDO_PI, VUHDO_2_PI = math.pi, math.pi * 2;
local floor = floor;
local pairs = pairs;
local type = type;
local abs = abs;
local GetAuraDataBySlot = C_UnitAuras and C_UnitAuras.GetAuraDataBySlot;
local GetAuraDataBySpellName = C_UnitAuras and C_UnitAuras.GetAuraDataBySpellName;
local GetAuraSlots = C_UnitAuras and C_UnitAuras.GetAuraSlots;
local GetUnitAuraBySpellID = C_UnitAuras and C_UnitAuras.GetUnitAuraBySpellID;
local GetPlayerAuraBySpellID = C_UnitAuras and C_UnitAuras.GetPlayerAuraBySpellID;
local ShouldSpellAuraBeSecret = C_Secrets and C_Secrets.ShouldSpellAuraBeSecret;
local FindAura = AuraUtil.FindAura;
local FindAuraByName = AuraUtil.FindAuraByName;
local IsUsableItem = IsUsableItem or C_Item.IsUsableItem;
local IsUsableSpell = IsUsableSpell or C_Spell.IsSpellUsable;
local GetSpellCooldownDuration = C_Spell and C_Spell.GetSpellCooldownDuration;
local IsSpellInRange = IsSpellInRange or C_Spell.IsSpellInRange;
local UnitIsDeadOrGhost = UnitIsDeadOrGhost;
local UnitIsConnected = UnitIsConnected;
local IsSpellInSpellBook = C_SpellBook and C_SpellBook.IsSpellInSpellBook;
local IsSpellKnownNew = C_SpellBook and C_SpellBook.IsSpellKnown;
local SpellBookSpellBank = Enum and Enum.SpellBookSpellBank;
local issecretvalue = issecretvalue;
local issecrettable = issecrettable;
local sSecretsEnabled = VUHDO_SECRETS_ENABLED;
local UnitHealthPercent = UnitHealthPercent;
local CurveConstants = CurveConstants;

-- talent cache maps for new large Dragonflight talent trees
local VUHDO_TALENT_CACHE_SPELL_ID = {
	-- [<spell ID>] = <spell name>,
};

local VUHDO_TALENT_CACHE_SPELL_NAME = {
	-- [<spell name>] = <spell ID>,
};

local sEmpty = { };
setmetatable(sEmpty, { __newindex = function(aTable, aKey, aValue) VUHDO_xMsg("WARNING: newindex on dummy array: ", aKey, aValue); end });

-- Common meta tables

VUHDO_META_EMPTY_ARRAY = {
	__index = function (aTable, aKey)
		return sEmpty;
	end
};

VUHDO_META_NEW_ARRAY = {
	__index = function(aTable, aKey)
		local tValue = { };
		rawset(aTable, aKey, tValue);
		return tValue;
	end
};



--
function VUHDO_tableCreate(...)

	local tTable = { };

	return tTable;

end
local tcreate = table.create or VUHDO_tableCreate;



--
local tResult;
local tGuid;
local tOtherGuid;
function VUHDO_unitIsUnit(aUnit, anotherUnit)

	tResult = UnitIsUnit(aUnit, anotherUnit);

	if tResult ~= nil and (not sSecretsEnabled or not issecretvalue(tResult)) then
		return tResult;
	end

	if not sSecretsEnabled then
		return false;
	end

	tGuid = UnitGUID(aUnit);
	tOtherGuid = UnitGUID(anotherUnit);

	if not tGuid or not tOtherGuid then
		return false;
	end

	if issecretvalue(tGuid) or issecretvalue(tOtherGuid) then
		return false;
	end

	return tGuid == tOtherGuid;

end



--
local tSpellInfo;
function VUHDO_getSpellInfo(aSpellId)

	if not aSpellId then
		return;
	end

	if GetSpellInfo then
		return GetSpellInfo(aSpellId);
	end

	tSpellInfo = C_Spell.GetSpellInfo(aSpellId);

	if not tSpellInfo then
		return;
	end

	return tSpellInfo.name, nil, tSpellInfo.iconID, tSpellInfo.castTime, tSpellInfo.minRange, tSpellInfo.maxRange, tSpellInfo.spellID, tSpellInfo.originalIconID;

end



--
local tSpellCooldown;
local tDuration;
function VUHDO_getSpellCooldown(aSpellId)

	if not aSpellId then
		return;
	end

	if GetSpellCooldown then
		return GetSpellCooldown(aSpellId);
	end

	tSpellCooldown = C_Spell.GetSpellCooldown(aSpellId);

	if not tSpellCooldown then
		return;
	end

	if sSecretsEnabled then
		tDuration = GetSpellCooldownDuration(aSpellId);

		return tSpellCooldown.startTime, tSpellCooldown.duration, tSpellCooldown.isEnabled, tSpellCooldown.modRate, tSpellCooldown.isOnGCD, tDuration;
	end

	return tSpellCooldown.startTime, tSpellCooldown.duration, tSpellCooldown.isEnabled, tSpellCooldown.modRate;

end



--
local tIconId;
function VUHDO_getSpellBookItemTexture(aSpellId)

	if not aSpellId then
		return;
	end

	_, tIconId = VUHDO_getSpellInfo(aSpellId);

	return tIconId;

end



--
local tSpellNameById;
function VUHDO_resolveSpellId(aSpellName)

	if tonumber(aSpellName or "x") then
		tSpellNameById = GetSpellName(tonumber(aSpellName));

		if tSpellNameById then
			return tSpellNameById;
		end
	end

	return aSpellName;

end



--
local tKeySpellName;
function VUHDO_addSpellNameKeys(aTable, ...)

	for tCnt = 1, select("#", ...) do
		tKeySpellName = GetSpellName((select(tCnt, ...)));

		if tKeySpellName then
			aTable[tKeySpellName] = true;
		end
	end

	return aTable;

end




--
local tResolvedName;
function VUHDO_formatAuraSpellDisplayName(aSpellName)

	tResolvedName = VUHDO_resolveSpellId(aSpellName);

	return (tResolvedName ~= aSpellName) and ("[" .. aSpellName .. "] " .. tResolvedName) or tostring(aSpellName);

end



--
local VUHDO_RANGE_SPELLS_REMAP = VUHDO_RANGE_SPELLS_REMAP;

local tIsSpellInRange;
function VUHDO_isSpellInRange(aSpell, aUnit, aUnitReaction)

	if not aSpell or not aUnit then
		return;
	end

	tIsSpellInRange = IsSpellInRange(aSpell, aUnit);

	if tIsSpellInRange == nil and aUnitReaction and
		VUHDO_RANGE_SPELLS_REMAP[aUnitReaction] and VUHDO_RANGE_SPELLS_REMAP[aUnitReaction][aSpell] then
		for _, tRangeSpell in pairs(VUHDO_RANGE_SPELLS_REMAP[aUnitReaction][aSpell]) do
			tIsSpellInRange = IsSpellInRange(tRangeSpell, aUnit);

			if tIsSpellInRange ~= nil then
				break;
			end
		end
	end

	if tIsSpellInRange == true or tIsSpellInRange == 1 then
		return true;
	elseif tIsSpellInRange == false or tIsSpellInRange == 0 then
		return false;
	end

	return;

end



--
local tTextureHeight, tTextureWidth = 256, 256;
local tRoleHeight, tRoleWidth = 67, 67;
function VUHDO_getTexCoordsForRole(aRole)

	if aRole == "GUIDE" then
		return GetTexCoordsByGrid(1, 1, tTextureWidth, tTextureHeight, tRoleWidth, tRoleHeight);
	elseif aRole == "TANK" then
		return GetTexCoordsByGrid(1, 2, tTextureWidth, tTextureHeight, tRoleWidth, tRoleHeight);
	elseif aRole == "HEALER" then
		return GetTexCoordsByGrid(2, 1, tTextureWidth, tTextureHeight, tRoleWidth, tRoleHeight);
	elseif aRole == "DAMAGER" then
		return GetTexCoordsByGrid(2, 2, tTextureWidth, tTextureHeight, tRoleWidth, tRoleHeight);
	end

end



--
local tMouseFoci;
function VUHDO_getMouseFocus()

	tMouseFoci = GetMouseFoci();

	if tMouseFoci and tMouseFoci[1] and tMouseFoci[1]:CanBeAccessedInContext() and not tMouseFoci[1]:IsForbidden() then
		return tMouseFoci[1];
	end

end



-- returns an array of numbers sequentially found in a string
local tNumbers = { };
local tIndex;
local tDigit;
local tIsInNumber;
function VUHDO_getNumbersFromString(aName, aMaxAnz)
	twipe(tNumbers);
	tIndex = 0;
	tIsInNumber = false;

	for tCnt = 1, #aName do
		tDigit = strbyte(aName, tCnt);
		if tDigit >= 48 and tDigit <= 57 then
			if tIsInNumber then
				tNumbers[tIndex] = tNumbers[tIndex] * 10 + tDigit - 48;
			else
				tIsInNumber = true;
				tIndex = tIndex + 1;
				tNumbers[tIndex] = tDigit - 48;
			end
		else
			if tIndex >= aMaxAnz then	return tNumbers; end
			tIsInNumber = false;
		end
	end

	return tNumbers;
end



--
--[[VUHDO_COMBAT_LOG_TRACE = {};
local tEntry;
function VUHDO_traceCombatLog(anArg1, anArg2, anArg3, anArg4, anArg5, anArg6, anArg7, anArg8, anArg9, anArg10, anArg11, anArg12, anArg13, anArg14)
	tEntry = "";
	tEntry = tEntry .. "[1]:" .. (anArg1 or "<nil>") .. ",";
	tEntry = tEntry .. "[2]:" .. (anArg2 or "<nil>") .. ",";
	tEntry = tEntry .. "[3]:" .. (anArg3 or "<nil>") .. ",";
	tEntry = tEntry .. "[4]:" .. (anArg4 or "<nil>") .. ",";
	tEntry = tEntry .. "[5]:" .. (anArg5 or "<nil>") .. ",";
	tEntry = tEntry .. "[6]:" .. (anArg6 or "<nil>") .. ",";
	tEntry = tEntry .. "[7]:" .. (anArg7 or "<nil>") .. ",";
	tEntry = tEntry .. "[8]:" .. (anArg8 or "<nil>") .. ",";
	tEntry = tEntry .. "[9]:" .. (anArg9 or "<nil>") .. ",";
	tEntry = tEntry .. "[10]:" .. (anArg10 or "<nil>") .. ",";
	tEntry = tEntry .. "[11]:" .. (anArg11 or "<nil>") .. ",";
	tEntry = tEntry .. "[12]:" .. (anArg12 or "<nil>") .. ",";
	tEntry = tEntry .. "[13]:" .. (anArg13 or "<nil>") .. ",";
	tEntry = tEntry .. "[14]:" .. (anArg14 or "<nil>") .. ",";
	tEntry = tEntry .. "[15]:" .. (anArg15 or "<nil>") .. ",";
	tEntry = tEntry .. "[16]:" .. (anArg16 or "<nil>") .. ",";
	tinsert(VUHDO_COMBAT_LOG_TRACE, tEntry);
end]]



--
function VUHDO_tableUniqueAdd(aTable, aValue)

	for _, tValue in pairs(aTable) do
		if tValue == aValue then
			return false;
		end
	end

	aTable[#aTable + 1] = aValue;

	return true;

end



--
local tKeysToRemove;
function VUHDO_tableRemoveValue(aTable, aValue)

	if not aTable or not aValue then
		return false;
	end

	tKeysToRemove = { };

	for tKey, tValue in pairs(aTable) do
		if tValue == aValue then
			tinsert(tKeysToRemove, tKey);
		end
	end

	for _, tKey in ipairs(tKeysToRemove) do
		aTable[tKey] = nil;
	end

	return #tKeysToRemove > 0;

end



--
function VUHDO_tableRemoveByKey(aTable, aKey)

	if not aTable or not aKey then
		return;
	end

	if aKey ~= nil then
		aTable[aKey] = nil;
	end

	return;

end



--
function VUHDO_tableGetKeyFromValue(aTable, aValue)

	if not aTable or not aValue then
		return nil;
	end

	for tKey, tValue in pairs(aTable) do
		if tValue == aValue then return tKey; end
	end

	return nil;

end


----------------------------------------------------
local VUHDO_RAID;
local VUHDO_UNIT_BUTTONS;
local VUHDO_CONFIG;
local VUHDO_BOSS_UNITS;
local VUHDO_isAuraDataRestricted;
local sRangeSpell;
local sIsHelpfulGuessRange = true;
local sIsHarmfulGuessRange = true;
local sScanRange;
local sZeroRange = "";
local sPetRangeSpell;
local sResurrectionRangeSpell;

local VUHDO_PET_RANGE_SPELLS = VUHDO_PET_RANGE_SPELLS;
local VUHDO_RESURRECTION_RANGE_SPELLS = VUHDO_RESURRECTION_RANGE_SPELLS;


--
function VUHDO_toolboxInitLocalOverrides()

	VUHDO_RAID = _G["VUHDO_RAID"];
	VUHDO_UNIT_BUTTONS = _G["VUHDO_UNIT_BUTTONS"];
	VUHDO_CONFIG = _G["VUHDO_CONFIG"];
	VUHDO_BOSS_UNITS = _G["VUHDO_BOSS_UNITS"];
	VUHDO_isAuraDataRestricted = _G["VUHDO_isAuraDataRestricted"];

	sScanRange = tonumber(VUHDO_CONFIG["SCAN_RANGE"]);

	-- FIXME: why can't model sanity be run prior to burst cache initialization?
	if type(VUHDO_CONFIG["RANGE_SPELL"]) == "table" and type(VUHDO_CONFIG["RANGE_PESSIMISTIC"]) == "table" then
		sRangeSpell = VUHDO_CONFIG["RANGE_SPELL"];
		sIsHelpfulGuessRange = VUHDO_CONFIG["RANGE_PESSIMISTIC"]["HELPFUL"] or GetSpellName(sRangeSpell["HELPFUL"]) == nil;
		sIsHarmfulGuessRange = VUHDO_CONFIG["RANGE_PESSIMISTIC"]["HARMFUL"] or GetSpellName(sRangeSpell["HARMFUL"]) == nil;
	end

	sPetRangeSpell = VUHDO_PET_RANGE_SPELLS[VUHDO_PLAYER_CLASS];
	sResurrectionRangeSpell = VUHDO_RESURRECTION_RANGE_SPELLS[VUHDO_PLAYER_CLASS];

	sZeroRange = "0.0 " .. VUHDO_I18N_YARDS;

	return;

end



local VUHDO_PROFILE_TIMER;

--
function VUHDO_initProfiler()
	VUHDO_PROFILE_TIMER = GetTime() * 1000;
end



--
function VUHDO_seeProfiler()
	VUHDO_xMsg("D: ", floor(GetTime() * 1000 - VUHDO_PROFILE_TIMER));
end



-- Print chat frame line with no "{Vuhdo} prefix
function VUHDO_MsgC(aMessage, aRed, aGreen, aBlue)
	aRed, aGreen, aBlue = aRed or 1, aGreen or 0.7, aBlue or 0.2;
	DEFAULT_CHAT_FRAME:AddMessage(aMessage, aRed, aGreen, aBlue);
end



--
local function VUHDO_arg2Text(anArg)
	if anArg == nil  then return "<nil>";
	elseif issecretvalue and issecretvalue(anArg) then return "<secret>";
	elseif "function" == type(anArg) then return "<func>";
	elseif "table" == type(anArg) then return "<table>";
	elseif "boolean" == type(anArg) then return anArg and "<true>" or  "<false>";
	elseif anArg == "" then return " ";
	else return anArg; end
end



-- Print a standard chat frame
function VUHDO_Msg(aMessage, aRed, aGreen, aBlue)
	VUHDO_MsgC("|cffffe566{VuhDo}|r " .. VUHDO_arg2Text(aMessage), aRed, aGreen, aBlue)
end



--
function VUHDO_xMsg(...)
	local tText = "";

	for tCnt = 1, select('#', ...) do
		tText = tText .. tCnt .. "=[" .. VUHDO_arg2Text(select(tCnt, ...)) .. "] ";
	end
	VUHDO_MsgC(tText);
end



--
function VUHDO_getCurrentGroupType()
	return IsInRaid() and 2 or IsInGroup() and 1 or 0;
end
local VUHDO_getCurrentGroupType = VUHDO_getCurrentGroupType;



-- returns unit-prefix, pet-prefix and maximum number of players in a party
function VUHDO_getUnitIds()
	if IsInRaid() then return "raid", "raidpet";
	elseif IsInGroup() then	return "party", "partypet";
	else return "player", "pet"; end
end



-- Extracts unit number from a Unit's name
function VUHDO_getUnitNo(aUnit)
	if not aUnit or VUHDO_isSpecialUnit(aUnit) then return 0; end
	if "player" == aUnit then aUnit = VUHDO_PLAYER_RAID_ID or "player"; end
	return tonumber(strsub(aUnit, -2, -1)) or tonumber(strsub(aUnit, -1)) or 1;
end
local VUHDO_getUnitNo = VUHDO_getUnitNo;



-- returns the units subgroup number, or 0 for pets/focus
function VUHDO_getUnitGroup(aUnit, anIsPet)
	if anIsPet or not aUnit or VUHDO_isSpecialUnit(aUnit) then return 0;
	elseif VUHDO_GROUP_TYPE_RAID == VUHDO_getCurrentGroupType() then
		return select(3, GetRaidRosterInfo(VUHDO_getUnitNo(aUnit))) or 1;
	else return 1; end
end



--
local tIsInRange;
local tIsChecked;
function VUHDO_checkInteractDistance(aUnit, aDistIndex)

	if sSecretsEnabled then
		if not sIsHarmfulGuessRange and UnitCanAttack("player", aUnit) and sRangeSpell["HARMFUL"] then
			tIsSpellInRange = VUHDO_isSpellInRange(sRangeSpell["HARMFUL"], aUnit, "HARMFUL");

			if tIsSpellInRange ~= nil then
				return tIsSpellInRange;
			end
		elseif not sIsHelpfulGuessRange and sRangeSpell["HELPFUL"] then
			tIsSpellInRange = VUHDO_isSpellInRange(sRangeSpell["HELPFUL"], aUnit, "HELPFUL");

			if tIsSpellInRange ~= nil then
				return tIsSpellInRange;
			end
		end

		if not InCombatLockdown() then
			return CheckInteractDistance(aUnit, aDistIndex);
		end

		return false;
	end

	if not InCombatLockdown() then
		return CheckInteractDistance(aUnit, aDistIndex);
	else
		if not sIsHarmfulGuessRange and UnitCanAttack("player", aUnit) then
			return (VUHDO_isSpellInRange(sRangeSpell["HARMFUL"], aUnit, "HARMFUL") == true) and true or false;
		elseif not sIsHelpfulGuessRange then
			return (VUHDO_isSpellInRange(sRangeSpell["HELPFUL"], aUnit, "HELPFUL") == true) and true or false;
		else
			tIsInRange, tIsChecked = UnitInRange(aUnit);

			if tIsChecked and not tIsInRange then
				return false;
			else
				return true;
			end
		end
	end

end



--
local tPhaseReason;
function VUHDO_unitPhaseReason(aUnit) 

	if not aUnit then
		return nil;
	end

	tPhaseReason = UnitPhaseReason(aUnit);

	if sSecretsEnabled and issecretvalue(tPhaseReason) then
		return nil;
	end

	-- FIXME: workaround for Blizzard API bug: https://github.com/Stanzilla/WoWUIBugs/issues/49
	if (tPhaseReason == Enum.PhaseReason.WarMode or tPhaseReason == Enum.PhaseReason.ChromieTime or tPhaseReason == Enum.PhaseReason.TimerunningHwt) and UnitIsVisible(aUnit) then
		return nil;
	else
		return tPhaseReason;
	end

end



--
function VUHDO_isUnitRangeCheckable(aUnit)

	if not aUnit then
		return false;
	end

	if "player" == aUnit or VUHDO_unitIsUnit(aUnit, "player") then
		return true;
	end

	if "pet" == aUnit or VUHDO_unitIsUnit(aUnit, "pet") then
		return UnitPlayerOrPetInParty(aUnit) or UnitPlayerOrPetInRaid(aUnit);
	end

	if UnitPlayerOrPetInParty(aUnit) or UnitPlayerOrPetInRaid(aUnit) then
		return UnitIsPlayer(aUnit);
	end

	return false;

end

local VUHDO_isUnitRangeCheckable = VUHDO_isUnitRangeCheckable;



--
function VUHDO_isUnitRangeEventDriven(aUnit)

	if not aUnit then
		return false;
	end

	if "player" == aUnit or VUHDO_unitIsUnit(aUnit, "player") then
		return true;
	end

	if "pet" == aUnit or VUHDO_unitIsUnit(aUnit, "pet") or VUHDO_isSpecialUnit(aUnit) then
		return false;
	end

	return VUHDO_isUnitRangeCheckable(aUnit);

end



--
local tIsInRange;
local tIsChecked;
local tIsGuessRange;
local tRangeSpell;
local tUnitReaction;
local tIsSpellInRange;
local tIsInteractDistance;
local tUnitInfo;
local tFriendlyRangeSpell;
function VUHDO_isInRange(aUnit, anIsForceUpdate)

	if not aUnit then
		return nil;
	end

	if "player" == aUnit or VUHDO_unitIsUnit(aUnit, "player") then
		return true;
	end

	if not anIsForceUpdate and VUHDO_RAID then
		tUnitInfo = VUHDO_RAID[aUnit];

		if tUnitInfo and tUnitInfo["isEventRange"] then
			return tUnitInfo["range"];
		end
	end

	if VUHDO_unitPhaseReason(aUnit) then
		return false;
	end

	if sPetRangeSpell and ("pet" == aUnit or VUHDO_unitIsUnit(aUnit, "pet")) then
		tIsSpellInRange = VUHDO_isSpellInRange(sPetRangeSpell, aUnit, "HELPFUL");

		if tIsSpellInRange ~= nil then
			return tIsSpellInRange;
		end
	end

	if UnitCanAttack("player", aUnit) then
		tIsGuessRange = sIsHarmfulGuessRange;
		tUnitReaction = "HARMFUL";
	else
		tIsGuessRange = sIsHelpfulGuessRange;
		tUnitReaction = "HELPFUL";
	end

	tRangeSpell = sRangeSpell and sRangeSpell[tUnitReaction];
	tFriendlyRangeSpell = sRangeSpell and sRangeSpell["HELPFUL"];

	-- UnitInRange is SecretReturns; IsSpellInRange is not (SpellDocumentation.lua / UnitDocumentation.lua).
	if VUHDO_isUnitRangeCheckable(aUnit) then
		if sSecretsEnabled then
			return UnitInRange(aUnit);
		end

		tIsInRange, tIsChecked = UnitInRange(aUnit);

		if tIsChecked then
			return tIsInRange;
		end
	end

	if tRangeSpell and not tIsGuessRange and UnitCanAttack("player", aUnit) then
		tIsSpellInRange = VUHDO_isSpellInRange(tRangeSpell, aUnit, tUnitReaction);

		if tIsSpellInRange ~= nil then
			return tIsSpellInRange;
		end
	end

	if sResurrectionRangeSpell and not UnitCanAttack("player", aUnit) and UnitIsDeadOrGhost(aUnit) then
		tIsSpellInRange = VUHDO_isSpellInRange(sResurrectionRangeSpell, aUnit, "HELPFUL");

		if tIsSpellInRange ~= nil then
			return tIsSpellInRange;
		end
	end

	if tRangeSpell and not tIsGuessRange and not UnitCanAttack("player", aUnit) then
		tIsSpellInRange = VUHDO_isSpellInRange(tRangeSpell, aUnit, tUnitReaction);

		if tIsSpellInRange ~= nil then
			if tIsSpellInRange == false and not InCombatLockdown() and CheckInteractDistance(aUnit, 4) then
				return true;
			end

			return tIsSpellInRange;
		end
	end

	if not InCombatLockdown() then
		tIsInteractDistance = CheckInteractDistance(aUnit, 4);

		if tIsInteractDistance ~= nil then
			return tIsInteractDistance and true or false;
		end
	end

	if tFriendlyRangeSpell and not sIsHelpfulGuessRange and not UnitCanAttack("player", aUnit)
		and UnitIsConnected(aUnit) and not UnitIsDeadOrGhost(aUnit) then
		return false;
	end

	return true;

end



-- Parses a aString line into an array of arguments
function VUHDO_textParse(aString)
	aString = strtrim(aString);

	while strfind(aString, "  ", 1, true) do
		aString = gsub(aString, "  ", " ");
	end

	return VUHDO_splitStringQuoted(aString);
end



-- Returns a "deep" copy of a table,
-- which means containing tables will be copies value-wise, not by reference
function VUHDO_deepCopyTable(aTable)
	local tDestTable = { };

	for tKey, tValue in pairs(aTable) do
		tDestTable[tKey] = "table" == type(tValue) and VUHDO_deepCopyTable(tValue) or tValue;
	end

	return tDestTable;
end



-- Tokenizes a String into an array of strings, which were delimited by "aChar"
function VUHDO_splitString(aText, aChar)
	return { strsplit(aChar, aText) };
end



function VUHDO_splitStringQuoted(aText) 

	if VUHDO_strempty(aText) then
		return { "" };
	end

	local tSplit = {};
	local tPrevToken, tQuoteToken; 

	for tToken in string.gmatch(aText, "%S+") do 
		local tStartQuote = string.match(tToken, [[^(['"])]]); 
		local tEndQuote = string.match(tToken, [[(['"])$]]);

		if tStartQuote and not tEndQuote and not tQuoteToken then 
			tPrevToken = tToken; 
			tQuoteToken = tStartQuote; 
		elseif tPrevToken and tQuoteToken == tEndQuote then 
			tToken = tPrevToken .. ' ' .. tToken;

			tPrevToken = nil;
			tQuoteToken = nil;
		elseif tPrevToken then 
			tPrevToken = tPrevToken .. ' ' .. tToken; 
		end 

		if not tPrevToken then
			tToken = string.gsub(tToken, [[^(['"])]], "");
			tToken = string.gsub(tToken, [[(['"])$]], "");

			tinsert(tSplit, tToken);
		end
	end

	return tSplit;

end

-- returns true if player currently is in a battleground
local tType;
function VUHDO_isInBattleground()
	_, tType = IsInInstance();
	return "pvp" == tType or "arena" == tType;
end
local VUHDO_isInBattleground = VUHDO_isInBattleground;



-- returns the appropriate addon message channel for player
function VUHDO_getAddOnDistribution()
	return VUHDO_isInBattleground() and "BATTLEGROUND"
		or VUHDO_GROUP_TYPE_RAID == VUHDO_getCurrentGroupType() and "RAID" or "PARTY";
end



-- returns the units rank in a raid which is 0 = raid member, 1 = assist, 2 = leader
-- returns 2 if not in raid
local tRank, tIsMl, tGroupType;
local tIsGroupLeader;
function VUHDO_getUnitRank(aUnit)

	tGroupType = VUHDO_getCurrentGroupType();

	if VUHDO_GROUP_TYPE_RAID == tGroupType then
		_, tRank, _, _, _, _, _, _, _, _, tIsMl = GetRaidRosterInfo(VUHDO_getUnitNo(aUnit));

		return tRank, tIsMl;
	elseif VUHDO_GROUP_TYPE_PARTY == tGroupType then
		tIsGroupLeader = UnitIsGroupLeader(aUnit);

		if sSecretsEnabled and issecretvalue(tIsGroupLeader) then
			return 0, true;
		end

		return tIsGroupLeader and 2 or 0, true;
	else
		return 2, true;
	end

end



-- returns the players rank in a raid which is 0 = raid member, 1 = assist, 2 = leader
-- returns leader if not in raid, and member if solo, as no main tank are needed
function VUHDO_getPlayerRank()
	return VUHDO_getUnitRank("player");
end



-- returns the raid unit of player eg. "raid13" or "party4"
local tRaidUnit;
function VUHDO_getPlayerRaidUnit()
	if VUHDO_GROUP_TYPE_RAID == VUHDO_getCurrentGroupType() then
		for tCnt = 1, 40 do
			tRaidUnit = "raid" .. tCnt;
			if VUHDO_unitIsUnit("player", tRaidUnit) then return tRaidUnit; end
		end
	end
	return "player";
end



--
function VUHDO_getNumGroupMembers(aGroupId)
	return #(VUHDO_GROUPS[aGroupId] or sEmpty);
end



--
local tZone, tIndex, tMap, tMapId, tInfo;
function VUHDO_getUnitZoneName(aUnit)

	tInfo = VUHDO_RAID[aUnit];

	if not tInfo then
		return;
	end

	if "player" == aUnit or tInfo["visible"] then 
		tZone = GetRealZoneText();
	elseif VUHDO_GROUP_TYPE_RAID == VUHDO_getCurrentGroupType() then
		tIndex = (VUHDO_RAID[aUnit] or sEmpty)["number"] or 1;

		_, _, _, _, _, _, tZone = GetRaidRosterInfo(tIndex);
	else
		VuhDoScanTooltip:SetOwner(VuhDo, "ANCHOR_NONE");
		VuhDoScanTooltip:ClearLines();
		VuhDoScanTooltip:SetUnit(aUnit);

		if VuhDoScanTooltip:NumLines() > 2 then
			tZone = VuhDoScanTooltipTextLeft3:GetText();
		end

		if tZone and not issecretvalue(tZone) and tZone == "PvP" and VuhDoScanTooltip:NumLines() > 3 then
			tZone = VuhDoScanTooltipTextLeft4:GetText();
		end
	end

	-- 8.0.1 build 26567 added restrictions (must be in player's party) on which unit IDs can be queried
	tMapId = C_Map.GetBestMapForUnit(aUnit);

	if tMapId then
		tMap = C_Map.GetMapInfo(tMapId);
	end

	return tZone or (tMap and tMap["name"]) or VUHDO_I18N_UNKNOWN, tMap and tMap["name"] or nil;

end



--
local tName, tEnchant;
function VUHDO_getWeaponEnchantName(aSlot)
	VuhDoScanTooltip:SetOwner(VuhDo, "ANCHOR_NONE");
	VuhDoScanTooltip:ClearLines();
	VuhDoScanTooltip:SetInventoryItem("player", aSlot);
	for tCnt = 1, VuhDoScanTooltip:NumLines() do
		tName = strmatch(_G["VuhDoScanTooltipTextLeft" .. tCnt]:GetText(), "^.+ %(%d+%s+.+%)$");
		if tName then
			tEnchant = gsub(tName, " %(.+%)", "");
			return tEnchant;
		end
	end

	return "*";
end



--
function VUHDO_isInSameZone(aUnit)
	return (VUHDO_RAID[aUnit] or sEmpty)["zone"] == (VUHDO_RAID["player"] or sEmpty)["zone"];
end
local VUHDO_isInSameZone = VUHDO_isInSameZone;



--
function VUHDO_setUnitInfoHealthMax(anInfo, aHealthMax)

	if sSecretsEnabled and issecretvalue(aHealthMax) then
		anInfo["healthmax"] = aHealthMax;
		anInfo["hasSecretHealthMax"] = true;
	elseif type(aHealthMax) == "number" and aHealthMax > 0 then
		anInfo["healthmax"] = aHealthMax;
		anInfo["hasSecretHealthMax"] = false;
	else
		anInfo["healthmax"] = 0;
		anInfo["hasSecretHealthMax"] = false;
	end

	return;

end



-- Returns health of unit info in Percent
local tHealthMax;
local tPercent;
function VUHDO_getUnitHealthPercent(anInfo)

	if sSecretsEnabled and (anInfo["hasSecretHealth"] or anInfo["hasSecretHealthMax"]) then
		tPercent = UnitHealthPercent(anInfo["unit"], true, CurveConstants.ScaleTo100);

		if tPercent then
			return tPercent;
		end

		return 100;
	end

	tHealthMax = anInfo["healthmax"];

	return tHealthMax == 0 and 0
		or anInfo["health"] < tHealthMax and 100 * anInfo["health"] / tHealthMax or 100;

end



--
local tSpellId;
function VUHDO_isSpellKnown(aSpellName)

	if type(aSpellName) == "number" then
		if IsSpellInSpellBook then
			return IsSpellInSpellBook(aSpellName, SpellBookSpellBank.Player, true)
				or (IsSpellKnownNew and IsSpellKnownNew(aSpellName, SpellBookSpellBank.Player))
				or (SpellBookSpellBank.Pet and (IsSpellInSpellBook(aSpellName, SpellBookSpellBank.Pet, true) or (IsSpellKnownNew and IsSpellKnownNew(aSpellName, SpellBookSpellBank.Pet))))
				or VUHDO_isTalentKnown(aSpellName);
		else
			return IsSpellKnown(aSpellName)
				or IsSpellKnownOrOverridesKnown(aSpellName)
				or IsPlayerSpell(aSpellName)
				or VUHDO_isTalentKnown(aSpellName);
		end
	elseif type(aSpellName) ~= "number" then
		aSpellName = VUHDO_NAME_TO_SPELL[aSpellName] or aSpellName;

		_, _, _, _, _, _, tSpellId = VUHDO_getSpellInfo(aSpellName);

		if tSpellId then
			if IsSpellInSpellBook then
				return IsSpellInSpellBook(tSpellId, SpellBookSpellBank.Player, true)
					or (IsSpellKnownNew and IsSpellKnownNew(tSpellId, SpellBookSpellBank.Player));
			else
				return IsSpellKnownOrOverridesKnown(tSpellId) or IsSpellKnown(tSpellId) or IsPlayerSpell(tSpellId);
			end
		end
	end

	return false;

end


--
function VUHDO_initTalentSpellCaches()

	if InCombatLockdown() then
		-- avoid expensive malloc on talent re-scan during combat
		-- SPELLS_CHANGED handler calls this on spell morph e.g. Priest 'Premonition'
		return;
	end

	local tActiveConfigId = C_ClassTalents.GetActiveConfigID();

	-- on initial PLAYER_ENTER_WORLD talents are not yet available
	if not tActiveConfigId then
		return;
	end

	twipe(VUHDO_TALENT_CACHE_SPELL_ID);
	twipe(VUHDO_TALENT_CACHE_SPELL_NAME);

	local tConfigInfo = C_Traits.GetConfigInfo(tActiveConfigId);

	for _, tTreeId in pairs(tConfigInfo.treeIDs) do
		local tTreeNodes = C_Traits.GetTreeNodes(tTreeId);

		for _, tNodeId in pairs(tTreeNodes) do
			local tNodeInfo = C_Traits.GetNodeInfo(tActiveConfigId, tNodeId);

			if tNodeInfo and tNodeInfo.entryIDsWithCommittedRanks then
				for _, tEntryId in ipairs(tNodeInfo.entryIDsWithCommittedRanks) do
					local tEntryInfo = C_Traits.GetEntryInfo(tActiveConfigId, tEntryId);
				
					if tEntryInfo and tEntryInfo.definitionID then
						local tDefinitionInfo = C_Traits.GetDefinitionInfo(tEntryInfo.definitionID);

						if tDefinitionInfo and tDefinitionInfo.spellID then
							local tSpellName = GetSpellName(tDefinitionInfo.spellID);

							VUHDO_TALENT_CACHE_SPELL_ID[tDefinitionInfo.spellID] = tSpellName;
							VUHDO_TALENT_CACHE_SPELL_NAME[tSpellName] = tDefinitionInfo.spellID;
						end
					end
				end
			end
		end
	end

	return;

end



--
function VUHDO_getTalentSpellId(aTalentName)

	if type(aTalentName) == "number" then
		return VUHDO_TALENT_CACHE_SPELL_ID[aTalentName] and aTalentName or nil;
	else
		return VUHDO_TALENT_CACHE_SPELL_NAME[aTalentName] or nil;
	end

end



--
function VUHDO_isTalentKnown(aTalentName)
	return VUHDO_getTalentSpellId(aTalentName) and true or false;
end


--
local tDeltaSecs;
function VUHDO_getDurationTextSince(aStartTime)
	if not aStartTime then return ""; end

	tDeltaSecs = GetTime() - aStartTime;
	return tDeltaSecs >= 3600
		and format("(|cffffffff%.0f:%02d %s|r)", tDeltaSecs / 3600, floor(tDeltaSecs / 60) % 60, VUHDO_I18N_HOURS)
		or format("(|cffffffff%d:%02d %s|r)", tDeltaSecs / 60, tDeltaSecs % 60, VUHDO_I18N_MINS);
end



--
local tDistance;
function VUHDO_getDistanceText(aUnit)
	tDistance = VUHDO_getDistanceBetween("player", aUnit);
	return tDistance ~= nil and tDistance or "player" == aUnit and sZeroRange or VUHDO_I18N_UNKNOWN;
end



--
local sTargetUnits = { };
function VUHDO_getTargetUnit(aSourceUnit)
	if not sTargetUnits[aSourceUnit] then
		sTargetUnits[aSourceUnit] = "player" == aSourceUnit and "target" or aSourceUnit .. "target";
	end

	return sTargetUnits[aSourceUnit];
end



--
function VUHDO_isModelHiddenOnFlavor(aModelId)

	if aModelId >= VUHDO_ID_WARRIORS and aModelId <= VUHDO_ID_EVOKERS then
		return not VUHDO_flavorHasClass(aModelId);
	end

	return false;

end



--
function VUHDO_getActiveSpecSlot()

	if VUHDO_FLAVOR_SPEC_TALENT_GROUPS == VUHDO_getFlavorSpecModel() then
		return C_SpecializationInfo.GetActiveSpecGroup();
	end

	return C_SpecializationInfo.GetSpecialization();

end






--
local tResurrectionSpells;
local tKnownResurrectionSpells;
function VUHDO_getResurrectionSpells()
	tResurrectionSpells = (VUHDO_RESURRECTION_SPELLS[VUHDO_PLAYER_CLASS] or sEmpty)[VUHDO_getActiveSpecSlot() or 0];

	if tResurrectionSpells then
		tKnownResurrectionSpells = { };

		for _, tResurrectionSpell in ipairs(tResurrectionSpells) do
			if VUHDO_isSpellKnown(tResurrectionSpell) and IsUsableSpell(tResurrectionSpell) then
				tinsert(tKnownResurrectionSpells, tResurrectionSpell);
			end
		end

		return unpack(tKnownResurrectionSpells);
	else
		return nil;
	end
end



--
local tInfo;
function VUHDO_resolveVehicleUnit(aUnit)
	tInfo = VUHDO_RAID[aUnit] or sEmpty;
	return tInfo["isPet"] and (VUHDO_RAID[tInfo["ownerUnit"]] or sEmpty)["isVehicle"]
		and tInfo["ownerUnit"] or aUnit;
end



--
function VUHDO_getUnitButtons(aUnit)
	return VUHDO_UNIT_BUTTONS[aUnit];
end


function VUHDO_getUnitButtonsSafe(aUnit)
	return VUHDO_UNIT_BUTTONS[aUnit] or sEmpty;
end


--
function VUHDO_getUnitButtonsPanel(aUnit, aPanelNum)
	return (VUHDO_UNIT_BUTTONS_PANEL[aUnit] or sEmpty)[aPanelNum] or sEmpty;
end



--
local tInfo;
function VUHDO_shouldScanUnit(aUnit)

	tInfo = VUHDO_RAID[aUnit] or sEmpty;

	if not tInfo["connected"] or tInfo["dead"] then
		return true;
	elseif sScanRange == 1 then
		return VUHDO_isInSameZone(aUnit);
	elseif sScanRange == 2 then
		return tInfo["visible"];
	elseif sScanRange == 3 then
		if tInfo["hasSecretRange"] or (sSecretsEnabled and issecretvalue(tInfo["baseRange"])) then
			return true;
		end

		return tInfo["baseRange"];
	else
		return true;
	end

end



--
local tStringLen;
local tNumCut;
local tNumChars;
local tByte;
function VUHDO_utf8Cut(aString, aNumChars)

	if not aString or aNumChars <= 0 then
		return "";
	end

	tStringLen = #aString;

	if tStringLen == 0 then
		return "";
	end

	tNumCut = 1;
	tNumChars = 0;

	while tNumCut <= tStringLen and tNumChars < aNumChars do
		tByte = strbyte(aString, tNumCut);

		if tByte < 128 then
			tNumCut = tNumCut + 1;
		elseif tByte < 192 then
			tNumCut = tNumCut + 1;
		elseif tByte < 224 then
			if tNumCut + 1 <= tStringLen then
				tNumCut = tNumCut + 2;
			else
				break;
			end
		elseif tByte < 240 then
			if tNumCut + 2 <= tStringLen then
				tNumCut = tNumCut + 3;
			else
				break;
			end
		elseif tByte < 248 then
			if tNumCut + 3 <= tStringLen then
				tNumCut = tNumCut + 4;
			else
				break;
			end
		else
			tNumCut = tNumCut + 1;
		end

		tNumChars = tNumChars + 1;
	end

	return strsub(aString, 1, tNumCut - 1);

end



--
function VUHDO_strempty(aString)
	if (aString or "") ~= "" then
		for tCnt = 1, #aString do
			if strbyte(aString, tCnt) ~= 32 then return false; end
		end
	end

	return true;
end



--
function VUHDO_tableAddAllKeys(aDestTable, aTableToAdd)
	for tIndex, tValue in pairs(aTableToAdd) do
		aDestTable[tIndex] = tValue;
	end
end



-- Throttle resetting to current map to avoid conflicts with other addons
local tNextTime = 0;
local tMap;
function VUHDO_setMapToCurrentZone()
	if tNextTime < GetTime() then
		tMap = C_Map.GetBestMapForUnit("player");
		
		if tMap and WorldMapFrame ~= nil then
			WorldMapFrame:SetMapID(tMap);
		end

		tNextTime = GetTime() + 2;
	end
end
local VUHDO_setMapToCurrentZone = VUHDO_setMapToCurrentZone;



--
local tInfo;
function VUHDO_replaceMacroTemplates(aText, aUnit)

	if aUnit then
		aText = gsub(aText, "[Vv][Uu][Hh][Dd][Oo]", aUnit);

		tInfo = VUHDO_RAID[aUnit];

		if tInfo then
			if not tInfo["hasSecretIdentity"] then
				aText = gsub(aText, "[Vv][Dd][Nn][Aa][Mm][Ee]", VUHDO_getUnitExternalName(aUnit) or tInfo["name"] or "");
			end

			if tInfo["petUnit"] then
				aText = gsub(aText, "[Vv][Dd][Pp][Ee][Tt]", tInfo["petUnit"]);
			end

			if tInfo["targetUnit"] then
				aText = gsub(aText, "[Vv][Dd][Tt][Aa][Rr][Gg][Ee][Tt]", tInfo["targetUnit"]);
			end
		end
	end

	return aText;

end



--
local tActionLowerName;
local tIsMacroKnown;
local tIsSpellKnown; 
local tIsTalentKnown;
local tIsHostileAction, tIsFriendlyAction;
function VUHDO_isActionValid(anActionName, anIsCustom, anIsHostile)

	if (anActionName or "") == "" then
		return nil;
	end

	tIsHostileAction = false;
	tIsFriendlyAction = false;
	tActionLowerName = strlower(anActionName);

	if anIsHostile then
		if (VUHDO_SPELL_KEY_ASSIST == tActionLowerName
		 or VUHDO_SPELL_KEY_FOCUS == tActionLowerName
		 or VUHDO_SPELL_KEY_TARGET == tActionLowerName
		 or VUHDO_SPELL_KEY_EXTRAACTIONBUTTON == tActionLowerName
		 or VUHDO_SPELL_KEY_MOUSELOOK == tActionLowerName
		 or VUHDO_SPELL_KEY_PING == tActionLowerName) then
			tIsHostileAction = true;
		end
	else
		if VUHDO_SPELL_KEY_ASSIST == tActionLowerName
		 or VUHDO_SPELL_KEY_FOCUS == tActionLowerName
		 or VUHDO_SPELL_KEY_MENU == tActionLowerName
		 or VUHDO_SPELL_KEY_TELL == tActionLowerName
		 or VUHDO_SPELL_KEY_TARGET == tActionLowerName
		 or VUHDO_SPELL_KEY_EXTRAACTIONBUTTON == tActionLowerName
		 or VUHDO_SPELL_KEY_MOUSELOOK == tActionLowerName
		 or VUHDO_SPELL_KEY_PING == tActionLowerName
		 or VUHDO_SPELL_KEY_DROPDOWN == tActionLowerName then
			tIsFriendlyAction = true;
		end
	end

	tIsMacroKnown = GetMacroIndexByName(anActionName) ~= 0;

	if tIsHostileAction or tIsFriendlyAction then
		if tIsMacroKnown then
			VUHDO_Msg(format(VUHDO_I18N_AMBIGUOUS_MACRO, anActionName), 1, 0.3, 0.3);
			return VUHDO_I18N_WARNING, 1, 0.3, 0.3, "WRN";
		else
			return VUHDO_I18N_COMMAND, 0.8, 1, 0.8, "CMD";
		end
	end

	tIsSpellKnown = VUHDO_isSpellKnown(anActionName);

	if not tIsSpellKnown then
		tIsTalentKnown = VUHDO_isTalentKnown(anActionName);
	end

	if (tIsSpellKnown or tIsTalentKnown) and tIsMacroKnown then
		VUHDO_Msg(format(VUHDO_I18N_AMBIGUOUS_MACRO, anActionName), 1, 0.3, 0.3);
		return VUHDO_I18N_WARNING, 1, 0.3, 0.3, "WRN";
	elseif tIsMacroKnown then
		return VUHDO_I18N_MACRO, 0.8, 0.8, 1, "MCR";
	elseif (tIsSpellKnown or tIsTalentKnown) then
		return VUHDO_I18N_SPELL, 1, 0.8, 0.8, "SPL";
	elseif IsUsableItem(anActionName) then
		return VUHDO_I18N_ITEM, 1, 1, 0.8, "ITM";
	elseif anIsCustom then
		return "Custom", 0.9, 0.9, 0.2, "CUS";
	elseif tActionLowerName == "13" then
		return VUHDO_I18N_TRINKET_1, 1, 1, 0.8, "TKT1";
	elseif tActionLowerName == "14" then
		return VUHDO_I18N_TRINKET_2, 1, 1, 0.8, "TKT2";
	else
		return nil;
	end

end



--
function VUHDO_isAltPowerActive(aUnit)

	local tBarId = UnitPowerBarID(aUnit);
	local tBarInfo = GetUnitPowerBarInfoByID(tBarId);

	if tBarInfo then 
		return tBarInfo.barType and (not tBarInfo.hideFromOthers or "player" == aUnit);
	else
		return false;
	end

end



--
function VUHDO_decompressStringHuffman(aFile)
	return "string" == type(aFile) and VUHDO_LibCompress:DecompressHuffman(aFile) or aFile;
end



--
function VUHDO_compressStringHuffman(aFile)
	return "string" == type(aFile) and VUHDO_LibCompress:CompressHuffman(aFile) or aFile;
end



--
function VUHDO_decompressIfCompressed(aFile)
	return "string" == type(aFile) and VUHDO_deserializeTable(VUHDO_decompressStringHuffman(aFile)) or aFile;
end



--
function VUHDO_decompressOrCopy(aFile)
	return "string" == type(aFile) and VUHDO_deserializeTable(VUHDO_decompressStringHuffman(aFile)) or VUHDO_deepCopyTable(aFile);
end



--
function VUHDO_compressTable(aTable)
	return type(aTable) == "table" and VUHDO_serializeTable(aTable) or aTable;
end



--
function VUHDO_compressAndPackTable(aTable)
	return type(aTable) == "table" and VUHDO_compressStringHuffman(VUHDO_serializeTable(aTable)) or aTable;
end





--
function VUHDO_compressAllBouquets()
	for tName, _ in pairs(VUHDO_BOUQUETS["STORED"]) do
		VUHDO_BOUQUETS["STORED"][tName] = VUHDO_compressTable(VUHDO_BOUQUETS["STORED"][tName]);
	end
end



--
function VUHDO_decompressAllBouquets()
	for tName, _ in pairs(VUHDO_BOUQUETS["STORED"]) do
		VUHDO_BOUQUETS["STORED"][tName] = VUHDO_decompressIfCompressed(VUHDO_BOUQUETS["STORED"][tName]);
	end
end



--
local tPlayerX, tPlayerY;
local tUnitX, tUnitY;
local tFacing;
local tIsInInstance;
function VUHDO_getUnitDirection(aUnit)
	-- as of patch 7.1 GetPlayerFacing()/GetPlayerMapPosition() do not function inside instances
	tIsInInstance, _ = IsInInstance();

	if tIsInInstance or (WorldMapFrame ~= nil and WorldMapFrame:IsShown()) then
		return nil;
	end

	tPlayerX, tPlayerY = VUHDO_getUnitMapPosition("player");
	if (tPlayerX or 0) + (tPlayerY or 0) <= 0 then
		VUHDO_setMapToCurrentZone();
		tPlayerX, tPlayerY = VUHDO_getUnitMapPosition("player");
		if (tPlayerX or 0) + (tPlayerY or 0) <= 0 then return nil; end
	end

	tUnitX, tUnitY = VUHDO_getUnitMapPosition(aUnit);
	if (tUnitX or 0) + (tUnitY or 0) <= 0 then return nil; end

	tFacing = GetPlayerFacing() or 0;
	tFacing = tFacing < 0 and tFacing + VUHDO_2_PI or tFacing;

	return VUHDO_PI - VUHDO_atan2(tPlayerX - tUnitX, tUnitY - tPlayerY) - tFacing;
end
local VUHDO_getUnitDirection = VUHDO_getUnitDirection;



--
local tDirection;
local tConeFactor = 180 / VUHDO_PI;
function VUHDO_isInConeInFrontOf(aUnit, aDegrees)
	if aDegrees >= 360 or "player" == aUnit then return true; end
	tDirection = VUHDO_getUnitDirection(aUnit);

	if not tDirection then return false;
	elseif tDirection < 0 then tDirection = tDirection + VUHDO_2_PI; end

	return aDegrees * 0.5 >= 180 - abs(180 - tConeFactor * tDirection);
end



--
function VUHDO_forceBooleanValue(aRawValue)
	if aRawValue == nil or aRawValue == 0 or aRawValue == false then return false;
	else return true; end
end



function VUHDO_getCurrentKeyModifierString()
	return format("%s%s%s",
		IsAltKeyDown() and "alt" or "",
		IsControlKeyDown() and "ctrl" or "",
		IsShiftKeyDown() and "shift" or "");
end



-- Helper to serialize a table to a string for pretty printing
-- Taken from Lua Users Wiki: http://lua-users.org/wiki/TableUtils
function VUHDO_tableValueToString(v)
  if "string" == type( v ) then
    v = string.gsub( v, "\n", "\\n" )
    if string.match( string.gsub(v,"[^'\"]",""), '^"+$' ) then
      return "'" .. v .. "'"
    end
    return '"' .. string.gsub(v,'"', '\\"' ) .. '"'
  else
    return "table" == type( v ) and VUHDO_tableToString( v ) or
      tostring( v )
  end
end



function VUHDO_tableKeyToString(k)
  if "string" == type( k ) and string.match( k, "^[_%a][_%a%d]*$" ) then
    return k
  else
    return "[" .. VUHDO_tableValueToString( k ) .. "]"
  end
end



function VUHDO_tableToString(tbl)
  local result, done = {}, {}
  for k, v in ipairs( tbl ) do
    tinsert( result, VUHDO_tableValueToString( v ) )
    done[ k ] = true
  end
  for k, v in pairs( tbl ) do
    if not done[ k ] then
      tinsert( result,
        VUHDO_tableKeyToString( k ) .. "=" .. VUHDO_tableValueToString( v ) )
    end
  end
  return "{" .. table.concat( result, "," ) .. "}"
end



function VUHDO_isBossUnit(aUnit) 

	return VUHDO_BOSS_UNITS and VUHDO_BOSS_UNITS[aUnit];

end



function VUHDO_isSpecialUnit(aUnit)

	return aUnit == "focus" or aUnit == "target" or VUHDO_isBossUnit(aUnit);

end



function VUHDO_round(number, digits)

	if digits then
		local shift = 10 ^ digits;

		return floor(number * shift + 0.5) / shift;
	else
		return floor(number + 0.5);
	end

end



--
local function VUHDO_isSpellIdMatch(aMatchSpellId, _, _, _, _, _, _, _, _, _, _, _, aSpellId)

	return aMatchSpellId == aSpellId;

end



--
local tPoints;
function VUHDO_unpackAuraData(anAuraData)

	if not anAuraData then
		return nil;
	end

	tPoints = anAuraData.points;

	if tPoints and not issecrettable(tPoints) then
		return anAuraData.name,
			anAuraData.icon,
			anAuraData.applications,
			anAuraData.dispelName,
			anAuraData.duration,
			anAuraData.expirationTime,
			anAuraData.sourceUnit,
			anAuraData.isStealable,
			anAuraData.nameplateShowPersonal,
			anAuraData.spellId,
			anAuraData.canApplyAura,
			anAuraData.isBossAura,
			anAuraData.isFromPlayerOrPlayerPet,
			anAuraData.nameplateShowAll,
			anAuraData.timeMod,
			unpack(tPoints);
	else
		return anAuraData.name,
			anAuraData.icon,
			anAuraData.applications,
			anAuraData.dispelName,
			anAuraData.duration,
			anAuraData.expirationTime,
			anAuraData.sourceUnit,
			anAuraData.isStealable,
			anAuraData.nameplateShowPersonal,
			anAuraData.spellId,
			anAuraData.canApplyAura,
			anAuraData.isBossAura,
			anAuraData.isFromPlayerOrPlayerPet,
			anAuraData.nameplateShowAll,
			anAuraData.timeMod;
	end

end
local UnpackAuraData = VUHDO_unpackAuraData;



--
local tSpellId;
local tAuraData;
function VUHDO_unitAura(aUnit, aSpell, aFilter, anAllowSecret)

	if not anAllowSecret and VUHDO_isAuraDataRestricted() then
		return nil;
	end

	if not anAllowSecret and ShouldSpellAuraBeSecret(aSpell) then
		return nil;
	end

	if (aFilter == nil) then
		aFilter = "HELPFUL";
	end

	tSpellId = tonumber(aSpell);

	if tSpellId == nil then
		if GetAuraDataBySpellName then
			tAuraData = GetAuraDataBySpellName(aUnit, aSpell, aFilter);

			return UnpackAuraData(tAuraData);
		else
			return FindAuraByName(aSpell, aUnit, aFilter);
		end
	else
		if GetUnitAuraBySpellID then
			if UnitIsUnit(aUnit, "player") and GetPlayerAuraBySpellID then
				tAuraData = GetPlayerAuraBySpellID(tSpellId);
			else
				tAuraData = GetUnitAuraBySpellID(aUnit, tSpellId);
			end

			return UnpackAuraData(tAuraData);
		else
			return FindAura(VUHDO_isSpellIdMatch, aUnit, aFilter, tSpellId);
		end
	end

end



--
function VUHDO_unitBuff(aUnit, aSpell)

	return VUHDO_unitAura(aUnit, aSpell, "HELPFUL");

end



--
function VUHDO_unitBuffAllowSecret(aUnit, aSpell)

	if not aUnit or not aSpell then
		return;
	end

	return VUHDO_unitAura(aUnit, aSpell, "HELPFUL", true);

end



--
function VUHDO_unitDebuff(aUnit, aSpell)

	return VUHDO_unitAura(aUnit, aSpell, "HARMFUL");

end



--
local function VUHDO_packAuraDataHelper(aSpellName, anIcon, aCount, aDebuffType, aDuration, aExpirationTime, aSource, anIsStealable, aNameplateShowPersonal, aSpellId, aCanApplyAura, anIsBossDebuff, aNameplateShowAll, aTimeMod, ...)

	return aSpellName, anIcon, aCount, aDebuffType, aDuration, aExpirationTime, aSource, anIsStealable, aNameplateShowPersonal, aSpellId, aCanApplyAura, anIsBossDebuff, aNameplateShowAll, aTimeMod, { ... };

end



--
local function VUHDO_packAuraData(aSpellName, anIcon, aCount, aDebuffType, aDuration, aExpirationTime, aSource, anIsStealable, aNameplateShowPersonal, aSpellId, aCanApplyAura, anIsBossDebuff, aNameplateShowAll, aTimeMod, ...)

	local tAuraData = { };

	tAuraData.name,	tAuraData.icon,	tAuraData.applications,	tAuraData.dispelName, tAuraData.duration, tAuraData.expirationTime, tAuraData.sourceUnit,
		tAuraData.isStealable, tAuraData.nameplateShowPersonal, tAuraData.spellId, tAuraData.canApplyAura, tAuraData.isBossAura, 
		tAuraData.nameplateShowAll, tAuraData.timeMod, tAuraData.points = VUHDO_packAuraDataHelper(
			aSpellName, anIcon, aCount, aDebuffType, aDuration, aExpirationTime, aSource, anIsStealable, aNameplateShowPersonal, aSpellId, 
			aCanApplyAura, anIsBossDebuff, aNameplateShowAll, aTimeMod, ...);

	return tAuraData;

end



--
local function VUHDO_getAuraDataByIndex(aUnit, aIndex, aFilter)

	return VUHDO_packAuraData(UnitAura(aUnit, aIndex, aFilter));


end



--
local tMaxCnt;
local tSlot;
local tDone;
local tAuraInfo;
local function VUHDO_forEachAuraHelper(aUnit, aFilter, aPredicate, aUsePackedAura, aContinuationToken, ...)

	tMaxCnt = select('#', ...);

	for tCnt = 1, tMaxCnt do
		tSlot = select(tCnt, ...);

		tAuraInfo = GetAuraDataBySlot(aUnit, tSlot);

		if aUsePackedAura then
			tDone = aPredicate(tAuraInfo);
		else
			tDone = aPredicate(UnpackAuraData(tAuraInfo));
		end

		if tDone then
			return nil;
		end
	end

	return aContinuationToken;

end



--
local tContinuationToken;
local tDone;
function VUHDO_forEachAura(aUnit, aFilter, aMaxCnt, aPredicate, aUsePackedAura)

		if VUHDO_isAuraDataRestricted() then
			return;
		end

		if aMaxCnt and aMaxCnt <= 0 then
			return;
		end

		if GetAuraSlots then
			tContinuationToken = nil;

			repeat
				tContinuationToken = VUHDO_forEachAuraHelper(aUnit, aFilter, aPredicate, aUsePackedAura, 
					GetAuraSlots(aUnit, aFilter, aMaxCnt, tContinuationToken));
			until tContinuationToken == nil;
		else
			for tCnt = 1, (aMaxCnt or huge) do
				tAuraInfo = VUHDO_getAuraDataByIndex(aUnit, tCnt, aFilter);

				if not tAuraInfo.icon then
					return nil;
				end

				if aUsePackedAura then
					tDone = aPredicate(tAuraInfo);
				else
					tDone = aPredicate(UnpackAuraData(tAuraInfo));
				end

				if tDone then
					return nil;
				end
			end
		end

end



--
function VUHDO_playSoundFile(aSound)

	if (aSound and (aSound == "Interface\\Quiet.ogg" or aSound == "Interface\\Quiet.mp3")) then
		-- sweep and reset any sound settings referencing the old 'none' LSM default	
		for _, tDebuffInfo in pairs(VUHDO_CONFIG["CUSTOM_DEBUFF"]["STORED_SETTINGS"]) do
			if (tDebuffInfo["SOUND"] and 
				(tDebuffInfo["SOUND"] == "Interface\\Quiet.ogg" or 
					tDebuffInfo["SOUND"] == "Interface\\Quiet.mp3")) then
				tDebuffInfo["SOUND"] = nil;
			end
		end

		-- reset custom debuff default sound if set to old 'none' LSM default
		if (VUHDO_CONFIG["CUSTOM_DEBUFF"]["SOUND"] and 
			(VUHDO_CONFIG["CUSTOM_DEBUFF"]["SOUND"] == "Interface\\Quiet.ogg" or 
				VUHDO_CONFIG["CUSTOM_DEBUFF"]["SOUND"] == "Interface\\Quiet.mp3")) then
			VUHDO_CONFIG["CUSTOM_DEBUFF"]["SOUND"] = nil;
		end

		-- reset standard debuff sound if set to old 'none' LSM default
		if (VUHDO_CONFIG["SOUND_DEBUFF"] and 
		      (VUHDO_CONFIG["SOUND_DEBUFF"] == "Interface\\Quiet.ogg" or 
				VUHDO_CONFIG["SOUND_DEBUFF"] == "Interface\\Quiet.mp3")) then
			VUHDO_CONFIG["SOUND_DEBUFF"] = nil;
		end

		-- return success because we've played nothing as requested (eg. Quiet.ogg)
		return true;
	end

	local tSuccess, tError = pcall(PlaySoundFile, aSound);

	if not tSuccess then
		VUHDO_Msg(format(VUHDO_I18N_PLAY_SOUND_FILE_ERR, aSound, tError));
	end

	return tSuccess;

end



--
function VUHDO_argToString(aValue)

	if sSecretsEnabled and issecretvalue(aValue) then
		return "<secret>";
	end

	return tostring(aValue);

end



--
local tInfo;
local tSpellInRange;
local tUnitInRange;
local tUnitInRangeChecked;
local tInteractDistance;
local tResolvedRange;
local tRangeSpellName;
function VUHDO_formatRangeProbeValue(aValue)

	if aValue == nil then
		return "<nil>";
	elseif sSecretsEnabled and issecretvalue(aValue) then
		return "<secret>";
	elseif "boolean" == type(aValue) then
		return aValue and "<true>" or "<false>";
	else
		return tostring(aValue);
	end

end



--
function VUHDO_dumpRangeDiagnostics(aUnit)

	if not aUnit or not VUHDO_RAID or not VUHDO_RAID[aUnit] then
		VUHDO_Msg("Menzil tanılaması: birim Raid listesinde değil.");

		return;
	end

	tInfo = VUHDO_RAID[aUnit];
	tRangeSpellName = sRangeSpell and sRangeSpell["HELPFUL"];

	VUHDO_Msg(format("Range diagnostic for %s:", aUnit));
	VUHDO_Msg(format("  range=%s hasSecretRange=%s baseRange=%s isEventRange=%s",
		VUHDO_formatRangeProbeValue(tInfo["range"]),
		tostring(tInfo["hasSecretRange"]),
		VUHDO_formatRangeProbeValue(tInfo["baseRange"]),
		tostring(tInfo["isEventRange"])));

	if tRangeSpellName then
		tSpellInRange = IsSpellInRange(tRangeSpellName, aUnit);

		VUHDO_Msg(format("  IsSpellInRange(%s)=%s", tRangeSpellName, VUHDO_formatRangeProbeValue(tSpellInRange)));
	end

	tUnitInRange, tUnitInRangeChecked = UnitInRange(aUnit);

	VUHDO_Msg(format("  UnitInRange=%s checked=%s",
		VUHDO_formatRangeProbeValue(tUnitInRange),
		VUHDO_formatRangeProbeValue(tUnitInRangeChecked)));

	if not InCombatLockdown() then
		tInteractDistance = CheckInteractDistance(aUnit, 4);

		VUHDO_Msg(format("  CheckInteractDistance(4)=%s", VUHDO_formatRangeProbeValue(tInteractDistance)));
	else
		VUHDO_Msg("  CheckInteractDistance(4)=<skipped in combat>");
	end

	tResolvedRange = VUHDO_isInRange(aUnit, true);

	VUHDO_Msg(format("  VUHDO_isInRange(force)=%s", VUHDO_formatRangeProbeValue(tResolvedRange)));

	return;

end



--
function VUHDO_rangeHelp()

	VUHDO_Msg("|cffFFD100--- Menzil Komutları ---|r");
	VUHDO_Msg("  |cffB0E0E6/vd range [unit]|r - Bir birimin menzil durumunu ve API denetimlerini yazdırır (varsayılan: fare üstü)");
	VUHDO_Msg("  |cffB0E0E6/vd range|r - Bu yardımı gösterir");
	VUHDO_Msg("|cffFFD100--- Menzil Komutlarının Sonu ---|r");

	return;

end