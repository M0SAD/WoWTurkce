-- WoWTurkce çekirdek: ayarlar, şablonlar, parmak izi, kayıt, yazı tipleri, komutlar.
local ADDON = ...
WoWTurkce = WoWTurkce or {}
local G = WoWTurkce
G.ADDON = ADDON
G.SURUM = "0.11.9"

-- Çeviri tabloları (Translations/*/*.lua dosyaları doldurur)
G.Veri = G.Veri or {}          -- görevler: [questID] = { b, h, a, i, t, k }
G.VeriEk = G.VeriEk or {}
G.GorevMetni = G.GorevMetni or {} -- kimliksiz görev metinleri: [parmak izi] = Türkçe      -- sonraki sürümlerde (TBC...) metni değişen görevlerin ek çevirisi, aynı yapı
G.Esya = G.Esya or {}          -- ipucu satırı şablonları: ["# Armor"] = "{1} Zırh"
G.Buyu = G.Buyu or {}          -- büyü açıklama şablonları
G.Hata = G.Hata or {}          -- hata mesajları
G.HataDesen = G.HataDesen or {} -- isim içeren hata/bilgi mesajı desenleri
G.Secenek = G.Secenek or {}    -- NPC konuşma seçenekleri
G.Konusma = G.Konusma or {}    -- NPC selamlama metinleri: [iz] = "Türkçe"
G.BuyuAdi = G.BuyuAdi or {}    -- büyü adları
G.BuyuSekme = G.BuyuSekme or {} -- büyü kitabı sekmeleri
G.GorevAdi = G.GorevAdi or {}  -- İngilizce görev adı -> Türkçe
G.Egitim = G.Egitim or {}
G.Arayuz = G.Arayuz or {}      -- genel arayüz yazıları      -- İpucu (tutorial) pencereleri
G.Yaratik = G.Yaratik or {}    -- yaratık (mob) adları: ["Mottled Boar"] = "Benekli Yaban Domuzu"
G.EsyaAdi = G.EsyaAdi or {}    -- eşya adları: ["Forest Mushroom Cap"] = "Orman Mantarı"
G.NpcUnvan = G.NpcUnvan or {}  -- NPC unvanları: ["Deathguard"] = "Ölüm Muhafızı"
G.NpcLakap = G.NpcLakap or {}  -- "X the Y" lakapları: ["Purifier"] = "Arındırıcı"
G.BuyuAlt = G.BuyuAlt or {}    -- Passive, Racial...
G.Kitap = G.Kitap or {}        -- kitap/mektup sayfaları: [iz] = "Türkçe"
G.KitapAdi = G.KitapAdi or {}  -- kitap başlıkları
G.NpcAltBaslik = G.NpcAltBaslik or {}     -- NPC alt başlıkları: ["Apprentice Weaponsmith"] = "Çırak Silah Ustası"
G.NpcAltBaslikId = G.NpcAltBaslikId or {} -- [npcID] = İngilizce alt başlık (Questie için)
G.EsyaId = G.EsyaId or {}                 -- [eşyaID] = İngilizce ad (görev eşyaları, Questie için)
G.Altyazi = G.Altyazi or {}               -- sinematik altyazıları: [iz] = "Türkçe"
G.Nesne = G.Nesne or {}                   -- etkileşimli nesne adları
G.NesneId = G.NesneId or {}               -- [nesneID] = İngilizce ad (Questie için)
G.Soz = G.Soz or {}            -- NPC sözleri (say/yell/emote): [iz] = "Türkçe"

local YOL = "Interface\\AddOns\\" .. ADDON .. "\\Fonts\\"
G.FONT_METIN = YOL .. "Metin.ttf"
G.FONT_BASLIK = YOL .. "Baslik.ttf"
G.FONT_ARAYUZ = YOL .. "Arayuz.ttf"

-- Oyun sürümü: Classic Era / Forever / Retail (normal). Aynı dosyalar hepsinde çalışır.
G.RETAIL = WOW_PROJECT_ID ~= nil and WOW_PROJECT_MAINLINE ~= nil and WOW_PROJECT_ID == WOW_PROJECT_MAINLINE
G.KLASIK = not G.RETAIL
-- Classic Forever (arayüz 16xxx): Forever'a özel görev numaraları Retail'de başka görevlere ait olabilir
do local _, _, _, arayuz = GetBuildInfo(); G.FOREVER = type(arayuz) == "number" and arayuz >= 16000 and arayuz < 20000 end
-- Retail 12.x: savaşta bazı yazılar "gizli değer" olarak gelir; bunlara dokunmayız
-- Not: gizli değer nil ile bile karşılaştırılamaz (v ~= nil hata verir); doğrudan issecretvalue'ya ver
function G.gizli(v) if issecretvalue then return issecretvalue(v) == true end return false end

-- Oyuncu adları asla çevrilmez ("Enrage" adlı oyuncu "Öfkelenme" olmasın)
G.OyuncuAdi = {}
function G.oyuncuEkle(birim)
	if not birim or not UnitExists or not UnitExists(birim) or not UnitIsPlayer or not UnitIsPlayer(birim) then return end
	local ok, ad = pcall(UnitName, birim)
	if ok and ad and not G.gizli(ad) and ad ~= "" then G.OyuncuAdi[ad] = true end
end
function G.oyuncuMu(s)
	if type(s) ~= "string" or G.gizli(s) then return false end
	local saf = s:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", ""):gsub("%-.*$", "")
	return G.OyuncuAdi[saf] == true
end
do
	local f = CreateFrame("Frame")
	for _, e in ipairs({ "PLAYER_LOGIN", "PLAYER_TARGET_CHANGED", "UPDATE_MOUSEOVER_UNIT", "GROUP_ROSTER_UPDATE", "NAME_PLATE_UNIT_ADDED", "PLAYER_FOCUS_CHANGED" }) do pcall(f.RegisterEvent, f, e) end
	f:SetScript("OnEvent", function(_, e, birim)
		pcall(function()
			G.oyuncuEkle("player")
			if e == "NAME_PLATE_UNIT_ADDED" then G.oyuncuEkle(birim)
			elseif e == "PLAYER_TARGET_CHANGED" then G.oyuncuEkle("target"); G.oyuncuEkle("targettarget")
			elseif e == "UPDATE_MOUSEOVER_UNIT" then G.oyuncuEkle("mouseover")
			elseif e == "PLAYER_FOCUS_CHANGED" then G.oyuncuEkle("focus")
			else
				for i = 1, 4 do G.oyuncuEkle("party" .. i) end
				for i = 1, 40 do G.oyuncuEkle("raid" .. i) end
			end
		end)
	end)
end

-- Oyuncu ve lonca adları asla çevrilmez ("Door" adlı oyuncu "Kapı" olmasın).
-- Arkadaş, lonca, kim listesi ve sohbetten gelen adları da bilinen oyuncular listesine ekle.
G.LoncaAdi = G.LoncaAdi or {}
local function adEkle(ad)
	if type(ad) ~= "string" or ad == "" or G.gizli(ad) then return end
	ad = ad:gsub("%-.*$", "")
	if ad ~= "" then G.OyuncuAdi[ad] = true end
end
G.adEkle = adEkle
local function loncaEkle(ad) if type(ad) == "string" and ad ~= "" and not G.gizli(ad) then G.LoncaAdi[ad] = true end end
local function listeleriTopla()
	if C_FriendList then
		local n = C_FriendList.GetNumFriends and C_FriendList.GetNumFriends() or 0
		for i = 1, n do local info = C_FriendList.GetFriendInfoByIndex(i); if info then adEkle(info.name) end end
		local k = C_FriendList.GetNumIgnores and C_FriendList.GetNumIgnores() or 0
		for i = 1, k do adEkle(C_FriendList.GetIgnoreName and C_FriendList.GetIgnoreName(i)) end
		local w = C_FriendList.GetNumWhoResults and C_FriendList.GetNumWhoResults() or 0
		for i = 1, w do local info = C_FriendList.GetWhoInfo(i); if info then adEkle(info.fullName); loncaEkle(info.fullGuildName) end end
	end
	if BNGetNumFriends and C_BattleNet and C_BattleNet.GetFriendAccountInfo then
		for i = 1, (BNGetNumFriends() or 0) do
			local a = C_BattleNet.GetFriendAccountInfo(i)
			local g = a and a.gameAccountInfo
			if g then adEkle(g.characterName) end
			if a then adEkle(a.accountName); adEkle(a.battleTag and a.battleTag:gsub("#.*$", "")) end
		end
	end
	if GetNumGuildMembers and GetGuildRosterInfo then
		for i = 1, (GetNumGuildMembers() or 0) do adEkle((GetGuildRosterInfo(i))) end
	end
	if GetGuildInfo then loncaEkle((GetGuildInfo("player"))) end
end
do
	local f = CreateFrame("Frame")
	for _, e in ipairs({ "PLAYER_LOGIN", "FRIENDLIST_UPDATE", "GUILD_ROSTER_UPDATE", "WHO_LIST_UPDATE", "BN_FRIEND_INFO_CHANGED",
		"BN_FRIEND_LIST_SIZE_CHANGED", "IGNORELIST_UPDATE" }) do pcall(f.RegisterEvent, f, e) end
	f:SetScript("OnEvent", function() pcall(listeleriTopla) end)
	-- Sohbette yazan oyuncular
	local s = CreateFrame("Frame")
	for _, e in ipairs({ "CHAT_MSG_SAY", "CHAT_MSG_YELL", "CHAT_MSG_PARTY", "CHAT_MSG_PARTY_LEADER", "CHAT_MSG_RAID", "CHAT_MSG_RAID_LEADER",
		"CHAT_MSG_GUILD", "CHAT_MSG_OFFICER", "CHAT_MSG_WHISPER", "CHAT_MSG_WHISPER_INFORM", "CHAT_MSG_CHANNEL", "CHAT_MSG_EMOTE",
		"CHAT_MSG_INSTANCE_CHAT", "CHAT_MSG_INSTANCE_CHAT_LEADER" }) do pcall(s.RegisterEvent, s, e) end
	s:SetScript("OnEvent", function(_, _, _, yazan) pcall(adEkle, yazan) end)
end
local eskiOyuncuMu = G.oyuncuMu
function G.oyuncuMu(s)
	if eskiOyuncuMu(s) then return true end
	if type(s) ~= "string" or G.gizli(s) then return false end
	local saf = s:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", "")
	saf = saf:gsub("^%s+", ""):gsub("%s+$", "")
	return G.LoncaAdi[saf] == true or G.OyuncuAdi[(saf:gsub("%-.*$", ""))] == true
end

local RENK = "|cff33ff99WoWTurkce|r: "
function G.yaz(msg) DEFAULT_CHAT_FRAME:AddMessage(RENK .. msg) end

---------------------------------------------------------------------------
-- Ayarlar
---------------------------------------------------------------------------
G.VARSAYILAN = {
	acik = true,       -- genel aç/kapat
	gorev = true,      -- görev metinleri
	ipucu = true,      -- eşya ipuçları
	buyu = true,       -- büyü / yetenek açıklamaları
	buyuadi = true,    -- büyü kitabında ve ipucunda büyü adları
	hata = true,       -- kırmızı hata mesajları
	konusma = true,    -- NPC konuşmaları
	egitim = true,     -- oyun ipucu (tutorial) pencereleri
	arayuz = true,     -- ayarlar, karakter penceresi vb. genel arayüz
	yaratik = false,   -- yaratık (mob) adları ve görev metinlerindeki ad değişimi
	npc = false,       -- NPC unvan ve lakapları (Deathguard -> Ölüm Muhafızı)
	font = true,       -- görev penceresinde Türkçe yazı tipi
	genelfont = true,  -- tüm arayüzde Türkçe karakter destekli yazı tipi
	kayit = true,      -- çevirisiz metinleri kaydet
	minimap = true,    -- minimap düğmesi
	kitap = true,      -- kitap, mektup ve not sayfaları
	altyazi = true,    -- sinematik ve film altyazıları
	balon = true,      -- NPC sözleri (sohbet ve konuşma balonları)
	tamir = false,     -- satıcıda otomatik tamir
	hurda = false,     -- satıcıda gri eşyaları otomatik sat
	shiftEn = true,    -- Shift basılı tutulunca her şeyi geçici olarak İngilizce göster
	stilEsya = "trEn",    -- eşya adı yazımı: "trEn" Türkçe (English), "enTr" English (Türkçe), "tr", "en"
	stilBuyu = "trEn",    -- büyü ve yetenek adı yazımı
	stilYaratik = "enTr", -- yaratık adı yazımı
	sohbetDil = "ikisi", -- sohbette çevrilen adlar: "ikisi" = Türkçe (İngilizce), "tr" = sadece Türkçe, "en" = sadece İngilizce
}

function G.ayar(k)
	if k == "acik" and G._shiftEn then return false end
	if WoWTurkce_Ayar == nil or WoWTurkce_Ayar[k] == nil then return G.VARSAYILAN[k] end
	return WoWTurkce_Ayar[k]
end

-- Ad yazım tarzı: anahtar = stilEsya | stilBuyu | stilYaratik
local tersAd = {}
local function tersBul(anahtar, tr)
	local kaynak = (anahtar == "stilBuyu" and G.BuyuAdi) or (anahtar == "stilEsya" and G.EsyaAdi) or nil
	if not kaynak then return nil end
	local t = tersAd[anahtar]
	if not t then
		t = {}
		for k, v in pairs(kaynak) do
			if type(k) == "string" and type(v) == "string" and k ~= v and t[v] == nil then t[v] = k end
		end
		tersAd[anahtar] = t
	end
	return t[tr]
end
local function adSade(x) return (x:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", ""):gsub("%s+", " "):gsub("^ ", ""):gsub(" $", "")) end
function G.adStil(anahtar, tr, en, renk)
	renk = renk or "|cff888888"
	local d = G.ayar(anahtar)
	-- İngilizce diye gelen yazı aslında Türkçeyse (oyun adı zaten çevrilmişse) gerçek İngilizcesini tersten bul
	if tr and tr ~= "" and en and en ~= "" and (adSade(tr) == adSade(en) or G.turkceMi(en)) then
		local gercek = tersBul(anahtar, adSade(tr))
		if gercek then en = gercek else return tr end
	end
	if not tr or tr == "" or not en or en == "" or tr == en then return tr or en end
	if d == "en" then return en elseif d == "tr" then return tr
	elseif d == "enTr" then return en .. " " .. renk .. "(" .. tr .. ")|r" end
	return tr .. " " .. renk .. "(" .. en .. ")|r"
end
local STIL_AD = { trEn = "Türkçe (English)", enTr = "English (Türkçe)", tr = "Sadece Türkçe", en = "Sadece English" }
local STIL_SIRA = { trEn = "enTr", enTr = "tr", tr = "en", en = "trEn" }
function G.stilAdi(anahtar) return STIL_AD[G.ayar(anahtar)] or STIL_AD.trEn end
function G.stilSonraki(anahtar) G.ayarla(anahtar, STIL_SIRA[G.ayar(anahtar)] or "enTr") end

function G.ayarla(k, v)
	WoWTurkce_Ayar = WoWTurkce_Ayar or {}
	WoWTurkce_Ayar[k] = v
	for _, f in ipairs(G.dinleyiciler) do f(k, v) end
end

-- Bir modül açık mı? (genel anahtar da açık olmalı)
function G.modul(k) return G.ayar("acik") and G.ayar(k) end

G.dinleyiciler = {}
function G.dinle(f) G.dinleyiciler[#G.dinleyiciler + 1] = f end

---------------------------------------------------------------------------
-- Yer tutucular: $N isim, $C sınıf, $R ırk, $Gerkek:kadın;
---------------------------------------------------------------------------
-- Türkçe metinlerde sınıf adı ($C büyük harfle, $c küçük harfle)
G.SINIF_TR = {} -- sınıf adları İngilizce kalır (kullanıcı tercihi)
---------------------------------------------------------------------------
-- Görev metinlerindeki İngilizce yaratık ve eşya adlarını Türkçeleriyle değiştir.
-- "Scavenger Paw'e" gibi eklerde ses uyumunu yeni ada göre düzeltir.
local adListe
local function adListesi()
	if adListe then return adListe end
	adListe = {}
	for _, t in ipairs({ G.Yaratik, G.EsyaAdi, G.ZindanAdi or {} }) do
		for en, tr in pairs(t) do
			if type(tr) == "string" and #en >= 3 and en:find("^%u") then adListe[#adListe + 1] = { en, tr } end
		end
	end
	table.sort(adListe, function(a, b) return #a[1] > #b[1] end)
	return adListe
end
local UNLU = { a="a", e="e", ["ı"]="ı", i="i", o="o", ["ö"]="ö", u="u", ["ü"]="ü", A="a", E="e", I="ı", ["İ"]="i", O="o", ["Ö"]="ö", U="u", ["Ü"]="ü" }
local function sonUnlu(s)
	local v
	for ch in s:gmatch("[%z\1-\127\194-\244][\128-\191]*") do if UNLU[ch] then v = UNLU[ch] end end
	return v or "e"
end
local KALIN = { ["a"] = true, ["ı"] = true, ["o"] = true, ["u"] = true, ["I"] = true }
local YUVARLAK = { ["o"] = true, ["ö"] = true, ["u"] = true, ["ü"] = true }
local function ekUyumla(ad, ek)
	local v = sonUnlu(ad)
	local kalin, yuv = KALIN[v], YUVARLAK[v]
	local son = ad:sub(-2)
	local unluBiter = ad:find("[aeiou]$") or son == "ı" or son == "ö" or son == "ü"
	local sert = ad:find("[fstkhp]$") or son == "ç" or son == "ş"
	-- "Pençesi", "Kanadı" gibi tamlamalar: kaynaştırma harfi n
	local tamlama = ad:find(" ") and (ad:find("[iu]$") or son == "ı" or son == "ü")
	local I = kalin and (yuv and "u" or "ı") or (yuv and "ü" or "i")
	local A = kalin and "a" or "e"
	local y = unluBiter and (tamlama and "n" or "y") or ""
	local k = ek:gsub("ı", "i"):gsub("ü", "u"):gsub("ö", "o"):gsub("İ", "i"):lower()
	if k:find("^l[ae]r") then
		local kalan = k:sub(4):gsub("[iu]", kalin and "ı" or "i"):gsub("[ae]", A)
		return "l" .. A .. "r" .. kalan
	end
	if k:find("^n?[iu]n$") then return (unluBiter and "n" or "") .. I .. "n" end
	if k:find("^n?[dt][ea]n$") then return (tamlama and "n" or "") .. (sert and "t" or "d") .. A .. "n" end
	if k:find("^n?[dt][ea]$") then return (tamlama and "n" or "") .. (sert and "t" or "d") .. A end
	if k:find("^y?l[ea]$") then return (unluBiter and "y" or "") .. "l" .. A end
	if k:find("^[yn]?[ea]$") then return y .. A end
	if k:find("^[yn]?[iu]$") then return y .. I end
	return ek
end
-- NPC adı: unvan çevrilir, kişisel ad kalır. Ayardan bağımsız (ipucundaki gri parantez için de kullanılır)
local unvanSirali
local function unvanlar()
	if unvanSirali then return unvanSirali end
	unvanSirali = {}
	for en, tr in pairs(G.NpcUnvan) do unvanSirali[#unvanSirali + 1] = { en, tr } end
	table.sort(unvanSirali, function(a, b) return #a[1] > #b[1] end)
	return unvanSirali
end
G.npcUnvanlar = unvanlar
G.ekUyumla = ekUyumla
function G.npcAdTr(ad)
	if not ad or ad == "" or G.Yaratik[ad] then return nil end
	-- Zaten çevrilmiş/parantezli ya da Türkçe karakterli metinleri tekrar işleme (sonsuz ekleme olmasın)
	if ad:find("[%(%)|]") or G.turkceMi(ad) then return nil end
	local kisi, lakap = ad:match("^(.-) the (.+)$")
	if kisi and G.NpcLakap[lakap] then
		local ktr = G.npcAdTr(kisi)
		return G.NpcLakap[lakap] .. " " .. (ktr or kisi)
	end
	for _, p in ipairs(unvanlar()) do
		local en = p[1]
		if ad:sub(1, #en + 1) == en .. " " then
			local kalan = ad:sub(#en + 2)
			if kalan:find("^%u") then return p[2] .. " " .. kalan end
		end
	end
end
-- Ayara göre: yaratık adı ya da NPC adı (açık değilse nil)
function G.yaratikCevir(ad)
	if not ad then return nil end
	if G.modul("yaratik") and G.Yaratik[ad] then return G.Yaratik[ad] end
	if G.modul("npc") then return G.npcAdTr(ad) end
end
-- Ayardan bağımsız Türkçe ad (ipucunda gri parantez için)
function G.adTr(ad)
	return ad and (G.Yaratik[ad] or G.npcAdTr(ad))
end
-- Yaratık adları kapalıyken eşya adlarında mob kısmı İngilizce kalır, gerisi çevrilir:
-- "Scavenger Paw" -> "Scavenger Pençesi", "Duskbat Wing" -> "Duskbat Kanadı"
local GENEL_HAYVAN = {}
for _, k in ipairs({ "Wolf", "Boar", "Bear", "Spider", "Crab", "Bat", "Cat", "Tiger", "Gorilla", "Lion", "Panther",
	"Snake", "Turtle", "Hyena", "Vulture", "Condor", "Owl", "Stag", "Deer", "Rabbit", "Rat", "Skeleton", "Zombie",
	"Ghoul", "Elemental", "Lizard", "Shark", "Raptor", "Crocolisk", "Scorpid", "Ooze", "Fox", "Hawk", "Eagle",
	"Ram", "Goat", "Cow", "Sheep", "Pig", "Chicken", "Frog", "Squirrel", "Spirit", "Ghost", "Imp" }) do GENEL_HAYVAN[k] = true end
-- Sadece yaratıktan düşen parça eşyalarında (pati, kanat, diş...) melez ad kullan
local PARCA = {}
for _, k in ipairs({ "Paw", "Wing", "Tail", "Flank", "Blood", "Femur", "Feather", "Heart", "Meat", "Fur", "Claw",
	"Fang", "Tusk", "Hide", "Skin", "Scale", "Eye", "Ear", "Horn", "Snout", "Leg", "Tooth", "Teeth", "Mane", "Hoof",
	"Rib", "Bone", "Skull", "Head", "Venom", "Gland", "Pelt", "Talon", "Beak", "Egg", "Mandible", "Carapace", "Chitin",
	"Stinger", "Shell", "Liver", "Tongue", "Brain", "Ichor", "Spine", "Fin", "Flipper", "Sac", "Silk", "Gizzard",
	"Kidney", "Haunch", "Steak", "Shank", "Ribs", "Tendon", "Sinew", "Antler", "Quill", "Plume", "Ectoplasm", "Dust",
	"Essence", "Husk", "Leather", "Flesh", "Mucus", "Slime", "Gut", "Guts", "Lung", "Spleen", "Bile", "Pincer" }) do
	PARCA[k] = true
end
local function kelimeler(s) local t = {}; for w in s:gmatch("%S+") do t[#t + 1] = w end; return t end
local yaratikEk
local function yaratikEkleri()
	if yaratikEk then return yaratikEk end
	yaratikEk = {}
	for en, tr in pairs(G.Yaratik) do
		local ew, tw = kelimeler(en), kelimeler(tr)
		for k = 1, #ew do
			local suf = table.concat(ew, " ", #ew - k + 1)
			if not (k == 1 and GENEL_HAYVAN[suf]) and not yaratikEk[suf] then
				yaratikEk[suf] = (#tw >= k) and table.concat(tw, " ", #tw - k + 1) or tr
			end
		end
	end
	return yaratikEk
end
local melezOnbellek = {}
function G.melezEsya(en)
	local m = melezOnbellek[en]
	if m ~= nil then return m or nil end
	local tr = G.EsyaAdi[en]
	m = false
	local son = en:match("(%a+)$")
	if son and not PARCA[son] and not PARCA[(son:gsub("e?s$", ""))] then tr = nil end
	if tr then
		local ek, ew, tw = yaratikEkleri(), kelimeler(en), kelimeler(tr)
		for k = math.min(3, #ew - 1), 1, -1 do
			local on = table.concat(ew, " ", 1, k)
			local ytr = ek[on]
			if ytr then
				local yw = kelimeler(ytr)
				local uyar = #tw > #yw
				for i = 1, #yw do
					if not uyar then break end
					if i < #yw then uyar = tw[i] == yw[i] else uyar = tw[i]:sub(1, #yw[i]) == yw[i] end
				end
				local kuyruk
				if uyar then kuyruk = table.concat(tw, " ", #yw + 1)
				else
					local r = #ew - k
					if #tw > r then kuyruk = table.concat(tw, " ", #tw - r + 1) end
				end
				if kuyruk and kuyruk ~= "" then m = on .. " " .. kuyruk end
				break
			end
		end
	end
	melezOnbellek[en] = m
	return m or nil
end
-- Sözlükte olmayan parça eşyaları: "Murloc Fin" -> "Murloc Yüzgeci", "Bloodscalp Tusks" -> "Bloodscalp Dişleri"
local PARCA_TR = {
	Paw = "Pençesi", Paws = "Pençeleri", Wing = "Kanadı", Wings = "Kanatları", Tail = "Kuyruğu", Tails = "Kuyrukları",
	Fang = "Dişi", Fangs = "Dişleri", Tusk = "Dişi", Tusks = "Dişleri", Tooth = "Dişi", Teeth = "Dişleri",
	Hide = "Postu", Hides = "Postları", Pelt = "Postu", Pelts = "Postları", Skin = "Derisi", Skins = "Derileri",
	Scale = "Pulu", Scales = "Pulları", Eye = "Gözü", Eyes = "Gözleri", Ear = "Kulağı", Ears = "Kulakları",
	Horn = "Boynuzu", Horns = "Boynuzları", Heart = "Kalbi", Hearts = "Kalpleri", Meat = "Eti", Fur = "Kürkü",
	Claw = "Pençesi", Claws = "Pençeleri", Talon = "Pençesi", Talons = "Pençeleri", Feather = "Tüyü", Feathers = "Tüyleri",
	Blood = "Kanı", Bone = "Kemiği", Bones = "Kemikleri", Skull = "Kafatası", Skulls = "Kafatasları", Head = "Kafası",
	Snout = "Burnu", Snouts = "Burunları", Leg = "Bacağı", Legs = "Bacakları", Fin = "Yüzgeci", Fins = "Yüzgeçleri",
	Rib = "Kaburgası", Ribs = "Kaburgaları", Beak = "Gagası", Egg = "Yumurtası", Eggs = "Yumurtaları", Mane = "Yelesi",
	Venom = "Zehri", Gland = "Bezi", Glands = "Bezleri", Stinger = "İğnesi", Stingers = "İğneleri", Shell = "Kabuğu",
	Carapace = "Kabuğu", Mandible = "Çenesi", Mandibles = "Çeneleri", Liver = "Ciğeri", Tongue = "Dili", Brain = "Beyni",
	Brains = "Beyinleri", Flank = "Butu", Flanks = "Butları", Ichor = "İrini", Silk = "İpeği", Hoof = "Toynağı", Hooves = "Toynakları",
	Spine = "Dikeni", Spines = "Dikenleri", Antler = "Boynuzu", Antlers = "Boynuzları", Quill = "Okluğu", Quills = "Oklukları",
	Haunch = "Budu", Gizzard = "Taşlığı", Ectoplasm = "Ektoplazması", Essence = "Özü", Sinew = "Siniri",
}
local yaratikKelime
function G.parcaMelez(en)
	local on, son = en:match("^(.+) (%a+)$")
	local str = son and PARCA_TR[son]
	if not str then return nil end
	if not yaratikKelime then
		yaratikKelime = {}
		for k in pairs(G.Yaratik) do for w in k:gmatch("%S+") do yaratikKelime[w] = true end end
	end
	if GENEL_HAYVAN[on] then return nil end -- tek başına "Wolf Fang" gibi genel hayvan adları
	for w in on:gmatch("%S+") do
		if not yaratikKelime[w] then return nil end
	end
	return on .. " " .. str
end
-- Ekranda gösterilecek eşya adı (ayara göre tam Türkçe ya da melez)
function G.esyaAdiGoster(en)
	local tr = G.EsyaAdi[en]
	if not tr then return G.parcaMelez(en) end
	if G.modul("yaratik") then return tr end
	return G.melezEsya(en) or tr
end
local melezListe
local function melezListesi()
	if melezListe then return melezListe end
	melezListe = {}
	for en, tr in pairs(G.EsyaAdi) do
		local m = G.melezEsya(en)
		if m and m ~= tr then melezListe[#melezListe + 1] = { tr, m } end
	end
	table.sort(melezListe, function(a, b) return #a[1] > #b[1] end)
	return melezListe
end

local function npcMetinCevir(s)
	if not G.modul("npc") then return s end
	for _, p in ipairs(unvanlar()) do
		local en = p[1]
		if s:find(en .. " ", 1, true) then
			s = s:gsub("%f[%w]" .. en:gsub("(%W)", "%%%1") .. " (%u)", (p[2]:gsub("%%", "%%%%")) .. " %1")
		end
	end
	s = s:gsub("(%u[%w']+) the (%u%a+)", function(kisi, lakap)
		local l = G.NpcLakap[lakap]
		if l then return l .. " " .. kisi end
	end)
	return s
end
-- Görev metinlerindeki büyü adları ("Lesser Heal (Rank 2)" -> "Küçük İyileştirme (Rütbe 2)")
local buyuListe
local function buyuMetinCevir(s)
	if not buyuListe then
		buyuListe = {}
		for en, tr in pairs(G.BuyuAdi) do
			if type(tr) == "string" and #en >= 6 and en:find("[ :]") and tr ~= en then buyuListe[#buyuListe + 1] = { en, tr } end
		end
		table.sort(buyuListe, function(a, b) return #a[1] > #b[1] end)
	end
	for _, p in ipairs(buyuListe) do
		if s:find(p[1], 1, true) then
			s = s:gsub("%f[%w]" .. p[1]:gsub("(%W)", "%%%1") .. "%f[^%w]", (p[2]:gsub("%%", "%%%%")))
		end
	end
	s = s:gsub("%(Rank (%d+)%)", "(Rütbe %1)")
	return s
end
G.buyuMetinCevir = buyuMetinCevir

function G.adCevir(s)
	if not s or s == "" then return s end
	s = npcMetinCevir(s)
	if G.modul("buyuadi") then s = buyuMetinCevir(s) end
	if not G.modul("yaratik") then
		-- Görev metinlerindeki tam Türkçe eşya adlarını melez hale getir
		for _, p in ipairs(melezListesi()) do
			if s:find(p[1], 1, true) then
				s = s:gsub(p[1]:gsub("(%W)", "%%%1"), (p[2]:gsub("%%", "%%%%")))
			end
		end
		return s
	end
	for _, p in ipairs(adListesi()) do
		local en, tr = p[1], p[2]
		if s:find(en, 1, true) then
			local kalip = "%f[%w]" .. en:gsub("(%W)", "%%%1")
			s = s:gsub(kalip .. "e?s?'([%a\195\196\128-\191]+)", function(ek) return tr .. "'" .. ekUyumla(tr, ek) end)
			s = s:gsub(kalip .. "e?s?%f[^%w]", (tr:gsub("%%", "%%%%")))
		end
	end
	return s
end

function G.doldur(s)
	if not s then return nil end
	local isim = UnitName("player") or ""
	local sinif = UnitClass("player") or ""
	local irk = UnitRace("player") or ""
	local cinsiyet = UnitSex("player")
	s = s:gsub("%$[Gg]%s*([^:;]*):([^;]*);", function(e, k)
		if cinsiyet == 3 then return k end
		return e
	end)
	local _, sinifKod = UnitClass("player")
	local st = G.SINIF_TR[sinifKod or ""]
	local sinifB, sinifK = st and st[1] or sinif, st and st[2] or sinif:lower()
	s = s:gsub("%$[Nn]", (isim:gsub("%%", "%%%%"))):gsub("%$C", (sinifB:gsub("%%", "%%%%"))):gsub("%$c", (sinifK:gsub("%%", "%%%%"))):gsub("%$[Rr]", (irk:gsub("%%", "%%%%")))
	s = s:gsub("%$[Bb]", "\n")
	-- Retail: $p (oyuncu adı) ve $1oa gibi kalan belirteçler
	s = s:gsub("%$[Pp]%f[%A]", (isim:gsub("%%", "%%%%")))
	return s
end

---------------------------------------------------------------------------
-- Parmak izi (djb2): küçük harf, oyuncu adı -> $n, harf/rakam dışı atılır
---------------------------------------------------------------------------
function G.iz(metin)
	if not metin or metin == "" then return nil end
	local s = metin
	local isim = UnitName("player")
	if isim and isim ~= "" then s = s:gsub(isim:gsub("(%W)", "%%%1"), "$n") end
	s = s:lower():gsub("[^%w%$]", "")
	local h = 5381
	for i = 1, #s do h = (h * 33 + s:byte(i)) % 4294967296 end
	return h
end

-- Büyü adı: doğrudan, ya da "Create Healthstone (Greater)", "Deadly Poison III" gibi ekli halleri
local AD_EK = { Greater = "Büyük", Lesser = "Küçük", Major = "Yüce", Minor = "Ufak", Feral = "Vahşi", Superior = "Üstün" }
function G.buyuAdiCevir(s)
	if not s or s == "" then return nil end
	local tr = G.BuyuAdi[s]; if tr then return tr end
	local kok, ek = s:match("^(.-) %((%a+)%)$")
	if kok and G.BuyuAdi[kok] then return G.BuyuAdi[kok] .. " (" .. (AD_EK[ek] or ek) .. ")" end
	kok, ek = s:match("^(.-) ([IVX]+)$")
	if kok and G.BuyuAdi[kok] then return G.BuyuAdi[kok] .. " " .. ek end
end

-- Sığdırma: çeviri orijinal yazıdan genişse yazıyı küçültüp orijinalin yerine sığdırır.
-- Böylece pencere düzeni bozulmaz, yazılar taşmaz ya da kesilmez.
local fontAsil = setmetatable({}, { __mode = "k" })
local function genislik(fs)
	if fs.GetUnboundedStringWidth then return fs:GetUnboundedStringWidth() end
	return fs:GetStringWidth() or 0
end
-- Türkçe/İngilizce geçişinde geri dönebilmek için: yazı -> { asıl İngilizce, koyduğumuz Türkçe }
local metinAsil = setmetatable({}, { __mode = "k" })
G.metinAsil = metinAsil
function G.asilKaydet(fs, yeni)
	if not fs or not fs.GetText then return end
	local eski = fs:GetText()
	if type(eski) == "string" and eski ~= yeni and not G.gizli(eski) then
		local k = metinAsil[fs]
		-- Yazı bizim Türkçemizse asıl İngilizceyi koru
		if not (k and k[2] == eski) then metinAsil[fs] = { eski, yeni } else k[2] = yeni end
	end
end
-- Türkçe kapatıldığında ekrandaki çevrilmiş yazıları İngilizce asıllarına döndür
function G.asillaraDon()
	for fs, k in pairs(metinAsil) do
		pcall(function()
			if fs:GetText() == k[2] then
				fs:SetText(k[1])
				G.sigdirSifirla(fs)
			end
		end)
	end
	wipe(metinAsil)
end

-- Sekme düğmeleri (Arkadaşlar, Kim, Lonca...) Türkçe yazıya göre genişletilir
local function sekmeMi(b)
	local ad = b and b.GetName and b:GetName()
	return ad and ad:find("Tab%d+$") and (b.Left or b.LeftDisabled or _G[ad .. "Left"] or _G[ad .. "LeftDisabled"]) and true
end
local function sekmeSigdir(b)
	if not PanelTemplates_TabResize then return false end
	if InCombatLockdown and InCombatLockdown() and b.IsProtected and b:IsProtected() then return false end
	return pcall(PanelTemplates_TabResize, b, 0)
end

-- Yazı tipini değiştirmek serbest mi? (yeni menülerdeki yazılarda SetFont yasak)
function G.fontSerbest(fs)
	-- Önce metatabloya bak: yasaklı yazılarda fs.SetFont'a erişmek bile hata veriyor
	if type(fs) ~= "table" then return false end
	if not G._stdFsMt then local o = UIParent:CreateFontString(); G._stdFsMt = getmetatable(o); o:Hide() end
	return getmetatable(fs) == G._stdFsMt
end

-- Sabit kutuda "..." ile kesilen yazıyı kutuya sığana kadar küçült (Macera Rehberi kartları gibi)
local function kesilmeSigdir(fs, asil)
	if not asil or not fs.IsTruncated then return end
	local ok, kes = pcall(fs.IsTruncated, fs)
	if not ok or not kes then return end
	for i = 1, 9 do
		local boy = math.floor(asil[2] * (1 - i * 0.05) * 10 + 0.5) / 10
		if boy < asil[2] * 0.6 then break end
		fs:SetFont(asil[1], boy, asil[3])
		local ok2, k2 = pcall(fs.IsTruncated, fs)
		if not ok2 or not k2 then return end
	end
end
-- Beceri penceresi: silah/zırh/dil becerilerinin yanına İngilizce adı gri parantezle ekle
local BECERI_EN = {}
for _, k in ipairs({ "Defense", "Unarmed", "Maces", "Wands", "Cloth", "Leather", "Mail", "Plate Mail", "Shield", "Swords", "Axes", "Daggers", "Staves",
	"Bows", "Guns", "Crossbows", "Thrown", "Fist Weapons", "Polearms", "Two-Handed Swords", "Two-Handed Axes", "Two-Handed Maces" }) do BECERI_EN[k] = true end
local function beceriPenceresinde(fs)
	local u, d = fs, 0
	while u and d < 12 do
		local ad = u.GetName and u:GetName()
		if ad and (ad:find("Skill") or ad:find("^CharacterFrame") or ad:find("^PaperDoll")) then return true end
		u = u.GetParent and u:GetParent(); d = d + 1
	end
	return false
end
function G.sigdirKoy(fs, yeni)
	if G.ist then G.ist.uygulanan = G.ist.uygulanan + 1 end
	if not fs or not fs.SetText then return end
	if type(yeni) == "string" and fs.GetText then
		local ok, cur = pcall(fs.GetText, fs)
		if ok and BECERI_EN[cur] and yeni ~= cur and not yeni:find("(", 1, true) and beceriPenceresinde(fs) then
			yeni = yeni .. " |cffaaaaaa(" .. cur .. ")|r"
		end
	end
	if G.yaziKutusunda and G.yaziKutusunda(fs) then return end
	-- Yeni menü sistemi (Blizzard_Menu Compositor) yazılarında SetFont yasak; çağırınca hata veriyor.
	-- Bu yazıların metatablosu değiştirilmiş olur: sadece metni koy, boyutla oynama.
	if fs.GetFont then
		if not G.fontSerbest(fs) then G.asilKaydet(fs, yeni); fs:SetText(yeni); return end
	end
	G.asilKaydet(fs, yeni)
	if not fs.GetFont then
		if sekmeMi(fs) then fs:SetText(yeni); if sekmeSigdir(fs) then return end end
		-- Düğme: yazıyı koy, düğmenin genişliğine sığmazsa düğmenin yazısını küçült
		fs:SetText(yeni)
		local yazi = fs.GetFontString and fs:GetFontString()
		local en = fs.GetWidth and fs:GetWidth()
		if yazi and yazi.GetFont and en and en > 0 then
			if not fontAsil[yazi] then local d, b, st = yazi:GetFont(); if d then fontAsil[yazi] = { d, b, st or "" } end end
			local a = fontAsil[yazi]
			if a then
				if not G.fontSerbest(yazi) then return end
				yazi:SetFont(a[1], a[2], a[3])
				local g = genislik(yazi)
				if g > en - 8 then yazi:SetFont(a[1], math.floor(a[2] * math.max(0.6, (en - 8) / g) * 10 + 0.5) / 10, a[3]) end
			end
		end
		return
	end
	local dosya, boyut, stil = fs:GetFont()
	local asil = fontAsil[fs]
	if asil and dosya and (asil[1] ~= dosya and boyut and math.abs(boyut - asil[2]) > 4) then asil = nil end
	-- orijinal genişliği, yazının kendi asıl boyutuyla ölç
	if asil and dosya then fs:SetFont(asil[1], asil[2], asil[3]) end
	local eski = genislik(fs)
	if not asil and dosya then asil = { dosya, boyut, stil or "" }; fontAsil[fs] = asil end
	fs:SetText(yeni)
	if not asil or eski <= 0 then return end
	-- Çok satırlı (kelime kaydıran) yazılarda dokunma; onlar kendi alanında akar
	if fs.GetNumLines and fs:GetNumLines() > 1 then kesilmeSigdir(fs, asil); return end
	local yeniG = genislik(fs)
	-- Düğme yazısıysa sınır, düğmenin kendi genişliği (kenarlardan pay bırakarak)
	local sinir = eski * 1.02
	local ust = fs.GetParent and fs:GetParent()
	if ust and ust.GetObjectType and (ust:GetObjectType() == "Button" or ust:GetObjectType() == "CheckButton")
		and ust.GetFontString and ust:GetFontString() == fs then
		local bw = ust:GetWidth() or 0
		if bw > 20 then sinir = math.min(math.max(sinir, bw - 12), bw - 12) end
	end
	if ust and sekmeMi(ust) and yeniG > sinir and sekmeSigdir(ust) then return end
	-- Yazının sağında boş yer varsa küçültme (beceri çubukları gibi geniş alanlar): kullanılabilir genişliği
	-- üst çerçevenin sağ kenarına ya da sağdaki ilk yazıya kadar ölç (bu yazıya bağlı olanları sayma)
	if yeniG > sinir and ust and ust.GetRight and not (ust.GetFontString and ust:GetFontString() == fs) then
		local sol, sag = fs:GetLeft(), ust:GetRight()
		local jh = fs.GetJustifyH and fs:GetJustifyH()
		if sol and sag and sag > sol and (jh == nil or jh == "LEFT") then
			local alan = sag - sol - 6
			local ust1, alt1 = fs:GetTop(), fs:GetBottom()
			for _, r in ipairs({ ust:GetRegions() }) do
				if r ~= fs and r.GetObjectType and r:GetObjectType() == "FontString" and r:IsShown() and (r:GetText() or "") ~= "" then
					local bagli = false
					for i = 1, (r.GetNumPoints and r:GetNumPoints() or 0) do
						local _, rel = r:GetPoint(i)
						if rel == fs then bagli = true end
					end
					local rl, rt, rb = r:GetLeft(), r:GetTop(), r:GetBottom()
					if not bagli and rl and rt and rb and ust1 and alt1 and rl > sol + 1 and rb < ust1 and rt > alt1 then
						alan = math.min(alan, rl - sol - 4)
					end
				end
			end
			if alan > sinir then sinir = alan end
		end
	end
	if yeniG > sinir then
		local oran = math.max(0.6, sinir / yeniG)
		fs:SetFont(asil[1], math.floor(asil[2] * oran * 10 + 0.5) / 10, asil[3])
	end
	kesilmeSigdir(fs, asil)
	-- Yazı alanı sabit genişlikteyse ve hâlâ kesiliyorsa ("Tümü" gibi): alanı yazı kadar genişlet
	local w = fs.GetWidth and fs:GetWidth() or 0
	local g = genislik(fs)
	-- Savaşta korumalı çerçevelerin bölgelerini yeniden boyutlandırma (engellenebilir)
	local korumali = InCombatLockdown and InCombatLockdown() and ust and ust.IsProtected and ust:IsProtected()
	if not korumali and ((w > 0 and g > w + 0.5) or (fs.IsTruncated and fs:IsTruncated())) then
		fs:SetWidth(g + 2)
	end
end

function G.sigdirSifirla(fs)
	if fs and not fs.GetFont and fs.GetFontString then fs = fs:GetFontString() end
	local asil = fs and fontAsil[fs]
	if asil and G.fontSerbest(fs) then fs:SetFont(asil[1], asil[2], asil[3]) end
end

-- Konuşma metinleri için: oyuncu adı, sınıfı ve ırkı yer tutuculara çevrilir ($n $c $r)
-- mod: nil = ad+sınıf+ırk yerine $n $c $r, 1 = sadece ad, 2 = hiçbiri (ham).
-- Not: Undead bir oyuncu için "undead" kelimesi de $r olur; bu yüzden aramada üç iz de denenir (G.izBul).
function G.konusmaIz(metin, mod)
	if not metin or metin == "" then return nil end
	local s = metin:lower()
	local function degis(deger, yer)
		if deger and deger ~= "" then s = s:gsub(deger:lower():gsub("(%W)", "%%%1"), yer) end
	end
	if mod ~= 2 then degis(UnitName("player"), "$n") end
	if not mod then
		degis(UnitClass("player"), "$c")
		degis(UnitRace("player"), "$r")
	end
	s = s:gsub("[^%w%$]", "")
	local h = 5381
	for i = 1, #s do h = (h * 33 + s:byte(i)) % 4294967296 end
	return h
end

-- Tabloda parmak iziyle ara: tam yer değiştirme, sadece ad, ham metin sırasıyla.
-- Dönüş: çeviri (yoksa nil), kayıt için kullanılacak iz
function G.izBul(tablo, metin)
	if not tablo or not metin or metin == "" then return nil end
	local ilk = G.konusmaIz(metin)
	if tablo[ilk] then return tablo[ilk], ilk end
	local i1 = G.konusmaIz(metin, 1)
	if i1 ~= ilk and tablo[i1] then return tablo[i1], i1 end
	local i2 = G.konusmaIz(metin, 2)
	if i2 ~= ilk and tablo[i2] then return tablo[i2], i2 end
	return nil, ilk
end

---------------------------------------------------------------------------
-- Sayı şablonları: "Smite an enemy for 13 to 17 Holy damage." -> "Smite an enemy for # to # Holy damage."
-- Türkçe karşılıkta {1}, {2} ... sayıların sırasıdır.
---------------------------------------------------------------------------
function G.sablon(s)
	local sayilar = {}
	local t = s:gsub("%d[%d%.,]*", function(n)
		local son = ""
		local c = n:sub(-1)
		if c == "." or c == "," then n = n:sub(1, -2); son = c end
		sayilar[#sayilar + 1] = n
		return "#" .. son
	end)
	return t, sayilar
end

function G.yerlestir(tr, sayilar)
	return (tr:gsub("{(%d+)}", function(i) return sayilar[tonumber(i)] or "?" end))
end

-- Tablodan şablonla çeviri: önce birebir, sonra sayısız şablon, sonra cümle cümle
local kosulOnbellek = {}
-- "%s" içeren anahtarlar (ör. "Show timer for %s debuff"): çalışma anında %s yerine büyü/boss adı gelir.
-- Anahtarı desene çevirip tam eşleşirse çeviri döner ("%s" yerine gelen metin olduğu gibi kalır).
local sablonListe, sablonYok2, sablonYokSay = nil, {}, 0
local function sablonKur()
	sablonListe = {}
	local function bol(x)
		local p, i = {}, 1
		while true do
			local a, b = x:find("%s", i, true)
			if not a then p[#p + 1] = x:sub(i); break end
			p[#p + 1] = x:sub(i, a - 1); i = b + 1
		end
		return p
	end
	for k, v in pairs(G.Arayuz) do
		if type(k) == "string" and type(v) == "string" and k:find("%s", 1, true) and not v:find("%%%d+%$") then
			local kp, vp = bol(k), bol(v)
			local lit = #k - 2 * (#kp - 1)
			if #kp == #vp and #kp <= 4 and lit >= 8 then
				local pat = "^"
				for i, seg in ipairs(kp) do
					pat = pat .. seg:gsub("[%^%$%(%)%%%.%[%]%*%+%-%?]", "%%%0") .. (i < #kp and "(.-)" or "")
				end
				sablonListe[#sablonListe + 1] = { pat = pat .. "$", vp = vp, lit = lit }
			end
		end
	end
	table.sort(sablonListe, function(x, y) return x.lit > y.lit end)
end
local function sablonCevir(s)
	if #s < 8 or #s > 400 or sablonYok2[s] then return nil end
	if not sablonListe then sablonKur() end
	for _, e in ipairs(sablonListe) do
		local c = { s:match(e.pat) }
		if c[1] ~= nil then
			local out = { e.vp[1] }
			for i = 1, #e.vp - 1 do out[#out + 1] = c[i] or ""; out[#out + 1] = e.vp[i + 1] end
			return table.concat(out)
		end
	end
	if sablonYokSay < 30000 then sablonYok2[s] = true; sablonYokSay = sablonYokSay + 1 end
end
local function tekCevir(tablo, s)
	local tr = tablo[s]
	if tr then return tr end
	local t, sayilar = G.sablon(s)
	tr = tablo[t]
	if tr then return G.yerlestir(tr, sayilar) end
	if tablo == G.Arayuz then
		tr = sablonCevir(s)
		if tr then return tr end
	end
	if tablo == G.Buyu then
		-- Anahtar sonunda renk kapatma "|r" ile kayıtlı olabilir; satır onsuz gelirse yine bul
		local a = tablo[s .. "|r"]
		if a then return (a:gsub("|r$", "")) end
		a = tablo[t .. "|r"]
		if a then return (G.yerlestir(a, sayilar):gsub("|r$", "")) end
		a = tablo["|r" .. s] or tablo["|cFFFFFFFF" .. s]
		if a then return a end
	end
	if tablo == G.Buyu and G.kosulEslestir then
		local c = kosulOnbellek[t]
		if c == nil then
			local ok, r = pcall(G.kosulEslestir, t)
			c = (ok and r) or false
			kosulOnbellek[t] = c
		end
		if c then return G.yerlestir(c, sayilar) end
	end
end

-- Büyü açıklamalarında geçen büyü adlarını stilBuyu ayarına göre yaz: Türkçe (English)
local adSonucu = {}
local function adlariIsle(en, tr)
	local ad = G.BuyuAdi
	if not ad or not tr then return tr end
	local sonuc = tr
	local kelimeler, n = {}, 0
	for k in en:gmatch("[^%s]+") do n = n + 1; kelimeler[n] = k end
	local islendi, islendiTr, kapsanan = {}, {}, 0
	for i = 1, n do
		if i > kapsanan and kelimeler[i]:find("^[%u]") then
			local parca = ""
			local enUzun = i
			for j = i, math.min(n, i + 5) do
				parca = (j == i) and kelimeler[j] or (parca .. " " .. kelimeler[j])
				local temiz = parca:gsub("[%.,;:!%?%)%(]+$", "")
				local t = ad[temiz]
				if t and t ~= temiz and not islendi[temiz] and not islendiTr[t] and #temiz > 3 then
					-- Yalnızca sözcük sınırında eşleş; "Göz Işını" içindeki "Göz Işın" gibi parçalara dokunma
					local init = 1
					while true do
						local a2, b2 = sonuc:find(t, init, true)
						if not a2 then break end
						local ons, son = sonuc:sub(a2 - 1, a2 - 1), sonuc:sub(b2 + 1, b2 + 1)
						local sinirOk = (ons == "" or not ons:find("[%w\128-\255]")) and (son == "" or not son:find("[%w\128-\255]"))
						if sinirOk and not sonuc:sub(1, a2 - 1):find("%(%s*$") and not sonuc:sub(b2 + 1):find("^%s*%(") then
							islendi[temiz] = true; islendiTr[t] = true
							local yeni = G.adStil("stilBuyu", t, temiz)
							sonuc = sonuc:sub(1, a2 - 1) .. yeni .. sonuc:sub(b2 + 1)
							enUzun = j
							break
						end
						init = a2 + 1
					end
				end
			end
			kapsanan = enUzun
		end
	end
	return sonuc
end

local cevirAsil
-- Çok satırlı metin (ör. Titan yardım sayfaları): tam eşleşme yoksa satır satır çevir; renk kodları korunur
local function satirSatir(tablo, s)
	local sonuc, say, n = {}, 0, 0
	for satir in (s .. "\n"):gmatch("(.-)\n") do
		local on = satir:match("^[%s]*((|[cC]%x%x%x%x%x%x%x%x)*)") or ""
		local govde = satir
		local basRenk, sonRenk = "", ""
		while true do
			local c = govde:match("^%s*(|[cC]%x%x%x%x%x%x%x%x)") or govde:match("^%s*(|[rR])")
			if not c then break end
			basRenk = basRenk .. c
			govde = govde:gsub("^%s*|[cC]%x%x%x%x%x%x%x%x", "", 1):gsub("^%s*|[rR]", "", 1)
		end
		while true do
			local c = govde:match("(|[rR])%s*$")
			if not c then break end
			sonRenk = c .. sonRenk
			govde = govde:gsub("|[rR]%s*$", "", 1)
		end
		n = n + 1
		local tr
		if govde:find("%S") then
			tr = cevirAsil(tablo, govde)
			if tr then say = say + 1 end
		end
		sonuc[#sonuc + 1] = tr and (basRenk .. tr .. sonRenk .. (satir:match("%s+$") or "")) or satir
	end
	if say == 0 then return nil end
	return table.concat(sonuc, "\n")
end

function G.cevir(tablo, s)
	local tr = cevirAsil(tablo, s)
	if not tr and tablo == G.Arayuz and type(s) == "string" and #s > 40 and s:find("\n", 1, true) then
		tr = satirSatir(tablo, s)
	end
	-- Satır içi renkli sözcükler: çeviri "§düz metin" anahtarında «renkli» işaretleriyle tutulur;
	-- renk kodları İngilizce metindeki sırayla yerleştirilir
	if not tr and tablo == G.Arayuz and type(s) == "string" and s:find("|c", 1, true) then
		local renkler = {}
		for c in s:gmatch("|[cC]%x%x%x%x%x%x%x%x") do renkler[#renkler + 1] = c end
		local duz = s:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", "")
		local m = cevirAsil(tablo, "§" .. duz)
		if m then
			local i = 0
			tr = m:gsub("«(.-)»", function(w)
				i = i + 1
				return renkler[i] and (renkler[i] .. w .. "|r") or w
			end)
		else
			tr = cevirAsil(tablo, duz)
		end
	end
	if tr and s and tablo == G.Buyu then
		local anahtar = s .. "\1" .. tostring(G.ayar("stilBuyu"))
		local c = adSonucu[anahtar]
		if not c then
			local ok, r = pcall(adlariIsle, s, tr)
			c = ok and r or tr
			adSonucu[anahtar] = c
		end
		return c
	end
	return tr
end

function cevirAsil(tablo, s)
	if not s or s == "" then return nil end
	s = s:gsub("%s+", " "):gsub("^ ", ""):gsub(" $", "")
	local tr = tekCevir(tablo, s)
	if tr then return tr end
	-- Cümlelere böl ("." "!" "?" sonrası boşluk); hepsi çevrilebiliyorsa birleştir
	if not s:find("[%.!%?]%s") then return nil end
	local parcalar, i = {}, 1
	while true do
		local a, b = s:find("[%.!%?]%s+", i)
		if not a then parcalar[#parcalar + 1] = s:sub(i); break end
		parcalar[#parcalar + 1] = s:sub(i, a)
		i = b + 1
	end
	local sonuc = {}
	for _, p in ipairs(parcalar) do
		if p ~= "" then
			local ptr = tekCevir(tablo, p)
			if not ptr then return nil end
			sonuc[#sonuc + 1] = ptr
		end
	end
	return table.concat(sonuc, " ")
end

---------------------------------------------------------------------------
-- Kayıt (çevirisiz metinler) - WoWTurkce_Kayit
--   [questID] = { baslik, aciklama, hedef, ilerleme, tamamlama, degisen }
--   buyu    = { [şablon] = "büyü adı" }
--   ipucu   = { [şablon] = true }
--   hata    = { [metin] = true }
--   konusma = { [iz] = { npc = "ad", metin = "..." } }
--   secenek = { [metin] = true }
---------------------------------------------------------------------------
local KATEGORI = { buyuadi = 20000, buyu = 20000, egitim = 500, arayuz = 20000, esyaadi = 20000, ipucu = 3000, hata = 500, konusma = 3000, secenek = 1000, sohbet = 1000, kitap = 1000, kitapadi = 1000, soz = 5000, altyazi = 1000, kelime = 3000 }
local SAYAC = {}

function G.kayitAc()
	WoWTurkce_Kayit = WoWTurkce_Kayit or {}
	return WoWTurkce_Kayit
end

-- Metin zaten Türkçe mi? (ç ö ü ğ ı İ ş harfleri) - kendi çevirimizi yeniden kaydetmemek için
function G.turkceMi(s)
	if type(s) ~= "string" then return false end
	-- Oyuncu adı Türkçe harf içeriyorsa (ör. "Löpçekitas") metni Türkçe sanma: adı çıkarıp bak
	local isim = UnitName and UnitName("player")
	if type(isim) == "string" and isim ~= "" and isim:find("[\195\196\197]") then
		local b, e = s:find(isim, 1, true)
		while b do s = s:sub(1, b - 1) .. s:sub(e + 1); b, e = s:find(isim, 1, true) end
	end
	return (s:find("[\196\197]") or s:find("\195[\135\150\156\167\182\188\162\174\187]")) ~= nil
end

function G.kaydetDiger(kat, anahtar, deger)
	if not G.ayar("kayit") or not anahtar or anahtar == "" then return end
	-- Çok satırlı metnin bir satırı Türkçe olsa bile İngilizce kalan satırları ayrı ayrı kaydet
	if type(anahtar) == "string" and G.turkceMi(anahtar) and anahtar:find("\n") then
		for satir in (anahtar .. "\n"):gmatch("(.-)\n") do
			satir = satir:gsub("^%s+", ""):gsub("%s+$", "")
			if satir:find("%a%a") and not G.turkceMi(satir) then G.kaydetDiger(kat, satir, deger) end
		end
		return
	end
	if G.turkceMi(anahtar) then return end
	-- Sohbet ve arayüz kayıtlarında kişisel veri (fısıltı, oyuncu adı) olmasın
	if (kat == "sohbet" or kat == "arayuz") and type(anahtar) == "string" and G.cop and G.cop(anahtar) then return end
	local K = G.kayitAc()
	K[kat] = K[kat] or {}
	local t = K[kat]
	if t[anahtar] ~= nil then return end
	if not SAYAC[kat] then local n = 0; for _ in pairs(t) do n = n + 1 end; SAYAC[kat] = n end
	if SAYAC[kat] >= (KATEGORI[kat] or 300) then return end -- dosya şişmesin
	SAYAC[kat] = SAYAC[kat] + 1
	t[anahtar] = deger == nil and true or deger
	G.ilkKayitBildir()
	G.istSay(kat)
end

-- Oturum istatistiği (/wowturkce durum)
G.ist = { uygulanan = 0, kaydedilen = 0, kat = {}, basla = time and time() or 0 }
function G.istSay(kat)
	G.ist.kaydedilen = G.ist.kaydedilen + 1
	G.ist.kat[kat] = (G.ist.kat[kat] or 0) + 1
end

function G.ilkKayitBildir()
	if G.yeniBildirildi then return end
	G.yeniBildirildi = true
	local fn = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
	local ok, v = pcall(fn, "WoWTurkce", "Version")
	G.yaz("Sürüm " .. ((ok and v) or "?") .. " yüklendi. Azeroth artık Türkçe konuşuyor; keyifli oyunlar dilerim! (|cff00ccff|Hplayer:Erkin Azcan|h[Erkin Azcan]|h|r)")
end

function G.kayitSayilari()
	local K = WoWTurkce_Kayit or {}
	local gorev, degisen = 0, 0
	local diger = {}
	for k, v in pairs(K) do
		if type(k) == "number" then
			gorev = gorev + 1
			if v.degisen then degisen = degisen + 1 end
		elseif type(v) == "table" then
			local n = 0
			for _ in pairs(v) do n = n + 1 end
			diger[k] = n
		end
	end
	return gorev, degisen, diger
end

---------------------------------------------------------------------------
-- Türkçe karakter destekli genel yazı tipi
-- Oyunun Font nesnelerinin yazı tipi dosyasını değiştirir, boyut ve stil korunur.
---------------------------------------------------------------------------
local orijinalFontNesne = {}
local ATLA = { NumberFontNormal = true, NumberFontNormalSmall = true, NumberFontNormalLarge = true, NumberFontNormalHuge = true }

function G.genelFontUygula()
	local acik = G.modul("genelfont")
	for ad, obj in pairs(_G) do
		-- Bazı tablolar (yasaklı nesneler, katı metatablolu addon tabloları) indekslenince hata verebilir
		if type(obj) == "table" and type(ad) == "string" and not ATLA[ad] then pcall(function()
		if obj.GetObjectType and obj.SetFont and obj.GetFont then
			local ok, tur = pcall(obj.GetObjectType, obj)
			if ok and tur == "Font" then
				local dosya, boyut, stil = obj:GetFont()
				if dosya then
					if not orijinalFontNesne[obj] then orijinalFontNesne[obj] = { dosya, boyut, stil } end
					local o = orijinalFontNesne[obj]
					if acik then
						local yeni = G.FONT_ARAYUZ
						if o[1]:upper():find("MORPHEUS") or o[1]:upper():find("SKURRI") then yeni = G.FONT_BASLIK end
						obj:SetFont(yeni, o[2], o[3] or "")
					else
						obj:SetFont(o[1], o[2], o[3] or "")
					end
				end
			end
		end
		end) end
	end
end

---------------------------------------------------------------------------
-- Komutlar
---------------------------------------------------------------------------
SLASH_WOWTR1 = "/wowturkce"
SlashCmdList.WOWTR = function(msg)
	msg = (msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
	if msg == "tr" or msg == "en" then
		G.ayarla("acik", msg == "tr")
		G.yaz(G.ayar("acik") and "Türkçe açık." or "Her şey İngilizce gösteriliyor.")
	elseif msg == "yenile" or msg == "reload" then
		ReloadUI()
	elseif msg == "ayar" or msg == "ayarlar" or msg == "a" then
		if G.ayarlariAc then G.ayarlariAc() end
	elseif msg == "esyatara" or msg == "esyatarama" or msg == "esyatara hepsi" then
		if G.esyaTaraBaslat then G.esyaTaraBaslat(msg == "esyatara hepsi") end
	elseif msg == "topla" then
		if G.toplayiciBaslat then G.toplayiciBaslat() end
	elseif msg == "questie" then
		if G.questieDokum then G.questieDokum() end
	elseif msg == "tani" or msg == "tanı" then
		local t = G.tani or {}
		G.yaz(("Arayüz: %d yazı tarandı, %d çevrildi. Modül: %s"):format(t.taranan or 0, t.cevrilen or 0, tostring(G.modul("arayuz"))))
		G.yaz(("Yakalayıcı: %s, yazı olayı: %d"):format(t.yakalayici and "kurulu" or "KURULAMADI", t.kanca or 0))
		G.yaz("Son hata: " .. tostring(t.hata or "yok"))
		G.yaz(("Sohbet eklenti satırı: %s çerçeve, %d çağrı, %d çevrildi, geçmişte %d düzeltme"):format(tostring(t.ekKurulu), t.ekCagri or 0, t.ekCevrilen or 0, t.ekGecmis or 0))
		if t.sysSon then G.yaz("Son sistem satırı: " .. t.sysSon) end
		if t.ekSon then G.yaz("Son görülen: " .. t.ekSon:gsub("|", "||")) end
	elseif msg == "paylas" or msg == "paylaş" then
		if G.paylasAc then G.paylasAc() end
	elseif msg == "gonder" or msg == "gönder" then
		if G.gonder then G.gonder() end
	elseif msg == "goster" or msg == "göster" then
		if G.paylasAc then G.paylasAc() end
	elseif msg == "durum" then
		if G.durumYaz then G.durumYaz() end
	elseif msg == "sohbet" then
		G.stilSonraki("stilEsya")
		G.yaz("Eşya adları: " .. G.stilAdi("stilEsya"))
	elseif msg == "sil" then
		WoWTurkce_Kayit = {}
		G.yaz("Kayıtlı metinler silindi.")
	else
		local n = 0
		for _ in pairs(G.Veri) do n = n + 1 end
		local gorev, degisen, diger = G.kayitSayilari()
		G.yaz(("Sürüm %s. %d görevin çevirisi yüklü."):format(G.SURUM, n))
		G.yaz(("Kaydedilen: %d görev (%d değişmiş), %d büyü, %d ipucu, %d hata, %d NPC konuşması, %d konuşma seçeneği, %d büyü adı, %d oyun ipucu, %d arayüz yazısı, %d kitap sayfası, %d NPC sözü.")
			:format(gorev, degisen, diger.buyu or 0, diger.ipucu or 0, diger.hata or 0, diger.konusma or 0, diger.secenek or 0, diger.buyuadi or 0, diger.egitim or 0, diger.arayuz or 0, diger.kitap or 0, diger.soz or 0))
		G.yaz("/wowturkce ayar  - Ayarlar panelini aç")
		G.yaz("/wowturkce gonder  - Çevrilmemiş metinleri gönder")
		G.yaz("/wowturkce goster  - Çevrilmemiş metinleri kopyalanabilir pencerede göster")
		G.yaz("/wowturkce durum  - Bu oturumun çeviri istatistiği")
		G.yaz("/wowturkce sohbet  - Sohbette adların dilini değiştir (Türkçe+İngilizce / Türkçe / İngilizce)")
		G.yaz("/wowturkce tr | en  - Türkçe / İngilizce")
		G.yaz("/wowturkce yenile  - Arayüzü yeniden yükle (kayıtları diske yazar, yeni çevirileri yükler)")
		G.yaz("/wowturkce esyatara  - Tüketilebilir eşya/malzeme/tarif açıklamalarını tara, çevirisizleri kaydet")
		G.yaz("/wowturkce esyatara hepsi  - Silah/zırh dahil TÜM eşyaları tara (uzun sürer)")
		G.yaz("/wowturkce topla  - Tüm sınıfların büyü açıklamalarını yeniden topla")
		G.yaz("/wowturkce paylas  - Kayıtları kopyalanabilir metin olarak göster (başkasına göndermek için)")
		G.yaz("/wowturkce sil  - Kayıtları temizle (çevirileri aldıktan sonra)")
	end
end

---------------------------------------------------------------------------
-- Başlangıç
---------------------------------------------------------------------------
G.baslangic = {}
function G.basla(f) G.baslangic[#G.baslangic + 1] = f end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function()
	G.kayitAc()
	WoWTurkce_Ayar = WoWTurkce_Ayar or {}
	local fok, ferr = pcall(G.genelFontUygula)
	if not fok then G.yaz("|cffff5555Hata:|r " .. tostring(ferr)) end
	for _, fn in ipairs(G.baslangic) do
		local ok, err = pcall(fn)
		if not ok then G.yaz("|cffff5555Hata:|r " .. tostring(err)) end
	end
end)

G.dinle(function(k)
	if (k == "genelfont" or k == "acik") and not G._shiftGecis then G.genelFontUygula() end
end)

-- Anahtarında çift boşluk ya da satır sonu olan çeviriler: G.cevir girdiyi tek boşluğa indirdiği için
-- bu anahtarların tek boşluklu kopyasını da ekle (oyun "A.  B" yazsa da "A. B" yazsa da eşleşsin)
G.basla(function()
	for _, t in ipairs({ G.Arayuz, G.Esya, G.Buyu, G.Secenek, G.Hata, G.Egitim }) do
		local ek = {}
		for k, v in pairs(t) do
			if type(k) == "string" and k:find("%s%s") or (type(k) == "string" and k:find("\n")) then
				local n = k:gsub("%s+", " "):gsub("^ ", ""):gsub(" $", "")
				if t[n] == nil then ek[n] = v end
			end
			-- Renk kodlu anahtarların renksiz kopyası (oyun metni çoğu yerde renksiz aranır)
			if type(k) == "string" and type(v) == "string" and k:find("|[cC]%x%x%x%x%x%x%x%x") then
				local n = k:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", ""):gsub("%s+", " "):gsub("^ ", ""):gsub(" $", "")
				if t[n] == nil and ek[n] == nil then ek[n] = (v:gsub("|[cC]%x%x%x%x%x%x%x%x", ""):gsub("|[rR]", "")) end
			end
		end
		for k, v in pairs(ek) do t[k] = v end
	end
end)

-- Oyunun hazır metin desenleri (GlobalStrings): "%s has joined the channel." gibi.
-- G.GlobalDesen[kelime] = { { desen, "Türkçe {1} {2}", {yakalama sırası} }, ... }
-- Her desen, içindeki en uzun sabit kelimeye göre gruplanır; metindeki kelimelerle aday desenler bulunur.
G.GlobalDesen = G.GlobalDesen or {}
function G.globalDesenCevir(s)
	if type(s) ~= "string" or #s > 600 then return nil end
	local denendi = {}
	for w in s:gmatch("%a+") do
		local liste = not denendi[w] and G.GlobalDesen[w:lower()]
		denendi[w] = true
		if liste then
			for _, d in ipairs(liste) do
				local c = { s:match(d[1]) }
				if c[1] ~= nil then
					local sira = d[3]
					return (d[2]:gsub("{(%d+)}", function(i)
						local v = c[sira and sira[tonumber(i)] or tonumber(i)]
						if type(v) == "string" and v:find("%a") then
							if G._sohbetModu then return G.isimCiftDil(v) end
							return G.isimCevir(v) or v
						end
						return v and tostring(v) or ""
					end))
				end
			end
		end
	end
end

G.dinle(function(k)
	if (k == "acik" or k == "arayuz") and not G.modul("arayuz") then pcall(G.asillaraDon) end
end)

-- Ad çevirici: büyü, beceri, meslek, eşya, görev adları.
-- "Skinning (Apprentice)" -> "Deri Yüzme (Çırak)", "Herbalism (75)" -> "Bitkicilik (75)", "Level 4" -> "Seviye 4"
local RUTBE_TR = { Apprentice = "Çırak", Journeyman = "Kalfa", Expert = "Uzman", Artisan = "Usta", Master = "Üstat",
	["Grand Master"] = "Büyük Üstat", Illustrious = "Ünlü" }
function G.isimCevir(v)
	if type(v) ~= "string" or v == "" or G.gizli(v) or v:find("|H") or G.turkceMi(v) then return nil end
	if G.oyuncuMu and G.oyuncuMu(v) then return nil end
	local tr = (G.BuyuAdi and G.BuyuAdi[v]) or G.EsyaAdi[v] or G.GorevAdi[v] or G.Arayuz[v] or (G.esyaSonekli and G.esyaSonekli(v))
	if tr then return tr end
	local n = v:match("^Level (%d+)$")
	if n then return "Seviye " .. n end
	local ad, ek = v:match("^(.-) %((.-)%)$")
	if ad then
		local atr = G.isimCevir(ad)
		local etr = RUTBE_TR[ek] or (ek:match("^%d+$") and ek) or (ek:match("^Rank (%d+)$") and ("Rütbe " .. ek:match("%d+"))) or G.Arayuz[ek]
		if atr and etr then return atr .. " (" .. etr .. ")" end
	end
	if G.buyuAdiCevir then
		local b = G.buyuAdiCevir(v)
		if b then return b end
	end
	if v:find(", ") then
		local out, hepsi = {}, true
		for p in (v .. ", "):gmatch("(.-), ") do
			local t = G.isimCevir(p)
			if not t then hepsi = false end
			out[#out + 1] = t or p
		end
		if hepsi then return table.concat(out, ", ") end
	end
end
-- Süre yazıları: "59 Mins 51 Secs" -> "59 dk 51 sn"
local SURE_BIRIM = { Sec = "sn", Secs = "sn", sec = "sn", secs = "sn", Second = "saniye", Seconds = "saniye", seconds = "saniye", second = "saniye",
	Min = "dk", Mins = "dk", min = "dk", mins = "dk", Minute = "dakika", Minutes = "dakika", minute = "dakika", minutes = "dakika",
	Hr = "saat", Hrs = "saat", hr = "saat", hrs = "saat", Hour = "saat", Hours = "saat", hour = "saat", hours = "saat",
	Day = "gün", Days = "gün", day = "gün", days = "gün" }
function G.sureCevir(s)
	if type(s) ~= "string" then return s end
	return (s:gsub("(%d+[%.,]?%d*) (%a+)", function(n, b) local t = SURE_BIRIM[b]; return t and (n .. " " .. t) or (n .. " " .. b) end))
end
-- Sohbet için: Türkçe ad + yanında gri İngilizcesi
function G.isimCiftDil(v)
	local tr = G.isimCevir(v)
	if tr and tr ~= v then
		return G.adStil("stilEsya", tr, v, "|cffaaaaaa")
	end
	return v
end

-- Rastgele ekli eşyalar: "Tough Leather Boots of the Bear" -> "Sağlam Deri Çizme (Ayı)"
G.EsyaSoneki = G.EsyaSoneki or {}
function G.esyaSonekli(ad)
	if type(ad) ~= "string" then return nil end
	local kok, ek = ad:match("^(.-) (of .+)$")
	if not kok then return nil end
	local s = G.EsyaSoneki[ek]
	local k = G.EsyaAdi[kok]
	if s and k then return k .. " (" .. s .. ")" end
end
