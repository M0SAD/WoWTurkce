local ADDON_NAME, FDJ = ...
FDJ = FDJ or _G.ForeverDungeonJournal_NS

-- Interface localization plus a separate content-localization layer. Internal
-- database keys remain stable; localized display text is resolved at render time.
FDJ.Locales = FDJ.Locales or {}

FDJ.Locales.enUS = {
    RANDOM_ENCHANT = "+Rastgele Büyü",
    ALSO_RECEIVE = "Ayrıca şunları alacaksın:",
    MAP_JUMP_LEVEL = "%d. kata atla",
    MAP_RFK_WALLJUMP = "Roogug'a ulaşmak için kapının üzerinden duvara tırmanarak zıpla",
    MAP_RFK_VINE = "Roogug'a ulaşmak için bu asmaya zıpla",
    MAP_OBJ_BFD_CHEST = "Lorgalis Elyazması'nı, havuzun bu girintisinde su altındaki Oyuk Demir Sandık'tan al.",
    MAP_OBJ_BFD_FATHOM = "Geçidin altında, su altındaki Fathom Taşı'na tıkla ve Fathom Çekirdeği'ni al. Bunu yapınca Baron Aquanis belirir.",
    MAP_OBJ_LOOT = "Burada ganimet al: %s",
    MAP_OBJ_USE = "Burada kullan",
    MAP_OBJ_EXPLORE = "Bu yeri keşfet",
    NOTICE_LV30_DATA = "30. seviyeye kadar olan zindanların yeni ganimet ve görevleri hâlâ keşfediliyor. Yeni veriler çıktıkça güncelleyeceğim. iyi şanslar, iyi eğlenceler",
    NOTICE_RESIZE = "Komutlar |cffff3030/fj|r yerine |cff33ff33/dj|r oldu.",
    MAP_SWIM_LEVEL = "%d. kat için su altında yüz",
    MAP_ENTRANCE = "Giriş",
    LOOT_COMPACT = "Kompakt görünüm",
    LOOT_DETAILED = "Ayrıntılı görünüm",
    LOOT_COMPACT_TIP = "Küçük satırlarla aynı anda daha fazla eşya göster",
    LOOT_DETAILED_TIP = "Tam eşya satırlarını göster",
    ATTUNE_ONYXIA = "Onyxia Uyumlanması",
    MAP_ENTRANCE_ORANGE = "Turuncu Giriş",
    MAP_ENTRANCE_PURPLE = "Mor Giriş",
    MAP_FLOOR = "%d. Kat",
    DUNGEON_JOURNAL = "Zindan Rehberi",
    SEARCH = "Zindan, eşya ara...",
    SEARCH_NO_RESULTS = "Sonuç yok",
    DUNGEONS = "Zindanlar",
    MAP = "Harita",
    BROWSE_DUNGEONS = "Zindanlara Göz At",
    HOME_SUBTITLE = "Boss'ları, ganimetleri ve görevleri görmek için bir zindan kapağı seç",
    FOREVER_BETA_DATA = "Forever beta verisi",
    BOSSES = "Boss'lar",
    QUESTS = "Görevler",
    QUEST = "görev",
    QUESTS_LOWER = "görev",
    LOOT = "Ganimet",
    ITEM = "eşya",
    ITEMS = "eşya",
    RARE = "NADİR",
    YOU_HAVE_IT = "SENDE VAR",
    TURN_IN_LABEL = "Teslim et",
    AVAILABLE_FROM_LEVEL = "%s. seviyeden itibaren alınabilir",
    REQUIRED_PREREQUISITE = "Gerekli ön görev",
    OBJECTIVE = "Hedef",
    STARTS_AT = "Başlangıç yeri",
    TURN_IN = "Teslim yeri",
    NOTES = "Notlar",
    SHARE = "Paylaş",
    NOT_SHAREABLE = "Paylaşılamaz",
    SHAREABLE_QUEST = "Paylaşılabilir Görev",
    ACCEPT_TO_SHARE = "Grubunla paylaşmak için bu görevi kabul et.",
    SHAREABLE_SAME_STEP = "Aynı adımdaki oyuncularla paylaşılabilir.",
    REWARD = "Ödül",
    REWARDS = "Ödüller",
    CHOOSE_ONE_REWARD = "Bir ödül seç",
    SHOW_ON_MAP = "Haritada Göster",
    SHOW_TURN_IN = "Teslim Yerini Göster",
    TURN_IN_DUNGEON = "Teslim: Zindan",
    ROUTE_FP_TARREN_MILL_TEXT = "Rota, uçuş noktasını alabilmen için burada sapıyor. Sonra yoldan geri dön ve doğuya, Arathi'ye doğru devam et.",
    ROUTE_FP_TARREN_MILL = "Tarren Mill Uçuş Noktası",
    ROUTE_REMOVE_HINT = "Rotayı kaldırmak için sağ tıkla",
    SHOW_LOCATION = "Konumu Göster",
    DUNGEON_ENTRANCE = "Zindan girişi",
    HOW_TO_GET_THERE = "Oraya nasıl gidilir",
    ROUTE = "Rota",
    BACK_TO_DUNGEON = "Zindana Dön",
    ALLIANCE_ROUTE = "İttifak rotası",
    SHOW_QUEST_CHAIN = "Görev Zincirini Göster",
    REQUIRED_QUESTS = "Gerekli Görevler",
    REQUIRED_ITEMS = "Gerekli Eşyalar",
    PROVIDED_ITEM = "Verilen Eşya",
    SHOW_WHOLE_CHAIN = "Tüm görev zincirini göstermek için tıkla",
    OPEN_REQUIRED_CHAIN = "Gerekli görev zincirini aç.",
    SHOW_GIVER_ON_MAP = "Görev vereni haritada göster",
    MAP_TOOLTIP = "Doğru bölgeyi açar ve kayıtlı görev başlangıç konumunu işaretler.",
    IN_DUNGEON = "Zindanda",
    NO_QUESTS = "Görev yok",
    NO_FACTION_QUESTS = "Bu zindan için kayıtlı %s görevi yok.",
    NO_FACTION_QUESTS_TBD = "Bu zindan için henüz bilinen %s görevi yok. Zindan yeni ve görevleri hâlâ keşfediliyor.",
    STEP_ACCEPT_ONLY = "(accept only)",
    LOOT_NOTE_TWO_ITEMS = "Can drop 2 items",
    LOOT_NOTE_HELNURATH = "Summoned by the Warlock epic mount quest",
    UNIQUE_TRASH = "Zindana özgü ufak yaratık ganimetleri",
    DROPS_FROM = "Düştüğü yer: %s",
    CLICK_DUNGEON = "Zindan ayrıntılarını açmak için tıkla",
    HIDE_DUNGEONS = "Zindanları Gizle",
    LOOT_FILTER = "Ganimet Filtresi",
    BUG_REPORT = "Hata Bildir",
    BUG_REPORT_SHORT = "Rapor",
    BUG_REPORT_TEXT = "Yanlış bilgi ya da eklenmesi gereken yeni keşifler mi buldun? Lütfen Discord'da bildir, ekran görüntüsü gerekli.",
    WM_WORLD_MAP = "Dünya Haritası",
    WM_DUNGEON_MAP = "Zindan Haritası",
    MINIMAP_HIDE_CONFIRM = "Zindan Rehberi mini harita düğmesi gizlensin mi?\n\nDüğmeyi /dj minimap yazarak geri getirebilirsin.",
    LF_SHOW_RECIPES = "Desen/tarif ganimetlerini her zaman göster",
    RESIZE_TIP_TITLE = "Yeniden Boyutlandır",
    RESIZE_TIP = "Pencereyi yeniden boyutlandırmak için sürükle. Sıfırlamak için sağ tıkla.",
    LF_ENABLE = "Etkinleştir",
    LF_DISABLE = "Devre dışı bırak",
    LF_MIN_LEVEL = "Gereken asgari seviye",
    OPT_UI = "Genel",
    OPT_DISCORD_TEXT = "Hata bildirmek, yeni keşifleri paylaşmak ve son haberleri almak için Zindan Rehberi Discord'una katıl.",
    OPT_DUNGEON_LIST = "Zindan listesi",
    OPT_HIDE_ITEM_LINE = "Eşya ipuçlarındaki rehber satırını gizle",
    OPT_HIDE_ITEM_LINE_TIP = "Bir eşyanın hangi boss'tan ya da görevden geldiğini gösteren satırı kaldırır.",
    MALLET_HOW = "How to get the Mallet",
    OPT_HIDE_MINIMAP = "Mini harita düğmesini gizle",
    OPT_HIDE_MINIMAP_TIP = "Düğmeyi geri getirmek için /dj minimap yaz.",
    OPT_BIND = "Rehberi Açma Tuşu",
    OPT_BIND_TIP = "Tıkla, sonra bir tuşa bas. Temizlemek için sağ tıkla.",
    OPT_NOT_BOUND = "Atanmamış",
    OPT_PRESS_KEY = "Bir tuşa bas...",
    OPT_KEY_TAKEN = "%s zaten atanmış. Kullanılmayan bir tuş seç.",
    OPT_NO_COMBAT = "Tuş atamaları çatışma sırasında değiştirilemez.",
    OPT_HIDE_OUTLEVELED = "Seviyesi geçilen zindanları otomatik gizle",
    OPT_HIDE_OUTLEVELED_TIP = "Seviyen bir zindanın seviye aralığını aştığında onu listeden gizler.",
    OPT_HIDE_QUESTS_DONE = "Tüm görevleri bitmiş zindanları otomatik gizle",
    OPT_HIDE_QUESTS_DONE_TIP = "Karakterinin orada yapabileceği tüm görevleri tamamladığında zindanı listeden gizler.",
    OPT_HIDE_DONE_TICK = "Bitmiş zindanlar için yeşil onay işaretini gizle",
    OPT_HIDE_DONE_TICK_TIP = "Tüm görevlerini tamamladığın bir zindanın görev sayısından önce ana sayfada görünen yeşil onay işaretini kaldırır.",
    OPT_SHOW_ALL_CLASS = "Tüm sınıf görevlerini göster",
    OPT_SHOW_ALL_CLASS_TIP = "Diğer sınıfların görevlerini de listeler (örneğin Warlock ya da Paladin görevleri). Kapalıyken yalnızca kendi sınıfının görevlerini görürsün.",
    OPT_HIDE_LFG = "Grup Bul Panelini Gizle",
    OPT_HIDE_LFG_TIP = "Zindan sayfalarında Konumu Göster'in yanındaki, o zindan için Grup Bul'u açan göz düğmesini gizler. Göze sağ tıklayıp Devre Dışı Bırak'ı da seçebilirsin.",
    OPT_HIDE_SLEEPING_BAG = "Uyku Tulumu görevini gizle",
    OPT_HIDE_SLEEPING_BAG_TIP = "Rehberin ana sayfasındaki Uyku Tulumu simgesini (WoW Forever ve Raid simgelerinin yanında) gizler. Simgeye sağ tıklayıp Gizle'yi de seçebilirsin. Takip edilen bir Uyku Tulumu zinciri okunu korur.",
    OPT_HIDE_DUNGEON_MAP = "Zindanın içindeyken Zindan Haritasını gizle",
    OPT_HIDE_DUNGEON_MAP_TIP = "İşaretliyse, zindanın içinde M tuşuna basmak rehberin zindan haritası yerine oyunun normal haritasını gösterir.",
    DESCRIPTION = "Açıklama",
    MINIMAP_OPTIONS = "Sağ tık: Seçenekler",
    LF_ARMOR_ALL = "Tümü",
    LF_ARMOR = "Zırh Filtresi",
    LF_WEAPON_ALL = "Tümü",
    LF_WEAPON = "Silah Filtresi",
    LF_WEAPONS = "Silahlar",
    LF_ARMOR_TIP = "Diğer türlerdeki zırh parçalarını gizler. Silahlar, kalkanlar, yüzükler, kolyeler, muskalar ve pelerinler her zaman kalır.",
    CHAIN_REQUIRED = "Önce bir görev zinciri gerekli.",
    CHAIN_STEP = "%d / %d. adımdasın.",
    SHOW_NEXT_STEP_MAP = "Sonraki Adımı Haritada Göster",
    LF_SHOW = "Sonuçları göster",
    LF_SHOW_TIP = "Yukarıdaki filtrelere uyan ganimet düşüren, tüm zindanlardaki her boss'u listeleyen bir sayfa açar.",
    LF_RESULTS = "Uyan ganimetler",
    LF_NO_RESULTS = "Bu filtrelere uyan eşya yok.",
    LF_BACK = "Kapat",
    LF_CLASS_ONLY = "Yalnızca sınıfımın kullanabileceği ganimetleri göster",
    LF_STATS_HEADER = "Yalnızca bu özelliklere sahip eşyalar",
    LF_STATS_HINT = "Aradığın özellikleri işaretle. Hiçbiri işaretli değilse her şey gösterilir.",
    LF_MATCH_ALL = "Eşya işaretli tüm özelliklere sahip olmalı",
    LF_CLEAR = "Temizle",
    OPT_DISCORD_COPY = "Davet bağlantısını kopyalamak için Ctrl+C'ye bas.",
    OPT_CLOSE = "Kapat",
    RPG_LOCKED = "Kilitli",
    RPG_LOCKED_CARD = "Rehber Sayfasının kilidini açmak için bir zindanın son boss'unu öldür",
    RPG_PROGRESS_BAR = "Yolculuk %d/%d (%%%d)",
    RPG_LOCKED_MSG = "Bu zindan kilitli. Kilidini açmak için son boss'unu yen.",
    RPG_LOCKED_TIP2 = "Bu sayfanın kilidini açmak için zindanın son boss'unu öldür.",
    RPG_LOCKED_TIP_TITLE = "Kilitli Rehber Sayfası",
    RPG_LOCKED_TIP = "Bu sayfanın kilidini açmak için %s zindanının son boss'u %s'i yen.",
    RPG_LOCKED_TIP_POINTS = "Kilidi açmak +%d yolculuk puanı verir.",
    RPG_UNLOCKED_MSG = "%s artık rehberinde açık!",
    RPG_TOAST_TITLE = "Rehber Sayfasının Kilidi Açıldı",
    RPG_TOAST_HINT = "Rehberde açmak için tıkla",
    RPG_QUEST_TOAST_TITLE = "Zindan Görevinin Kilidi Açıldı",
    RPG_QUEST_UNLOCKED_MSG = "%s görevinin kilidi açıldı! %d/%d",
    RPG_QUEST_TOAST_HINT = "Rehberde açmak için tıkla",
    RPG_BOSS_HIDDEN = "Ortaya çıkarmak için bu boss'u yen.",
    RPG_TRASH_HIDDEN = "Ortaya çıkarmak için zindandaki ufak yaratıkların yaklaşık %%20'sini temizle.",
    RPG_QUEST_HIDDEN = "Kilidini açmak için bu görevi al.",
    RPG_MAP_LOCKED_TITLE = "Harita Kilitli",
    RPG_MAP_LOCKED_TIP = "Kilidini açmak için zindandaki ufak yaratıkların yaklaşık %%20'sini temizle: %d/%d.",
    RPG_MAP_LOCKED_MSG = "Zindan haritası, ufak yaratıkların yaklaşık %%20'si temizlendikten sonra açılır (%d/%d).",
    RPG_MAP_TOAST_TITLE = "Zindan Haritasının Kilidi Açıldı",
    RPG_MAP_UNLOCKED_MSG = "%s haritasının kilidi açıldı!",
    RPG_MAP_TOAST_HINT = "Haritayı rehberde açmak için tıkla",
    RPG_MAP_TOAST_HINT_M = "Görmek için zindanda M'ye bas",
    RPG_BOSS_REVEALED_MSG = "%s rehberinde ortaya çıktı!",
    RPG_LOCKED_TIP_QUEST = "Görevlerinden birini almak bir kısmını açar.",
    RPG_PROGRESS = "Yolculuk %%%d",
    RPG_PROGRESS_TITLE = "Zindan Yolculuğu",
    RPG_PROGRESS_TIP = "Fraksiyonun ve sınıfın için %d zindan görevinden %d tanesi tamamlandı.",
    RPG_PROGRESS_PAGES = "%d rehber sayfasından %d tanesinin kilidi açıldı (son boss'lar yenildi).",
    RPG_PROGRESS_POINTS = "Her görev %d puan, her rehber sayfası %d puan değerinde.",
    RPG_SUBTITLE = "Sayfalarının kilidini açmak için bir zindanın son boss'unu yen",
    MODE_TITLE = "Rehberini seç",
    MODE_SUB = "Bunu istediğin zaman seçeneklerden (/dj options) ya da /dj mode ile değiştirebilirsin.",
    MODE_GAMER = "Oyuncu Modu",
    MODE_GAMER_DESC = "Tam rehber: her zindan, boss, ganimet tablosu ve görev baştan açık.",
    MODE_RPG = "RPG Modu",
    MODE_RPG_DESC = "Zindanlar kilitli başlar ve son boss'ları yenilince açılır. Bir ilerleme çubuğu tamamladığın her zindan görevini izler.",
    MODE_CHOOSE = "Seç",
    RPG_CONFIRM_TEXT = "Bu modda zindanlar, son boss'u öldürene kadar kilitli kalır. Modu istediğin zaman seçenekler panelinden değiştirebilirsin.",
    RPG_CONFIRM_OK = "Tamam",
    RPG_CONFIRM_BACK = "Yeniden seç",
    RPG_INTRO_TEXT = "Zindanlar, son boss'larını öldürene kadar kilitli kalır.",
    RPG_INTRO_KEEP = "RPG Modunu Koru",
    RPG_INTRO_OPTIONS = "Seçeneklerden Kapat",
    MODE_RPG_ENABLE = "Seçeneklerden Etkinleştir",
    COMING_SOON = "Çok Yakında",
    PREVIEW_DATA_SOON = "Boss, ganimet ve görev verileri çok yakında.",
    PREVIEW_MAP_CLICK = "Haritayı görmek için tıkla.",
    ITEM_CLICK_MAP = "Haritada göstermek için tıkla.",
    REPEAT_SHOW = "Tekrarlanabilir Görevleri Göster (%d)",
    REPEAT_HIDE = "Tekrarlanabilir Görevleri Gizle (%d)",
    OPT_SHOW_ALL_PROF = "Tüm Meslek Görevlerini Göster",
    OPT_SHOW_ALL_PROF_TIP = "Bu karakterin sahip olmadığı mesleklerin görevlerini de (Demircilik, Madencilik...) listeler.",
    OPT_FOREVER_ONLY = "Yalnızca Forever Zindanları",
    OPT_FOREVER_ONLY_TIP = "Yalnızca WoW Forever'da yeni olan zindanları göster. Zindan listesinin sol üstündeki WoW Forever amblemine tıklamakla aynı şey: tüm zindanları yeniden görmek için işareti kaldır.",
    PROF_BLACKSMITHING = "Demircilik",
    PROF_MINING = "Madencilik",
    RAIDS_TITLE = "Raidler",
    ITEM_UNSEEN_TITLE = "Henüz görülmedi",
    ITEM_UNSEEN_TIP = "Bu eşya oyunda var ama sunucu henüz ayrıntılarını göndermedi. Biri onu gördüğünde (örneğin düştüğünde) görünecek.",
    FOREVER_FILTER_TITLE = "WoW Forever Zindanları",
    FOREVER_FILTER_TIP = "Yalnızca WoW Forever'da yeni olan zindanları göstermek için tıkla.",
    FOREVER_FILTER_ON = "Yalnızca WoW Forever zindanları gösteriliyor. Tüm zindanları yeniden göstermek için tıkla.",
    OPT_RPG_MODE = "RPG Modu",
    OPT_RPG_MODE_TIP = "Zindanlar, bu karakter son boss'larını yenene kadar kilitli kalır ve bir ilerleme çubuğu zindan görevlerini izler.",
    OPT_VERSION = "Sürüm: %s",
    OPT_ACCESS = "Seçeneklere %s ile eriş",
    OPT_OPEN_OPTIONS = "Seçenekleri Aç",
    OPT_COPY = "Kopyala",
    OPT_COPIED = "Kopyalandı!",
    OPT_TAB_OPTIONS = "Seçenekler",
    OPT_DISCORD = "Discord",
    LF_OK = "Tamam",
    LF_HIDDEN_NOTE = "Ganimet Filtresi tarafından %d tanesi gizlendi",
    RECIPES_SECTION = "Tarifler ve Desenler (%d)",
    SHARED_SHOW = "Ortak Ganimeti Göster (%d)",
    SHARED_HIDE = "Ortak Ganimeti Gizle (%d)",
    PROBABLE_LOOT = "Doğrulanmadı ama büyük olasılıkla düşüyor (%d)",
    SHARED_NOTE = "düşme şansı düşük, birçok boss",
    SHARED_LOOT = "Ortak Ganimet",
    SEVERAL_DUNGEONS = "birkaç zindan",
    LF_STAT_HEAL = "İyileştirme",
    LF_STAT_SPELL = "Büyü Hasarı",
    LF_STAT_AP = "Saldırı Gücü",
    LF_STAT_CRIT = "Kritik Vuruş",
    LF_STAT_SPELLCRIT = "Büyü Kritiği",
    LF_STAT_HIT = "İsabet",
    LF_STAT_SPELLHIT = "Büyü İsabeti",
    LF_STAT_MP5 = "MP5",
    LF_STAT_MP5_TIP = "5 saniyede yenilenen mana",
    LF_STAT_HP5 = "HP5",
    LF_STAT_HP5_TIP = "5 saniyede yenilenen can",
    LF_ARMOR_BTN = "Zırh",
    LF_RING = "Yüzük",
    LF_NECK = "Boyun",
    LF_TRINKET = "Muska",
    LF_CLOAK = "Pelerin",
    LF_WEAPON_BTN = "Silah",
    LF_RESIST = "Direnç Filtresi",
    LF_RESISTANCES = "Dirençler",
    LF_RES_FIRE = "Ateş",
    LF_RES_HOLY = "Kutsal",
    LF_SCHOOLS = "Büyü okulları",
    LF_RES_FROST = "Buz",
    LF_RES_NATURE = "Doğa",
    LF_RES_SHADOW = "Gölge",
    LF_RES_ARCANE = "Arkan",
    LF_STAT_DEF = "Savunma Derecesi",
    LF_STAT_STR = "Güç",
    LF_STAT_AGI = "Çeviklik",
    LF_STAT_STA = "Dayanıklılık",
    LF_STAT_INT = "Zeka",
    LF_STAT_SPI = "Ruh",
    DONE = "Bitti",
    HIDDEN = "Gizli",
    CLICK_HIDE_DUNGEON = "Bu zindanı gizlemek için tıkla.",
    CLICK_RESTORE_DUNGEON = "Bu zindanı geri getirmek için tıkla.",
    ALL_DUNGEONS_HIDDEN = "Tüm zindanlar gizli. Geri getirmek için Zindanları Gizle'ye tıkla.",
    FACTION_QUESTS = "%s görevleri",
    QUEST_IN_LOG = "Bu önceki görev görev günlüğünde.",
    QUEST_COMPLETED = "Bu önceki görev tamamlandı.",
    QUEST_NOT_CACHED = "Görev metni şu anda istemci tarafından önbelleğe alınmamış.",
    CLASS_ONLY = "YALNIZCA %s",
    MINIMAP_HIDDEN = "mini harita düğmesi gizlendi. /dj minimap kullan.",
    MINIMAP_LEFT = "Sol tık: Aç / kapat",
    MINIMAP_DRAG = "Sürükle: Taşı",
    MINIMAP_RIGHT = "Sağ tık: Gizle",
    LANGUAGE_CURRENT = "Dil: %s",
    LANGUAGE_SET = "Dil %s olarak ayarlandı.",
    LANGUAGE_AUTO = "Otomatik (%s)",
    LANGUAGE_HELP = "Dil testi: /dj lang tr, de, fr, es, ru, it, pt, ko, zh, zhtw, en, /dj lang auto",
    UPDATE_AVAILABLE = "%s sürümü mevcut (sende %s var). CurseForge'dan güncelle.",
    PREVIOUS_QUEST = "Önceki görev",
    REQUIRES_QUEST = "Gerektirir: %s",
    NEXT_QUEST = "Sonraki görev",
    LEADS_TO = "Şuna götürür: %s",
    MAP_MARKER_REMOVED = "harita işareti kaldırıldı.",
    MAP_LEFT_TARGET = "Yakındaysa görev vereni hedeflemek ve işaretlemek için sol tıkla",
    MAP_RIGHT_REMOVE = "İşareti kaldırmak için sağ tıkla",
    MAP_PATROL = "Walks around: the line shows the path",
    MAP_QUEST_TARGET = "Quest target",
    MAP_MARKED = "%s haritada işaretlendi.",
    MAP_OPEN_FAILED = "kayıtlı harita konumu açılamadı.",
    MAP_COMBAT = "çatışma sırasında harita açılamaz. İşaretli noktayı görmek için %s tuşuna bas.",
    QUEST_GIVER = "Görev veren",
    QUEST_STARTS_HERE = "Görev burada başlıyor",
    TRACK = "Takip Et",
    TRACKING = "Takip Ediliyor",
    TRACK_TIP = "Bu zindanın görevlerini ilerlemenle birlikte ekranında gösterir. İstediğin yere sürükle.",
    TRACK_STOP = "Takibi bırak",
    TRACK_READY = "Teslime hazır",
    TRACK_DONE = "Tamamlandı",
    TRACK_IN_LOG = "Görev günlüğünde",
    TRACK_CLICK = "Rehberde açmak için tıkla",
    TURN_IN_HERE = "Burada teslim et",
    TRACK_ACCEPT = "Görevi kabul etmek için tıkla",
}

FDJ.Locales.deDE = {
    RANDOM_ENCHANT = "<Zufällige Verzauberung>",
    ALSO_RECEIVE = "Ihr bekommt außerdem:",
    MAP_JUMP_LEVEL = "Auf Ebene %d hinunterspringen",
    MAP_RFK_WALLJUMP = "Spring an der Wand über das Tor, um Roogug zu erreichen",
    MAP_RFK_VINE = "Spring auf diese Ranke, um Roogug zu erreichen",
    MAP_OBJ_BFD_CHEST = "Plündere das Lorgalis-Manuskript aus der Narbigen Eisentruhe, unter Wasser in dieser Nische des Beckens.",
    MAP_OBJ_BFD_FATHOM = "Klicke unter Wasser unter dem Steg auf den Tiefenstein, um den Tiefenkern zu erhalten. Dabei erscheint Baron Aquanis.",
    MAP_OBJ_LOOT = "Hier plündern: %s",
    MAP_OBJ_USE = "Hier benutzen",
    MAP_OBJ_EXPLORE = "Diesen Ort erkunden",
    NOTICE_LV30_DATA = "Neue Beute und Quests für Dungeons bis Stufe 30 werden noch entdeckt. Ich aktualisiere, sobald neue Daten erscheinen. gl hf",
    NOTICE_RESIZE = "Die Befehle wurden von |cffff3030/fj|r zu |cff33ff33/dj|r geändert.",
    MAP_SWIM_LEVEL = "Unter Wasser tauchen für Ebene %d",
    MAP_ENTRANCE = "Eingang",
    LOOT_COMPACT = "Kompaktansicht",
    LOOT_DETAILED = "Detailansicht",
    LOOT_COMPACT_TIP = "Mehr Gegenstände auf einmal in kleineren Zeilen anzeigen",
    LOOT_DETAILED_TIP = "Vollständige Zeilen anzeigen",
    ATTUNE_ONYXIA = "Onyxia-Einstimmung",
    MAP_ENTRANCE_ORANGE = "Orangefarbener Eingang",
    MAP_ENTRANCE_PURPLE = "Violetter Eingang",
    MAP_FLOOR = "Ebene %d",
    DUNGEON_JOURNAL = "Dungeon-Journal",
    SEARCH = "Dungeons, Gegenstände suchen...",
    SEARCH_NO_RESULTS = "Keine Ergebnisse",
    DUNGEONS = "Dungeons",
    MAP = "Karte",
    BROWSE_DUNGEONS = "Dungeons durchsuchen",
    HOME_SUBTITLE = "Wähle einen Dungeon, um Bosse, Beute und Quests anzusehen",
    FOREVER_BETA_DATA = "Forever-Betadaten",
    BOSSES = "Bosse",
    QUESTS = "Quests",
    QUEST = "Quest",
    QUESTS_LOWER = "Quests",
    LOOT = "Beute",
    ITEM = "Gegenstand",
    ITEMS = "Gegenstände",
    RARE = "RARE",
    YOU_HAVE_IT = "ANGENOMMEN",
    TURN_IN_LABEL = "Abgeben",
    AVAILABLE_FROM_LEVEL = "Verfügbar ab Stufe %s",
    REQUIRED_PREREQUISITE = "Benötigte Vorquest",
    OBJECTIVE = "Ziel",
    STARTS_AT = "Startet bei",
    TURN_IN = "Abgeben bei",
    NOTES = "Hinweise",
    SHARE = "Teilen",
    NOT_SHAREABLE = "Nicht teilbar",
    SHAREABLE_QUEST = "Teilbare Quest",
    ACCEPT_TO_SHARE = "Nimm diese Quest an, um sie mit deiner Gruppe zu teilen.",
    SHAREABLE_SAME_STEP = "Mit Spielern teilbar, die beim selben Schritt sind.",
    REWARD = "Belohnung",
    REWARDS = "Belohnungen",
    CHOOSE_ONE_REWARD = "Wähle eine Belohnung",
    SHOW_ON_MAP = "Auf Karte zeigen",
    SHOW_TURN_IN = "Abgabe anzeigen",
    TURN_IN_DUNGEON = "Abgabe: Dungeon",
    SHOW_LOCATION = "Ort anzeigen",
    DUNGEON_ENTRANCE = "Dungeoneingang",
    HOW_TO_GET_THERE = "Anreise",
    ROUTE = "Route",
    BACK_TO_DUNGEON = "Zurück zum Dungeon",
    ALLIANCE_ROUTE = "Allianz-Route",
    SHOW_QUEST_CHAIN = "Questreihe anzeigen",
    REQUIRED_QUESTS = "Benötigte Quests",
    REQUIRED_ITEMS = "Benötigte Gegenstände",
    PROVIDED_ITEM = "Bereitgestellter Gegenstand",
    SHOW_WHOLE_CHAIN = "Klicken, um die gesamte Questreihe anzuzeigen",
    OPEN_REQUIRED_CHAIN = "Benötigte Questreihe öffnen.",
    SHOW_GIVER_ON_MAP = "Queststart auf Karte anzeigen",
    MAP_TOOLTIP = "Öffnet das passende Gebiet und markiert den Startpunkt dieser Quest. Rechtsklick auf die Markierung entfernt sie.",
    IN_DUNGEON = "Im Dungeon",
    NO_QUESTS = "Keine Quests",
    NO_FACTION_QUESTS = "Keine %s-Quests für diesen Dungeon erfasst.",
    NO_FACTION_QUESTS_TBD = "Noch keine %s-Quests für diesen Dungeon bekannt. Er ist neu und seine Quests werden noch gesammelt.",
    STEP_ACCEPT_ONLY = "(nur annehmen)",
    LOOT_NOTE_TWO_ITEMS = "Kann 2 Gegenstände droppen",
    LOOT_NOTE_HELNURATH = "Beschworen durch die epische Reittier-Quest der Hexenmeister",
    UNIQUE_TRASH = "Einzigartige Beute von Trashmobs",
    DROPS_FROM = "Beute von: %s",
    CLICK_DUNGEON = "Klicken, um Dungeon-Details zu öffnen",
    HIDE_DUNGEONS = "Dungeons ausblenden",
    LOOT_FILTER = "Beutefilter",
    BUG_REPORT = "Fehler melden",
    BUG_REPORT_SHORT = "Melden",
    BUG_REPORT_TEXT = "Falsche Informationen gefunden oder neue Entdeckungen, die hinzugefügt werden sollten? Bitte melde es auf Discord, Screenshot erforderlich.",
    WM_WORLD_MAP = "Weltkarte",
    WM_DUNGEON_MAP = "Dungeonkarte",
    MINIMAP_HIDE_CONFIRM = "Minimap-Schaltfläche des Dungeon-Journals ausblenden?\n\nMit /dj minimap wird sie wieder angezeigt.",
    LF_SHOW_RECIPES = "Muster-/Rezept-Drops immer anzeigen",
    RESIZE_TIP_TITLE = "Größe ändern",
    RESIZE_TIP = "Ziehen, um die Fenstergröße zu ändern. Rechtsklick zum Zurücksetzen.",
    LF_ENABLE = "Aktivieren",
    LF_DISABLE = "Deaktivieren",
    LF_MIN_LEVEL = "Mindeststufe (benötigt)",
    OPT_UI = "Allgemein",
    OPT_DISCORD_TEXT = "Tritt dem Dungeon Journal Discord bei, um Fehler zu melden, neue Entdeckungen zu teilen und die neuesten News zu erhalten.",
    OPT_DUNGEON_LIST = "Dungeonliste",
    OPT_HIDE_ITEM_LINE = "Journalzeile in Gegenstandstooltips ausblenden",
    OPT_HIDE_ITEM_LINE_TIP = "Entfernt die Zeile, die zeigt, von welchem Boss oder aus welcher Quest ein Gegenstand stammt.",
    MALLET_HOW = "So bekommst du den Hammer",
    OPT_HIDE_MINIMAP = "Minikartenknopf ausblenden",
    OPT_HIDE_MINIMAP_TIP = "Mit /dj minimap holst du den Knopf zurück.",
    OPT_BIND = "Taste: Journal öffnen",
    OPT_BIND_TIP = "Klicken, dann eine Taste drücken. Rechtsklick zum Löschen.",
    OPT_NOT_BOUND = "Nicht belegt",
    OPT_PRESS_KEY = "Taste drücken...",
    OPT_KEY_TAKEN = "%s ist bereits belegt. Wähle eine freie Taste.",
    OPT_NO_COMBAT = "Tastenbelegungen können im Kampf nicht geändert werden.",
    OPT_HIDE_OUTLEVELED = "Zu niedrige Dungeons automatisch ausblenden",
    OPT_HIDE_OUTLEVELED_TIP = "Blendet einen Dungeon aus der Liste aus, sobald deine Stufe über seinem Stufenbereich liegt.",
    OPT_HIDE_QUESTS_DONE = "Dungeons mit allen Quests erledigt ausblenden",
    OPT_HIDE_QUESTS_DONE_TIP = "Blendet einen Dungeon aus der Liste aus, sobald du jede Quest erledigt hast, die dein Charakter dort machen kann.",
    OPT_HIDE_DONE_TICK = "Grünes Häkchen für fertige Dungeons ausblenden",
    OPT_HIDE_DONE_TICK_TIP = "Entfernt das grüne Häkchen auf der Startseite vor der Questanzahl eines Dungeons, dessen Quests du alle erledigt hast.",
    OPT_SHOW_ALL_CLASS = "Alle Klassenquests anzeigen",
    OPT_SHOW_ALL_CLASS_TIP = "Zeigt auch Klassenquests anderer Klassen (zum Beispiel Hexenmeister- oder Paladinquests). Aus: Du siehst nur die Quests deiner eigenen Klasse.",
    OPT_HIDE_LFG = "LFG-Button ausblenden",
    OPT_HIDE_LFG_TIP = "Blendet den Augen-Button neben „Ort anzeigen“ auf Dungeonseiten aus, der die Gruppensuche für diesen Dungeon öffnet. Geht auch per Rechtsklick auf das Auge → Deaktivieren.",
    OPT_HIDE_SLEEPING_BAG = "Schlafsack-Quest ausblenden",
    OPT_HIDE_SLEEPING_BAG_TIP = "Blendet das Schlafsack-Symbol auf der Startseite des Journals aus (neben den Symbolen für WoW Forever und Schlachtzüge). Geht auch per Rechtsklick auf das Symbol → Ausblenden. Eine verfolgte Schlafsack-Questreihe behält ihren Pfeil.",
    OPT_HIDE_DUNGEON_MAP = "Dungeonkarte im Dungeon ausblenden",
    OPT_HIDE_DUNGEON_MAP_TIP = "Wenn aktiviert, zeigt M im Dungeon die normale Karte des Spiels statt der Dungeonkarte des Journals.",
    DESCRIPTION = "Beschreibung",
    MINIMAP_OPTIONS = "Rechtsklick: Optionen",
    LF_ARMOR_ALL = "Alle",
    LF_ARMOR = "Rüstungsfilter",
    LF_WEAPON_ALL = "Alle",
    LF_WEAPON = "Waffenfilter",
    LF_WEAPONS = "Waffen",
    LF_ARMOR_TIP = "Blendet Rüstungsteile anderer Typen aus. Waffen, Schilde, Ringe, Halsketten, Schmuckstücke und Umhänge bleiben immer sichtbar.",
    CHAIN_REQUIRED = "Erfordert zuerst eine Questreihe.",
    CHAIN_STEP = "Du bist bei Schritt %d von %d.",
    SHOW_NEXT_STEP_MAP = "Nächsten Schritt auf Karte zeigen",
    LF_SHOW = "Ergebnisse",
    LF_SHOW_TIP = "Öffnet eine Seite mit allen Bossen aus allen Dungeons, die zur Auswahl passende Beute fallen lassen.",
    LF_RESULTS = "Passende Beute",
    LF_NO_RESULTS = "Keine Gegenstände passen zu diesen Filtern.",
    LF_BACK = "Schließen",
    LF_STAT_STR = "Stärke",
    LF_STAT_AGI = "Beweglichkeit",
    LF_STAT_STA = "Ausdauer",
    LF_STAT_INT = "Intelligenz",
    LF_STAT_SPI = "Willenskraft",
    LF_CLASS_ONLY = "Nur Beute anzeigen, die meine Klasse nutzen kann",
    LF_STATS_HEADER = "Nur Gegenstände mit diesen Werten",
    LF_STATS_HINT = "Gesuchte Werte auswählen. Ohne Auswahl wird alles angezeigt.",
    LF_MATCH_ALL = "Gegenstand muss alle gewählten Werte haben",
    LF_CLEAR = "Leeren",
    OPT_DISCORD_COPY = "Drücke Strg+C, um den Einladungslink zu kopieren.",
    OPT_CLOSE = "Schließen",
    RPG_LOCKED = "Gesperrt",
    RPG_LOCKED_CARD = "Besiege den letzten Boss eines Dungeons, um die Journalseite freizuschalten",
    RPG_PROGRESS_BAR = "Reise %d/%d (%d%%)",
    RPG_LOCKED_MSG = "Dieser Dungeon ist gesperrt. Besiege seinen Endboss, um ihn freizuschalten.",
    RPG_LOCKED_TIP2 = "Besiege den Endboss des Dungeons, um diese Seite freizuschalten.",
    RPG_LOCKED_TIP_TITLE = "Gesperrte Journalseite",
    RPG_LOCKED_TIP = "Besiege %s, den Endboss von %s, um diese Seite freizuschalten.",
    RPG_LOCKED_TIP_POINTS = "Das Freischalten bringt +%d Reisepunkte.",
    RPG_UNLOCKED_MSG = "%s ist jetzt in deinem Journal freigeschaltet!",
    RPG_TOAST_TITLE = "Journalseite freigeschaltet",
    RPG_TOAST_HINT = "Klicken, um sie im Journal zu öffnen",
    RPG_QUEST_TOAST_TITLE = "Dungeonquest freigeschaltet",
    RPG_QUEST_UNLOCKED_MSG = "%s: Quest freigeschaltet! %d/%d",
    RPG_QUEST_TOAST_HINT = "Klicken, um sie im Journal zu öffnen",
    RPG_BOSS_HIDDEN = "Besiege diesen Boss, um ihn aufzudecken.",
    RPG_TRASH_HIDDEN = "Besiege etwa 20 % der Gegner im Dungeon, um es aufzudecken.",
    RPG_QUEST_HIDDEN = "Nimm diese Quest an, um sie freizuschalten.",
    RPG_MAP_LOCKED_TITLE = "Karte gesperrt",
    RPG_MAP_LOCKED_TIP = "Besiege etwa 20 %% der Gegner im Dungeon, um sie freizuschalten: %d/%d.",
    RPG_MAP_LOCKED_MSG = "Die Dungeonkarte wird freigeschaltet, wenn etwa 20 %% der Gegner besiegt sind (%d/%d).",
    RPG_MAP_TOAST_TITLE = "Dungeonkarte freigeschaltet",
    RPG_MAP_UNLOCKED_MSG = "%s: Karte freigeschaltet!",
    RPG_MAP_TOAST_HINT = "Klicken, um die Karte im Journal zu öffnen",
    RPG_MAP_TOAST_HINT_M = "Drücke M im Dungeon, um sie zu sehen",
    RPG_BOSS_REVEALED_MSG = "%s im Journal aufgedeckt!",
    RPG_LOCKED_TIP_QUEST = "Nimmst du eine seiner Quests an, öffnet sich ein Teil davon.",
    RPG_PROGRESS = "Reise %d%%",
    RPG_PROGRESS_TITLE = "Dungeon-Reise",
    RPG_PROGRESS_TIP = "%d von %d Dungeon-Quests für deine Fraktion und Klasse abgeschlossen.",
    RPG_PROGRESS_PAGES = "%d von %d Journalseiten freigeschaltet (Endbosse besiegt).",
    RPG_PROGRESS_POINTS = "Jede Quest bringt %d Punkte, jede Journalseite %d.",
    RPG_SUBTITLE = "Besiege den Endboss eines Dungeons, um seine Seiten freizuschalten",
    MODE_TITLE = "Wähle dein Journal",
    MODE_SUB = "Du kannst das jederzeit in den Optionen (/dj options) oder mit /dj mode ändern.",
    MODE_GAMER = "Gamer-Modus",
    MODE_GAMER_DESC = "Das volle Journal: Jeder Dungeon, Boss, jede Beute und Quest ist von Anfang an offen.",
    MODE_RPG = "RPG-Modus",
    MODE_RPG_DESC = "Dungeons sind zu Beginn gesperrt und werden freigeschaltet, wenn du ihren Endboss besiegst. Ein Fortschrittsbalken zeigt alle abgeschlossenen Dungeon-Quests.",
    MODE_CHOOSE = "Wählen",
    RPG_CONFIRM_TEXT = "In diesem Modus bleiben Dungeons gesperrt, bis du den Endboss besiegst. Du kannst den Modus jederzeit in den Optionen ändern.",
    RPG_CONFIRM_OK = "Ok",
    RPG_CONFIRM_BACK = "Erneut wählen",
    RPG_INTRO_TEXT = "Dungeons bleiben gesperrt, bis du ihren Endboss besiegst.",
    RPG_INTRO_KEEP = "RPG-Modus behalten",
    RPG_INTRO_OPTIONS = "In den Optionen deaktivieren",
    MODE_RPG_ENABLE = "In den Optionen aktivieren",
    COMING_SOON = "Demnächst",
    PREVIEW_DATA_SOON = "Boss-, Beute- und Questdaten folgen bald.",
    PREVIEW_MAP_CLICK = "Klicken, um die Karte anzusehen.",
    ITEM_CLICK_MAP = "Klicken, um den Ort auf der Karte zu zeigen.",
    REPEAT_SHOW = "Wiederholbare Quests anzeigen (%d)",
    REPEAT_HIDE = "Wiederholbare Quests ausblenden (%d)",
    OPT_SHOW_ALL_PROF = "Alle Berufsquests anzeigen",
    OPT_SHOW_ALL_PROF_TIP = "Zeigt auch Berufsquests (Schmiedekunst, Bergbau...) für Berufe, die dieser Charakter nicht hat.",
    OPT_FOREVER_ONLY = "Nur Forever-Dungeons",
    OPT_FOREVER_ONLY_TIP = "Zeigt nur die Dungeons, die neu in WoW Forever sind. Wie ein Klick auf das WoW-Forever-Emblem oben links in der Dungeonliste: Haken entfernen, um wieder alle Dungeons zu sehen.",
    PROF_BLACKSMITHING = "Schmiedekunst",
    PROF_MINING = "Bergbau",
    RAIDS_TITLE = "Schlachtzüge",
    ITEM_UNSEEN_TITLE = "Noch nicht gesehen",
    ITEM_UNSEEN_TIP = "Dieser Gegenstand ist im Spiel, aber der Server hat seine Details noch nicht gesendet. Sie erscheinen, sobald jemand ihn gesehen hat (zum Beispiel, nachdem er gedroppt ist).",
    FOREVER_FILTER_TITLE = "WoW-Forever-Dungeons",
    FOREVER_FILTER_TIP = "Klicken, um nur die Dungeons anzuzeigen, die neu in WoW Forever sind.",
    FOREVER_FILTER_ON = "Es werden nur WoW-Forever-Dungeons angezeigt. Klicken, um wieder alle Dungeons anzuzeigen.",
    OPT_RPG_MODE = "RPG-Modus",
    OPT_RPG_MODE_TIP = "Dungeons bleiben gesperrt, bis dieser Charakter ihren Endboss besiegt; ein Fortschrittsbalken zeigt deine Dungeon-Quests.",
    OPT_VERSION = "Version: %s",
    OPT_ACCESS = "Optionen mit %s öffnen",
    OPT_OPEN_OPTIONS = "Optionen öffnen",
    OPT_COPY = "Kopieren",
    OPT_COPIED = "Kopiert!",
    OPT_TAB_OPTIONS = "Optionen",
    OPT_DISCORD = "Discord",
    LF_OK = "Ok",
    LF_HIDDEN_NOTE = "%d vom Beutefilter ausgeblendet",
    RECIPES_SECTION = "Rezepte & Muster (%d)",
    SHARED_SHOW = "Geteilte Beute anzeigen (%d)",
    SHARED_HIDE = "Geteilte Beute ausblenden (%d)",
    PROBABLE_LOOT = "Nicht bestätigt, aber wahrscheinlicher Drop (%d)",
    SHARED_NOTE = "geringe Dropchance, viele Bosse",
    SHARED_LOOT = "Geteilte Beute",
    SEVERAL_DUNGEONS = "mehrere Dungeons",
    LF_STAT_HEAL = "Heilung",
    LF_STAT_SPELL = "Zauberschaden",
    LF_STAT_AP = "Angriffskraft",
    LF_STAT_CRIT = "Kritischer Treffer",
    LF_STAT_SPELLCRIT = "Zauberkrit",
    LF_STAT_HIT = "Trefferchance",
    LF_STAT_SPELLHIT = "Zaubertreffer",
    LF_STAT_MP5 = "MP5",
    LF_STAT_MP5_TIP = "Mana alle 5 Sekunden",
    LF_STAT_HP5 = "HP5",
    LF_STAT_HP5_TIP = "Gesundheit alle 5 Sekunden",
    LF_ARMOR_BTN = "Rüstung",
    LF_RING = "Ring",
    LF_NECK = "Hals",
    LF_TRINKET = "Schmuck",
    LF_CLOAK = "Umhang",
    LF_WEAPON_BTN = "Waffe",
    LF_RESIST = "Widerstandsfilter",
    LF_RESISTANCES = "Widerstände",
    LF_RES_FIRE = "Feuer",
    LF_RES_HOLY = "Heilig",
    LF_SCHOOLS = "Zauberschulen",
    LF_RES_FROST = "Frost",
    LF_RES_NATURE = "Natur",
    LF_RES_SHADOW = "Schatten",
    LF_RES_ARCANE = "Arkan",
    LF_STAT_DEF = "Verteidigungswertung",
    DONE = "Fertig",
    HIDDEN = "Ausgeblendet",
    CLICK_HIDE_DUNGEON = "Klicken, um diesen Dungeon auszublenden.",
    CLICK_RESTORE_DUNGEON = "Klicken, um diesen Dungeon wieder einzublenden.",
    ALL_DUNGEONS_HIDDEN = "Alle Dungeons sind ausgeblendet. Klicke auf Dungeons ausblenden, um sie wieder einzublenden.",
    FACTION_QUESTS = "%s-Quests",
    QUEST_IN_LOG = "Diese frühere Quest befindet sich in deinem Questlog.",
    QUEST_COMPLETED = "Diese frühere Quest wurde abgeschlossen.",
    QUEST_NOT_CACHED = "Der Questtext ist derzeit nicht im Client-Cache.",
    CLASS_ONLY = "NUR %s",
    MINIMAP_HIDDEN = "Minimap-Schaltfläche ausgeblendet. Mit /dj minimap wieder anzeigen.",
    MINIMAP_LEFT = "Linksklick: Öffnen / schließen",
    MINIMAP_DRAG = "Ziehen: Verschieben",
    MINIMAP_RIGHT = "Rechtsklick: Ausblenden",
    LANGUAGE_CURRENT = "Sprache: %s",
    LANGUAGE_SET = "Sprache auf %s gesetzt.",
    LANGUAGE_AUTO = "Automatisch (%s)",
    LANGUAGE_HELP = "Sprachtest: /dj lang de, fr, es, ru, it, pt, en oder auto",
    UPDATE_AVAILABLE = "Version %s ist verfügbar (du hast %s). Aktualisiere über CurseForge.",
    PREVIOUS_QUEST = "Vorherige Quest",
    REQUIRES_QUEST = "Erfordert: %s",
    NEXT_QUEST = "Nächste Quest",
    LEADS_TO = "Führt zu: %s",
    MAP_MARKER_REMOVED = "Kartenmarkierung entfernt.",
    MAP_LEFT_TARGET = "Linksklick, um den Questgeber in der Nähe anzuvisieren und zu markieren",
    MAP_RIGHT_REMOVE = "Rechtsklick zum Entfernen der Markierung",
    MAP_PATROL = "Läuft umher: die Linie zeigt den Weg",
    MAP_QUEST_TARGET = "Questziel",
    MAP_MARKED = "%s auf der Karte markiert.",
    MAP_OPEN_FAILED = "Der gespeicherte Kartenort konnte nicht geöffnet werden.",
    MAP_COMBAT = "Die Karte lässt sich im Kampf nicht öffnen. Drücke %s, um die markierte Stelle zu sehen.",
    QUEST_GIVER = "Questgeber",
    QUEST_STARTS_HERE = "Quest startet hier",
    TRACK = "Verfolgen",
    TRACKING = "Verfolgt",
    TRACK_TIP = "Zeigt die Quests dieses Dungeons mit deinem Fortschritt auf dem Bildschirm. Lässt sich überallhin ziehen.",
    TRACK_STOP = "Nicht mehr verfolgen",
    TRACK_READY = "Bereit zur Abgabe",
    TRACK_DONE = "Abgeschlossen",
    TRACK_IN_LOG = "In deinem Questlog",
    TRACK_CLICK = "Klicken, um sie im Journal zu öffnen",
    TURN_IN_HERE = "Hier abgeben",
    TRACK_ACCEPT = "Klicken, um die Quest anzunehmen",
}

local function NormalizeLanguage(value)
    value = tostring(value or "auto"):lower()
    if value == "de" or value == "dede" or value == "german" or value == "deutsch" then return "deDE" end
    if value == "fr" or value == "frfr" or value == "french" or value == "français" or value == "francais" then return "frFR" end
    if value == "es" or value == "eses" or value == "esmx" or value == "spanish" or value == "español" or value == "espanol" then return "esES" end
    if value == "ru" or value == "ruru" or value == "russian" or value == "русский" then return "ruRU" end
    if value == "it" or value == "itit" or value == "italian" or value == "italiano" then return "itIT" end
    if value == "zhtw" or value == "tw" or value == "繁體中文" or value == "繁体中文" then return "zhTW" end
    if value == "zh" or value == "zhcn" or value == "chinese" or value == "中文" or value == "简体中文" then return "zhCN" end
    if value == "ko" or value == "kokr" or value == "korean" or value == "한국어" then return "koKR" end
    if value == "pt" or value == "ptbr" or value == "portuguese" or value == "portugues" or value == "português" then return "ptBR" end
    if value == "en" or value == "enus" or value == "engb" or value == "english" then return "enUS" end
    return "auto"
end

function FDJ.GetLanguage()
    ForeverDungeonJournalDB = ForeverDungeonJournalDB or {}
    local override = NormalizeLanguage(ForeverDungeonJournalDB.language)
    if override ~= "auto" then return override end
    local client = type(GetLocale) == "function" and GetLocale() or "enUS"
    if client == "deDE" then return "deDE" end
    if client == "frFR" then return "frFR" end
    if client == "esES" or client == "esMX" then return "esES" end
    if client == "ruRU" then return "ruRU" end
    if client == "itIT" then return "itIT" end
    if client == "ptBR" then return "ptBR" end
    if client == "koKR" then return "koKR" end
    if client == "zhCN" then return "zhCN" end
    if client == "zhTW" then return "zhTW" end
    return "enUS"
end

function FDJ.SetLanguage(value)
    ForeverDungeonJournalDB = ForeverDungeonJournalDB or {}
    ForeverDungeonJournalDB.language = NormalizeLanguage(value)
    return FDJ.GetLanguage(), ForeverDungeonJournalDB.language
end

function FDJ.L(key, ...)
    local lang = FDJ.GetLanguage()
    local active = FDJ.Locales[lang] or FDJ.Locales.enUS
    local value = active[key] or FDJ.Locales.enUS[key] or key
    if select("#", ...) > 0 then
        local ok, formatted = pcall(string.format, value, ...)
        if ok then return formatted end
    end
    return value
end


function FDJ.GetClientLanguage()
    local client = type(GetLocale) == "function" and GetLocale() or "enUS"
    if client == "deDE" then return "deDE" end
    if client == "frFR" then return "frFR" end
    if client == "esES" or client == "esMX" then return "esES" end
    if client == "ruRU" then return "ruRU" end
    if client == "itIT" then return "itIT" end
    if client == "ptBR" then return "ptBR" end
    if client == "koKR" then return "koKR" end
    if client == "zhCN" then return "zhCN" end
    if client == "zhTW" then return "zhTW" end
    return "enUS"
end

-- Client-provided quest/item strings are already localized, but only to the
-- actual WoW client language. When /dj lang forces a different language for
-- testing, use our content table instead of mixing English client text into it.
function FDJ.CanUseClientLocalizedText()
    return FDJ.GetLanguage() == FDJ.GetClientLanguage()
end

local function ContentTable()
    local all = FDJ.ContentLocales or {}
    return all[FDJ.GetLanguage()]
end

-- Free text is only ever translated as a WHOLE string or as whole
-- comma-separated parts ("Tinkmaster Overspark, Ironforge" -> the place part).
-- Words are never swapped inside a sentence: a sentence without a full
-- translation stays in English instead of becoming a half-translated mix.
local plainMapCache = {}
local function PlainText(pattern)
    return (pattern:gsub("%%(%p)", "%1"))
end
local function FreeTextMap(content, lang)
    local cached = plainMapCache[lang]
    if cached and cached.source == content then return cached.map end
    local map = {}
    for key, value in pairs(content.places or {}) do map[key] = value end
    for _, pair in ipairs(content.replacements or {}) do
        local key = PlainText(pair[1])
        if map[key] == nil then map[key] = (pair[2]:gsub("%%%%", "%%")) end
    end
    plainMapCache[lang] = { source = content, map = map }
    return map
end

function FDJ.LocalizeFreeText(value)
    if type(value) ~= "string" or value == "" then return value end
    local content = ContentTable()
    if not content then return value end
    local map = FreeTextMap(content, FDJ.GetLanguage())
    if map[value] then return map[value] end

    -- Whole parts separated by " — " (label lines) or commas (NPC, place).
    local function TranslateCommaList(text)
        if map[text] then return map[text], true end
        if not text:find(",", 1, true) then return text, false end
        local parts, changed = {}, false
        for part in text:gmatch("([^,]+)") do
            local clean = part:gsub("^%s+", ""):gsub("%s+$", "")
            local translated = map[clean]
            if translated then changed = true end
            parts[#parts + 1] = translated or clean
        end
        return table.concat(parts, ", "), changed
    end

    local dash = " \226\128\148 " -- " — "
    if value:find(dash, 1, true) then
        local out, changed, rest = {}, false, value
        while true do
            local i = rest:find(dash, 1, true)
            local piece = i and rest:sub(1, i - 1) or rest
            local t, c = TranslateCommaList(piece)
            out[#out + 1] = t
            changed = changed or c
            if not i then break end
            rest = rest:sub(i + #dash)
        end
        if changed then return table.concat(out, dash) end
        return value
    end

    local t, changed = TranslateCommaList(value)
    if changed then return t end
    return value
end


-- Reputation reward names need their own localization pass because reward
-- summaries store them together with the amount (for example
-- "Ironforge +100").  Localize the faction name before rebuilding that token
-- instead of requiring a translation entry for every possible amount.
local REPUTATION_NAMES = {
    deDE = {
        ["Gadgetzan"] = "Gadgetzan",
        ["Kirin Tor"] = "Kirin Tor",
        ["Gnomeregan Exiles"] = "Gnomeregangnome",
        ["Argent Dawn"] = "Argentumdämmerung",
        ["Darnassus"] = "Darnassus",
        ["Darkspear Trolls"] = "Dunkelspeertrolle",
        ["Earthen Ring"] = "Der Irdene Ring",
        ["Orgrimmar"] = "Orgrimmar",
        ["Stormwind"] = "Sturmwind",
        ["Ironforge"] = "Eisenschmiede",
        ["Thunder Bluff"] = "Donnerfels",
        ["Undercity"] = "Unterstadt",
    },
    frFR = {
        ["Gadgetzan"] = "Gadgetzan",
        ["Kirin Tor"] = "Kirin Tor",
        ["Gnomeregan Exiles"] = "Exilés de Gnomeregan",
        ["Argent Dawn"] = "Aube d'argent",
        ["Darnassus"] = "Darnassus",
        ["Darkspear Trolls"] = "Trolls Sombrelance",
        ["Earthen Ring"] = "Cercle terrestre",
        ["Orgrimmar"] = "Orgrimmar",
        ["Stormwind"] = "Hurlevent",
        ["Ironforge"] = "Forgefer",
        ["Thunder Bluff"] = "Pitons-du-Tonnerre",
        ["Undercity"] = "Fossoyeuse",
    },
    esES = {
        ["Gadgetzan"] = "Gadgetzan",
        ["Kirin Tor"] = "Kirin Tor",
        ["Gnomeregan Exiles"] = "Exiliados de Gnomeregan",
        ["Argent Dawn"] = "Alba Argenta",
        ["Darnassus"] = "Darnassus",
        ["Darkspear Trolls"] = "Trols Lanza Negra",
        ["Earthen Ring"] = "Anillo de la Tierra",
        ["Orgrimmar"] = "Orgrimmar",
        ["Stormwind"] = "Ventormenta",
        ["Ironforge"] = "Forjaz",
        ["Thunder Bluff"] = "Cima del Trueno",
        ["Undercity"] = "Entrañas",
    },
    itIT = {
        ["Gadgetzan"] = "Gadgetzan",
        ["Kirin Tor"] = "Kirin Tor",
        ["Gnomeregan Exiles"] = "Esuli di Gnomeregan",
        ["Argent Dawn"] = "Alba d'Argento",
        ["Darnassus"] = "Darnassus",
        ["Darkspear Trolls"] = "Troll Lanciascura",
        ["Earthen Ring"] = "Circolo della Terra",
        ["Orgrimmar"] = "Orgrimmar",
        ["Stormwind"] = "Roccavento",
        ["Ironforge"] = "Forgiardente",
        ["Thunder Bluff"] = "Picco del Tuono",
        ["Undercity"] = "Sepulcra",
    },
    ptBR = {
        ["Gadgetzan"] = "Geringontzan",
        ["Kirin Tor"] = "Kirin Tor",
        ["Gnomeregan Exiles"] = "Exilados de Gnomeregan",
        ["Argent Dawn"] = "Aurora Argêntea",
        ["Darnassus"] = "Darnassus",
        ["Darkspear Trolls"] = "Trolls Lançanegra",
        ["Earthen Ring"] = "Harmonia Telúrica",
        ["Orgrimmar"] = "Orgrimmar",
        ["Stormwind"] = "Ventobravo",
        ["Ironforge"] = "Altaforja",
        ["Thunder Bluff"] = "Penhasco do Trovão",
        ["Undercity"] = "Cidade Baixa",
    },
    ruRU = {
        ["Gadgetzan"] = "Прибамбасск",
        ["Kirin Tor"] = "Kirin Tor",
        ["Gnomeregan Exiles"] = "Изгнанники Гномрегана",
        ["Argent Dawn"] = "Серебряный Рассвет",
        ["Darnassus"] = "Дарнас",
        ["Darkspear Trolls"] = "Тролли Черного Копья",
        ["Earthen Ring"] = "Служители Земли",
        ["Orgrimmar"] = "Оргриммар",
        ["Stormwind"] = "Штормград",
        ["Ironforge"] = "Стальгорн",
        ["Thunder Bluff"] = "Громовой Утёс",
        ["Undercity"] = "Подгород",
    },
    koKR = {
        ["Gadgetzan"] = "가젯잔",
        ["Kirin Tor"] = "Kirin Tor",
        ["Gnomeregan Exiles"] = "놈리건 추방자",
        ["Argent Dawn"] = "은빛 여명회",
        ["Darnassus"] = "다르나서스",
        ["Darkspear Trolls"] = "검은창 트롤",
        ["Earthen Ring"] = "대지 고리회",
        ["Orgrimmar"] = "오그리마",
        ["Stormwind"] = "스톰윈드",
        ["Ironforge"] = "아이언포지",
        ["Thunder Bluff"] = "썬더 블러프",
        ["Undercity"] = "언더시티",
    },
    zhCN = {
        ["Gadgetzan"] = "加基森",
        ["Kirin Tor"] = "Kirin Tor",
        ["Gnomeregan Exiles"] = "诺莫瑞根流亡者",
        ["Argent Dawn"] = "银色黎明",
        ["Darnassus"] = "达纳苏斯",
        ["Darkspear Trolls"] = "暗矛巨魔",
        ["Earthen Ring"] = "大地之环",
        ["Orgrimmar"] = "奥格瑞玛",
        ["Stormwind"] = "暴风城",
        ["Ironforge"] = "铁炉堡",
        ["Thunder Bluff"] = "雷霆崖",
        ["Undercity"] = "幽暗城",
    },
    zhTW = {
        ["Gadgetzan"] = "加基森",
        ["Kirin Tor"] = "Kirin Tor",
        ["Gnomeregan Exiles"] = "諾姆瑞根流亡者",
        ["Argent Dawn"] = "銀色黎明",
        ["Darnassus"] = "達納蘇斯",
        ["Darkspear Trolls"] = "暗矛食人妖",
        ["Earthen Ring"] = "大地之環",
        ["Orgrimmar"] = "奧格瑪",
        ["Stormwind"] = "暴風城",
        ["Ironforge"] = "鐵爐堡",
        ["Thunder Bluff"] = "雷霆崖",
        ["Undercity"] = "幽暗城",
    },
}

function FDJ.LocalizeReputationName(name)
    if type(name) ~= "string" or name == "" then return name end
    local names = REPUTATION_NAMES[FDJ.GetLanguage()]
    if names and names[name] then return names[name] end
    -- Keep this fallback so any future reputation name already present in the
    -- general content tables still localizes without another code change.
    return FDJ.LocalizeFreeText(name)
end

function FDJ.LocalizeDungeonName(internalName)
    local content = ContentTable()
    local entry = content and content.dungeons and content.dungeons[internalName]
    return (entry and entry.name) or internalName
end

function FDJ.LocalizeDungeonField(internalName, field, fallback)
    local content = ContentTable()
    local entry = content and content.dungeons and content.dungeons[internalName]
    local value = entry and entry[field]
    if value and value ~= "" then return value end
    return FDJ.LocalizeFreeText(fallback)
end

function FDJ.LocalizeQuestField(questID, field, fallback)
    local content = ContentTable()
    local entry = content and content.quests and content.quests[questID]
    local value = entry and entry[field]
    if value and value ~= "" then return value end
    return FDJ.LocalizeFreeText(fallback)
end

function FDJ.LocalizeBossName(name)
    if name == "Recipes & Patterns" then
        -- Reuse the translated divider text ("Recipes & Patterns (%d)") without its count.
        local text = FDJ.L("RECIPES_SECTION", 0):gsub("%s*%(0%)%s*", "")
        return text
    end
    local content = ContentTable()
    local value = content and content.bosses and content.bosses[name]
    return value or FDJ.LocalizeFreeText(name)
end

function FDJ.LocalizeItemSlot(slotText)
    if type(slotText) ~= "string" or slotText == "" then return slotText end
    local content = ContentTable()
    if not content or not content.slotParts then return slotText end

    -- Item categories in the database are comma-separated canonical tokens
    -- (for example "Shoulder, Leather" or "One-Hand, Dagger"). Translate
    -- each complete token instead of doing substring replacements. This avoids
    -- partial/ordering edge cases and guarantees mixed strings are fully
    -- localized.
    local translated = {}
    for token in slotText:gmatch("([^,]+)") do
        local clean = token:gsub("^%s+", ""):gsub("%s+$", "")
        translated[#translated + 1] = content.slotParts[clean] or clean
    end
    if #translated > 1 then
        return table.concat(translated, ", ")
    elseif #translated == 1 then
        return translated[1]
    end

    return content.slotParts[slotText] or slotText
end

function FDJ.LocalizeMapLocation(loc)
    if type(loc) ~= "table" then return loc end
    if FDJ.GetLanguage() == "enUS" then return loc end
    -- Do not mutate the database table; MapMarkers may retain it after a click.
    return {
        mapID = loc.mapID,
        x = loc.x,
        y = loc.y,
        label = FDJ.LocalizeFreeText(loc.label),
        detail = FDJ.LocalizeFreeText(loc.detail),
    }
end
