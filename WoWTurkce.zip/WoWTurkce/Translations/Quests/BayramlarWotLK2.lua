-- WotLK bayram görevleri 2
-- b=başlık, a=açıklama, h=hedef, i=ilerleme, t=tamamlama
-- k = çevrilen İngilizce metnin parmak izi (metin değişirse çeviri gösterilmez, yeniden kaydedilir)
local V = WoWTurkce.Veri

V[13495] = { b="Aleve Saygı Göster", t="Dragonblight alevine saygı göster.", k={b=427467665, t=1842947270} }
V[13496] = { b="Aleve Saygı Göster", t="Howling Fjord alevine saygı göster.", k={b=427467665, t=509256158} }
V[13497] = { b="Aleve Saygı Göster", t="Grizzly Hills alevine saygı göster.", k={b=427467665, t=1738286248} }
V[13498] = { b="Aleve Saygı Göster", t="Storm Peaks alevine saygı göster.", k={b=427467665, t=1700100122} }
V[13499] = { b="Aleve Saygı Göster", t="Crystalsong Forest alevine saygı göster.", k={b=427467665, t=2120447005} }
V[13500] = { b="Aleve Saygı Göster", t="Zul'Drak alevine saygı göster.", k={b=427467665, t=3936107502} }
V[13501] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13548] = { b="Şeker Kovası", t="Bunun gibi şeker kovaları diyarlardaki tüm hanlarda bulunur. Hadi çekinme... biraz al!", k={b=2899454418, t=555881347} }
V[13966] = { b="Bir Kış Örtüsü Hediyesi", k={b=3222383993} }
