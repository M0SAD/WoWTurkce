-- BetterFishing arayüz çevirisi
local G = WoWTurkce
local A = G.Arayuz
local function e(k, v) if A[k] == nil then A[k] = v end end
e("Always Auto Loot fishing loot (Ignores Settings)", "Balık ganimetini her zaman otomatik topla (ayarları yok sayar)")
e("Auto-Hide NPC Nameplates and Names (except Hostile) while fishing", "Balık tutarken NPC isim plakalarını ve adlarını otomatik gizle (düşmanlar hariç)")
e("Enhance Sounds", "Sesleri Güçlendir")
e("Double-click to cast", "Atmak için çift tıkla")
e("Allow double-clicking to cast while mounted", "Binekteyken çift tıklayarak atmaya izin ver")
e("Double-click to recast while fishing (modifier key hooks); inverted when off", "Balık tutarken çift tıklayarak yeniden at (değiştirici tuş bağlantıları); kapalıyken tersine döner")
e("Allow fishing while the \"Looking for Lunkers\" (Dragonflight) buff is active", "\"Looking for Lunkers\" (Dragonflight) buffı etkinken balık tutmaya izin ver")
e("Disable icon above bobber (visibility varies by nameplate addon)", "Şamandıranın üstündeki simgeyi kapat (görünürlük isim plakası eklentisine göre değişir)")
e("Cast and Interact", "At ve Etkileşime Geç")
_G.BINDING_NAME_BETTERFISHINGKEY = "At ve Etkileşime Geç"
e("Single Keybind/Double Click Fishing and Enhanced Sound while fishing", "Tek tuşla / çift tıkla balık tutma ve balık tutarken güçlendirilmiş ses")
e("Slash command: /bf, /betterfishing", "Komut: /bf, /betterfishing")
