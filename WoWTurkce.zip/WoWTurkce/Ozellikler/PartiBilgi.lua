-- Parti çerçevelerinin üstünde oyuncunun seviyesini ve sınıfını gösterir (ayarlardan kapatılabilir).
local G = WoWTurkce

local SINIF = {
	WARRIOR = "Warrior", PALADIN = "Paladin", HUNTER = "Hunter", ROGUE = "Rogue", PRIEST = "Priest",
	SHAMAN = "Shaman", MAGE = "Mage", WARLOCK = "Warlock", DRUID = "Druid", DEATHKNIGHT = "Death Knight",
	MONK = "Monk", DEMONHUNTER = "Demon Hunter", EVOKER = "Evoker",
}

local yazilar = {}

local function cerceveler()
	local liste = {}
	for i = 1, 4 do
		local f = (PartyFrame and PartyFrame["MemberFrame" .. i]) or _G["PartyMemberFrame" .. i]
		if f then liste[#liste + 1] = { f, "party" .. i } end
	end
	return liste
end

local function metin(birim)
	if not UnitExists(birim) then return nil end
	local sv = UnitLevel(birim)
	local _, token = UnitClass(birim)
	if G.gizli(sv) or G.gizli(token) then return nil end
	local sinif = token and (SINIF[token] or token) or ""
	local r, g, b = 1, 0.82, 0
	local c = token and RAID_CLASS_COLORS and RAID_CLASS_COLORS[token]
	if c then r, g, b = c.r, c.g, c.b end
	local sev = (sv and sv > 0) and ("Level " .. sv) or "Level ??"
	return sev .. " " .. sinif, r, g, b
end

local function guncelle()
	local ac = G.ayar("partiBilgi") and G.ayar("acik") ~= false
	for _, p in ipairs(cerceveler()) do
		local f, birim = p[1], p[2]
		local fs = yazilar[birim]
		if not fs then
			fs = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
			fs:SetPoint("BOTTOMLEFT", f, "TOPLEFT", 58, -4)
			fs:SetJustifyH("LEFT")
			yazilar[birim] = fs
		end
		local t, r, g, b
		if ac then t, r, g, b = metin(birim) end
		if t and f:IsShown() then
			fs:SetText(t); fs:SetTextColor(r, g, b); fs:Show()
		else
			fs:Hide()
		end
	end
end

G.basla(function()
	local f = CreateFrame("Frame")
	for _, e in ipairs({ "PLAYER_ENTERING_WORLD", "GROUP_ROSTER_UPDATE", "UNIT_LEVEL", "UNIT_NAME_UPDATE", "PARTY_MEMBER_ENABLE" }) do
		pcall(f.RegisterEvent, f, e)
	end
	f:SetScript("OnEvent", function() pcall(guncelle); C_Timer.After(1, function() pcall(guncelle) end) end)
	G.dinle(function(k) if k == "partiBilgi" or k == "acik" then pcall(guncelle) end end)
	C_Timer.NewTicker(5, function() pcall(guncelle) end)
	pcall(guncelle)
end)
