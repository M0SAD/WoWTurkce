-- Classic Forever veritabanında olup klasik veritabanında olmayan eşya, nesne ve NPC alt başlıkları.
local E, A, N, U = WoWTurkce.EsyaAdi, WoWTurkce.Arayuz, WoWTurkce.Nesne, WoWTurkce.NpcAltBaslik
local function n(en, tr) if A[en] == nil then A[en] = tr end if N[en] == nil then N[en] = tr end end
local function u(en, tr) if A[en] == nil then A[en] = tr end if U[en] == nil then U[en] = tr end end
if E["\"Gold\""] == nil then E["\"Gold\""] = "\"Altın\"" end
if E["\"Secret\" Bait"] == nil then E["\"Secret\" Bait"] = "\"Gizli\" Yem" end
if E["9-60 Battery Pack"] == nil then E["9-60 Battery Pack"] = "9-60 Pil Paketi" end
if E["A Footman's Copper Coin"] == nil then E["A Footman's Copper Coin"] = "Bir Piyadenin Bakır Sikkesi" end
if E["A Little Somethin'"] == nil then E["A Little Somethin'"] = "Ufak Bi' Şey" end
if E["A Luddite's Guide to Caring for Your Demonic Pet"] == nil then E["A Luddite's Guide to Caring for Your Demonic Pet"] = "Teknoloji Karşıtları İçin İblis Evcil Hayvan Bakım Rehberi" end
if E["A Web of Lies: Debunking Myths and Legends"] == nil then E["A Web of Lies: Debunking Myths and Legends"] = "Yalanlar Ağı: Mitleri ve Efsaneleri Çürütmek" end
if E["A'sharahm, the Roiling Tempest"] == nil then E["A'sharahm, the Roiling Tempest"] = "A'sharahm, Kabaran Fırtına" end
if E["Abigail's Hope"] == nil then E["Abigail's Hope"] = "Abigail'in Umudu" end
if E["Acid-Etched Blade"] == nil then E["Acid-Etched Blade"] = "Asitle Oyulmuş Kılıç" end
if E["Acolyte's Boots"] == nil then E["Acolyte's Boots"] = "Mürit Çizmeleri" end
if E["Acolyte's Chain Belt"] == nil then E["Acolyte's Chain Belt"] = "Mürit Zincir Kemeri" end
if E["Acolyte's Chain Helm"] == nil then E["Acolyte's Chain Helm"] = "Mürit Zincir Miğferi" end
if E["Acolyte's Chain Leggings"] == nil then E["Acolyte's Chain Leggings"] = "Mürit Zincir Tozlukları" end
if E["Acolyte's Chain Shirt"] == nil then E["Acolyte's Chain Shirt"] = "Mürit Zincir Gömleği" end
if E["Acolyte's Gloves"] == nil then E["Acolyte's Gloves"] = "Mürit Eldivenleri" end
if E["Acolyte's Pants"] == nil then E["Acolyte's Pants"] = "Mürit Pantolonu" end
if E["Acolyte's Robe"] == nil then E["Acolyte's Robe"] = "Mürit Cübbesi" end
if E["Acolyte's Shirt"] == nil then E["Acolyte's Shirt"] = "Mürit Gömleği" end
if E["Acolyte's Shoes"] == nil then E["Acolyte's Shoes"] = "Mürit Ayakkabıları" end
if E["Acolyte's Silvered Chain Helm"] == nil then E["Acolyte's Silvered Chain Helm"] = "Mürit Gümüşlü Zincir Miğferi" end
if E["Acolyte's Silvered Chain Leggings"] == nil then E["Acolyte's Silvered Chain Leggings"] = "Mürit Gümüşlü Zincir Tozlukları" end
if E["Acolyte's Silvered Chain Shirt"] == nil then E["Acolyte's Silvered Chain Shirt"] = "Mürit Gümüşlü Zincir Gömleği" end
if E["Adept's Cloak"] == nil then E["Adept's Cloak"] = "Usta Çırak Pelerini" end
if E["Admiral Proudmoore's Orders"] == nil then E["Admiral Proudmoore's Orders"] = "Amiral Proudmoore'un Emirleri" end
if E["Adventurer's Cloak"] == nil then E["Adventurer's Cloak"] = "Maceracı Pelerini" end
if E["Adventurer's Lost Boots"] == nil then E["Adventurer's Lost Boots"] = "Maceracının Kayıp Çizmeleri" end
if E["Advisor Emerson's Instructions"] == nil then E["Advisor Emerson's Instructions"] = "Danışman Emerson'ın Talimatları" end
if E["Advisor Nazgrel's Instructions"] == nil then E["Advisor Nazgrel's Instructions"] = "Danışman Nazgrel'in Talimatları" end
if E["Aegwynn's Silver Coin"] == nil then E["Aegwynn's Silver Coin"] = "Aegwynn'in Gümüş Sikkesi" end
if E["Agamaggan's Roar"] == nil then E["Agamaggan's Roar"] = "Agamaggan'ın Kükreyişi" end
if E["Aggor's Belt"] == nil then E["Aggor's Belt"] = "Aggor'un Kemeri" end
if E["Aggor's Refitted Belt"] == nil then E["Aggor's Refitted Belt"] = "Aggor'un Yenilenmiş Kemeri" end
if E["Airy Magister's Shirt"] == nil then E["Airy Magister's Shirt"] = "Havadar Magister Gömleği" end
if E["Airy Peacekeeper's Shirt"] == nil then E["Airy Peacekeeper's Shirt"] = "Havadar Barış Muhafızı Gömleği" end
if E["Airy Skyseer's Shirt"] == nil then E["Airy Skyseer's Shirt"] = "Havadar Gökgören Gömleği" end
if E["Airy Windseeker's Shirt"] == nil then E["Airy Windseeker's Shirt"] = "Havadar Rüzgârarayan Gömleği" end
if E["Aka'rai's Tattered Vestments"] == nil then E["Aka'rai's Tattered Vestments"] = "Aka'rai'nin Yırtık Giysileri" end
if E["Al'Aketh Cultist's Ear"] == nil then E["Al'Aketh Cultist's Ear"] = "Al'Aketh Tarikatçı Kulağı" end
if E["Al'Aketh Handwraps"] == nil then E["Al'Aketh Handwraps"] = "Al'Aketh El Sargıları" end
if E["Al'Aketh Legguards"] == nil then E["Al'Aketh Legguards"] = "Al'Aketh Bacak Koruyucuları" end
if E["Al'Aketh Vestments"] == nil then E["Al'Aketh Vestments"] = "Al'Aketh Giysileri" end
if E["Al'Aketh Windstone Charm"] == nil then E["Al'Aketh Windstone Charm"] = "Al'Aketh Rüzgâr Taşı Tılsımı" end
if E["Al'Aketh Zealot's Belt"] == nil then E["Al'Aketh Zealot's Belt"] = "Al'Aketh Fanatik Kemeri" end
if E["Al'Aketh Zealot's Boots"] == nil then E["Al'Aketh Zealot's Boots"] = "Al'Aketh Fanatik Çizmeleri" end
if E["Al'Aketh Zealot's Cloak"] == nil then E["Al'Aketh Zealot's Cloak"] = "Al'Aketh Fanatik Pelerini" end
if E["Al'Aketh Zealot's Gloves"] == nil then E["Al'Aketh Zealot's Gloves"] = "Al'Aketh Fanatik Eldivenleri" end
if E["Al'Aketh Zealot's Helm"] == nil then E["Al'Aketh Zealot's Helm"] = "Al'Aketh Fanatik Miğferi" end
if E["Al'Aketh Zealot's Leggings"] == nil then E["Al'Aketh Zealot's Leggings"] = "Al'Aketh Fanatik Tozlukları" end
if E["Al'Aketh Zealot's Pauldrons"] == nil then E["Al'Aketh Zealot's Pauldrons"] = "Al'Aketh Fanatik Omuzlukları" end
if E["Al'Aketh Zealot's Robe"] == nil then E["Al'Aketh Zealot's Robe"] = "Al'Aketh Fanatik Cübbesi" end
if E["Al'Aketh Zealot's Vest"] == nil then E["Al'Aketh Zealot's Vest"] = "Al'Aketh Fanatik Yeleği" end
if E["Al'aketh Armguards"] == nil then E["Al'aketh Armguards"] = "Al'aketh Kol Koruyucuları" end
if E["Al'aketh Belt"] == nil then E["Al'aketh Belt"] = "Al'aketh Kemeri" end
if E["Al'aketh Boots"] == nil then E["Al'aketh Boots"] = "Al'aketh Çizmeleri" end
if E["Al'aketh Bracers"] == nil then E["Al'aketh Bracers"] = "Al'aketh Bileklikleri" end
if E["Al'aketh Chain"] == nil then E["Al'aketh Chain"] = "Al'aketh Zinciri" end
if E["Al'aketh Chainmail"] == nil then E["Al'aketh Chainmail"] = "Al'aketh Zincir Zırhı" end
if E["Al'aketh Cord"] == nil then E["Al'aketh Cord"] = "Al'aketh Kuşağı" end
if E["Al'aketh Cuffs"] == nil then E["Al'aketh Cuffs"] = "Al'aketh Kollukları" end
if E["Al'aketh Footwraps"] == nil then E["Al'aketh Footwraps"] = "Al'aketh Ayak Sargıları" end
if E["Al'aketh Gauntlets"] == nil then E["Al'aketh Gauntlets"] = "Al'aketh Demir Eldivenleri" end
if E["Al'aketh Gloves"] == nil then E["Al'aketh Gloves"] = "Al'aketh Eldivenleri" end
if E["Al'aketh Greaves"] == nil then E["Al'aketh Greaves"] = "Al'aketh Baldırlıkları" end
if E["Al'aketh Harness"] == nil then E["Al'aketh Harness"] = "Al'aketh Koşumu" end
if E["Al'aketh Jerkin"] == nil then E["Al'aketh Jerkin"] = "Al'aketh Ceketi" end
if E["Al'aketh Leggings"] == nil then E["Al'aketh Leggings"] = "Al'aketh Tozlukları" end
if E["Al'aketh Mitts"] == nil then E["Al'aketh Mitts"] = "Al'aketh Parmaksız Eldivenleri" end
if E["Al'aketh Pants"] == nil then E["Al'aketh Pants"] = "Al'aketh Pantolonu" end
if E["Al'aketh Shoes"] == nil then E["Al'aketh Shoes"] = "Al'aketh Ayakkabıları" end
if E["Al'aketh Strap"] == nil then E["Al'aketh Strap"] = "Al'aketh Kayışı" end
if E["Al'aketh Trousers"] == nil then E["Al'aketh Trousers"] = "Al'aketh Şalvarı" end
if E["Al'aketh Wristguards"] == nil then E["Al'aketh Wristguards"] = "Al'aketh Bilek Koruyucuları" end
if E["Alaric's Remains"] == nil then E["Alaric's Remains"] = "Alaric'in Kalıntıları" end
if E["Alchemey Ward - Fel Ash Experimentation Notes"] == nil then E["Alchemey Ward - Fel Ash Experimentation Notes"] = "Simya Koğuşu - Fel Külü Deney Notları" end
if E["Alexston's Reply"] == nil then E["Alexston's Reply"] = "Alexston'ın Cevabı" end
if E["Alleria's Silver Coin"] == nil then E["Alleria's Silver Coin"] = "Alleria'nın Gümüş Sikkesi" end
if E["Alliance Outrunner's Sword"] == nil then E["Alliance Outrunner's Sword"] = "Alliance Öncüsünün Kılıcı" end
if E["Alterac Assassin's Gloves"] == nil then E["Alterac Assassin's Gloves"] = "Alterac Suikastçısının Eldivenleri" end
if E["Ambassdor's Bloodrobes"] == nil then E["Ambassdor's Bloodrobes"] = "Elçinin Kan Cübbesi" end
if E["Amberhall's Soulstone"] == nil then E["Amberhall's Soulstone"] = "Amberhall'un Ruh Taşı" end
if E["Amulet of Gol'gere"] == nil then E["Amulet of Gol'gere"] = "Gol'gere Muskası" end
if E["An'she's Radiance"] == nil then E["An'she's Radiance"] = "An'she'nin Işıltısı" end
if E["Anarchist's Workbench"] == nil then E["Anarchist's Workbench"] = "Anarşistin Tezgâhı" end
if E["Ancient Hero's Skull"] == nil then E["Ancient Hero's Skull"] = "Kadim Kahramanın Kafatası" end
if E["Anduin Wrynn's Gold Coin"] == nil then E["Anduin Wrynn's Gold Coin"] = "Anduin Wrynn'in Altın Sikkesi" end
if E["Ansirem's Copper Coin"] == nil then E["Ansirem's Copper Coin"] = "Ansirem'in Bakır Sikkesi" end
if E["Antonidas' Silver Coin"] == nil then E["Antonidas' Silver Coin"] = "Antonidas'ın Gümüş Sikkesi" end
if E["Anvil"] == nil then E["Anvil"] = "Örs" end
if E["Aonda's Written Report"] == nil then E["Aonda's Written Report"] = "Aonda'nın Yazılı Raporu" end
if E["Apothecary's Concoction"] == nil then E["Apothecary's Concoction"] = "Eczacının Karışımı" end
if E["Apprentice Wizard's Gown"] == nil then E["Apprentice Wizard's Gown"] = "Çırak Büyücü Elbisesi" end
if E["Apprentice's Blouse"] == nil then E["Apprentice's Blouse"] = "Çırak Bluzu" end
if E["Apprentice's Boots"] == nil then E["Apprentice's Boots"] = "Çırak Çizmeleri" end
if E["Apprentice's Herb Pouch"] == nil then E["Apprentice's Herb Pouch"] = "Çırak Ot Kesesi" end
if E["Apprentice's Mining Pack"] == nil then E["Apprentice's Mining Pack"] = "Çırak Madencilik Çantası" end
if E["Apprentice's Pants"] == nil then E["Apprentice's Pants"] = "Çırak Pantolonu" end
if E["Apprentice's Robe"] == nil then E["Apprentice's Robe"] = "Çırak Cübbesi" end
if E["Apprentice's Shirt"] == nil then E["Apprentice's Shirt"] = "Çırak Gömleği" end
if E["Apprentice's Skinning Satchel"] == nil then E["Apprentice's Skinning Satchel"] = "Çırak Deri Yüzme Heybesi" end
if E["Apprentice's Spellstaff"] == nil then E["Apprentice's Spellstaff"] = "Çırak Büyü Asası" end
if E["Arcane Explainer: Magical Stuff in Simple Words"] == nil then E["Arcane Explainer: Magical Stuff in Simple Words"] = "Arkan Açıklayıcı: Basit Sözlerle Büyülü Şeyler" end
if E["Arcane-Infused Net"] == nil then E["Arcane-Infused Net"] = "Arkanla Dolu Ağ" end
if E["Arcanist Doan's Silver Coin"] == nil then E["Arcanist Doan's Silver Coin"] = "Arkanist Doan'ın Gümüş Sikkesi" end
if E["Archaeologist's Gown"] == nil then E["Archaeologist's Gown"] = "Arkeolog Elbisesi" end
if E["Archer's Leggings"] == nil then E["Archer's Leggings"] = "Okçu Tozlukları" end
if E["Archimonde's Gold Coin"] == nil then E["Archimonde's Gold Coin"] = "Archimonde'un Altın Sikkesi" end
if E["Archmage Antonidas: The Unabridged Autobiography"] == nil then E["Archmage Antonidas: The Unabridged Autobiography"] = "Başbüyücü Antonidas: Kısaltılmamış Otobiyografi" end
if E["Archmage Theocritus' Research Journal"] == nil then E["Archmage Theocritus' Research Journal"] = "Başbüyücü Theocritus'un Araştırma Günlüğü" end
if E["Archmagister's Faceted Pendant"] == nil then E["Archmagister's Faceted Pendant"] = "Başmagisterin Yontulmuş Kolyesi" end
if E["Arthas' Gold Coin"] == nil then E["Arthas' Gold Coin"] = "Arthas'ın Altın Sikkesi" end
if E["Artifact Seeker's Pendant"] == nil then E["Artifact Seeker's Pendant"] = "Eser Arayıcının Kolyesi" end
if E["Arugal's Gold Coin"] == nil then E["Arugal's Gold Coin"] = "Arugal'ın Altın Sikkesi" end
if E["Ash-tainted Sap"] == nil then E["Ash-tainted Sap"] = "Külle Kirlenmiş Özsu" end
if E["Assassin's Dagger"] == nil then E["Assassin's Dagger"] = "Suikastçı Hançeri" end
if E["Assassin's Waistguard"] == nil then E["Assassin's Waistguard"] = "Suikastçı Bel Koruyucusu" end
if E["Ataeric's Staff"] == nil then E["Ataeric's Staff"] = "Ataeric'in Asası" end
if E["Ataeric: On Arcane Curiosities"] == nil then E["Ataeric: On Arcane Curiosities"] = "Ataeric: Arkan Tuhaflıklar Üzerine" end
if E["Attumen's Copper Coin"] == nil then E["Attumen's Copper Coin"] = "Attumen'in Bakır Sikkesi" end
if E["Autographed Picture of Foror & Tigule"] == nil then E["Autographed Picture of Foror & Tigule"] = "Foror & Tigule'ün İmzalı Fotoğrafı" end
if E["Avala's Binding"] == nil then E["Avala's Binding"] = "Avala'nın Bağı" end
if E["Avala's Core"] == nil then E["Avala's Core"] = "Avala'nın Çekirdeği" end
if E["Avelina's Heart"] == nil then E["Avelina's Heart"] = "Avelina'nın Kalbi" end
if E["Azgalor's Ashes"] == nil then E["Azgalor's Ashes"] = "Azgalor'un Külleri" end
if E["Azore's Transcription"] == nil then E["Azore's Transcription"] = "Azore'un Çevriyazısı" end
if E["Bael'dun Tankard"] == nil then E["Bael'dun Tankard"] = "Bael'dun Maşrapası" end
if E["Ban'ethil Quiver"] == nil then E["Ban'ethil Quiver"] = "Ban'ethil Sadağı" end
if E["Bandit's Jerkin"] == nil then E["Bandit's Jerkin"] = "Haydut Ceketi" end
if E["Banished Centaur's Pauldrons"] == nil then E["Banished Centaur's Pauldrons"] = "Sürgün Centaur Omuzlukları" end
if E["Barely Legible Journal Entry, Page I"] == nil then E["Barely Legible Journal Entry, Page I"] = "Zar Zor Okunan Günlük Kaydı, Sayfa I" end
if E["Barely Legible Journal Entry, Page II"] == nil then E["Barely Legible Journal Entry, Page II"] = "Zar Zor Okunan Günlük Kaydı, Sayfa II" end
if E["Barely Legible Journal Entry, Page III"] == nil then E["Barely Legible Journal Entry, Page III"] = "Zar Zor Okunan Günlük Kaydı, Sayfa III" end
if E["Barely Legible Journal Entry, Page IV"] == nil then E["Barely Legible Journal Entry, Page IV"] = "Zar Zor Okunan Günlük Kaydı, Sayfa IV" end
if E["Barely Legible Journal Entry, Page IX"] == nil then E["Barely Legible Journal Entry, Page IX"] = "Zar Zor Okunan Günlük Kaydı, Sayfa IX" end
if E["Barely Legible Journal Entry, Page V"] == nil then E["Barely Legible Journal Entry, Page V"] = "Zar Zor Okunan Günlük Kaydı, Sayfa V" end
if E["Barely Legible Journal Entry, Page VI"] == nil then E["Barely Legible Journal Entry, Page VI"] = "Zar Zor Okunan Günlük Kaydı, Sayfa VI" end
if E["Barely Legible Journal Entry, Page VII"] == nil then E["Barely Legible Journal Entry, Page VII"] = "Zar Zor Okunan Günlük Kaydı, Sayfa VII" end
if E["Barely Legible Journal Entry, Page VIII"] == nil then E["Barely Legible Journal Entry, Page VIII"] = "Zar Zor Okunan Günlük Kaydı, Sayfa VIII" end
if E["Barely Legible Journal Entry, Page X"] == nil then E["Barely Legible Journal Entry, Page X"] = "Zar Zor Okunan Günlük Kaydı, Sayfa X" end
if E["Barton's Scouting Report"] == nil then E["Barton's Scouting Report"] = "Barton'ın Keşif Raporu" end
if E["Basilisks: Should Petrification be Feared?"] == nil then E["Basilisks: Should Petrification be Feared?"] = "Basiliskler: Taşlaşmaktan Korkmalı mı?" end
if E["Battleguard Captain's Sticker"] == nil then E["Battleguard Captain's Sticker"] = "Savaş Muhafızı Kaptanının Çıkartması" end
if E["Baxtan: On Destructive Magics"] == nil then E["Baxtan: On Destructive Magics"] = "Baxtan: Yıkıcı Büyüler Üzerine" end
if E["Bayne's Bite"] == nil then E["Bayne's Bite"] = "Bayne'in Isırığı" end
if E["Beastmaster's Girdle"] == nil then E["Beastmaster's Girdle"] = "Canavar Efendisinin Kuşağı" end
if E["Beggar's Leggings"] == nil then E["Beggar's Leggings"] = "Dilenci Tozlukları" end
if E["Beguiler's Blade"] == nil then E["Beguiler's Blade"] = "Ayartıcının Kılıcı" end
if E["Benedict's Orders"] == nil then E["Benedict's Orders"] = "Benedict'in Emirleri" end
if E["Berard's Journal"] == nil then E["Berard's Journal"] = "Berard'ın Günlüğü" end
if E["Berdun's Trusty Rifle"] == nil then E["Berdun's Trusty Rifle"] = "Berdun'un Güvenilir Tüfeği" end
if E["Bernice's Necklace"] == nil then E["Bernice's Necklace"] = "Bernice'in Kolyesi" end
if E["Bethor's Potion"] == nil then E["Bethor's Potion"] = "Bethor'un İksiri" end
if E["Bethor's Scroll"] == nil then E["Bethor's Scroll"] = "Bethor'un Parşömeni" end
if E["Big Bag o' Gold"] == nil then E["Big Bag o' Gold"] = "Koca Kese Altın" end
if E["Big Ball o' Bait"] == nil then E["Big Ball o' Bait"] = "Koca Yem Topu" end
if E["Blademaster's Banner"] == nil then E["Blademaster's Banner"] = "Kılıç Ustasının Sancağı" end
if E["Blindwatcher's Sight"] == nil then E["Blindwatcher's Sight"] = "Kör Gözcünün Görüşü" end
if E["Blood of Immol'thar"] == nil then E["Blood of Immol'thar"] = "Immol'thar'ın Kanı" end
if E["Blood-Stained Bandit Mask"] == nil then E["Blood-Stained Bandit Mask"] = "Kan Lekeli Haydut Maskesi" end
if E["Blood-Stained Letter"] == nil then E["Blood-Stained Letter"] = "Kan Lekeli Mektup" end
if E["Blood-Stained Parchment"] == nil then E["Blood-Stained Parchment"] = "Kan Lekeli Parşömen" end
if E["Bloodmaster's Ring"] == nil then E["Bloodmaster's Ring"] = "Kan Efendisinin Yüzüğü" end
if E["Bloodmaw's Basher"] == nil then E["Bloodmaw's Basher"] = "Bloodmaw'un Ezicisi" end
if E["Blueprint: Alchemy Laboratory"] == nil then E["Blueprint: Alchemy Laboratory"] = "Proje: Simya Laboratuvarı" end
if E["Blueprint: Anarchist's Workbench"] == nil then E["Blueprint: Anarchist's Workbench"] = "Proje: Anarşistin Tezgâhı" end
if E["Blueprint: Anvil"] == nil then E["Blueprint: Anvil"] = "Proje: Örs" end
if E["Blueprint: Arcane Forge"] == nil then E["Blueprint: Arcane Forge"] = "Proje: Arkan Demirhane" end
if E["Blueprint: Arcane Salvager"] == nil then E["Blueprint: Arcane Salvager"] = "Proje: Arkan Kurtarıcı" end
if E["Blueprint: Cookie's Feast"] == nil then E["Blueprint: Cookie's Feast"] = "Proje: Cookie'nin Ziyafeti" end
if E["Blueprint: Expert Campfire"] == nil then E["Blueprint: Expert Campfire"] = "Proje: Uzman Kamp Ateşi" end
if E["Blueprint: Fermenter"] == nil then E["Blueprint: Fermenter"] = "Proje: Mayalayıcı" end
if E["Blueprint: Field Guide"] == nil then E["Blueprint: Field Guide"] = "Proje: Saha Rehberi" end
if E["Blueprint: Fishing Hut"] == nil then E["Blueprint: Fishing Hut"] = "Proje: Balıkçı Kulübesi" end
if E["Blueprint: Fishing Rack"] == nil then E["Blueprint: Fishing Rack"] = "Proje: Balık Askısı" end
if E["Blueprint: Greenhouse"] == nil then E["Blueprint: Greenhouse"] = "Proje: Sera" end
if E["Blueprint: Iron Oven"] == nil then E["Blueprint: Iron Oven"] = "Proje: Demir Fırın" end
if E["Blueprint: Journeyman Campfire"] == nil then E["Blueprint: Journeyman Campfire"] = "Proje: Kalfa Kamp Ateşi" end
if E["Blueprint: Loom"] == nil then E["Blueprint: Loom"] = "Proje: Dokuma Tezgâhı" end
if E["Blueprint: Master Forge"] == nil then E["Blueprint: Master Forge"] = "Proje: Usta Demirhanesi" end
if E["Blueprint: Molten Foundry"] == nil then E["Blueprint: Molten Foundry"] = "Proje: Erimiş Dökümhane" end
if E["Blueprint: Plague Doctor's Laboratory"] == nil then E["Blueprint: Plague Doctor's Laboratory"] = "Proje: Veba Doktorunun Laboratuvarı" end
if E["Blueprint: Repair Bot"] == nil then E["Blueprint: Repair Bot"] = "Proje: Tamir Robotu" end
if E["Blueprint: Rock Garden"] == nil then E["Blueprint: Rock Garden"] = "Proje: Taş Bahçesi" end
if E["Blueprint: Seed Hybridizer"] == nil then E["Blueprint: Seed Hybridizer"] = "Proje: Tohum Melezleyici" end
if E["Blueprint: Sewing Machine"] == nil then E["Blueprint: Sewing Machine"] = "Proje: Dikiş Makinesi" end
if E["Blueprint: Spinning Wheel"] == nil then E["Blueprint: Spinning Wheel"] = "Proje: Çıkrık" end
if E["Blueprint: Tanning Rack"] == nil then E["Blueprint: Tanning Rack"] = "Proje: Tabaklama Askısı" end
if E["Blueprint: Toxin Study"] == nil then E["Blueprint: Toxin Study"] = "Proje: Toksin Çalışması" end
if E["Blueprint: Trapper's Workbench"] == nil then E["Blueprint: Trapper's Workbench"] = "Proje: Tuzakçı Tezgâhı" end
if E["Bolder'ok Loincloth"] == nil then E["Bolder'ok Loincloth"] = "Bolder'ok Peştamalı" end
if E["Bonebinder's Signet"] == nil then E["Bonebinder's Signet"] = "Kemik Bağlayıcının Mühür Yüzüğü" end
if E["Boots of the People's Militia"] == nil then E["Boots of the People's Militia"] = "Halk Milislerinin Çizmeleri" end
if E["Booty Bay Bruiser's Buckshot"] == nil then E["Booty Bay Bruiser's Buckshot"] = "Booty Bay Kabadayısının Saçması" end
if E["Bottom-Left Map Piece"] == nil then E["Bottom-Left Map Piece"] = "Sol Alt Harita Parçası" end
if E["Bottom-Right Map Piece"] == nil then E["Bottom-Right Map Piece"] = "Sağ Alt Harita Parçası" end
if E["Bramblesnap's Panacea"] == nil then E["Bramblesnap's Panacea"] = "Bramblesnap'in Her Derde Devası" end
if E["Brann Bronzebeard's Gold Coin"] == nil then E["Brann Bronzebeard's Gold Coin"] = "Brann Bronzebeard'ın Altın Sikkesi" end
if E["Brass-Banded Bracers"] == nil then E["Brass-Banded Bracers"] = "Pirinç Bantlı Bileklikler" end
if E["Brass-fitted Flam-Tamp Flange"] == nil then E["Brass-fitted Flam-Tamp Flange"] = "Pirinç Takımlı Alev-Tıkaç Flanşı" end
if E["Brass-studded Bracers"] == nil then E["Brass-studded Bracers"] = "Pirinç Çivili Bileklikler" end
if E["Brave's Axe"] == nil then E["Brave's Axe"] = "Cesur Savaşçının Baltası" end
if E["Bravo's Armbands"] == nil then E["Bravo's Armbands"] = "Bravo'nun Kolçakları" end
if E["Brawler's Leather Armor"] == nil then E["Brawler's Leather Armor"] = "Kavgacı Deri Zırhı" end
if E["Brawler's Leather Belt"] == nil then E["Brawler's Leather Belt"] = "Kavgacı Deri Kemeri" end
if E["Brawler's Leather Boots"] == nil then E["Brawler's Leather Boots"] = "Kavgacı Deri Çizmeleri" end
if E["Brawler's Leather Gloves"] == nil then E["Brawler's Leather Gloves"] = "Kavgacı Deri Eldivenleri" end
if E["Brawler's Leather Helm"] == nil then E["Brawler's Leather Helm"] = "Kavgacı Deri Miğferi" end
if E["Brawler's Leather Hood"] == nil then E["Brawler's Leather Hood"] = "Kavgacı Deri Başlığı" end
if E["Brawler's Leather Legguards"] == nil then E["Brawler's Leather Legguards"] = "Kavgacı Deri Bacak Koruyucuları" end
if E["Brawler's Leather Pants"] == nil then E["Brawler's Leather Pants"] = "Kavgacı Deri Pantolonu" end
if E["Brawler's Leather Tunic"] == nil then E["Brawler's Leather Tunic"] = "Kavgacı Deri Tuniği" end
if E["Brawler's Pants"] == nil then E["Brawler's Pants"] = "Kavgacı Pantolonu" end
if E["Breaker's Gauntlets"] == nil then E["Breaker's Gauntlets"] = "Kırıcının Demir Eldivenleri" end
if E["Brewer's Bracers"] == nil then E["Brewer's Bracers"] = "Biracı Bileklikleri" end
if E["Brilliant Watcher's Signet"] == nil then E["Brilliant Watcher's Signet"] = "Parlak Gözcünün Mühür Yüzüğü" end
if E["Brog's Friendship Bracelet"] == nil then E["Brog's Friendship Bracelet"] = "Brog'un Dostluk Bilekliği" end
if E["Broken Electro-lantern"] == nil then E["Broken Electro-lantern"] = "Kırık Elektro-fener" end
if E["Broken I.W.I.N. Button"] == nil then E["Broken I.W.I.N. Button"] = "Kırık I.W.I.N. Düğmesi" end
if E["Broken Staff of Incinerator Gar'im"] == nil then E["Broken Staff of Incinerator Gar'im"] = "Yakıcı Gar'im'in Kırık Asası" end
if E["Broken Tooth's Flayed Hide"] == nil then E["Broken Tooth's Flayed Hide"] = "Broken Tooth'un Yüzülmüş Postu" end
if E["Broodwatcher's Belt"] == nil then E["Broodwatcher's Belt"] = "Kuluçka Gözcüsünün Kemeri" end
if E["Broodwatcher's Clenchers"] == nil then E["Broodwatcher's Clenchers"] = "Kuluçka Gözcüsünün Kıskaçları" end
if E["Broodwatcher's Treaders"] == nil then E["Broodwatcher's Treaders"] = "Kuluçka Gözcüsünün Ayakkabıları" end
if E["Brother's Half-Key"] == nil then E["Brother's Half-Key"] = "Kardeşin Yarım Anahtarı" end
if E["Bruuz's Dorsal Fin"] == nil then E["Bruuz's Dorsal Fin"] = "Bruuz'un Sırt Yüzgeci" end
if E["Bundle of I'lalai Findings"] == nil then E["Bundle of I'lalai Findings"] = "I'lalai Buluntuları Destesi" end
if E["Ca'zass's Head"] == nil then E["Ca'zass's Head"] = "Ca'zass'ın Kafası" end
if E["Captain Nials' Correspondence"] == nil then E["Captain Nials' Correspondence"] = "Kaptan Nials'ın Yazışmaları" end
if E["Captain Sander's Locker"] == nil then E["Captain Sander's Locker"] = "Kaptan Sander'ın Dolabı" end
if E["Captain Sander's Lucky Shooter"] == nil then E["Captain Sander's Lucky Shooter"] = "Kaptan Sander'ın Şanslı Tabancası" end
if E["Captain's Skeleton Key"] == nil then E["Captain's Skeleton Key"] = "Kaptanın Maymuncuğu" end
if E["Caretaker's Cord"] == nil then E["Caretaker's Cord"] = "Bakıcının Kuşağı" end
if E["Carnage's Head"] == nil then E["Carnage's Head"] = "Carnage'ın Kafası" end
if E["Carpenter's Mallet"] == nil then E["Carpenter's Mallet"] = "Marangoz Tokmağı" end
if E["Cell Keeper's Claws"] == nil then E["Cell Keeper's Claws"] = "Zindancının Pençeleri" end
if E["Centaur Raider's Axe"] == nil then E["Centaur Raider's Axe"] = "Centaur Yağmacısının Baltası" end
if E["Chakuyak's Pelt"] == nil then E["Chakuyak's Pelt"] = "Chakuyak'ın Postu" end
if E["Champion's Legplates"] == nil then E["Champion's Legplates"] = "Şampiyonun Bacak Plakaları" end
if E["Channeler's Ring"] == nil then E["Channeler's Ring"] = "Kanalcının Yüzüğü" end
if E["Chef's Hat"] == nil then E["Chef's Hat"] = "Aşçı Şapkası" end
if E["Chef's Knife"] == nil then E["Chef's Knife"] = "Aşçı Bıçağı" end
if E["Chief Sharptusk Thornmantle's Head"] == nil then E["Chief Sharptusk Thornmantle's Head"] = "Şef Sharptusk Thornmantle'ın Kafası" end
if E["Chogg's Head"] == nil then E["Chogg's Head"] = "Chogg'un Kafası" end
if E["Chol'aruk's Head"] == nil then E["Chol'aruk's Head"] = "Chol'aruk'un Kafası" end
if E["Chol'aruk's Trophy Sword"] == nil then E["Chol'aruk's Trophy Sword"] = "Chol'aruk'un Ganimet Kılıcı" end
if E["Clack's Claw"] == nil then E["Clack's Claw"] = "Clack'in Kıskacı" end
if E["Claw of Shalla'kal"] == nil then E["Claw of Shalla'kal"] = "Shalla'kal'ın Pençesi" end
if E["Cleric's Elixir"] == nil then E["Cleric's Elixir"] = "Rahibin İksiri" end
if E["Clever Expeditionary's Spellblade"] == nil then E["Clever Expeditionary's Spellblade"] = "Zeki Seferci Büyü Kılıcı" end
if E["Cliff Walker's Cinch"] == nil then E["Cliff Walker's Cinch"] = "Uçurum Yürüyücüsünün Kemeri" end
if E["Clobrok's Block Rock"] == nil then E["Clobrok's Block Rock"] = "Clobrok'un Blok Kayası" end
if E["Clutchlord's Grips"] == nil then E["Clutchlord's Grips"] = "Kuluçka Lordunun Eldivenleri" end
if E["Clutchlord's Stompers"] == nil then E["Clutchlord's Stompers"] = "Kuluçka Lordunun Postalları" end
if E["Clutchlord's Support"] == nil then E["Clutchlord's Support"] = "Kuluçka Lordunun Desteği" end
if E["Coalbeard's Rifle"] == nil then E["Coalbeard's Rifle"] = "Coalbeard'ın Tüfeği" end
if E["Collector's Edition Tabard"] == nil then E["Collector's Edition Tabard"] = "Koleksiyoncu Sürümü Arması" end
if E["Commander Cyclas's Head"] == nil then E["Commander Cyclas's Head"] = "Komutan Cyclas'ın Kafası" end
if E["Commander Haalien's Severed Head"] == nil then E["Commander Haalien's Severed Head"] = "Komutan Haalien'in Kesik Kafası" end
if E["Commoner's Sword"] == nil then E["Commoner's Sword"] = "Halktan Birinin Kılıcı" end
if E["Conjurer's Codex"] == nil then E["Conjurer's Codex"] = "Çağırıcının Kodeksi" end
if E["Conqueror's Helm"] == nil then E["Conqueror's Helm"] = "Fatihin Miğferi" end
if E["Contest Winner's Tabard"] == nil then E["Contest Winner's Tabard"] = "Yarışma Kazananı Arması" end
if E["Cookie's Feast"] == nil then E["Cookie's Feast"] = "Cookie'nin Ziyafeti" end
if E["Corpsefeeder's Carapace"] == nil then E["Corpsefeeder's Carapace"] = "Leşyiyenin Kabuğu" end
if E["Corpsefeeder's Shedding"] == nil then E["Corpsefeeder's Shedding"] = "Leşyiyenin Döküntüsü" end
if E["Courier's Shipment"] == nil then E["Courier's Shipment"] = "Kuryenin Sevkiyatı" end
if E["Courier's Wristguards"] == nil then E["Courier's Wristguards"] = "Kurye Bilek Koruyucuları" end
if E["Craftsman's Dagger"] == nil then E["Craftsman's Dagger"] = "Zanaatkâr Hançeri" end
if E["Craftsman's Writ: Advanced Target Dummy"] == nil then E["Craftsman's Writ: Advanced Target Dummy"] = "Zanaatkâr Yazısı: Gelişmiş Hedef Mankeni" end
if E["Craftsman's Writ: Arcanite Skeleton Key"] == nil then E["Craftsman's Writ: Arcanite Skeleton Key"] = "Zanaatkâr Yazısı: Arkanit Maymuncuk" end
if E["Craftsman's Writ: Azure Silk Hood"] == nil then E["Craftsman's Writ: Azure Silk Hood"] = "Zanaatkâr Yazısı: Gök Mavisi İpek Başlık" end
if E["Craftsman's Writ: Barbaric Gloves"] == nil then E["Craftsman's Writ: Barbaric Gloves"] = "Zanaatkâr Yazısı: Barbar Eldivenler" end
if E["Craftsman's Writ: Big Bronze Bomb"] == nil then E["Craftsman's Writ: Big Bronze Bomb"] = "Zanaatkâr Yazısı: Büyük Bronz Bomba" end
if E["Craftsman's Writ: Big Bronze Knife"] == nil then E["Craftsman's Writ: Big Bronze Knife"] = "Zanaatkâr Yazısı: Büyük Bronz Bıçak" end
if E["Craftsman's Writ: Big Voodoo Mask"] == nil then E["Craftsman's Writ: Big Voodoo Mask"] = "Zanaatkâr Yazısı: Büyük Vudu Maskesi" end
if E["Craftsman's Writ: Big Voodoo Robe"] == nil then E["Craftsman's Writ: Big Voodoo Robe"] = "Zanaatkâr Yazısı: Büyük Vudu Cübbesi" end
if E["Craftsman's Writ: Black Mageweave Vest"] == nil then E["Craftsman's Writ: Black Mageweave Vest"] = "Zanaatkâr Yazısı: Siyah Büyüdokuma Yelek" end
if E["Craftsman's Writ: Blue Glittering Axe"] == nil then E["Craftsman's Writ: Blue Glittering Axe"] = "Zanaatkâr Yazısı: Mavi Parıldayan Balta" end
if E["Craftsman's Writ: Blue Overalls"] == nil then E["Craftsman's Writ: Blue Overalls"] = "Zanaatkâr Yazısı: Mavi Tulum" end
if E["Craftsman's Writ: Catseye Draught"] == nil then E["Craftsman's Writ: Catseye Draught"] = "Zanaatkâr Yazısı: Kedigözü Şerbeti" end
if E["Craftsman's Writ: Catseye Ultra Goggles"] == nil then E["Craftsman's Writ: Catseye Ultra Goggles"] = "Zanaatkâr Yazısı: Kedigözü Ultra Gözlük" end
if E["Craftsman's Writ: Cenarion Herb Bag"] == nil then E["Craftsman's Writ: Cenarion Herb Bag"] = "Zanaatkâr Yazısı: Cenarion Ot Çantası" end
if E["Craftsman's Writ: Chimeric Vest"] == nil then E["Craftsman's Writ: Chimeric Vest"] = "Zanaatkâr Yazısı: Kimerik Yelek" end
if E["Craftsman's Writ: Cindercloth Robe"] == nil then E["Craftsman's Writ: Cindercloth Robe"] = "Zanaatkâr Yazısı: Kordokuma Cübbe" end
if E["Craftsman's Writ: Colorful Kilt"] == nil then E["Craftsman's Writ: Colorful Kilt"] = "Zanaatkâr Yazısı: Renkli Etek" end
if E["Craftsman's Writ: Comfortable Leather Hat"] == nil then E["Craftsman's Writ: Comfortable Leather Hat"] = "Zanaatkâr Yazısı: Rahat Deri Şapka" end
if E["Craftsman's Writ: Crafted Solid Shot"] == nil then E["Craftsman's Writ: Crafted Solid Shot"] = "Zanaatkâr Yazısı: İşlenmiş Sağlam Mermi" end
if E["Craftsman's Writ: Craftsman's Monocle"] == nil then E["Craftsman's Writ: Craftsman's Monocle"] = "Zanaatkâr Yazısı: Zanaatkâr Monoklu" end
if E["Craftsman's Writ: Crimson Silk Robe"] == nil then E["Craftsman's Writ: Crimson Silk Robe"] = "Zanaatkâr Yazısı: Kızıl İpek Cübbe" end
if E["Craftsman's Writ: Dark Iron Bomb"] == nil then E["Craftsman's Writ: Dark Iron Bomb"] = "Zanaatkâr Yazısı: Dark Iron Bombası" end
if E["Craftsman's Writ: Dark Leather Shoulders"] == nil then E["Craftsman's Writ: Dark Leather Shoulders"] = "Zanaatkâr Yazısı: Koyu Deri Omuzluklar" end
if E["Craftsman's Writ: Dark Leather Tunic"] == nil then E["Craftsman's Writ: Dark Leather Tunic"] = "Zanaatkâr Yazısı: Koyu Deri Tunik" end
if E["Craftsman's Writ: Darkrune Gauntlets"] == nil then E["Craftsman's Writ: Darkrune Gauntlets"] = "Zanaatkâr Yazısı: Kara Rün Demir Eldivenleri" end
if E["Craftsman's Writ: Distilled Firewater"] == nil then E["Craftsman's Writ: Distilled Firewater"] = "Zanaatkâr Yazısı: Damıtılmış Ateşsuyu" end
if E["Craftsman's Writ: Draught of Detect Demon"] == nil then E["Craftsman's Writ: Draught of Detect Demon"] = "Zanaatkâr Yazısı: İblis Algılama Şerbeti" end
if E["Craftsman's Writ: Draught of Water Breathing"] == nil then E["Craftsman's Writ: Draught of Water Breathing"] = "Zanaatkâr Yazısı: Su Altında Nefes Alma Şerbeti" end
if E["Craftsman's Writ: Dreamless Sleep Potion"] == nil then E["Craftsman's Writ: Dreamless Sleep Potion"] = "Zanaatkâr Yazısı: Rüyasız Uyku İksiri" end
if E["Craftsman's Writ: Dusky Bracers"] == nil then E["Craftsman's Writ: Dusky Bracers"] = "Zanaatkâr Yazısı: Alacakaranlık Bileklikleri" end
if E["Craftsman's Writ: Earthen Silk Belt"] == nil then E["Craftsman's Writ: Earthen Silk Belt"] = "Zanaatkâr Yazısı: Toprak İpek Kemer" end
if E["Craftsman's Writ: Ebon Shiv"] == nil then E["Craftsman's Writ: Ebon Shiv"] = "Zanaatkâr Yazısı: Abanoz Bıçak" end
if E["Craftsman's Writ: Elixir of Agility"] == nil then E["Craftsman's Writ: Elixir of Agility"] = "Zanaatkâr Yazısı: Çeviklik İksiri" end
if E["Craftsman's Writ: Elixir of Defense"] == nil then E["Craftsman's Writ: Elixir of Defense"] = "Zanaatkâr Yazısı: Savunma İksiri" end
if E["Craftsman's Writ: Elixir of Lesser Agility"] == nil then E["Craftsman's Writ: Elixir of Lesser Agility"] = "Zanaatkâr Yazısı: Küçük Çeviklik İksiri" end
if E["Craftsman's Writ: Elixir of Ogre's Strength"] == nil then E["Craftsman's Writ: Elixir of Ogre's Strength"] = "Zanaatkâr Yazısı: Ogre Gücü İksiri" end
if E["Craftsman's Writ: Elixir of Wisdom"] == nil then E["Craftsman's Writ: Elixir of Wisdom"] = "Zanaatkâr Yazısı: Bilgelik İksiri" end
if E["Craftsman's Writ: Enchanted Mageweave Pouch"] == nil then E["Craftsman's Writ: Enchanted Mageweave Pouch"] = "Zanaatkâr Yazısı: Efsunlu Büyüdokuma Kese" end
if E["Craftsman's Writ: Explosive Sheep"] == nil then E["Craftsman's Writ: Explosive Sheep"] = "Zanaatkâr Yazısı: Patlayıcı Koyun" end
if E["Craftsman's Writ: Felcloth Boots"] == nil then E["Craftsman's Writ: Felcloth Boots"] = "Zanaatkâr Yazısı: Feldokuma Çizmeler" end
if E["Craftsman's Writ: Field Repair Bot 74A"] == nil then E["Craftsman's Writ: Field Repair Bot 74A"] = "Zanaatkâr Yazısı: Saha Tamir Robotu 74A" end
if E["Craftsman's Writ: Fine Leather Pants"] == nil then E["Craftsman's Writ: Fine Leather Pants"] = "Zanaatkâr Yazısı: İnce Deri Pantolon" end
if E["Craftsman's Writ: Fire Goggles"] == nil then E["Craftsman's Writ: Fire Goggles"] = "Zanaatkâr Yazısı: Ateş Gözlüğü" end
if E["Craftsman's Writ: Fire Protection Potion"] == nil then E["Craftsman's Writ: Fire Protection Potion"] = "Zanaatkâr Yazısı: Ateşten Korunma İksiri" end
if E["Craftsman's Writ: Flash Bomb"] == nil then E["Craftsman's Writ: Flash Bomb"] = "Zanaatkâr Yazısı: Flaş Bombası" end
if E["Craftsman's Writ: Flask of Chromatic Resistance"] == nil then E["Craftsman's Writ: Flask of Chromatic Resistance"] = "Zanaatkâr Yazısı: Kromatik Direnç Şişesi" end
if E["Craftsman's Writ: Free Action Potion"] == nil then E["Craftsman's Writ: Free Action Potion"] = "Zanaatkâr Yazısı: Serbest Hareket İksiri" end
if E["Craftsman's Writ: Frost Protection Potion"] == nil then E["Craftsman's Writ: Frost Protection Potion"] = "Zanaatkâr Yazısı: Ayazdan Korunma İksiri" end
if E["Craftsman's Writ: Frostsaber Boots"] == nil then E["Craftsman's Writ: Frostsaber Boots"] = "Zanaatkâr Yazısı: Frostsaber Çizmeleri" end
if E["Craftsman's Writ: Ghostweave Vest"] == nil then E["Craftsman's Writ: Ghostweave Vest"] = "Zanaatkâr Yazısı: Hayaletdokuma Yelek" end
if E["Craftsman's Writ: Gift of Arthas"] == nil then E["Craftsman's Writ: Gift of Arthas"] = "Zanaatkâr Yazısı: Arthas'ın Armağanı" end
if E["Craftsman's Writ: Gnomish Alarm-O-Bot"] == nil then E["Craftsman's Writ: Gnomish Alarm-O-Bot"] = "Zanaatkâr Yazısı: Gnome Alarm-O-Bot" end
if E["Craftsman's Writ: Gnomish Universal Remote"] == nil then E["Craftsman's Writ: Gnomish Universal Remote"] = "Zanaatkâr Yazısı: Gnome Evrensel Kumandası" end
if E["Craftsman's Writ: Goblin Jumper Cables XL"] == nil then E["Craftsman's Writ: Goblin Jumper Cables XL"] = "Zanaatkâr Yazısı: Goblin Takviye Kabloları XL" end
if E["Craftsman's Writ: Goblin Land Mine"] == nil then E["Craftsman's Writ: Goblin Land Mine"] = "Zanaatkâr Yazısı: Goblin Kara Mayını" end
if E["Craftsman's Writ: Goblin Rocket Fuel"] == nil then E["Craftsman's Writ: Goblin Rocket Fuel"] = "Zanaatkâr Yazısı: Goblin Roket Yakıtı" end
if E["Craftsman's Writ: Golden Rod"] == nil then E["Craftsman's Writ: Golden Rod"] = "Zanaatkâr Yazısı: Altın Çubuk" end
if E["Craftsman's Writ: Golden Scale Coif"] == nil then E["Craftsman's Writ: Golden Scale Coif"] = "Zanaatkâr Yazısı: Altın Pullu Başlık" end
if E["Craftsman's Writ: Golden Scale Gauntlets"] == nil then E["Craftsman's Writ: Golden Scale Gauntlets"] = "Zanaatkâr Yazısı: Altın Pullu Demir Eldivenler" end
if E["Craftsman's Writ: Gordok Ogre Suit"] == nil then E["Craftsman's Writ: Gordok Ogre Suit"] = "Zanaatkâr Yazısı: Gordok Ogre Kostümü" end
if E["Craftsman's Writ: Great Rage Potion"] == nil then E["Craftsman's Writ: Great Rage Potion"] = "Zanaatkâr Yazısı: Büyük Öfke İksiri" end
if E["Craftsman's Writ: Greater Adept's Robe"] == nil then E["Craftsman's Writ: Greater Adept's Robe"] = "Zanaatkâr Yazısı: Büyük Usta Çırak Cübbesi" end
if E["Craftsman's Writ: Greater Fire Protection Potion"] == nil then E["Craftsman's Writ: Greater Fire Protection Potion"] = "Zanaatkâr Yazısı: Büyük Ateşten Korunma İksiri" end
if E["Craftsman's Writ: Green Iron Boots"] == nil then E["Craftsman's Writ: Green Iron Boots"] = "Zanaatkâr Yazısı: Yeşil Demir Çizmeler" end
if E["Craftsman's Writ: Green Iron Gauntlets"] == nil then E["Craftsman's Writ: Green Iron Gauntlets"] = "Zanaatkâr Yazısı: Yeşil Demir Eldivenler" end
if E["Craftsman's Writ: Green Lens"] == nil then E["Craftsman's Writ: Green Lens"] = "Zanaatkâr Yazısı: Yeşil Mercek" end
if E["Craftsman's Writ: Guardian Cloak"] == nil then E["Craftsman's Writ: Guardian Cloak"] = "Zanaatkâr Yazısı: Muhafız Pelerini" end
if E["Craftsman's Writ: Gyromatic Micro-Adjuster"] == nil then E["Craftsman's Writ: Gyromatic Micro-Adjuster"] = "Zanaatkâr Yazısı: Jiromatik Mikro Ayarlayıcı" end
if E["Craftsman's Writ: Heavy Bronze Mace"] == nil then E["Craftsman's Writ: Heavy Bronze Mace"] = "Zanaatkâr Yazısı: Ağır Bronz Gürz" end
if E["Craftsman's Writ: Heavy Leather Ball"] == nil then E["Craftsman's Writ: Heavy Leather Ball"] = "Zanaatkâr Yazısı: Ağır Deri Top" end
if E["Craftsman's Writ: Heavy Mithril Axe"] == nil then E["Craftsman's Writ: Heavy Mithril Axe"] = "Zanaatkâr Yazısı: Ağır Mithril Balta" end
if E["Craftsman's Writ: Heavy Quiver"] == nil then E["Craftsman's Writ: Heavy Quiver"] = "Zanaatkâr Yazısı: Ağır Sadak" end
if E["Craftsman's Writ: Heavy Scorpid Helm"] == nil then E["Craftsman's Writ: Heavy Scorpid Helm"] = "Zanaatkâr Yazısı: Ağır Scorpid Miğferi" end
if E["Craftsman's Writ: Herbalist's Gloves"] == nil then E["Craftsman's Writ: Herbalist's Gloves"] = "Zanaatkâr Yazısı: Otacı Eldivenleri" end
if E["Craftsman's Writ: Huge Thorium Battleaxe"] == nil then E["Craftsman's Writ: Huge Thorium Battleaxe"] = "Zanaatkâr Yazısı: Devasa Toryum Savaş Baltası" end
if E["Craftsman's Writ: Imperial Plate Chest"] == nil then E["Craftsman's Writ: Imperial Plate Chest"] = "Zanaatkâr Yazısı: İmparatorluk Plaka Göğüslüğü" end
if E["Craftsman's Writ: Inlaid Mithril Cylinder"] == nil then E["Craftsman's Writ: Inlaid Mithril Cylinder"] = "Zanaatkâr Yazısı: Kakmalı Mithril Silindir" end
if E["Craftsman's Writ: Iridescent Hammer"] == nil then E["Craftsman's Writ: Iridescent Hammer"] = "Zanaatkâr Yazısı: Yanardöner Çekiç" end
if E["Craftsman's Writ: Lesser Invisibility Potion"] == nil then E["Craftsman's Writ: Lesser Invisibility Potion"] = "Zanaatkâr Yazısı: Küçük Görünmezlik İksiri" end
if E["Craftsman's Writ: Lesser Mana Potion"] == nil then E["Craftsman's Writ: Lesser Mana Potion"] = "Zanaatkâr Yazısı: Küçük Mana İksiri" end
if E["Craftsman's Writ: Lesser Stoneshield Potion"] == nil then E["Craftsman's Writ: Lesser Stoneshield Potion"] = "Zanaatkâr Yazısı: Küçük Taş Kalkan İksiri" end
if E["Craftsman's Writ: Lesser Troll's Blood Elixir"] == nil then E["Craftsman's Writ: Lesser Troll's Blood Elixir"] = "Zanaatkâr Yazısı: Küçük Troll Kanı İksiri" end
if E["Craftsman's Writ: Lesser Wizard's Robe"] == nil then E["Craftsman's Writ: Lesser Wizard's Robe"] = "Zanaatkâr Yazısı: Küçük Büyücü Cübbesi" end
if E["Craftsman's Writ: Lifelike Mechanical Toad"] == nil then E["Craftsman's Writ: Lifelike Mechanical Toad"] = "Zanaatkâr Yazısı: Canlı Gibi Mekanik Kurbağa" end
if E["Craftsman's Writ: Limited Invulnerability Potion"] == nil then E["Craftsman's Writ: Limited Invulnerability Potion"] = "Zanaatkâr Yazısı: Sınırlı Dokunulmazlık İksiri" end
if E["Craftsman's Writ: Mageweave Bag"] == nil then E["Craftsman's Writ: Mageweave Bag"] = "Zanaatkâr Yazısı: Büyüdokuma Çanta" end
if E["Craftsman's Writ: Major Rejuvenation Potion"] == nil then E["Craftsman's Writ: Major Rejuvenation Potion"] = "Zanaatkâr Yazısı: Yüce Yenilenme İksiri" end
if E["Craftsman's Writ: Mana Potion"] == nil then E["Craftsman's Writ: Mana Potion"] = "Zanaatkâr Yazısı: Mana İksiri" end
if E["Craftsman's Writ: Masterwork Target Dummy"] == nil then E["Craftsman's Writ: Masterwork Target Dummy"] = "Zanaatkâr Yazısı: Ustalık Eseri Hedef Mankeni" end
if E["Craftsman's Writ: Mechanical Dragonling"] == nil then E["Craftsman's Writ: Mechanical Dragonling"] = "Zanaatkâr Yazısı: Mekanik Ejder Yavrusu" end
if E["Craftsman's Writ: Mechanical Repair Kit"] == nil then E["Craftsman's Writ: Mechanical Repair Kit"] = "Zanaatkâr Yazısı: Mekanik Tamir Takımı" end
if E["Craftsman's Writ: Minor Recombobulator"] == nil then E["Craftsman's Writ: Minor Recombobulator"] = "Zanaatkâr Yazısı: Küçük Yeniden Toparlayıcı" end
if E["Craftsman's Writ: Mithril Frag Bomb"] == nil then E["Craftsman's Writ: Mithril Frag Bomb"] = "Zanaatkâr Yazısı: Mithril Parça Bombası" end
if E["Craftsman's Writ: Mithril Spurs"] == nil then E["Craftsman's Writ: Mithril Spurs"] = "Zanaatkâr Yazısı: Mithril Mahmuzlar" end
if E["Craftsman's Writ: Moonsight Rifle"] == nil then E["Craftsman's Writ: Moonsight Rifle"] = "Zanaatkâr Yazısı: Ay Görüşü Tüfeği" end
if E["Craftsman's Writ: Moonsteel Broadsword"] == nil then E["Craftsman's Writ: Moonsteel Broadsword"] = "Zanaatkâr Yazısı: Ay Çeliği Geniş Kılıç" end
if E["Craftsman's Writ: Nature Protection Potion"] == nil then E["Craftsman's Writ: Nature Protection Potion"] = "Zanaatkâr Yazısı: Doğadan Korunma İksiri" end
if E["Craftsman's Writ: Nightscape Shoulders"] == nil then E["Craftsman's Writ: Nightscape Shoulders"] = "Zanaatkâr Yazısı: Gece Manzarası Omuzlukları" end
if E["Craftsman's Writ: Orange Martial Shirt"] == nil then E["Craftsman's Writ: Orange Martial Shirt"] = "Zanaatkâr Yazısı: Turuncu Dövüş Gömleği" end
if E["Craftsman's Writ: Orcish War Leggings"] == nil then E["Craftsman's Writ: Orcish War Leggings"] = "Zanaatkâr Yazısı: Ork Savaş Tozlukları" end
if E["Craftsman's Writ: Ornate Mithril Shoulders"] == nil then E["Craftsman's Writ: Ornate Mithril Shoulders"] = "Zanaatkâr Yazısı: Süslü Mithril Omuzluklar" end
if E["Craftsman's Writ: Ornate Spyglass"] == nil then E["Craftsman's Writ: Ornate Spyglass"] = "Zanaatkâr Yazısı: Süslü Dürbün" end
if E["Craftsman's Writ: Pearl-Handled Dagger"] == nil then E["Craftsman's Writ: Pearl-Handled Dagger"] = "Zanaatkâr Yazısı: İnci Saplı Hançer" end
if E["Craftsman's Writ: Phoenix Pants"] == nil then E["Craftsman's Writ: Phoenix Pants"] = "Zanaatkâr Yazısı: Anka Pantolonu" end
if E["Craftsman's Writ: Pilferer's Gloves"] == nil then E["Craftsman's Writ: Pilferer's Gloves"] = "Zanaatkâr Yazısı: Yankesici Eldivenleri" end
if E["Craftsman's Writ: Potion of Demonslaying"] == nil then E["Craftsman's Writ: Potion of Demonslaying"] = "Zanaatkâr Yazısı: İblis Avlama İksiri" end
if E["Craftsman's Writ: Practice Lock"] == nil then E["Craftsman's Writ: Practice Lock"] = "Zanaatkâr Yazısı: Alıştırma Kilidi" end
if E["Craftsman's Writ: Quickdraw Quiver"] == nil then E["Craftsman's Writ: Quickdraw Quiver"] = "Zanaatkâr Yazısı: Çabuk Çekiş Sadağı" end
if E["Craftsman's Writ: Radiant Belt"] == nil then E["Craftsman's Writ: Radiant Belt"] = "Zanaatkâr Yazısı: Işıltılı Kemer" end
if E["Craftsman's Writ: Radiant Circlet"] == nil then E["Craftsman's Writ: Radiant Circlet"] = "Zanaatkâr Yazısı: Işıltılı Taç" end
if E["Craftsman's Writ: Red Mageweave Pants"] == nil then E["Craftsman's Writ: Red Mageweave Pants"] = "Zanaatkâr Yazısı: Kırmızı Büyüdokuma Pantolon" end
if E["Craftsman's Writ: Red Whelp Gloves"] == nil then E["Craftsman's Writ: Red Whelp Gloves"] = "Zanaatkâr Yazısı: Kırmızı Ejder Yavrusu Eldivenleri" end
if E["Craftsman's Writ: Red Woolen Boots"] == nil then E["Craftsman's Writ: Red Woolen Boots"] = "Zanaatkâr Yazısı: Kırmızı Yün Çizmeler" end
if E["Craftsman's Writ: Rough Bronze Leggings"] == nil then E["Craftsman's Writ: Rough Bronze Leggings"] = "Zanaatkâr Yazısı: Kaba Bronz Tozluklar" end
if E["Craftsman's Writ: Runecloth Bag"] == nil then E["Craftsman's Writ: Runecloth Bag"] = "Zanaatkâr Yazısı: Rünkumaş Çanta" end
if E["Craftsman's Writ: Runecloth Boots"] == nil then E["Craftsman's Writ: Runecloth Boots"] = "Zanaatkâr Yazısı: Rünkumaş Çizmeler" end
if E["Craftsman's Writ: Runic Leather Bracers"] == nil then E["Craftsman's Writ: Runic Leather Bracers"] = "Zanaatkâr Yazısı: Rünik Deri Bileklikler" end
if E["Craftsman's Writ: Runic Leather Headband"] == nil then E["Craftsman's Writ: Runic Leather Headband"] = "Zanaatkâr Yazısı: Rünik Deri Saç Bandı" end
if E["Craftsman's Writ: Shadow Goggles"] == nil then E["Craftsman's Writ: Shadow Goggles"] = "Zanaatkâr Yazısı: Gölge Gözlüğü" end
if E["Craftsman's Writ: Shadow Oil"] == nil then E["Craftsman's Writ: Shadow Oil"] = "Zanaatkâr Yazısı: Gölge Yağı" end
if E["Craftsman's Writ: Shadow Protection Potion"] == nil then E["Craftsman's Writ: Shadow Protection Potion"] = "Zanaatkâr Yazısı: Gölgeden Korunma İksiri" end
if E["Craftsman's Writ: Shadoweave Gloves"] == nil then E["Craftsman's Writ: Shadoweave Gloves"] = "Zanaatkâr Yazısı: Gölgedokuma Eldivenler" end
if E["Craftsman's Writ: Shadoweave Mask"] == nil then E["Craftsman's Writ: Shadoweave Mask"] = "Zanaatkâr Yazısı: Gölgedokuma Maske" end
if E["Craftsman's Writ: Shadoweave Robe"] == nil then E["Craftsman's Writ: Shadoweave Robe"] = "Zanaatkâr Yazısı: Gölgedokuma Cübbe" end
if E["Craftsman's Writ: Silver Skeleton Key"] == nil then E["Craftsman's Writ: Silver Skeleton Key"] = "Zanaatkâr Yazısı: Gümüş Maymuncuk" end
if E["Craftsman's Writ: Small Silk Pack"] == nil then E["Craftsman's Writ: Small Silk Pack"] = "Zanaatkâr Yazısı: Küçük İpek Çanta" end
if E["Craftsman's Writ: Sniper Scope"] == nil then E["Craftsman's Writ: Sniper Scope"] = "Zanaatkâr Yazısı: Keskin Nişancı Dürbünü" end
if E["Craftsman's Writ: Solid Sharpening Stone"] == nil then E["Craftsman's Writ: Solid Sharpening Stone"] = "Zanaatkâr Yazısı: Sağlam Bileği Taşı" end
if E["Craftsman's Writ: Soul Pouch"] == nil then E["Craftsman's Writ: Soul Pouch"] = "Zanaatkâr Yazısı: Ruh Kesesi" end
if E["Craftsman's Writ: Spider Silk Slippers"] == nil then E["Craftsman's Writ: Spider Silk Slippers"] = "Zanaatkâr Yazısı: Örümcek İpeği Terlikler" end
if E["Craftsman's Writ: Star Belt"] == nil then E["Craftsman's Writ: Star Belt"] = "Zanaatkâr Yazısı: Yıldız Kemer" end
if E["Craftsman's Writ: Steel Plate Helm"] == nil then E["Craftsman's Writ: Steel Plate Helm"] = "Zanaatkâr Yazısı: Çelik Plaka Miğfer" end
if E["Craftsman's Writ: Steel Weapon Chain"] == nil then E["Craftsman's Writ: Steel Weapon Chain"] = "Zanaatkâr Yazısı: Çelik Silah Zinciri" end
if E["Craftsman's Writ: Swift Boots"] == nil then E["Craftsman's Writ: Swift Boots"] = "Zanaatkâr Yazısı: Süratli Çizmeler" end
if E["Craftsman's Writ: Thick Leather Ammo Pouch"] == nil then E["Craftsman's Writ: Thick Leather Ammo Pouch"] = "Zanaatkâr Yazısı: Kalın Deri Cephane Kesesi" end
if E["Craftsman's Writ: Tranquil Mechanical Yeti"] == nil then E["Craftsman's Writ: Tranquil Mechanical Yeti"] = "Zanaatkâr Yazısı: Sakin Mekanik Yeti" end
if E["Craftsman's Writ: Truesilver Rod"] == nil then E["Craftsman's Writ: Truesilver Rod"] = "Zanaatkâr Yazısı: Saf Gümüş Çubuk" end
if E["Craftsman's Writ: Truesilver Transformer"] == nil then E["Craftsman's Writ: Truesilver Transformer"] = "Zanaatkâr Yazısı: Saf Gümüş Dönüştürücü" end
if E["Craftsman's Writ: Turtle Scale Breastplate"] == nil then E["Craftsman's Writ: Turtle Scale Breastplate"] = "Zanaatkâr Yazısı: Kaplumbağa Pulu Göğüs Zırhı" end
if E["Craftsman's Writ: Tuxedo Jacket"] == nil then E["Craftsman's Writ: Tuxedo Jacket"] = "Zanaatkâr Yazısı: Smokin Ceketi" end
if E["Craftsman's Writ: Unstable Trigger"] == nil then E["Craftsman's Writ: Unstable Trigger"] = "Zanaatkâr Yazısı: Dengesiz Tetik" end
if E["Craftsman's Writ: Volcanic Breastplate"] == nil then E["Craftsman's Writ: Volcanic Breastplate"] = "Zanaatkâr Yazısı: Volkanik Göğüs Zırhı" end
if E["Craftsman's Writ: White Bandit Mask"] == nil then E["Craftsman's Writ: White Bandit Mask"] = "Zanaatkâr Yazısı: Beyaz Haydut Maskesi" end
if E["Craftsman's Writ: Wicked Leather Bracers"] == nil then E["Craftsman's Writ: Wicked Leather Bracers"] = "Zanaatkâr Yazısı: Kötücül Deri Bileklikler" end
if E["Craftsman's Writ: Wicked Leather Pants"] == nil then E["Craftsman's Writ: Wicked Leather Pants"] = "Zanaatkâr Yazısı: Kötücül Deri Pantolon" end
if E["Craftsman's Writ: Wicked Mithril Blade"] == nil then E["Craftsman's Writ: Wicked Mithril Blade"] = "Zanaatkâr Yazısı: Kötücül Mithril Kılıç" end
if E["Craftsman's Writ: Wild Leather Helmet"] == nil then E["Craftsman's Writ: Wild Leather Helmet"] = "Zanaatkâr Yazısı: Yabani Deri Miğfer" end
if E["Craftsman's Writ: Wild Leather Shoulders"] == nil then E["Craftsman's Writ: Wild Leather Shoulders"] = "Zanaatkâr Yazısı: Yabani Deri Omuzluklar" end
if E["Craftsman's Writ: Wildvine Potion"] == nil then E["Craftsman's Writ: Wildvine Potion"] = "Zanaatkâr Yazısı: Yabanisarmaşık İksiri" end
if E["Craftsman's Writ: Wizardweave Turban"] == nil then E["Craftsman's Writ: Wizardweave Turban"] = "Zanaatkâr Yazısı: Büyücüdokuma Sarık" end
if E["Crawler's Clackers"] == nil then E["Crawler's Clackers"] = "Sürüngenin Kıskaçları" end
if E["Crazed Firecaller's Cloak"] == nil then E["Crazed Firecaller's Cloak"] = "Çılgın Ateş Çağırıcının Pelerini" end
if E["Criminal's Pauldrons"] == nil then E["Criminal's Pauldrons"] = "Suçlunun Omuzlukları" end
if E["Croaky's Head"] == nil then E["Croaky's Head"] = "Croaky'nin Kafası" end
if E["Cross-Stitched Cord"] == nil then E["Cross-Stitched Cord"] = "Çapraz Dikişli Kuşak" end
if E["Cross-stitched Belt"] == nil then E["Cross-stitched Belt"] = "Çapraz Dikişli Kemer" end
if E["Cross-stitched Bracers"] == nil then E["Cross-stitched Bracers"] = "Çapraz Dikişli Bileklikler" end
if E["Cross-stitched Cloak"] == nil then E["Cross-stitched Cloak"] = "Çapraz Dikişli Pelerin" end
if E["Cross-stitched Gloves"] == nil then E["Cross-stitched Gloves"] = "Çapraz Dikişli Eldivenler" end
if E["Cross-stitched Pants"] == nil then E["Cross-stitched Pants"] = "Çapraz Dikişli Pantolon" end
if E["Cross-stitched Sandals"] == nil then E["Cross-stitched Sandals"] = "Çapraz Dikişli Sandaletler" end
if E["Cross-stitched Shoulderpads"] == nil then E["Cross-stitched Shoulderpads"] = "Çapraz Dikişli Omuzluklar" end
if E["Cross-stitched Vest"] == nil then E["Cross-stitched Vest"] = "Çapraz Dikişli Yelek" end
if E["Crossroads' Supply Crates"] == nil then E["Crossroads' Supply Crates"] = "Crossroads'un Erzak Sandıkları" end
if E["Crown Jewels of Eldre'Thalas"] == nil then E["Crown Jewels of Eldre'Thalas"] = "Eldre'Thalas'ın Taç Mücevherleri" end
if E["Crusader's Chain Belt"] == nil then E["Crusader's Chain Belt"] = "Haçlı Zincir Kemeri" end
if E["Crusader's Chain Helm"] == nil then E["Crusader's Chain Helm"] = "Haçlı Zincir Miğferi" end
if E["Crusader's Chain Leggings"] == nil then E["Crusader's Chain Leggings"] = "Haçlı Zincir Tozlukları" end
if E["Crusader's Chain Shirt"] == nil then E["Crusader's Chain Shirt"] = "Haçlı Zincir Gömleği" end
if E["Crusader's Gloves"] == nil then E["Crusader's Gloves"] = "Haçlı Eldivenleri" end
if E["Crusader's Silvered Chain Helm"] == nil then E["Crusader's Silvered Chain Helm"] = "Haçlı Gümüşlü Zincir Miğferi" end
if E["Crusader's Silvered Chain Leggings"] == nil then E["Crusader's Silvered Chain Leggings"] = "Haçlı Gümüşlü Zincir Tozlukları" end
if E["Crusader's Silvered Chain Shirt"] == nil then E["Crusader's Silvered Chain Shirt"] = "Haçlı Gümüşlü Zincir Gömleği" end
if E["Crystal-flecked Cord"] == nil then E["Crystal-flecked Cord"] = "Kristal Benekli Kuşak" end
if E["Crystal-flecked Waistguard"] == nil then E["Crystal-flecked Waistguard"] = "Kristal Benekli Bel Koruyucusu" end
if E["Cult Hunter's Boots"] == nil then E["Cult Hunter's Boots"] = "Tarikat Avcısının Çizmeleri" end
if E["Cultist's Armguards"] == nil then E["Cultist's Armguards"] = "Tarikatçı Kol Koruyucuları" end
if E["Cultist's Chestguard"] == nil then E["Cultist's Chestguard"] = "Tarikatçı Göğüslüğü" end
if E["Curly's Chopper"] == nil then E["Curly's Chopper"] = "Curly'nin Satırı" end
if E["Cutthroat's Signet"] == nil then E["Cutthroat's Signet"] = "Gırtlak Kesenin Mühür Yüzüğü" end
if E["Cutty's Rune"] == nil then E["Cutty's Rune"] = "Cutty'nin Runu" end
if E["Daewyn's Girdle"] == nil then E["Daewyn's Girdle"] = "Daewyn'in Kuşağı" end
if E["Daggerfang's Daggerfang"] == nil then E["Daggerfang's Daggerfang"] = "Daggerfang'in Hançer Dişi" end
if E["Damp Diary Page (Day 4)"] == nil then E["Damp Diary Page (Day 4)"] = "Nemli Günlük Sayfası (4. Gün)" end
if E["Damp Diary Page (Day 512)"] == nil then E["Damp Diary Page (Day 512)"] = "Nemli Günlük Sayfası (512. Gün)" end
if E["Damp Diary Page (Day 87)"] == nil then E["Damp Diary Page (Day 87)"] = "Nemli Günlük Sayfası (87. Gün)" end
if E["Danath's Copper Coin"] == nil then E["Danath's Copper Coin"] = "Danath'ın Bakır Sikkesi" end
if E["Danitha's Satchel"] == nil then E["Danitha's Satchel"] = "Danitha'nın Heybesi" end
if E["Dargol's Skull"] == nil then E["Dargol's Skull"] = "Dargol'un Kafatası" end
if E["Darkspear Insurgent's Spellblade"] == nil then E["Darkspear Insurgent's Spellblade"] = "Darkspear İsyancısının Büyü Kılıcı" end
if E["Darkspear Raider's Cloak"] == nil then E["Darkspear Raider's Cloak"] = "Darkspear Yağmacısının Pelerini" end
if E["Darkspear Raider's Reaper"] == nil then E["Darkspear Raider's Reaper"] = "Darkspear Yağmacısının Tırpanı" end
if E["Darkspear Skirmisher's Bludgeon"] == nil then E["Darkspear Skirmisher's Bludgeon"] = "Darkspear Akıncısının Sopası" end
if E["Darthalia's Orders"] == nil then E["Darthalia's Orders"] = "Darthalia'nın Emirleri" end
if E["Dathrohan's Correspondance"] == nil then E["Dathrohan's Correspondance"] = "Dathrohan'ın Yazışmaları" end
if E["Deadwind Cage \"Key\""] == nil then E["Deadwind Cage \"Key\""] = "Deadwind Kafesi \"Anahtarı\"" end
if E["Death's Essence"] == nil then E["Death's Essence"] = "Ölümün Özü" end
if E["Deckswabber's Mitts"] == nil then E["Deckswabber's Mitts"] = "Güverte Temizleyicisinin Eldivenleri" end
if E["Deep-Sea Waders"] == nil then E["Deep-Sea Waders"] = "Derin Deniz Çizmeleri" end
if E["Defender's Aegis"] == nil then E["Defender's Aegis"] = "Savunucunun Siperi" end
if E["Defender's Bracers"] == nil then E["Defender's Bracers"] = "Savunucu Bileklikleri" end
if E["Defender's Grip Stabilizer"] == nil then E["Defender's Grip Stabilizer"] = "Savunucunun Kabza Dengeleyicisi" end
if E["Defender's Leather Armor"] == nil then E["Defender's Leather Armor"] = "Savunucu Deri Zırhı" end
if E["Defender's Leather Belt"] == nil then E["Defender's Leather Belt"] = "Savunucu Deri Kemeri" end
if E["Defender's Leather Boots"] == nil then E["Defender's Leather Boots"] = "Savunucu Deri Çizmeleri" end
if E["Defender's Leather Gloves"] == nil then E["Defender's Leather Gloves"] = "Savunucu Deri Eldivenleri" end
if E["Defender's Leather Helm"] == nil then E["Defender's Leather Helm"] = "Savunucu Deri Miğferi" end
if E["Defender's Leather Hood"] == nil then E["Defender's Leather Hood"] = "Savunucu Deri Başlığı" end
if E["Defender's Leather Kilt"] == nil then E["Defender's Leather Kilt"] = "Savunucu Deri Eteği" end
if E["Defender's Leather Pants"] == nil then E["Defender's Leather Pants"] = "Savunucu Deri Pantolonu" end
if E["Defender's Leather Tunic"] == nil then E["Defender's Leather Tunic"] = "Savunucu Deri Tuniği" end
if E["Deliah's Ring"] == nil then E["Deliah's Ring"] = "Deliah'nın Yüzüğü" end
if E["Den Guardian's Crusher"] == nil then E["Den Guardian's Crusher"] = "İn Muhafızının Ezicisi" end
if E["Dendweller's Hammer"] == nil then E["Dendweller's Hammer"] = "İnsakininin Çekici" end
if E["Denmother's Hide"] == nil then E["Denmother's Hide"] = "İn Anasının Postu" end
if E["Denric's Dog Tags"] == nil then E["Denric's Dog Tags"] = "Denric'in Künyeleri" end
if E["Desert Crawler's Claw"] == nil then E["Desert Crawler's Claw"] = "Çöl Sürüngeninin Pençesi" end
if E["Devlin's Remains"] == nil then E["Devlin's Remains"] = "Devlin'in Kalıntıları" end
if E["Dillinger's Report"] == nil then E["Dillinger's Report"] = "Dillinger'ın Raporu" end
if E["Dimensional Transporter - Mt. Hyjal"] == nil then E["Dimensional Transporter - Mt. Hyjal"] = "Boyutsal Taşıyıcı - Mt. Hyjal" end
if E["Direhorn Matriarch's Heart"] == nil then E["Direhorn Matriarch's Heart"] = "Direhorn Anaerkinin Kalbi" end
if E["Dirt-Heavy Bracers"] == nil then E["Dirt-Heavy Bracers"] = "Toprağa Bulanmış Bileklikler" end
if E["Dirt-trodden Boots"] == nil then E["Dirt-trodden Boots"] = "Toprak Çiğnemiş Çizmeler" end
if E["Disease Ward - Fel Ash Experimentation Notes"] == nil then E["Disease Ward - Fel Ash Experimentation Notes"] = "Hastalık Koğuşu - Fel Külü Deney Notları" end
if E["Doomcaller's Pants"] == nil then E["Doomcaller's Pants"] = "Kıyamet Çağırıcının Pantolonu" end
if E["Double-Plated Legplates"] == nil then E["Double-Plated Legplates"] = "Çift Plakalı Bacak Plakaları" end
if E["Double-stitched Cloak"] == nil then E["Double-stitched Cloak"] = "Çift Dikişli Pelerin" end
if E["Dream-Infused Dragonscale"] == nil then E["Dream-Infused Dragonscale"] = "Rüyayla Dolu Ejder Pulu" end
if E["Dream-Touched Dragonscale"] == nil then E["Dream-Touched Dragonscale"] = "Rüya Dokunuşlu Ejder Pulu" end
if E["Dreamer's Chestguard"] == nil then E["Dreamer's Chestguard"] = "Rüyacı Göğüslüğü" end
if E["Dreamer's Leggings"] == nil then E["Dreamer's Leggings"] = "Rüyacı Tozlukları" end
if E["Dro'zem's Tunic"] == nil then E["Dro'zem's Tunic"] = "Dro'zem'in Tuniği" end
if E["Dudd's Second-Favorite Wand"] == nil then E["Dudd's Second-Favorite Wand"] = "Dudd'ın En Sevdiği İkinci Değnek" end
if E["Dudd's Thinkin' Cap"] == nil then E["Dudd's Thinkin' Cap"] = "Dudd'ın Düşünme Şapkası" end
if E["Dunston's Ogre Duster"] == nil then E["Dunston's Ogre Duster"] = "Dunston'ın Ogre Pardösüsü" end
if E["Durgen Dirgehammer's Head"] == nil then E["Durgen Dirgehammer's Head"] = "Durgen Dirgehammer'ın Kafası" end
if E["Durgen's Crescent Axe"] == nil then E["Durgen's Crescent Axe"] = "Durgen'in Hilal Baltası" end
if E["Durnan's Scalding Mornbrew"] == nil then E["Durnan's Scalding Mornbrew"] = "Durnan'ın Kaynar Sabah Demi" end
if E["Duskstalker's Hide"] == nil then E["Duskstalker's Hide"] = "Duskstalker'ın Postu" end
if E["Dust-covered Leggings"] == nil then E["Dust-covered Leggings"] = "Toz Kaplı Tozluklar" end
if E["EZ and SAF Field Transporter: Mt. Hyjal"] == nil then E["EZ and SAF Field Transporter: Mt. Hyjal"] = "EZ ve SAF Saha Taşıyıcısı: Mt. Hyjal" end
if E["EZ-Thro Bronze Mortar"] == nil then E["EZ-Thro Bronze Mortar"] = "EZ-Atış Bronz Havan" end
if E["EZ-Thro Copper Bomb XL"] == nil then E["EZ-Thro Copper Bomb XL"] = "EZ-Atış Bakır Bomba XL" end
if E["EZ-Thro Dark Bomb"] == nil then E["EZ-Thro Dark Bomb"] = "EZ-Atış Karanlık Bomba" end
if E["EZ-Thro Field Transporter: Gadgetzan"] == nil then E["EZ-Thro Field Transporter: Gadgetzan"] = "EZ-Atış Saha Taşıyıcısı: Gadgetzan" end
if E["EZ-Thro Fireproof Fuse"] == nil then E["EZ-Thro Fireproof Fuse"] = "EZ-Atış Yanmaz Fitil" end
if E["EZ-Thro Grenade"] == nil then E["EZ-Thro Grenade"] = "EZ-Atış El Bombası" end
if E["EZ-Thro Magnetic Displacer"] == nil then E["EZ-Thro Magnetic Displacer"] = "EZ-Atış Manyetik Yer Değiştirici" end
if E["EZ-Thro Mana Bomb"] == nil then E["EZ-Thro Mana Bomb"] = "EZ-Atış Mana Bombası" end
if E["EZ-Thro Shell"] == nil then E["EZ-Thro Shell"] = "EZ-Atış Kovan" end
if E["EZ-Thro Thorium Grenade"] == nil then E["EZ-Thro Thorium Grenade"] = "EZ-Atış Toryum El Bombası" end
if E["EZ-Thro Tru-Trigger"] == nil then E["EZ-Thro Tru-Trigger"] = "EZ-Atış Tam-Tetik" end
if E["EZ-Thro Wrap"] == nil then E["EZ-Thro Wrap"] = "EZ-Atış Sargı" end
if E["Earth-Infused Rockguards"] == nil then E["Earth-Infused Rockguards"] = "Toprakla Dolu Kaya Koruyucular" end
if E["Echeyakee's Hide"] == nil then E["Echeyakee's Hide"] = "Echeyakee'nin Postu" end
if E["Edward's Knife"] == nil then E["Edward's Knife"] = "Edward'ın Bıçağı" end
if E["Elaadrin Evengale's Silver Coin"] == nil then E["Elaadrin Evengale's Silver Coin"] = "Elaadrin Evengale'in Gümüş Sikkesi" end
if E["Elder's Cane"] == nil then E["Elder's Cane"] = "Yaşlı Bastonu" end
if E["Elder's Tunic"] == nil then E["Elder's Tunic"] = "Yaşlı Tuniği" end
if E["Elementalist's Guard"] == nil then E["Elementalist's Guard"] = "Elementalistin Muhafızı" end
if E["Elite Peacekeeper's Leggings"] == nil then E["Elite Peacekeeper's Leggings"] = "Seçkin Barış Muhafızı Tozlukları" end
if E["Elixir of Lion's Strength"] == nil then E["Elixir of Lion's Strength"] = "Aslan Gücü İksiri" end
if E["Elling Trias' Copper Coin"] == nil then E["Elling Trias' Copper Coin"] = "Elling Trias'ın Bakır Sikkesi" end
if E["Elmpaw's Head"] == nil then E["Elmpaw's Head"] = "Elmpaw'un Kafası" end
if E["Emerald Watcher's Dreamstaff"] == nil then E["Emerald Watcher's Dreamstaff"] = "Zümrüt Gözcünün Rüya Asası" end
if E["Emogg's \"Crusher\""] == nil then E["Emogg's \"Crusher\""] = "Emogg'un \"Ezicisi\"" end
if E["Enchant 2H Weapon - Agility"] == nil then E["Enchant 2H Weapon - Agility"] = "İki Elli Silah Büyüsü - Çeviklik" end
if E["Enchant 2H Weapon - Grand Arcanist"] == nil then E["Enchant 2H Weapon - Grand Arcanist"] = "İki Elli Silah Büyüsü - Yüce Arkanist" end
if E["Enchant 2H Weapon - Grand Inquisitor"] == nil then E["Enchant 2H Weapon - Grand Inquisitor"] = "İki Elli Silah Büyüsü - Yüce Engizisyoncu" end
if E["Enchant 2H Weapon - Greater Impact"] == nil then E["Enchant 2H Weapon - Greater Impact"] = "İki Elli Silah Büyüsü - Büyük Darbe" end
if E["Enchant 2H Weapon - Impact"] == nil then E["Enchant 2H Weapon - Impact"] = "İki Elli Silah Büyüsü - Darbe" end
if E["Enchant 2H Weapon - Lesser Agility"] == nil then E["Enchant 2H Weapon - Lesser Agility"] = "İki Elli Silah Büyüsü - Küçük Çeviklik" end
if E["Enchant 2H Weapon - Lesser Impact"] == nil then E["Enchant 2H Weapon - Lesser Impact"] = "İki Elli Silah Büyüsü - Küçük Darbe" end
if E["Enchant 2H Weapon - Lesser Intellect"] == nil then E["Enchant 2H Weapon - Lesser Intellect"] = "İki Elli Silah Büyüsü - Küçük Zekâ" end
if E["Enchant 2H Weapon - Lesser Spirit"] == nil then E["Enchant 2H Weapon - Lesser Spirit"] = "İki Elli Silah Büyüsü - Küçük Ruh" end
if E["Enchant 2H Weapon - Lesser Strength"] == nil then E["Enchant 2H Weapon - Lesser Strength"] = "İki Elli Silah Büyüsü - Küçük Güç" end
if E["Enchant 2H Weapon - Major Intellect"] == nil then E["Enchant 2H Weapon - Major Intellect"] = "İki Elli Silah Büyüsü - Yüce Zeka" end
if E["Enchant 2H Weapon - Major Spirit"] == nil then E["Enchant 2H Weapon - Major Spirit"] = "İki Elli Silah Büyüsü - Yüce Ruh" end
if E["Enchant 2H Weapon - Mighty Healing Power"] == nil then E["Enchant 2H Weapon - Mighty Healing Power"] = "İki Elli Silah Büyüsü - Kudretli İyileştirme Gücü" end
if E["Enchant 2H Weapon - Mighty Spell Power"] == nil then E["Enchant 2H Weapon - Mighty Spell Power"] = "İki Elli Silah Büyüsü - Kudretli Büyü Gücü" end
if E["Enchant 2H Weapon - Minor Impact"] == nil then E["Enchant 2H Weapon - Minor Impact"] = "İki Elli Silah Büyüsü - Küçük Darbe" end
if E["Enchant 2H Weapon - Spellblasting"] == nil then E["Enchant 2H Weapon - Spellblasting"] = "İki Elli Silah Büyüsü - Büyü Patlatma" end
if E["Enchant 2H Weapon - Superior Impact"] == nil then E["Enchant 2H Weapon - Superior Impact"] = "İki Elli Silah Büyüsü - Üstün Darbe" end
if E["Enchant Boots - Agility"] == nil then E["Enchant Boots - Agility"] = "Çizme Büyüsü - Çeviklik" end
if E["Enchant Boots - Greater Agility"] == nil then E["Enchant Boots - Greater Agility"] = "Çizme Büyüsü - Büyük Çeviklik" end
if E["Enchant Boots - Greater Stamina"] == nil then E["Enchant Boots - Greater Stamina"] = "Çizme Büyüsü - Büyük Dayanıklılık" end
if E["Enchant Boots - Lesser Agility"] == nil then E["Enchant Boots - Lesser Agility"] = "Çizme Büyüsü - Hafif Çeviklik" end
if E["Enchant Boots - Lesser Spirit"] == nil then E["Enchant Boots - Lesser Spirit"] = "Çizme Büyüsü - Hafif Ruh" end
if E["Enchant Boots - Lesser Stamina"] == nil then E["Enchant Boots - Lesser Stamina"] = "Çizme Büyüsü - Hafif Dayanıklılık" end
if E["Enchant Boots - Minor Agility"] == nil then E["Enchant Boots - Minor Agility"] = "Çizme Büyüsü - Küçük Çeviklik" end
if E["Enchant Boots - Minor Speed"] == nil then E["Enchant Boots - Minor Speed"] = "Çizme Büyüsü - Küçük Hız" end
if E["Enchant Boots - Minor Stamina"] == nil then E["Enchant Boots - Minor Stamina"] = "Çizme Büyüsü - Küçük Dayanıklılık" end
if E["Enchant Boots - Spirit"] == nil then E["Enchant Boots - Spirit"] = "Çizme Büyüsü - Ruh" end
if E["Enchant Boots - Stamina"] == nil then E["Enchant Boots - Stamina"] = "Çizme Büyüsü - Dayanıklılık" end
if E["Enchant Bracer - Agility"] == nil then E["Enchant Bracer - Agility"] = "Bileklik Büyüsü - Çeviklik" end
if E["Enchant Bracer - Deflection"] == nil then E["Enchant Bracer - Deflection"] = "Bileklik Büyüsü - Saptırma" end
if E["Enchant Bracer - Greater Agility"] == nil then E["Enchant Bracer - Greater Agility"] = "Bileklik Büyüsü - Büyük Çeviklik" end
if E["Enchant Bracer - Greater Intellect"] == nil then E["Enchant Bracer - Greater Intellect"] = "Bileklik Büyüsü - Büyük Zeka" end
if E["Enchant Bracer - Greater Spellpower"] == nil then E["Enchant Bracer - Greater Spellpower"] = "Bileklik Büyüsü - Büyük Büyü Gücü" end
if E["Enchant Bracer - Greater Spirit"] == nil then E["Enchant Bracer - Greater Spirit"] = "Bileklik Büyüsü - Büyük Ruh" end
if E["Enchant Bracer - Greater Stamina"] == nil then E["Enchant Bracer - Greater Stamina"] = "Bileklik Büyüsü - Büyük Dayanıklılık" end
if E["Enchant Bracer - Greater Strength"] == nil then E["Enchant Bracer - Greater Strength"] = "Bileklik Büyüsü - Büyük Güç" end
if E["Enchant Bracer - Healing Power"] == nil then E["Enchant Bracer - Healing Power"] = "Bileklik Büyüsü - İyileştirme Gücü" end
if E["Enchant Bracer - Inferior Stamina"] == nil then E["Enchant Bracer - Inferior Stamina"] = "Bileklik Büyüsü - Düşük Dayanıklılık" end
if E["Enchant Bracer - Intellect"] == nil then E["Enchant Bracer - Intellect"] = "Bileklik Büyüsü - Zeka" end
if E["Enchant Bracer - Lesser Agility"] == nil then E["Enchant Bracer - Lesser Agility"] = "Bileklik Büyüsü - Hafif Çeviklik" end
if E["Enchant Bracer - Lesser Deflection"] == nil then E["Enchant Bracer - Lesser Deflection"] = "Bileklik Büyüsü - Hafif Saptırma" end
if E["Enchant Bracer - Lesser Healing Power"] == nil then E["Enchant Bracer - Lesser Healing Power"] = "Bileklik Büyüsü - Hafif İyileştirme Gücü" end
if E["Enchant Bracer - Lesser Intellect"] == nil then E["Enchant Bracer - Lesser Intellect"] = "Bileklik Büyüsü - Hafif Zeka" end
if E["Enchant Bracer - Lesser Spirit"] == nil then E["Enchant Bracer - Lesser Spirit"] = "Bileklik Büyüsü - Hafif Ruh" end
if E["Enchant Bracer - Lesser Stamina"] == nil then E["Enchant Bracer - Lesser Stamina"] = "Bileklik Büyüsü - Hafif Dayanıklılık" end
if E["Enchant Bracer - Lesser Strength"] == nil then E["Enchant Bracer - Lesser Strength"] = "Bileklik Büyüsü - Hafif Güç" end
if E["Enchant Bracer - Mana Regeneration"] == nil then E["Enchant Bracer - Mana Regeneration"] = "Bileklik Büyüsü - Mana Yenilenmesi" end
if E["Enchant Bracer - Minor Agility"] == nil then E["Enchant Bracer - Minor Agility"] = "Bileklik Büyüsü - Küçük Çeviklik" end
if E["Enchant Bracer - Minor Deflect"] == nil then E["Enchant Bracer - Minor Deflect"] = "Bileklik Büyüsü - Küçük Saptırma" end
if E["Enchant Bracer - Minor Healing Power"] == nil then E["Enchant Bracer - Minor Healing Power"] = "Bileklik Büyüsü - Küçük İyileştirme Gücü" end
if E["Enchant Bracer - Minor Intellect"] == nil then E["Enchant Bracer - Minor Intellect"] = "Bileklik Büyüsü - Küçük Zeka" end
if E["Enchant Bracer - Minor Spirit"] == nil then E["Enchant Bracer - Minor Spirit"] = "Bileklik Büyüsü - Küçük Ruh" end
if E["Enchant Bracer - Minor Stamina"] == nil then E["Enchant Bracer - Minor Stamina"] = "Bileklik Büyüsü - Küçük Dayanıklılık" end
if E["Enchant Bracer - Minor Strength"] == nil then E["Enchant Bracer - Minor Strength"] = "Bileklik Büyüsü - Küçük Güç" end
if E["Enchant Bracer - Spell Power"] == nil then E["Enchant Bracer - Spell Power"] = "Bileklik Büyüsü - Büyü Gücü" end
if E["Enchant Bracer - Spirit"] == nil then E["Enchant Bracer - Spirit"] = "Bileklik Büyüsü - Ruh" end
if E["Enchant Bracer - Stamina"] == nil then E["Enchant Bracer - Stamina"] = "Bileklik Büyüsü - Dayanıklılık" end
if E["Enchant Bracer - Strength"] == nil then E["Enchant Bracer - Strength"] = "Bileklik Büyüsü - Güç" end
if E["Enchant Bracer - Superior Agility"] == nil then E["Enchant Bracer - Superior Agility"] = "Bileklik Büyüsü - Üstün Çeviklik" end
if E["Enchant Bracer - Superior Deflection"] == nil then E["Enchant Bracer - Superior Deflection"] = "Bileklik Büyüsü - Üstün Saptırma" end
if E["Enchant Bracer - Superior Intellect"] == nil then E["Enchant Bracer - Superior Intellect"] = "Bileklik Büyüsü - Üstün Zeka" end
if E["Enchant Bracer - Superior Spirit"] == nil then E["Enchant Bracer - Superior Spirit"] = "Bileklik Büyüsü - Üstün Ruh" end
if E["Enchant Bracer - Superior Stamina"] == nil then E["Enchant Bracer - Superior Stamina"] = "Bileklik Büyüsü - Üstün Dayanıklılık" end
if E["Enchant Bracer - Superior Strength"] == nil then E["Enchant Bracer - Superior Strength"] = "Bileklik Büyüsü - Üstün Güç" end
if E["Enchant Chest - Absorption"] == nil then E["Enchant Chest - Absorption"] = "Göğüs Büyüsü - Emilim" end
if E["Enchant Chest - Greater Intellect"] == nil then E["Enchant Chest - Greater Intellect"] = "Göğüs Büyüsü - Büyük Zeka" end
if E["Enchant Chest - Greater Stamina"] == nil then E["Enchant Chest - Greater Stamina"] = "Göğüs Büyüsü - Büyük Dayanıklılık" end
if E["Enchant Chest - Greater Stats"] == nil then E["Enchant Chest - Greater Stats"] = "Göğüs Büyüsü - Büyük Nitelikler" end
if E["Enchant Chest - Inferior Stamina"] == nil then E["Enchant Chest - Inferior Stamina"] = "Göğüs Büyüsü - Düşük Dayanıklılık" end
if E["Enchant Chest - Intellect"] == nil then E["Enchant Chest - Intellect"] = "Göğüs Büyüsü - Zeka" end
if E["Enchant Chest - Lesser Absorption"] == nil then E["Enchant Chest - Lesser Absorption"] = "Göğüs Büyüsü - Hafif Emilim" end
if E["Enchant Chest - Lesser Intellect"] == nil then E["Enchant Chest - Lesser Intellect"] = "Göğüs Büyüsü - Hafif Zeka" end
if E["Enchant Chest - Lesser Stamina"] == nil then E["Enchant Chest - Lesser Stamina"] = "Göğüs Büyüsü - Hafif Dayanıklılık" end
if E["Enchant Chest - Lesser Stats"] == nil then E["Enchant Chest - Lesser Stats"] = "Göğüs Büyüsü - Hafif Nitelikler" end
if E["Enchant Chest - Living Stats"] == nil then E["Enchant Chest - Living Stats"] = "Göğüs Büyüsü - Canlı Nitelikler" end
if E["Enchant Chest - Major Intellect"] == nil then E["Enchant Chest - Major Intellect"] = "Göğüs Büyüsü - Yüce Zeka" end
if E["Enchant Chest - Major Stamina"] == nil then E["Enchant Chest - Major Stamina"] = "Göğüs Büyüsü - Yüce Dayanıklılık" end
if E["Enchant Chest - Minor Absorption"] == nil then E["Enchant Chest - Minor Absorption"] = "Göğüs Büyüsü - Küçük Emilim" end
if E["Enchant Chest - Minor Intellect"] == nil then E["Enchant Chest - Minor Intellect"] = "Göğüs Büyüsü - Küçük Zeka" end
if E["Enchant Chest - Minor Stats"] == nil then E["Enchant Chest - Minor Stats"] = "Göğüs Büyüsü - Küçük Nitelikler" end
if E["Enchant Chest - Retricutioner"] == nil then E["Enchant Chest - Retricutioner"] = "Göğüs Büyüsü - Cezalandırıcı" end
if E["Enchant Chest - Stamina"] == nil then E["Enchant Chest - Stamina"] = "Göğüs Büyüsü - Dayanıklılık" end
if E["Enchant Chest - Stats"] == nil then E["Enchant Chest - Stats"] = "Göğüs Büyüsü - Nitelikler" end
if E["Enchant Chest - Superior Intellect"] == nil then E["Enchant Chest - Superior Intellect"] = "Göğüs Büyüsü - Üstün Zeka" end
if E["Enchant Chest - Superior Stamina"] == nil then E["Enchant Chest - Superior Stamina"] = "Göğüs Büyüsü - Üstün Dayanıklılık" end
if E["Enchant Cloak - Agility"] == nil then E["Enchant Cloak - Agility"] = "Pelerin Büyüsü - Çeviklik" end
if E["Enchant Cloak - Defense"] == nil then E["Enchant Cloak - Defense"] = "Pelerin Büyüsü - Savunma" end
if E["Enchant Cloak - Dodge"] == nil then E["Enchant Cloak - Dodge"] = "Pelerin Büyüsü - Kaçınma" end
if E["Enchant Cloak - Fire Resistance"] == nil then E["Enchant Cloak - Fire Resistance"] = "Pelerin Büyüsü - Ateş Direnci" end
if E["Enchant Cloak - Greater Defense"] == nil then E["Enchant Cloak - Greater Defense"] = "Pelerin Büyüsü - Büyük Savunma" end
if E["Enchant Cloak - Greater Fire Resistance"] == nil then E["Enchant Cloak - Greater Fire Resistance"] = "Pelerin Büyüsü - Büyük Ateş Direnci" end
if E["Enchant Cloak - Greater Nature Resistance"] == nil then E["Enchant Cloak - Greater Nature Resistance"] = "Pelerin Büyüsü - Büyük Doğa Direnci" end
if E["Enchant Cloak - Greater Resistance"] == nil then E["Enchant Cloak - Greater Resistance"] = "Pelerin Büyüsü - Büyük Direnç" end
if E["Enchant Cloak - Lesser Agility"] == nil then E["Enchant Cloak - Lesser Agility"] = "Pelerin Büyüsü - Hafif Çeviklik" end
if E["Enchant Cloak - Lesser Fire Resistance"] == nil then E["Enchant Cloak - Lesser Fire Resistance"] = "Pelerin Büyüsü - Hafif Ateş Direnci" end
if E["Enchant Cloak - Lesser Protection"] == nil then E["Enchant Cloak - Lesser Protection"] = "Pelerin Büyüsü - Hafif Koruma" end
if E["Enchant Cloak - Lesser Shadow Resistance"] == nil then E["Enchant Cloak - Lesser Shadow Resistance"] = "Pelerin Büyüsü - Hafif Gölge Direnci" end
if E["Enchant Cloak - Minor Agility"] == nil then E["Enchant Cloak - Minor Agility"] = "Pelerin Büyüsü - Küçük Çeviklik" end
if E["Enchant Cloak - Minor Protection"] == nil then E["Enchant Cloak - Minor Protection"] = "Pelerin Büyüsü - Küçük Koruma" end
if E["Enchant Cloak - Minor Resistance"] == nil then E["Enchant Cloak - Minor Resistance"] = "Pelerin Büyüsü - Küçük Direnç" end
if E["Enchant Cloak - Resistance"] == nil then E["Enchant Cloak - Resistance"] = "Pelerin Büyüsü - Direnç" end
if E["Enchant Cloak - Stealth"] == nil then E["Enchant Cloak - Stealth"] = "Pelerin Büyüsü - Gizlilik" end
if E["Enchant Cloak - Subtlety"] == nil then E["Enchant Cloak - Subtlety"] = "Pelerin Büyüsü - İncelik" end
if E["Enchant Cloak - Superior Defense"] == nil then E["Enchant Cloak - Superior Defense"] = "Pelerin Büyüsü - Üstün Savunma" end
if E["Enchant Gloves - Advanced Herbalism"] == nil then E["Enchant Gloves - Advanced Herbalism"] = "Eldiven Büyüsü - İleri Bitkicilik" end
if E["Enchant Gloves - Advanced Mining"] == nil then E["Enchant Gloves - Advanced Mining"] = "Eldiven Büyüsü - İleri Madencilik" end
if E["Enchant Gloves - Advanced Skinning"] == nil then E["Enchant Gloves - Advanced Skinning"] = "Eldiven Büyüsü - İleri Deri Yüzme" end
if E["Enchant Gloves - Agility"] == nil then E["Enchant Gloves - Agility"] = "Eldiven Büyüsü - Çeviklik" end
if E["Enchant Gloves - Arcane Power"] == nil then E["Enchant Gloves - Arcane Power"] = "Eldiven Büyüsü - Arkan Gücü" end
if E["Enchant Gloves - Fire Power"] == nil then E["Enchant Gloves - Fire Power"] = "Eldiven Büyüsü - Ateş Gücü" end
if E["Enchant Gloves - Fishing"] == nil then E["Enchant Gloves - Fishing"] = "Eldiven Büyüsü - Balıkçılık" end
if E["Enchant Gloves - Frost Power"] == nil then E["Enchant Gloves - Frost Power"] = "Eldiven Büyüsü - Buz Gücü" end
if E["Enchant Gloves - Greater Agility"] == nil then E["Enchant Gloves - Greater Agility"] = "Eldiven Büyüsü - Büyük Çeviklik" end
if E["Enchant Gloves - Greater Strength"] == nil then E["Enchant Gloves - Greater Strength"] = "Eldiven Büyüsü - Büyük Güç" end
if E["Enchant Gloves - Healing Power"] == nil then E["Enchant Gloves - Healing Power"] = "Eldiven Büyüsü - İyileştirme Gücü" end
if E["Enchant Gloves - Herbalism"] == nil then E["Enchant Gloves - Herbalism"] = "Eldiven Büyüsü - Bitkicilik" end
if E["Enchant Gloves - Holy Power"] == nil then E["Enchant Gloves - Holy Power"] = "Eldiven Büyüsü - Kutsal Güç" end
if E["Enchant Gloves - Lotus Claw"] == nil then E["Enchant Gloves - Lotus Claw"] = "Eldiven Büyüsü - Lotus Pençesi" end
if E["Enchant Gloves - Mining"] == nil then E["Enchant Gloves - Mining"] = "Eldiven Büyüsü - Madencilik" end
if E["Enchant Gloves - Minor Haste"] == nil then E["Enchant Gloves - Minor Haste"] = "Eldiven Büyüsü - Küçük Hız" end
if E["Enchant Gloves - Natural Power"] == nil then E["Enchant Gloves - Natural Power"] = "Eldiven Büyüsü - Doğa Gücü" end
if E["Enchant Gloves - Riding Skill"] == nil then E["Enchant Gloves - Riding Skill"] = "Eldiven Büyüsü - Binicilik Becerisi" end
if E["Enchant Gloves - Shadow Power"] == nil then E["Enchant Gloves - Shadow Power"] = "Eldiven Büyüsü - Gölge Gücü" end
if E["Enchant Gloves - Skinning"] == nil then E["Enchant Gloves - Skinning"] = "Eldiven Büyüsü - Deri Yüzme" end
if E["Enchant Gloves - Strength"] == nil then E["Enchant Gloves - Strength"] = "Eldiven Büyüsü - Güç" end
if E["Enchant Gloves - Superior Agility"] == nil then E["Enchant Gloves - Superior Agility"] = "Eldiven Büyüsü - Üstün Çeviklik" end
if E["Enchant Gloves - Superior Strength"] == nil then E["Enchant Gloves - Superior Strength"] = "Eldiven Büyüsü - Üstün Güç" end
if E["Enchant Gloves - Threat"] == nil then E["Enchant Gloves - Threat"] = "Eldiven Büyüsü - Tehdit" end
if E["Enchant Necklace - Agility"] == nil then E["Enchant Necklace - Agility"] = "Kolye Büyüsü - Çeviklik" end
if E["Enchant Necklace - Deflection"] == nil then E["Enchant Necklace - Deflection"] = "Kolye Büyüsü - Saptırma" end
if E["Enchant Necklace - Healing Power"] == nil then E["Enchant Necklace - Healing Power"] = "Kolye Büyüsü - İyileştirme Gücü" end
if E["Enchant Necklace - Spell Power"] == nil then E["Enchant Necklace - Spell Power"] = "Kolye Büyüsü - Büyü Gücü" end
if E["Enchant Necklace - Strength"] == nil then E["Enchant Necklace - Strength"] = "Kolye Büyüsü - Güç" end
if E["Enchant Off-Hand - Excellent Spirit"] == nil then E["Enchant Off-Hand - Excellent Spirit"] = "Yan El Büyüsü - Mükemmel Ruh" end
if E["Enchant Off-Hand - Superior Intellect"] == nil then E["Enchant Off-Hand - Superior Intellect"] = "Yan El Büyüsü - Üstün Zeka" end
if E["Enchant Off-Hand - Wisdom"] == nil then E["Enchant Off-Hand - Wisdom"] = "Yan El Büyüsü - Bilgelik" end
if E["Enchant Shield - Critical Strike"] == nil then E["Enchant Shield - Critical Strike"] = "Kalkan Büyüsü - Kritik Vuruş" end
if E["Enchant Shield - Excellent Stamina"] == nil then E["Enchant Shield - Excellent Stamina"] = "Kalkan Büyüsü - Mükemmel Dayanıklılık" end
if E["Enchant Shield - Frost Resistance"] == nil then E["Enchant Shield - Frost Resistance"] = "Kalkan Büyüsü - Buz Direnci" end
if E["Enchant Shield - Greater Spirit"] == nil then E["Enchant Shield - Greater Spirit"] = "Kalkan Büyüsü - Büyük Ruh" end
if E["Enchant Shield - Greater Stamina"] == nil then E["Enchant Shield - Greater Stamina"] = "Kalkan Büyüsü - Büyük Dayanıklılık" end
if E["Enchant Shield - Law of Nature"] == nil then E["Enchant Shield - Law of Nature"] = "Kalkan Büyüsü - Doğa Yasası" end
if E["Enchant Shield - Lesser Block"] == nil then E["Enchant Shield - Lesser Block"] = "Kalkan Büyüsü - Hafif Blok" end
if E["Enchant Shield - Lesser Protection"] == nil then E["Enchant Shield - Lesser Protection"] = "Kalkan Büyüsü - Hafif Koruma" end
if E["Enchant Shield - Lesser Spirit"] == nil then E["Enchant Shield - Lesser Spirit"] = "Kalkan Büyüsü - Hafif Ruh" end
if E["Enchant Shield - Lesser Stamina"] == nil then E["Enchant Shield - Lesser Stamina"] = "Kalkan Büyüsü - Hafif Dayanıklılık" end
if E["Enchant Shield - Minor Stamina"] == nil then E["Enchant Shield - Minor Stamina"] = "Kalkan Büyüsü - Küçük Dayanıklılık" end
if E["Enchant Shield - Spirit"] == nil then E["Enchant Shield - Spirit"] = "Kalkan Büyüsü - Ruh" end
if E["Enchant Shield - Stamina"] == nil then E["Enchant Shield - Stamina"] = "Kalkan Büyüsü - Dayanıklılık" end
if E["Enchant Shield - Superior Spirit"] == nil then E["Enchant Shield - Superior Spirit"] = "Kalkan Büyüsü - Üstün Ruh" end
if E["Enchant Weapon - Agility"] == nil then E["Enchant Weapon - Agility"] = "Silah Büyüsü - Çeviklik" end
if E["Enchant Weapon - Crusader"] == nil then E["Enchant Weapon - Crusader"] = "Silah Büyüsü - Haçlı" end
if E["Enchant Weapon - Demonslaying"] == nil then E["Enchant Weapon - Demonslaying"] = "Silah Büyüsü - İblis Avcılığı" end
if E["Enchant Weapon - Dismantle"] == nil then E["Enchant Weapon - Dismantle"] = "Silah Büyüsü - Söküm" end
if E["Enchant Weapon - Fiery Weapon"] == nil then E["Enchant Weapon - Fiery Weapon"] = "Silah Büyüsü - Alevli Silah" end
if E["Enchant Weapon - Grand Crusader"] == nil then E["Enchant Weapon - Grand Crusader"] = "Silah Büyüsü - Ulu Haçlı" end
if E["Enchant Weapon - Grand Sorcerer"] == nil then E["Enchant Weapon - Grand Sorcerer"] = "Silah Büyüsü - Ulu Büyücü" end
if E["Enchant Weapon - Greater Striking"] == nil then E["Enchant Weapon - Greater Striking"] = "Silah Büyüsü - Büyük Vuruş" end
if E["Enchant Weapon - Healing Power"] == nil then E["Enchant Weapon - Healing Power"] = "Silah Büyüsü - İyileştirme Gücü" end
if E["Enchant Weapon - Icy Chill"] == nil then E["Enchant Weapon - Icy Chill"] = "Silah Büyüsü - Buzlu Ayaz" end
if E["Enchant Weapon - Insight"] == nil then E["Enchant Weapon - Insight"] = "Silah Büyüsü - Sezgi" end
if E["Enchant Weapon - Lesser Beastslayer"] == nil then E["Enchant Weapon - Lesser Beastslayer"] = "Silah Büyüsü - Hafif Canavar Katili" end
if E["Enchant Weapon - Lesser Elemental Slayer"] == nil then E["Enchant Weapon - Lesser Elemental Slayer"] = "Silah Büyüsü - Hafif Element Katili" end
if E["Enchant Weapon - Lesser Striking"] == nil then E["Enchant Weapon - Lesser Striking"] = "Silah Büyüsü - Hafif Vuruş" end
if E["Enchant Weapon - Lifestealing"] == nil then E["Enchant Weapon - Lifestealing"] = "Silah Büyüsü - Can Çalma" end
if E["Enchant Weapon - Mighty Intellect"] == nil then E["Enchant Weapon - Mighty Intellect"] = "Silah Büyüsü - Kudretli Zeka" end
if E["Enchant Weapon - Mighty Spirit"] == nil then E["Enchant Weapon - Mighty Spirit"] = "Silah Büyüsü - Kudretli Ruh" end
if E["Enchant Weapon - Minor Beastslayer"] == nil then E["Enchant Weapon - Minor Beastslayer"] = "Silah Büyüsü - Küçük Canavar Katili" end
if E["Enchant Weapon - Minor Striking"] == nil then E["Enchant Weapon - Minor Striking"] = "Silah Büyüsü - Küçük Vuruş" end
if E["Enchant Weapon - Recovery"] == nil then E["Enchant Weapon - Recovery"] = "Silah Büyüsü - İyileşme" end
if E["Enchant Weapon - Revelation"] == nil then E["Enchant Weapon - Revelation"] = "Silah Büyüsü - Vahiy" end
if E["Enchant Weapon - Spell Power"] == nil then E["Enchant Weapon - Spell Power"] = "Silah Büyüsü - Büyü Gücü" end
if E["Enchant Weapon - Strength"] == nil then E["Enchant Weapon - Strength"] = "Silah Büyüsü - Güç" end
if E["Enchant Weapon - Striking"] == nil then E["Enchant Weapon - Striking"] = "Silah Büyüsü - Vuruş" end
if E["Enchant Weapon - Superior Striking"] == nil then E["Enchant Weapon - Superior Striking"] = "Silah Büyüsü - Üstün Vuruş" end
if E["Enchant Weapon - Unholy Weapon"] == nil then E["Enchant Weapon - Unholy Weapon"] = "Silah Büyüsü - Kutsalsız Silah" end
if E["Enchant Weapon - Winter's Might"] == nil then E["Enchant Weapon - Winter's Might"] = "Silah Büyüsü - Kışın Kudreti" end
if E["Enchanted Sigil: Flowing Waters"] == nil then E["Enchanted Sigil: Flowing Waters"] = "Büyülü Mühür: Akan Sular" end
if E["Enchanted Sigil: Innovation"] == nil then E["Enchanted Sigil: Innovation"] = "Büyülü Mühür: Yenilik" end
if E["Encroacher's Claim"] == nil then E["Encroacher's Claim"] = "İstilacının Hak İddiası" end
if E["Ensemble: Al'Aketh Zealot's Garb"] == nil then E["Ensemble: Al'Aketh Zealot's Garb"] = "Takım: Al'Aketh Bağnazının Kıyafeti" end
if E["Ensemble: Shen'dorei Magister's Garb"] == nil then E["Ensemble: Shen'dorei Magister's Garb"] = "Takım: Shen'dorei Magister Kıyafeti" end
if E["Ensemble: Shen'dorei Peacekeeper's Garb"] == nil then E["Ensemble: Shen'dorei Peacekeeper's Garb"] = "Takım: Shen'dorei Barış Muhafızı Kıyafeti" end
if E["Ensemble: Shen'dorei Skyseer's Garb"] == nil then E["Ensemble: Shen'dorei Skyseer's Garb"] = "Takım: Shen'dorei Gökgörücü Kıyafeti" end
if E["Ensemble: Veteran Adventurer's Outdoor Wear"] == nil then E["Ensemble: Veteran Adventurer's Outdoor Wear"] = "Takım: Kıdemli Maceracının Dış Mekân Kıyafeti" end
if E["Erudite's Amulet"] == nil then E["Erudite's Amulet"] = "Bilginin Muskası" end
if E["Essene's Hope"] == nil then E["Essene's Hope"] = "Essene'in Umudu" end
if E["Essene's Necklace"] == nil then E["Essene's Necklace"] = "Essene'in Kolyesi" end
if E["Essene's Note"] == nil then E["Essene's Note"] = "Essene'in Notu" end
if E["Essene's Spellbook"] == nil then E["Essene's Spellbook"] = "Essene'in Büyü Kitabı" end
if E["Essene's Waterskin"] == nil then E["Essene's Waterskin"] = "Essene'in Su Matarası" end
if E["Eternal Explorer's Backpack"] == nil then E["Eternal Explorer's Backpack"] = "Ebedi Kâşifin Sırt Çantası" end
if E["Ex-Commander's Gauntlets"] == nil then E["Ex-Commander's Gauntlets"] = "Eski Komutanın Eldivenleri" end
if E["Executioner's Mace"] == nil then E["Executioner's Mace"] = "Celladın Gürzü" end
if E["Executor's Motivator"] == nil then E["Executor's Motivator"] = "İnfazcının Teşvikçisi" end
if E["Expeditionary's Cape"] == nil then E["Expeditionary's Cape"] = "Seferinin Pelerini" end
if E["Explorer's League Dustcover"] == nil then E["Explorer's League Dustcover"] = "Explorer's League Toz Örtüsü" end
if E["Explorer's Shortsword"] == nil then E["Explorer's Shortsword"] = "Kâşifin Kısa Kılıcı" end
if E["Explorers' League Cartographer's Kit"] == nil then E["Explorers' League Cartographer's Kit"] = "Explorers' League Haritacı Seti" end
if E["Explorers' League Mining Helmet"] == nil then E["Explorers' League Mining Helmet"] = "Explorers' League Madenci Kaskı" end
if E["Exterminator's Vest"] == nil then E["Exterminator's Vest"] = "Haşere Avcısının Yeleği" end
if E["Extra-Destructive Explosives"] == nil then E["Extra-Destructive Explosives"] = "Ekstra Yıkıcı Patlayıcılar" end
if E["Faerie Dragon's Skin"] == nil then E["Faerie Dragon's Skin"] = "Peri Ejderhasının Derisi" end
if E["Faerleia's Shield"] == nil then E["Faerleia's Shield"] = "Faerleia'nın Kalkanı" end
if E["Faladiel's Heart"] == nil then E["Faladiel's Heart"] = "Faladiel'in Kalbi" end
if E["Fallen Adventurer's Femur"] == nil then E["Fallen Adventurer's Femur"] = "Düşmüş Maceracının Uyluk Kemiği" end
if E["Fallen Dragon's Scepter"] == nil then E["Fallen Dragon's Scepter"] = "Düşmüş Ejderhanın Asası" end
if E["Fallen Guard's Pendant"] == nil then E["Fallen Guard's Pendant"] = "Düşmüş Muhafızın Kolyesi" end
if E["Falorne's Homemade Tart"] == nil then E["Falorne's Homemade Tart"] = "Falorne'un Ev Yapımı Tartı" end
if E["Falstad Wildhammer's Copper Coin"] == nil then E["Falstad Wildhammer's Copper Coin"] = "Falstad Wildhammer'ın Bakır Sikkesi" end
if E["Fandral Staghelm's Silver Coin"] == nil then E["Fandral Staghelm's Silver Coin"] = "Fandral Staghelm'in Gümüş Sikkesi" end
if E["Farmer's Boots"] == nil then E["Farmer's Boots"] = "Çiftçi Çizmeleri" end
if E["Farmer's Field Boots"] == nil then E["Farmer's Field Boots"] = "Çiftçinin Tarla Çizmeleri" end
if E["Farmers' Mementos"] == nil then E["Farmers' Mementos"] = "Çiftçilerin Hatıraları" end
if E["Farseer's Forgotten Shield"] == nil then E["Farseer's Forgotten Shield"] = "Uzakgörenin Unutulmuş Kalkanı" end
if E["Feardred's Amulet"] == nil then E["Feardred's Amulet"] = "Feardred'in Muskası" end
if E["Feardred's Cleansed Amulet"] == nil then E["Feardred's Cleansed Amulet"] = "Feardred'in Arındırılmış Muskası" end
if E["Feather of Jai'vhanel"] == nil then E["Feather of Jai'vhanel"] = "Jai'vhanel Tüyü" end
if E["Feather-Stitched Moccasins"] == nil then E["Feather-Stitched Moccasins"] = "Tüy Dikişli Mokasenler" end
if E["Fel-Slime Crystal"] == nil then E["Fel-Slime Crystal"] = "Fel Balçığı Kristali" end
if E["Fel-Slime Ooze"] == nil then E["Fel-Slime Ooze"] = "Fel Balçığı Sızıntısı" end
if E["Fel-Tainted Bear Heart"] == nil then E["Fel-Tainted Bear Heart"] = "Fel Bulaşmış Ayı Kalbi" end
if E["Fel-Tainted Branch"] == nil then E["Fel-Tainted Branch"] = "Fel Bulaşmış Dal" end
if E["Fel-Tainted Flesh"] == nil then E["Fel-Tainted Flesh"] = "Fel Bulaşmış Et" end
if E["Fel-Tainted Giblets"] == nil then E["Fel-Tainted Giblets"] = "Fel Bulaşmış Sakatat" end
if E["Fel-Tainted Remains"] == nil then E["Fel-Tainted Remains"] = "Fel Bulaşmış Kalıntılar" end
if E["Fel-Tainted Rock"] == nil then E["Fel-Tainted Rock"] = "Fel Bulaşmış Kaya" end
if E["Fel-Touched Flower"] == nil then E["Fel-Touched Flower"] = "Fel Dokunmuş Çiçek" end
if E["Felflick's Fire Flicker"] == nil then E["Felflick's Fire Flicker"] = "Felflick'in Ateş Kıvılcımı" end
if E["Felix's Box"] == nil then E["Felix's Box"] = "Felix'in Kutusu" end
if E["Felix's Bucket of Bolts"] == nil then E["Felix's Bucket of Bolts"] = "Felix'in Cıvata Kovası" end
if E["Felix's Chest"] == nil then E["Felix's Chest"] = "Felix'in Sandığı" end
if E["Fellicent's Bindings"] == nil then E["Fellicent's Bindings"] = "Fellicent'in Bağları" end
if E["Felweaver's Staff"] == nil then E["Felweaver's Staff"] = "Feldokuyanın Asası" end
if E["Ferocious Watcher's Signet"] == nil then E["Ferocious Watcher's Signet"] = "Vahşi Gözcünün Mühür Yüzüğü" end
if E["Field Marshal's Log"] == nil then E["Field Marshal's Log"] = "Saha Mareşalinin Kayıt Defteri" end
if E["Field Researcher's Loop"] == nil then E["Field Researcher's Loop"] = "Saha Araştırmacısının Halkası" end
if E["Fightin' Fish"] == nil then E["Fightin' Fish"] = "Dövüşken Balık" end
if E["Filet o' Flank"] == nil then E["Filet o' Flank"] = "Böğür Fileto" end
if E["Firebird's Cowl"] == nil then E["Firebird's Cowl"] = "Ateş Kuşunun Başlığı" end
if E["First Mate's Armguards"] == nil then E["First Mate's Armguards"] = "İkinci Kaptanın Kol Koruyucuları" end
if E["Fist-sized Spinneret"] == nil then E["Fist-sized Spinneret"] = "Yumruk Büyüklüğünde Ağ Bezi" end
if E["Fizsprocket's Clipboard"] == nil then E["Fizsprocket's Clipboard"] = "Fizsprocket'in Not Panosu" end
if E["Fizzbolt's Fashionable Fedora"] == nil then E["Fizzbolt's Fashionable Fedora"] = "Fizzbolt'un Şık Fötr Şapkası" end
if E["Fizzgrimble's Mysterious Crate"] == nil then E["Fizzgrimble's Mysterious Crate"] = "Fizzgrimble'ın Gizemli Sandığı" end
if E["Fizzle's Claw"] == nil then E["Fizzle's Claw"] = "Fizzle'ın Pençesi" end
if E["Fizzle's Zippy Lighter"] == nil then E["Fizzle's Zippy Lighter"] = "Fizzle'ın Hızlı Çakmağı" end
if E["Flintfire's Shipment"] == nil then E["Flintfire's Shipment"] = "Flintfire'ın Sevkiyatı" end
if E["Fool's Gold Dust"] == nil then E["Fool's Gold Dust"] = "Sahte Altın Tozu" end
if E["Footpad's Pants"] == nil then E["Footpad's Pants"] = "Yol Kesicinin Pantolonu" end
if E["Footpad's Shirt"] == nil then E["Footpad's Shirt"] = "Yol Kesicinin Gömleği" end
if E["Footpad's Shoes"] == nil then E["Footpad's Shoes"] = "Yol Kesicinin Ayakkabıları" end
if E["Foreman's Blackjack"] == nil then E["Foreman's Blackjack"] = "Ustabaşının Coplu Sopası" end
if E["Foreman's Crate"] == nil then E["Foreman's Crate"] = "Ustabaşının Sandığı" end
if E["Foreman's Enforcers"] == nil then E["Foreman's Enforcers"] = "Ustabaşının Zorlayıcıları" end
if E["Foreman's Helm"] == nil then E["Foreman's Helm"] = "Ustabaşının Miğferi" end
if E["Forest Defender's Axe"] == nil then E["Forest Defender's Axe"] = "Orman Savunucusunun Baltası" end
if E["Forest Oracle's Cloak"] == nil then E["Forest Oracle's Cloak"] = "Orman Kâhininin Pelerini" end
if E["Forever-Lovely Rose"] == nil then E["Forever-Lovely Rose"] = "Ebediyen Güzel Gül" end
if E["Forger's Quill"] == nil then E["Forger's Quill"] = "Sahtekârın Tüy Kalemi" end
if E["Forgewright's Notes"] == nil then E["Forgewright's Notes"] = "Demirci Ustasının Notları" end
if E["Formula: Brilliant Wand"] == nil then E["Formula: Brilliant Wand"] = "Formül: Parlak Değnek" end
if E["Formula: Dreambough Wand"] == nil then E["Formula: Dreambough Wand"] = "Formül: Rüyadalı Değneği" end
if E["Formula: Dreamstaff"] == nil then E["Formula: Dreamstaff"] = "Formül: Rüya Asası" end
if E["Formula: Enchant 2H Weapon - Lesser Agility"] == nil then E["Formula: Enchant 2H Weapon - Lesser Agility"] = "Formül: İki Elli Silah Büyüsü - Hafif Çeviklik" end
if E["Formula: Enchant 2H Weapon - Lesser Strength"] == nil then E["Formula: Enchant 2H Weapon - Lesser Strength"] = "Formül: İki Elli Silah Büyüsü - Hafif Güç" end
if E["Formula: Enchant 2H Weapon - Mighty Healing Power"] == nil then E["Formula: Enchant 2H Weapon - Mighty Healing Power"] = "Formül: İki Elli Silah Büyüsü - Kudretli İyileştirme Gücü" end
if E["Formula: Enchant 2H Weapon - Mighty Spell Power"] == nil then E["Formula: Enchant 2H Weapon - Mighty Spell Power"] = "Formül: İki Elli Silah Büyüsü - Kudretli Büyü Gücü" end
if E["Formula: Enchant 2H Weapon - Spellblasting"] == nil then E["Formula: Enchant 2H Weapon - Spellblasting"] = "Formül: İki Elli Silah Büyüsü - Büyü Patlatma" end
if E["Formula: Enchant 2H Weapon - Strength"] == nil then E["Formula: Enchant 2H Weapon - Strength"] = "Formül: İki Elli Silah Büyüsü - Güç" end
if E["Formula: Enchant Bracer - Agility"] == nil then E["Formula: Enchant Bracer - Agility"] = "Formül: Bileklik Büyüsü - Çeviklik" end
if E["Formula: Enchant Bracer - Greater Agility"] == nil then E["Formula: Enchant Bracer - Greater Agility"] = "Formül: Bileklik Büyüsü - Büyük Çeviklik" end
if E["Formula: Enchant Bracer - Greater Spellpower"] == nil then E["Formula: Enchant Bracer - Greater Spellpower"] = "Formül: Bileklik Büyüsü - Büyük Büyü Gücü" end
if E["Formula: Enchant Bracer - Lesser Agility"] == nil then E["Formula: Enchant Bracer - Lesser Agility"] = "Formül: Bileklik Büyüsü - Hafif Çeviklik" end
if E["Formula: Enchant Bracer - Lesser Healing Power"] == nil then E["Formula: Enchant Bracer - Lesser Healing Power"] = "Formül: Bileklik Büyüsü - Hafif İyileştirme Gücü" end
if E["Formula: Enchant Bracer - Minor Healing Power"] == nil then E["Formula: Enchant Bracer - Minor Healing Power"] = "Formül: Bileklik Büyüsü - Küçük İyileştirme Gücü" end
if E["Formula: Enchant Bracer - Minor Intellect"] == nil then E["Formula: Enchant Bracer - Minor Intellect"] = "Formül: Bileklik Büyüsü - Küçük Zeka" end
if E["Formula: Enchant Bracer - Superior Agility"] == nil then E["Formula: Enchant Bracer - Superior Agility"] = "Formül: Bileklik Büyüsü - Üstün Çeviklik" end
if E["Formula: Enchant Bracer - Superior Deflection"] == nil then E["Formula: Enchant Bracer - Superior Deflection"] = "Formül: Bileklik Büyüsü - Üstün Saptırma" end
if E["Formula: Enchant Bracer - Superior Intellect"] == nil then E["Formula: Enchant Bracer - Superior Intellect"] = "Formül: Bileklik Büyüsü - Üstün Zeka" end
if E["Formula: Enchant Chest - Absorption"] == nil then E["Formula: Enchant Chest - Absorption"] = "Formül: Göğüs Büyüsü - Emilim" end
if E["Formula: Enchant Cloak - Agility"] == nil then E["Formula: Enchant Cloak - Agility"] = "Formül: Pelerin Büyüsü - Çeviklik" end
if E["Formula: Enchant Gloves - Advanced Skinning"] == nil then E["Formula: Enchant Gloves - Advanced Skinning"] = "Formül: Eldiven Büyüsü - İleri Deri Yüzme" end
if E["Formula: Enchant Gloves - Arcane Power"] == nil then E["Formula: Enchant Gloves - Arcane Power"] = "Formül: Eldiven Büyüsü - Arkan Gücü" end
if E["Formula: Enchant Gloves - Holy Power"] == nil then E["Formula: Enchant Gloves - Holy Power"] = "Formül: Eldiven Büyüsü - Kutsal Güç" end
if E["Formula: Enchant Gloves - Lotus Claw"] == nil then E["Formula: Enchant Gloves - Lotus Claw"] = "Formül: Eldiven Büyüsü - Lotus Pençesi" end
if E["Formula: Enchant Gloves - Natural Power"] == nil then E["Formula: Enchant Gloves - Natural Power"] = "Formül: Eldiven Büyüsü - Doğa Gücü" end
if E["Formula: Enchant Gloves - Superior Strength"] == nil then E["Formula: Enchant Gloves - Superior Strength"] = "Formül: Eldiven Büyüsü - Üstün Güç" end
if E["Formula: Enchant Necklace - Agility"] == nil then E["Formula: Enchant Necklace - Agility"] = "Formül: Kolye Büyüsü - Çeviklik" end
if E["Formula: Enchant Necklace - Deflection"] == nil then E["Formula: Enchant Necklace - Deflection"] = "Formül: Kolye Büyüsü - Saptırma" end
if E["Formula: Enchant Necklace - Healing Power"] == nil then E["Formula: Enchant Necklace - Healing Power"] = "Formül: Kolye Büyüsü - İyileştirme Gücü" end
if E["Formula: Enchant Necklace - Spell Power"] == nil then E["Formula: Enchant Necklace - Spell Power"] = "Formül: Kolye Büyüsü - Büyü Gücü" end
if E["Formula: Enchant Necklace - Strength"] == nil then E["Formula: Enchant Necklace - Strength"] = "Formül: Kolye Büyüsü - Güç" end
if E["Formula: Enchant Off-Hand - Excellent Spirit"] == nil then E["Formula: Enchant Off-Hand - Excellent Spirit"] = "Formül: Yan El Büyüsü - Mükemmel Ruh" end
if E["Formula: Enchant Off-Hand - Superior Intellect"] == nil then E["Formula: Enchant Off-Hand - Superior Intellect"] = "Formül: Yan El Büyüsü - Üstün Zeka" end
if E["Formula: Enchant Off-Hand - Wisdom"] == nil then E["Formula: Enchant Off-Hand - Wisdom"] = "Formül: Yan El Büyüsü - Bilgelik" end
if E["Formula: Enchant Shield - Critical Strike"] == nil then E["Formula: Enchant Shield - Critical Strike"] = "Formül: Kalkan Büyüsü - Kritik Vuruş" end
if E["Formula: Enchant Shield - Excellent Stamina"] == nil then E["Formula: Enchant Shield - Excellent Stamina"] = "Formül: Kalkan Büyüsü - Mükemmel Dayanıklılık" end
if E["Formula: Enchant Weapon - Insight"] == nil then E["Formula: Enchant Weapon - Insight"] = "Formül: Silah Büyüsü - Sezgi" end
if E["Formula: Enchant Weapon - Recovery"] == nil then E["Formula: Enchant Weapon - Recovery"] = "Formül: Silah Büyüsü - İyileşme" end
if E["Formula: Enchant Weapon - Revelation"] == nil then E["Formula: Enchant Weapon - Revelation"] = "Formül: Silah Büyüsü - Vahiy" end
if E["Formula: Glimmering Staff"] == nil then E["Formula: Glimmering Staff"] = "Formül: Işıldayan Asa" end
if E["Formula: Greater Eternal Wand"] == nil then E["Formula: Greater Eternal Wand"] = "Formül: Büyük Ebedi Değnek" end
if E["Formula: Idol of Swiftness"] == nil then E["Formula: Idol of Swiftness"] = "Formül: Sürat İdolü" end
if E["Formula: Idol of the Dream"] == nil then E["Formula: Idol of the Dream"] = "Formül: Rüya İdolü" end
if E["Formula: Idol of the Ursine Twins"] == nil then E["Formula: Idol of the Ursine Twins"] = "Formül: Ayı İkizlerin İdolü" end
if E["Formula: Lesser Eternal Wand"] == nil then E["Formula: Lesser Eternal Wand"] = "Formül: Küçük Ebedi Değnek" end
if E["Formula: Libram of Holy Alacrity"] == nil then E["Formula: Libram of Holy Alacrity"] = "Formül: Kutsal Çabukluk Libramı" end
if E["Formula: Libram of Infusion"] == nil then E["Formula: Libram of Infusion"] = "Formül: Aşılama Libramı" end
if E["Formula: Libram of Invocation"] == nil then E["Formula: Libram of Invocation"] = "Formül: Yakarış Libramı" end
if E["Formula: Mystic Mushroom"] == nil then E["Formula: Mystic Mushroom"] = "Formül: Mistik Mantar" end
if E["Formula: Orb of Mystic Insight"] == nil then E["Formula: Orb of Mystic Insight"] = "Formül: Mistik Sezgi Küresi" end
if E["Formula: Orb of Souls"] == nil then E["Formula: Orb of Souls"] = "Formül: Ruhlar Küresi" end
if E["Formula: Polished Driftwood Icon"] == nil then E["Formula: Polished Driftwood Icon"] = "Formül: Cilalı Sürüklenmiş Odun İkonası" end
if E["Formula: Radiant Staff"] == nil then E["Formula: Radiant Staff"] = "Formül: Işıyan Asa" end
if E["Formula: Soulstaff"] == nil then E["Formula: Soulstaff"] = "Formül: Ruh Asası" end
if E["Formula: Steadfast Libram"] == nil then E["Formula: Steadfast Libram"] = "Formül: Sarsılmaz Libram" end
if E["Formula: Talons of Wrath"] == nil then E["Formula: Talons of Wrath"] = "Formül: Gazap Pençeleri" end
if E["Formula: Tenets of the Silver Hand"] == nil then E["Formula: Tenets of the Silver Hand"] = "Formül: Silver Hand İlkeleri" end
if E["Formula: Torch of Light"] == nil then E["Formula: Torch of Light"] = "Formül: Işık Meşalesi" end
if E["Formula: Totem of Ancestral Protection"] == nil then E["Formula: Totem of Ancestral Protection"] = "Formül: Ata Koruması Totemi" end
if E["Formula: Totem of Thunder"] == nil then E["Formula: Totem of Thunder"] = "Formül: Gök Gürültüsü Totemi" end
if E["Formula: Totem of Urgency"] == nil then E["Formula: Totem of Urgency"] = "Formül: Aciliyet Totemi" end
if E["Formula: Truesilver Conduit"] == nil then E["Formula: Truesilver Conduit"] = "Formül: Hakiki Gümüş İletken" end
if E["Formula: Twisted Nether Wand"] == nil then E["Formula: Twisted Nether Wand"] = "Formül: Bükülmüş Nether Değneği" end
if E["Formula: Twisting Essence Jar"] == nil then E["Formula: Twisting Essence Jar"] = "Formül: Kıvrılan Öz Kavanozu" end
if E["Fox-Catching Net"] == nil then E["Fox-Catching Net"] = "Tilki Yakalama Ağı" end
if E["Fras Siabi's Advertisement"] == nil then E["Fras Siabi's Advertisement"] = "Fras Siabi'nin İlanı" end
if E["Frazzlespark's Crate"] == nil then E["Frazzlespark's Crate"] = "Frazzlespark'ın Sandığı" end
if E["Fredd's Head"] == nil then E["Fredd's Head"] = "Fredd'in Kafası" end
if E["Freebooter's Armband"] == nil then E["Freebooter's Armband"] = "Korsanın Kol Bandı" end
if E["Freya's Sigil"] == nil then E["Freya's Sigil"] = "Freya'nın Mührü" end
if E["Friz's Secret Stash"] == nil then E["Friz's Secret Stash"] = "Friz'in Gizli Zulası" end
if E["Frost's Whisper Pendant"] == nil then E["Frost's Whisper Pendant"] = "Ayaz Fısıltısı Kolyesi" end
if E["Frosthowl's Footwarmers"] == nil then E["Frosthowl's Footwarmers"] = "Frosthowl'un Ayak Isıtıcıları" end
if E["Fur-Lined Bracers"] == nil then E["Fur-Lined Bracers"] = "Kürk Astarlı Bileklikler" end
if E["Fur-Lined Shoes"] == nil then E["Fur-Lined Shoes"] = "Kürk Astarlı Ayakkabılar" end
if E["Furbolg Shaman's Girdle"] == nil then E["Furbolg Shaman's Girdle"] = "Furbolg Şamanının Kuşağı" end
if E["GG12-082 Cartridge Fuse"] == nil then E["GG12-082 Cartridge Fuse"] = "GG12-082 Kartuş Sigortası" end
if E["Galvinquam's Belongings"] == nil then E["Galvinquam's Belongings"] = "Galvinquam'ın Eşyaları" end
if E["Galvinquam's Drinking Gourd"] == nil then E["Galvinquam's Drinking Gourd"] = "Galvinquam'ın Su Kabağı" end
if E["Gandling's Signet Ring"] == nil then E["Gandling's Signet Ring"] = "Gandling'in Mühür Yüzüğü" end
if E["Garrick's Head"] == nil then E["Garrick's Head"] = "Garrick'in Kafası" end
if E["Gazlowe's Ledger"] == nil then E["Gazlowe's Ledger"] = "Gazlowe'un Hesap Defteri" end
if E["Geolord's Mitts"] == nil then E["Geolord's Mitts"] = "Yerbeyinin Eldivenleri" end
if E["Geomancy: The Stone-Cold Truth"] == nil then E["Geomancy: The Stone-Cold Truth"] = "Jeomansi: Taş Gibi Soğuk Gerçek" end
if E["Ghostfang's Steps"] == nil then E["Ghostfang's Steps"] = "Ghostfang'in Adımları" end
if E["Ghostmaw's Fang"] == nil then E["Ghostmaw's Fang"] = "Ghostmaw'un Dişi" end
if E["Gimashi's Findings"] == nil then E["Gimashi's Findings"] = "Gimashi'nin Bulguları" end
if E["Gnarled Necromancer's Staff"] == nil then E["Gnarled Necromancer's Staff"] = "Budaklı Ölü Çağırıcı Asası" end
if E["Gnoll Shaman's Staff"] == nil then E["Gnoll Shaman's Staff"] = "Gnoll Şamanının Asası" end
if E["Gold-capped Troll Tusk"] == nil then E["Gold-capped Troll Tusk"] = "Altın Kaplı Trol Dişi" end
if E["Goliath's Wristguards"] == nil then E["Goliath's Wristguards"] = "Devin Bilek Koruyucuları" end
if E["Goo-Covered Demonic Gauntlet"] == nil then E["Goo-Covered Demonic Gauntlet"] = "Balçık Kaplı İblis Eldiveni" end
if E["Gordo's Report"] == nil then E["Gordo's Report"] = "Gordo'nun Raporu" end
if E["Gordon's Crate"] == nil then E["Gordon's Crate"] = "Gordon'un Sandığı" end
if E["Gorefang's Runners"] == nil then E["Gorefang's Runners"] = "Gorefang'in Koşu Ayakkabıları" end
if E["Gozwin's Mechanic's Log"] == nil then E["Gozwin's Mechanic's Log"] = "Gozwin'in Mekanik Kayıt Defteri" end
if E["Gramma Stonefield's Note"] == nil then E["Gramma Stonefield's Note"] = "Büyükanne Stonefield'ın Notu" end
if E["Grant's Mace"] == nil then E["Grant's Mace"] = "Grant'in Gürzü" end
if E["Grant's Shield"] == nil then E["Grant's Shield"] = "Grant'in Kalkanı" end
if E["Graverobber's Shovel"] == nil then E["Graverobber's Shovel"] = "Mezar Soyguncusunun Küreği" end
if E["Greater Cleric's Elixir"] == nil then E["Greater Cleric's Elixir"] = "Büyük Din Adamı İksiri" end
if E["Greater Mender's Potion"] == nil then E["Greater Mender's Potion"] = "Büyük Onarıcı İksiri" end
if E["Gregor's Remains"] == nil then E["Gregor's Remains"] = "Gregor'un Kalıntıları" end
if E["Grelin Whitebeard's Journal"] == nil then E["Grelin Whitebeard's Journal"] = "Grelin Whitebeard'ın Günlüğü" end
if E["Grelin's Report"] == nil then E["Grelin's Report"] = "Grelin'in Raporu" end
if E["Grime-Encrusted Salvage"] == nil then E["Grime-Encrusted Salvage"] = "Kir Kaplı Hurda" end
if E["Grimm's Premium Tobacco"] == nil then E["Grimm's Premium Tobacco"] = "Grimm'in Birinci Sınıf Tütünü" end
if E["Grimtotem Naturalist's Tunic"] == nil then E["Grimtotem Naturalist's Tunic"] = "Grimtotem Doğabilimcisinin Tuniği" end
if E["Grizzle's Skinner"] == nil then E["Grizzle's Skinner"] = "Grizzle'ın Yüzme Bıçağı" end
if E["Grizzwerks Defense Industries Founder's Certificate"] == nil then E["Grizzwerks Defense Industries Founder's Certificate"] = "Grizzwerks Savunma Sanayii Kurucu Sertifikası" end
if E["Gronok's Key"] == nil then E["Gronok's Key"] = "Gronok'un Anahtarı" end
if E["Groundshaker's Bindings"] == nil then E["Groundshaker's Bindings"] = "Yersarsanın Bağları" end
if E["Grove Scoundrel's Boots"] == nil then E["Grove Scoundrel's Boots"] = "Koru Alçağının Çizmeleri" end
if E["Grove Scoundrel's Pants"] == nil then E["Grove Scoundrel's Pants"] = "Koru Alçağının Pantolonu" end
if E["Grove Scoundrel's Shirt"] == nil then E["Grove Scoundrel's Shirt"] = "Koru Alçağının Gömleği" end
if E["Gruklash's Basher"] == nil then E["Gruklash's Basher"] = "Gruklash'ın Ezicisi" end
if E["Gryphon Rider's Crop"] == nil then E["Gryphon Rider's Crop"] = "Grifon Binicisinin Kamçısı" end
if E["Guard's Boots"] == nil then E["Guard's Boots"] = "Muhafız Çizmeleri" end
if E["Guard's Chain Belt"] == nil then E["Guard's Chain Belt"] = "Muhafız Zincir Kemeri" end
if E["Guard's Chain Helm"] == nil then E["Guard's Chain Helm"] = "Muhafız Zincir Miğferi" end
if E["Guard's Chain Leggings"] == nil then E["Guard's Chain Leggings"] = "Muhafız Zincir Bacaklığı" end
if E["Guard's Chain Shirt"] == nil then E["Guard's Chain Shirt"] = "Muhafız Zincir Gömleği" end
if E["Guard's Gloves"] == nil then E["Guard's Gloves"] = "Muhafız Eldivenleri" end
if E["Guard's Silvered Chain Helm"] == nil then E["Guard's Silvered Chain Helm"] = "Muhafızın Gümüşlenmiş Zincir Miğferi" end
if E["Guard's Silvered Chain Leggings"] == nil then E["Guard's Silvered Chain Leggings"] = "Muhafızın Gümüşlenmiş Zincir Bacaklığı" end
if E["Guard's Silvered Chain Shirt"] == nil then E["Guard's Silvered Chain Shirt"] = "Muhafızın Gümüşlenmiş Zincir Gömleği" end
if E["Guardian's Dualblade"] == nil then E["Guardian's Dualblade"] = "Koruyucunun Çift Kılıcı" end
if E["Guardian's Maulers"] == nil then E["Guardian's Maulers"] = "Koruyucunun Parçalayıcıları" end
if E["Guerilla's Jagged Mace"] == nil then E["Guerilla's Jagged Mace"] = "Gerillanın Tırtıklı Gürzü" end
if E["Gul'gash's Greathammer"] == nil then E["Gul'gash's Greathammer"] = "Gul'gash'ın Büyük Çekici" end
if E["Gunther's Spellbook"] == nil then E["Gunther's Spellbook"] = "Gunther'in Büyü Kitabı" end
if E["Hailgiant's Fists"] == nil then E["Hailgiant's Fists"] = "Dolu Devinin Yumrukları" end
if E["Half-Eaten Boots"] == nil then E["Half-Eaten Boots"] = "Yarısı Yenmiş Çizmeler" end
if E["Half-Eaten Fish"] == nil then E["Half-Eaten Fish"] = "Yarısı Yenmiş Balık" end
if E["Halikor's Hoof"] == nil then E["Halikor's Hoof"] = "Halikor'un Toynağı" end
if E["Halycon's Muzzle"] == nil then E["Halycon's Muzzle"] = "Halycon'un Ağızlığı" end
if E["Hamhock's Cleaver"] == nil then E["Hamhock's Cleaver"] = "Hamhock'un Satırı" end
if E["Hand-Hewn Buckler"] == nil then E["Hand-Hewn Buckler"] = "Elle Yontulmuş Küçük Kalkan" end
if E["Harvester's Pestslayer"] == nil then E["Harvester's Pestslayer"] = "Hasatçının Haşere Katili" end
if E["Hatescreech's Amulet"] == nil then E["Hatescreech's Amulet"] = "Hatescreech'in Muskası" end
if E["Haughty Fellow's Monocle"] == nil then E["Haughty Fellow's Monocle"] = "Kibirli Adamın Monoklü" end
if E["Hazza'rah's Charm of Destruction"] == nil then E["Hazza'rah's Charm of Destruction"] = "Hazza'rah'ın Yıkım Tılsımı" end
if E["Hazza'rah's Charm of Healing"] == nil then E["Hazza'rah's Charm of Healing"] = "Hazza'rah'ın Şifa Tılsımı" end
if E["Hazza'rah's Charm of Magic"] == nil then E["Hazza'rah's Charm of Magic"] = "Hazza'rah'ın Büyü Tılsımı" end
if E["Head Scratcher's Scratchers"] == nil then E["Head Scratcher's Scratchers"] = "Kafa Kaşıyıcının Kaşıyıcıları" end
if E["Head of Urs'anah"] == nil then E["Head of Urs'anah"] = "Urs'anah'ın Kafası" end
if E["Headhunter's Head"] == nil then E["Headhunter's Head"] = "Kelle Avcısının Kafası" end
if E["Headmaster's Records"] == nil then E["Headmaster's Records"] = "Müdürün Kayıtları" end
if E["Healer's Staff"] == nil then E["Healer's Staff"] = "Şifacının Asası" end
if E["Heart of Vek'zol"] == nil then E["Heart of Vek'zol"] = "Vek'zol'un Kalbi" end
if E["Heckler's Hide"] == nil then E["Heckler's Hide"] = "Laf Atanın Postu" end
if E["Herak's Head"] == nil then E["Herak's Head"] = "Herak'ın Kafası" end
if E["High Tinker Mekkatorque's Silver Coin"] == nil then E["High Tinker Mekkatorque's Silver Coin"] = "Yüce Tamirci Mekkatorque'un Gümüş Sikkesi" end
if E["Highlander's Chain Vest"] == nil then E["Highlander's Chain Vest"] = "Dağlının Zincir Yeleği" end
if E["Highlands Defender's Shield"] == nil then E["Highlands Defender's Shield"] = "Yaylalar Savunucusunun Kalkanı" end
if E["Hildelve's Journal"] == nil then E["Hildelve's Journal"] = "Hildelve'in Günlüğü" end
if E["Hillman's Leather Boots"] == nil then E["Hillman's Leather Boots"] = "Tepeli Adamın Deri Çizmeleri" end
if E["Hivethrasher's Boots"] == nil then E["Hivethrasher's Boots"] = "Kovan Dövenin Çizmeleri" end
if E["Hivethrasher's Claws"] == nil then E["Hivethrasher's Claws"] = "Kovan Dövenin Pençeleri" end
if E["Hivethrasher's Girdle"] == nil then E["Hivethrasher's Girdle"] = "Kovan Dövenin Kuşağı" end
if E["Hoarder's Foot"] == nil then E["Hoarder's Foot"] = "İstifçinin Ayağı" end
if E["Hol'anyee's Big Book of Big Lizards"] == nil then E["Hol'anyee's Big Book of Big Lizards"] = "Hol'anyee'nin Büyük Kertenkeleler Büyük Kitabı" end
if E["Hollee's Note"] == nil then E["Hollee's Note"] = "Hollee'nin Notu" end
if E["Honor Guard's Plate"] == nil then E["Honor Guard's Plate"] = "Onur Muhafızının Plaka Zırhı" end
if E["Hoof of Lakota'mani"] == nil then E["Hoof of Lakota'mani"] = "Lakota'mani'nin Toynağı" end
if E["Hoof-Holstered Blade"] == nil then E["Hoof-Holstered Blade"] = "Toynak Kılıflı Bıçak" end
if E["Hoof-Shaped Foot Pedal"] == nil then E["Hoof-Shaped Foot Pedal"] = "Toynak Biçimli Ayak Pedalı" end
if E["Horn of Arra'chea"] == nil then E["Horn of Arra'chea"] = "Arra'chea'nın Boynuzu" end
if E["Horn of Ve'ho"] == nil then E["Horn of Ve'ho"] = "Ve'ho'nun Boynuzu" end
if E["Horseman's Unyielding Shroud"] == nil then E["Horseman's Unyielding Shroud"] = "Süvarinin Boyun Eğmez Örtüsü" end
if E["Howin's Missive"] == nil then E["Howin's Missive"] = "Howin'in Mektubu" end
if E["Howler's Furs"] == nil then E["Howler's Furs"] = "Uluyanın Kürkleri" end
if E["Hunter's Cord"] == nil then E["Hunter's Cord"] = "Avcının Kordonu" end
if E["Hunter's Muzzle Loader"] == nil then E["Hunter's Muzzle Loader"] = "Avcının Ağızdan Dolma Tüfeği" end
if E["Hunter's Simple Cloak"] == nil then E["Hunter's Simple Cloak"] = "Avcının Sade Pelerini" end
if E["Huntress' Kite Shield"] == nil then E["Huntress' Kite Shield"] = "Avcı Kadının Uçurtma Kalkanı" end
if E["Hurley's Felling Axe"] == nil then E["Hurley's Felling Axe"] = "Hurley'nin Kesim Baltası" end
if E["Hyjal's Wisdom"] == nil then E["Hyjal's Wisdom"] = "Hyjal'ın Bilgeliği" end
if E["Hyperconductive Arcano-Filament"] == nil then E["Hyperconductive Arcano-Filament"] = "Süperiletken Arkano-Filaman" end
if E["I'lalai Fetish"] == nil then E["I'lalai Fetish"] = "I'lalai Fetişi" end
if E["Illari's Key"] == nil then E["Illari's Key"] = "Illari'nin Anahtarı" end
if E["Impcaster's Staff"] == nil then E["Impcaster's Staff"] = "İmp Çağırıcının Asası" end
if E["Incinerator's Boots"] == nil then E["Incinerator's Boots"] = "Yakıcının Çizmeleri" end
if E["Indari's Offering"] == nil then E["Indari's Offering"] = "Indari'nin Adağı" end
if E["Inigo's Copper Coin"] == nil then E["Inigo's Copper Coin"] = "Inigo'nun Bakır Sikkesi" end
if E["Insurgent's Band"] == nil then E["Insurgent's Band"] = "İsyancının Yüzüğü" end
if E["Insurgent's Manifesto"] == nil then E["Insurgent's Manifesto"] = "İsyancının Manifestosu" end
if E["Invader's Mace"] == nil then E["Invader's Mace"] = "İstilacının Gürzü" end
if E["Invading Marine's Shield"] == nil then E["Invading Marine's Shield"] = "İstilacı Deniz Piyadesinin Kalkanı" end
if E["Ira's Dagger"] == nil then E["Ira's Dagger"] = "Ira'nın Hançeri" end
if E["Ironforge Agent's Gloves"] == nil then E["Ironforge Agent's Gloves"] = "Ironforge Ajanının Eldivenleri" end
if E["Isaac's Heart"] == nil then E["Isaac's Heart"] = "Isaac'in Kalbi" end
if E["Ishamuhale's Fang"] == nil then E["Ishamuhale's Fang"] = "Ishamuhale'nin Dişi" end
if E["Ivar's Head"] == nil then E["Ivar's Head"] = "Ivar'ın Kafası" end
if E["Iverron's Antidote"] == nil then E["Iverron's Antidote"] = "Iverron'un Panzehiri" end
if E["Ivy-weave Bracers"] == nil then E["Ivy-weave Bracers"] = "Sarmaşık Örgü Bileklikler" end
if E["Jailer's Discarded Chain"] == nil then E["Jailer's Discarded Chain"] = "Gardiyanın Atılmış Zinciri" end
if E["Jameson's Backup Sword"] == nil then E["Jameson's Backup Sword"] = "Jameson'ın Yedek Kılıcı" end
if E["Jameson's Training Sword"] == nil then E["Jameson's Training Sword"] = "Jameson'ın Talim Kılıcı" end
if E["Jhordy's Misplaced Screwdriver"] == nil then E["Jhordy's Misplaced Screwdriver"] = "Jhordy'nin Kaybolan Tornavidası" end
if E["Johaan's Findings"] == nil then E["Johaan's Findings"] = "Johaan'ın Bulguları" end
if E["Johaan's Special Drink"] == nil then E["Johaan's Special Drink"] = "Johaan'ın Özel İçeceği" end
if E["Jom-jom's Gabbar"] == nil then E["Jom-jom's Gabbar"] = "Jom-jom'un Gabbar'ı" end
if E["Jorin's List"] == nil then E["Jorin's List"] = "Jorin'in Listesi" end
if E["Junior's Hunting Bow"] == nil then E["Junior's Hunting Bow"] = "Junior'ın Av Yayı" end
if E["Justicar's Belt"] == nil then E["Justicar's Belt"] = "Adalet Bekçisinin Kemeri" end
if E["Justicar's Boots"] == nil then E["Justicar's Boots"] = "Adalet Bekçisinin Çizmeleri" end
if E["Justicar's Gauntlet"] == nil then E["Justicar's Gauntlet"] = "Adalet Bekçisinin Zırh Eldiveni" end
if E["Justicar's Gloves"] == nil then E["Justicar's Gloves"] = "Adalet Bekçisinin Eldivenleri" end
if E["Justicar's Pauldrons"] == nil then E["Justicar's Pauldrons"] = "Adalet Bekçisinin Omurlukları" end
if E["Justicar's Sabatons"] == nil then E["Justicar's Sabatons"] = "Adalet Bekçisinin Zırh Ayakkabıları" end
if E["Justicar's Waistguard"] == nil then E["Justicar's Waistguard"] = "Adalet Bekçisinin Bel Koruyucusu" end
if E["Justicar's Wristguards"] == nil then E["Justicar's Wristguards"] = "Adalet Bekçisinin Bilek Koruyucuları" end
if E["Ka-Boom!"] == nil then E["Ka-Boom!"] = "Ka-Bum!" end
if E["Kajind's Blade"] == nil then E["Kajind's Blade"] = "Kajind'in Kılıcı" end
if E["Kamuro's Head"] == nil then E["Kamuro's Head"] = "Kamuro'nun Kafası" end
if E["Kanai's Knife"] == nil then E["Kanai's Knife"] = "Kanai'nin Bıçağı" end
if E["Kel'Thuzad's Gold Coin"] == nil then E["Kel'Thuzad's Gold Coin"] = "Kel'Thuzad'ın Altın Sikkesi" end
if E["Ketharas' Empty Vial"] == nil then E["Ketharas' Empty Vial"] = "Ketharas'ın Boş Şişesi" end
if E["Ketharas' Filled Vial"] == nil then E["Ketharas' Filled Vial"] = "Ketharas'ın Dolu Şişesi" end
if E["Ketharas' Hyjal Stew"] == nil then E["Ketharas' Hyjal Stew"] = "Ketharas'ın Hyjal Yahnisi" end
if E["Ketharas' Linked Belt"] == nil then E["Ketharas' Linked Belt"] = "Ketharas'ın Halkalı Kemeri" end
if E["Ketharas' Note"] == nil then E["Ketharas' Note"] = "Ketharas'ın Notu" end
if E["Khadgar's Silver Coin"] == nil then E["Khadgar's Silver Coin"] = "Khadgar'ın Gümüş Sikkesi" end
if E["Kilgar's Head"] == nil then E["Kilgar's Head"] = "Kilgar'ın Kafası" end
if E["King Terenas Menethil's Silver Coin"] == nil then E["King Terenas Menethil's Silver Coin"] = "Kral Terenas Menethil'in Gümüş Sikkesi" end
if E["Knife-Polishing Rag"] == nil then E["Knife-Polishing Rag"] = "Bıçak Parlatma Bezi" end
if E["Knight's Lance"] == nil then E["Knight's Lance"] = "Şövalyenin Mızrağı" end
if E["Kodo Hunter's Leggings"] == nil then E["Kodo Hunter's Leggings"] = "Kodo Avcısının Bacaklığı" end
if E["Komuk's Warmaul"] == nil then E["Komuk's Warmaul"] = "Komuk'un Savaş Tokmağı" end
if E["Kreenig Snarlsnout's Tusk"] == nil then E["Kreenig Snarlsnout's Tusk"] = "Kreenig Snarlsnout'un Dişi" end
if E["Krellian's Head"] == nil then E["Krellian's Head"] = "Krellian'ın Kafası" end
if E["Kristof's Report"] == nil then E["Kristof's Report"] = "Kristof'un Raporu" end
if E["Krol'dok Compound Key"] == nil then E["Krol'dok Compound Key"] = "Krol'dok Yerleşke Anahtarı" end
if E["Krol'dok Moulding"] == nil then E["Krol'dok Moulding"] = "Krol'dok Kalıbı" end
if E["Krol'dok Ogre Key"] == nil then E["Krol'dok Ogre Key"] = "Krol'dok Ogre Anahtarı" end
if E["Kron's Amulet"] == nil then E["Kron's Amulet"] = "Kron'un Muskası" end
if E["Kuramaa's Mask"] == nil then E["Kuramaa's Mask"] = "Kuramaa'nın Maskesi" end
if E["Kurmokk's Pelt"] == nil then E["Kurmokk's Pelt"] = "Kurmokk'un Postu" end
if E["Kuroma's Head"] == nil then E["Kuroma's Head"] = "Kuroma'nın Kafası" end
if E["Kurzen Fighter's Uniform"] == nil then E["Kurzen Fighter's Uniform"] = "Kurzen Dövüşçüsünün Üniforması" end
if E["Kurzen Headshrinker's Cinch"] == nil then E["Kurzen Headshrinker's Cinch"] = "Kurzen Kafa Küçültücüsünün Kemeri" end
if E["Lady Jaina Proudmoore's Gold Coin"] == nil then E["Lady Jaina Proudmoore's Gold Coin"] = "Leydi Jaina Proudmoore'un Altın Sikkesi" end
if E["Lady Katrana Prestor's Gold Coin"] == nil then E["Lady Katrana Prestor's Gold Coin"] = "Leydi Katrana Prestor'un Altın Sikkesi" end
if E["Lady Sesspira's Key"] == nil then E["Lady Sesspira's Key"] = "Leydi Sesspira'nın Anahtarı" end
if E["Lady's Tear Moss"] == nil then E["Lady's Tear Moss"] = "Leydi Gözyaşı Yosunu" end
if E["Lakeshire Firefighter's Headband"] == nil then E["Lakeshire Firefighter's Headband"] = "Lakeshire İtfaiyecisinin Saç Bandı" end
if E["Lamora's Key"] == nil then E["Lamora's Key"] = "Lamora'nın Anahtarı" end
if E["Lamora's Loot"] == nil then E["Lamora's Loot"] = "Lamora'nın Ganimeti" end
if E["Landro Longshot's Copper Coin"] == nil then E["Landro Longshot's Copper Coin"] = "Landro Longshot'un Bakır Sikkesi" end
if E["Larcenist's Belt"] == nil then E["Larcenist's Belt"] = "Hırsızın Kemeri" end
if E["Last Week's Ration"] == nil then E["Last Week's Ration"] = "Geçen Haftanın Erzakı" end
if E["Leafre's Ring of Armor Piercing"] == nil then E["Leafre's Ring of Armor Piercing"] = "Leafre'nin Zırh Delme Yüzüğü" end
if E["Leafre's Ring of Great Resistance"] == nil then E["Leafre's Ring of Great Resistance"] = "Leafre'nin Büyük Direnç Yüzüğü" end
if E["Leafre's Ring of Precise Spell Power"] == nil then E["Leafre's Ring of Precise Spell Power"] = "Leafre'nin Hassas Büyü Gücü Yüzüğü" end
if E["Leather-bound Flask"] == nil then E["Leather-bound Flask"] = "Deri Kaplı Matara" end
if E["Legends of the Gurubashi, Volume 3"] == nil then E["Legends of the Gurubashi, Volume 3"] = "Gurubashi Efsaneleri, Cilt 3" end
if E["Leopard's Head"] == nil then E["Leopard's Head"] = "Leopar Kafası" end
if E["Lesser Cleric's Elixir"] == nil then E["Lesser Cleric's Elixir"] = "Küçük Din Adamı İksiri" end
if E["Lesser Mender's Potion"] == nil then E["Lesser Mender's Potion"] = "Küçük Onarıcı İksiri" end
if E["Lich's Index Finger"] == nil then E["Lich's Index Finger"] = "Lich'in İşaret Parmağı" end
if E["Lightning's Grasp"] == nil then E["Lightning's Grasp"] = "Yıldırımın Kavrayışı" end
if E["Lion-stamped Gloves"] == nil then E["Lion-stamped Gloves"] = "Aslan Damgalı Eldivenler" end
if E["Long-barreled Musket"] == nil then E["Long-barreled Musket"] = "Uzun Namlulu Misket Tüfeği" end
if E["Longwalker Malah's Report"] == nil then E["Longwalker Malah's Report"] = "Uzunyürüyen Malah'ın Raporu" end
if E["Lookie's Spyglass"] == nil then E["Lookie's Spyglass"] = "Lookie'nin Dürbünü" end
if E["Loom"] == nil then E["Loom"] = "Dokuma Tezgâhı" end
if E["Loot-A-Rang"] == nil then E["Loot-A-Rang"] = "Ganimet-A-Rang" end
if E["Lord Sarthiss' Head"] == nil then E["Lord Sarthiss' Head"] = "Lord Sarthiss'in Kafası" end
if E["Lost Chieftain's Greatsword"] == nil then E["Lost Chieftain's Greatsword"] = "Kayıp Reisin Büyük Kılıcı" end
if E["Lost Veteran's Sabatons"] == nil then E["Lost Veteran's Sabatons"] = "Kayıp Gazinin Zırh Ayakkabıları" end
if E["Lovers' Hearts"] == nil then E["Lovers' Hearts"] = "Âşıkların Kalpleri" end
if E["Low-Background Truesilver Plates"] == nil then E["Low-Background Truesilver Plates"] = "Düşük Radyasyonlu Hakiki Gümüş Plakalar" end
if E["MacGrann's Dried Meats"] == nil then E["MacGrann's Dried Meats"] = "MacGrann'ın Kurutulmuş Etleri" end
if E["Madman's Blade"] == nil then E["Madman's Blade"] = "Delinin Kılıcı" end
if E["Maggot Eye's Paw"] == nil then E["Maggot Eye's Paw"] = "Maggot Eye'ın Pençesi" end
if E["Magician's Cord"] == nil then E["Magician's Cord"] = "Sihirbazın Kordonu" end
if E["Magistrate's Chain Hood"] == nil then E["Magistrate's Chain Hood"] = "Sulh Hâkiminin Zincir Başlığı" end
if E["Magistrate's Pantaloons"] == nil then E["Magistrate's Pantaloons"] = "Sulh Hâkiminin Şalvarı" end
if E["Magma or Lava?"] == nil then E["Magma or Lava?"] = "Magma mı Lav mı?" end
if E["Maiev Shadowsong's Silver Coin"] == nil then E["Maiev Shadowsong's Silver Coin"] = "Maiev Shadowsong'un Gümüş Sikkesi" end
if E["Major Mender's Potion"] == nil then E["Major Mender's Potion"] = "Yüce Onarıcı İksiri" end
if E["Maker's Spark"] == nil then E["Maker's Spark"] = "Yaratıcının Kıvılcımı" end
if E["Makeshift Stickin' Spear"] == nil then E["Makeshift Stickin' Spear"] = "Derme Çatma Saplama Mızrağı" end
if E["Malefactor's End"] == nil then E["Malefactor's End"] = "Kötülükçünün Sonu" end
if E["Mana-Siphoning Wand"] == nil then E["Mana-Siphoning Wand"] = "Mana Emen Değnek" end
if E["Mana-Warped Chain Shirt"] == nil then E["Mana-Warped Chain Shirt"] = "Mana Bükülmüş Zincir Gömlek" end
if E["Mana-infused Cord"] == nil then E["Mana-infused Cord"] = "Mana Aşılanmış Kordon" end
if E["Manual: Clever Poultice"] == nil then E["Manual: Clever Poultice"] = "Kılavuz: Akıllıca Lapa" end
if E["Manual: Greater Healing Potion"] == nil then E["Manual: Greater Healing Potion"] = "Kılavuz: Büyük Şifa İksiri" end
if E["Manual: Leather Tourniquet"] == nil then E["Manual: Leather Tourniquet"] = "Kılavuz: Deri Turnike" end
if E["Manual: Major Healing Potion"] == nil then E["Manual: Major Healing Potion"] = "Kılavuz: Yüce Şifa İksiri" end
if E["Manual: Potent Anti-Venom"] == nil then E["Manual: Potent Anti-Venom"] = "Kılavuz: Güçlü Panzehir" end
if E["Manual: Powerful Poultice"] == nil then E["Manual: Powerful Poultice"] = "Kılavuz: Kuvvetli Lapa" end
if E["Manual: Superior Healing Potion"] == nil then E["Manual: Superior Healing Potion"] = "Kılavuz: Üstün Şifa İksiri" end
if E["Manual: Superior Poultice"] == nil then E["Manual: Superior Poultice"] = "Kılavuz: Üstün Lapa" end
if E["Manual: Surgical Tourniquet"] == nil then E["Manual: Surgical Tourniquet"] = "Kılavuz: Cerrahi Turnike" end
if E["Marek's Croc-Hunting Knife"] == nil then E["Marek's Croc-Hunting Knife"] = "Marek'in Timsah Avlama Bıçağı" end
if E["Mark of Urs'endris"] == nil then E["Mark of Urs'endris"] = "Urs'endris'in İşareti" end
if E["Marn's Warding Incense"] == nil then E["Marn's Warding Incense"] = "Marn'ın Koruyucu Tütsüsü" end
if E["Marsh Serpent's Scales"] == nil then E["Marsh Serpent's Scales"] = "Bataklık Yılanının Pulları" end
if E["Marshal McBride's Documents"] == nil then E["Marshal McBride's Documents"] = "Mareşal McBride'ın Belgeleri" end
if E["Marshal Ryan's Crest"] == nil then E["Marshal Ryan's Crest"] = "Mareşal Ryan'ın Arması" end
if E["Martyr's Armor"] == nil then E["Martyr's Armor"] = "Şehidin Zırhı" end
if E["Martyr's Legplates"] == nil then E["Martyr's Legplates"] = "Şehidin Bacak Plakaları" end
if E["Mason's Copper Coin"] == nil then E["Mason's Copper Coin"] = "Mason'ın Bakır Sikkesi" end
if E["Mason's Note"] == nil then E["Mason's Note"] = "Mason'ın Notu" end
if E["Master Angler's Fishing Hat"] == nil then E["Master Angler's Fishing Hat"] = "Usta Balıkçının Balıkçı Şapkası" end
if E["Master Hunter's Spellsword"] == nil then E["Master Hunter's Spellsword"] = "Usta Avcının Büyü Kılıcı" end
if E["Master Hunter's Wand"] == nil then E["Master Hunter's Wand"] = "Usta Avcının Asası" end
if E["Matriarch's Mantle"] == nil then E["Matriarch's Mantle"] = "Anaerkilin Mantosu" end
if E["Mauler's Mutton"] == nil then E["Mauler's Mutton"] = "Parçalayıcının Koyun Eti" end
if E["Mavoris's Warstaff"] == nil then E["Mavoris's Warstaff"] = "Mavoris'in Savaş Asası" end
if E["Maybell's Love Letter"] == nil then E["Maybell's Love Letter"] = "Maybell'in Aşk Mektubu" end
if E["Medivh's Silver Coin"] == nil then E["Medivh's Silver Coin"] = "Medivh'in Gümüş Sikkesi" end
if E["Melenas' Head"] == nil then E["Melenas' Head"] = "Melenas'ın Kafası" end
if E["Mender's Leather Belt"] == nil then E["Mender's Leather Belt"] = "Şifacının Deri Kemeri" end
if E["Mender's Leather Boots"] == nil then E["Mender's Leather Boots"] = "Şifacının Deri Çizmeleri" end
if E["Mender's Leather Bracers"] == nil then E["Mender's Leather Bracers"] = "Şifacının Deri Bileklikleri" end
if E["Mender's Leather Gauntlets"] == nil then E["Mender's Leather Gauntlets"] = "Şifacının Deri Zırh Eldivenleri" end
if E["Mender's Leather Gloves"] == nil then E["Mender's Leather Gloves"] = "Şifacının Deri Eldivenleri" end
if E["Mender's Leather Shoes"] == nil then E["Mender's Leather Shoes"] = "Şifacının Deri Ayakkabıları" end
if E["Mender's Leather Shoulder"] == nil then E["Mender's Leather Shoulder"] = "Şifacının Deri Omuzluğu" end
if E["Mender's Leather Waistguard"] == nil then E["Mender's Leather Waistguard"] = "Şifacının Deri Bel Koruyucusu" end
if E["Mender's Mail Belt"] == nil then E["Mender's Mail Belt"] = "Şifacının Zincir Kemeri" end
if E["Mender's Mail Boots"] == nil then E["Mender's Mail Boots"] = "Şifacının Zincir Çizmeleri" end
if E["Mender's Mail Bracers"] == nil then E["Mender's Mail Bracers"] = "Şifacının Zincir Bileklikleri" end
if E["Mender's Mail Gauntlets"] == nil then E["Mender's Mail Gauntlets"] = "Şifacının Zincir Zırh Eldivenleri" end
if E["Mender's Mail Sabatons"] == nil then E["Mender's Mail Sabatons"] = "Şifacının Zincir Zırh Çizmeleri" end
if E["Mender's Mail Shoulder"] == nil then E["Mender's Mail Shoulder"] = "Şifacının Zincir Omuzluğu" end
if E["Mender's Potion"] == nil then E["Mender's Potion"] = "Şifacının İksiri" end
if E["Merrick's Bow"] == nil then E["Merrick's Bow"] = "Merrick'in Yayı" end
if E["Midshipman's Worn Boots"] == nil then E["Midshipman's Worn Boots"] = "Asteğmenin Eskimiş Çizmeleri" end
if E["Migi's Friendship Bracelet"] == nil then E["Migi's Friendship Bracelet"] = "Migi'nin Dostluk Bileziği" end
if E["Migi's Lunch"] == nil then E["Migi's Lunch"] = "Migi'nin Öğle Yemeği" end
if E["Militant's Band"] == nil then E["Militant's Band"] = "Militanın Yüzüğü" end
if E["Milly's Harvest"] == nil then E["Milly's Harvest"] = "Milly'nin Hasadı" end
if E["Miner's Workboots"] == nil then E["Miner's Workboots"] = "Madencinin İş Çizmeleri" end
if E["Miner's Workgloves"] == nil then E["Miner's Workgloves"] = "Madencinin İş Eldivenleri" end
if E["Minor Cleric's Elixir"] == nil then E["Minor Cleric's Elixir"] = "Küçük Rahip İksiri" end
if E["Minor Mender's Potion"] == nil then E["Minor Mender's Potion"] = "Küçük Şifacı İksiri" end
if E["Minshina's Skull"] == nil then E["Minshina's Skull"] = "Minshina'nın Kafatası" end
if E["Mirror of Rath'mael"] == nil then E["Mirror of Rath'mael"] = "Rath'mael'in Aynası" end
if E["Mirrorscale's Wing"] == nil then E["Mirrorscale's Wing"] = "Mirrorscale'in Kanadı" end
if E["Mogra's Friendship Bracelet"] == nil then E["Mogra's Friendship Bracelet"] = "Mogra'nın Dostluk Bileziği" end
if E["Molok's Masher"] == nil then E["Molok's Masher"] = "Molok'un Ezicisi" end
if E["Monster Hunter's First Rune Fragment"] == nil then E["Monster Hunter's First Rune Fragment"] = "Canavar Avcısının Birinci Rün Parçası" end
if E["Monster Hunter's Second Rune Fragment"] == nil then E["Monster Hunter's Second Rune Fragment"] = "Canavar Avcısının İkinci Rün Parçası" end
if E["Monster Hunter's Third Rune Fragment"] == nil then E["Monster Hunter's Third Rune Fragment"] = "Canavar Avcısının Üçüncü Rün Parçası" end
if E["Moongazer's Wand"] == nil then E["Moongazer's Wand"] = "Ay Gözcüsünün Asası" end
if E["Moss-covered Gauntlets"] == nil then E["Moss-covered Gauntlets"] = "Yosun Kaplı Zırh Eldivenleri" end
if E["Moss-twined Heart"] == nil then E["Moss-twined Heart"] = "Yosun Sarmalı Yürek" end
if E["Mountaineer Gretchen's Report"] == nil then E["Mountaineer Gretchen's Report"] = "Dağcı Gretchen'ın Raporu" end
if E["Mountaineer's Greataxe"] == nil then E["Mountaineer's Greataxe"] = "Dağcının Büyük Baltası" end
if E["Mourner's Shroud"] == nil then E["Mourner's Shroud"] = "Yaslının Kefeni" end
if E["Mummies: A Guide to the Unsavory Undead"] == nil then E["Mummies: A Guide to the Unsavory Undead"] = "Mumyalar: Tatsız Ölümsüzlere Bir Rehber" end
if E["Muradin Bronzebeard's Silver Coin"] == nil then E["Muradin Bronzebeard's Silver Coin"] = "Muradin Bronzebeard'ın Gümüş Sikkesi" end
if E["Murloc Oracle's Dagger"] == nil then E["Murloc Oracle's Dagger"] = "Murloc Kâhininin Hançeri" end
if E["Murloc-hide Gloves"] == nil then E["Murloc-hide Gloves"] = "Murloc Derisi Eldivenler" end
if E["Mus'hale's Stolen Supplies"] == nil then E["Mus'hale's Stolen Supplies"] = "Mus'hale'in Çalınan Erzakı" end
if E["Museum Keeper's Chain"] == nil then E["Museum Keeper's Chain"] = "Müze Bekçisinin Zinciri" end
if E["Mysterious 'Darnassian' Scroll"] == nil then E["Mysterious 'Darnassian' Scroll"] = "Gizemli 'Darnassian' Parşömen" end
if E["Mystmane's Pelt"] == nil then E["Mystmane's Pelt"] = "Mystmane'in Postu" end
if E["Naga Maiden's Gown"] == nil then E["Naga Maiden's Gown"] = "Naga Kızının Elbisesi" end
if E["Naga Priestess's Mantle"] == nil then E["Naga Priestess's Mantle"] = "Naga Rahibesinin Mantosu" end
if E["Nail"] == nil then E["Nail"] = "Çivi" end
if E["Namida's Hoof"] == nil then E["Namida's Hoof"] = "Namida'nın Toynağı" end
if E["Nar'thalas Almanac, Vol. 74"] == nil then E["Nar'thalas Almanac, Vol. 74"] = "Nar'thalas Almanağı, Cilt 74" end
if E["Nat Pagle's Guide to Extreme Anglin'"] == nil then E["Nat Pagle's Guide to Extreme Anglin'"] = "Nat Pagle'ın Uç Balıkçılık Rehberi" end
if E["Nature's Cull"] == nil then E["Nature's Cull"] = "Doğanın Ayıklaması" end
if E["Nature's Sting Legguards"] == nil then E["Nature's Sting Legguards"] = "Doğanın İğnesi Bacak Koruyucuları" end
if E["Needletooth's Needletooth"] == nil then E["Needletooth's Needletooth"] = "Needletooth'un İğnedişi" end
if E["Nefarion's Remit"] == nil then E["Nefarion's Remit"] = "Nefarion'un Buyruğu" end
if E["Nelanna's Enchanted Jewel"] == nil then E["Nelanna's Enchanted Jewel"] = "Nelanna'nın Efsunlu Mücevheri" end
if E["Neophyte's Boots"] == nil then E["Neophyte's Boots"] = "Çömezin Çizmeleri" end
if E["Neophyte's Pants"] == nil then E["Neophyte's Pants"] = "Çömezin Pantolonu" end
if E["Neophyte's Robe"] == nil then E["Neophyte's Robe"] = "Çömezin Cübbesi" end
if E["Neophyte's Shirt"] == nil then E["Neophyte's Shirt"] = "Çömezin Gömleği" end
if E["Neophyte's Wand"] == nil then E["Neophyte's Wand"] = "Çömezin Asası" end
if E["Nibbled-On Book"] == nil then E["Nibbled-On Book"] = "Kemirilmiş Kitap" end
if E["Night Watchman's Torch"] == nil then E["Night Watchman's Torch"] = "Gece Bekçisinin Meşalesi" end
if E["Nissa's Remains"] == nil then E["Nissa's Remains"] = "Nissa'nın Kalıntıları" end
if E["No Slip SAF-T Padding"] == nil then E["No Slip SAF-T Padding"] = "Kaymaz SAF-T Dolgu" end
if E["Noboru's Cudgel"] == nil then E["Noboru's Cudgel"] = "Noboru'nun Sopası" end
if E["Nori's Mug"] == nil then E["Nori's Mug"] = "Nori'nin Kupası" end
if E["Northern Kalimdor - A Comprehensive Guide"] == nil then E["Northern Kalimdor - A Comprehensive Guide"] = "Kuzey Kalimdor - Kapsamlı Bir Rehber" end
if E["Nostro's Compendium of Dragon Slaying"] == nil then E["Nostro's Compendium of Dragon Slaying"] = "Nostro'nun Ejderha Avcılığı Derlemesi" end
if E["Novice Arcanist's Sash"] == nil then E["Novice Arcanist's Sash"] = "Acemi Arkanistin Kuşağı" end
if E["Novice Ardent's Sash"] == nil then E["Novice Ardent's Sash"] = "Acemi Gayretlinin Kuşağı" end
if E["Novice's Pants"] == nil then E["Novice's Pants"] = "Acemi Pantolonu" end
if E["Novice's Practice Wand"] == nil then E["Novice's Practice Wand"] = "Acemi Alıştırma Asası" end
if E["Novice's Quarterstaff"] == nil then E["Novice's Quarterstaff"] = "Acemi Sopası" end
if E["Novice's Robe"] == nil then E["Novice's Robe"] = "Acemi Cübbesi" end
if E["Ofalo's Copper Coin"] == nil then E["Ofalo's Copper Coin"] = "Ofalo'nun Bakır Sikkesi" end
if E["Officer's Belt"] == nil then E["Officer's Belt"] = "Subayın Kemeri" end
if E["Officer's Boots"] == nil then E["Officer's Boots"] = "Subayın Çizmeleri" end
if E["Officer's Gauntlet"] == nil then E["Officer's Gauntlet"] = "Subayın Zırh Eldiveni" end
if E["Officer's Gloves"] == nil then E["Officer's Gloves"] = "Subayın Eldivenleri" end
if E["Officer's Pauldrons"] == nil then E["Officer's Pauldrons"] = "Subayın Omuz Zırhları" end
if E["Officer's Sabatons"] == nil then E["Officer's Sabatons"] = "Subayın Zırh Çizmeleri" end
if E["Officer's Waistguard"] == nil then E["Officer's Waistguard"] = "Subayın Bel Koruyucusu" end
if E["Officer's Wristguards"] == nil then E["Officer's Wristguards"] = "Subayın Bilek Koruyucuları" end
if E["Oil-stained Cloak"] == nil then E["Oil-stained Cloak"] = "Yağ Lekeli Pelerin" end
if E["Olgra's Adornments"] == nil then E["Olgra's Adornments"] = "Olgra'nın Süsleri" end
if E["Olvek's Guide to Tinctures, Tonics, and Toxins"] == nil then E["Olvek's Guide to Tinctures, Tonics, and Toxins"] = "Olvek'in Tentürler, Tonikler ve Zehirler Rehberi" end
if E["Ombassa's Hide"] == nil then E["Ombassa's Hide"] = "Ombassa'nın Derisi" end
if E["Omnuron's Spear"] == nil then E["Omnuron's Spear"] = "Omnuron'un Mızrağı" end
if E["One \"Gerenzo\", of Stonetalon"] == nil then E["One \"Gerenzo\", of Stonetalon"] = "Stonetalon'lu Bir \"Gerenzo\"" end
if E["Onu's Patience"] == nil then E["Onu's Patience"] = "Onu'nun Sabrı" end
if E["Operator's Gloves"] == nil then E["Operator's Gloves"] = "Operatörün Eldivenleri" end
if E["Ott's Masterwork"] == nil then E["Ott's Masterwork"] = "Ott'un Başyapıtı" end
if E["Outlaw's Collar"] == nil then E["Outlaw's Collar"] = "Kanun Kaçağının Yakası" end
if E["Overseer's Keyring"] == nil then E["Overseer's Keyring"] = "Gözetmenin Anahtarlığı" end
if E["Overseer's License"] == nil then E["Overseer's License"] = "Gözetmenin Ruhsatı" end
if E["Oversized Ogre's Mittens"] == nil then E["Oversized Ogre's Mittens"] = "Dev Boy Ogre Eldivenleri" end
if E["Owatanka's Tailspike"] == nil then E["Owatanka's Tailspike"] = "Owatanka'nın Kuyruk Dikeni" end
if E["Parachute-Priest Pager"] == nil then E["Parachute-Priest Pager"] = "Paraşüt-Rahip Çağrı Cihazı" end
if E["Pathfinder's Clearway"] == nil then E["Pathfinder's Clearway"] = "İz Sürenin Açık Yolu" end
if E["Pattern: Azure Gustwoven Belt"] == nil then E["Pattern: Azure Gustwoven Belt"] = "Desen: Gök Mavisi Rüzgârdokuma Kemer" end
if E["Pattern: Azure Gustwoven Boots"] == nil then E["Pattern: Azure Gustwoven Boots"] = "Desen: Gök Mavisi Rüzgârdokuma Çizmeler" end
if E["Pattern: Azure Gustwoven Bracers"] == nil then E["Pattern: Azure Gustwoven Bracers"] = "Desen: Gök Mavisi Rüzgârdokuma Bileklikler" end
if E["Pattern: Azure Gustwoven Gloves"] == nil then E["Pattern: Azure Gustwoven Gloves"] = "Desen: Gök Mavisi Rüzgârdokuma Eldivenler" end
if E["Pattern: Azure Gustwoven Harness"] == nil then E["Pattern: Azure Gustwoven Harness"] = "Desen: Gök Mavisi Rüzgârdokuma Koşum" end
if E["Pattern: Azure Gustwoven Hood"] == nil then E["Pattern: Azure Gustwoven Hood"] = "Desen: Gök Mavisi Rüzgârdokuma Başlık" end
if E["Pattern: Azure Gustwoven Spaulders"] == nil then E["Pattern: Azure Gustwoven Spaulders"] = "Desen: Gök Mavisi Rüzgârdokuma Omuz Levhaları" end
if E["Pattern: Azure Gustwoven Trousers"] == nil then E["Pattern: Azure Gustwoven Trousers"] = "Desen: Gök Mavisi Rüzgârdokuma Şalvar" end
if E["Pattern: Azure Stormsewn Cord"] == nil then E["Pattern: Azure Stormsewn Cord"] = "Desen: Gök Mavisi Fırtınadikişi İp Kuşak" end
if E["Pattern: Azure Stormsewn Cowl"] == nil then E["Pattern: Azure Stormsewn Cowl"] = "Desen: Gök Mavisi Fırtınadikişi Kukuleta" end
if E["Pattern: Azure Stormsewn Cuffs"] == nil then E["Pattern: Azure Stormsewn Cuffs"] = "Desen: Gök Mavisi Fırtınadikişi Kolluklar" end
if E["Pattern: Azure Stormsewn Epaulets"] == nil then E["Pattern: Azure Stormsewn Epaulets"] = "Desen: Gök Mavisi Fırtınadikişi Apoletler" end
if E["Pattern: Azure Stormsewn Handwraps"] == nil then E["Pattern: Azure Stormsewn Handwraps"] = "Desen: Gök Mavisi Fırtınadikişi El Sargıları" end
if E["Pattern: Azure Stormsewn Leggings"] == nil then E["Pattern: Azure Stormsewn Leggings"] = "Desen: Gök Mavisi Fırtınadikişi Tozluklar" end
if E["Pattern: Azure Stormsewn Shoes"] == nil then E["Pattern: Azure Stormsewn Shoes"] = "Desen: Gök Mavisi Fırtınadikişi Ayakkabılar" end
if E["Pattern: Azure Stormsewn Vest"] == nil then E["Pattern: Azure Stormsewn Vest"] = "Desen: Gök Mavisi Fırtınadikişi Yelek" end
if E["Pattern: Azure Windraveled Armguards"] == nil then E["Pattern: Azure Windraveled Armguards"] = "Desen: Gök Mavisi Rüzgârsarmalı Kol Koruyucuları" end
if E["Pattern: Azure Windraveled Cover"] == nil then E["Pattern: Azure Windraveled Cover"] = "Desen: Gök Mavisi Rüzgârsarmalı Örtü" end
if E["Pattern: Azure Windraveled Drapes"] == nil then E["Pattern: Azure Windraveled Drapes"] = "Desen: Gök Mavisi Rüzgârsarmalı Omuz Örtüleri" end
if E["Pattern: Azure Windraveled Footwraps"] == nil then E["Pattern: Azure Windraveled Footwraps"] = "Desen: Gök Mavisi Rüzgârsarmalı Ayak Sargıları" end
if E["Pattern: Azure Windraveled Jerkin"] == nil then E["Pattern: Azure Windraveled Jerkin"] = "Desen: Gök Mavisi Rüzgârsarmalı Cepken" end
if E["Pattern: Azure Windraveled Mitts"] == nil then E["Pattern: Azure Windraveled Mitts"] = "Desen: Gök Mavisi Rüzgârsarmalı Parmaksız Eldivenler" end
if E["Pattern: Azure Windraveled Pants"] == nil then E["Pattern: Azure Windraveled Pants"] = "Desen: Gök Mavisi Rüzgârsarmalı Pantolon" end
if E["Pattern: Azure Windraveled Strap"] == nil then E["Pattern: Azure Windraveled Strap"] = "Desen: Gök Mavisi Rüzgârsarmalı Kayış" end
if E["Pattern: Beastculler's Adaptive Bracers"] == nil then E["Pattern: Beastculler's Adaptive Bracers"] = "Desen: Canavar Kıranın Uyumlu Bileklikleri" end
if E["Pattern: Beastculler's Adaptive Vest"] == nil then E["Pattern: Beastculler's Adaptive Vest"] = "Desen: Canavar Kıranın Uyumlu Yeleği" end
if E["Pattern: Beastculler's Adaptive Wrap"] == nil then E["Pattern: Beastculler's Adaptive Wrap"] = "Desen: Canavar Kıranın Uyumlu Sargısı" end
if E["Pattern: Beastmender's Adaptive Girdle"] == nil then E["Pattern: Beastmender's Adaptive Girdle"] = "Desen: Canavar Şifacısının Uyumlu Bel Kuşağı" end
if E["Pattern: Beastmender's Adaptive Robe"] == nil then E["Pattern: Beastmender's Adaptive Robe"] = "Desen: Canavar Şifacısının Uyumlu Cübbesi" end
if E["Pattern: Beastmender's Adaptive Wristlinks"] == nil then E["Pattern: Beastmender's Adaptive Wristlinks"] = "Desen: Canavar Şifacısının Uyumlu Bilek Halkaları" end
if E["Pattern: Bileblister Boots"] == nil then E["Pattern: Bileblister Boots"] = "Desen: Safra Kabarcığı Çizmeleri" end
if E["Pattern: Bileblister Claws"] == nil then E["Pattern: Bileblister Claws"] = "Desen: Safra Kabarcığı Pençeleri" end
if E["Pattern: Bileblister Girdle"] == nil then E["Pattern: Bileblister Girdle"] = "Desen: Safra Kabarcığı Bel Kuşağı" end
if E["Pattern: Black Cord"] == nil then E["Pattern: Black Cord"] = "Desen: Siyah İp Kuşak" end
if E["Pattern: Black Dragonscale Helm"] == nil then E["Pattern: Black Dragonscale Helm"] = "Desen: Siyah Ejderha Pulu Miğferi" end
if E["Pattern: Black Gloves"] == nil then E["Pattern: Black Gloves"] = "Desen: Siyah Eldivenler" end
if E["Pattern: Black Handwraps"] == nil then E["Pattern: Black Handwraps"] = "Desen: Siyah El Sargıları" end
if E["Pattern: Black Sandals"] == nil then E["Pattern: Black Sandals"] = "Desen: Siyah Sandaletler" end
if E["Pattern: Black Slippers"] == nil then E["Pattern: Black Slippers"] = "Desen: Siyah Terlikler" end
if E["Pattern: Black Waistcord"] == nil then E["Pattern: Black Waistcord"] = "Desen: Siyah Bel İpi" end
if E["Pattern: Black Whelp Slippers"] == nil then E["Pattern: Black Whelp Slippers"] = "Desen: Siyah Yavru Ejderha Terlikleri" end
if E["Pattern: Blue Dragonscale Helm"] == nil then E["Pattern: Blue Dragonscale Helm"] = "Desen: Mavi Ejderha Pulu Miğferi" end
if E["Pattern: Blue Suede Armor"] == nil then E["Pattern: Blue Suede Armor"] = "Desen: Mavi Süet Zırh" end
if E["Pattern: Blue Suede Belt"] == nil then E["Pattern: Blue Suede Belt"] = "Desen: Mavi Süet Kemer" end
if E["Pattern: Blue Suede Bracers"] == nil then E["Pattern: Blue Suede Bracers"] = "Desen: Mavi Süet Bileklikler" end
if E["Pattern: Blue Suede Gloves"] == nil then E["Pattern: Blue Suede Gloves"] = "Desen: Mavi Süet Eldivenler" end
if E["Pattern: Blue Suede Hat"] == nil then E["Pattern: Blue Suede Hat"] = "Desen: Mavi Süet Şapka" end
if E["Pattern: Blue Suede Pants"] == nil then E["Pattern: Blue Suede Pants"] = "Desen: Mavi Süet Pantolon" end
if E["Pattern: Blue Suede Shoes"] == nil then E["Pattern: Blue Suede Shoes"] = "Desen: Mavi Süet Ayakkabılar" end
if E["Pattern: Blue Suede Shoulder"] == nil then E["Pattern: Blue Suede Shoulder"] = "Desen: Mavi Süet Omuzluk" end
if E["Pattern: Boots of Conviction"] == nil then E["Pattern: Boots of Conviction"] = "Desen: Kararlılığın Çizmeleri" end
if E["Pattern: Bottomless Reagent Bag"] == nil then E["Pattern: Bottomless Reagent Bag"] = "Desen: Dipsiz Bileşen Çantası" end
if E["Pattern: Brawler's Leather Belt"] == nil then E["Pattern: Brawler's Leather Belt"] = "Desen: Kavgacının Deri Kemeri" end
if E["Pattern: Brawler's Leather Boots"] == nil then E["Pattern: Brawler's Leather Boots"] = "Desen: Kavgacının Deri Çizmeleri" end
if E["Pattern: Brawler's Leather Gloves"] == nil then E["Pattern: Brawler's Leather Gloves"] = "Desen: Kavgacının Deri Eldivenleri" end
if E["Pattern: Brawler's Leather Hood"] == nil then E["Pattern: Brawler's Leather Hood"] = "Desen: Kavgacının Deri Başlığı" end
if E["Pattern: Brawler's Leather Legguards"] == nil then E["Pattern: Brawler's Leather Legguards"] = "Desen: Kavgacının Deri Bacak Koruyucuları" end
if E["Pattern: Brawler's Leather Tunic"] == nil then E["Pattern: Brawler's Leather Tunic"] = "Desen: Kavgacının Deri Tuniği" end
if E["Pattern: Broodwatcher's Belt"] == nil then E["Pattern: Broodwatcher's Belt"] = "Desen: Kuluçka Bekçisinin Kemeri" end
if E["Pattern: Broodwatcher's Clenchers"] == nil then E["Pattern: Broodwatcher's Clenchers"] = "Desen: Kuluçka Bekçisinin Kıskaçları" end
if E["Pattern: Broodwatcher's Treaders"] == nil then E["Pattern: Broodwatcher's Treaders"] = "Desen: Kuluçka Bekçisinin Ayaklıkları" end
if E["Pattern: Centaur Hoofwarmers"] == nil then E["Pattern: Centaur Hoofwarmers"] = "Desen: Centaur Toynak Isıtıcıları" end
if E["Pattern: Charged Scorpid Belt"] == nil then E["Pattern: Charged Scorpid Belt"] = "Desen: Yüklü Akrep Kemeri" end
if E["Pattern: Charged Scorpid Boots"] == nil then E["Pattern: Charged Scorpid Boots"] = "Desen: Yüklü Akrep Çizmeleri" end
if E["Pattern: Charged Scorpid Bracers"] == nil then E["Pattern: Charged Scorpid Bracers"] = "Desen: Yüklü Akrep Bileklikleri" end
if E["Pattern: Charged Scorpid Gauntlets"] == nil then E["Pattern: Charged Scorpid Gauntlets"] = "Desen: Yüklü Akrep Zırh Eldivenleri" end
if E["Pattern: Charged Scorpid Helm"] == nil then E["Pattern: Charged Scorpid Helm"] = "Desen: Yüklü Akrep Miğferi" end
if E["Pattern: Charged Scorpid Leggings"] == nil then E["Pattern: Charged Scorpid Leggings"] = "Desen: Yüklü Akrep Tozlukları" end
if E["Pattern: Charged Scorpid Shoulder"] == nil then E["Pattern: Charged Scorpid Shoulder"] = "Desen: Yüklü Akrep Omuzluğu" end
if E["Pattern: Charged Scorpid Vest"] == nil then E["Pattern: Charged Scorpid Vest"] = "Desen: Yüklü Akrep Yeleği" end
if E["Pattern: Cloak of Earth and Sky"] == nil then E["Pattern: Cloak of Earth and Sky"] = "Desen: Toprak ve Gök Pelerini" end
if E["Pattern: Cloudy Gustwoven Belt"] == nil then E["Pattern: Cloudy Gustwoven Belt"] = "Desen: Bulutlu Rüzgârdokuma Kemer" end
if E["Pattern: Cloudy Gustwoven Boots"] == nil then E["Pattern: Cloudy Gustwoven Boots"] = "Desen: Bulutlu Rüzgârdokuma Çizmeler" end
if E["Pattern: Cloudy Gustwoven Bracers"] == nil then E["Pattern: Cloudy Gustwoven Bracers"] = "Desen: Bulutlu Rüzgârdokuma Bileklikler" end
if E["Pattern: Cloudy Gustwoven Gloves"] == nil then E["Pattern: Cloudy Gustwoven Gloves"] = "Desen: Bulutlu Rüzgârdokuma Eldivenler" end
if E["Pattern: Cloudy Gustwoven Harness"] == nil then E["Pattern: Cloudy Gustwoven Harness"] = "Desen: Bulutlu Rüzgârdokuma Koşum" end
if E["Pattern: Cloudy Gustwoven Hood"] == nil then E["Pattern: Cloudy Gustwoven Hood"] = "Desen: Bulutlu Rüzgârdokuma Başlık" end
if E["Pattern: Cloudy Gustwoven Spaulders"] == nil then E["Pattern: Cloudy Gustwoven Spaulders"] = "Desen: Bulutlu Rüzgârdokuma Omuz Levhaları" end
if E["Pattern: Cloudy Gustwoven Trousers"] == nil then E["Pattern: Cloudy Gustwoven Trousers"] = "Desen: Bulutlu Rüzgârdokuma Şalvar" end
if E["Pattern: Cloudy Stormsewn Cord"] == nil then E["Pattern: Cloudy Stormsewn Cord"] = "Desen: Bulutlu Fırtınadikişi İp Kuşak" end
if E["Pattern: Cloudy Stormsewn Cowl"] == nil then E["Pattern: Cloudy Stormsewn Cowl"] = "Desen: Bulutlu Fırtınadikişi Kukuleta" end
if E["Pattern: Cloudy Stormsewn Cuffs"] == nil then E["Pattern: Cloudy Stormsewn Cuffs"] = "Desen: Bulutlu Fırtınadikişi Kolluklar" end
if E["Pattern: Cloudy Stormsewn Epaulets"] == nil then E["Pattern: Cloudy Stormsewn Epaulets"] = "Desen: Bulutlu Fırtınadikişi Apoletler" end
if E["Pattern: Cloudy Stormsewn Handwraps"] == nil then E["Pattern: Cloudy Stormsewn Handwraps"] = "Desen: Bulutlu Fırtınadikişi El Sargıları" end
if E["Pattern: Cloudy Stormsewn Leggings"] == nil then E["Pattern: Cloudy Stormsewn Leggings"] = "Desen: Bulutlu Fırtınadikişi Tozluklar" end
if E["Pattern: Cloudy Stormsewn Shoes"] == nil then E["Pattern: Cloudy Stormsewn Shoes"] = "Desen: Bulutlu Fırtınadikişi Ayakkabılar" end
if E["Pattern: Cloudy Stormsewn Vest"] == nil then E["Pattern: Cloudy Stormsewn Vest"] = "Desen: Bulutlu Fırtınadikişi Yelek" end
if E["Pattern: Cloudy Windraveled Armguards"] == nil then E["Pattern: Cloudy Windraveled Armguards"] = "Desen: Bulutlu Rüzgârsarmalı Kol Koruyucuları" end
if E["Pattern: Cloudy Windraveled Cover"] == nil then E["Pattern: Cloudy Windraveled Cover"] = "Desen: Bulutlu Rüzgârsarmalı Örtü" end
if E["Pattern: Cloudy Windraveled Drapes"] == nil then E["Pattern: Cloudy Windraveled Drapes"] = "Desen: Bulutlu Rüzgârsarmalı Omuz Örtüleri" end
if E["Pattern: Cloudy Windraveled Footwraps"] == nil then E["Pattern: Cloudy Windraveled Footwraps"] = "Desen: Bulutlu Rüzgârsarmalı Ayak Sargıları" end
if E["Pattern: Cloudy Windraveled Jerkin"] == nil then E["Pattern: Cloudy Windraveled Jerkin"] = "Desen: Bulutlu Rüzgârsarmalı Cepken" end
if E["Pattern: Cloudy Windraveled Mitts"] == nil then E["Pattern: Cloudy Windraveled Mitts"] = "Desen: Bulutlu Rüzgârsarmalı Parmaksız Eldivenler" end
if E["Pattern: Cloudy Windraveled Pants"] == nil then E["Pattern: Cloudy Windraveled Pants"] = "Desen: Bulutlu Rüzgârsarmalı Pantolon" end
if E["Pattern: Cloudy Windraveled Strap"] == nil then E["Pattern: Cloudy Windraveled Strap"] = "Desen: Bulutlu Rüzgârsarmalı Kayış" end
if E["Pattern: Dark Leather Boots"] == nil then E["Pattern: Dark Leather Boots"] = "Desen: Koyu Deri Çizmeler" end
if E["Pattern: Dawn Armor"] == nil then E["Pattern: Dawn Armor"] = "Desen: Şafak Zırhı" end
if E["Pattern: Defender's Leather Belt"] == nil then E["Pattern: Defender's Leather Belt"] = "Desen: Savunucunun Deri Kemeri" end
if E["Pattern: Defender's Leather Boots"] == nil then E["Pattern: Defender's Leather Boots"] = "Desen: Savunucunun Deri Çizmeleri" end
if E["Pattern: Defender's Leather Gloves"] == nil then E["Pattern: Defender's Leather Gloves"] = "Desen: Savunucunun Deri Eldivenleri" end
if E["Pattern: Defender's Leather Hood"] == nil then E["Pattern: Defender's Leather Hood"] = "Desen: Savunucunun Deri Başlığı" end
if E["Pattern: Defender's Leather Kilt"] == nil then E["Pattern: Defender's Leather Kilt"] = "Desen: Savunucunun Deri Eteği" end
if E["Pattern: Defender's Leather Tunic"] == nil then E["Pattern: Defender's Leather Tunic"] = "Desen: Savunucunun Deri Tuniği" end
if E["Pattern: Demonheart Boots"] == nil then E["Pattern: Demonheart Boots"] = "Desen: İblis Yüreği Çizmeleri" end
if E["Pattern: Demonheart Gloves"] == nil then E["Pattern: Demonheart Gloves"] = "Desen: İblis Yüreği Eldivenleri" end
if E["Pattern: Demonheart Leggings"] == nil then E["Pattern: Demonheart Leggings"] = "Desen: İblis Yüreği Tozlukları" end
if E["Pattern: Demonheart Spaulders"] == nil then E["Pattern: Demonheart Spaulders"] = "Desen: İblis Yüreği Omuz Levhaları" end
if E["Pattern: Dinodestroyer's Adaptive Belt"] == nil then E["Pattern: Dinodestroyer's Adaptive Belt"] = "Desen: Dinozor Yok Edicinin Uyumlu Kemeri" end
if E["Pattern: Dinodestroyer's Adaptive Chestguard"] == nil then E["Pattern: Dinodestroyer's Adaptive Chestguard"] = "Desen: Dinozor Yok Edicinin Uyumlu Göğüs Koruyucusu" end
if E["Pattern: Dinodestroyer's Adaptive Wrists"] == nil then E["Pattern: Dinodestroyer's Adaptive Wrists"] = "Desen: Dinozor Yok Edicinin Uyumlu Bileklikleri" end
if E["Pattern: Dinomender's Adaptive Chain"] == nil then E["Pattern: Dinomender's Adaptive Chain"] = "Desen: Dinozor Şifacısının Uyumlu Zinciri" end
if E["Pattern: Dinomender's Adaptive Tunic"] == nil then E["Pattern: Dinomender's Adaptive Tunic"] = "Desen: Dinozor Şifacısının Uyumlu Tuniği" end
if E["Pattern: Dinomender's Adaptive Wrists"] == nil then E["Pattern: Dinomender's Adaptive Wrists"] = "Desen: Dinozor Şifacısının Uyumlu Bileklikleri" end
if E["Pattern: Earthen Leggings"] == nil then E["Pattern: Earthen Leggings"] = "Desen: Toprak Tozlukları" end
if E["Pattern: Earthen Silk Cuffs"] == nil then E["Pattern: Earthen Silk Cuffs"] = "Desen: Toprak İpeği Kollukları" end
if E["Pattern: Earthen Silk Gloves"] == nil then E["Pattern: Earthen Silk Gloves"] = "Desen: Toprak İpeği Eldivenleri" end
if E["Pattern: Earthen Silk Hood"] == nil then E["Pattern: Earthen Silk Hood"] = "Desen: Toprak İpeği Başlığı" end
if E["Pattern: Earthen Silk Shoulders"] == nil then E["Pattern: Earthen Silk Shoulders"] = "Desen: Toprak İpeği Omuzlukları" end
if E["Pattern: Earthen Silk Slippers"] == nil then E["Pattern: Earthen Silk Slippers"] = "Desen: Toprak İpeği Terlikleri" end
if E["Pattern: Earthenweave Boots"] == nil then E["Pattern: Earthenweave Boots"] = "Desen: Toprak Örgüsü Çizmeleri" end
if E["Pattern: Earthenweave Cord"] == nil then E["Pattern: Earthenweave Cord"] = "Desen: Toprak Örgüsü İp Kuşağı" end
if E["Pattern: Earthenweave Crown"] == nil then E["Pattern: Earthenweave Crown"] = "Desen: Toprak Örgüsü Tacı" end
if E["Pattern: Earthenweave Cuffs"] == nil then E["Pattern: Earthenweave Cuffs"] = "Desen: Toprak Örgüsü Kollukları" end
if E["Pattern: Earthenweave Gloves"] == nil then E["Pattern: Earthenweave Gloves"] = "Desen: Toprak Örgüsü Eldivenleri" end
if E["Pattern: Earthenweave Leggings"] == nil then E["Pattern: Earthenweave Leggings"] = "Desen: Toprak Örgüsü Tozlukları" end
if E["Pattern: Earthenweave Mantle"] == nil then E["Pattern: Earthenweave Mantle"] = "Desen: Toprak Örgüsü Mantosu" end
if E["Pattern: Earthenweave Vest"] == nil then E["Pattern: Earthenweave Vest"] = "Desen: Toprak Örgüsü Yeleği" end
if E["Pattern: Elderwild Pants"] == nil then E["Pattern: Elderwild Pants"] = "Desen: Kadim Yaban Pantolonu" end
if E["Pattern: Elderwild Waistcord"] == nil then E["Pattern: Elderwild Waistcord"] = "Desen: Kadim Yaban Bel İpi" end
if E["Pattern: Eternity Pauldrons"] == nil then E["Pattern: Eternity Pauldrons"] = "Desen: Sonsuzluk Omuz Zırhları" end
if E["Pattern: Fel Cape"] == nil then E["Pattern: Fel Cape"] = "Desen: Fel Kepeneği" end
if E["Pattern: Felblood Soul Bag"] == nil then E["Pattern: Felblood Soul Bag"] = "Desen: Felkanı Ruh Çantası" end
if E["Pattern: Fiery Cord"] == nil then E["Pattern: Fiery Cord"] = "Desen: Ateşli İp Kuşak" end
if E["Pattern: Fiery Gloves"] == nil then E["Pattern: Fiery Gloves"] = "Desen: Ateşli Eldivenler" end
if E["Pattern: Fiery Handwraps"] == nil then E["Pattern: Fiery Handwraps"] = "Desen: Ateşli El Sargıları" end
if E["Pattern: Fiery Sandals"] == nil then E["Pattern: Fiery Sandals"] = "Desen: Ateşli Sandaletler" end
if E["Pattern: Fiery Slippers"] == nil then E["Pattern: Fiery Slippers"] = "Desen: Ateşli Terlikler" end
if E["Pattern: Fiery Waistcord"] == nil then E["Pattern: Fiery Waistcord"] = "Desen: Ateşli Bel İpi" end
if E["Pattern: Filigreed Flame Circlet"] == nil then E["Pattern: Filigreed Flame Circlet"] = "Desen: Telkari Alev Alınlığı" end
if E["Pattern: Filigreed Flame Gown"] == nil then E["Pattern: Filigreed Flame Gown"] = "Desen: Telkari Alev Elbisesi" end
if E["Pattern: Filigreed Flame Leggings"] == nil then E["Pattern: Filigreed Flame Leggings"] = "Desen: Telkari Alev Tozlukları" end
if E["Pattern: Filigreed Pearly Circlet"] == nil then E["Pattern: Filigreed Pearly Circlet"] = "Desen: Telkari İncili Alınlık" end
if E["Pattern: Filigreed Pearly Gown"] == nil then E["Pattern: Filigreed Pearly Gown"] = "Desen: Telkari İncili Elbise" end
if E["Pattern: Filigreed Pearly Leggings"] == nil then E["Pattern: Filigreed Pearly Leggings"] = "Desen: Telkari İncili Tozluklar" end
if E["Pattern: Filigreed Pristine Circlet"] == nil then E["Pattern: Filigreed Pristine Circlet"] = "Desen: Telkari Kusursuz Alınlık" end
if E["Pattern: Filigreed Pristine Gown"] == nil then E["Pattern: Filigreed Pristine Gown"] = "Desen: Telkari Kusursuz Elbise" end
if E["Pattern: Filigreed Pristine Leggings"] == nil then E["Pattern: Filigreed Pristine Leggings"] = "Desen: Telkari Kusursuz Tozluklar" end
if E["Pattern: Filigreed Shadow Circlet"] == nil then E["Pattern: Filigreed Shadow Circlet"] = "Desen: Telkari Gölge Alınlığı" end
if E["Pattern: Filigreed Shadow Gown"] == nil then E["Pattern: Filigreed Shadow Gown"] = "Desen: Telkari Gölge Elbisesi" end
if E["Pattern: Filigreed Shadow Leggings"] == nil then E["Pattern: Filigreed Shadow Leggings"] = "Desen: Telkari Gölge Tozlukları" end
if E["Pattern: Filigreed Shining Circlet"] == nil then E["Pattern: Filigreed Shining Circlet"] = "Desen: Telkari Parlayan Alınlık" end
if E["Pattern: Filigreed Shining Gown"] == nil then E["Pattern: Filigreed Shining Gown"] = "Desen: Telkari Parlayan Elbise" end
if E["Pattern: Filigreed Shining Leggings"] == nil then E["Pattern: Filigreed Shining Leggings"] = "Desen: Telkari Parlayan Tozluklar" end
if E["Pattern: Filigreed Silky Circlet"] == nil then E["Pattern: Filigreed Silky Circlet"] = "Desen: Telkari İpeksi Alınlık" end
if E["Pattern: Filigreed Silky Gown"] == nil then E["Pattern: Filigreed Silky Gown"] = "Desen: Telkari İpeksi Elbise" end
if E["Pattern: Filigreed Silky Leggings"] == nil then E["Pattern: Filigreed Silky Leggings"] = "Desen: Telkari İpeksi Tozluklar" end
if E["Pattern: Flame Boots"] == nil then E["Pattern: Flame Boots"] = "Desen: Alev Çizmeleri" end
if E["Pattern: Flame Circlet"] == nil then E["Pattern: Flame Circlet"] = "Desen: Alev Alınlığı" end
if E["Pattern: Flame Gloves"] == nil then E["Pattern: Flame Gloves"] = "Desen: Alev Eldivenleri" end
if E["Pattern: Flame Gown"] == nil then E["Pattern: Flame Gown"] = "Desen: Alev Elbisesi" end
if E["Pattern: Flame Leggings"] == nil then E["Pattern: Flame Leggings"] = "Desen: Alev Tozlukları" end
if E["Pattern: Flame Sash"] == nil then E["Pattern: Flame Sash"] = "Desen: Alev Kuşağı" end
if E["Pattern: Forceful Heavy Armor Kit"] == nil then E["Pattern: Forceful Heavy Armor Kit"] = "Desen: Güçlü Ağır Zırh Kiti" end
if E["Pattern: Forceful Medium Armor Kit"] == nil then E["Pattern: Forceful Medium Armor Kit"] = "Desen: Güçlü Orta Zırh Kiti" end
if E["Pattern: Forceful Rugged Armor Kit"] == nil then E["Pattern: Forceful Rugged Armor Kit"] = "Desen: Güçlü Sağlam Zırh Kiti" end
if E["Pattern: Forceful Thick Armor Kit"] == nil then E["Pattern: Forceful Thick Armor Kit"] = "Desen: Güçlü Kalın Zırh Kiti" end
if E["Pattern: Frothing Cord"] == nil then E["Pattern: Frothing Cord"] = "Desen: Köpüren İp Kuşak" end
if E["Pattern: Frothing Gloves"] == nil then E["Pattern: Frothing Gloves"] = "Desen: Köpüren Eldivenler" end
if E["Pattern: Frothing Handwraps"] == nil then E["Pattern: Frothing Handwraps"] = "Desen: Köpüren El Sargıları" end
if E["Pattern: Frothing Sandals"] == nil then E["Pattern: Frothing Sandals"] = "Desen: Köpüren Sandaletler" end
if E["Pattern: Frothing Slippers"] == nil then E["Pattern: Frothing Slippers"] = "Desen: Köpüren Terlikler" end
if E["Pattern: Frothing Waistcord"] == nil then E["Pattern: Frothing Waistcord"] = "Desen: Köpüren Bel İpi" end
if E["Pattern: Ghostweave Boots"] == nil then E["Pattern: Ghostweave Boots"] = "Desen: Hayalet Örgüsü Çizmeleri" end
if E["Pattern: Ghostweave Cord"] == nil then E["Pattern: Ghostweave Cord"] = "Desen: Hayalet Örgüsü İp Kuşağı" end
if E["Pattern: Ghostweave Hood"] == nil then E["Pattern: Ghostweave Hood"] = "Desen: Hayalet Örgüsü Başlığı" end
if E["Pattern: Ghostweave Mantle"] == nil then E["Pattern: Ghostweave Mantle"] = "Desen: Hayalet Örgüsü Mantosu" end
if E["Pattern: Gilded Cord"] == nil then E["Pattern: Gilded Cord"] = "Desen: Yaldızlı İp Kuşak" end
if E["Pattern: Gilded Gloves"] == nil then E["Pattern: Gilded Gloves"] = "Desen: Yaldızlı Eldivenler" end
if E["Pattern: Gilded Handwraps"] == nil then E["Pattern: Gilded Handwraps"] = "Desen: Yaldızlı El Sargıları" end
if E["Pattern: Gilded Sandals"] == nil then E["Pattern: Gilded Sandals"] = "Desen: Yaldızlı Sandaletler" end
if E["Pattern: Gilded Slippers"] == nil then E["Pattern: Gilded Slippers"] = "Desen: Yaldızlı Terlikler" end
if E["Pattern: Gilded Waistcord"] == nil then E["Pattern: Gilded Waistcord"] = "Desen: Yaldızlı Bel İpi" end
if E["Pattern: Gloves of Conviction"] == nil then E["Pattern: Gloves of Conviction"] = "Desen: Kararlılığın Eldivenleri" end
if E["Pattern: Golden Cord"] == nil then E["Pattern: Golden Cord"] = "Desen: Altın İp Kuşak" end
if E["Pattern: Golden Gloves"] == nil then E["Pattern: Golden Gloves"] = "Desen: Altın Eldivenler" end
if E["Pattern: Golden Handwraps"] == nil then E["Pattern: Golden Handwraps"] = "Desen: Altın El Sargıları" end
if E["Pattern: Golden Sandals"] == nil then E["Pattern: Golden Sandals"] = "Desen: Altın Sandaletler" end
if E["Pattern: Golden Slippers"] == nil then E["Pattern: Golden Slippers"] = "Desen: Altın Terlikler" end
if E["Pattern: Golden Waistcord"] == nil then E["Pattern: Golden Waistcord"] = "Desen: Altın Bel İpi" end
if E["Pattern: Green Winter Clothes"] == nil then E["Pattern: Green Winter Clothes"] = "Desen: Yeşil Kış Kıyafetleri" end
if E["Pattern: Grimstitch Boots"] == nil then E["Pattern: Grimstitch Boots"] = "Desen: Kasvetli Dikiş Çizmeleri" end
if E["Pattern: Grimstitch Gloves"] == nil then E["Pattern: Grimstitch Gloves"] = "Desen: Kasvetli Dikiş Eldivenleri" end
if E["Pattern: Grimstitch Pants"] == nil then E["Pattern: Grimstitch Pants"] = "Desen: Kasvetli Dikiş Pantolonu" end
if E["Pattern: Grimstitch Spaulders"] == nil then E["Pattern: Grimstitch Spaulders"] = "Desen: Kasvetli Dikiş Omuz Levhaları" end
if E["Pattern: Grovekeeper Boots"] == nil then E["Pattern: Grovekeeper Boots"] = "Desen: Koru Bekçisi Çizmeleri" end
if E["Pattern: Grovekeeper Gauntlets"] == nil then E["Pattern: Grovekeeper Gauntlets"] = "Desen: Koru Bekçisi Zırh Eldivenleri" end
if E["Pattern: Grovekeeper Grips"] == nil then E["Pattern: Grovekeeper Grips"] = "Desen: Koru Bekçisi Kavrayıcıları" end
if E["Pattern: Grovekeeper Handguards"] == nil then E["Pattern: Grovekeeper Handguards"] = "Desen: Koru Bekçisi El Koruyucuları" end
if E["Pattern: Grovekeeper Kilt"] == nil then E["Pattern: Grovekeeper Kilt"] = "Desen: Koru Bekçisi Eteği" end
if E["Pattern: Grovekeeper Leggings"] == nil then E["Pattern: Grovekeeper Leggings"] = "Desen: Koru Bekçisi Tozlukları" end
if E["Pattern: Grovekeeper Legguards"] == nil then E["Pattern: Grovekeeper Legguards"] = "Desen: Koru Bekçisi Bacak Koruyucuları" end
if E["Pattern: Grovekeeper Mantle"] == nil then E["Pattern: Grovekeeper Mantle"] = "Desen: Koru Bekçisi Mantosu" end
if E["Pattern: Grovekeeper Mitts"] == nil then E["Pattern: Grovekeeper Mitts"] = "Desen: Koru Bekçisi Parmaksız Eldivenleri" end
if E["Pattern: Grovekeeper Pauldrons"] == nil then E["Pattern: Grovekeeper Pauldrons"] = "Desen: Koru Bekçisi Omuz Zırhları" end
if E["Pattern: Grovekeeper Sandals"] == nil then E["Pattern: Grovekeeper Sandals"] = "Desen: Koru Bekçisi Sandaletleri" end
if E["Pattern: Grovekeeper Shoulderpads"] == nil then E["Pattern: Grovekeeper Shoulderpads"] = "Desen: Koru Bekçisi Omuz Pedleri" end
if E["Pattern: Grovekeeper Spaulders"] == nil then E["Pattern: Grovekeeper Spaulders"] = "Desen: Koru Bekçisi Omuz Levhaları" end
if E["Pattern: Grovekeeper Stompers"] == nil then E["Pattern: Grovekeeper Stompers"] = "Desen: Koru Bekçisi Tepicileri" end
if E["Pattern: Grovekeeper Treads"] == nil then E["Pattern: Grovekeeper Treads"] = "Desen: Koru Bekçisi Adımlıkları" end
if E["Pattern: Grovekeeper Trousers"] == nil then E["Pattern: Grovekeeper Trousers"] = "Desen: Koru Bekçisi Şalvarı" end
if E["Pattern: Handguards of Conviction"] == nil then E["Pattern: Handguards of Conviction"] = "Desen: Kararlılığın El Koruyucuları" end
if E["Pattern: Heavy Scorpid Boots"] == nil then E["Pattern: Heavy Scorpid Boots"] = "Desen: Ağır Akrep Çizmeleri" end
if E["Pattern: Hillman's Leather Boots"] == nil then E["Pattern: Hillman's Leather Boots"] = "Desen: Dağlının Deri Çizmeleri" end
if E["Pattern: Hivethrasher's Boots"] == nil then E["Pattern: Hivethrasher's Boots"] = "Desen: Kovan Ezicinin Çizmeleri" end
if E["Pattern: Hivethrasher's Claws"] == nil then E["Pattern: Hivethrasher's Claws"] = "Desen: Kovan Ezicinin Pençeleri" end
if E["Pattern: Hivethrasher's Girdle"] == nil then E["Pattern: Hivethrasher's Girdle"] = "Desen: Kovan Ezicinin Bel Kuşağı" end
if E["Pattern: Invoker's Cord"] == nil then E["Pattern: Invoker's Cord"] = "Desen: Çağırıcının İp Kuşağı" end
if E["Pattern: Invoker's Mantle"] == nil then E["Pattern: Invoker's Mantle"] = "Desen: Çağırıcının Mantosu" end
if E["Pattern: Ironfeather Leggings"] == nil then E["Pattern: Ironfeather Leggings"] = "Desen: Demirtüy Tozlukları" end
if E["Pattern: Leggings of Conviction"] == nil then E["Pattern: Leggings of Conviction"] = "Desen: Kararlılığın Tozlukları" end
if E["Pattern: Light Leather Reagent Bag"] == nil then E["Pattern: Light Leather Reagent Bag"] = "Desen: Hafif Deri Bileşen Çantası" end
if E["Pattern: Linen Reagent Bag"] == nil then E["Pattern: Linen Reagent Bag"] = "Desen: Keten Bileşen Çantası" end
if E["Pattern: Living Crown"] == nil then E["Pattern: Living Crown"] = "Desen: Yaşayan Taç" end
if E["Pattern: Mageweave Reagent Bag"] == nil then E["Pattern: Mageweave Reagent Bag"] = "Desen: Büyüdokuma Bileşen Çantası" end
if E["Pattern: Mana-infused Cord"] == nil then E["Pattern: Mana-infused Cord"] = "Desen: Mana Aşılanmış İp Kuşak" end
if E["Pattern: Manaflare Boots"] == nil then E["Pattern: Manaflare Boots"] = "Desen: Mana Parıltısı Çizmeleri" end
if E["Pattern: Manaflare Gloves"] == nil then E["Pattern: Manaflare Gloves"] = "Desen: Mana Parıltısı Eldivenleri" end
if E["Pattern: Manaflare Mantle"] == nil then E["Pattern: Manaflare Mantle"] = "Desen: Mana Parıltısı Mantosu" end
if E["Pattern: Manaflare Pants"] == nil then E["Pattern: Manaflare Pants"] = "Desen: Mana Parıltısı Pantolonu" end
if E["Pattern: Mantle of Conviction"] == nil then E["Pattern: Mantle of Conviction"] = "Desen: Kararlılığın Mantosu" end
if E["Pattern: Mender's Leather Belt"] == nil then E["Pattern: Mender's Leather Belt"] = "Desen: Şifacının Deri Kemeri" end
if E["Pattern: Mender's Leather Boots"] == nil then E["Pattern: Mender's Leather Boots"] = "Desen: Şifacının Deri Çizmeleri" end
if E["Pattern: Mender's Leather Bracers"] == nil then E["Pattern: Mender's Leather Bracers"] = "Desen: Şifacının Deri Bileklikleri" end
if E["Pattern: Mender's Leather Gauntlets"] == nil then E["Pattern: Mender's Leather Gauntlets"] = "Desen: Şifacının Deri Zırh Eldivenleri" end
if E["Pattern: Mender's Leather Gloves"] == nil then E["Pattern: Mender's Leather Gloves"] = "Desen: Şifacının Deri Eldivenleri" end
if E["Pattern: Mender's Leather Shoes"] == nil then E["Pattern: Mender's Leather Shoes"] = "Desen: Şifacının Deri Ayakkabıları" end
if E["Pattern: Mender's Leather Shoulder"] == nil then E["Pattern: Mender's Leather Shoulder"] = "Desen: Şifacının Deri Omuzluğu" end
if E["Pattern: Mender's Leather Waistguard"] == nil then E["Pattern: Mender's Leather Waistguard"] = "Desen: Şifacının Deri Bel Koruyucusu" end
if E["Pattern: Mender's Mail Belt"] == nil then E["Pattern: Mender's Mail Belt"] = "Desen: Şifacının Zincir Kemeri" end
if E["Pattern: Mender's Mail Boots"] == nil then E["Pattern: Mender's Mail Boots"] = "Desen: Şifacının Zincir Çizmeleri" end
if E["Pattern: Mender's Mail Bracers"] == nil then E["Pattern: Mender's Mail Bracers"] = "Desen: Şifacının Zincir Bileklikleri" end
if E["Pattern: Mender's Mail Gauntlets"] == nil then E["Pattern: Mender's Mail Gauntlets"] = "Desen: Şifacının Zincir Zırh Eldivenleri" end
if E["Pattern: Mender's Mail Sabatons"] == nil then E["Pattern: Mender's Mail Sabatons"] = "Desen: Şifacının Zincir Zırh Çizmeleri" end
if E["Pattern: Mender's Mail Shoulder"] == nil then E["Pattern: Mender's Mail Shoulder"] = "Desen: Şifacının Zincir Omuzluğu" end
if E["Pattern: Mooncloth Reagent Bag"] == nil then E["Pattern: Mooncloth Reagent Bag"] = "Desen: Ay Kumaşı Bileşen Çantası" end
if E["Pattern: Moonglow Boots"] == nil then E["Pattern: Moonglow Boots"] = "Desen: Ay Işıltısı Çizmeleri" end
if E["Pattern: Mourning Handguards"] == nil then E["Pattern: Mourning Handguards"] = "Desen: Yas El Koruyucuları" end
if E["Pattern: Murloc Scale Shoes"] == nil then E["Pattern: Murloc Scale Shoes"] = "Desen: Murloc Pulu Ayakkabıları" end
if E["Pattern: Mystic Heavy Armor Kit"] == nil then E["Pattern: Mystic Heavy Armor Kit"] = "Desen: Mistik Ağır Zırh Kiti" end
if E["Pattern: Mystic Medium Armor Kit"] == nil then E["Pattern: Mystic Medium Armor Kit"] = "Desen: Mistik Orta Zırh Kiti" end
if E["Pattern: Mystic Rugged Armor Kit"] == nil then E["Pattern: Mystic Rugged Armor Kit"] = "Desen: Mistik Sağlam Zırh Kiti" end
if E["Pattern: Mystic Thick Armor Kit"] == nil then E["Pattern: Mystic Thick Armor Kit"] = "Desen: Mistik Kalın Zırh Kiti" end
if E["Pattern: Netherflame Cuffs"] == nil then E["Pattern: Netherflame Cuffs"] = "Desen: Hiçlik Alevi Kollukları" end
if E["Pattern: Netherflame Shoulders"] == nil then E["Pattern: Netherflame Shoulders"] = "Desen: Hiçlik Alevi Omuzlukları" end
if E["Pattern: Netherfroth Cuffs"] == nil then E["Pattern: Netherfroth Cuffs"] = "Desen: Hiçlik Köpüğü Kollukları" end
if E["Pattern: Netherfroth Shoulders"] == nil then E["Pattern: Netherfroth Shoulders"] = "Desen: Hiçlik Köpüğü Omuzlukları" end
if E["Pattern: Nethergeld Cuffs"] == nil then E["Pattern: Nethergeld Cuffs"] = "Desen: Hiçlik Yaldızı Kollukları" end
if E["Pattern: Nethergeld Shoulders"] == nil then E["Pattern: Nethergeld Shoulders"] = "Desen: Hiçlik Yaldızı Omuzlukları" end
if E["Pattern: Netherlight Cuffs"] == nil then E["Pattern: Netherlight Cuffs"] = "Desen: Hiçlik Işığı Kollukları" end
if E["Pattern: Netherlight Shoulders"] == nil then E["Pattern: Netherlight Shoulders"] = "Desen: Hiçlik Işığı Omuzlukları" end
if E["Pattern: Netherpearl Cuffs"] == nil then E["Pattern: Netherpearl Cuffs"] = "Desen: Hiçlik İncisi Kollukları" end
if E["Pattern: Netherpearl Shoulders"] == nil then E["Pattern: Netherpearl Shoulders"] = "Desen: Hiçlik İncisi Omuzlukları" end
if E["Pattern: Nethershine Cuffs"] == nil then E["Pattern: Nethershine Cuffs"] = "Desen: Hiçlik Parıltısı Kollukları" end
if E["Pattern: Nethershine Shoulders"] == nil then E["Pattern: Nethershine Shoulders"] = "Desen: Hiçlik Parıltısı Omuzlukları" end
if E["Pattern: Novice Arcanist's Sash"] == nil then E["Pattern: Novice Arcanist's Sash"] = "Desen: Acemi Arkanistin Kuşağı" end
if E["Pattern: Novice Ardent's Sash"] == nil then E["Pattern: Novice Ardent's Sash"] = "Desen: Acemi Gayretlinin Kuşağı" end
if E["Pattern: Outlaw's Collar"] == nil then E["Pattern: Outlaw's Collar"] = "Desen: Kanun Kaçağının Yakası" end
if E["Pattern: Pants of Conviction"] == nil then E["Pattern: Pants of Conviction"] = "Desen: Kararlılığın Pantolonu" end
if E["Pattern: Pauldrons of Conviction"] == nil then E["Pattern: Pauldrons of Conviction"] = "Desen: Kararlılığın Omuz Zırhları" end
if E["Pattern: Pearly Boots"] == nil then E["Pattern: Pearly Boots"] = "Desen: İncili Çizmeler" end
if E["Pattern: Pearly Circlet"] == nil then E["Pattern: Pearly Circlet"] = "Desen: İncili Alınlık" end
if E["Pattern: Pearly Gloves"] == nil then E["Pattern: Pearly Gloves"] = "Desen: İncili Eldivenler" end
if E["Pattern: Pearly Gown"] == nil then E["Pattern: Pearly Gown"] = "Desen: İncili Elbise" end
if E["Pattern: Pearly Leggings"] == nil then E["Pattern: Pearly Leggings"] = "Desen: İncili Tozluklar" end
if E["Pattern: Pearly Sash"] == nil then E["Pattern: Pearly Sash"] = "Desen: İncili Kuşak" end
if E["Pattern: Phoenix Bindings"] == nil then E["Pattern: Phoenix Bindings"] = "Desen: Anka Bağları" end
if E["Pattern: Pristine Boots"] == nil then E["Pattern: Pristine Boots"] = "Desen: Kusursuz Çizmeler" end
if E["Pattern: Pristine Circlet"] == nil then E["Pattern: Pristine Circlet"] = "Desen: Kusursuz Alınlık" end
if E["Pattern: Pristine Gloves"] == nil then E["Pattern: Pristine Gloves"] = "Desen: Kusursuz Eldivenler" end
if E["Pattern: Pristine Gown"] == nil then E["Pattern: Pristine Gown"] = "Desen: Kusursuz Elbise" end
if E["Pattern: Pristine Leggings"] == nil then E["Pattern: Pristine Leggings"] = "Desen: Kusursuz Tozluklar" end
if E["Pattern: Pristine Sash"] == nil then E["Pattern: Pristine Sash"] = "Desen: Kusursuz Kuşak" end
if E["Pattern: Pristine Scorpid Leggings"] == nil then E["Pattern: Pristine Scorpid Leggings"] = "Desen: Kusursuz Akrep Tozlukları" end
if E["Pattern: Prowler's Leather Belt"] == nil then E["Pattern: Prowler's Leather Belt"] = "Desen: Sinsi Avcının Deri Kemeri" end
if E["Pattern: Prowler's Leather Boots"] == nil then E["Pattern: Prowler's Leather Boots"] = "Desen: Sinsi Avcının Deri Çizmeleri" end
if E["Pattern: Prowler's Leather Bracers"] == nil then E["Pattern: Prowler's Leather Bracers"] = "Desen: Sinsi Avcının Deri Bileklikleri" end
if E["Pattern: Prowler's Leather Gauntlets"] == nil then E["Pattern: Prowler's Leather Gauntlets"] = "Desen: Sinsi Avcının Deri Zırh Eldivenleri" end
if E["Pattern: Prowler's Leather Gloves"] == nil then E["Pattern: Prowler's Leather Gloves"] = "Desen: Sinsi Avcının Deri Eldivenleri" end
if E["Pattern: Prowler's Leather Shoes"] == nil then E["Pattern: Prowler's Leather Shoes"] = "Desen: Sinsi Avcının Deri Ayakkabıları" end
if E["Pattern: Prowler's Leather Shoulder"] == nil then E["Pattern: Prowler's Leather Shoulder"] = "Desen: Sinsi Avcının Deri Omuzluğu" end
if E["Pattern: Prowler's Leather Waistguard"] == nil then E["Pattern: Prowler's Leather Waistguard"] = "Desen: Sinsi Avcının Deri Bel Koruyucusu" end
if E["Pattern: Radiant Cord"] == nil then E["Pattern: Radiant Cord"] = "Desen: Işıldayan İp Kuşak" end
if E["Pattern: Radiant Gloves"] == nil then E["Pattern: Radiant Gloves"] = "Desen: Işıldayan Eldivenler" end
if E["Pattern: Radiant Handwraps"] == nil then E["Pattern: Radiant Handwraps"] = "Desen: Işıldayan El Sargıları" end
if E["Pattern: Radiant Sandals"] == nil then E["Pattern: Radiant Sandals"] = "Desen: Işıldayan Sandaletler" end
if E["Pattern: Radiant Slippers"] == nil then E["Pattern: Radiant Slippers"] = "Desen: Işıldayan Terlikler" end
if E["Pattern: Radiant Waistcord"] == nil then E["Pattern: Radiant Waistcord"] = "Desen: Işıldayan Bel İpi" end
if E["Pattern: Red Dragonscale Leggings"] == nil then E["Pattern: Red Dragonscale Leggings"] = "Desen: Kırmızı Ejderha Pulu Tozlukları" end
if E["Pattern: Red Winter Clothes"] == nil then E["Pattern: Red Winter Clothes"] = "Desen: Kırmızı Kış Kıyafetleri" end
if E["Pattern: Rime-encrusted Boots"] == nil then E["Pattern: Rime-encrusted Boots"] = "Desen: Kırağı Kaplı Çizmeler" end
if E["Pattern: Robes of Fiery Devastation"] == nil then E["Pattern: Robes of Fiery Devastation"] = "Desen: Ateşli Yıkımın Cübbeleri" end
if E["Pattern: Runecloth Cuffs"] == nil then E["Pattern: Runecloth Cuffs"] = "Desen: Rün Kumaşı Kollukları" end
if E["Pattern: Runecloth Reagent Bag"] == nil then E["Pattern: Runecloth Reagent Bag"] = "Desen: Rün Kumaşı Bileşen Çantası" end
if E["Pattern: Scalegut Belt"] == nil then E["Pattern: Scalegut Belt"] = "Desen: Pulbağırsak Kemeri" end
if E["Pattern: Scalegut Clenchers"] == nil then E["Pattern: Scalegut Clenchers"] = "Desen: Pulbağırsak Kıskaçları" end
if E["Pattern: Scalegut Treaders"] == nil then E["Pattern: Scalegut Treaders"] = "Desen: Pulbağırsak Ayaklıkları" end
if E["Pattern: Scarlet Augur's Vestments"] == nil then E["Pattern: Scarlet Augur's Vestments"] = "Desen: Scarlet Kâhininin Giysileri" end
if E["Pattern: Shadow Boots"] == nil then E["Pattern: Shadow Boots"] = "Desen: Gölge Çizmeleri" end
if E["Pattern: Shadow Circlet"] == nil then E["Pattern: Shadow Circlet"] = "Desen: Gölge Alınlığı" end
if E["Pattern: Shadow Gloves"] == nil then E["Pattern: Shadow Gloves"] = "Desen: Gölge Eldivenleri" end
if E["Pattern: Shadow Gown"] == nil then E["Pattern: Shadow Gown"] = "Desen: Gölge Elbisesi" end
if E["Pattern: Shadow Leggings"] == nil then E["Pattern: Shadow Leggings"] = "Desen: Gölge Tozlukları" end
if E["Pattern: Shadow Sash"] == nil then E["Pattern: Shadow Sash"] = "Desen: Gölge Kuşağı" end
if E["Pattern: Shining Boots"] == nil then E["Pattern: Shining Boots"] = "Desen: Parlayan Çizmeler" end
if E["Pattern: Shining Circlet"] == nil then E["Pattern: Shining Circlet"] = "Desen: Parlayan Alınlık" end
if E["Pattern: Shining Gloves"] == nil then E["Pattern: Shining Gloves"] = "Desen: Parlayan Eldivenler" end
if E["Pattern: Shining Gown"] == nil then E["Pattern: Shining Gown"] = "Desen: Parlayan Elbise" end
if E["Pattern: Shining Leggings"] == nil then E["Pattern: Shining Leggings"] = "Desen: Parlayan Tozluklar" end
if E["Pattern: Shining Sash"] == nil then E["Pattern: Shining Sash"] = "Desen: Parlayan Kuşak" end
if E["Pattern: Silk Reagent Bag"] == nil then E["Pattern: Silk Reagent Bag"] = "Desen: İpek Bileşen Çantası" end
if E["Pattern: Silky Boots"] == nil then E["Pattern: Silky Boots"] = "Desen: İpeksi Çizmeler" end
if E["Pattern: Silky Circlet"] == nil then E["Pattern: Silky Circlet"] = "Desen: İpeksi Alınlık" end
if E["Pattern: Silky Gloves"] == nil then E["Pattern: Silky Gloves"] = "Desen: İpeksi Eldivenler" end
if E["Pattern: Silky Gown"] == nil then E["Pattern: Silky Gown"] = "Desen: İpeksi Elbise" end
if E["Pattern: Silky Leggings"] == nil then E["Pattern: Silky Leggings"] = "Desen: İpeksi Tozluklar" end
if E["Pattern: Silky Sash"] == nil then E["Pattern: Silky Sash"] = "Desen: İpeksi Kuşak" end
if E["Pattern: Skirmisher's Leather Belt"] == nil then E["Pattern: Skirmisher's Leather Belt"] = "Desen: Çatışmacının Deri Kemeri" end
if E["Pattern: Skirmisher's Leather Gloves"] == nil then E["Pattern: Skirmisher's Leather Gloves"] = "Desen: Çatışmacının Deri Eldivenleri" end
if E["Pattern: Skirmisher's Mail Belt"] == nil then E["Pattern: Skirmisher's Mail Belt"] = "Desen: Çatışmacının Zincir Kemeri" end
if E["Pattern: Skirmisher's Mail Boots"] == nil then E["Pattern: Skirmisher's Mail Boots"] = "Desen: Çatışmacının Zincir Çizmeleri" end
if E["Pattern: Skirmisher's Mail Bracers"] == nil then E["Pattern: Skirmisher's Mail Bracers"] = "Desen: Çatışmacının Zincir Bileklikleri" end
if E["Pattern: Skirmisher's Mail Gauntlets"] == nil then E["Pattern: Skirmisher's Mail Gauntlets"] = "Desen: Çatışmacının Zincir Zırh Eldivenleri" end
if E["Pattern: Skirmisher's Mail Sabatons"] == nil then E["Pattern: Skirmisher's Mail Sabatons"] = "Desen: Çatışmacının Zincir Zırh Çizmeleri" end
if E["Pattern: Skirmisher's Mail Shoulder"] == nil then E["Pattern: Skirmisher's Mail Shoulder"] = "Desen: Çatışmacının Zincir Omuzluğu" end
if E["Pattern: Skulker's Leather Belt"] == nil then E["Pattern: Skulker's Leather Belt"] = "Desen: Pusucunun Deri Kemeri" end
if E["Pattern: Skulker's Leather Boots"] == nil then E["Pattern: Skulker's Leather Boots"] = "Desen: Pusucunun Deri Çizmeleri" end
if E["Pattern: Skulker's Leather Bracers"] == nil then E["Pattern: Skulker's Leather Bracers"] = "Desen: Pusucunun Deri Bileklikleri" end
if E["Pattern: Skulker's Leather Gauntlets"] == nil then E["Pattern: Skulker's Leather Gauntlets"] = "Desen: Pusucunun Deri Zırh Eldivenleri" end
if E["Pattern: Skulker's Leather Gloves"] == nil then E["Pattern: Skulker's Leather Gloves"] = "Desen: Pusucunun Deri Eldivenleri" end
if E["Pattern: Skulker's Leather Shoes"] == nil then E["Pattern: Skulker's Leather Shoes"] = "Desen: Pusucunun Deri Ayakkabıları" end
if E["Pattern: Skulker's Leather Shoulder"] == nil then E["Pattern: Skulker's Leather Shoulder"] = "Desen: Pusucunun Deri Omuzluğu" end
if E["Pattern: Skulker's Leather Waistguard"] == nil then E["Pattern: Skulker's Leather Waistguard"] = "Desen: Pusucunun Deri Bel Koruyucusu" end
if E["Pattern: Skycaller's Leather Belt"] == nil then E["Pattern: Skycaller's Leather Belt"] = "Desen: Gök Çağırıcının Deri Kemeri" end
if E["Pattern: Skycaller's Leather Boots"] == nil then E["Pattern: Skycaller's Leather Boots"] = "Desen: Gök Çağırıcının Deri Çizmeleri" end
if E["Pattern: Skycaller's Leather Bracers"] == nil then E["Pattern: Skycaller's Leather Bracers"] = "Desen: Gök Çağırıcının Deri Bileklikleri" end
if E["Pattern: Skycaller's Leather Gauntlets"] == nil then E["Pattern: Skycaller's Leather Gauntlets"] = "Desen: Gök Çağırıcının Deri Zırh Eldivenleri" end
if E["Pattern: Skycaller's Leather Gloves"] == nil then E["Pattern: Skycaller's Leather Gloves"] = "Desen: Gök Çağırıcının Deri Eldivenleri" end
if E["Pattern: Skycaller's Leather Shoes"] == nil then E["Pattern: Skycaller's Leather Shoes"] = "Desen: Gök Çağırıcının Deri Ayakkabıları" end
if E["Pattern: Skycaller's Leather Shoulder"] == nil then E["Pattern: Skycaller's Leather Shoulder"] = "Desen: Gök Çağırıcının Deri Omuzluğu" end
if E["Pattern: Skycaller's Leather Waistguard"] == nil then E["Pattern: Skycaller's Leather Waistguard"] = "Desen: Gök Çağırıcının Deri Bel Koruyucusu" end
if E["Pattern: Skycaller's Mail Belt"] == nil then E["Pattern: Skycaller's Mail Belt"] = "Desen: Gök Çağırıcının Zincir Kemeri" end
if E["Pattern: Skycaller's Mail Boots"] == nil then E["Pattern: Skycaller's Mail Boots"] = "Desen: Gök Çağırıcının Zincir Çizmeleri" end
if E["Pattern: Skycaller's Mail Bracers"] == nil then E["Pattern: Skycaller's Mail Bracers"] = "Desen: Gök Çağırıcının Zincir Bileklikleri" end
if E["Pattern: Skycaller's Mail Gauntlets"] == nil then E["Pattern: Skycaller's Mail Gauntlets"] = "Desen: Gök Çağırıcının Zincir Zırh Eldivenleri" end
if E["Pattern: Skycaller's Mail Sabatons"] == nil then E["Pattern: Skycaller's Mail Sabatons"] = "Desen: Gök Çağırıcının Zincir Zırh Çizmeleri" end
if E["Pattern: Skycaller's Mail Shoulder"] == nil then E["Pattern: Skycaller's Mail Shoulder"] = "Desen: Gök Çağırıcının Zincir Omuzluğu" end
if E["Pattern: Slimeslayer's Adaptive Cord"] == nil then E["Pattern: Slimeslayer's Adaptive Cord"] = "Desen: Balçık Avcısının Uyumlu İp Kuşağı" end
if E["Pattern: Slimeslayer's Adaptive Cuffs"] == nil then E["Pattern: Slimeslayer's Adaptive Cuffs"] = "Desen: Balçık Avcısının Uyumlu Kollukları" end
if E["Pattern: Slimeslayer's Adaptive Robes"] == nil then E["Pattern: Slimeslayer's Adaptive Robes"] = "Desen: Balçık Avcısının Uyumlu Cübbeleri" end
if E["Pattern: Slimetender's Adaptive Belt"] == nil then E["Pattern: Slimetender's Adaptive Belt"] = "Desen: Balçık Bakıcısının Uyumlu Kemeri" end
if E["Pattern: Slimetender's Adaptive Bracers"] == nil then E["Pattern: Slimetender's Adaptive Bracers"] = "Desen: Balçık Bakıcısının Uyumlu Bileklikleri" end
if E["Pattern: Slimetender's Adaptive Tunic"] == nil then E["Pattern: Slimetender's Adaptive Tunic"] = "Desen: Balçık Bakıcısının Uyumlu Tuniği" end
if E["Pattern: Spiritcaller Boots"] == nil then E["Pattern: Spiritcaller Boots"] = "Desen: Ruh Çağırıcı Çizmeleri" end
if E["Pattern: Spiritcaller Epaulets"] == nil then E["Pattern: Spiritcaller Epaulets"] = "Desen: Ruh Çağırıcı Apoletleri" end
if E["Pattern: Spiritcaller Gauntlets"] == nil then E["Pattern: Spiritcaller Gauntlets"] = "Desen: Ruh Çağırıcı Zırh Eldivenleri" end
if E["Pattern: Spiritcaller Gloves"] == nil then E["Pattern: Spiritcaller Gloves"] = "Desen: Ruh Çağırıcı Eldivenleri" end
if E["Pattern: Spiritcaller Greaves"] == nil then E["Pattern: Spiritcaller Greaves"] = "Desen: Ruh Çağırıcı Baldırlıkları" end
if E["Pattern: Spiritcaller Grips"] == nil then E["Pattern: Spiritcaller Grips"] = "Desen: Ruh Çağırıcı Kavrayıcıları" end
if E["Pattern: Spiritcaller Kilt"] == nil then E["Pattern: Spiritcaller Kilt"] = "Desen: Ruh Çağırıcı Eteği" end
if E["Pattern: Spiritcaller Leggings"] == nil then E["Pattern: Spiritcaller Leggings"] = "Desen: Ruh Çağırıcı Tozlukları" end
if E["Pattern: Spiritcaller Mantle"] == nil then E["Pattern: Spiritcaller Mantle"] = "Desen: Ruh Çağırıcı Mantosu" end
if E["Pattern: Spiritcaller Pants"] == nil then E["Pattern: Spiritcaller Pants"] = "Desen: Ruh Çağırıcı Pantolonu" end
if E["Pattern: Spiritcaller Spaulders"] == nil then E["Pattern: Spiritcaller Spaulders"] = "Desen: Ruh Çağırıcı Omuz Levhaları" end
if E["Pattern: Spiritcaller Treads"] == nil then E["Pattern: Spiritcaller Treads"] = "Desen: Ruh Çağırıcı Adımlıkları" end
if E["Pattern: Stalker's Leather Belt"] == nil then E["Pattern: Stalker's Leather Belt"] = "Desen: İz Sürücünün Deri Kemeri" end
if E["Pattern: Stalker's Leather Gloves"] == nil then E["Pattern: Stalker's Leather Gloves"] = "Desen: İz Sürücünün Deri Eldivenleri" end
if E["Pattern: Stalker's Mail Belt"] == nil then E["Pattern: Stalker's Mail Belt"] = "Desen: İz Sürücünün Zincir Kemeri" end
if E["Pattern: Stalker's Mail Boots"] == nil then E["Pattern: Stalker's Mail Boots"] = "Desen: İz Sürücünün Zincir Çizmeleri" end
if E["Pattern: Stalker's Mail Bracers"] == nil then E["Pattern: Stalker's Mail Bracers"] = "Desen: İz Sürücünün Zincir Bileklikleri" end
if E["Pattern: Stalker's Mail Gauntlets"] == nil then E["Pattern: Stalker's Mail Gauntlets"] = "Desen: İz Sürücünün Zincir Zırh Eldivenleri" end
if E["Pattern: Stalker's Mail Sabatons"] == nil then E["Pattern: Stalker's Mail Sabatons"] = "Desen: İz Sürücünün Zincir Zırh Çizmeleri" end
if E["Pattern: Stalker's Mail Shoulder"] == nil then E["Pattern: Stalker's Mail Shoulder"] = "Desen: İz Sürücünün Zincir Omuzluğu" end
if E["Pattern: Stormrider's Leather Belt"] == nil then E["Pattern: Stormrider's Leather Belt"] = "Desen: Fırtına Süvarisinin Deri Kemeri" end
if E["Pattern: Stormrider's Leather Boots"] == nil then E["Pattern: Stormrider's Leather Boots"] = "Desen: Fırtına Süvarisinin Deri Çizmeleri" end
if E["Pattern: Stormrider's Leather Gloves"] == nil then E["Pattern: Stormrider's Leather Gloves"] = "Desen: Fırtına Süvarisinin Deri Eldivenleri" end
if E["Pattern: Stormrider's Leather Hood"] == nil then E["Pattern: Stormrider's Leather Hood"] = "Desen: Fırtına Süvarisinin Deri Başlığı" end
if E["Pattern: Stormrider's Leather Kilt"] == nil then E["Pattern: Stormrider's Leather Kilt"] = "Desen: Fırtına Süvarisinin Deri Eteği" end
if E["Pattern: Stormrider's Leather Tunic"] == nil then E["Pattern: Stormrider's Leather Tunic"] = "Desen: Fırtına Süvarisinin Deri Tuniği" end
if E["Pattern: Supple Scorpid Belt"] == nil then E["Pattern: Supple Scorpid Belt"] = "Desen: Esnek Akrep Kemeri" end
if E["Pattern: Supple Scorpid Boots"] == nil then E["Pattern: Supple Scorpid Boots"] = "Desen: Esnek Akrep Çizmeleri" end
if E["Pattern: Supple Scorpid Bracers"] == nil then E["Pattern: Supple Scorpid Bracers"] = "Desen: Esnek Akrep Bileklikleri" end
if E["Pattern: Supple Scorpid Helm"] == nil then E["Pattern: Supple Scorpid Helm"] = "Desen: Esnek Akrep Miğferi" end
if E["Pattern: Supple Scorpid Leggings"] == nil then E["Pattern: Supple Scorpid Leggings"] = "Desen: Esnek Akrep Tozlukları" end
if E["Pattern: Supple Scorpid Sabatons"] == nil then E["Pattern: Supple Scorpid Sabatons"] = "Desen: Esnek Akrep Zırh Çizmeleri" end
if E["Pattern: Supple Scorpid Shoulder"] == nil then E["Pattern: Supple Scorpid Shoulder"] = "Desen: Esnek Akrep Omuzluğu" end
if E["Pattern: Supple Scorpid Vest"] == nil then E["Pattern: Supple Scorpid Vest"] = "Desen: Esnek Akrep Yeleği" end
if E["Pattern: Swarmtender's Cord"] == nil then E["Pattern: Swarmtender's Cord"] = "Desen: Sürü Bakıcısının İp Kuşağı" end
if E["Pattern: Swarmtender's Footpads"] == nil then E["Pattern: Swarmtender's Footpads"] = "Desen: Sürü Bakıcısının Ayak Pedleri" end
if E["Pattern: Swarmtender's Gloves"] == nil then E["Pattern: Swarmtender's Gloves"] = "Desen: Sürü Bakıcısının Eldivenleri" end
if E["Pattern: Timbermaw Tunic"] == nil then E["Pattern: Timbermaw Tunic"] = "Desen: Timbermaw Tuniği" end
if E["Pattern: Tooled Leather Armor"] == nil then E["Pattern: Tooled Leather Armor"] = "Desen: İşlenmiş Deri Zırh" end
if E["Pattern: Tooled Leather Belt"] == nil then E["Pattern: Tooled Leather Belt"] = "Desen: İşlenmiş Deri Kemer" end
if E["Pattern: Tooled Leather Boots"] == nil then E["Pattern: Tooled Leather Boots"] = "Desen: İşlenmiş Deri Çizmeler" end
if E["Pattern: Tooled Leather Bracers"] == nil then E["Pattern: Tooled Leather Bracers"] = "Desen: İşlenmiş Deri Bileklikler" end
if E["Pattern: Tooled Leather Crown"] == nil then E["Pattern: Tooled Leather Crown"] = "Desen: İşlenmiş Deri Taç" end
if E["Pattern: Tooled Leather Epaulets"] == nil then E["Pattern: Tooled Leather Epaulets"] = "Desen: İşlenmiş Deri Apoletler" end
if E["Pattern: Tooled Leather Gauntlets"] == nil then E["Pattern: Tooled Leather Gauntlets"] = "Desen: İşlenmiş Deri Zırh Eldivenleri" end
if E["Pattern: Tooled Leather Pants"] == nil then E["Pattern: Tooled Leather Pants"] = "Desen: İşlenmiş Deri Pantolon" end
if E["Pattern: Totemic Leather Belt"] == nil then E["Pattern: Totemic Leather Belt"] = "Desen: Totemik Deri Kemer" end
if E["Pattern: Totemic Leather Boots"] == nil then E["Pattern: Totemic Leather Boots"] = "Desen: Totemik Deri Çizmeler" end
if E["Pattern: Totemic Leather Gloves"] == nil then E["Pattern: Totemic Leather Gloves"] = "Desen: Totemik Deri Eldivenler" end
if E["Pattern: Totemic Leather Hood"] == nil then E["Pattern: Totemic Leather Hood"] = "Desen: Totemik Deri Başlık" end
if E["Pattern: Totemic Leather Leggings"] == nil then E["Pattern: Totemic Leather Leggings"] = "Desen: Totemik Deri Tozluklar" end
if E["Pattern: Totemic Leather Tunic"] == nil then E["Pattern: Totemic Leather Tunic"] = "Desen: Totemik Deri Tunik" end
if E["Pattern: Tranquil Wristguards"] == nil then E["Pattern: Tranquil Wristguards"] = "Desen: Sakin Bilek Koruyucuları" end
if E["Pattern: Trapper's Leather Belt"] == nil then E["Pattern: Trapper's Leather Belt"] = "Desen: Tuzakçının Deri Kemeri" end
if E["Pattern: Trapper's Leather Boots"] == nil then E["Pattern: Trapper's Leather Boots"] = "Desen: Tuzakçının Deri Çizmeleri" end
if E["Pattern: Trapper's Leather Gloves"] == nil then E["Pattern: Trapper's Leather Gloves"] = "Desen: Tuzakçının Deri Eldivenleri" end
if E["Pattern: Trapper's Leather Hood"] == nil then E["Pattern: Trapper's Leather Hood"] = "Desen: Tuzakçının Deri Başlığı" end
if E["Pattern: Trapper's Leather Legguards"] == nil then E["Pattern: Trapper's Leather Legguards"] = "Desen: Tuzakçının Deri Bacak Koruyucuları" end
if E["Pattern: Trapper's Leather Tunic"] == nil then E["Pattern: Trapper's Leather Tunic"] = "Desen: Tuzakçının Deri Tuniği" end
if E["Pattern: Treads of Conviction"] == nil then E["Pattern: Treads of Conviction"] = "Desen: Kararlılığın Adımlıkları" end
if E["Pattern: Venomspew Cord"] == nil then E["Pattern: Venomspew Cord"] = "Desen: Zehirpüskürten İp Kuşak" end
if E["Pattern: Venomspew Footpads"] == nil then E["Pattern: Venomspew Footpads"] = "Desen: Zehirpüskürten Ayak Pedleri" end
if E["Pattern: Venomspew Gloves"] == nil then E["Pattern: Venomspew Gloves"] = "Desen: Zehirpüskürten Eldivenler" end
if E["Pattern: Warbear Helm"] == nil then E["Pattern: Warbear Helm"] = "Desen: Savaş Ayısı Miğferi" end
if E["Pattern: Warden's Leather Belt"] == nil then E["Pattern: Warden's Leather Belt"] = "Desen: Muhafızın Deri Kemeri" end
if E["Pattern: Warden's Leather Boots"] == nil then E["Pattern: Warden's Leather Boots"] = "Desen: Bekçinin Deri Çizmeleri" end
if E["Pattern: Warden's Leather Bracers"] == nil then E["Pattern: Warden's Leather Bracers"] = "Desen: Bekçinin Deri Bileklikleri" end
if E["Pattern: Warden's Leather Gauntlets"] == nil then E["Pattern: Warden's Leather Gauntlets"] = "Desen: Bekçinin Deri Zırhlı Eldivenleri" end
if E["Pattern: Warden's Leather Gloves"] == nil then E["Pattern: Warden's Leather Gloves"] = "Desen: Bekçinin Deri Eldivenleri" end
if E["Pattern: Warden's Leather Shoes"] == nil then E["Pattern: Warden's Leather Shoes"] = "Desen: Bekçinin Deri Ayakkabıları" end
if E["Pattern: Warden's Leather Shoulder"] == nil then E["Pattern: Warden's Leather Shoulder"] = "Desen: Bekçinin Deri Omuzluğu" end
if E["Pattern: Warden's Leather Waistguard"] == nil then E["Pattern: Warden's Leather Waistguard"] = "Desen: Bekçinin Deri Bel Koruması" end
if E["Pattern: Wicked Leather Boots"] == nil then E["Pattern: Wicked Leather Boots"] = "Desen: Kötücül Deri Çizmeler" end
if E["Pattern: Wicked Leather Shoulder"] == nil then E["Pattern: Wicked Leather Shoulder"] = "Desen: Kötücül Deri Omuzluk" end
if E["Pattern: Wild Leather Armor Kit"] == nil then E["Pattern: Wild Leather Armor Kit"] = "Desen: Vahşi Deri Zırh Takımı" end
if E["Pattern: Wildstalker's Gauntlets"] == nil then E["Pattern: Wildstalker's Gauntlets"] = "Desen: Vahşi İzcinin Zırhlı Eldivenleri" end
if E["Pattern: Wildstalker's Greaves"] == nil then E["Pattern: Wildstalker's Greaves"] = "Desen: Vahşi İzcinin Baldırlıkları" end
if E["Pattern: Wildstalker's Legguards"] == nil then E["Pattern: Wildstalker's Legguards"] = "Desen: Vahşi İzcinin Bacak Korumaları" end
if E["Pattern: Wildstalker's Spaulders"] == nil then E["Pattern: Wildstalker's Spaulders"] = "Desen: Vahşi İzcinin Omuz Plakaları" end
if E["Pattern: Winter Boots"] == nil then E["Pattern: Winter Boots"] = "Desen: Kış Çizmeleri" end
if E["Pattern: Wisdom's Leather Belt"] == nil then E["Pattern: Wisdom's Leather Belt"] = "Desen: Bilgeliğin Deri Kemeri" end
if E["Pattern: Wisdom's Leather Boots"] == nil then E["Pattern: Wisdom's Leather Boots"] = "Desen: Bilgeliğin Deri Çizmeleri" end
if E["Pattern: Wisdom's Leather Gloves"] == nil then E["Pattern: Wisdom's Leather Gloves"] = "Desen: Bilgeliğin Deri Eldivenleri" end
if E["Pattern: Wisdom's Leather Hood"] == nil then E["Pattern: Wisdom's Leather Hood"] = "Desen: Bilgeliğin Deri Başlığı" end
if E["Pattern: Wisdom's Leather Leggings"] == nil then E["Pattern: Wisdom's Leather Leggings"] = "Desen: Bilgeliğin Deri Tozlukları" end
if E["Pattern: Wisdom's Leather Tunic"] == nil then E["Pattern: Wisdom's Leather Tunic"] = "Desen: Bilgeliğin Deri Tuniği" end
if E["Pattern: Woolen Reagent Bag"] == nil then E["Pattern: Woolen Reagent Bag"] = "Desen: Yün Reaktif Çantası" end
if E["Peacekeeper's Buckler"] == nil then E["Peacekeeper's Buckler"] = "Barış Koruyucusunun Küçük Kalkanı" end
if E["Peacekeeper's Legguards"] == nil then E["Peacekeeper's Legguards"] = "Barış Koruyucusunun Bacak Korumaları" end
if E["Peacekeeper's Mail"] == nil then E["Peacekeeper's Mail"] = "Barış Koruyucusunun Örgü Zırhı" end
if E["Peacekeeper's Pickhammer"] == nil then E["Peacekeeper's Pickhammer"] = "Barış Koruyucusunun Kazma Çekici" end
if E["Penitent's Cinch"] == nil then E["Penitent's Cinch"] = "Tövbekarın Kolanı" end
if E["Philanthropist's Ring"] == nil then E["Philanthropist's Ring"] = "Hayırseverin Yüzüğü" end
if E["Picture Book: Fun with Elementals"] == nil then E["Picture Book: Fun with Elementals"] = "Resimli Kitap: Elementallerle Eğlence" end
if E["Plague Doctor's Laboratory"] == nil then E["Plague Doctor's Laboratory"] = "Veba Doktorunun Laboratuvarı" end
if E["Plain Ol' Paletusk"] == nil then E["Plain Ol' Paletusk"] = "Bildiğin Paletusk" end
if E["Plans: Acolyte's Boots"] == nil then E["Plans: Acolyte's Boots"] = "Plan: Çömezin Çizmeleri" end
if E["Plans: Acolyte's Chain Belt"] == nil then E["Plans: Acolyte's Chain Belt"] = "Plan: Çömezin Zincir Kemeri" end
if E["Plans: Acolyte's Gloves"] == nil then E["Plans: Acolyte's Gloves"] = "Plan: Çömezin Eldivenleri" end
if E["Plans: Acolyte's Silvered Chain Helm"] == nil then E["Plans: Acolyte's Silvered Chain Helm"] = "Plan: Çömezin Gümüşlü Zincir Miğferi" end
if E["Plans: Acolyte's Silvered Chain Leggings"] == nil then E["Plans: Acolyte's Silvered Chain Leggings"] = "Plan: Çömezin Gümüşlü Zincir Tozlukları" end
if E["Plans: Acolyte's Silvered Chain Shirt"] == nil then E["Plans: Acolyte's Silvered Chain Shirt"] = "Plan: Çömezin Gümüşlü Zincir Gömleği" end
if E["Plans: Arcanite Blacksmith Hammer"] == nil then E["Plans: Arcanite Blacksmith Hammer"] = "Plan: Arkanit Demirci Çekici" end
if E["Plans: Azerothium Legplates"] == nil then E["Plans: Azerothium Legplates"] = "Plan: Azerothium Bacak Plakaları" end
if E["Plans: Azure Skyforged Chain"] == nil then E["Plans: Azure Skyforged Chain"] = "Plan: Gök Mavisi Gökte Dövülmüş Zincir" end
if E["Plans: Azure Skyforged Chainmail"] == nil then E["Plans: Azure Skyforged Chainmail"] = "Plan: Gök Mavisi Gökte Dövülmüş Zincir Zırh" end
if E["Plans: Azure Skyforged Gauntlets"] == nil then E["Plans: Azure Skyforged Gauntlets"] = "Plan: Gök Mavisi Gökte Dövülmüş Zırhlı Eldivenler" end
if E["Plans: Azure Skyforged Greaves"] == nil then E["Plans: Azure Skyforged Greaves"] = "Plan: Gök Mavisi Gökte Dövülmüş Baldırlıklar" end
if E["Plans: Azure Skyforged Helm"] == nil then E["Plans: Azure Skyforged Helm"] = "Plan: Gök Mavisi Gökte Dövülmüş Miğfer" end
if E["Plans: Azure Skyforged Legguards"] == nil then E["Plans: Azure Skyforged Legguards"] = "Plan: Gök Mavisi Gökte Dövülmüş Bacak Korumaları" end
if E["Plans: Azure Skyforged Pauldrons"] == nil then E["Plans: Azure Skyforged Pauldrons"] = "Plan: Gök Mavisi Gökte Dövülmüş Omuz Zırhları" end
if E["Plans: Azure Skyforged Wristguards"] == nil then E["Plans: Azure Skyforged Wristguards"] = "Plan: Gök Mavisi Gökte Dövülmüş Bilek Korumaları" end
if E["Plans: Bagh Nakh"] == nil then E["Plans: Bagh Nakh"] = "Plan: Bagh Nakh" end
if E["Plans: Blessed Plate Belt"] == nil then E["Plans: Blessed Plate Belt"] = "Plan: Kutsanmış Plaka Kemer" end
if E["Plans: Blessed Plate Boots"] == nil then E["Plans: Blessed Plate Boots"] = "Plan: Kutsanmış Plaka Çizmeler" end
if E["Plans: Blessed Plate Bracers"] == nil then E["Plans: Blessed Plate Bracers"] = "Plan: Kutsanmış Plaka Bileklikler" end
if E["Plans: Blessed Plate Chest"] == nil then E["Plans: Blessed Plate Chest"] = "Plan: Kutsanmış Plaka Göğüs Zırhı" end
if E["Plans: Blessed Plate Gauntlet"] == nil then E["Plans: Blessed Plate Gauntlet"] = "Plan: Kutsanmış Plaka Eldiven" end
if E["Plans: Blessed Plate Helm"] == nil then E["Plans: Blessed Plate Helm"] = "Plan: Kutsanmış Plaka Miğfer" end
if E["Plans: Blessed Plate Leggings"] == nil then E["Plans: Blessed Plate Leggings"] = "Plan: Kutsanmış Plaka Tozluklar" end
if E["Plans: Blessed Plate Pauldrons"] == nil then E["Plans: Blessed Plate Pauldrons"] = "Plan: Kutsanmış Plaka Omuz Zırhları" end
if E["Plans: Bold Dirk"] == nil then E["Plans: Bold Dirk"] = "Plan: Cesur Hançer" end
if E["Plans: Brass Knuckles"] == nil then E["Plans: Brass Knuckles"] = "Plan: Pirinç Muşta" end
if E["Plans: Breastplate of Salvation"] == nil then E["Plans: Breastplate of Salvation"] = "Plan: Kurtuluşun Göğüslüğü" end
if E["Plans: Bronze Dory"] == nil then E["Plans: Bronze Dory"] = "Plan: Bronz Mızrak" end
if E["Plans: Champion's Legplates"] == nil then E["Plans: Champion's Legplates"] = "Plan: Şampiyonun Bacak Plakaları" end
if E["Plans: Charged Mithril Battleaxe"] == nil then E["Plans: Charged Mithril Battleaxe"] = "Plan: Yüklü Mithril Savaş Baltası" end
if E["Plans: Cloudy Skyforged Chain"] == nil then E["Plans: Cloudy Skyforged Chain"] = "Plan: Bulutlu Gökte Dövülmüş Zincir" end
if E["Plans: Cloudy Skyforged Chainmail"] == nil then E["Plans: Cloudy Skyforged Chainmail"] = "Plan: Bulutlu Gökte Dövülmüş Zincir Zırh" end
if E["Plans: Cloudy Skyforged Gauntlets"] == nil then E["Plans: Cloudy Skyforged Gauntlets"] = "Plan: Bulutlu Gökte Dövülmüş Zırhlı Eldivenler" end
if E["Plans: Cloudy Skyforged Greaves"] == nil then E["Plans: Cloudy Skyforged Greaves"] = "Plan: Bulutlu Gökte Dövülmüş Baldırlıklar" end
if E["Plans: Cloudy Skyforged Helm"] == nil then E["Plans: Cloudy Skyforged Helm"] = "Plan: Bulutlu Gökte Dövülmüş Miğfer" end
if E["Plans: Cloudy Skyforged Legguards"] == nil then E["Plans: Cloudy Skyforged Legguards"] = "Plan: Bulutlu Gökte Dövülmüş Bacak Korumaları" end
if E["Plans: Cloudy Skyforged Pauldrons"] == nil then E["Plans: Cloudy Skyforged Pauldrons"] = "Plan: Bulutlu Gökte Dövülmüş Omuz Zırhları" end
if E["Plans: Cloudy Skyforged Wristguards"] == nil then E["Plans: Cloudy Skyforged Wristguards"] = "Plan: Bulutlu Gökte Dövülmüş Bilek Korumaları" end
if E["Plans: Clutchlord's Grips"] == nil then E["Plans: Clutchlord's Grips"] = "Plan: Clutchlord'un Kavrayıcıları" end
if E["Plans: Clutchlord's Stompers"] == nil then E["Plans: Clutchlord's Stompers"] = "Plan: Clutchlord'un Ezici Çizmeleri" end
if E["Plans: Clutchlord's Support"] == nil then E["Plans: Clutchlord's Support"] = "Plan: Clutchlord'un Desteği" end
if E["Plans: Cracked Blacksmith Hammer"] == nil then E["Plans: Cracked Blacksmith Hammer"] = "Plan: Çatlak Demirci Çekici" end
if E["Plans: Crusader's Boots"] == nil then E["Plans: Crusader's Boots"] = "Plan: Haçlının Çizmeleri" end
if E["Plans: Crusader's Chain Belt"] == nil then E["Plans: Crusader's Chain Belt"] = "Plan: Haçlının Zincir Kemeri" end
if E["Plans: Crusader's Gloves"] == nil then E["Plans: Crusader's Gloves"] = "Plan: Haçlının Eldivenleri" end
if E["Plans: Crusader's Silvered Chain Helm"] == nil then E["Plans: Crusader's Silvered Chain Helm"] = "Plan: Haçlının Gümüşlü Zincir Miğferi" end
if E["Plans: Crusader's Silvered Chain Leggings"] == nil then E["Plans: Crusader's Silvered Chain Leggings"] = "Plan: Haçlının Gümüşlü Zincir Tozlukları" end
if E["Plans: Crusader's Silvered Chain Shirt"] == nil then E["Plans: Crusader's Silvered Chain Shirt"] = "Plan: Haçlının Gümüşlü Zincir Gömleği" end
if E["Plans: Dazzling Mithril Rapier"] == nil then E["Plans: Dazzling Mithril Rapier"] = "Plan: Göz Kamaştırıcı Mithril Meç" end
if E["Plans: Depleted Thorium Sabatons"] == nil then E["Plans: Depleted Thorium Sabatons"] = "Plan: Tükenmiş Toryum Zırh Pabuçları" end
if E["Plans: Earthcrusher's Adaptive Armguards"] == nil then E["Plans: Earthcrusher's Adaptive Armguards"] = "Plan: Toprak Ezicinin Uyarlanabilir Kol Korumaları" end
if E["Plans: Earthcrusher's Adaptive Chestplate"] == nil then E["Plans: Earthcrusher's Adaptive Chestplate"] = "Plan: Toprak Ezicinin Uyarlanabilir Göğüs Plakası" end
if E["Plans: Earthcrusher's Adaptive Girdle"] == nil then E["Plans: Earthcrusher's Adaptive Girdle"] = "Plan: Toprak Ezicinin Uyarlanabilir Kuşağı" end
if E["Plans: Earthweaver's Adaptive Links"] == nil then E["Plans: Earthweaver's Adaptive Links"] = "Plan: Toprak Dokuyucunun Uyarlanabilir Halkaları" end
if E["Plans: Earthweaver's Adaptive Plate"] == nil then E["Plans: Earthweaver's Adaptive Plate"] = "Plan: Toprak Dokuyucunun Uyarlanabilir Plaka Zırhı" end
if E["Plans: Earthweaver's Adaptive Waistguard"] == nil then E["Plans: Earthweaver's Adaptive Waistguard"] = "Plan: Toprak Dokuyucunun Uyarlanabilir Bel Koruması" end
if E["Plans: Enriched Thorium Breastplate"] == nil then E["Plans: Enriched Thorium Breastplate"] = "Plan: Zenginleştirilmiş Toryum Göğüslük" end
if E["Plans: Enriched Thorium Helm"] == nil then E["Plans: Enriched Thorium Helm"] = "Plan: Zenginleştirilmiş Toryum Miğfer" end
if E["Plans: Enriched Thorium Leggings"] == nil then E["Plans: Enriched Thorium Leggings"] = "Plan: Zenginleştirilmiş Toryum Tozluklar" end
if E["Plans: Evergreen Shield"] == nil then E["Plans: Evergreen Shield"] = "Plan: Yaprak Dökmez Kalkan" end
if E["Plans: Forest Defender's Axe"] == nil then E["Plans: Forest Defender's Axe"] = "Plan: Orman Savunucusunun Baltası" end
if E["Plans: Gauntlets of Glory"] == nil then E["Plans: Gauntlets of Glory"] = "Plan: Şanın Zırhlı Eldivenleri" end
if E["Plans: Gemmed Copper Boots"] == nil then E["Plans: Gemmed Copper Boots"] = "Plan: Mücevherli Bakır Çizmeler" end
if E["Plans: Glowing Copper Boots"] == nil then E["Plans: Glowing Copper Boots"] = "Plan: Parlayan Bakır Çizmeler" end
if E["Plans: Goregasher Grips"] == nil then E["Plans: Goregasher Grips"] = "Plan: Goregasher Kavrayıcıları" end
if E["Plans: Goregasher Stompers"] == nil then E["Plans: Goregasher Stompers"] = "Plan: Goregasher Ezici Çizmeleri" end
if E["Plans: Goregasher Support"] == nil then E["Plans: Goregasher Support"] = "Plan: Goregasher Desteği" end
if E["Plans: Greaves of Glory"] == nil then E["Plans: Greaves of Glory"] = "Plan: Şanın Baldırlıkları" end
if E["Plans: Greenhammer"] == nil then E["Plans: Greenhammer"] = "Plan: Yeşil Çekiç" end
if E["Plans: Guard's Boots"] == nil then E["Plans: Guard's Boots"] = "Plan: Muhafızın Çizmeleri" end
if E["Plans: Guard's Chain Belt"] == nil then E["Plans: Guard's Chain Belt"] = "Plan: Muhafızın Zincir Kemeri" end
if E["Plans: Guard's Chain Shirt"] == nil then E["Plans: Guard's Chain Shirt"] = "Plan: Muhafızın Zincir Gömleği" end
if E["Plans: Guard's Gloves"] == nil then E["Plans: Guard's Gloves"] = "Plan: Muhafızın Eldivenleri" end
if E["Plans: Guard's Silvered Chain Helm"] == nil then E["Plans: Guard's Silvered Chain Helm"] = "Plan: Muhafızın Gümüşlü Zincir Miğferi" end
if E["Plans: Guard's Silvered Chain Leggings"] == nil then E["Plans: Guard's Silvered Chain Leggings"] = "Plan: Muhafızın Gümüşlü Zincir Tozlukları" end
if E["Plans: Guard's Silvered Chain Shirt"] == nil then E["Plans: Guard's Silvered Chain Shirt"] = "Plan: Muhafızın Gümüşlü Zincir Gömleği" end
if E["Plans: Handguards of Glory"] == nil then E["Plans: Handguards of Glory"] = "Plan: Şanın El Korumaları" end
if E["Plans: Hard Gold Boots"] == nil then E["Plans: Hard Gold Boots"] = "Plan: Sert Altın Çizmeler" end
if E["Plans: Hard Gold Bracers"] == nil then E["Plans: Hard Gold Bracers"] = "Plan: Sert Altın Bileklikler" end
if E["Plans: Hard Gold Coif"] == nil then E["Plans: Hard Gold Coif"] = "Plan: Sert Altın Zincir Başlık" end
if E["Plans: Hard Gold Cuirass"] == nil then E["Plans: Hard Gold Cuirass"] = "Plan: Sert Altın Gövde Zırhı" end
if E["Plans: Hard Gold Gauntlet"] == nil then E["Plans: Hard Gold Gauntlet"] = "Plan: Sert Altın Eldiven" end
if E["Plans: Hard Gold Leggings"] == nil then E["Plans: Hard Gold Leggings"] = "Plan: Sert Altın Tozluklar" end
if E["Plans: Hard Gold Pauldrons"] == nil then E["Plans: Hard Gold Pauldrons"] = "Plan: Sert Altın Omuz Zırhları" end
if E["Plans: Heavy Thorium Gauntlets"] == nil then E["Plans: Heavy Thorium Gauntlets"] = "Plan: Ağır Toryum Zırhlı Eldivenler" end
if E["Plans: Imperial Plate Gauntlets"] == nil then E["Plans: Imperial Plate Gauntlets"] = "Plan: İmparatorluk Plaka Zırhlı Eldivenleri" end
if E["Plans: Iron Fists"] == nil then E["Plans: Iron Fists"] = "Plan: Demir Yumruklar" end
if E["Plans: Iron Morningstar"] == nil then E["Plans: Iron Morningstar"] = "Plan: Demir Çivili Gürz" end
if E["Plans: Ironwood Blade"] == nil then E["Plans: Ironwood Blade"] = "Plan: Demir Ağacı Kılıcı" end
if E["Plans: Justicar's Belt"] == nil then E["Plans: Justicar's Belt"] = "Plan: Yargıcın Kemeri" end
if E["Plans: Justicar's Boots"] == nil then E["Plans: Justicar's Boots"] = "Plan: Yargıcın Çizmeleri" end
if E["Plans: Justicar's Gauntlet"] == nil then E["Plans: Justicar's Gauntlet"] = "Plan: Yargıcın Eldiveni" end
if E["Plans: Justicar's Gloves"] == nil then E["Plans: Justicar's Gloves"] = "Plan: Yargıcın Eldivenleri" end
if E["Plans: Justicar's Pauldrons"] == nil then E["Plans: Justicar's Pauldrons"] = "Plan: Yargıcın Omuz Zırhları" end
if E["Plans: Justicar's Sabatons"] == nil then E["Plans: Justicar's Sabatons"] = "Plan: Yargıcın Zırh Pabuçları" end
if E["Plans: Justicar's Waistguard"] == nil then E["Plans: Justicar's Waistguard"] = "Plan: Yargıcın Bel Koruması" end
if E["Plans: Justicar's Wristguards"] == nil then E["Plans: Justicar's Wristguards"] = "Plan: Yargıcın Bilek Korumaları" end
if E["Plans: Justice Epaulets"] == nil then E["Plans: Justice Epaulets"] = "Plan: Adalet Apoletleri" end
if E["Plans: Justice Gauntlets"] == nil then E["Plans: Justice Gauntlets"] = "Plan: Adalet Zırhlı Eldivenleri" end
if E["Plans: Justice Gloves"] == nil then E["Plans: Justice Gloves"] = "Plan: Adalet Eldivenleri" end
if E["Plans: Justice Greaves"] == nil then E["Plans: Justice Greaves"] = "Plan: Adalet Baldırlıkları" end
if E["Plans: Justice Handguards"] == nil then E["Plans: Justice Handguards"] = "Plan: Adalet El Korumaları" end
if E["Plans: Justice Leggings"] == nil then E["Plans: Justice Leggings"] = "Plan: Adalet Tozlukları" end
if E["Plans: Justice Legguards"] == nil then E["Plans: Justice Legguards"] = "Plan: Adalet Bacak Korumaları" end
if E["Plans: Justice Legplates"] == nil then E["Plans: Justice Legplates"] = "Plan: Adalet Bacak Plakaları" end
if E["Plans: Justice Pauldrons"] == nil then E["Plans: Justice Pauldrons"] = "Plan: Adalet Omuz Zırhları" end
if E["Plans: Justice Sabatons"] == nil then E["Plans: Justice Sabatons"] = "Plan: Adalet Zırh Pabuçları" end
if E["Plans: Justice Spaulders"] == nil then E["Plans: Justice Spaulders"] = "Plan: Adalet Omuz Plakaları" end
if E["Plans: Justice Treads"] == nil then E["Plans: Justice Treads"] = "Plan: Adalet Pabuçları" end
if E["Plans: Legguards of Glory"] == nil then E["Plans: Legguards of Glory"] = "Plan: Şanın Bacak Korumaları" end
if E["Plans: Legionite Glaive"] == nil then E["Plans: Legionite Glaive"] = "Plan: Lejyonit Pala" end
if E["Plans: Legplates of Glory"] == nil then E["Plans: Legplates of Glory"] = "Plan: Şanın Bacak Plakaları" end
if E["Plans: Martyr's Legplates"] == nil then E["Plans: Martyr's Legplates"] = "Plan: Şehidin Bacak Plakaları" end
if E["Plans: Mithril Blacksmith Hammer"] == nil then E["Plans: Mithril Blacksmith Hammer"] = "Plan: Mithril Demirci Çekici" end
if E["Plans: Mithril Claws"] == nil then E["Plans: Mithril Claws"] = "Plan: Mithril Pençeler" end
if E["Plans: Mithril Claymore"] == nil then E["Plans: Mithril Claymore"] = "Plan: Mithril Büyük Kılıç" end
if E["Plans: Mithril Shortsword"] == nil then E["Plans: Mithril Shortsword"] = "Plan: Mithril Kısa Kılıç" end
if E["Plans: Mithril Stiletto"] == nil then E["Plans: Mithril Stiletto"] = "Plan: Mithril Stilet" end
if E["Plans: Mithril Warhammer"] == nil then E["Plans: Mithril Warhammer"] = "Plan: Mithril Savaş Çekici" end
if E["Plans: Officer's Belt"] == nil then E["Plans: Officer's Belt"] = "Plan: Subayın Kemeri" end
if E["Plans: Officer's Boots"] == nil then E["Plans: Officer's Boots"] = "Plan: Subayın Çizmeleri" end
if E["Plans: Officer's Gauntlet"] == nil then E["Plans: Officer's Gauntlet"] = "Plan: Subayın Eldiveni" end
if E["Plans: Officer's Gloves"] == nil then E["Plans: Officer's Gloves"] = "Plan: Subayın Eldivenleri" end
if E["Plans: Officer's Pauldrons"] == nil then E["Plans: Officer's Pauldrons"] = "Plan: Subayın Omuz Zırhları" end
if E["Plans: Officer's Sabatons"] == nil then E["Plans: Officer's Sabatons"] = "Plan: Subayın Zırh Pabuçları" end
if E["Plans: Officer's Waistguard"] == nil then E["Plans: Officer's Waistguard"] = "Plan: Subayın Bel Koruması" end
if E["Plans: Officer's Wristguard"] == nil then E["Plans: Officer's Wristguard"] = "Plan: Subayın Bilek Koruması" end
if E["Plans: Pauldrons of Glory"] == nil then E["Plans: Pauldrons of Glory"] = "Plan: Şanın Omuz Zırhları" end
if E["Plans: Prefect's Belt"] == nil then E["Plans: Prefect's Belt"] = "Plan: Valinin Kemeri" end
if E["Plans: Prefect's Boots"] == nil then E["Plans: Prefect's Boots"] = "Plan: Valinin Çizmeleri" end
if E["Plans: Prefect's Gauntlet"] == nil then E["Plans: Prefect's Gauntlet"] = "Plan: Valinin Eldiveni" end
if E["Plans: Prefect's Gloves"] == nil then E["Plans: Prefect's Gloves"] = "Plan: Valinin Eldivenleri" end
if E["Plans: Prefect's Pauldrons"] == nil then E["Plans: Prefect's Pauldrons"] = "Plan: Valinin Omuz Zırhları" end
if E["Plans: Prefect's Sabatons"] == nil then E["Plans: Prefect's Sabatons"] = "Plan: Valinin Zırh Pabuçları" end
if E["Plans: Prefect's Waistguard"] == nil then E["Plans: Prefect's Waistguard"] = "Plan: Valinin Bel Koruması" end
if E["Plans: Prefect's Wristguard"] == nil then E["Plans: Prefect's Wristguard"] = "Plan: Valinin Bilek Koruması" end
if E["Plans: Protector's Boots"] == nil then E["Plans: Protector's Boots"] = "Plan: Koruyucunun Çizmeleri" end
if E["Plans: Protector's Chain Belt"] == nil then E["Plans: Protector's Chain Belt"] = "Plan: Koruyucunun Zincir Kemeri" end
if E["Plans: Protector's Gloves"] == nil then E["Plans: Protector's Gloves"] = "Plan: Koruyucunun Eldivenleri" end
if E["Plans: Protector's Silvered Chain Helm"] == nil then E["Plans: Protector's Silvered Chain Helm"] = "Plan: Koruyucunun Gümüşlü Zincir Miğferi" end
if E["Plans: Protector's Silvered Chain Leggings"] == nil then E["Plans: Protector's Silvered Chain Leggings"] = "Plan: Koruyucunun Gümüşlü Zincir Tozlukları" end
if E["Plans: Protector's Silvered Chain Shirt"] == nil then E["Plans: Protector's Silvered Chain Shirt"] = "Plan: Koruyucunun Gümüşlü Zincir Gömleği" end
if E["Plans: Rough Copper Chain Boots"] == nil then E["Plans: Rough Copper Chain Boots"] = "Plan: Kaba Bakır Zincir Çizmeler" end
if E["Plans: Sabatons of Glory"] == nil then E["Plans: Sabatons of Glory"] = "Plan: Şanın Zırh Pabuçları" end
if E["Plans: Sentinel's Belt"] == nil then E["Plans: Sentinel's Belt"] = "Plan: Nöbetçinin Kemeri" end
if E["Plans: Sentinel's Boots"] == nil then E["Plans: Sentinel's Boots"] = "Plan: Nöbetçinin Çizmeleri" end
if E["Plans: Sentinel's Gauntlet"] == nil then E["Plans: Sentinel's Gauntlet"] = "Plan: Nöbetçinin Eldiveni" end
if E["Plans: Sentinel's Gloves"] == nil then E["Plans: Sentinel's Gloves"] = "Plan: Nöbetçinin Eldivenleri" end
if E["Plans: Sentinel's Pauldrons"] == nil then E["Plans: Sentinel's Pauldrons"] = "Plan: Nöbetçinin Omuz Zırhları" end
if E["Plans: Sentinel's Sabatons"] == nil then E["Plans: Sentinel's Sabatons"] = "Plan: Nöbetçinin Zırh Pabuçları" end
if E["Plans: Sentinel's Waistguard"] == nil then E["Plans: Sentinel's Waistguard"] = "Plan: Nöbetçinin Bel Koruması" end
if E["Plans: Sentinel's Wristguard"] == nil then E["Plans: Sentinel's Wristguard"] = "Plan: Nöbetçinin Bilek Koruması" end
if E["Plans: Shining Mithril Boots"] == nil then E["Plans: Shining Mithril Boots"] = "Plan: Parlak Mithril Çizmeler" end
if E["Plans: Shining Mithril Breastplate"] == nil then E["Plans: Shining Mithril Breastplate"] = "Plan: Parlak Mithril Göğüslük" end
if E["Plans: Shining Mithril Gauntlet"] == nil then E["Plans: Shining Mithril Gauntlet"] = "Plan: Parlak Mithril Eldiven" end
if E["Plans: Shining Mithril Pants"] == nil then E["Plans: Shining Mithril Pants"] = "Plan: Parlak Mithril Pantolon" end
if E["Plans: Shining Mithril Pauldrons"] == nil then E["Plans: Shining Mithril Pauldrons"] = "Plan: Parlak Mithril Omuz Zırhları" end
if E["Plans: Shoulders of Glory"] == nil then E["Plans: Shoulders of Glory"] = "Plan: Şanın Omuzlukları" end
if E["Plans: Stalwart Helm"] == nil then E["Plans: Stalwart Helm"] = "Plan: Yılmaz Miğfer" end
if E["Plans: Steel Spear"] == nil then E["Plans: Steel Spear"] = "Plan: Çelik Mızrak" end
if E["Plans: Sterling Silver Boots"] == nil then E["Plans: Sterling Silver Boots"] = "Plan: Saf Gümüş Çizmeler" end
if E["Plans: Sterling Silver Breastplate"] == nil then E["Plans: Sterling Silver Breastplate"] = "Plan: Saf Gümüş Göğüslük" end
if E["Plans: Sterling Silver Gauntlet"] == nil then E["Plans: Sterling Silver Gauntlet"] = "Plan: Saf Gümüş Eldiven" end
if E["Plans: Sterling Silver Leggings"] == nil then E["Plans: Sterling Silver Leggings"] = "Plan: Saf Gümüş Tozluklar" end
if E["Plans: Sterling Silver Shoulders"] == nil then E["Plans: Sterling Silver Shoulders"] = "Plan: Saf Gümüş Omuzluklar" end
if E["Plans: Stormcarver"] == nil then E["Plans: Stormcarver"] = "Plan: Fırtına Oyucu" end
if E["Plans: Strange Copper Boots"] == nil then E["Plans: Strange Copper Boots"] = "Plan: Tuhaf Bakır Çizmeler" end
if E["Plans: Tempered Interference-Negating Helmet"] == nil then E["Plans: Tempered Interference-Negating Helmet"] = "Plan: Temperlenmiş Parazit Önleyici Kask" end
if E["Plans: Thorium Cestus"] == nil then E["Plans: Thorium Cestus"] = "Plan: Toryum Dövüş Eldiveni" end
if E["Plans: Thorium Greatmace"] == nil then E["Plans: Thorium Greatmace"] = "Plan: Toryum Büyük Gürz" end
if E["Plans: Thorium Poleaxe"] == nil then E["Plans: Thorium Poleaxe"] = "Plan: Toryum Teber" end
if E["Plans: Veteran's Boots"] == nil then E["Plans: Veteran's Boots"] = "Plan: Emektarın Çizmeleri" end
if E["Plans: Veteran's Chain Belt"] == nil then E["Plans: Veteran's Chain Belt"] = "Plan: Emektarın Zincir Kemeri" end
if E["Plans: Veteran's Gloves"] == nil then E["Plans: Veteran's Gloves"] = "Plan: Emektarın Eldivenleri" end
if E["Plans: Veteran's Silvered Chain Helm"] == nil then E["Plans: Veteran's Silvered Chain Helm"] = "Plan: Emektarın Gümüşlü Zincir Miğferi" end
if E["Plans: Veteran's Silvered Chain Leggings"] == nil then E["Plans: Veteran's Silvered Chain Leggings"] = "Plan: Emektarın Gümüşlü Zincir Tozlukları" end
if E["Plans: Veteran's Silvered Chain Shirt"] == nil then E["Plans: Veteran's Silvered Chain Shirt"] = "Plan: Emektarın Gümüşlü Zincir Gömleği" end
if E["Plans: Warder's Belt"] == nil then E["Plans: Warder's Belt"] = "Plan: Gardiyanın Kemeri" end
if E["Plans: Warder's Boots"] == nil then E["Plans: Warder's Boots"] = "Plan: Gardiyanın Çizmeleri" end
if E["Plans: Warder's Gauntlet"] == nil then E["Plans: Warder's Gauntlet"] = "Plan: Gardiyanın Eldiveni" end
if E["Plans: Warder's Gloves"] == nil then E["Plans: Warder's Gloves"] = "Plan: Gardiyanın Eldivenleri" end
if E["Plans: Warder's Pauldrons"] == nil then E["Plans: Warder's Pauldrons"] = "Plan: Gardiyanın Omuz Zırhları" end
if E["Plans: Warder's Sabatons"] == nil then E["Plans: Warder's Sabatons"] = "Plan: Gardiyanın Zırh Pabuçları" end
if E["Plans: Warder's Waistguard"] == nil then E["Plans: Warder's Waistguard"] = "Plan: Gardiyanın Bel Koruması" end
if E["Plans: Warder's Wristguard"] == nil then E["Plans: Warder's Wristguard"] = "Plan: Gardiyanın Bilek Koruması" end
if E["Podrig's Order"] == nil then E["Podrig's Order"] = "Podrig'in Siparişi" end
if E["Pop-Up Shrub"] == nil then E["Pop-Up Shrub"] = "Açılır Çalı" end
if E["Potent Anti-Venom"] == nil then E["Potent Anti-Venom"] = "Güçlü Panzehir" end
if E["Potion of Experience - Level 23"] == nil then E["Potion of Experience - Level 23"] = "Deneyim İksiri - Seviye 23" end
if E["Potion of Experience - Level 38"] == nil then E["Potion of Experience - Level 38"] = "Deneyim İksiri - Seviye 38" end
if E["Potion of Experience - Level 57"] == nil then E["Potion of Experience - Level 57"] = "Deneyim İksiri - Seviye 57" end
if E["Potion of Experience - Level 60"] == nil then E["Potion of Experience - Level 60"] = "Deneyim İksiri - Seviye 60" end
if E["Potion of Tradeskill Testing - Level 60"] == nil then E["Potion of Tradeskill Testing - Level 60"] = "Meslek Testi İksiri - Seviye 60" end
if E["Prefect's Belt"] == nil then E["Prefect's Belt"] = "Valinin Kemeri" end
if E["Prefect's Boots"] == nil then E["Prefect's Boots"] = "Valinin Çizmeleri" end
if E["Prefect's Gauntlet"] == nil then E["Prefect's Gauntlet"] = "Valinin Eldiveni" end
if E["Prefect's Gloves"] == nil then E["Prefect's Gloves"] = "Valinin Eldivenleri" end
if E["Prefect's Pauldrons"] == nil then E["Prefect's Pauldrons"] = "Valinin Omuz Zırhları" end
if E["Prefect's Sabatons"] == nil then E["Prefect's Sabatons"] = "Valinin Zırh Pabuçları" end
if E["Prefect's Waistguard"] == nil then E["Prefect's Waistguard"] = "Valinin Bel Koruması" end
if E["Prefect's Wristguards"] == nil then E["Prefect's Wristguards"] = "Valinin Bilek Korumaları" end
if E["Prelate's Orb"] == nil then E["Prelate's Orb"] = "Başrahibin Küresi" end
if E["Premier Centurion's Chain Sabatons"] == nil then E["Premier Centurion's Chain Sabatons"] = "Senturyonun Seçkin Zincir Zırh Pabuçları" end
if E["Premier Centurion's Dragonhide Boots"] == nil then E["Premier Centurion's Dragonhide Boots"] = "Senturyonun Seçkin Ejder Derisi Çizmeleri" end
if E["Premier Centurion's Felweave Boots"] == nil then E["Premier Centurion's Felweave Boots"] = "Senturyonun Seçkin Fel Dokuması Çizmeleri" end
if E["Premier Centurion's Kodohide Boots"] == nil then E["Premier Centurion's Kodohide Boots"] = "Senturyonun Seçkin Kodo Derisi Çizmeleri" end
if E["Premier Centurion's Lamellar Boots"] == nil then E["Premier Centurion's Lamellar Boots"] = "Senturyonun Seçkin Lamel Çizmeleri" end
if E["Premier Centurion's Linked Boots"] == nil then E["Premier Centurion's Linked Boots"] = "Senturyonun Seçkin Halkalı Çizmeleri" end
if E["Premier Centurion's Magus Boots"] == nil then E["Premier Centurion's Magus Boots"] = "Senturyonun Seçkin Büyücü Çizmeleri" end
if E["Premier Centurion's Mail Boots"] == nil then E["Premier Centurion's Mail Boots"] = "Senturyonun Seçkin Örgü Çizmeleri" end
if E["Premier Centurion's Mortarplate Boots"] == nil then E["Premier Centurion's Mortarplate Boots"] = "Senturyonun Seçkin Harç Plaka Çizmeleri" end
if E["Premier Centurion's Ringmail Boots"] == nil then E["Premier Centurion's Ringmail Boots"] = "Senturyonun Seçkin Halka Örgü Çizmeleri" end
if E["Premier Centurion's Satin Boots"] == nil then E["Premier Centurion's Satin Boots"] = "Senturyonun Seçkin Saten Çizmeleri" end
if E["Premier Centurion's Scaled Boots"] == nil then E["Premier Centurion's Scaled Boots"] = "Senturyonun Seçkin Pullu Çizmeleri" end
if E["Premier Centurion's Shadowhide Treads"] == nil then E["Premier Centurion's Shadowhide Treads"] = "Senturyonun Seçkin Gölge Derisi Pabuçları" end
if E["Premier Centurion's Silken Boots"] == nil then E["Premier Centurion's Silken Boots"] = "Senturyonun Seçkin İpek Çizmeleri" end
if E["Premier Centurion's Wyrmhide Boots"] == nil then E["Premier Centurion's Wyrmhide Boots"] = "Senturyonun Seçkin Wyrm Derisi Çizmeleri" end
if E["Premier Champion's Chain Gloves"] == nil then E["Premier Champion's Chain Gloves"] = "Şampiyonun Seçkin Zincir Eldivenleri" end
if E["Premier Champion's Dragonhide Gloves"] == nil then E["Premier Champion's Dragonhide Gloves"] = "Şampiyonun Seçkin Ejder Derisi Eldivenleri" end
if E["Premier Champion's Felweave Gloves"] == nil then E["Premier Champion's Felweave Gloves"] = "Şampiyonun Seçkin Fel Dokuması Eldivenleri" end
if E["Premier Champion's Kodohide Gloves"] == nil then E["Premier Champion's Kodohide Gloves"] = "Şampiyonun Seçkin Kodo Derisi Eldivenleri" end
if E["Premier Champion's Lamellar Gloves"] == nil then E["Premier Champion's Lamellar Gloves"] = "Şampiyonun Seçkin Lamel Eldivenleri" end
if E["Premier Champion's Linked Gauntlets"] == nil then E["Premier Champion's Linked Gauntlets"] = "Şampiyonun Seçkin Halkalı Zırhlı Eldivenleri" end
if E["Premier Champion's Magus Handguards"] == nil then E["Premier Champion's Magus Handguards"] = "Şampiyonun Seçkin Büyücü El Korumaları" end
if E["Premier Champion's Mail Gauntlets"] == nil then E["Premier Champion's Mail Gauntlets"] = "Şampiyonun Seçkin Örgü Zırhlı Eldivenleri" end
if E["Premier Champion's Mortarplate Gauntlets"] == nil then E["Premier Champion's Mortarplate Gauntlets"] = "Şampiyonun Seçkin Harç Plaka Zırhlı Eldivenleri" end
if E["Premier Champion's Ringmail Gauntlets"] == nil then E["Premier Champion's Ringmail Gauntlets"] = "Şampiyonun Seçkin Halka Örgü Zırhlı Eldivenleri" end
if E["Premier Champion's Satin Gloves"] == nil then E["Premier Champion's Satin Gloves"] = "Şampiyonun Seçkin Saten Eldivenleri" end
if E["Premier Champion's Scaled Gloves"] == nil then E["Premier Champion's Scaled Gloves"] = "Şampiyonun Seçkin Pullu Eldivenleri" end
if E["Premier Champion's Shadowhide Mitts"] == nil then E["Premier Champion's Shadowhide Mitts"] = "Şampiyonun Seçkin Gölge Derisi Parmaksız Eldivenleri" end
if E["Premier Champion's Silken Gloves"] == nil then E["Premier Champion's Silken Gloves"] = "Şampiyonun Seçkin İpek Eldivenleri" end
if E["Premier Champion's Wyrmhide Gloves"] == nil then E["Premier Champion's Wyrmhide Gloves"] = "Şampiyonun Seçkin Wyrm Derisi Eldivenleri" end
if E["Premier Field Marshal's Beasthide Breastplate"] == nil then E["Premier Field Marshal's Beasthide Breastplate"] = "Saha Mareşalinin Seçkin Hayvan Derisi Göğüslüğü" end
if E["Premier Field Marshal's Beasthide Helmet"] == nil then E["Premier Field Marshal's Beasthide Helmet"] = "Saha Mareşalinin Seçkin Hayvan Derisi Kaskı" end
if E["Premier Field Marshal's Chainmail Breastplate"] == nil then E["Premier Field Marshal's Chainmail Breastplate"] = "Saha Mareşalinin Seçkin Zincir Örgü Göğüslüğü" end
if E["Premier Field Marshal's Chainmail Helm"] == nil then E["Premier Field Marshal's Chainmail Helm"] = "Saha Mareşalinin Seçkin Zincir Örgü Miğferi" end
if E["Premier Field Marshal's Chevalier Chestplate"] == nil then E["Premier Field Marshal's Chevalier Chestplate"] = "Saha Mareşalinin Seçkin Şövalye Göğüs Plakası" end
if E["Premier Field Marshal's Chevalier Faceguard"] == nil then E["Premier Field Marshal's Chevalier Faceguard"] = "Saha Mareşalinin Seçkin Şövalye Yüz Koruması" end
if E["Premier Field Marshal's Dreadweave Coronal"] == nil then E["Premier Field Marshal's Dreadweave Coronal"] = "Saha Mareşalinin Seçkin Dehşet Dokuması Tacı" end
if E["Premier Field Marshal's Dreadweave Robe"] == nil then E["Premier Field Marshal's Dreadweave Robe"] = "Saha Mareşalinin Seçkin Dehşet Dokuması Cüppesi" end
if E["Premier Field Marshal's Dreamhide Breastplate"] == nil then E["Premier Field Marshal's Dreamhide Breastplate"] = "Saha Mareşalinin Seçkin Rüya Derisi Göğüslüğü" end
if E["Premier Field Marshal's Dreamhide Helmet"] == nil then E["Premier Field Marshal's Dreamhide Helmet"] = "Saha Mareşalinin Seçkin Rüya Derisi Kaskı" end
if E["Premier Field Marshal's Flatmail Armor"] == nil then E["Premier Field Marshal's Flatmail Armor"] = "Saha Mareşalinin Seçkin Yassı Örgü Zırhı" end
if E["Premier Field Marshal's Flatmail Helm"] == nil then E["Premier Field Marshal's Flatmail Helm"] = "Saha Mareşalinin Seçkin Yassı Örgü Miğferi" end
if E["Premier Field Marshal's Leather Chestpiece"] == nil then E["Premier Field Marshal's Leather Chestpiece"] = "Saha Mareşalinin Seçkin Deri Göğüs Zırhı" end
if E["Premier Field Marshal's Leather Mask"] == nil then E["Premier Field Marshal's Leather Mask"] = "Saha Mareşalinin Seçkin Deri Maskesi" end
if E["Premier Field Marshal's Linkmail Armor"] == nil then E["Premier Field Marshal's Linkmail Armor"] = "Saha Mareşalinin Seçkin Bağlantılı Örgü Zırhı" end
if E["Premier Field Marshal's Linkmail Helm"] == nil then E["Premier Field Marshal's Linkmail Helm"] = "Saha Mareşalinin Seçkin Bağlantılı Örgü Miğferi" end
if E["Premier Field Marshal's Luminous Chestplate"] == nil then E["Premier Field Marshal's Luminous Chestplate"] = "Saha Mareşalinin Seçkin Işıltılı Göğüs Plakası" end
if E["Premier Field Marshal's Luminous Faceguard"] == nil then E["Premier Field Marshal's Luminous Faceguard"] = "Saha Mareşalinin Seçkin Işıltılı Yüz Koruması" end
if E["Premier Field Marshal's Lunarhide Breastplate"] == nil then E["Premier Field Marshal's Lunarhide Breastplate"] = "Saha Mareşalinin Seçkin Ay Derisi Göğüslüğü" end
if E["Premier Field Marshal's Lunarhide Helmet"] == nil then E["Premier Field Marshal's Lunarhide Helmet"] = "Saha Mareşalinin Seçkin Ay Derisi Kaskı" end
if E["Premier Field Marshal's Mooncloth Headdress"] == nil then E["Premier Field Marshal's Mooncloth Headdress"] = "Saha Mareşalinin Seçkin Ay Kumaşı Baş Süsü" end
if E["Premier Field Marshal's Mooncloth Vestments"] == nil then E["Premier Field Marshal's Mooncloth Vestments"] = "Saha Mareşalinin Seçkin Ay Kumaşı Giysileri" end
if E["Premier Field Marshal's Plate Armor"] == nil then E["Premier Field Marshal's Plate Armor"] = "Saha Mareşalinin Seçkin Plaka Zırhı" end
if E["Premier Field Marshal's Plate Helm"] == nil then E["Premier Field Marshal's Plate Helm"] = "Saha Mareşalinin Seçkin Plaka Miğferi" end
if E["Premier Field Marshal's Scalemail Armor"] == nil then E["Premier Field Marshal's Scalemail Armor"] = "Saha Mareşalinin Seçkin Pul Örgü Zırhı" end
if E["Premier Field Marshal's Scalemail Helm"] == nil then E["Premier Field Marshal's Scalemail Helm"] = "Saha Mareşalinin Seçkin Pul Örgü Miğferi" end
if E["Premier Field Marshal's Silk Coronet"] == nil then E["Premier Field Marshal's Silk Coronet"] = "Saha Mareşalinin Seçkin İpek Küçük Tacı" end
if E["Premier Field Marshal's Silk Vestments"] == nil then E["Premier Field Marshal's Silk Vestments"] = "Saha Mareşalinin Seçkin İpek Giysileri" end
if E["Premier Field Marshal's Voidcloth Headdress"] == nil then E["Premier Field Marshal's Voidcloth Headdress"] = "Saha Mareşalinin Seçkin Boşluk Kumaşı Baş Süsü" end
if E["Premier Field Marshal's Voidcloth Vestments"] == nil then E["Premier Field Marshal's Voidcloth Vestments"] = "Saha Mareşalinin Seçkin Boşluk Kumaşı Giysileri" end
if E["Premier General's Chain Legguards"] == nil then E["Premier General's Chain Legguards"] = "Generalin Seçkin Zincir Bacak Korumaları" end
if E["Premier General's Chain Shoulders"] == nil then E["Premier General's Chain Shoulders"] = "Generalin Seçkin Zincir Omuzlukları" end
if E["Premier General's Dragonhide Epaulets"] == nil then E["Premier General's Dragonhide Epaulets"] = "Generalin Seçkin Ejder Derisi Apoletleri" end
if E["Premier General's Dragonhide Leggings"] == nil then E["Premier General's Dragonhide Leggings"] = "Generalin Seçkin Ejder Derisi Tozlukları" end
if E["Premier General's Felweave Mantle"] == nil then E["Premier General's Felweave Mantle"] = "Generalin Seçkin Fel Dokuması Omuz Örtüsü" end
if E["Premier General's Felweave Pants"] == nil then E["Premier General's Felweave Pants"] = "Generalin Seçkin Fel Dokuması Pantolonu" end
if E["Premier General's Kodohide Epaulets"] == nil then E["Premier General's Kodohide Epaulets"] = "Generalin Seçkin Kodo Derisi Apoletleri" end
if E["Premier General's Kodohide Leggings"] == nil then E["Premier General's Kodohide Leggings"] = "Generalin Seçkin Kodo Derisi Tozlukları" end
if E["Premier General's Lamellar Legplates"] == nil then E["Premier General's Lamellar Legplates"] = "Generalin Seçkin Lamel Bacak Plakaları" end
if E["Premier General's Lamellar Pauldrons"] == nil then E["Premier General's Lamellar Pauldrons"] = "Generalin Seçkin Lamel Omuz Zırhları" end
if E["Premier General's Linked Leggings"] == nil then E["Premier General's Linked Leggings"] = "Generalin Seçkin Halkalı Tozlukları" end
if E["Premier General's Linked Spaulders"] == nil then E["Premier General's Linked Spaulders"] = "Generalin Seçkin Halkalı Omuz Plakaları" end
if E["Premier General's Magus Amice"] == nil then E["Premier General's Magus Amice"] = "Generalin Seçkin Büyücü Omuz Atkısı" end
if E["Premier General's Magus Trousers"] == nil then E["Premier General's Magus Trousers"] = "Generalin Seçkin Büyücü Şalvarı" end
if E["Premier General's Mail Leggings"] == nil then E["Premier General's Mail Leggings"] = "Generalin Seçkin Örgü Tozlukları" end
if E["Premier General's Mail Spaulders"] == nil then E["Premier General's Mail Spaulders"] = "Generalin Seçkin Örgü Omuz Plakaları" end
if E["Premier General's Mortarplate Leggings"] == nil then E["Premier General's Mortarplate Leggings"] = "Generalin Seçkin Harç Plaka Tozlukları" end
if E["Premier General's Mortarplate Shoulders"] == nil then E["Premier General's Mortarplate Shoulders"] = "Generalin Seçkin Harç Plaka Omuzlukları" end
if E["Premier General's Ringmail Leggings"] == nil then E["Premier General's Ringmail Leggings"] = "Generalin Seçkin Halka Örgü Tozlukları" end
if E["Premier General's Ringmail Spaulders"] == nil then E["Premier General's Ringmail Spaulders"] = "Generalin Seçkin Halka Örgü Omuz Plakaları" end
if E["Premier General's Satin Leggings"] == nil then E["Premier General's Satin Leggings"] = "Generalin Seçkin Saten Tozlukları" end
if E["Premier General's Satin Mantle"] == nil then E["Premier General's Satin Mantle"] = "Generalin Seçkin Saten Omuz Örtüsü" end
if E["Premier General's Scaled Legplates"] == nil then E["Premier General's Scaled Legplates"] = "Generalin Seçkin Pullu Bacak Plakaları" end
if E["Premier General's Scaled Pauldrons"] == nil then E["Premier General's Scaled Pauldrons"] = "Generalin Seçkin Pullu Omuz Zırhları" end
if E["Premier General's Shadowhide Legguards"] == nil then E["Premier General's Shadowhide Legguards"] = "Generalin Seçkin Gölge Derisi Bacak Korumaları" end
if E["Premier General's Shadowhide Spaulders"] == nil then E["Premier General's Shadowhide Spaulders"] = "Generalin Seçkin Gölge Derisi Omuz Plakaları" end
if E["Premier General's Silken Leggings"] == nil then E["Premier General's Silken Leggings"] = "Generalin Seçkin İpek Tozlukları" end
if E["Premier General's Silken Mantle"] == nil then E["Premier General's Silken Mantle"] = "Generalin Seçkin İpek Omuz Örtüsü" end
if E["Premier General's Wyrmhide Epaulets"] == nil then E["Premier General's Wyrmhide Epaulets"] = "Generalin Seçkin Wyrm Derisi Apoletleri" end
if E["Premier General's Wyrmhide Leggings"] == nil then E["Premier General's Wyrmhide Leggings"] = "Generalin Seçkin Wyrm Derisi Tozlukları" end
if E["Premier Grand Marshal's Aegis"] == nil then E["Premier Grand Marshal's Aegis"] = "Büyük Mareşalin Seçkin Koruyucu Kalkanı" end
if E["Premier Grand Marshal's Barricade"] == nil then E["Premier Grand Marshal's Barricade"] = "Büyük Mareşalin Seçkin Barikatı" end
if E["Premier Grand Marshal's Battle Hammer"] == nil then E["Premier Grand Marshal's Battle Hammer"] = "Büyük Mareşalin Seçkin Muharebe Çekici" end
if E["Premier Grand Marshal's Bullseye"] == nil then E["Premier Grand Marshal's Bullseye"] = "Büyük Mareşalin Seçkin Tam İsabeti" end
if E["Premier Grand Marshal's Claymore"] == nil then E["Premier Grand Marshal's Claymore"] = "Büyük Mareşalin Seçkin Büyük Kılıcı" end
if E["Premier Grand Marshal's Demolisher"] == nil then E["Premier Grand Marshal's Demolisher"] = "Büyük Mareşalin Seçkin Yıkıcısı" end
if E["Premier Grand Marshal's Dirk"] == nil then E["Premier Grand Marshal's Dirk"] = "Büyük Mareşalin Seçkin Hançeri" end
if E["Premier Grand Marshal's Glaive"] == nil then E["Premier Grand Marshal's Glaive"] = "Büyük Mareşalin Seçkin Palası" end
if E["Premier Grand Marshal's Hand Cannon"] == nil then E["Premier Grand Marshal's Hand Cannon"] = "Büyük Mareşalin Seçkin El Topu" end
if E["Premier Grand Marshal's Handaxe"] == nil then E["Premier Grand Marshal's Handaxe"] = "Büyük Mareşalin Seçkin El Baltası" end
if E["Premier Grand Marshal's Left Hand Blade"] == nil then E["Premier Grand Marshal's Left Hand Blade"] = "Büyük Mareşalin Seçkin Sol El Bıçağı" end
if E["Premier Grand Marshal's Longsword"] == nil then E["Premier Grand Marshal's Longsword"] = "Büyük Mareşalin Seçkin Uzun Kılıcı" end
if E["Premier Grand Marshal's Mageblade"] == nil then E["Premier Grand Marshal's Mageblade"] = "Büyük Mareşalin Seçkin Büyücü Kılıcı" end
if E["Premier Grand Marshal's Punisher"] == nil then E["Premier Grand Marshal's Punisher"] = "Büyük Mareşalin Seçkin Cezalandırıcısı" end
if E["Premier Grand Marshal's Repeater"] == nil then E["Premier Grand Marshal's Repeater"] = "Büyük Mareşalin Seçkin Seri Arbaleti" end
if E["Premier Grand Marshal's Right Hand Blade"] == nil then E["Premier Grand Marshal's Right Hand Blade"] = "Büyük Mareşalin Seçkin Sağ El Bıçağı" end
if E["Premier Grand Marshal's Stave"] == nil then E["Premier Grand Marshal's Stave"] = "Büyük Mareşalin Seçkin Asası" end
if E["Premier Grand Marshal's Sunderer"] == nil then E["Premier Grand Marshal's Sunderer"] = "Büyük Mareşalin Seçkin Parçalayıcısı" end
if E["Premier Grand Marshal's Swiftblade"] == nil then E["Premier Grand Marshal's Swiftblade"] = "Büyük Mareşalin Seçkin Çevik Kılıcı" end
if E["Premier Grand Marshal's Tome of Power"] == nil then E["Premier Grand Marshal's Tome of Power"] = "Büyük Mareşalin Seçkin Güç Kitabı" end
if E["Premier Grand Marshal's Tome of Restoration"] == nil then E["Premier Grand Marshal's Tome of Restoration"] = "Büyük Mareşalin Seçkin Yenilenme Kitabı" end
if E["Premier Grand Marshal's Warhammer"] == nil then E["Premier Grand Marshal's Warhammer"] = "Büyük Mareşalin Seçkin Savaş Çekici" end
if E["Premier High Warlord's Barricade"] == nil then E["Premier High Warlord's Barricade"] = "Yüce Savaş Lordunun Seçkin Barikatı" end
if E["Premier High Warlord's Battle Axe"] == nil then E["Premier High Warlord's Battle Axe"] = "Yüce Savaş Lordunun Seçkin Savaş Baltası" end
if E["Premier High Warlord's Battle Mace"] == nil then E["Premier High Warlord's Battle Mace"] = "Yüce Savaş Lordunun Seçkin Savaş Gürzü" end
if E["Premier High Warlord's Blade"] == nil then E["Premier High Warlord's Blade"] = "Yüce Savaş Lordunun Seçkin Kılıcı" end
if E["Premier High Warlord's Bludgeon"] == nil then E["Premier High Warlord's Bludgeon"] = "Yüce Savaş Lordunun Seçkin Lobutu" end
if E["Premier High Warlord's Cleaver"] == nil then E["Premier High Warlord's Cleaver"] = "Yüce Savaş Lordunun Seçkin Satırı" end
if E["Premier High Warlord's Crossbow"] == nil then E["Premier High Warlord's Crossbow"] = "Yüce Savaş Lordunun Seçkin Arbaleti" end
if E["Premier High Warlord's Destroyer"] == nil then E["Premier High Warlord's Destroyer"] = "Yüce Savaş Lordunun Seçkin Yok Edicisi" end
if E["Premier High Warlord's Greatsword"] == nil then E["Premier High Warlord's Greatsword"] = "Yüce Savaş Lordunun Seçkin Koca Kılıcı" end
if E["Premier High Warlord's Left Claw"] == nil then E["Premier High Warlord's Left Claw"] = "Yüce Savaş Lordunun Seçkin Sol Pençesi" end
if E["Premier High Warlord's Pig Sticker"] == nil then E["Premier High Warlord's Pig Sticker"] = "Yüce Savaş Lordunun Seçkin Domuz Şişi" end
if E["Premier High Warlord's Pulverizer"] == nil then E["Premier High Warlord's Pulverizer"] = "Yüce Savaş Lordunun Seçkin Ufalayıcısı" end
if E["Premier High Warlord's Quickblade"] == nil then E["Premier High Warlord's Quickblade"] = "Yüce Savaş Lordunun Seçkin Hızlı Kılıcı" end
if E["Premier High Warlord's Razor"] == nil then E["Premier High Warlord's Razor"] = "Yüce Savaş Lordunun Seçkin Usturası" end
if E["Premier High Warlord's Recurve"] == nil then E["Premier High Warlord's Recurve"] = "Yüce Savaş Lordunun Seçkin Kavisli Yayı" end
if E["Premier High Warlord's Right Claw"] == nil then E["Premier High Warlord's Right Claw"] = "Yüce Savaş Lordunun Seçkin Sağ Pençesi" end
if E["Premier High Warlord's Shield Wall"] == nil then E["Premier High Warlord's Shield Wall"] = "Yüce Savaş Lordunun Seçkin Kalkan Duvarı" end
if E["Premier High Warlord's Spellblade"] == nil then E["Premier High Warlord's Spellblade"] = "Yüce Savaş Lordunun Seçkin Büyü Kılıcı" end
if E["Premier High Warlord's Street Sweeper"] == nil then E["Premier High Warlord's Street Sweeper"] = "Yüce Savaş Lordunun Seçkin Sokak Süpürgesi" end
if E["Premier High Warlord's Tome of Destruction"] == nil then E["Premier High Warlord's Tome of Destruction"] = "Yüce Savaş Lordunun Seçkin Yıkım Kitabı" end
if E["Premier High Warlord's Tome of Mending"] == nil then E["Premier High Warlord's Tome of Mending"] = "Yüce Savaş Lordunun Seçkin Onarım Kitabı" end
if E["Premier High Warlord's War Staff"] == nil then E["Premier High Warlord's War Staff"] = "Yüce Savaş Lordunun Seçkin Savaş Asası" end
if E["Premier Knight-Captain's Beasthide Bracers"] == nil then E["Premier Knight-Captain's Beasthide Bracers"] = "Şövalye Yüzbaşının Seçkin Hayvan Derisi Bileklikleri" end
if E["Premier Knight-Captain's Beasthide Waistguard"] == nil then E["Premier Knight-Captain's Beasthide Waistguard"] = "Şövalye Yüzbaşının Seçkin Hayvan Derisi Bel Koruması" end
if E["Premier Knight-Captain's Chainmail Bracers"] == nil then E["Premier Knight-Captain's Chainmail Bracers"] = "Şövalye Yüzbaşının Seçkin Zincir Örgü Bileklikleri" end
if E["Premier Knight-Captain's Chainmail Girdle"] == nil then E["Premier Knight-Captain's Chainmail Girdle"] = "Şövalye Yüzbaşının Seçkin Zincir Örgü Kuşağı" end
if E["Premier Knight-Captain's Chevalier Armguards"] == nil then E["Premier Knight-Captain's Chevalier Armguards"] = "Şövalye Yüzbaşının Seçkin Şövalye Kol Korumaları" end
if E["Premier Knight-Captain's Chevalier Belt"] == nil then E["Premier Knight-Captain's Chevalier Belt"] = "Şövalye Yüzbaşının Seçkin Şövalye Kemeri" end
if E["Premier Knight-Captain's Dreadweave Cuffs"] == nil then E["Premier Knight-Captain's Dreadweave Cuffs"] = "Şövalye Yüzbaşının Seçkin Dehşet Dokuması Kollukları" end
if E["Premier Knight-Captain's Dreadweave Sash"] == nil then E["Premier Knight-Captain's Dreadweave Sash"] = "Şövalye Yüzbaşının Seçkin Dehşet Dokuması Bel Bağı" end
if E["Premier Knight-Captain's Dreamhide Bracers"] == nil then E["Premier Knight-Captain's Dreamhide Bracers"] = "Şövalye Yüzbaşının Seçkin Rüya Derisi Bileklikleri" end
if E["Premier Knight-Captain's Dreamhide Waistguard"] == nil then E["Premier Knight-Captain's Dreamhide Waistguard"] = "Şövalye Yüzbaşının Seçkin Rüya Derisi Bel Koruması" end
if E["Premier Knight-Captain's Flatmail Bracers"] == nil then E["Premier Knight-Captain's Flatmail Bracers"] = "Şövalye Yüzbaşının Seçkin Yassı Örgü Bileklikleri" end
if E["Premier Knight-Captain's Flatmail Waistband"] == nil then E["Premier Knight-Captain's Flatmail Waistband"] = "Şövalye Yüzbaşının Seçkin Yassı Örgü Bel Bandı" end
if E["Premier Knight-Captain's Leather Armsplints"] == nil then E["Premier Knight-Captain's Leather Armsplints"] = "Şövalye Yüzbaşının Seçkin Deri Kol Atelleri" end
if E["Premier Knight-Captain's Leather Cinch"] == nil then E["Premier Knight-Captain's Leather Cinch"] = "Şövalye Yüzbaşının Seçkin Deri Kolanı" end
if E["Premier Knight-Captain's Linkmail Bracers"] == nil then E["Premier Knight-Captain's Linkmail Bracers"] = "Şövalye Yüzbaşının Seçkin Bağlantılı Örgü Bileklikleri" end
if E["Premier Knight-Captain's Linkmail Waistband"] == nil then E["Premier Knight-Captain's Linkmail Waistband"] = "Şövalye Yüzbaşının Seçkin Bağlantılı Örgü Bel Bandı" end
if E["Premier Knight-Captain's Luminous Armguards"] == nil then E["Premier Knight-Captain's Luminous Armguards"] = "Şövalye Yüzbaşının Seçkin Işıltılı Kol Korumaları" end
if E["Premier Knight-Captain's Luminous Belt"] == nil then E["Premier Knight-Captain's Luminous Belt"] = "Şövalye Yüzbaşının Seçkin Işıltılı Kemeri" end
if E["Premier Knight-Captain's Lunarhide Bracers"] == nil then E["Premier Knight-Captain's Lunarhide Bracers"] = "Şövalye Yüzbaşının Seçkin Ay Derisi Bileklikleri" end
if E["Premier Knight-Captain's Lunarhide Waistguard"] == nil then E["Premier Knight-Captain's Lunarhide Waistguard"] = "Şövalye Yüzbaşının Seçkin Ay Derisi Bel Koruması" end
if E["Premier Knight-Captain's Mooncloth Bracers"] == nil then E["Premier Knight-Captain's Mooncloth Bracers"] = "Şövalye Yüzbaşının Seçkin Ay Kumaşı Bileklikleri" end
if E["Premier Knight-Captain's Mooncloth Sash"] == nil then E["Premier Knight-Captain's Mooncloth Sash"] = "Şövalye Yüzbaşının Seçkin Ay Kumaşı Bel Bağı" end
if E["Premier Knight-Captain's Plate Bracers"] == nil then E["Premier Knight-Captain's Plate Bracers"] = "Şövalye Yüzbaşının Seçkin Plaka Bileklikleri" end
if E["Premier Knight-Captain's Plate Girdle"] == nil then E["Premier Knight-Captain's Plate Girdle"] = "Şövalye Yüzbaşının Seçkin Plaka Kuşağı" end
if E["Premier Knight-Captain's Scalemail Bracers"] == nil then E["Premier Knight-Captain's Scalemail Bracers"] = "Şövalye Yüzbaşının Seçkin Pul Örgü Bileklikleri" end
if E["Premier Knight-Captain's Scalemail Waistband"] == nil then E["Premier Knight-Captain's Scalemail Waistband"] = "Şövalye Yüzbaşının Seçkin Pul Örgü Bel Bandı" end
if E["Premier Knight-Captain's Silk Bracers"] == nil then E["Premier Knight-Captain's Silk Bracers"] = "Şövalye Yüzbaşının Seçkin İpek Bileklikleri" end
if E["Premier Knight-Captain's Silk Sash"] == nil then E["Premier Knight-Captain's Silk Sash"] = "Şövalye Yüzbaşının Seçkin İpek Bel Bağı" end
if E["Premier Knight-Captain's Voidcloth Bracers"] == nil then E["Premier Knight-Captain's Voidcloth Bracers"] = "Şövalye Yüzbaşının Seçkin Boşluk Kumaşı Bileklikleri" end
if E["Premier Knight-Captain's Voidcloth Sash"] == nil then E["Premier Knight-Captain's Voidcloth Sash"] = "Şövalye Yüzbaşının Seçkin Boşluk Kumaşı Bel Bağı" end
if E["Premier Knight-Champion's Beasthide Boots"] == nil then E["Premier Knight-Champion's Beasthide Boots"] = "Şövalye Şampiyonun Seçkin Hayvan Derisi Çizmeleri" end
if E["Premier Knight-Champion's Chainmail Boots"] == nil then E["Premier Knight-Champion's Chainmail Boots"] = "Şövalye Şampiyonun Seçkin Zincir Örgü Çizmeleri" end
if E["Premier Knight-Champion's Chevalier Boots"] == nil then E["Premier Knight-Champion's Chevalier Boots"] = "Şövalye Şampiyonun Seçkin Şövalye Çizmeleri" end
if E["Premier Knight-Champion's Dreadweave Boots"] == nil then E["Premier Knight-Champion's Dreadweave Boots"] = "Şövalye Şampiyonun Seçkin Dehşet Dokuması Çizmeleri" end
if E["Premier Knight-Champion's Dreamhide Boots"] == nil then E["Premier Knight-Champion's Dreamhide Boots"] = "Şövalye Şampiyonun Seçkin Rüya Derisi Çizmeleri" end
if E["Premier Knight-Champion's Flatmail Boots"] == nil then E["Premier Knight-Champion's Flatmail Boots"] = "Şövalye Şampiyonun Seçkin Yassı Örgü Çizmeleri" end
if E["Premier Knight-Champion's Leather Footguards"] == nil then E["Premier Knight-Champion's Leather Footguards"] = "Şövalye Şampiyonun Seçkin Deri Ayak Korumaları" end
if E["Premier Knight-Champion's Linkmail Boots"] == nil then E["Premier Knight-Champion's Linkmail Boots"] = "Şövalye Şampiyonun Seçkin Bağlantılı Örgü Çizmeleri" end
if E["Premier Knight-Champion's Luminous Boots"] == nil then E["Premier Knight-Champion's Luminous Boots"] = "Şövalye Şampiyonun Seçkin Işıltılı Çizmeleri" end
if E["Premier Knight-Champion's Lunarhide Boots"] == nil then E["Premier Knight-Champion's Lunarhide Boots"] = "Şövalye Şampiyonun Seçkin Ay Derisi Çizmeleri" end
if E["Premier Knight-Champion's Mooncloth Sandals"] == nil then E["Premier Knight-Champion's Mooncloth Sandals"] = "Şövalye Şampiyonun Seçkin Ay Kumaşı Sandaletleri" end
if E["Premier Knight-Champion's Plate Boots"] == nil then E["Premier Knight-Champion's Plate Boots"] = "Şövalye Şampiyonun Seçkin Plaka Çizmeleri" end
if E["Premier Knight-Champion's Scalemail Boots"] == nil then E["Premier Knight-Champion's Scalemail Boots"] = "Şövalye Şampiyonun Seçkin Pul Örgü Çizmeleri" end
if E["Premier Knight-Champion's Silk Footwraps"] == nil then E["Premier Knight-Champion's Silk Footwraps"] = "Şövalye Şampiyonun Seçkin İpek Ayak Sargıları" end
if E["Premier Knight-Champion's Voidcloth Sandals"] == nil then E["Premier Knight-Champion's Voidcloth Sandals"] = "Şövalye Şampiyonun Seçkin Boşluk Kumaşı Sandaletleri" end
if E["Premier Legionnaire's Chain Girdle"] == nil then E["Premier Legionnaire's Chain Girdle"] = "Lejyonerin Seçkin Zincir Kuşağı" end
if E["Premier Legionnaire's Chain Wristguards"] == nil then E["Premier Legionnaire's Chain Wristguards"] = "Lejyonerin Seçkin Zincir Bilek Korumaları" end
if E["Premier Legionnaire's Dragonhide Belt"] == nil then E["Premier Legionnaire's Dragonhide Belt"] = "Lejyonerin Seçkin Ejder Derisi Kemeri" end
if E["Premier Legionnaire's Dragonhide Bracers"] == nil then E["Premier Legionnaire's Dragonhide Bracers"] = "Lejyonerin Seçkin Ejder Derisi Bileklikleri" end
if E["Premier Legionnaire's Felweave Belt"] == nil then E["Premier Legionnaire's Felweave Belt"] = "Lejyonerin Seçkin Fel Dokuması Kemeri" end
if E["Premier Legionnaire's Felweave Bracers"] == nil then E["Premier Legionnaire's Felweave Bracers"] = "Lejyonerin Seçkin Fel Dokuması Bileklikleri" end
if E["Premier Legionnaire's Kodohide Belt"] == nil then E["Premier Legionnaire's Kodohide Belt"] = "Lejyonerin Seçkin Kodo Derisi Kemeri" end
if E["Premier Legionnaire's Kodohide Bracers"] == nil then E["Premier Legionnaire's Kodohide Bracers"] = "Lejyonerin Seçkin Kodo Derisi Bileklikleri" end
if E["Premier Legionnaire's Lamellar Armguards"] == nil then E["Premier Legionnaire's Lamellar Armguards"] = "Lejyonerin Seçkin Lamel Kol Korumaları" end
if E["Premier Legionnaire's Lamellar Belt"] == nil then E["Premier Legionnaire's Lamellar Belt"] = "Lejyonerin Seçkin Lamel Kemeri" end
if E["Premier Legionnaire's Linked Bracers"] == nil then E["Premier Legionnaire's Linked Bracers"] = "Lejyonerin Seçkin Halkalı Bileklikleri" end
if E["Premier Legionnaire's Linked Waistband"] == nil then E["Premier Legionnaire's Linked Waistband"] = "Lejyonerin Seçkin Halkalı Bel Bandı" end
if E["Premier Legionnaire's Magus Cuffs"] == nil then E["Premier Legionnaire's Magus Cuffs"] = "Lejyonerin Seçkin Büyücü Kollukları" end
if E["Premier Legionnaire's Magus Sash"] == nil then E["Premier Legionnaire's Magus Sash"] = "Lejyonerin Seçkin Büyücü Bel Bağı" end
if E["Premier Legionnaire's Mail Bracers"] == nil then E["Premier Legionnaire's Mail Bracers"] = "Lejyonerin Seçkin Örgü Bileklikleri" end
if E["Premier Legionnaire's Mail Waistband"] == nil then E["Premier Legionnaire's Mail Waistband"] = "Lejyonerin Seçkin Örgü Bel Bandı" end
if E["Premier Legionnaire's Mortarplate Armguards"] == nil then E["Premier Legionnaire's Mortarplate Armguards"] = "Lejyonerin Seçkin Harç Plaka Kol Korumaları" end
if E["Premier Legionnaire's Mortarplate Girdle"] == nil then E["Premier Legionnaire's Mortarplate Girdle"] = "Lejyonerin Seçkin Harç Plaka Kuşağı" end
if E["Premier Legionnaire's Ringmail Bracers"] == nil then E["Premier Legionnaire's Ringmail Bracers"] = "Lejyonerin Seçkin Halka Örgü Bileklikleri" end
if E["Premier Legionnaire's Ringmail Waistband"] == nil then E["Premier Legionnaire's Ringmail Waistband"] = "Lejyonerin Seçkin Halka Örgü Bel Bandı" end
if E["Premier Legionnaire's Satin Bracers"] == nil then E["Premier Legionnaire's Satin Bracers"] = "Lejyonerin Seçkin Saten Bileklikleri" end
if E["Premier Legionnaire's Satin Cinch"] == nil then E["Premier Legionnaire's Satin Cinch"] = "Lejyonerin Seçkin Saten Kolanı" end
if E["Premier Legionnaire's Scaled Armguards"] == nil then E["Premier Legionnaire's Scaled Armguards"] = "Lejyonerin Seçkin Pullu Kol Korumaları" end
if E["Premier Legionnaire's Scaled Belt"] == nil then E["Premier Legionnaire's Scaled Belt"] = "Lejyonerin Seçkin Pullu Kemeri" end
if E["Premier Legionnaire's Shadowhide Armsplints"] == nil then E["Premier Legionnaire's Shadowhide Armsplints"] = "Lejyonerin Seçkin Gölge Derisi Kol Atelleri" end
if E["Premier Legionnaire's Shadowhide Girdle"] == nil then E["Premier Legionnaire's Shadowhide Girdle"] = "Lejyonerin Seçkin Gölge Derisi Kuşağı" end
if E["Premier Legionnaire's Silken Bracers"] == nil then E["Premier Legionnaire's Silken Bracers"] = "Lejyonerin Seçkin İpek Bileklikleri" end
if E["Premier Legionnaire's Silken Cinch"] == nil then E["Premier Legionnaire's Silken Cinch"] = "Lejyonerin Seçkin İpek Kolanı" end
if E["Premier Legionnaire's Wyrmhide Belt"] == nil then E["Premier Legionnaire's Wyrmhide Belt"] = "Lejyonerin Seçkin Wyrm Derisi Kemeri" end
if E["Premier Legionnaire's Wyrmhide Bracers"] == nil then E["Premier Legionnaire's Wyrmhide Bracers"] = "Lejyonerin Seçkin Wyrm Derisi Bileklikleri" end
if E["Premier Lieutenant Commander's Beasthide Gauntlets"] == nil then E["Premier Lieutenant Commander's Beasthide Gauntlets"] = "Yarbayın Seçkin Hayvan Derisi Zırhlı Eldivenleri" end
if E["Premier Lieutenant Commander's Chainmail Grips"] == nil then E["Premier Lieutenant Commander's Chainmail Grips"] = "Yarbayın Seçkin Zincir Örgü Kavrayıcıları" end
if E["Premier Lieutenant Commander's Chevalier Gloves"] == nil then E["Premier Lieutenant Commander's Chevalier Gloves"] = "Yarbayın Seçkin Şövalye Eldivenleri" end
if E["Premier Lieutenant Commander's Dreadweave Gloves"] == nil then E["Premier Lieutenant Commander's Dreadweave Gloves"] = "Yarbayın Seçkin Dehşet Dokuması Eldivenleri" end
if E["Premier Lieutenant Commander's Dreamhide Gauntlets"] == nil then E["Premier Lieutenant Commander's Dreamhide Gauntlets"] = "Yarbayın Seçkin Rüya Derisi Zırhlı Eldivenleri" end
if E["Premier Lieutenant Commander's Flatmail Gauntlets"] == nil then E["Premier Lieutenant Commander's Flatmail Gauntlets"] = "Yarbayın Seçkin Yassı Örgü Zırhlı Eldivenleri" end
if E["Premier Lieutenant Commander's Leather Handgrips"] == nil then E["Premier Lieutenant Commander's Leather Handgrips"] = "Yarbayın Seçkin Deri El Kavrayıcıları" end
if E["Premier Lieutenant Commander's Linkmail Gauntlets"] == nil then E["Premier Lieutenant Commander's Linkmail Gauntlets"] = "Yarbayın Seçkin Bağlantılı Örgü Zırhlı Eldivenleri" end
if E["Premier Lieutenant Commander's Luminous Gloves"] == nil then E["Premier Lieutenant Commander's Luminous Gloves"] = "Yarbayın Seçkin Işıltılı Eldivenleri" end
if E["Premier Lieutenant Commander's Lunarhide Gauntlets"] == nil then E["Premier Lieutenant Commander's Lunarhide Gauntlets"] = "Yarbayın Seçkin Ay Derisi Zırhlı Eldivenleri" end
if E["Premier Lieutenant Commander's Mooncloth Gloves"] == nil then E["Premier Lieutenant Commander's Mooncloth Gloves"] = "Yarbayın Seçkin Ay Kumaşı Eldivenleri" end
if E["Premier Lieutenant Commander's Plate Gauntlets"] == nil then E["Premier Lieutenant Commander's Plate Gauntlets"] = "Yarbayın Seçkin Plaka Zırhlı Eldivenleri" end
if E["Premier Lieutenant Commander's Scalemail Gauntlets"] == nil then E["Premier Lieutenant Commander's Scalemail Gauntlets"] = "Yarbayın Seçkin Pul Örgü Zırhlı Eldivenleri" end
if E["Premier Lieutenant Commander's Silk Gloves"] == nil then E["Premier Lieutenant Commander's Silk Gloves"] = "Yarbayın Seçkin İpek Eldivenleri" end
if E["Premier Lieutenant Commander's Voidcloth Gloves"] == nil then E["Premier Lieutenant Commander's Voidcloth Gloves"] = "Yarbayın Seçkin Boşluk Kumaşı Eldivenleri" end
if E["Premier Marshal's Beasthide Legguards"] == nil then E["Premier Marshal's Beasthide Legguards"] = "Mareşalin Seçkin Hayvan Derisi Bacak Korumaları" end
if E["Premier Marshal's Beasthide Spaulders"] == nil then E["Premier Marshal's Beasthide Spaulders"] = "Mareşalin Seçkin Hayvan Derisi Omuz Plakaları" end
if E["Premier Marshal's Chainmail Legguards"] == nil then E["Premier Marshal's Chainmail Legguards"] = "Mareşalin Seçkin Zincir Örgü Bacak Korumaları" end
if E["Premier Marshal's Chainmail Spaulders"] == nil then E["Premier Marshal's Chainmail Spaulders"] = "Mareşalin Seçkin Zincir Örgü Omuz Plakaları" end
if E["Premier Marshal's Chevalier Legplates"] == nil then E["Premier Marshal's Chevalier Legplates"] = "Mareşalin Seçkin Şövalye Bacak Plakaları" end
if E["Premier Marshal's Chevalier Pauldrons"] == nil then E["Premier Marshal's Chevalier Pauldrons"] = "Mareşalin Seçkin Şövalye Omuz Zırhları" end
if E["Premier Marshal's Dreadweave Leggings"] == nil then E["Premier Marshal's Dreadweave Leggings"] = "Mareşalin Seçkin Dehşet Dokuması Tozlukları" end
if E["Premier Marshal's Dreadweave Shoulders"] == nil then E["Premier Marshal's Dreadweave Shoulders"] = "Mareşalin Seçkin Dehşet Dokuması Omuzlukları" end
if E["Premier Marshal's Dreamhide Legguards"] == nil then E["Premier Marshal's Dreamhide Legguards"] = "Mareşalin Seçkin Rüya Derisi Bacak Korumaları" end
if E["Premier Marshal's Dreamhide Spaulders"] == nil then E["Premier Marshal's Dreamhide Spaulders"] = "Mareşalin Seçkin Rüya Derisi Omuz Plakaları" end
if E["Premier Marshal's Flatmail Leggings"] == nil then E["Premier Marshal's Flatmail Leggings"] = "Mareşalin Seçkin Yassı Örgü Tozlukları" end
if E["Premier Marshal's Flatmail Spaulders"] == nil then E["Premier Marshal's Flatmail Spaulders"] = "Mareşalin Seçkin Yassı Örgü Omuz Plakaları" end
if E["Premier Marshal's Leather Epaulets"] == nil then E["Premier Marshal's Leather Epaulets"] = "Mareşalin Seçkin Deri Apoletleri" end
if E["Premier Marshal's Leather Leggings"] == nil then E["Premier Marshal's Leather Leggings"] = "Mareşalin Seçkin Deri Tozlukları" end
if E["Premier Marshal's Linkmail Leggings"] == nil then E["Premier Marshal's Linkmail Leggings"] = "Mareşalin Seçkin Bağlantılı Örgü Tozlukları" end
if E["Premier Marshal's Linkmail Spaulders"] == nil then E["Premier Marshal's Linkmail Spaulders"] = "Mareşalin Seçkin Bağlantılı Örgü Omuz Plakaları" end
if E["Premier Marshal's Luminous Legplates"] == nil then E["Premier Marshal's Luminous Legplates"] = "Mareşalin Seçkin Işıltılı Bacak Plakaları" end
if E["Premier Marshal's Luminous Pauldrons"] == nil then E["Premier Marshal's Luminous Pauldrons"] = "Mareşalin Seçkin Işıltılı Omuz Zırhları" end
if E["Premier Marshal's Lunarhide Legguards"] == nil then E["Premier Marshal's Lunarhide Legguards"] = "Mareşalin Seçkin Ay Derisi Bacak Korumaları" end
if E["Premier Marshal's Lunarhide Spaulders"] == nil then E["Premier Marshal's Lunarhide Spaulders"] = "Mareşalin Seçkin Ay Derisi Omuz Plakaları" end
if E["Premier Marshal's Mooncloth Mantle"] == nil then E["Premier Marshal's Mooncloth Mantle"] = "Mareşalin Seçkin Ay Kumaşı Omuz Örtüsü" end
if E["Premier Marshal's Mooncloth Pants"] == nil then E["Premier Marshal's Mooncloth Pants"] = "Mareşalin Seçkin Ay Kumaşı Pantolonu" end
if E["Premier Marshal's Plate Legguards"] == nil then E["Premier Marshal's Plate Legguards"] = "Mareşalin Seçkin Plaka Bacak Korumaları" end
if E["Premier Marshal's Plate Shoulderguards"] == nil then E["Premier Marshal's Plate Shoulderguards"] = "Mareşalin Seçkin Plaka Omuz Korumaları" end
if E["Premier Marshal's Scalemail Leggings"] == nil then E["Premier Marshal's Scalemail Leggings"] = "Mareşalin Seçkin Pul Örgü Tozlukları" end
if E["Premier Marshal's Scalemail Spaulders"] == nil then E["Premier Marshal's Scalemail Spaulders"] = "Mareşalin Seçkin Pul Örgü Omuz Plakaları" end
if E["Premier Marshal's Silk Leggings"] == nil then E["Premier Marshal's Silk Leggings"] = "Mareşalin Seçkin İpek Tozlukları" end
if E["Premier Marshal's Silk Spaulders"] == nil then E["Premier Marshal's Silk Spaulders"] = "Mareşalin Seçkin İpek Omuz Plakaları" end
if E["Premier Marshal's Voidcloth Mantle"] == nil then E["Premier Marshal's Voidcloth Mantle"] = "Mareşalin Seçkin Boşluk Kumaşı Omuz Örtüsü" end
if E["Premier Marshal's Voidcloth Pants"] == nil then E["Premier Marshal's Voidcloth Pants"] = "Mareşalin Seçkin Boşluk Kumaşı Pantolonu" end
if E["Premier Master Sergeant's Insignia"] == nil then E["Premier Master Sergeant's Insignia"] = "Başçavuşun Seçkin Nişanı" end
if E["Premier Senior Sergeant's Insignia"] == nil then E["Premier Senior Sergeant's Insignia"] = "Kıdemli Çavuşun Seçkin Nişanı" end
if E["Premier Sergeant's Cape"] == nil then E["Premier Sergeant's Cape"] = "Çavuşun Seçkin Kepeneği" end
if E["Premier Sergeant's Cloak"] == nil then E["Premier Sergeant's Cloak"] = "Çavuşun Seçkin Pelerini" end
if E["Premier Warlord's Chain Chestpiece"] == nil then E["Premier Warlord's Chain Chestpiece"] = "Savaş Lordunun Seçkin Zincir Göğüs Zırhı" end
if E["Premier Warlord's Chain Helmet"] == nil then E["Premier Warlord's Chain Helmet"] = "Savaş Lordunun Seçkin Zincir Kaskı" end
if E["Premier Warlord's Dragonhide Hauberk"] == nil then E["Premier Warlord's Dragonhide Hauberk"] = "Savaş Lordunun Seçkin Ejder Derisi Halka Zırhı" end
if E["Premier Warlord's Dragonhide Helmet"] == nil then E["Premier Warlord's Dragonhide Helmet"] = "Savaş Lordunun Seçkin Ejder Derisi Kaskı" end
if E["Premier Warlord's Felweave Hood"] == nil then E["Premier Warlord's Felweave Hood"] = "Savaş Lordunun Seçkin Fel Dokuması Başlığı" end
if E["Premier Warlord's Felweave Robe"] == nil then E["Premier Warlord's Felweave Robe"] = "Savaş Lordunun Seçkin Fel Dokuması Cüppesi" end
if E["Premier Warlord's Kodohide Hauberk"] == nil then E["Premier Warlord's Kodohide Hauberk"] = "Savaş Lordunun Seçkin Kodo Derisi Halka Zırhı" end
if E["Premier Warlord's Kodohide Helmet"] == nil then E["Premier Warlord's Kodohide Helmet"] = "Savaş Lordunun Seçkin Kodo Derisi Kaskı" end
if E["Premier Warlord's Lamellar Chestplate"] == nil then E["Premier Warlord's Lamellar Chestplate"] = "Savaş Lordunun Seçkin Lamel Göğüs Plakası" end
if E["Premier Warlord's Lamellar Faceguard"] == nil then E["Premier Warlord's Lamellar Faceguard"] = "Savaş Lordunun Seçkin Lamel Yüz Koruması" end
if E["Premier Warlord's Linked Armor"] == nil then E["Premier Warlord's Linked Armor"] = "Savaş Lordunun Seçkin Halkalı Zırhı" end
if E["Premier Warlord's Linked Helm"] == nil then E["Premier Warlord's Linked Helm"] = "Savaş Lordunun Seçkin Halkalı Miğferi" end
if E["Premier Warlord's Magus Cowl"] == nil then E["Premier Warlord's Magus Cowl"] = "Savaş Lordunun Seçkin Büyücü Kukuletası" end
if E["Premier Warlord's Magus Raiment"] == nil then E["Premier Warlord's Magus Raiment"] = "Savaş Lordunun Seçkin Büyücü Giysisi" end
if E["Premier Warlord's Mail Armor"] == nil then E["Premier Warlord's Mail Armor"] = "Savaş Lordunun Seçkin Örgü Zırhı" end
if E["Premier Warlord's Mail Helm"] == nil then E["Premier Warlord's Mail Helm"] = "Savaş Lordunun Seçkin Örgü Miğferi" end
if E["Premier Warlord's Mortarplate Armor"] == nil then E["Premier Warlord's Mortarplate Armor"] = "Savaş Lordunun Seçkin Harç Plaka Zırhı" end
if E["Premier Warlord's Mortarplate Headpiece"] == nil then E["Premier Warlord's Mortarplate Headpiece"] = "Savaş Lordunun Seçkin Harç Plaka Baş Zırhı" end
if E["Premier Warlord's Ringmail Armor"] == nil then E["Premier Warlord's Ringmail Armor"] = "Savaş Lordunun Seçkin Halka Örgü Zırhı" end
if E["Premier Warlord's Ringmail Helm"] == nil then E["Premier Warlord's Ringmail Helm"] = "Savaş Lordunun Seçkin Halka Örgü Miğferi" end
if E["Premier Warlord's Satin Cowl"] == nil then E["Premier Warlord's Satin Cowl"] = "Savaş Lordunun Seçkin Saten Kukuletası" end
if E["Premier Warlord's Satin Robes"] == nil then E["Premier Warlord's Satin Robes"] = "Savaş Lordunun Seçkin Saten Cüppesi" end
if E["Premier Warlord's Scaled Chestplate"] == nil then E["Premier Warlord's Scaled Chestplate"] = "Savaş Lordunun Seçkin Pullu Göğüs Plakası" end
if E["Premier Warlord's Scaled Faceguard"] == nil then E["Premier Warlord's Scaled Faceguard"] = "Savaş Lordunun Seçkin Pullu Yüz Koruması" end
if E["Premier Warlord's Shadowhide Breastplate"] == nil then E["Premier Warlord's Shadowhide Breastplate"] = "Savaş Lordunun Seçkin Gölge Derisi Göğüslüğü" end
if E["Premier Warlord's Shadowhide Helm"] == nil then E["Premier Warlord's Shadowhide Helm"] = "Savaş Lordunun Seçkin Gölge Derisi Miğferi" end
if E["Premier Warlord's Silken Cowl"] == nil then E["Premier Warlord's Silken Cowl"] = "Savaş Lordunun Seçkin İpek Kukuletası" end
if E["Premier Warlord's Silken Robes"] == nil then E["Premier Warlord's Silken Robes"] = "Savaş Lordunun Seçkin İpek Cüppesi" end
if E["Premier Warlord's Wyrmhide Hauberk"] == nil then E["Premier Warlord's Wyrmhide Hauberk"] = "Savaş Lordunun Seçkin Wyrm Derisi Halka Zırhı" end
if E["Premier Warlord's Wyrmhide Helmet"] == nil then E["Premier Warlord's Wyrmhide Helmet"] = "Savaş Lordunun Seçkin Wyrm Derisi Kaskı" end
if E["Prince Magni Bronzebeard's Silver Coin"] == nil then E["Prince Magni Bronzebeard's Silver Coin"] = "Prens Magni Bronzebeard'ın Gümüş Sikkesi" end
if E["Pristine Fel-Slime Crystal"] == nil then E["Pristine Fel-Slime Crystal"] = "Kusursuz Fel-Balçık Kristali" end
if E["Prophet's Waistcord"] == nil then E["Prophet's Waistcord"] = "Peygamberin Bel İpi" end
if E["Prospector's Signet"] == nil then E["Prospector's Signet"] = "Maden Arayıcısının Mühür Yüzüğü" end
if E["Protector's Armguards"] == nil then E["Protector's Armguards"] = "Koruyucunun Kol Korumaları" end
if E["Protector's Boots"] == nil then E["Protector's Boots"] = "Koruyucunun Çizmeleri" end
if E["Protector's Chain Belt"] == nil then E["Protector's Chain Belt"] = "Koruyucunun Zincir Kemeri" end
if E["Protector's Chain Helm"] == nil then E["Protector's Chain Helm"] = "Koruyucunun Zincir Miğferi" end
if E["Protector's Chain Leggings"] == nil then E["Protector's Chain Leggings"] = "Koruyucunun Zincir Tozlukları" end
if E["Protector's Chain Shirt"] == nil then E["Protector's Chain Shirt"] = "Koruyucunun Zincir Gömleği" end
if E["Protector's Gloves"] == nil then E["Protector's Gloves"] = "Koruyucunun Eldivenleri" end
if E["Protector's Silvered Chain Helm"] == nil then E["Protector's Silvered Chain Helm"] = "Koruyucunun Gümüşlü Zincir Miğferi" end
if E["Protector's Silvered Chain Leggings"] == nil then E["Protector's Silvered Chain Leggings"] = "Koruyucunun Gümüşlü Zincir Tozlukları" end
if E["Protector's Silvered Chain Shirt"] == nil then E["Protector's Silvered Chain Shirt"] = "Koruyucunun Gümüşlü Zincir Gömleği" end
if E["Proud Brave's Guard"] == nil then E["Proud Brave's Guard"] = "Gururlu Yiğidin Koruması" end
if E["Prowler's Leather Belt"] == nil then E["Prowler's Leather Belt"] = "Pusucunun Deri Kemeri" end
if E["Prowler's Leather Boots"] == nil then E["Prowler's Leather Boots"] = "Pusucunun Deri Çizmeleri" end
if E["Prowler's Leather Bracers"] == nil then E["Prowler's Leather Bracers"] = "Pusucunun Deri Bileklikleri" end
if E["Prowler's Leather Gauntlets"] == nil then E["Prowler's Leather Gauntlets"] = "Pusucunun Deri Zırhlı Eldivenleri" end
if E["Prowler's Leather Gloves"] == nil then E["Prowler's Leather Gloves"] = "Pusucunun Deri Eldivenleri" end
if E["Prowler's Leather Shoes"] == nil then E["Prowler's Leather Shoes"] = "Pusucunun Deri Ayakkabıları" end
if E["Prowler's Leather Shoulder"] == nil then E["Prowler's Leather Shoulder"] = "Pusucunun Deri Omuzluğu" end
if E["Prowler's Leather Waistguard"] == nil then E["Prowler's Leather Waistguard"] = "Pusucunun Deri Bel Koruması" end
if E["Puk's Friendship Bracelet"] == nil then E["Puk's Friendship Bracelet"] = "Puk'un Dostluk Bileziği" end
if E["Punchy's Punchers"] == nil then E["Punchy's Punchers"] = "Punchy'nin Yumrukları" end
if E["Pyrewood Blacksmith's Hammer"] == nil then E["Pyrewood Blacksmith's Hammer"] = "Pyrewood Demircisinin Çekici" end
if E["QAEnchant Shield - Law of Nature"] == nil then E["QAEnchant Shield - Law of Nature"] = "QAEnchant Kalkan - Doğa Kanunu" end
if E["Queen Guard's Royal Seal"] == nil then E["Queen Guard's Royal Seal"] = "Kraliçe Muhafızının Kraliyet Mührü" end
if E["Quickblade's Dagger"] == nil then E["Quickblade's Dagger"] = "Quickblade'in Hançeri" end
if E["Quinn's Potion"] == nil then E["Quinn's Potion"] = "Quinn'in İksiri" end
if E["Raani's Lucky Feather"] == nil then E["Raani's Lucky Feather"] = "Raani'nin Uğurlu Tüyü" end
if E["Rabbit Crate (Artic)"] == nil then E["Rabbit Crate (Artic)"] = "Tavşan Kafesi (Kutup)" end
if E["Rabbit Crate (Brown)"] == nil then E["Rabbit Crate (Brown)"] = "Tavşan Kafesi (Kahverengi)" end
if E["Rabbit's Foot"] == nil then E["Rabbit's Foot"] = "Tavşan Ayağı" end
if E["Rageroar's Best Club"] == nil then E["Rageroar's Best Club"] = "Rageroar'un En İyi Sopası" end
if E["Ragnar's Favorite Hat"] == nil then E["Ragnar's Favorite Hat"] = "Ragnar'ın Favori Şapkası" end
if E["Raider's Battleaxe"] == nil then E["Raider's Battleaxe"] = "Akıncının Savaş Baltası" end
if E["Raider's Bow"] == nil then E["Raider's Bow"] = "Akıncının Yayı" end
if E["Rain-spotted Cape"] == nil then E["Rain-spotted Cape"] = "Yağmur Lekeli Kepenek" end
if E["Rancher's Trousers"] == nil then E["Rancher's Trousers"] = "Çiftçinin Şalvarı" end
if E["Ranger's Belt"] == nil then E["Ranger's Belt"] = "Korucunun Kemeri" end
if E["Ranger-Apprentice Cape"] == nil then E["Ranger-Apprentice Cape"] = "Korucu Çırağı Kepeneği" end
if E["Raptor's Gaze"] == nil then E["Raptor's Gaze"] = "Raptorun Bakışı" end
if E["Rath'mael's Copper Coin"] == nil then E["Rath'mael's Copper Coin"] = "Rath'mael'in Bakır Sikkesi" end
if E["Razor-sharp Beak"] == nil then E["Razor-sharp Beak"] = "Ustura Keskinliğinde Gaga" end
if E["Razzeric's Customized Seatbelt"] == nil then E["Razzeric's Customized Seatbelt"] = "Razzeric'in Özel Emniyet Kemeri" end
if E["Razzeric's Racing Grips"] == nil then E["Razzeric's Racing Grips"] = "Razzeric'in Yarış Kavrayıcıları" end
if E["Reanimator's Amulet"] == nil then E["Reanimator's Amulet"] = "Diriltenin Muskası" end
if E["Reaver's Repeater"] == nil then E["Reaver's Repeater"] = "Yağmacının Seri Tüfeği" end
if E["Rebels' Rugged Reaper"] == nil then E["Rebels' Rugged Reaper"] = "Asilerin Sağlam Tırpanı" end
if E["Recipe: Barbecued Buzzard Wing"] == nil then E["Recipe: Barbecued Buzzard Wing"] = "Tarif: Mangalda Akbaba Kanadı" end
if E["Recipe: Bat Hachee"] == nil then E["Recipe: Bat Hachee"] = "Tarif: Yarasa Haşesi" end
if E["Recipe: Bear Brisket"] == nil then E["Recipe: Bear Brisket"] = "Tarif: Ayı Döşü" end
if E["Recipe: Bear Bruscitti"] == nil then E["Recipe: Bear Bruscitti"] = "Tarif: Ayı Bruscitti" end
if E["Recipe: Beer Basted Boar Ribs"] == nil then E["Recipe: Beer Basted Boar Ribs"] = "Tarif: Biralı Yaban Domuzu Kaburgası" end
if E["Recipe: Breakfast Omelette"] == nil then E["Recipe: Breakfast Omelette"] = "Tarif: Kahvaltı Omleti" end
if E["Recipe: Briny Seafood Stew"] == nil then E["Recipe: Briny Seafood Stew"] = "Tarif: Tuzlu Deniz Ürünleri Yahnisi" end
if E["Recipe: Calcified Smoothie"] == nil then E["Recipe: Calcified Smoothie"] = "Tarif: Kireçlenmiş Smoothie" end
if E["Recipe: Caustic Smog Potion"] == nil then E["Recipe: Caustic Smog Potion"] = "Tarif: Yakıcı Duman İksiri" end
if E["Recipe: Clam Linguine"] == nil then E["Recipe: Clam Linguine"] = "Tarif: Midyeli Linguine" end
if E["Recipe: Cleric's Elixir"] == nil then E["Recipe: Cleric's Elixir"] = "Tarif: Rahibin İksiri" end
if E["Recipe: Discolored Healing Potion"] == nil then E["Recipe: Discolored Healing Potion"] = "Tarif: Rengi Solmuş Şifa İksiri" end
if E["Recipe: Disorienting Smog Potion"] == nil then E["Recipe: Disorienting Smog Potion"] = "Tarif: Sersemletici Duman İksiri" end
if E["Recipe: Distilled Firewater"] == nil then E["Recipe: Distilled Firewater"] = "Tarif: Damıtılmış Ateşsuyu" end
if E["Recipe: Dragonfire Potion"] == nil then E["Recipe: Dragonfire Potion"] = "Tarif: Ejderha Ateşi İksiri" end
if E["Recipe: Draught of Predatory Senses"] == nil then E["Recipe: Draught of Predatory Senses"] = "Tarif: Yırtıcı Duyular Şerbeti" end
if E["Recipe: Elixir of Cunning"] == nil then E["Recipe: Elixir of Cunning"] = "Tarif: Kurnazlık İksiri" end
if E["Recipe: Elixir of Ferocity"] == nil then E["Recipe: Elixir of Ferocity"] = "Tarif: Vahşet İksiri" end
if E["Recipe: Elixir of Greater Fortitude"] == nil then E["Recipe: Elixir of Greater Fortitude"] = "Tarif: Büyük Dayanıklılık İksiri" end
if E["Recipe: Elixir of Greater Spirit"] == nil then E["Recipe: Elixir of Greater Spirit"] = "Tarif: Büyük Ruh İksiri" end
if E["Recipe: Elixir of Intellect"] == nil then E["Recipe: Elixir of Intellect"] = "Tarif: Zekâ İksiri" end
if E["Recipe: Elixir of Lesser Intellect"] == nil then E["Recipe: Elixir of Lesser Intellect"] = "Tarif: Hafif Zekâ İksiri" end
if E["Recipe: Elixir of Lesser Spirit"] == nil then E["Recipe: Elixir of Lesser Spirit"] = "Tarif: Hafif Ruh İksiri" end
if E["Recipe: Elixir of Minor Spirit"] == nil then E["Recipe: Elixir of Minor Spirit"] = "Tarif: Küçük Ruh İksiri" end
if E["Recipe: Elixir of Nature Power"] == nil then E["Recipe: Elixir of Nature Power"] = "Tarif: Doğa Gücü İksiri" end
if E["Recipe: Elixir of Sages"] == nil then E["Recipe: Elixir of Sages"] = "Tarif: Bilgeler İksiri" end
if E["Recipe: Elixir of Spirit"] == nil then E["Recipe: Elixir of Spirit"] = "Tarif: Ruh İksiri" end
if E["Recipe: Elixir of Strength"] == nil then E["Recipe: Elixir of Strength"] = "Tarif: Güç İksiri" end
if E["Recipe: Elixir of Wicked Regeneration"] == nil then E["Recipe: Elixir of Wicked Regeneration"] = "Tarif: Kötücül Yenilenme İksiri" end
if E["Recipe: Elixir of the Grizzly"] == nil then E["Recipe: Elixir of the Grizzly"] = "Tarif: Bozayı İksiri" end
if E["Recipe: Elixir of the Owl"] == nil then E["Recipe: Elixir of the Owl"] = "Tarif: Baykuş İksiri" end
if E["Recipe: Elixir of the Phalanx"] == nil then E["Recipe: Elixir of the Phalanx"] = "Tarif: Falanks İksiri" end
if E["Recipe: Elixir of the Whale"] == nil then E["Recipe: Elixir of the Whale"] = "Tarif: Balina İksiri" end
if E["Recipe: Flank au Poivre"] == nil then E["Recipe: Flank au Poivre"] = "Tarif: Biberli Bonfile" end
if E["Recipe: Flask of Natural Accuracy"] == nil then E["Recipe: Flask of Natural Accuracy"] = "Tarif: Doğal İsabet Şişesi" end
if E["Recipe: Flask of Natural Aggression"] == nil then E["Recipe: Flask of Natural Aggression"] = "Tarif: Doğal Saldırganlık Şişesi" end
if E["Recipe: Flask of Natural Precision"] == nil then E["Recipe: Flask of Natural Precision"] = "Tarif: Doğal Hassasiyet Şişesi" end
if E["Recipe: Flask of Natural Swiftness"] == nil then E["Recipe: Flask of Natural Swiftness"] = "Tarif: Doğal Sürat Şişesi" end
if E["Recipe: Frenzy Potion"] == nil then E["Recipe: Frenzy Potion"] = "Tarif: Çılgınlık İksiri" end
if E["Recipe: Giant Scrambled Eggs"] == nil then E["Recipe: Giant Scrambled Eggs"] = "Tarif: Dev Yumurta Çırpması" end
if E["Recipe: Greater Cleric's Elixir"] == nil then E["Recipe: Greater Cleric's Elixir"] = "Tarif: Büyük Rahip İksiri" end
if E["Recipe: Greater Frenzy Potion"] == nil then E["Recipe: Greater Frenzy Potion"] = "Tarif: Büyük Çılgınlık İksiri" end
if E["Recipe: Greater Mageblood Elixir"] == nil then E["Recipe: Greater Mageblood Elixir"] = "Tarif: Büyük Büyücü Kanı İksiri" end
if E["Recipe: Greater Spellblasting Potion"] == nil then E["Recipe: Greater Spellblasting Potion"] = "Tarif: Büyük Büyü Patlatma İksiri" end
if E["Recipe: Lesser Arcane Elixir"] == nil then E["Recipe: Lesser Arcane Elixir"] = "Tarif: Hafif Arkan İksiri" end
if E["Recipe: Lesser Cleric's Elixir"] == nil then E["Recipe: Lesser Cleric's Elixir"] = "Tarif: Hafif Rahip İksiri" end
if E["Recipe: Lesser Frenzy Potion"] == nil then E["Recipe: Lesser Frenzy Potion"] = "Tarif: Hafif Çılgınlık İksiri" end
if E["Recipe: Lesser Mageblood Elixir"] == nil then E["Recipe: Lesser Mageblood Elixir"] = "Tarif: Hafif Büyücü Kanı İksiri" end
if E["Recipe: Lesser Mender's Potion"] == nil then E["Recipe: Lesser Mender's Potion"] = "Tarif: Hafif Onarıcı İksiri" end
if E["Recipe: Lesser Spellblasting Potion"] == nil then E["Recipe: Lesser Spellblasting Potion"] = "Tarif: Hafif Büyü Patlatma İksiri" end
if E["Recipe: Major Frenzy Potion"] == nil then E["Recipe: Major Frenzy Potion"] = "Tarif: Yüce Çılgınlık İksiri" end
if E["Recipe: Major Mender's Potion"] == nil then E["Recipe: Major Mender's Potion"] = "Tarif: Yüce Onarıcı İksiri" end
if E["Recipe: Major Spellblasting Potion"] == nil then E["Recipe: Major Spellblasting Potion"] = "Tarif: Yüce Büyü Patlatma İksiri" end
if E["Recipe: Mender's Potion"] == nil then E["Recipe: Mender's Potion"] = "Tarif: Onarıcı İksiri" end
if E["Recipe: Minor Cleric's Elixir"] == nil then E["Recipe: Minor Cleric's Elixir"] = "Tarif: Küçük Rahip İksiri" end
if E["Recipe: Minor Frenzy Potion"] == nil then E["Recipe: Minor Frenzy Potion"] = "Tarif: Küçük Çılgınlık İksiri" end
if E["Recipe: Minor Mageblood Elixir"] == nil then E["Recipe: Minor Mageblood Elixir"] = "Tarif: Küçük Büyücü Kanı İksiri" end
if E["Recipe: Minor Mender's Potion"] == nil then E["Recipe: Minor Mender's Potion"] = "Tarif: Küçük Onarıcı İksiri" end
if E["Recipe: Minor Spellblasting Potion"] == nil then E["Recipe: Minor Spellblasting Potion"] = "Tarif: Küçük Büyü Patlatma İksiri" end
if E["Recipe: Monster Omelet"] == nil then E["Recipe: Monster Omelet"] = "Tarif: Canavar Omleti" end
if E["Recipe: Mrrggl Smrrthle"] == nil then E["Recipe: Mrrggl Smrrthle"] = "Tarif: Mrrggl Smrrthle" end
if E["Recipe: Peace Tea"] == nil then E["Recipe: Peace Tea"] = "Tarif: Barış Çayı" end
if E["Recipe: Pincer Bites"] == nil then E["Recipe: Pincer Bites"] = "Tarif: Kıskaç Lokmaları" end
if E["Recipe: Plain Ol' Paletusk"] == nil then E["Recipe: Plain Ol' Paletusk"] = "Tarif: Sade Paletusk" end
if E["Recipe: Plated Armorfish"] == nil then E["Recipe: Plated Armorfish"] = "Tarif: Tabakta Zırhbalığı" end
if E["Recipe: Potion of Beast Slaying"] == nil then E["Recipe: Potion of Beast Slaying"] = "Tarif: Canavar Avlama İksiri" end
if E["Recipe: Potion of Elemental Purging"] == nil then E["Recipe: Potion of Elemental Purging"] = "Tarif: Elemental Arındırma İksiri" end
if E["Recipe: Potion of Venomous Blood"] == nil then E["Recipe: Potion of Venomous Blood"] = "Tarif: Zehirli Kan İksiri" end
if E["Recipe: Prehistoric Pulled Raptor"] == nil then E["Recipe: Prehistoric Pulled Raptor"] = "Tarif: Tarih Öncesi Didiklenmiş Raptor" end
if E["Recipe: Raging Raptor Ribs"] == nil then E["Recipe: Raging Raptor Ribs"] = "Tarif: Öfkeli Raptor Kaburgası" end
if E["Recipe: Raptor Rouladen"] == nil then E["Recipe: Raptor Rouladen"] = "Tarif: Raptor Rulosu" end
if E["Recipe: Root Tea"] == nil then E["Recipe: Root Tea"] = "Tarif: Kök Çayı" end
if E["Recipe: Royal Tea"] == nil then E["Recipe: Royal Tea"] = "Tarif: Kraliyet Çayı" end
if E["Recipe: Sage's Tea"] == nil then E["Recipe: Sage's Tea"] = "Tarif: Bilgenin Çayı" end
if E["Recipe: Savory Stag Sliders"] == nil then E["Recipe: Savory Stag Sliders"] = "Tarif: Lezzetli Geyik Mini Burgerleri" end
if E["Recipe: Savory Turtle Stew"] == nil then E["Recipe: Savory Turtle Stew"] = "Tarif: Lezzetli Kaplumbağa Yahnisi" end
if E["Recipe: Savory Whimsyfin Delight"] == nil then E["Recipe: Savory Whimsyfin Delight"] = "Tarif: Lezzetli Hayalyüzgeç Ziyafeti" end
if E["Recipe: Skywall Souffle"] == nil then E["Recipe: Skywall Souffle"] = "Tarif: Skywall Suflesi" end
if E["Recipe: Slimy Smoothie"] == nil then E["Recipe: Slimy Smoothie"] = "Tarif: Balçıklı Smoothie" end
if E["Recipe: Soaring Pamplona"] == nil then E["Recipe: Soaring Pamplona"] = "Tarif: Süzülen Pamplona" end
if E["Recipe: Spellblasting Potion"] == nil then E["Recipe: Spellblasting Potion"] = "Tarif: Büyü Patlatma İksiri" end
if E["Recipe: Spicy Smoothie"] == nil then E["Recipe: Spicy Smoothie"] = "Tarif: Baharatlı Smoothie" end
if E["Recipe: Steaming Stag Steak"] == nil then E["Recipe: Steaming Stag Steak"] = "Tarif: Dumanı Tüten Geyik Bifteği" end
if E["Recipe: Sunny Tea"] == nil then E["Recipe: Sunny Tea"] = "Tarif: Güneşli Çay" end
if E["Recipe: Superior Frenzy Potion"] == nil then E["Recipe: Superior Frenzy Potion"] = "Tarif: Üstün Çılgınlık İksiri" end
if E["Recipe: Superior Mender's Potion"] == nil then E["Recipe: Superior Mender's Potion"] = "Tarif: Üstün Onarıcı İksiri" end
if E["Recipe: Superior Spellblasting Potion"] == nil then E["Recipe: Superior Spellblasting Potion"] = "Tarif: Üstün Büyü Patlatma İksiri" end
if E["Recipe: Sweetpaw Jam"] == nil then E["Recipe: Sweetpaw Jam"] = "Tarif: Tatlıpati Reçeli" end
if E["Recipe: Swiftstrike Steak"] == nil then E["Recipe: Swiftstrike Steak"] = "Tarif: Çevik Darbe Bifteği" end
if E["Recipe: Tasty Raptor Bites"] == nil then E["Recipe: Tasty Raptor Bites"] = "Tarif: Lezzetli Raptor Lokmaları" end
if E["Recipe: Transmute Legionite"] == nil then E["Recipe: Transmute Legionite"] = "Tarif: Dönüştürme: Legionite" end
if E["Recipe: Triage Tea"] == nil then E["Recipe: Triage Tea"] = "Tarif: Triyaj Çayı" end
if E["Recipe: Twice-Spiced Raptor Slice"] == nil then E["Recipe: Twice-Spiced Raptor Slice"] = "Tarif: İki Kez Baharatlanmış Raptor Dilimi" end
if E["Recipe: Venomous Smoothie"] == nil then E["Recipe: Venomous Smoothie"] = "Tarif: Zehirli Smoothie" end
if E["Recipe: Wicked Smoothie"] == nil then E["Recipe: Wicked Smoothie"] = "Tarif: Kötücül Smoothie" end
if E["Reclaimer's Robes"] == nil then E["Reclaimer's Robes"] = "Geri Kazananın Cübbeleri" end
if E["Recruit's Boots"] == nil then E["Recruit's Boots"] = "Acemi Erin Çizmeleri" end
if E["Recruit's Pants"] == nil then E["Recruit's Pants"] = "Acemi Erin Pantolonu" end
if E["Recruit's Shirt"] == nil then E["Recruit's Shirt"] = "Acemi Erin Gömleği" end
if E["Redeemer's Waistcord"] == nil then E["Redeemer's Waistcord"] = "Kurtarıcının Bel İpi" end
if E["Reed-woven Heart"] == nil then E["Reed-woven Heart"] = "Kamış Örgü Yürek" end
if E["Relentless Raider's Seal"] == nil then E["Relentless Raider's Seal"] = "Amansız Akıncının Mührü" end
if E["Renferrel's Findings"] == nil then E["Renferrel's Findings"] = "Renferrel'in Bulguları" end
if E["Replica Dartol's Rod of Transformation"] == nil then E["Replica Dartol's Rod of Transformation"] = "Dartol'un Dönüşüm Asası Replikası" end
if E["Resaan's Heirloom"] == nil then E["Resaan's Heirloom"] = "Resaan'ın Yadigârı" end
if E["Researcher's Night Light"] == nil then E["Researcher's Night Light"] = "Araştırmacının Gece Lambası" end
if E["Restorer's Fine Gloves"] == nil then E["Restorer's Fine Gloves"] = "Onarıcının İnce Eldivenleri" end
if E["Rexxar's Testament"] == nil then E["Rexxar's Testament"] = "Rexxar'ın Vasiyeti" end
if E["Rhonin's Gold Coin"] == nil then E["Rhonin's Gold Coin"] = "Rhonin'in Altın Sikkesi" end
if E["Rime-encrusted Boots"] == nil then E["Rime-encrusted Boots"] = "Kırağı Kaplı Çizmeler" end
if E["Ring of Nature's Cycles"] == nil then E["Ring of Nature's Cycles"] = "Doğanın Döngüleri Yüzüğü" end
if E["Ringo's Blizzard Boots"] == nil then E["Ringo's Blizzard Boots"] = "Ringo'nun Tipi Çizmeleri" end
if E["Riptear's Cleaver"] == nil then E["Riptear's Cleaver"] = "Riptear'ın Satırı" end
if E["Riptear's Heart"] == nil then E["Riptear's Heart"] = "Riptear'ın Yüreği" end
if E["Riptear's Spare Arm"] == nil then E["Riptear's Spare Arm"] = "Riptear'ın Yedek Kolu" end
if E["Roadwatcher's Confidence"] == nil then E["Roadwatcher's Confidence"] = "Yol Gözcüsünün Güveni" end
if E["Roamer's Leggings"] == nil then E["Roamer's Leggings"] = "Gezginin Tozlukları" end
if E["Robbie's Hat"] == nil then E["Robbie's Hat"] = "Robbie'nin Şapkası" end
if E["Rog'mar Report"] == nil then E["Rog'mar Report"] = "Rog'mar Raporu" end
if E["Rog'mar Supply Crate"] == nil then E["Rog'mar Supply Crate"] = "Rog'mar Erzak Sandığı" end
if E["Rogue's Diary"] == nil then E["Rogue's Diary"] = "Haydutun Günlüğü" end
if E["Rolf and Malakai's Medallions"] == nil then E["Rolf and Malakai's Medallions"] = "Rolf ve Malakai'nin Madalyonları" end
if E["Roogug's Severed Head"] == nil then E["Roogug's Severed Head"] = "Roogug'un Kesik Kafası" end
if E["Rot-Covered Harpoon"] == nil then E["Rot-Covered Harpoon"] = "Çürük Kaplı Zıpkın" end
if E["Rotmender's Garb"] == nil then E["Rotmender's Garb"] = "Çürük Onarıcının Kıyafeti" end
if E["Rotmender's Gloves"] == nil then E["Rotmender's Gloves"] = "Çürük Onarıcının Eldivenleri" end
if E["Rotmender's Leggings"] == nil then E["Rotmender's Leggings"] = "Çürük Onarıcının Tozlukları" end
if E["Rotmender's Sash"] == nil then E["Rotmender's Sash"] = "Çürük Onarıcının Kuşağı" end
if E["Rotmender's Treads"] == nil then E["Rotmender's Treads"] = "Çürük Onarıcının Adımlıkları" end
if E["Rough-hewn Kodo Leggings"] == nil then E["Rough-hewn Kodo Leggings"] = "Kaba Yontma Kodo Tozlukları" end
if E["Ruby-Adorned Blade"] == nil then E["Ruby-Adorned Blade"] = "Yakut Süslü Kılıç" end
if E["Rudolph Gelhardt's Head"] == nil then E["Rudolph Gelhardt's Head"] = "Rudolph Gelhardt'ın Kafası" end
if E["Rugged Trapper's Pants"] == nil then E["Rugged Trapper's Pants"] = "Sağlam Tuzakçı Pantolonu" end
if E["Rumbleshot's Ammo"] == nil then E["Rumbleshot's Ammo"] = "Rumbleshot'ın Cephanesi" end
if E["Rumi of Gnomeregan: The Collected Works"] == nil then E["Rumi of Gnomeregan: The Collected Works"] = "Gnomeregan'lı Rumi: Toplu Eserler" end
if E["Rune of Teleportation: Antechamber"] == nil then E["Rune of Teleportation: Antechamber"] = "Işınlanma Rünü: Ön Oda" end
if E["Rune of Teleportation: Frostwyrm's Lair"] == nil then E["Rune of Teleportation: Frostwyrm's Lair"] = "Işınlanma Rünü: Frostwyrm's Lair" end
if E["Rune-Etched Ring"] == nil then E["Rune-Etched Ring"] = "Rün Oymalı Yüzük" end
if E["Rune-inscribed Pendant"] == nil then E["Rune-inscribed Pendant"] = "Rün Yazılı Kolye" end
if E["Runemender's Seal"] == nil then E["Runemender's Seal"] = "Rün Onarıcının Mührü" end
if E["Runes of the Sorcerer-Kings"] == nil then E["Runes of the Sorcerer-Kings"] = "Büyücü Kralların Rünleri" end
if E["Rust-covered Blunderbuss"] == nil then E["Rust-covered Blunderbuss"] = "Pas Kaplı Tromblon" end
if E["Ruzzgot's Shipment"] == nil then E["Ruzzgot's Shipment"] = "Ruzzgot'un Sevkiyatı" end
if E["SAF-T Bell"] == nil then E["SAF-T Bell"] = "SAF-T Çan" end
if E["SAF-T Bomb"] == nil then E["SAF-T Bomb"] = "SAF-T Bomba" end
if E["SAF-T Bronze Bomb"] == nil then E["SAF-T Bronze Bomb"] = "SAF-T Bronz Bomba" end
if E["SAF-T Casing"] == nil then E["SAF-T Casing"] = "SAF-T Gövde" end
if E["SAF-T Clever Dynamite"] == nil then E["SAF-T Clever Dynamite"] = "SAF-T Akıllı Dinamit" end
if E["SAF-T Copper Bomb"] == nil then E["SAF-T Copper Bomb"] = "SAF-T Bakır Bomba" end
if E["SAF-T Disposable Parachute"] == nil then E["SAF-T Disposable Parachute"] = "SAF-T Tek Kullanımlık Paraşüt" end
if E["SAF-T Dynamite"] == nil then E["SAF-T Dynamite"] = "SAF-T Dinamit" end
if E["SAF-T Emergency Ripper: Everlook"] == nil then E["SAF-T Emergency Ripper: Everlook"] = "SAF-T Acil Durum Yarıcısı: Everlook" end
if E["SAF-T Jumbo Dynamite"] == nil then E["SAF-T Jumbo Dynamite"] = "SAF-T Jumbo Dinamit" end
if E["SAF-T Nitro Boosts"] == nil then E["SAF-T Nitro Boosts"] = "SAF-T Nitro Takviyesi" end
if E["SAF-T Tabs"] == nil then E["SAF-T Tabs"] = "SAF-T Dilcikler" end
if E["SAF-T Teleport"] == nil then E["SAF-T Teleport"] = "SAF-T Işınlanma" end
if E["SAF-T Tube"] == nil then E["SAF-T Tube"] = "SAF-T Tüp" end
if E["SAF-T Ultra Precision Scope"] == nil then E["SAF-T Ultra Precision Scope"] = "SAF-T Ultra Hassas Dürbün" end
if E["SI:7 Disguise Kit"] == nil then E["SI:7 Disguise Kit"] = "SI:7 Kılık Değiştirme Seti" end
if E["Sack of \"Picture\" Books"] == nil then E["Sack of \"Picture\" Books"] = "\"Resimli\" Kitap Çuvalı" end
if E["Sage's Tea"] == nil then E["Sage's Tea"] = "Bilgenin Çayı" end
if E["Sair's Copper Coin"] == nil then E["Sair's Copper Coin"] = "Sair'in Bakır Sikkesi" end
if E["Saltseer's Helm"] == nil then E["Saltseer's Helm"] = "Tuz Kâhininin Miğferi" end
if E["Saria's Knapsack"] == nil then E["Saria's Knapsack"] = "Saria'nın Sırt Çantası" end
if E["Sarkoth's Mangled Claw"] == nil then E["Sarkoth's Mangled Claw"] = "Sarkoth'un Parçalanmış Pençesi" end
if E["Savory Shen'dralar Steak"] == nil then E["Savory Shen'dralar Steak"] = "Lezzetli Shen'dralar Bifteği" end
if E["Scavenger's Ring"] == nil then E["Scavenger's Ring"] = "Leşçinin Yüzüğü" end
if E["Schematic: 9-60 Battery Pack"] == nil then E["Schematic: 9-60 Battery Pack"] = "Şema: 9-60 Pil Paketi" end
if E["Schematic: Bent Goggles"] == nil then E["Schematic: Bent Goggles"] = "Şema: Eğri Gözlük" end
if E["Schematic: Centaur Banner Deployment Device"] == nil then E["Schematic: Centaur Banner Deployment Device"] = "Şema: Centaur Sancağı Yerleştirme Cihazı" end
if E["Schematic: Clanking Cord"] == nil then E["Schematic: Clanking Cord"] = "Şema: Takırdayan İp Kuşak" end
if E["Schematic: Compact Critter Carrier"] == nil then E["Schematic: Compact Critter Carrier"] = "Şema: Kompakt Hayvan Taşıyıcı" end
if E["Schematic: Dented Goggles"] == nil then E["Schematic: Dented Goggles"] = "Şema: Göçük Gözlük" end
if E["Schematic: Dimensional Transporter: Mt. Hyjal"] == nil then E["Schematic: Dimensional Transporter: Mt. Hyjal"] = "Şema: Boyutsal Taşıyıcı: Mt. Hyjal" end
if E["Schematic: EZ and SAF Field Transporter: Mt. Hyjal"] == nil then E["Schematic: EZ and SAF Field Transporter: Mt. Hyjal"] = "Şema: EZ ve SAF Saha Taşıyıcısı: Mt. Hyjal" end
if E["Schematic: EZ-Thro Bronze Mortar"] == nil then E["Schematic: EZ-Thro Bronze Mortar"] = "Şema: EZ-Atış Bronz Havan" end
if E["Schematic: EZ-Thro Copper Bomb XL"] == nil then E["Schematic: EZ-Thro Copper Bomb XL"] = "Şema: EZ-Atış Bakır Bomba XL" end
if E["Schematic: EZ-Thro Dark Bomb"] == nil then E["Schematic: EZ-Thro Dark Bomb"] = "Şema: EZ-Atış Karanlık Bomba" end
if E["Schematic: EZ-Thro Field Transporter: Gadgetzan"] == nil then E["Schematic: EZ-Thro Field Transporter: Gadgetzan"] = "Şema: EZ-Atış Saha Taşıyıcısı: Gadgetzan" end
if E["Schematic: EZ-Thro Fireproof Fuse"] == nil then E["Schematic: EZ-Thro Fireproof Fuse"] = "Şema: EZ-Atış Yanmaz Fitil" end
if E["Schematic: EZ-Thro Grenade"] == nil then E["Schematic: EZ-Thro Grenade"] = "Şema: EZ-Atış El Bombası" end
if E["Schematic: EZ-Thro Magnetic Displacer"] == nil then E["Schematic: EZ-Thro Magnetic Displacer"] = "Şema: EZ-Atış Manyetik Yer Değiştirici" end
if E["Schematic: EZ-Thro Mana Bomb"] == nil then E["Schematic: EZ-Thro Mana Bomb"] = "Şema: EZ-Atış Mana Bombası" end
if E["Schematic: EZ-Thro Shell"] == nil then E["Schematic: EZ-Thro Shell"] = "Şema: EZ-Atış Kovan" end
if E["Schematic: EZ-Thro Thorium Grenade"] == nil then E["Schematic: EZ-Thro Thorium Grenade"] = "Şema: EZ-Atış Toryum El Bombası" end
if E["Schematic: EZ-Thro Tru-Trigger"] == nil then E["Schematic: EZ-Thro Tru-Trigger"] = "Şema: EZ-Atış Tam-Tetik" end
if E["Schematic: EZ-Thro Wrap"] == nil then E["Schematic: EZ-Thro Wrap"] = "Şema: EZ-Atış Sargı" end
if E["Schematic: Emergency Field Cloak"] == nil then E["Schematic: Emergency Field Cloak"] = "Şema: Acil Durum Saha Pelerini" end
if E["Schematic: Enormous Tranquilizer Dart"] == nil then E["Schematic: Enormous Tranquilizer Dart"] = "Şema: Devasa Uyuşturucu Dart" end
if E["Schematic: Floppy Goggles"] == nil then E["Schematic: Floppy Goggles"] = "Şema: Sarkık Gözlük" end
if E["Schematic: G.R.R.-Nade"] == nil then E["Schematic: G.R.R.-Nade"] = "Şema: G.R.R.-Nade" end
if E["Schematic: Gizmo Girdle"] == nil then E["Schematic: Gizmo Girdle"] = "Şema: Zımbırtı Bel Kuşağı" end
if E["Schematic: Gnomish Army Knife"] == nil then E["Schematic: Gnomish Army Knife"] = "Şema: Gnome Çakısı" end
if E["Schematic: Gnomish Poultryizer"] == nil then E["Schematic: Gnomish Poultryizer"] = "Şema: Gnome Tavuklaştırıcı" end
if E["Schematic: Gnomish Weather Machine"] == nil then E["Schematic: Gnomish Weather Machine"] = "Şema: Gnome Hava Durumu Makinesi" end
if E["Schematic: Harvester Override Signalcaster"] == nil then E["Schematic: Harvester Override Signalcaster"] = "Şema: Biçerdöver Kontrol Ele Geçirme Sinyal Vericisi" end
if E["Schematic: Hoof-Shaped Foot Pedal"] == nil then E["Schematic: Hoof-Shaped Foot Pedal"] = "Şema: Toynak Biçimli Ayak Pedalı" end
if E["Schematic: Hyper Deluxe Sniper Rifle Mk XVII"] == nil then E["Schematic: Hyper Deluxe Sniper Rifle Mk XVII"] = "Şema: Hiper Lüks Keskin Nişancı Tüfeği Mk XVII" end
if E["Schematic: Large Purple Rocket"] == nil then E["Schematic: Large Purple Rocket"] = "Şema: Büyük Mor Roket" end
if E["Schematic: Large Purple Rocket Cluster"] == nil then E["Schematic: Large Purple Rocket Cluster"] = "Şema: Büyük Mor Roket Demeti" end
if E["Schematic: Large White Rocket"] == nil then E["Schematic: Large White Rocket"] = "Şema: Büyük Beyaz Roket" end
if E["Schematic: Large White Rocket Cluster"] == nil then E["Schematic: Large White Rocket Cluster"] = "Şema: Büyük Beyaz Roket Demeti" end
if E["Schematic: Large Yellow Rocket"] == nil then E["Schematic: Large Yellow Rocket"] = "Şema: Büyük Sarı Roket" end
if E["Schematic: Large Yellow Rocket Cluster"] == nil then E["Schematic: Large Yellow Rocket Cluster"] = "Şema: Büyük Sarı Roket Demeti" end
if E["Schematic: Loot-A-Rang"] == nil then E["Schematic: Loot-A-Rang"] = "Şema: Ganimet-A-Rang" end
if E["Schematic: No Slip SAF-T Padding"] == nil then E["Schematic: No Slip SAF-T Padding"] = "Şema: Kaymaz SAF-T Dolgu" end
if E["Schematic: Pop-Up Shrub"] == nil then E["Schematic: Pop-Up Shrub"] = "Şema: Açılır Çalı" end
if E["Schematic: Purple Rocket Cluster"] == nil then E["Schematic: Purple Rocket Cluster"] = "Şema: Mor Roket Demeti" end
if E["Schematic: SAF-T Bell"] == nil then E["Schematic: SAF-T Bell"] = "Şema: SAF-T Çan" end
if E["Schematic: SAF-T Bomb"] == nil then E["Schematic: SAF-T Bomb"] = "Şema: SAF-T Bomba" end
if E["Schematic: SAF-T Bronze Bomb"] == nil then E["Schematic: SAF-T Bronze Bomb"] = "Şema: SAF-T Bronz Bomba" end
if E["Schematic: SAF-T Casing"] == nil then E["Schematic: SAF-T Casing"] = "Şema: SAF-T Gövde" end
if E["Schematic: SAF-T Clever Dynamite"] == nil then E["Schematic: SAF-T Clever Dynamite"] = "Şema: SAF-T Akıllı Dinamit" end
if E["Schematic: SAF-T Copper Bomb"] == nil then E["Schematic: SAF-T Copper Bomb"] = "Şema: SAF-T Bakır Bomba" end
if E["Schematic: SAF-T Disposable Parachute"] == nil then E["Schematic: SAF-T Disposable Parachute"] = "Şema: SAF-T Tek Kullanımlık Paraşüt" end
if E["Schematic: SAF-T Dynamite"] == nil then E["Schematic: SAF-T Dynamite"] = "Şema: SAF-T Dinamit" end
if E["Schematic: SAF-T Emergency Ripper: Everlook"] == nil then E["Schematic: SAF-T Emergency Ripper: Everlook"] = "Şema: SAF-T Acil Durum Yarıcısı: Everlook" end
if E["Schematic: SAF-T Jumbo Dynamite"] == nil then E["Schematic: SAF-T Jumbo Dynamite"] = "Şema: SAF-T Jumbo Dinamit" end
if E["Schematic: SAF-T Nitro Boosts"] == nil then E["Schematic: SAF-T Nitro Boosts"] = "Şema: SAF-T Nitro Takviyesi" end
if E["Schematic: SAF-T Tabs"] == nil then E["Schematic: SAF-T Tabs"] = "Şema: SAF-T Dilcikler" end
if E["Schematic: SAF-T Teleport"] == nil then E["Schematic: SAF-T Teleport"] = "Şema: SAF-T Işınlanma" end
if E["Schematic: SAF-T Tube"] == nil then E["Schematic: SAF-T Tube"] = "Şema: SAF-T Tüp" end
if E["Schematic: SAF-T Ultra Precision Scope"] == nil then E["Schematic: SAF-T Ultra Precision Scope"] = "Şema: SAF-T Ultra Hassas Dürbün" end
if E["Schematic: Satchel of Bronze Bombs"] == nil then E["Schematic: Satchel of Bronze Bombs"] = "Şema: Bronz Bomba Çantası" end
if E["Schematic: Satchel of Copper Bombs"] == nil then E["Schematic: Satchel of Copper Bombs"] = "Şema: Bakır Bomba Çantası" end
if E["Schematic: Satchel of Dark Iron Bombs"] == nil then E["Schematic: Satchel of Dark Iron Bombs"] = "Şema: Dark Iron Bomba Çantası" end
if E["Schematic: Satchel of Iron Bombs"] == nil then E["Schematic: Satchel of Iron Bombs"] = "Şema: Demir Bomba Çantası" end
if E["Schematic: Semisafe Transporter: New Avalon"] == nil then E["Schematic: Semisafe Transporter: New Avalon"] = "Şema: Yarı Güvenli Taşıyıcı: New Avalon" end
if E["Schematic: Serrated Strap"] == nil then E["Schematic: Serrated Strap"] = "Şema: Tırtıklı Kayış" end
if E["Schematic: Shafety Sheep"] == nil then E["Schematic: Shafety Sheep"] = "Şema: Güvenlikli Koyun" end
if E["Schematic: Sludge Suppressor"] == nil then E["Schematic: Sludge Suppressor"] = "Şema: Balçık Bastırıcı" end
if E["Schematic: Small Purple Rocket"] == nil then E["Schematic: Small Purple Rocket"] = "Şema: Küçük Mor Roket" end
if E["Schematic: Small White Rocket"] == nil then E["Schematic: Small White Rocket"] = "Şema: Küçük Beyaz Roket" end
if E["Schematic: Small Yellow Rocket"] == nil then E["Schematic: Small Yellow Rocket"] = "Şema: Küçük Sarı Roket" end
if E["Schematic: Stealthman 52"] == nil then E["Schematic: Stealthman 52"] = "Şema: Stealthman 52" end
if E["Schematic: Stuckbutton Goggles"] == nil then E["Schematic: Stuckbutton Goggles"] = "Şema: Takılı Düğmeli Gözlük" end
if E["Schematic: Swiftfeather Arrow"] == nil then E["Schematic: Swiftfeather Arrow"] = "Şema: Çeviktüy Oku" end
if E["Schematic: Swiftstrike Shot"] == nil then E["Schematic: Swiftstrike Shot"] = "Şema: Çevik Darbe Mermisi" end
if E["Schematic: Tinker: Magnetic Displacement"] == nil then E["Schematic: Tinker: Magnetic Displacement"] = "Şema: Tamirat: Manyetik Yer Değiştirme" end
if E["Schematic: Tinker: Nitro Boosts"] == nil then E["Schematic: Tinker: Nitro Boosts"] = "Şema: Tamirat: Nitro Takviyesi" end
if E["Schematic: Tinker: Teleport"] == nil then E["Schematic: Tinker: Teleport"] = "Şema: Tamirat: Işınlanma" end
if E["Schematic: Tinkerbox"] == nil then E["Schematic: Tinkerbox"] = "Şema: Tamir Kutusu" end
if E["Schematic: Tinkerbox: Magnetic Displacement"] == nil then E["Schematic: Tinkerbox: Magnetic Displacement"] = "Şema: Tamir Kutusu: Manyetik Yer Değiştirme" end
if E["Schematic: Tinkerbox: Nitro Boosts"] == nil then E["Schematic: Tinkerbox: Nitro Boosts"] = "Şema: Tamir Kutusu: Nitro Takviyesi" end
if E["Schematic: Tinkerbox: Teleport"] == nil then E["Schematic: Tinkerbox: Teleport"] = "Şema: Tamir Kutusu: Işınlanma" end
if E["Schematic: Tru-Trigger Frag Bomb"] == nil then E["Schematic: Tru-Trigger Frag Bomb"] = "Şema: Tam-Tetik Parça Bombası" end
if E["Schematic: Ultralight Goblin Glider"] == nil then E["Schematic: Ultralight Goblin Glider"] = "Şema: Ultra Hafif Goblin Planörü" end
if E["Schematic: Ultrasafe Rechargeable Battery"] == nil then E["Schematic: Ultrasafe Rechargeable Battery"] = "Şema: Ultra Güvenli Şarj Edilebilir Pil" end
if E["Schematic: Unsanctified Grenade"] == nil then E["Schematic: Unsanctified Grenade"] = "Şema: Kutsanmamış El Bombası" end
if E["Schematic: Whimsical Waistwrap"] == nil then E["Schematic: Whimsical Waistwrap"] = "Şema: Tuhaf Bel Sargısı" end
if E["Schematic: White Rocket Cluster"] == nil then E["Schematic: White Rocket Cluster"] = "Şema: Beyaz Roket Demeti" end
if E["Schematic: Yellow Rocket Cluster"] == nil then E["Schematic: Yellow Rocket Cluster"] = "Şema: Sarı Roket Demeti" end
if E["Scourge: Undead Menace or Misunderstood?"] == nil then E["Scourge: Undead Menace or Misunderstood?"] = "Scourge: Ölümsüz Tehdit mi, Yanlış Anlaşılan mı?" end
if E["Scout Ranger's Belt"] == nil then E["Scout Ranger's Belt"] = "İzci Korucunun Kemeri" end
if E["Scout Ranger's Boots"] == nil then E["Scout Ranger's Boots"] = "İzci Korucunun Çizmeleri" end
if E["Scout Ranger's Dagger"] == nil then E["Scout Ranger's Dagger"] = "İzci Korucunun Hançeri" end
if E["Scout Ranger's Gloves"] == nil then E["Scout Ranger's Gloves"] = "İzci Korucunun Eldivenleri" end
if E["Scout Ranger's Leggings"] == nil then E["Scout Ranger's Leggings"] = "İzci Korucunun Tozlukları" end
if E["Scout Ranger's Tunic"] == nil then E["Scout Ranger's Tunic"] = "İzci Korucunun Tuniği" end
if E["Scout's Cloak"] == nil then E["Scout's Cloak"] = "İzcinin Pelerini" end
if E["Scout's Dagger"] == nil then E["Scout's Dagger"] = "İzcinin Hançeri" end
if E["Scoutmaster's Eye"] == nil then E["Scoutmaster's Eye"] = "İzci Başının Gözü" end
if E["Scoutmaster's Eyepatch"] == nil then E["Scoutmaster's Eyepatch"] = "İzci Başının Göz Bandı" end
if E["Scrapper's Salvage"] == nil then E["Scrapper's Salvage"] = "Hurdacının Kurtardıkları" end
if E["Scribbled I.O.U."] == nil then E["Scribbled I.O.U."] = "Karalanmış Borç Senedi" end
if E["Scroll of Arcane Protection - Fire I"] == nil then E["Scroll of Arcane Protection - Fire I"] = "Arkan Koruma Parşömeni - Ateş I" end
if E["Scroll of Arcane Protection - Frost I"] == nil then E["Scroll of Arcane Protection - Frost I"] = "Arkan Koruma Parşömeni - Ayaz I" end
if E["Scroll of Khadgar's Unlocking"] == nil then E["Scroll of Khadgar's Unlocking"] = "Khadgar'ın Kilit Açma Parşömeni" end
if E["Scroll of Polymorph: Odd Melon"] == nil then E["Scroll of Polymorph: Odd Melon"] = "Dönüşüm Parşömeni: Tuhaf Kavun" end
if E["Scroll: CHAP BALK WELLES"] == nil then E["Scroll: CHAP BALK WELLES"] = "Parşömen: CHAP BALK WELLES" end
if E["Scroll: CWAL"] == nil then E["Scroll: CWAL"] = "Parşömen: CWAL" end
if E["Scroll: DOST OREM"] == nil then E["Scroll: DOST OREM"] = "Parşömen: DOST OREM" end
if E["Scroll: FORGOT HOOF THUD"] == nil then E["Scroll: FORGOT HOOF THUD"] = "Parşömen: FORGOT HOOF THUD" end
if E["Scroll: KEEP CLEF FOCI"] == nil then E["Scroll: KEEP CLEF FOCI"] = "Parşömen: KEEP CLEF FOCI" end
if E["Scroll: KWYJIBO"] == nil then E["Scroll: KWYJIBO"] = "Parşömen: KWYJIBO" end
if E["Scroll: LOWER PING WHOMEVER"] == nil then E["Scroll: LOWER PING WHOMEVER"] = "Parşömen: LOWER PING WHOMEVER" end
if E["Scroll: OMIT KESA"] == nil then E["Scroll: OMIT KESA"] = "Parşömen: OMIT KESA" end
if E["Scroll: PEATCHY ATTAX"] == nil then E["Scroll: PEATCHY ATTAX"] = "Parşömen: PEATCHY ATTAX" end
if E["Scroll: RARE SERVICHI RADAR"] == nil then E["Scroll: RARE SERVICHI RADAR"] = "Parşömen: RARE SERVICHI RADAR" end
if E["Scroll: SHOOBEEDOOP"] == nil then E["Scroll: SHOOBEEDOOP"] = "Parşömen: SHOOBEEDOOP" end
if E["Scroll: STHENIC LUNATE"] == nil then E["Scroll: STHENIC LUNATE"] = "Parşömen: STHENIC LUNATE" end
if E["Scroll: THAW WORDS"] == nil then E["Scroll: THAW WORDS"] = "Parşömen: THAW WORDS" end
if E["Scroll: TOPAZ YORAK"] == nil then E["Scroll: TOPAZ YORAK"] = "Parşömen: TOPAZ YORAK" end
if E["Scroll: UPDOG"] == nil then E["Scroll: UPDOG"] = "Parşömen: UPDOG" end
if E["Scroll: VOCE WELL"] == nil then E["Scroll: VOCE WELL"] = "Parşömen: VOCE WELL" end
if E["Scroll: WUBBA WUBBA"] == nil then E["Scroll: WUBBA WUBBA"] = "Parşömen: WUBBA WUBBA" end
if E["Scryer's Key"] == nil then E["Scryer's Key"] = "Kâhinin Anahtarı" end
if E["Sea Giant's Toe Ring"] == nil then E["Sea Giant's Toe Ring"] = "Deniz Devinin Ayak Parmağı Yüzüğü" end
if E["Sea Monster's Head"] == nil then E["Sea Monster's Head"] = "Deniz Canavarının Kafası" end
if E["Seadog's Battered Cuffs"] == nil then E["Seadog's Battered Cuffs"] = "Deniz Kurdunun Hırpalanmış Kollukları" end
if E["Sealed Apprentice's Writ"] == nil then E["Sealed Apprentice's Writ"] = "Mühürlü Çırak Siparişi" end
if E["Sealed Artisan's Writ"] == nil then E["Sealed Artisan's Writ"] = "Mühürlü Zanaatkâr Yazısı" end
if E["Sealed Expert's Writ"] == nil then E["Sealed Expert's Writ"] = "Mühürlü Uzman Siparişi" end
if E["Sealed Journeyman's Writ"] == nil then E["Sealed Journeyman's Writ"] = "Mühürlü Kalfa Siparişi" end
if E["Seals of the Sin'dorei"] == nil then E["Seals of the Sin'dorei"] = "Sin'dorei Mühürleri" end
if E["Seasoned Fighter's Cloak"] == nil then E["Seasoned Fighter's Cloak"] = "Kıdemli Dövüşçünün Pelerini" end
if E["Senir's Report"] == nil then E["Senir's Report"] = "Senir'in Raporu" end
if E["Sentinel's Belt"] == nil then E["Sentinel's Belt"] = "Nöbetçinin Kemeri" end
if E["Sentinel's Boots"] == nil then E["Sentinel's Boots"] = "Nöbetçinin Çizmeleri" end
if E["Sentinel's Gauntlet"] == nil then E["Sentinel's Gauntlet"] = "Nöbetçinin Zırh Eldiveni" end
if E["Sentinel's Gloves"] == nil then E["Sentinel's Gloves"] = "Nöbetçinin Eldivenleri" end
if E["Sentinel's Libram"] == nil then E["Sentinel's Libram"] = "Nöbetçinin Libramı" end
if E["Sentinel's Pauldrons"] == nil then E["Sentinel's Pauldrons"] = "Nöbetçinin Omuz Zırhları" end
if E["Sentinel's Plate"] == nil then E["Sentinel's Plate"] = "Nöbetçinin Plaka Zırhı" end
if E["Sentinel's Sabatons"] == nil then E["Sentinel's Sabatons"] = "Nöbetçinin Zırh Çizmeleri" end
if E["Sentinel's Sight"] == nil then E["Sentinel's Sight"] = "Nöbetçinin Görüşü" end
if E["Sentinel's Slasher"] == nil then E["Sentinel's Slasher"] = "Nöbetçinin Doğrayıcısı" end
if E["Sentinel's Waistguard"] == nil then E["Sentinel's Waistguard"] = "Nöbetçinin Bel Koruyucusu" end
if E["Sentinel's Wristguards"] == nil then E["Sentinel's Wristguards"] = "Nöbetçinin Bilek Koruyucuları" end
if E["Settler's Leggings"] == nil then E["Settler's Leggings"] = "Yerleşimcinin Tozlukları" end
if E["Sevren's Orders"] == nil then E["Sevren's Orders"] = "Sevren'in Emirleri" end
if E["Shadow Council Apprentice's Mantle"] == nil then E["Shadow Council Apprentice's Mantle"] = "Shadow Council Çırağının Mantosu" end
if E["Shal'ma's Shawl"] == nil then E["Shal'ma's Shawl"] = "Shal'ma'nın Şalı" end
if E["Shapeshifter's Helm"] == nil then E["Shapeshifter's Helm"] = "Şekil Değiştiricinin Miğferi" end
if E["Shapeshifting Sentinel's Strides"] == nil then E["Shapeshifting Sentinel's Strides"] = "Şekil Değiştiren Nöbetçinin Adımlıkları" end
if E["Shen'dar Ledgers"] == nil then E["Shen'dar Ledgers"] = "Shen'dar Defterleri" end
if E["Shen'dar Village Offering Coffer"] == nil then E["Shen'dar Village Offering Coffer"] = "Shen'dar Köyü Adak Sandığı" end
if E["Shen'dorei Magister's Belt"] == nil then E["Shen'dorei Magister's Belt"] = "Shen'dorei Magister Kemeri" end
if E["Shen'dorei Magister's Boots"] == nil then E["Shen'dorei Magister's Boots"] = "Shen'dorei Magister Çizmeleri" end
if E["Shen'dorei Magister's Cloak"] == nil then E["Shen'dorei Magister's Cloak"] = "Shen'dorei Magister Pelerini" end
if E["Shen'dorei Magister's Gloves"] == nil then E["Shen'dorei Magister's Gloves"] = "Shen'dorei Magister Eldivenleri" end
if E["Shen'dorei Magister's Helm"] == nil then E["Shen'dorei Magister's Helm"] = "Shen'dorei Magister Miğferi" end
if E["Shen'dorei Magister's Leggings"] == nil then E["Shen'dorei Magister's Leggings"] = "Shen'dorei Magister Tozlukları" end
if E["Shen'dorei Magister's Pauldrons"] == nil then E["Shen'dorei Magister's Pauldrons"] = "Shen'dorei Magister Omuz Zırhları" end
if E["Shen'dorei Magister's Robe"] == nil then E["Shen'dorei Magister's Robe"] = "Shen'dorei Magister Cübbesi" end
if E["Shen'dorei Magister's Vest"] == nil then E["Shen'dorei Magister's Vest"] = "Shen'dorei Magister Yeleği" end
if E["Shen'dorei Peacekeeper's Belt"] == nil then E["Shen'dorei Peacekeeper's Belt"] = "Shen'dorei Barış Muhafızı Kemeri" end
if E["Shen'dorei Peacekeeper's Boots"] == nil then E["Shen'dorei Peacekeeper's Boots"] = "Shen'dorei Barış Muhafızı Çizmeleri" end
if E["Shen'dorei Peacekeeper's Cloak"] == nil then E["Shen'dorei Peacekeeper's Cloak"] = "Shen'dorei Barış Muhafızı Pelerini" end
if E["Shen'dorei Peacekeeper's Gloves"] == nil then E["Shen'dorei Peacekeeper's Gloves"] = "Shen'dorei Barış Muhafızı Eldivenleri" end
if E["Shen'dorei Peacekeeper's Helm"] == nil then E["Shen'dorei Peacekeeper's Helm"] = "Shen'dorei Barış Muhafızı Miğferi" end
if E["Shen'dorei Peacekeeper's Leggings"] == nil then E["Shen'dorei Peacekeeper's Leggings"] = "Shen'dorei Barış Muhafızı Tozlukları" end
if E["Shen'dorei Peacekeeper's Pauldrons"] == nil then E["Shen'dorei Peacekeeper's Pauldrons"] = "Shen'dorei Barış Muhafızı Omuz Zırhları" end
if E["Shen'dorei Peacekeeper's Robe"] == nil then E["Shen'dorei Peacekeeper's Robe"] = "Shen'dorei Barış Muhafızı Cübbesi" end
if E["Shen'dorei Peacekeeper's Vest"] == nil then E["Shen'dorei Peacekeeper's Vest"] = "Shen'dorei Barış Muhafızı Yeleği" end
if E["Shen'dorei Signet"] == nil then E["Shen'dorei Signet"] = "Shen'dorei Mühür Yüzüğü" end
if E["Shen'dorei Skyseer's Belt"] == nil then E["Shen'dorei Skyseer's Belt"] = "Shen'dorei Gökgörücü Kemeri" end
if E["Shen'dorei Skyseer's Boots"] == nil then E["Shen'dorei Skyseer's Boots"] = "Shen'dorei Gökgörücü Çizmeleri" end
if E["Shen'dorei Skyseer's Cloak"] == nil then E["Shen'dorei Skyseer's Cloak"] = "Shen'dorei Gökgörücü Pelerini" end
if E["Shen'dorei Skyseer's Gloves"] == nil then E["Shen'dorei Skyseer's Gloves"] = "Shen'dorei Gökgörücü Eldivenleri" end
if E["Shen'dorei Skyseer's Helm"] == nil then E["Shen'dorei Skyseer's Helm"] = "Shen'dorei Gökgörücü Miğferi" end
if E["Shen'dorei Skyseer's Leggings"] == nil then E["Shen'dorei Skyseer's Leggings"] = "Shen'dorei Gökgörücü Tozlukları" end
if E["Shen'dorei Skyseer's Pauldrons"] == nil then E["Shen'dorei Skyseer's Pauldrons"] = "Shen'dorei Gökgörücü Omuz Zırhları" end
if E["Shen'dorei Skyseer's Robe"] == nil then E["Shen'dorei Skyseer's Robe"] = "Shen'dorei Gökgörücü Cübbesi" end
if E["Shen'dorei Skyseer's Vest"] == nil then E["Shen'dorei Skyseer's Vest"] = "Shen'dorei Gökgörücü Yeleği" end
if E["Shen'dorei Tabard"] == nil then E["Shen'dorei Tabard"] = "Shen'dorei Tabarı" end
if E["Shen'dorei Windwell"] == nil then E["Shen'dorei Windwell"] = "Shen'dorei Rüzgâr Kuyusu" end
if E["Shield, Lordaeron Guard"] == nil then E["Shield, Lordaeron Guard"] = "Kalkan, Lordaeron Muhafızı" end
if E["Shifter's Belt"] == nil then E["Shifter's Belt"] = "Şekil Değiştiricinin Kemeri" end
if E["Shipwright's Satchel"] == nil then E["Shipwright's Satchel"] = "Gemi Ustasının Çantası" end
if E["Shizzle's Drizzle Blocker"] == nil then E["Shizzle's Drizzle Blocker"] = "Shizzle'ın Çisenti Engelleyicisi" end
if E["Shizzle's Muzzle"] == nil then E["Shizzle's Muzzle"] = "Shizzle'ın Ağızlığı" end
if E["Shizzle's Nozzle Wiper"] == nil then E["Shizzle's Nozzle Wiper"] = "Shizzle'ın Nozul Sileceği" end
if E["Short-handled Battle Axe"] == nil then E["Short-handled Battle Axe"] = "Kısa Saplı Savaş Baltası" end
if E["Shriekling Matriarch's Head"] == nil then E["Shriekling Matriarch's Head"] = "Çığırtkan Matriarkın Kafası" end
if E["Siegebreaker's Blaster"] == nil then E["Siegebreaker's Blaster"] = "Kuşatma Kıranın Patlatıcısı" end
if E["Silvia's Sword"] == nil then E["Silvia's Sword"] = "Silvia'nın Kılıcı" end
if E["Sin'dorei Tome of Summoning"] == nil then E["Sin'dorei Tome of Summoning"] = "Sin'dorei Çağırma Kitabı" end
if E["Sinslayer's Smasher"] == nil then E["Sinslayer's Smasher"] = "Günah Avcısının Ezicisi" end
if E["Sister's Half-Key"] == nil then E["Sister's Half-Key"] = "Kız Kardeşin Yarım Anahtarı" end
if E["Skirmisher's Leather Belt"] == nil then E["Skirmisher's Leather Belt"] = "Çatışmacının Deri Kemeri" end
if E["Skirmisher's Leather Gloves"] == nil then E["Skirmisher's Leather Gloves"] = "Çatışmacının Deri Eldivenleri" end
if E["Skirmisher's Mail Belt"] == nil then E["Skirmisher's Mail Belt"] = "Çatışmacının Zincir Kemeri" end
if E["Skirmisher's Mail Boots"] == nil then E["Skirmisher's Mail Boots"] = "Çatışmacının Zincir Çizmeleri" end
if E["Skirmisher's Mail Bracers"] == nil then E["Skirmisher's Mail Bracers"] = "Çatışmacının Zincir Bileklikleri" end
if E["Skirmisher's Mail Gauntlets"] == nil then E["Skirmisher's Mail Gauntlets"] = "Çatışmacının Zincir Zırh Eldivenleri" end
if E["Skirmisher's Mail Sabatons"] == nil then E["Skirmisher's Mail Sabatons"] = "Çatışmacının Zincir Zırh Çizmeleri" end
if E["Skirmisher's Mail Shoulder"] == nil then E["Skirmisher's Mail Shoulder"] = "Çatışmacının Zincir Omuzluğu" end
if E["Skonk's List"] == nil then E["Skonk's List"] = "Skonk'un Listesi" end
if E["Skorn's Hammer"] == nil then E["Skorn's Hammer"] = "Skorn'un Çekici" end
if E["Skorn's Rifle"] == nil then E["Skorn's Rifle"] = "Skorn'un Tüfeği" end
if E["Skulker's Leather Belt"] == nil then E["Skulker's Leather Belt"] = "Pusucunun Deri Kemeri" end
if E["Skulker's Leather Boots"] == nil then E["Skulker's Leather Boots"] = "Pusucunun Deri Çizmeleri" end
if E["Skulker's Leather Bracers"] == nil then E["Skulker's Leather Bracers"] = "Pusucunun Deri Bileklikleri" end
if E["Skulker's Leather Gauntlets"] == nil then E["Skulker's Leather Gauntlets"] = "Pusucunun Deri Zırh Eldivenleri" end
if E["Skulker's Leather Gloves"] == nil then E["Skulker's Leather Gloves"] = "Pusucunun Deri Eldivenleri" end
if E["Skulker's Leather Shoes"] == nil then E["Skulker's Leather Shoes"] = "Pusucunun Deri Ayakkabıları" end
if E["Skulker's Leather Shoulder"] == nil then E["Skulker's Leather Shoulder"] = "Pusucunun Deri Omuzluğu" end
if E["Skulker's Leather Waistguard"] == nil then E["Skulker's Leather Waistguard"] = "Pusucunun Deri Bel Koruyucusu" end
if E["Skulker's Shiv"] == nil then E["Skulker's Shiv"] = "Pusucunun Bıçağı" end
if E["Skum's Bucket"] == nil then E["Skum's Bucket"] = "Skum'ın Kovası" end
if E["Skycaller's Leather Belt"] == nil then E["Skycaller's Leather Belt"] = "Gök Çağırıcının Deri Kemeri" end
if E["Skycaller's Leather Boots"] == nil then E["Skycaller's Leather Boots"] = "Gök Çağırıcının Deri Çizmeleri" end
if E["Skycaller's Leather Bracers"] == nil then E["Skycaller's Leather Bracers"] = "Gök Çağırıcının Deri Bileklikleri" end
if E["Skycaller's Leather Gauntlets"] == nil then E["Skycaller's Leather Gauntlets"] = "Gök Çağırıcının Deri Zırh Eldivenleri" end
if E["Skycaller's Leather Gloves"] == nil then E["Skycaller's Leather Gloves"] = "Gök Çağırıcının Deri Eldivenleri" end
if E["Skycaller's Leather Shoes"] == nil then E["Skycaller's Leather Shoes"] = "Gök Çağırıcının Deri Ayakkabıları" end
if E["Skycaller's Leather Shoulder"] == nil then E["Skycaller's Leather Shoulder"] = "Gök Çağırıcının Deri Omuzluğu" end
if E["Skycaller's Leather Waistguard"] == nil then E["Skycaller's Leather Waistguard"] = "Gök Çağırıcının Deri Bel Koruyucusu" end
if E["Skycaller's Mail Belt"] == nil then E["Skycaller's Mail Belt"] = "Gök Çağırıcının Zincir Kemeri" end
if E["Skycaller's Mail Boots"] == nil then E["Skycaller's Mail Boots"] = "Gök Çağırıcının Zincir Çizmeleri" end
if E["Skycaller's Mail Bracers"] == nil then E["Skycaller's Mail Bracers"] = "Gök Çağırıcının Zincir Bileklikleri" end
if E["Skycaller's Mail Gauntlets"] == nil then E["Skycaller's Mail Gauntlets"] = "Gök Çağırıcının Zincir Zırh Eldivenleri" end
if E["Skycaller's Mail Sabatons"] == nil then E["Skycaller's Mail Sabatons"] = "Gök Çağırıcının Zincir Zırh Çizmeleri" end
if E["Skycaller's Mail Shoulder"] == nil then E["Skycaller's Mail Shoulder"] = "Gök Çağırıcının Zincir Omuzluğu" end
if E["Skyseeker's Greatstaff"] == nil then E["Skyseeker's Greatstaff"] = "Gök Arayıcının Büyük Asası" end
if E["Skyseer's Belt"] == nil then E["Skyseer's Belt"] = "Gökgörücünün Kemeri" end
if E["Skyseer's Gloves"] == nil then E["Skyseer's Gloves"] = "Gökgörücünün Eldivenleri" end
if E["Skyseer's Pants"] == nil then E["Skyseer's Pants"] = "Gökgörücünün Pantolonu" end
if E["Skyseer's Slippers"] == nil then E["Skyseer's Slippers"] = "Gökgörücünün Terlikleri" end
if E["Skyseer's Vest"] == nil then E["Skyseer's Vest"] = "Gökgörücünün Yeleği" end
if E["Skywatcher's Vestments"] == nil then E["Skywatcher's Vestments"] = "Gök Gözcüsünün Giysileri" end
if E["Slain Baron's Signet"] == nil then E["Slain Baron's Signet"] = "Öldürülmüş Baronun Mühür Yüzüğü" end
if E["Sleeveless T-Shirt"] == nil then E["Sleeveless T-Shirt"] = "Kolsuz Tişört" end
if E["Slice of Carrie's Apple Pie"] == nil then E["Slice of Carrie's Apple Pie"] = "Carrie'nin Elmalı Turtasından Bir Dilim" end
if E["Slime Ward - Fel Ash Experimentation Notes"] == nil then E["Slime Ward - Fel Ash Experimentation Notes"] = "Balçık Koruması - Fel Külü Deney Notları" end
if E["Sludge-Stained Band"] == nil then E["Sludge-Stained Band"] = "Balçık Lekeli Yüzük" end
if E["Smotts' Pinky Ring"] == nil then E["Smotts' Pinky Ring"] = "Smotts'un Serçe Parmak Yüzüğü" end
if E["Snargl's Snout"] == nil then E["Snargl's Snout"] = "Snargl'ın Burnu" end
if E["Soft Fur-lined Shoes"] == nil then E["Soft Fur-lined Shoes"] = "Yumuşak Kürk Astarlı Ayakkabılar" end
if E["Soldier's Visor"] == nil then E["Soldier's Visor"] = "Askerin Siperliği" end
if E["Solomon's Comfortable Hat"] == nil then E["Solomon's Comfortable Hat"] = "Solomon'un Rahat Şapkası" end
if E["Solomon's Plea to Farholde"] == nil then E["Solomon's Plea to Farholde"] = "Solomon'un Farholde'a Ricası" end
if E["Sonya Darkhallow's Gold Coin"] == nil then E["Sonya Darkhallow's Gold Coin"] = "Sonya Darkhallow'un Altın Sikkesi" end
if E["Sootfur's Pelt"] == nil then E["Sootfur's Pelt"] = "Sootfur'un Postu" end
if E["Sorrow's Shroud"] == nil then E["Sorrow's Shroud"] = "Kederin Kefeni" end
if E["Spectral Magister's Commission"] == nil then E["Spectral Magister's Commission"] = "Hayalet Magisterin Görev Belgesi" end
if E["Spirit-buckle Belt"] == nil then E["Spirit-buckle Belt"] = "Ruh Tokalı Kemer" end
if E["Squire Rowan's Copper Coin"] == nil then E["Squire Rowan's Copper Coin"] = "Silahtar Rowan'ın Bakır Sikkesi" end
if E["Squire's Pants"] == nil then E["Squire's Pants"] = "Silahtarın Pantolonu" end
if E["Staff of Ohk'zi"] == nil then E["Staff of Ohk'zi"] = "Ohk'zi Asası" end
if E["Stag Lord's Bauble"] == nil then E["Stag Lord's Bauble"] = "Geyik Lordunun Biblosu" end
if E["Stalker's Leather Belt"] == nil then E["Stalker's Leather Belt"] = "İz Sürücünün Deri Kemeri" end
if E["Stalker's Leather Gloves"] == nil then E["Stalker's Leather Gloves"] = "İz Sürücünün Deri Eldivenleri" end
if E["Stalker's Mail Belt"] == nil then E["Stalker's Mail Belt"] = "İz Sürücünün Zincir Kemeri" end
if E["Stalker's Mail Boots"] == nil then E["Stalker's Mail Boots"] = "İz Sürücünün Zincir Çizmeleri" end
if E["Stalker's Mail Bracers"] == nil then E["Stalker's Mail Bracers"] = "İz Sürücünün Zincir Bileklikleri" end
if E["Stalker's Mail Gauntlets"] == nil then E["Stalker's Mail Gauntlets"] = "İz Sürücünün Zincir Zırh Eldivenleri" end
if E["Stalker's Mail Sabatons"] == nil then E["Stalker's Mail Sabatons"] = "İz Sürücünün Zincir Zırh Çizmeleri" end
if E["Stalker's Mail Shoulder"] == nil then E["Stalker's Mail Shoulder"] = "İz Sürücünün Zincir Omuzluğu" end
if E["Stalwart Watcher's Signet"] == nil then E["Stalwart Watcher's Signet"] = "Yılmaz Gözcünün Mühür Yüzüğü" end
if E["Steelgrill's Tools"] == nil then E["Steelgrill's Tools"] = "Steelgrill'in Aletleri" end
if E["Stolen Shen'dar Supplies"] == nil then E["Stolen Shen'dar Supplies"] = "Çalınmış Shen'dar Erzakı" end
if E["Stoneanvil's Rifle"] == nil then E["Stoneanvil's Rifle"] = "Stoneanvil'in Tüfeği" end
if E["Stonewalker's Slippers"] == nil then E["Stonewalker's Slippers"] = "Taş Yürüyenin Terlikleri" end
if E["Stormheart's Still-beating Heart"] == nil then E["Stormheart's Still-beating Heart"] = "Stormheart'ın Hâlâ Atan Yüreği" end
if E["Stormrider's Leather Armor"] == nil then E["Stormrider's Leather Armor"] = "Fırtına Süvarisinin Deri Zırhı" end
if E["Stormrider's Leather Belt"] == nil then E["Stormrider's Leather Belt"] = "Fırtına Süvarisinin Deri Kemeri" end
if E["Stormrider's Leather Boots"] == nil then E["Stormrider's Leather Boots"] = "Fırtına Süvarisinin Deri Çizmeleri" end
if E["Stormrider's Leather Gloves"] == nil then E["Stormrider's Leather Gloves"] = "Fırtına Süvarisinin Deri Eldivenleri" end
if E["Stormrider's Leather Helm"] == nil then E["Stormrider's Leather Helm"] = "Fırtına Süvarisinin Deri Miğferi" end
if E["Stormrider's Leather Hood"] == nil then E["Stormrider's Leather Hood"] = "Fırtına Süvarisinin Deri Başlığı" end
if E["Stormrider's Leather Kilt"] == nil then E["Stormrider's Leather Kilt"] = "Fırtına Süvarisinin Deri Eteği" end
if E["Stormrider's Leather Pants"] == nil then E["Stormrider's Leather Pants"] = "Fırtına Süvarisinin Deri Pantolonu" end
if E["Stormrider's Leather Tunic"] == nil then E["Stormrider's Leather Tunic"] = "Fırtına Süvarisinin Deri Tuniği" end
if E["Stormseeker's Girdle"] == nil then E["Stormseeker's Girdle"] = "Fırtına Arayıcının Bel Kuşağı" end
if E["Subdued Dragon's Fang"] == nil then E["Subdued Dragon's Fang"] = "Boyun Eğdirilmiş Ejderhanın Dişi" end
if E["Summoner's Salt"] == nil then E["Summoner's Salt"] = "Çağırıcının Tuzu" end
if E["Sun-Bleached Bone"] == nil then E["Sun-Bleached Bone"] = "Güneşte Ağarmış Kemik" end
if E["Sun-beaten Cloak"] == nil then E["Sun-beaten Cloak"] = "Güneşte Yıpranmış Pelerin" end
if E["Sunhammer's Rifle"] == nil then E["Sunhammer's Rifle"] = "Sunhammer'ın Tüfeği" end
if E["Superior Mender's Potion"] == nil then E["Superior Mender's Potion"] = "Üstün Onarıcı İksiri" end
if E["Supply Shipment: Copper Bars"] == nil then E["Supply Shipment: Copper Bars"] = "Erzak Sevkiyatı: Bakır Külçeler" end
if E["Survivor's Amulet"] == nil then E["Survivor's Amulet"] = "Hayatta Kalanın Muskası" end
if E["Survivor's Torch"] == nil then E["Survivor's Torch"] = "Hayatta Kalanın Meşalesi" end
if E["Sutara's Lasso"] == nil then E["Sutara's Lasso"] = "Sutara'nın Kementi" end
if E["Swamp Roamer's Band"] == nil then E["Swamp Roamer's Band"] = "Bataklık Gezgininin Yüzüğü" end
if E["Swarmtender's Cord"] == nil then E["Swarmtender's Cord"] = "Sürü Bakıcısının İp Kuşağı" end
if E["Swarmtender's Footpads"] == nil then E["Swarmtender's Footpads"] = "Sürü Bakıcısının Ayak Pedleri" end
if E["Swarmtender's Gloves"] == nil then E["Swarmtender's Gloves"] = "Sürü Bakıcısının Eldivenleri" end
if E["Sweat-Stained Shirt"] == nil then E["Sweat-Stained Shirt"] = "Ter Lekeli Gömlek" end
if E["Swineherd's Staff"] == nil then E["Swineherd's Staff"] = "Domuz Çobanının Asası" end
if E["Sylvanas Windrunner's Gold Coin"] == nil then E["Sylvanas Windrunner's Gold Coin"] = "Sylvanas Windrunner'ın Altın Sikkesi" end
if E["Syndicate Executioner's Slicer"] == nil then E["Syndicate Executioner's Slicer"] = "Syndicate Celladının Doğrayıcısı" end
if E["Tabitha's Cuffs"] == nil then E["Tabitha's Cuffs"] = "Tabitha'nın Kollukları" end
if E["Tale of I'lalai in Zandali"] == nil then E["Tale of I'lalai in Zandali"] = "Zandali Dilinde I'lalai Masalı" end
if E["Taleen's Offering"] == nil then E["Taleen's Offering"] = "Taleen'in Adağı" end
if E["Tallonkai's Jewel"] == nil then E["Tallonkai's Jewel"] = "Tallonkai'nin Mücevheri" end
if E["Taurenbane's Family Cleaver"] == nil then E["Taurenbane's Family Cleaver"] = "Taurenbane'in Aile Satırı" end
if E["Tazzik's Sweaty Shirt"] == nil then E["Tazzik's Sweaty Shirt"] = "Tazzik'in Terli Gömleği" end
if E["Technician's Bracers"] == nil then E["Technician's Bracers"] = "Teknisyenin Bileklikleri" end
if E["Tel'Abim Plantains"] == nil then E["Tel'Abim Plantains"] = "Tel'Abim Muzları" end
if E["Tenn's Road-Worn Flute"] == nil then E["Tenn's Road-Worn Flute"] = "Tenn'in Yoldan Yıpranmış Flütü" end
if E["Tessa's Tonic"] == nil then E["Tessa's Tonic"] = "Tessa'nın Toniği" end
if E["Thaddius' Lightning Bolts"] == nil then E["Thaddius' Lightning Bolts"] = "Thaddius'un Yıldırımları" end
if E["Thaelemaches' Talisman"] == nil then E["Thaelemaches' Talisman"] = "Thaelemaches'in Tılsımı" end
if E["Thane's Hammer"] == nil then E["Thane's Hammer"] = "Thane'in Çekici" end
if E["Thazz'ril's Pick"] == nil then E["Thazz'ril's Pick"] = "Thazz'ril'in Kazması" end
if E["The Apothecary's Metaphysical Primer"] == nil then E["The Apothecary's Metaphysical Primer"] = "Eczacının Metafizik El Kitabı" end
if E["The Coldbringer's Eye"] == nil then E["The Coldbringer's Eye"] = "Soğuk Getirenin Gözü" end
if E["The Collector's Ring"] == nil then E["The Collector's Ring"] = "Koleksiyoncunun Yüzüğü" end
if E["The Collector's Schedule"] == nil then E["The Collector's Schedule"] = "Koleksiyoncunun Programı" end
if E["The Dalaran Digest, Vol. 23"] == nil then E["The Dalaran Digest, Vol. 23"] = "Dalaran Özeti, Cilt 23" end
if E["The First Tablet of I'lalai"] == nil then E["The First Tablet of I'lalai"] = "I'lalai'nin Birinci Tableti" end
if E["The Fourth Tablet of I'lalai"] == nil then E["The Fourth Tablet of I'lalai"] = "I'lalai'nin Dördüncü Tableti" end
if E["The Lessons of Ta'zo"] == nil then E["The Lessons of Ta'zo"] = "Ta'zo'nun Dersleri" end
if E["The Second Tablet of I'lalai"] == nil then E["The Second Tablet of I'lalai"] = "I'lalai'nin İkinci Tableti" end
if E["The Third Tablet of I'lalai"] == nil then E["The Third Tablet of I'lalai"] = "I'lalai'nin Üçüncü Tableti" end
if E["Theka's Last Breath"] == nil then E["Theka's Last Breath"] = "Theka'nın Son Nefesi" end
if E["Thendal Apprentice's Boots"] == nil then E["Thendal Apprentice's Boots"] = "Thendal Çırak Çizmeleri" end
if E["Thendal Apprentice's Pants"] == nil then E["Thendal Apprentice's Pants"] = "Thendal Çırak Pantolonu" end
if E["Thendal Apprentice's Shirt"] == nil then E["Thendal Apprentice's Shirt"] = "Thendal Çırak Gömleği" end
if E["Thendal Novice's Boots"] == nil then E["Thendal Novice's Boots"] = "Thendal Acemi Çizmeleri" end
if E["Thendal Novice's Pants"] == nil then E["Thendal Novice's Pants"] = "Thendal Acemi Pantolonu" end
if E["Thendal Novice's Shirt"] == nil then E["Thendal Novice's Shirt"] = "Thendal Acemi Gömleği" end
if E["Thendal Ranger's Belt"] == nil then E["Thendal Ranger's Belt"] = "Thendal Korucu Kemeri" end
if E["Thendal Ranger's Gloves"] == nil then E["Thendal Ranger's Gloves"] = "Thendal Korucu Eldivenleri" end
if E["Thendal Ranger's Shoes"] == nil then E["Thendal Ranger's Shoes"] = "Thendal Korucu Ayakkabıları" end
if E["Thendal Survivalist's Boots"] == nil then E["Thendal Survivalist's Boots"] = "Thendal Sağkalımcı Çizmeleri" end
if E["Thendal Survivalist's Pants"] == nil then E["Thendal Survivalist's Pants"] = "Thendal Sağkalımcı Pantolonu" end
if E["Thendal Survivalist's Shirt"] == nil then E["Thendal Survivalist's Shirt"] = "Thendal Sağkalımcı Gömleği" end
if E["Thendal Warrior's Boots"] == nil then E["Thendal Warrior's Boots"] = "Thendal Savaşçı Çizmeleri" end
if E["Thendal Warrior's Pants"] == nil then E["Thendal Warrior's Pants"] = "Thendal Savaşçı Pantolonu" end
if E["Thendal Warrior's Shirt"] == nil then E["Thendal Warrior's Shirt"] = "Thendal Savaşçı Gömleği" end
if E["Thendal Watcher's Belt"] == nil then E["Thendal Watcher's Belt"] = "Thendal Gözcü Kemeri" end
if E["Thendal Watcher's Boots"] == nil then E["Thendal Watcher's Boots"] = "Thendal Gözcü Çizmeleri" end
if E["Thendal Watcher's Gloves"] == nil then E["Thendal Watcher's Gloves"] = "Thendal Gözcü Eldivenleri" end
if E["Thendal Watcher's Leggings"] == nil then E["Thendal Watcher's Leggings"] = "Thendal Gözcü Tozlukları" end
if E["Thendal Watcher's Vest"] == nil then E["Thendal Watcher's Vest"] = "Thendal Gözcü Yeleği" end
if E["Thick Ogre's Belt"] == nil then E["Thick Ogre's Belt"] = "Kalın Ogre Kemeri" end
if E["Thisalee's Whistle"] == nil then E["Thisalee's Whistle"] = "Thisalee'nin Düdüğü" end
if E["Thomas's Ring"] == nil then E["Thomas's Ring"] = "Thomas'ın Yüzüğü" end
if E["Thra's Friendship Bracelet"] == nil then E["Thra's Friendship Bracelet"] = "Thra'nın Arkadaşlık Bilekliği" end
if E["Thrall's Gold Coin"] == nil then E["Thrall's Gold Coin"] = "Thrall'ın Altın Sikkesi" end
if E["Thrash's Trash"] == nil then E["Thrash's Trash"] = "Thrash'in Çöpü" end
if E["Thrice-Damned Effigy"] == nil then E["Thrice-Damned Effigy"] = "Üç Kez Lanetli Kukla" end
if E["Thrice-Stitched Flesh"] == nil then E["Thrice-Stitched Flesh"] = "Üç Kez Dikilmiş Et" end
if E["Thule's Head"] == nil then E["Thule's Head"] = "Thule'un Kafası" end
if E["Thunderhorn's Report"] == nil then E["Thunderhorn's Report"] = "Thunderhorn'un Raporu" end
if E["Thunderstomp's Horn"] == nil then E["Thunderstomp's Horn"] = "Thunderstomp'un Boynuzu" end
if E["Thundris' Letter"] == nil then E["Thundris' Letter"] = "Thundris'in Mektubu" end
if E["Thurman's Letter"] == nil then E["Thurman's Letter"] = "Thurman'ın Mektubu" end
if E["Thurman's Remains"] == nil then E["Thurman's Remains"] = "Thurman'ın Kalıntıları" end
if E["Ti'ik's Head"] == nil then E["Ti'ik's Head"] = "Ti'ik'in Kafası" end
if E["Ti'ik's Tattered Trousers"] == nil then E["Ti'ik's Tattered Trousers"] = "Ti'ik'in Yırtık Şalvarı" end
if E["Tidebringer's Claw"] == nil then E["Tidebringer's Claw"] = "Gelgit Getirenin Pençesi" end
if E["Tigule's Strawberry Ice Cream"] == nil then E["Tigule's Strawberry Ice Cream"] = "Tigule'ün Çilekli Dondurması" end
if E["Tiller's Vest"] == nil then E["Tiller's Vest"] = "Çiftçinin Yeleği" end
if E["Tim's Lost Rib"] == nil then E["Tim's Lost Rib"] = "Tim'in Kayıp Kaburgası" end
if E["Timeless Wanderer's Insights"] == nil then E["Timeless Wanderer's Insights"] = "Zamansız Gezginin Sezgileri" end
if E["Tinkerbox: Magnetic Displacement"] == nil then E["Tinkerbox: Magnetic Displacement"] = "Tamirci Kutusu: Manyetik Yer Değiştirme" end
if E["Tinkerbox: Nitro Boosts"] == nil then E["Tinkerbox: Nitro Boosts"] = "Tamirci Kutusu: Nitro Hızlandırıcılar" end
if E["Tinkerbox: Teleport"] == nil then E["Tinkerbox: Teleport"] = "Tamirci Kutusu: Işınlanma" end
if E["Tirion Fordring's Gold Coin"] == nil then E["Tirion Fordring's Gold Coin"] = "Tirion Fordring'in Altın Sikkesi" end
if E["Tom's Gift"] == nil then E["Tom's Gift"] = "Tom'un Hediyesi" end
if E["Tomb Robber's Gloves"] == nil then E["Tomb Robber's Gloves"] = "Mezar Soyguncusunun Eldivenleri" end
if E["Top-Left Map Piece"] == nil then E["Top-Left Map Piece"] = "Sol Üst Harita Parçası" end
if E["Top-Right Map Piece"] == nil then E["Top-Right Map Piece"] = "Sağ Üst Harita Parçası" end
if E["Tough Guy's Eyepatch"] == nil then E["Tough Guy's Eyepatch"] = "Sert Adamın Göz Bandı" end
if E["Town Clerk's Mittens"] == nil then E["Town Clerk's Mittens"] = "Kasaba Kâtibinin Parmaksız Eldivenleri" end
if E["Tracker's Pants"] == nil then E["Tracker's Pants"] = "İz Sürücünün Pantolonu" end
if E["Translated Tale of I'lalai"] == nil then E["Translated Tale of I'lalai"] = "I'lalai'nin Çevrilmiş Hikâyesi" end
if E["Trapclaw's Pincer"] == nil then E["Trapclaw's Pincer"] = "Trapclaw'ın Kıskacı" end
if E["Trapper's Leather Armor"] == nil then E["Trapper's Leather Armor"] = "Tuzakçının Deri Zırhı" end
if E["Trapper's Leather Belt"] == nil then E["Trapper's Leather Belt"] = "Tuzakçının Deri Kemeri" end
if E["Trapper's Leather Boots"] == nil then E["Trapper's Leather Boots"] = "Tuzakçının Deri Çizmeleri" end
if E["Trapper's Leather Gloves"] == nil then E["Trapper's Leather Gloves"] = "Tuzakçının Deri Eldivenleri" end
if E["Trapper's Leather Helm"] == nil then E["Trapper's Leather Helm"] = "Tuzakçının Deri Miğferi" end
if E["Trapper's Leather Hood"] == nil then E["Trapper's Leather Hood"] = "Tuzakçının Deri Başlığı" end
if E["Trapper's Leather Legguards"] == nil then E["Trapper's Leather Legguards"] = "Tuzakçının Deri Bacak Korumaları" end
if E["Trapper's Leather Pants"] == nil then E["Trapper's Leather Pants"] = "Tuzakçının Deri Pantolonu" end
if E["Trapper's Leather Tunic"] == nil then E["Trapper's Leather Tunic"] = "Tuzakçının Deri Tuniği" end
if E["Trapper's Pants"] == nil then E["Trapper's Pants"] = "Tuzakçının Pantolonu" end
if E["Trapper's Workbench"] == nil then E["Trapper's Workbench"] = "Tuzakçı Tezgâhı" end
if E["Traveler's Shawl"] == nil then E["Traveler's Shawl"] = "Yolcunun Şalı" end
if E["Traveler's Symbols"] == nil then E["Traveler's Symbols"] = "Yolcunun Sembolleri" end
if E["Traveler's Wraps"] == nil then E["Traveler's Wraps"] = "Yolcunun Sargıları" end
if E["Trevan's Weapon Notes"] == nil then E["Trevan's Weapon Notes"] = "Trevan'ın Silah Notları" end
if E["Trogg's Lucky Rock"] == nil then E["Trogg's Lucky Rock"] = "Trogg'un Uğurlu Taşı" end
if E["Troll's Pendant"] == nil then E["Troll's Pendant"] = "Troll'ün Kolyesi" end
if E["Tru-Trigger Frag Bomb"] == nil then E["Tru-Trigger Frag Bomb"] = "Tam Tetik Parça Bombası" end
if E["Truesong's Hammer"] == nil then E["Truesong's Hammer"] = "Truesong'un Çekici" end
if E["Truskis' Cheesecake Slice"] == nil then E["Truskis' Cheesecake Slice"] = "Truskis'in Cheesecake Dilimi" end
if E["Truthseeker's Bow"] == nil then E["Truthseeker's Bow"] = "Hakikat Arayanın Yayı" end
if E["Tuft of Renalard's Fur"] == nil then E["Tuft of Renalard's Fur"] = "Renalard'ın Kürk Tutamı" end
if E["Tunneler's Incense"] == nil then E["Tunneler's Incense"] = "Tünelcinin Tütsüsü" end
if E["Twice-Spiced Raptor Slice"] == nil then E["Twice-Spiced Raptor Slice"] = "Çift Baharatlı Raptor Dilimi" end
if E["Twilight Initiate's Belt"] == nil then E["Twilight Initiate's Belt"] = "Alacakaranlık Müridinin Kemeri" end
if E["Twin's Pact"] == nil then E["Twin's Pact"] = "İkizin Ahdi" end
if E["Tyler's Balanced Bobble"] == nil then E["Tyler's Balanced Bobble"] = "Tyler'ın Dengeli Şamandırası" end
if E["Ukor's Burden"] == nil then E["Ukor's Burden"] = "Ukor'un Yükü" end
if E["Ukor's Lost Pack"] == nil then E["Ukor's Lost Pack"] = "Ukor'un Kayıp Çantası" end
if E["Ukta's Conduit"] == nil then E["Ukta's Conduit"] = "Ukta'nın Kanalı" end
if E["Umbrinoth's Gold Coin"] == nil then E["Umbrinoth's Gold Coin"] = "Umbrinoth'un Altın Sikkesi" end
if E["Un'Goro Tested Sample"] == nil then E["Un'Goro Tested Sample"] = "Un'Goro Test Edilmiş Numune" end
if E["Uncle's Heroism"] == nil then E["Uncle's Heroism"] = "Amcanın Kahramanlığı" end
if E["Undead Knight's Bracers"] == nil then E["Undead Knight's Bracers"] = "Ölümsüz Şövalyenin Bileklikleri" end
if E["Urchin's Pants"] == nil then E["Urchin's Pants"] = "Sokak Çocuğunun Pantolonu" end
if E["Ursol'lok's Paws"] == nil then E["Ursol'lok's Paws"] = "Ursol'lok'un Patileri" end
if E["Uthek's Draenethyst Staff"] == nil then E["Uthek's Draenethyst Staff"] = "Uthek'in Draenethyst Asası" end
if E["Uthek's Staff"] == nil then E["Uthek's Staff"] = "Uthek'in Asası" end
if E["Uther Lightbringer's Gold Coin"] == nil then E["Uther Lightbringer's Gold Coin"] = "Uther Lightbringer'ın Altın Sikkesi" end
if E["Uthil's Cudgel"] == nil then E["Uthil's Cudgel"] = "Uthil'in Sopası" end
if E["Valdred's Hands"] == nil then E["Valdred's Hands"] = "Valdred'in Elleri" end
if E["Valdrus Blackthorne's Gold Coin"] == nil then E["Valdrus Blackthorne's Gold Coin"] = "Valdrus Blackthorne'un Altın Sikkesi" end
if E["Valiant's Waistguard"] == nil then E["Valiant's Waistguard"] = "Yiğidin Bel Koruması" end
if E["Vargoth's Copper Coin"] == nil then E["Vargoth's Copper Coin"] = "Vargoth'un Bakır Sikkesi" end
if E["Velvet of Kala'th's Horn"] == nil then E["Velvet of Kala'th's Horn"] = "Kala'th'ın Boynuzunun Kadifesi" end
if E["Venom-dripping Heart"] == nil then E["Venom-dripping Heart"] = "Zehir Damlayan Kalp" end
if E["Venture Co. Documents"] == nil then E["Venture Co. Documents"] = "Venture Co. Belgeleri" end
if E["Venture Co. Work Order"] == nil then E["Venture Co. Work Order"] = "Venture Co. İş Emri" end
if E["Vessel Ward - Fel Ash Experimentation Notes"] == nil then E["Vessel Ward - Fel Ash Experimentation Notes"] = "Kap Koruması - Fel Külü Deney Notları" end
if E["Veteran Adventurer's Belt"] == nil then E["Veteran Adventurer's Belt"] = "Kıdemli Maceracının Kemeri" end
if E["Veteran Adventurer's Boots"] == nil then E["Veteran Adventurer's Boots"] = "Kıdemli Maceracının Çizmeleri" end
if E["Veteran Adventurer's Bracer"] == nil then E["Veteran Adventurer's Bracer"] = "Kıdemli Maceracının Bilekliği" end
if E["Veteran Adventurer's Chestpiece"] == nil then E["Veteran Adventurer's Chestpiece"] = "Kıdemli Maceracının Göğüs Zırhı" end
if E["Veteran Adventurer's Cloak"] == nil then E["Veteran Adventurer's Cloak"] = "Kıdemli Maceracının Pelerini" end
if E["Veteran Adventurer's Gloves"] == nil then E["Veteran Adventurer's Gloves"] = "Kıdemli Maceracının Eldivenleri" end
if E["Veteran Adventurer's Hood"] == nil then E["Veteran Adventurer's Hood"] = "Kıdemli Maceracının Başlığı" end
if E["Veteran Adventurer's Legguards"] == nil then E["Veteran Adventurer's Legguards"] = "Kıdemli Maceracının Bacak Korumaları" end
if E["Veteran Adventurer's Loyal Companion"] == nil then E["Veteran Adventurer's Loyal Companion"] = "Kıdemli Maceracının Sadık Yoldaşı" end
if E["Veteran Adventurer's Rucksack"] == nil then E["Veteran Adventurer's Rucksack"] = "Kıdemli Maceracının Sırt Çantası" end
if E["Veteran Adventurer's Shoulderpads"] == nil then E["Veteran Adventurer's Shoulderpads"] = "Kıdemli Maceracının Omuz Yastıkları" end
if E["Veteran's Boots"] == nil then E["Veteran's Boots"] = "Emektarın Çizmeleri" end
if E["Veteran's Chain Belt"] == nil then E["Veteran's Chain Belt"] = "Emektarın Zincir Kemeri" end
if E["Veteran's Chain Helm"] == nil then E["Veteran's Chain Helm"] = "Emektarın Zincir Miğferi" end
if E["Veteran's Chain Leggings"] == nil then E["Veteran's Chain Leggings"] = "Emektarın Zincir Tozlukları" end
if E["Veteran's Chain Shirt"] == nil then E["Veteran's Chain Shirt"] = "Emektarın Zincir Gömleği" end
if E["Veteran's Gloves"] == nil then E["Veteran's Gloves"] = "Emektarın Eldivenleri" end
if E["Veteran's Silvered Chain Helm"] == nil then E["Veteran's Silvered Chain Helm"] = "Emektarın Gümüşlü Zincir Miğferi" end
if E["Veteran's Silvered Chain Leggings"] == nil then E["Veteran's Silvered Chain Leggings"] = "Emektarın Gümüşlü Zincir Tozlukları" end
if E["Veteran's Silvered Chain Shirt"] == nil then E["Veteran's Silvered Chain Shirt"] = "Emektarın Gümüşlü Zincir Gömleği" end
if E["Vick's VIP Pass"] == nil then E["Vick's VIP Pass"] = "Vick'in VIP Kartı" end
if E["Vigilant Watcher's Signet"] == nil then E["Vigilant Watcher's Signet"] = "Uyanık Gözcünün Mühür Yüzüğü" end
if E["Vindael's Spectral Pickaxe"] == nil then E["Vindael's Spectral Pickaxe"] = "Vindael'in Hayalet Kazması" end
if E["Vindicator's Belt"] == nil then E["Vindicator's Belt"] = "Haklı Çıkaranın Kemeri" end
if E["Vine Pruner's Cloak"] == nil then E["Vine Pruner's Cloak"] = "Bağ Budayıcısının Pelerini" end
if E["Vine-Wrapped Scroll"] == nil then E["Vine-Wrapped Scroll"] = "Sarmaşık Sarılı Parşömen" end
if E["Violet Sorcerer's Leggings"] == nil then E["Violet Sorcerer's Leggings"] = "Mor Sihirbazın Tozlukları" end
if E["Violet Sorcerer's Mantle"] == nil then E["Violet Sorcerer's Mantle"] = "Mor Sihirbazın Omuz Örtüsü" end
if E["Violet Sorcerer's Robes"] == nil then E["Violet Sorcerer's Robes"] = "Mor Sihirbazın Cüppesi" end
if E["Violet Sorcerer's Sandals"] == nil then E["Violet Sorcerer's Sandals"] = "Mor Sihirbazın Sandaletleri" end
if E["Violet Sorcerer's Wraps"] == nil then E["Violet Sorcerer's Wraps"] = "Mor Sihirbazın Sargıları" end
if E["Volunteer's Lucky Seal"] == nil then E["Volunteer's Lucky Seal"] = "Gönüllünün Uğurlu Mührü" end
if E["Voodoo-Infused Artifact"] == nil then E["Voodoo-Infused Artifact"] = "Vudu Aşılanmış Eser" end
if E["Vulgara's Head"] == nil then E["Vulgara's Head"] = "Vulgara'nın Kafası" end
if E["Walton's Second-Favorite Gun"] == nil then E["Walton's Second-Favorite Gun"] = "Walton'ın İkinci En Sevdiği Tüfek" end
if E["Wanderer's Broadsword"] == nil then E["Wanderer's Broadsword"] = "Gezginin Geniş Kılıcı" end
if E["Warden's Leather Belt"] == nil then E["Warden's Leather Belt"] = "Bekçinin Deri Kemeri" end
if E["Warden's Leather Boots"] == nil then E["Warden's Leather Boots"] = "Bekçinin Deri Çizmeleri" end
if E["Warden's Leather Bracers"] == nil then E["Warden's Leather Bracers"] = "Bekçinin Deri Bileklikleri" end
if E["Warden's Leather Gauntlets"] == nil then E["Warden's Leather Gauntlets"] = "Bekçinin Deri Zırhlı Eldivenleri" end
if E["Warden's Leather Gloves"] == nil then E["Warden's Leather Gloves"] = "Bekçinin Deri Eldivenleri" end
if E["Warden's Leather Shoes"] == nil then E["Warden's Leather Shoes"] = "Bekçinin Deri Ayakkabıları" end
if E["Warden's Leather Shoulder"] == nil then E["Warden's Leather Shoulder"] = "Bekçinin Deri Omuzluğu" end
if E["Warden's Leather Waistguard"] == nil then E["Warden's Leather Waistguard"] = "Bekçinin Deri Bel Koruması" end
if E["Warder's Belt"] == nil then E["Warder's Belt"] = "Gardiyanın Kemeri" end
if E["Warder's Boots"] == nil then E["Warder's Boots"] = "Gardiyanın Çizmeleri" end
if E["Warder's Gauntlet"] == nil then E["Warder's Gauntlet"] = "Gardiyanın Eldiveni" end
if E["Warder's Gloves"] == nil then E["Warder's Gloves"] = "Gardiyanın Eldivenleri" end
if E["Warder's Pauldrons"] == nil then E["Warder's Pauldrons"] = "Gardiyanın Omuz Zırhları" end
if E["Warder's Sabatons"] == nil then E["Warder's Sabatons"] = "Gardiyanın Zırh Pabuçları" end
if E["Warder's Waistguard"] == nil then E["Warder's Waistguard"] = "Gardiyanın Bel Koruması" end
if E["Warder's Wristguards"] == nil then E["Warder's Wristguards"] = "Gardiyanın Bilek Korumaları" end
if E["Warglaive of Azzinoth (Left)"] == nil then E["Warglaive of Azzinoth (Left)"] = "Azzinoth'un Savaş Kılıcı (Sol)" end
if E["Warglaive of Azzinoth (Right)"] == nil then E["Warglaive of Azzinoth (Right)"] = "Azzinoth'un Savaş Kılıcı (Sağ)" end
if E["Warleader's Signet"] == nil then E["Warleader's Signet"] = "Savaş Önderinin Mühür Yüzüğü" end
if E["Watcher's Eye"] == nil then E["Watcher's Eye"] = "Gözcünün Gözü" end
if E["Watcher's Mail Chest"] == nil then E["Watcher's Mail Chest"] = "Gözcünün Örgü Göğüslüğü" end
if E["Waylaid Crate: Apprentice Curiosities"] == nil then E["Waylaid Crate: Apprentice Curiosities"] = "Yolda Kalmış Sandık: Çırak Tuhaflıklar" end
if E["Waylaid Crate: Apprentice Fabrics"] == nil then E["Waylaid Crate: Apprentice Fabrics"] = "Yolda Kalmış Sandık: Çırak Kumaşlar" end
if E["Waylaid Crate: Apprentice Herbs"] == nil then E["Waylaid Crate: Apprentice Herbs"] = "Yolda Kalmış Sandık: Çırak Bitkiler" end
if E["Waylaid Crate: Apprentice Ingots"] == nil then E["Waylaid Crate: Apprentice Ingots"] = "Yolda Kalmış Sandık: Çırak Külçeler" end
if E["Waylaid Crate: Apprentice Ore"] == nil then E["Waylaid Crate: Apprentice Ore"] = "Yolda Kalmış Sandık: Çırak Cevher" end
if E["Waylaid Crate: Apprentice Parts"] == nil then E["Waylaid Crate: Apprentice Parts"] = "Yolda Kalmış Sandık: Çırak Parçalar" end
if E["Waylaid Crate: Apprentice Textiles"] == nil then E["Waylaid Crate: Apprentice Textiles"] = "Yolda Kalmış Sandık: Çırak Dokumalar" end
if E["Waylaid Crate: Artisan Curiosities"] == nil then E["Waylaid Crate: Artisan Curiosities"] = "Yolda Kalmış Sandık: Usta Tuhaflıklar" end
if E["Waylaid Crate: Artisan Fabrics"] == nil then E["Waylaid Crate: Artisan Fabrics"] = "Yolda Kalmış Sandık: Usta Kumaşlar" end
if E["Waylaid Crate: Artisan Ingots"] == nil then E["Waylaid Crate: Artisan Ingots"] = "Yolda Kalmış Sandık: Usta Külçeler" end
if E["Waylaid Crate: Artisan Ore"] == nil then E["Waylaid Crate: Artisan Ore"] = "Yolda Kalmış Sandık: Usta Cevher" end
if E["Waylaid Crate: Artisan Parts"] == nil then E["Waylaid Crate: Artisan Parts"] = "Yolda Kalmış Sandık: Usta Parçalar" end
if E["Waylaid Crate: Artisan Textiles"] == nil then E["Waylaid Crate: Artisan Textiles"] = "Yolda Kalmış Sandık: Usta Dokumalar" end
if E["Waylaid Crate: Earthly Artisan Herbs"] == nil then E["Waylaid Crate: Earthly Artisan Herbs"] = "Yolda Kalmış Sandık: Usta Toprak Bitkiler" end
if E["Waylaid Crate: Earthly Expert Herbs"] == nil then E["Waylaid Crate: Earthly Expert Herbs"] = "Yolda Kalmış Sandık: Uzman Toprak Bitkiler" end
if E["Waylaid Crate: Expert Curiosities"] == nil then E["Waylaid Crate: Expert Curiosities"] = "Yolda Kalmış Sandık: Uzman Tuhaflıklar" end
if E["Waylaid Crate: Expert Fabrics"] == nil then E["Waylaid Crate: Expert Fabrics"] = "Yolda Kalmış Sandık: Uzman Kumaşlar" end
if E["Waylaid Crate: Expert Ingots"] == nil then E["Waylaid Crate: Expert Ingots"] = "Yolda Kalmış Sandık: Uzman Külçeler" end
if E["Waylaid Crate: Expert Ore"] == nil then E["Waylaid Crate: Expert Ore"] = "Yolda Kalmış Sandık: Uzman Cevher" end
if E["Waylaid Crate: Expert Parts"] == nil then E["Waylaid Crate: Expert Parts"] = "Yolda Kalmış Sandık: Uzman Parçalar" end
if E["Waylaid Crate: Expert Textiles"] == nil then E["Waylaid Crate: Expert Textiles"] = "Yolda Kalmış Sandık: Uzman Dokumalar" end
if E["Waylaid Crate: Flowering Artisan Herbs"] == nil then E["Waylaid Crate: Flowering Artisan Herbs"] = "Yolda Kalmış Sandık: Usta Çiçekli Bitkiler" end
if E["Waylaid Crate: Flowering Expert Herbs"] == nil then E["Waylaid Crate: Flowering Expert Herbs"] = "Yolda Kalmış Sandık: Uzman Çiçekli Bitkiler" end
if E["Waylaid Crate: Journeyman Curiosities"] == nil then E["Waylaid Crate: Journeyman Curiosities"] = "Yolda Kalmış Sandık: Kalfa Tuhaflıklar" end
if E["Waylaid Crate: Journeyman Fabrics"] == nil then E["Waylaid Crate: Journeyman Fabrics"] = "Yolda Kalmış Sandık: Kalfa Kumaşlar" end
if E["Waylaid Crate: Journeyman Herbs"] == nil then E["Waylaid Crate: Journeyman Herbs"] = "Yolda Kalmış Sandık: Kalfa Bitkiler" end
if E["Waylaid Crate: Journeyman Ingots"] == nil then E["Waylaid Crate: Journeyman Ingots"] = "Yolda Kalmış Sandık: Kalfa Külçeler" end
if E["Waylaid Crate: Journeyman Ore"] == nil then E["Waylaid Crate: Journeyman Ore"] = "Yolda Kalmış Sandık: Kalfa Cevher" end
if E["Waylaid Crate: Journeyman Parts"] == nil then E["Waylaid Crate: Journeyman Parts"] = "Yolda Kalmış Sandık: Kalfa Parçalar" end
if E["Waylaid Crate: Journeyman Textiles"] == nil then E["Waylaid Crate: Journeyman Textiles"] = "Yolda Kalmış Sandık: Kalfa Dokumalar" end
if E["Waylaid Supplies: Barbaric Shoulders"] == nil then E["Waylaid Supplies: Barbaric Shoulders"] = "Yolda Kalmış Erzak: Barbar Omuzluklar" end
if E["Waylaid Supplies: Big Iron Bombs"] == nil then E["Waylaid Supplies: Big Iron Bombs"] = "Yolda Kalmış Erzak: Büyük Demir Bombalar" end
if E["Waylaid Supplies: Black Mageweave Headbands"] == nil then E["Waylaid Supplies: Black Mageweave Headbands"] = "Yolda Kalmış Erzak: Siyah Büyüdokuma Saç Bantları" end
if E["Waylaid Supplies: Brilliant Smallfish"] == nil then E["Waylaid Supplies: Brilliant Smallfish"] = "Yolda Kalmış Erzak: Parlak Küçük Balık" end
if E["Waylaid Supplies: Bronze Bars"] == nil then E["Waylaid Supplies: Bronze Bars"] = "Yolda Kalmış Erzak: Bronz Külçeler" end
if E["Waylaid Supplies: Brown Linen Pants"] == nil then E["Waylaid Supplies: Brown Linen Pants"] = "Yolda Kalmış Erzak: Kahverengi Keten Pantolonlar" end
if E["Waylaid Supplies: Brown Linen Robes"] == nil then E["Waylaid Supplies: Brown Linen Robes"] = "Yolda Kalmış Erzak: Kahverengi Keten Cüppeler" end
if E["Waylaid Supplies: Bruiseweed"] == nil then E["Waylaid Supplies: Bruiseweed"] = "Yolda Kalmış Erzak: Bruiseweed" end
if E["Waylaid Supplies: Compact Harvest Reaper Kits"] == nil then E["Waylaid Supplies: Compact Harvest Reaper Kits"] = "Yolda Kalmış Erzak: Kompakt Hasat Biçici Takımları" end
if E["Waylaid Supplies: Copper Bars"] == nil then E["Waylaid Supplies: Copper Bars"] = "Yolda Kalmış Erzak: Bakır Külçeler" end
if E["Waylaid Supplies: Copper Shortswords"] == nil then E["Waylaid Supplies: Copper Shortswords"] = "Yolda Kalmış Erzak: Bakır Kısa Kılıçlar" end
if E["Waylaid Supplies: Crimson Silk Pantaloons"] == nil then E["Waylaid Supplies: Crimson Silk Pantaloons"] = "Yolda Kalmış Erzak: Kızıl İpek Şalvarlar" end
if E["Waylaid Supplies: Dark Leather Cloaks"] == nil then E["Waylaid Supplies: Dark Leather Cloaks"] = "Yolda Kalmış Erzak: Koyu Deri Pelerinler" end
if E["Waylaid Supplies: Deadly Scopes"] == nil then E["Waylaid Supplies: Deadly Scopes"] = "Yolda Kalmış Erzak: Ölümcül Dürbünler" end
if E["Waylaid Supplies: Dreamfoil"] == nil then E["Waylaid Supplies: Dreamfoil"] = "Yolda Kalmış Erzak: Dreamfoil" end
if E["Waylaid Supplies: Dusky Belts"] == nil then E["Waylaid Supplies: Dusky Belts"] = "Yolda Kalmış Erzak: Alacakaranlık Kemerleri" end
if E["Waylaid Supplies: Elixir of Firepower"] == nil then E["Waylaid Supplies: Elixir of Firepower"] = "Yolda Kalmış Erzak: Ateş Gücü İksiri" end
if E["Waylaid Supplies: Elixirs of Agility"] == nil then E["Waylaid Supplies: Elixirs of Agility"] = "Yolda Kalmış Erzak: Çeviklik İksirleri" end
if E["Waylaid Supplies: Elixirs of Greater Defense"] == nil then E["Waylaid Supplies: Elixirs of Greater Defense"] = "Yolda Kalmış Erzak: Büyük Savunma İksirleri" end
if E["Waylaid Supplies: Embossed Leather Vests"] == nil then E["Waylaid Supplies: Embossed Leather Vests"] = "Yolda Kalmış Erzak: Kabartmalı Deri Yelekler" end
if E["Waylaid Supplies: Enchanted Thorium Bars"] == nil then E["Waylaid Supplies: Enchanted Thorium Bars"] = "Yolda Kalmış Erzak: Efsunlu Toryum Külçeler" end
if E["Waylaid Supplies: Fadeleaf"] == nil then E["Waylaid Supplies: Fadeleaf"] = "Yolda Kalmış Erzak: Fadeleaf" end
if E["Waylaid Supplies: Fire Oil"] == nil then E["Waylaid Supplies: Fire Oil"] = "Yolda Kalmış Erzak: Ateş Yağı" end
if E["Waylaid Supplies: Formal White Shirts"] == nil then E["Waylaid Supplies: Formal White Shirts"] = "Yolda Kalmış Erzak: Resmi Beyaz Gömlekler" end
if E["Waylaid Supplies: Frost Leather Cloaks"] == nil then E["Waylaid Supplies: Frost Leather Cloaks"] = "Yolda Kalmış Erzak: Ayaz Derisi Pelerinler" end
if E["Waylaid Supplies: Gnomish Rocket Boots"] == nil then E["Waylaid Supplies: Gnomish Rocket Boots"] = "Yolda Kalmış Erzak: Gnome Roket Çizmeleri" end
if E["Waylaid Supplies: Goblin Deviled Clams"] == nil then E["Waylaid Supplies: Goblin Deviled Clams"] = "Yolda Kalmış Erzak: Goblin Acılı Midyeler" end
if E["Waylaid Supplies: Goblin Mortars"] == nil then E["Waylaid Supplies: Goblin Mortars"] = "Yolda Kalmış Erzak: Goblin Havanları" end
if E["Waylaid Supplies: Gold Bars"] == nil then E["Waylaid Supplies: Gold Bars"] = "Yolda Kalmış Erzak: Altın Külçeler" end
if E["Waylaid Supplies: Gray Woolen Shirts"] == nil then E["Waylaid Supplies: Gray Woolen Shirts"] = "Yolda Kalmış Erzak: Gri Yün Gömlekler" end
if E["Waylaid Supplies: Greater Healing Potions"] == nil then E["Waylaid Supplies: Greater Healing Potions"] = "Yolda Kalmış Erzak: Büyük Şifa İksirleri" end
if E["Waylaid Supplies: Green Iron Bracers"] == nil then E["Waylaid Supplies: Green Iron Bracers"] = "Yolda Kalmış Erzak: Yeşil Demir Bileklikler" end
if E["Waylaid Supplies: Guardian Gloves"] == nil then E["Waylaid Supplies: Guardian Gloves"] = "Yolda Kalmış Erzak: Koruyucu Eldivenler" end
if E["Waylaid Supplies: Handstitched Leather Belts"] == nil then E["Waylaid Supplies: Handstitched Leather Belts"] = "Yolda Kalmış Erzak: El Dikişi Deri Kemerler" end
if E["Waylaid Supplies: Healing Potions"] == nil then E["Waylaid Supplies: Healing Potions"] = "Yolda Kalmış Erzak: Şifa İksirleri" end
if E["Waylaid Supplies: Heavy Hide"] == nil then E["Waylaid Supplies: Heavy Hide"] = "Yolda Kalmış Erzak: Ağır Post" end
if E["Waylaid Supplies: Heavy Linen Bandages"] == nil then E["Waylaid Supplies: Heavy Linen Bandages"] = "Yolda Kalmış Erzak: Ağır Keten Sargılar" end
if E["Waylaid Supplies: Heavy Mageweave Bandages"] == nil then E["Waylaid Supplies: Heavy Mageweave Bandages"] = "Yolda Kalmış Erzak: Ağır Büyüdokuma Sargılar" end
if E["Waylaid Supplies: Heavy Mithril Gauntlets"] == nil then E["Waylaid Supplies: Heavy Mithril Gauntlets"] = "Yolda Kalmış Erzak: Ağır Mithril Zırhlı Eldivenler" end
if E["Waylaid Supplies: Heavy Silk Bandages"] == nil then E["Waylaid Supplies: Heavy Silk Bandages"] = "Yolda Kalmış Erzak: Ağır İpek Sargılar" end
if E["Waylaid Supplies: Heavy Wool Bandages"] == nil then E["Waylaid Supplies: Heavy Wool Bandages"] = "Yolda Kalmış Erzak: Ağır Yün Sargılar" end
if E["Waylaid Supplies: Herb Baked Eggs"] == nil then E["Waylaid Supplies: Herb Baked Eggs"] = "Yolda Kalmış Erzak: Otlu Fırın Yumurta" end
if E["Waylaid Supplies: Hi-Explosive Bombs"] == nil then E["Waylaid Supplies: Hi-Explosive Bombs"] = "Yolda Kalmış Erzak: Yüksek Patlayıcı Bombalar" end
if E["Waylaid Supplies: Hillman's Shoulders"] == nil then E["Waylaid Supplies: Hillman's Shoulders"] = "Yolda Kalmış Erzak: Dağlı Omuzlukları" end
if E["Waylaid Supplies: Khadgar's Whisker"] == nil then E["Waylaid Supplies: Khadgar's Whisker"] = "Yolda Kalmış Erzak: Khadgar's Whisker" end
if E["Waylaid Supplies: Lesser Magic Wands"] == nil then E["Waylaid Supplies: Lesser Magic Wands"] = "Yolda Kalmış Erzak: Hafif Büyü Değnekleri" end
if E["Waylaid Supplies: Lesser Mana Potions"] == nil then E["Waylaid Supplies: Lesser Mana Potions"] = "Yolda Kalmış Erzak: Hafif Mana İksirleri" end
if E["Waylaid Supplies: Lesser Stoneshield Potions"] == nil then E["Waylaid Supplies: Lesser Stoneshield Potions"] = "Yolda Kalmış Erzak: Hafif Taş Kalkan İksirleri" end
if E["Waylaid Supplies: Light Leather"] == nil then E["Waylaid Supplies: Light Leather"] = "Yolda Kalmış Erzak: Hafif Deri" end
if E["Waylaid Supplies: Major Healing Potions"] == nil then E["Waylaid Supplies: Major Healing Potions"] = "Yolda Kalmış Erzak: Yüce Şifa İksirleri" end
if E["Waylaid Supplies: Massive Iron Axes"] == nil then E["Waylaid Supplies: Massive Iron Axes"] = "Yolda Kalmış Erzak: Devasa Demir Baltalar" end
if E["Waylaid Supplies: Medium Leather"] == nil then E["Waylaid Supplies: Medium Leather"] = "Yolda Kalmış Erzak: Orta Deri" end
if E["Waylaid Supplies: Minor Healing Potions"] == nil then E["Waylaid Supplies: Minor Healing Potions"] = "Yolda Kalmış Erzak: Küçük Şifa İksirleri" end
if E["Waylaid Supplies: Minor Mana Oil"] == nil then E["Waylaid Supplies: Minor Mana Oil"] = "Yolda Kalmış Erzak: Küçük Mana Yağı" end
if E["Waylaid Supplies: Minor Wizard Oil"] == nil then E["Waylaid Supplies: Minor Wizard Oil"] = "Yolda Kalmış Erzak: Küçük Büyücü Yağı" end
if E["Waylaid Supplies: Mithril Bars"] == nil then E["Waylaid Supplies: Mithril Bars"] = "Yolda Kalmış Erzak: Mithril Külçeler" end
if E["Waylaid Supplies: Mithril Blunderbuss"] == nil then E["Waylaid Supplies: Mithril Blunderbuss"] = "Yolda Kalmış Erzak: Mithril Alaybozan" end
if E["Waylaid Supplies: Mithril Coifs"] == nil then E["Waylaid Supplies: Mithril Coifs"] = "Yolda Kalmış Erzak: Mithril Zincir Başlıklar" end
if E["Waylaid Supplies: Nightfin Soup"] == nil then E["Waylaid Supplies: Nightfin Soup"] = "Yolda Kalmış Erzak: Gece Yüzgeci Çorbası" end
if E["Waylaid Supplies: Ornate Spyglasses"] == nil then E["Waylaid Supplies: Ornate Spyglasses"] = "Yolda Kalmış Erzak: Süslü Dürbünler" end
if E["Waylaid Supplies: Peacebloom"] == nil then E["Waylaid Supplies: Peacebloom"] = "Yolda Kalmış Erzak: Peacebloom" end
if E["Waylaid Supplies: Pearl-clasped Cloaks"] == nil then E["Waylaid Supplies: Pearl-clasped Cloaks"] = "Yolda Kalmış Erzak: İnci Tokalı Pelerinler" end
if E["Waylaid Supplies: Purple Lotus"] == nil then E["Waylaid Supplies: Purple Lotus"] = "Yolda Kalmış Erzak: Purple Lotus" end
if E["Waylaid Supplies: Rich Purple Silk Shirts"] == nil then E["Waylaid Supplies: Rich Purple Silk Shirts"] = "Yolda Kalmış Erzak: Zengin Mor İpek Gömlekler" end
if E["Waylaid Supplies: Rockscale Cod"] == nil then E["Waylaid Supplies: Rockscale Cod"] = "Yolda Kalmış Erzak: Kaya Pullu Morina" end
if E["Waylaid Supplies: Rough Boomsticks"] == nil then E["Waylaid Supplies: Rough Boomsticks"] = "Yolda Kalmış Erzak: Kaba Patlangaçlar" end
if E["Waylaid Supplies: Rough Bronze Boots"] == nil then E["Waylaid Supplies: Rough Bronze Boots"] = "Yolda Kalmış Erzak: Kaba Bronz Çizmeler" end
if E["Waylaid Supplies: Rough Copper Bombs"] == nil then E["Waylaid Supplies: Rough Copper Bombs"] = "Yolda Kalmış Erzak: Kaba Bakır Bombalar" end
if E["Waylaid Supplies: Rough Stone"] == nil then E["Waylaid Supplies: Rough Stone"] = "Yolda Kalmış Erzak: Kaba Taş" end
if E["Waylaid Supplies: Rugged Armor Kits"] == nil then E["Waylaid Supplies: Rugged Armor Kits"] = "Yolda Kalmış Erzak: Sağlam Zırh Takımları" end
if E["Waylaid Supplies: Rugged Leather"] == nil then E["Waylaid Supplies: Rugged Leather"] = "Yolda Kalmış Erzak: Sağlam Deri" end
if E["Waylaid Supplies: Runecloth Belts"] == nil then E["Waylaid Supplies: Runecloth Belts"] = "Yolda Kalmış Erzak: Rün Kumaşı Kemerler" end
if E["Waylaid Supplies: Runed Copper Pants"] == nil then E["Waylaid Supplies: Runed Copper Pants"] = "Yolda Kalmış Erzak: Rünlü Bakır Pantolonlar" end
if E["Waylaid Supplies: Runed Silver Rods"] == nil then E["Waylaid Supplies: Runed Silver Rods"] = "Yolda Kalmış Erzak: Rünlü Gümüş Çubuklar" end
if E["Waylaid Supplies: Runic Leather Bracers"] == nil then E["Waylaid Supplies: Runic Leather Bracers"] = "Yolda Kalmış Erzak: Rünik Deri Bileklikler" end
if E["Waylaid Supplies: Shadowskin Gloves"] == nil then E["Waylaid Supplies: Shadowskin Gloves"] = "Yolda Kalmış Erzak: Gölge Derisi Eldivenler" end
if E["Waylaid Supplies: Silver Bars"] == nil then E["Waylaid Supplies: Silver Bars"] = "Yolda Kalmış Erzak: Gümüş Külçeler" end
if E["Waylaid Supplies: Silver Skeleton Keys"] == nil then E["Waylaid Supplies: Silver Skeleton Keys"] = "Yolda Kalmış Erzak: Gümüş Maymuncuklar" end
if E["Waylaid Supplies: Silverleaf"] == nil then E["Waylaid Supplies: Silverleaf"] = "Yolda Kalmış Erzak: Silverleaf" end
if E["Waylaid Supplies: Small Bronze Bombs"] == nil then E["Waylaid Supplies: Small Bronze Bombs"] = "Yolda Kalmış Erzak: Küçük Bronz Bombalar" end
if E["Waylaid Supplies: Smoked Bear Meat"] == nil then E["Waylaid Supplies: Smoked Bear Meat"] = "Yolda Kalmış Erzak: Füme Ayı Eti" end
if E["Waylaid Supplies: Smoked Sagefish"] == nil then E["Waylaid Supplies: Smoked Sagefish"] = "Yolda Kalmış Erzak: Füme Adaçayı Balığı" end
if E["Waylaid Supplies: Solid Grinding Stones"] == nil then E["Waylaid Supplies: Solid Grinding Stones"] = "Yolda Kalmış Erzak: Sağlam Bileme Taşları" end
if E["Waylaid Supplies: Soothing Turtle Bisque"] == nil then E["Waylaid Supplies: Soothing Turtle Bisque"] = "Yolda Kalmış Erzak: Yatıştırıcı Kaplumbağa Çorbası" end
if E["Waylaid Supplies: Spiced Wolf Meat"] == nil then E["Waylaid Supplies: Spiced Wolf Meat"] = "Yolda Kalmış Erzak: Baharatlı Kurt Eti" end
if E["Waylaid Supplies: Spider Sausages"] == nil then E["Waylaid Supplies: Spider Sausages"] = "Yolda Kalmış Erzak: Örümcek Sucukları" end
if E["Waylaid Supplies: Sungrass"] == nil then E["Waylaid Supplies: Sungrass"] = "Yolda Kalmış Erzak: Sungrass" end
if E["Waylaid Supplies: Superior Mana Potions"] == nil then E["Waylaid Supplies: Superior Mana Potions"] = "Yolda Kalmış Erzak: Üstün Mana İksirleri" end
if E["Waylaid Supplies: Swiftthistle"] == nil then E["Waylaid Supplies: Swiftthistle"] = "Yolda Kalmış Erzak: Swiftthistle" end
if E["Waylaid Supplies: Tender Wolf Steaks"] == nil then E["Waylaid Supplies: Tender Wolf Steaks"] = "Yolda Kalmış Erzak: Yumuşak Kurt Biftekleri" end
if E["Waylaid Supplies: Thick Hide"] == nil then E["Waylaid Supplies: Thick Hide"] = "Yolda Kalmış Erzak: Kalın Post" end
if E["Waylaid Supplies: Thick Leather"] == nil then E["Waylaid Supplies: Thick Leather"] = "Yolda Kalmış Erzak: Kalın Deri" end
if E["Waylaid Supplies: Thorium Bars"] == nil then E["Waylaid Supplies: Thorium Bars"] = "Yolda Kalmış Erzak: Toryum Külçeler" end
if E["Waylaid Supplies: Thorium Belts"] == nil then E["Waylaid Supplies: Thorium Belts"] = "Yolda Kalmış Erzak: Toryum Kemerler" end
if E["Waylaid Supplies: Thorium Grenades"] == nil then E["Waylaid Supplies: Thorium Grenades"] = "Yolda Kalmış Erzak: Toryum El Bombaları" end
if E["Waylaid Supplies: Thorium Rifles"] == nil then E["Waylaid Supplies: Thorium Rifles"] = "Yolda Kalmış Erzak: Toryum Tüfekler" end
if E["Waylaid Supplies: Truesilver Bars"] == nil then E["Waylaid Supplies: Truesilver Bars"] = "Yolda Kalmış Erzak: Hakiki Gümüş Külçeler" end
if E["Waylaid Supplies: Truesilver Gauntlets"] == nil then E["Waylaid Supplies: Truesilver Gauntlets"] = "Yolda Kalmış Erzak: Hakiki Gümüş Zırhlı Eldivenler" end
if E["Waylaid Supplies: Turtle Scale Bracers"] == nil then E["Waylaid Supplies: Turtle Scale Bracers"] = "Yolda Kalmış Erzak: Kaplumbağa Pulu Bileklikler" end
if E["Waylaid Supplies: Tuxedo Shirts"] == nil then E["Waylaid Supplies: Tuxedo Shirts"] = "Yolda Kalmış Erzak: Smokin Gömlekleri" end
if E["Waylaid Supplies: Undermine Clam Chowder"] == nil then E["Waylaid Supplies: Undermine Clam Chowder"] = "Yolda Kalmış Erzak: Undermine Midye Çorbası" end
if E["Waylaid Supplies: White Bandit Masks"] == nil then E["Waylaid Supplies: White Bandit Masks"] = "Yolda Kalmış Erzak: Beyaz Haydut Maskeleri" end
if E["Waylaid Supplies: Wicked Leather Bracers"] == nil then E["Waylaid Supplies: Wicked Leather Bracers"] = "Yolda Kalmış Erzak: Kötücül Deri Bileklikler" end
if E["Waylaid Supplies: Wintersbite"] == nil then E["Waylaid Supplies: Wintersbite"] = "Yolda Kalmış Erzak: Wintersbite" end
if E["Weak Troll's Blood Potion"] == nil then E["Weak Troll's Blood Potion"] = "Zayıf Troll Kanı İksiri" end
if E["Weather-worn Boots"] == nil then E["Weather-worn Boots"] = "Hava Yıpratmış Çizmeler" end
if E["Weathered Deathstalker's Blade"] == nil then E["Weathered Deathstalker's Blade"] = "Yıpranmış Ölüm Avcısının Kılıcı" end
if E["Well-Weathered Cloak"] == nil then E["Well-Weathered Cloak"] = "İyice Yıpranmış Pelerin" end
if E["Well-Worn Pants"] == nil then E["Well-Worn Pants"] = "Epey Eskimiş Pantolon" end
if E["Well-stitched Robe"] == nil then E["Well-stitched Robe"] = "Sağlam Dikişli Cüppe" end
if E["Well-used Sword"] == nil then E["Well-used Sword"] = "Çok Kullanılmış Kılıç" end
if E["Wheeler's Steed Feed"] == nil then E["Wheeler's Steed Feed"] = "Wheeler'ın Binek Yemi" end
if E["Whipfang's Skinsearer"] == nil then E["Whipfang's Skinsearer"] = "Whipfang'in Deri Dağlayıcısı" end
if E["Whirleygig's Supply Stash"] == nil then E["Whirleygig's Supply Stash"] = "Whirleygig'in Erzak Zulası" end
if E["Whisker of Shalla'kal"] == nil then E["Whisker of Shalla'kal"] = "Shalla'kal'ın Bıyığı" end
if E["Whitemane's Plateau"] == nil then E["Whitemane's Plateau"] = "Whitemane'in Yaylası" end
if E["Who, What, Where, When, and Die! Five Keys to a Good Inquisition"] == nil then E["Who, What, Where, When, and Die! Five Keys to a Good Inquisition"] = "Kim, Ne, Nerede, Ne Zaman ve Öl! İyi Bir Engizisyonun Beş Anahtarı" end
if E["Wicked Lich's Finger"] == nil then E["Wicked Lich's Finger"] = "Kötü Lich'in Parmağı" end
if E["Wicked Ritualist's Kris"] == nil then E["Wicked Ritualist's Kris"] = "Kötü Ayincinin Kris Hançeri" end
if E["Wide-Brimmed Fishing Hat"] == nil then E["Wide-Brimmed Fishing Hat"] = "Geniş Kenarlı Balıkçı Şapkası" end
if E["Wildstalker's Breastplate"] == nil then E["Wildstalker's Breastplate"] = "Vahşi İzcinin Göğüslüğü" end
if E["Wildstalker's Gauntlets"] == nil then E["Wildstalker's Gauntlets"] = "Vahşi İzcinin Zırhlı Eldivenleri" end
if E["Wildstalker's Greaves"] == nil then E["Wildstalker's Greaves"] = "Vahşi İzcinin Baldırlıkları" end
if E["Wildstalker's Helm"] == nil then E["Wildstalker's Helm"] = "Vahşi İzcinin Miğferi" end
if E["Wildstalker's Legguards"] == nil then E["Wildstalker's Legguards"] = "Vahşi İzcinin Bacak Korumaları" end
if E["Wildstalker's Spaulders"] == nil then E["Wildstalker's Spaulders"] = "Vahşi İzcinin Omuz Plakaları" end
if E["William's Shipment"] == nil then E["William's Shipment"] = "William'ın Sevkiyatı" end
if E["Wind-Infused Bough"] == nil then E["Wind-Infused Bough"] = "Rüzgâr Aşılanmış Dal" end
if E["Wind-Worn Boots"] == nil then E["Wind-Worn Boots"] = "Rüzgârdan Yıpranmış Çizmeler" end
if E["Windle's Lighter"] == nil then E["Windle's Lighter"] = "Windle'ın Çakmağı" end
if E["Windmistress Gaedress' Amulet"] == nil then E["Windmistress Gaedress' Amulet"] = "Rüzgâr Hanımı Gaedress'in Muskası" end
if E["Windseeker's Belt"] == nil then E["Windseeker's Belt"] = "Rüzgâr Arayanın Kemeri" end
if E["Wine-stained Cloak"] == nil then E["Wine-stained Cloak"] = "Şarap Lekeli Pelerin" end
if E["Wisdom's Leather Armor"] == nil then E["Wisdom's Leather Armor"] = "Bilgeliğin Deri Zırhı" end
if E["Wisdom's Leather Belt"] == nil then E["Wisdom's Leather Belt"] = "Bilgeliğin Deri Kemeri" end
if E["Wisdom's Leather Boots"] == nil then E["Wisdom's Leather Boots"] = "Bilgeliğin Deri Çizmeleri" end
if E["Wisdom's Leather Gloves"] == nil then E["Wisdom's Leather Gloves"] = "Bilgeliğin Deri Eldivenleri" end
if E["Wisdom's Leather Helm"] == nil then E["Wisdom's Leather Helm"] = "Bilgeliğin Deri Miğferi" end
if E["Wisdom's Leather Hood"] == nil then E["Wisdom's Leather Hood"] = "Bilgeliğin Deri Başlığı" end
if E["Wisdom's Leather Leggings"] == nil then E["Wisdom's Leather Leggings"] = "Bilgeliğin Deri Tozlukları" end
if E["Wisdom's Leather Pants"] == nil then E["Wisdom's Leather Pants"] = "Bilgeliğin Deri Pantolonu" end
if E["Wisdom's Leather Tunic"] == nil then E["Wisdom's Leather Tunic"] = "Bilgeliğin Deri Tuniği" end
if E["Witchdoctor's Dress"] == nil then E["Witchdoctor's Dress"] = "Büyücü Doktorun Elbisesi" end
if E["Witchmother Arysa's Amulet"] == nil then E["Witchmother Arysa's Amulet"] = "Cadı Ana Arysa'nın Muskası" end
if E["Woodworker's Axe"] == nil then E["Woodworker's Axe"] = "Ağaç İşçisinin Baltası" end
if E["Wool-Stitched Waistband"] == nil then E["Wool-Stitched Waistband"] = "Yün Dikişli Bel Bandı" end
if E["Worn Miner's Waistcord"] == nil then E["Worn Miner's Waistcord"] = "Yıpranmış Madencinin Bel İpi" end
if E["Worn Ranger's Dagger"] == nil then E["Worn Ranger's Dagger"] = "Yıpranmış Korucunun Hançeri" end
if E["Wyrmak's Cuirass"] == nil then E["Wyrmak's Cuirass"] = "Wyrmak'ın Gövde Zırhı" end
if E["Yaely's Mending Tool"] == nil then E["Yaely's Mending Tool"] = "Yaely'nin Onarım Aleti" end
if E["Yashiro's Spirit Bead"] == nil then E["Yashiro's Spirit Bead"] = "Yashiro'nun Ruh Boncuğu" end
if E["Yelmak's Potion"] == nil then E["Yelmak's Potion"] = "Yelmak'ın İksiri" end
if E["Yesterday's Leftovers"] == nil then E["Yesterday's Leftovers"] = "Dünden Kalan Artıklar" end
if E["Yesterday's Pants"] == nil then E["Yesterday's Pants"] = "Dünkü Pantolon" end
if E["Yngwe's Axe"] == nil then E["Yngwe's Axe"] = "Yngwe'nin Baltası" end
if E["Youngster's First Bow"] == nil then E["Youngster's First Bow"] = "Gencin İlk Yayı" end
if E["Ysera's Tear"] == nil then E["Ysera's Tear"] = "Ysera'nın Gözyaşı" end
if E["Zac's Head"] == nil then E["Zac's Head"] = "Zac'in Kafası" end
if E["Zalazane's Head"] == nil then E["Zalazane's Head"] = "Zalazane'in Kafası" end
if E["Zarla Ober's Gold Coin"] == nil then E["Zarla Ober's Gold Coin"] = "Zarla Ober'in Altın Sikkesi" end
if E["Zarla's Journal"] == nil then E["Zarla's Journal"] = "Zarla'nın Günlüğü" end
if E["Zayus's Exorcism Censer"] == nil then E["Zayus's Exorcism Censer"] = "Zayus'un Şeytan Kovma Buhurdanı" end
if E["Zizplink's Grocery List"] == nil then E["Zizplink's Grocery List"] = "Zizplink'in Alışveriş Listesi" end
if E["Zum'rah's Head"] == nil then E["Zum'rah's Head"] = "Zum'rah'ın Kafası" end
if E["[TMP] Funerary Headdress"] == nil then E["[TMP] Funerary Headdress"] = "[TMP] Cenaze Baş Süsü" end
if E["[TMP] Furbolg Ritual Stave"] == nil then E["[TMP] Furbolg Ritual Stave"] = "[TMP] Furbolg Ayin Asası" end
if E["[TMP] Satyrbane"] == nil then E["[TMP] Satyrbane"] = "[TMP] Satir Belası" end
n("Abandon hope, all ye who enter here.", "Buraya giren herkes, umudunu bıraksın.")
n("Angelista's Boutique", "Angelista'nın Butiği")
n("Anvil", "Örs")
n("Araj's Phylactery", "Araj'ın Mahfazası")
n("Archaeologist's Cart", "Arkeoloğun El Arabası")
n("Aska's Kitchen", "Aska'nın Mutfağı")
n("Asoran's Market", "Asoran'ın Pazarı")
n("Atal'ai Artifact", "Atal'ai Eseri")
n("Atal'ai Light BIG (DND)", "Atal'ai Işığı BÜYÜK (DND)")
n("Atal'ai Light SMALL (DND)", "Atal'ai Işığı KÜÇÜK (DND)")
n("Aura of Elune (SMALL)", "Elune'nin Aurası (KÜÇÜK)")
n("BEWARE!", "DİKKAT!")
n("Bags", "Çantalar")
n("Bank", "Banka")
n("Barim's Reagents", "Barim'in Malzemeleri")
n("Bell", "Çan")
n("Bena's Alchemy", "Bena'nın Simyası")
n("Berryfizz's Potions and Mixed Drinks", "Berryfizz'in İksirleri ve Karışık İçecekleri")
n("Blue aura. short column. scale 3", "Mavi aura. kısa sütun. ölçek 3")
n("Book", "Kitap")
n("Borstan's Firepit", "Borstan'ın Ateş Çukuru")
n("Boucher's Cauldron", "Boucher'ın Kazanı")
n("Bounty Available: Vulgara the Insatiable!", "Ödül Var: Doymak Bilmez Vulgara!")
n("Box o' Squirrels", "Sincap Kutusu")
n("Bruuk's Corner", "Bruuk'un Köşesi")
n("Burbik's Supplies", "Burbik'in Malzemeleri")
n("Burned-Out Remains", "Yanmış Kalıntılar")
n("Cash & Sons - Pawn Brokers", "Cash & Sons - Rehinciler")
n("Cask of Fool's Stout", "Fool's Stout Fıçısı")
n("Champions' Hall", "Şampiyonlar Salonu")
n("Chilton's Magic Shop", "Chilton'ın Sihir Dükkânı")
n("Christmas Tree (Large)", "Yılbaşı Ağacı (Büyük)")
n("Christmas Tree (Medium)", "Yılbaşı Ağacı (Orta)")
n("Circle Loc (spell focus)", "Circle Loc (büyü odağı)")
n("Cloudweaver's Baskets", "Cloudweaver'ın Sepetleri")
n("Coalbeard's Rifle", "Coalbeard'ın Tüfeği")
n("Cookie's Feast", "Cookie'nin Ziyafeti")
n("Corrupted Moonwell Spell Focus (DND)", "Bozulmuş Ay Kuyusu Büyü Odağı (DND)")
n("Craghelm's Plate and Chain", "Craghelm'in Levha ve Zincir Zırhları")
n("Crusaders' Square", "Haçlılar Meydanı")
n("Crystalvein Mine - Keep Out!", "Crystalvein Madeni - Girilmez!")
n("DANGER!", "TEHLİKE!")
n("DARKMOON FAIRE - Coming Soon!", "DARKMOON FAIRE - Yakında!")
n("Danger! Crystalvein Mine closed!", "Tehlike! Crystalvein Madeni kapalı!")
n("Darrowshire Town Square spell focus (DND)", "Darrowshire Kasaba Meydanı büyü odağı (DND)")
n("Dor'Danil Pillar", "Dor'Danil Sütunu")
n("Dredan's Table", "Dredan'ın Masası")
n("Drop-Off Point", "Teslim Noktası")
n("Duncan's Textiles", "Duncan'ın Kumaşları")
n("Echeyakee's Lair", "Echeyakee'nin İni")
n("Edana Hatetalon Spell Focus (DND)", "Edana Hatetalon Büyü Odağı (DND)")
n("Elders' Square", "Yaşlılar Meydanı")
n("End of Venture Co. Lands", "Venture Co. Topraklarının Sonu")
n("Enoyls Engineering, Inc.", "Enoyls Mühendislik A.Ş.")
n("Equinex Monolith Spell Focus (DND)", "Equinex Monoliti Büyü Odağı (DND)")
n("Event Generator Saurfang Pre-War", "Olay Üreteci Saurfang Savaş Öncesi")
n("Evil God Spell Focus (DND)", "Kötü Tanrı Büyü Odağı (DND)")
n("Fence", "Çit")
n("Finespindle's Leather Goods", "Finespindle'ın Deri Ürünleri")
n("Fire", "Ateş")
n("Fizzlespinner's General Goods", "Fizzlespinner'ın Genel Malları")
n("Flintfire's Shipment", "Flintfire'ın Sevkiyatı")
n("Floating, Medium - MFF", "Süzülen, Orta - MFF")
n("Floating, medium", "Süzülen, orta")
n("Fool's Gold Vein", "Aptal Altını Damarı")
n("Forge", "Demirci Ocağı")
n("Fortune Teller's Tent", "Falcının Çadırı")
n("Fras Siabi's Premium Tobacco", "Fras Siabi'nin Premium Tütünü")
n("G_Pumpkin_01 scale 4.0", "G_Pumpkin_01 ölçek 4.0")
n("Ghost Magnet Spell Focus (DND)", "Hayalet Mıknatısı Büyü Odağı (DND)")
n("Godan's Runeworks", "Godan'ın Rün Atölyesi")
n("Gol'Bolar Quarry", "Gol'Bolar Taş Ocağı")
n("Goldfury's Hunting Supplies", "Goldfury'nin Avcılık Malzemeleri")
n("Goodman's General Store", "Goodman'ın Genel Mağazası")
n("Gor'tesh's Lopped Off Head", "Gor'tesh'in Kesik Başı")
n("Gotri's Travelling Gear", "Gotri'nin Seyahat Teçhizatı")
n("Gozwin's Mechanic's Log", "Gozwin'in Tamirci Günlüğü")
n("Grasp of C'Thun", "C'Thun'un Pençesi")
n("Grimand's Anvil", "Grimand'ın Örsü")
n("Grimshade's Vision", "Grimshade'in Görüsü")
n("Grom's Monument", "Grom'un Anıtı")
n("Guild", "Lonca")
n("Gurda's Shredder", "Gurda'nın Parçalayıcısı")
n("Hanging, Door", "Asma, Kapı")
n("Hanging, Square, Large", "Asma, Kare, Büyük")
n("Hanging, Square, Large - MFF", "Asma, Kare, Büyük - MFF")
n("Hanging, Square, Medium", "Asma, Kare, Orta")
n("Hanging, Square, Medium - MFF", "Asma, Kare, Orta - MFF")
n("Hanging, Square, Small - MFF", "Asma, Kare, Küçük - MFF")
n("Hanging, Streamer - MFF", "Asma, Flama - MFF")
n("Hanging, Streamer x3 - MFF", "Asma, Flama x3 - MFF")
n("Hanging, Streamers, Medium", "Asma, Flamalar, Orta")
n("Hanging, Streamers, x3", "Asma, Flamalar, x3")
n("Hanging, Tall/Thin, Large", "Asma, Uzun/İnce, Büyük")
n("Hanging, Tall/Thin, Large - MFF", "Asma, Uzun/İnce, Büyük - MFF")
n("Hanging, Tall/Thin, Medium", "Asma, Uzun/İnce, Orta")
n("Hanging, Tall/Thin, Medium - MFF", "Asma, Uzun/İnce, Orta - MFF")
n("Hanging, Tall/Thin, Small - MFF", "Asma, Uzun/İnce, Küçük - MFF")
n("Hastily Rolled-Up Satchel", "Aceleyle Dürülmüş Çanta")
n("Hewa's Armory", "Hewa'nın Silahhanesi")
n("Hunter's Hall", "Avcılar Salonu")
n("Inn", "Han")
n("Ironforge Visitor's Center", "Ironforge Ziyaretçi Merkezi")
n("Ironzar's Imported Weaponry", "Ironzar'ın İthal Silahları")
n("J.D.'s Manual", "J.D.'nin El Kitabı")
n("Jaguar - Crocolisk Cage", "Jaguar - Crocolisk Kafesi")
n("Jandi's Arboretum", "Jandi'nin Arboretumu")
n("Jazzik's General Goods", "Jazzik'in Genel Malları")
n("Jin'Zil's Smoke", "Jin'Zil'in Dumanı")
n("Jintha'Alor Alter", "Jintha'Alor Sunağı")
n("KEEP OUT!", "GİRİLMEZ!")
n("Karn's Smithy", "Karn'ın Demirhanesi")
n("Kibler's Cage", "Kibler'ın Kafesi")
n("King's Square", "Kral Meydanı")
n("Kiro's Harnesses", "Kiro'nun Koşumları")
n("Kirtonos Bros. Funeral Home", "Kirtonos Kardeşler Cenaze Evi")
n("Knife", "Bıçak")
n("Knot's Ball and Chain", "Knot'un Gülle ve Zinciri")
n("Krastinov's Work Bench", "Krastinov'un Çalışma Tezgâhı")
n("Kroshius' Remains", "Kroshius'un Kalıntıları")
n("Kuramaa's Stump", "Kuramaa'nın Kütüğü")
n("Kuruk's Goods", "Kuruk'un Malları")
n("Lady's Tear Moss", "Lady's Tear Yosunu")
n("Leeka's Shields & Maces", "Leeka'nın Kalkanları & Gürzları")
n("Legacy of Steel - Fine Weaponry", "Legacy of Steel - İnce İşçilikli Silahlar")
n("Lights x3, Broken", "Işıklar x3, Kırık")
n("Lights, Broken", "Işıklar, Kırık")
n("Longberry's Reagents", "Longberry'nin Malzemeleri")
n("Lumak's Fishing", "Lumak'ın Balıkçı Dükkânı")
n("Maestra's Post", "Maestra'nın Üssü")
n("Maeva's Mystical Apparel", "Maeva'nın Mistik Giysileri")
n("Magar's Cloth Goods", "Magar'ın Kumaş Ürünleri")
n("Magus Rimtori's Journal", "Magus Rimtori'nin Günlüğü")
n("Maiden's Fancy - Round trips to Booty Bay", "Maiden's Fancy - Booty Bay'e gidiş-dönüş seferleri")
n("Merithra's Wake", "Merithra'nın Uyanışı")
n("Metzen's Fencing", "Metzen'in Çitleri")
n("Metzen's Stable", "Metzen'in Ahırı")
n("Miblon's Door", "Miblon'un Kapısı")
n("Miblon's Spell Focus (DND)", "Miblon'un Büyü Odağı (DND)")
n("Mordan's Reagents", "Mordan'ın Malzemeleri")
n("Mountaintop Bait & Tackle", "Dağ Zirvesi Yem & Olta Dükkânı")
n("Mural of Ta'zo", "Ta'zo'nun Duvar Resmi")
n("Murgut's Totem Basket", "Murgut'un Totem Sepeti")
n("NG-5 Explosives (Blue)", "NG-5 Patlayıcılar (Mavi)")
n("NG-5 Explosives (Red)", "NG-5 Patlayıcılar (Kırmızı)")
n("Nogg's Machine Shop", "Nogg'un Makine Dükkânı")
n("Note", "Not")
n("On the Shal'nan", "Shal'nan Üzerine")
n("One \"Gerenzo\", of Stonetalon", "Stonetalon'dan bir \"Gerenzo\"")
n("Pamela's Doll", "Pamela'nın Bebeği")
n("Pestle's Apothecary", "Pestle'ın Eczanesi")
n("Pierce's Pistols", "Pierce'ın Tabancaları")
n("Pirate's Treasure!", "Korsan Hazinesi!")
n("Plaguewood Fire (Large)", "Plaguewood Ateşi (Büyük)")
n("Plaguewood Fire (Small)", "Plaguewood Ateşi (Küçük)")
n("Plate-n-Chain", "Levha ve Zincir")
n("Prince's Chest Aura", "Prensin Sandık Aurası")
n("Purple aura, short column, 0.6 scale", "Mor aura, kısa sütun, 0.6 ölçek")
n("Raider's Battleaxe", "Akıncının Savaş Baltası")
n("Raider's Bow", "Akıncının Yayı")
n("Raider's Shield", "Akıncının Kalkanı")
n("Recipe: Raw Plated Armorfish", "Tarif: Çiğ Zırhlı Balık")
n("Rekkul's Poisons", "Rekkul'un Zehirleri")
n("Robe", "Cübbe")
n("Rogues' Quarter", "Haydutlar Mahallesi")
n("Rug", "Halı")
n("Sar'theris Striker Fishing Location", "Sar'theris Striker Balıkçılık Noktası")
n("Scholomance Viewing Room Spell Focus (DND)", "Scholomance İzleme Odası Büyü Odağı (DND)")
n("Sen'jin Village", "Sen'jin Köyü")
n("Sentinel's Bunkhouse", "Nöbetçi Yatakhanesi")
n("Shadra'Alor Altar", "Shadra'Alor Sunağı")
n("Smite's Chest", "Smite'ın Sandığı")
n("Smoke Emitter, Large AOI, scale 2", "Duman Yayıcı, Büyük AOI, ölçek 2")
n("Soran's Leather and Steel Armory", "Soran'ın Deri ve Çelik Silahhanesi")
n("Springspindle's Gadgets", "Springspindle'ın Aletleri")
n("Staff", "Asa")
n("Standing, Exterior, Medium - MFF", "Ayaklı, Dış Mekân, Orta - MFF")
n("Standing, Giant", "Ayaklı, Dev")
n("Standing, Interior, Medium - MFF", "Ayaklı, İç Mekân, Orta - MFF")
n("Standing, Interior, Small - MFF", "Ayaklı, İç Mekân, Küçük - MFF")
n("Standing, Large", "Ayaklı, Büyük")
n("Standing, Medium Interior", "Ayaklı, Orta İç Mekân")
n("Standing, Medium, Exterior", "Ayaklı, Orta, Dış Mekân")
n("Standing, Post - MFF", "Ayaklı, Direk - MFF")
n("Standing, small Interior", "Ayaklı, küçük İç Mekân")
n("Steelfury's Weapon Emporium", "Steelfury'nin Silah Mağazası")
n("Stone of Shy-Rotam", "Shy-Rotam Taşı")
n("Stoneanvil's Rifle", "Stoneanvil'in Tüfeği")
n("Stoneblade's", "Stoneblade'in")
n("Stonebrow's Clothier", "Stonebrow'un Terzisi")
n("Stormwind Visitor's Center", "Stormwind Ziyaretçi Merkezi")
n("Stove", "Soba")
n("Strahad's Summoning Circle", "Strahad'ın Çağırma Çemberi")
n("Styleen's Cart", "Styleen'in El Arabası")
n("Sunhammer's Rifle", "Sunhammer'ın Tüfeği")
n("Table", "Masa")
n("Talvash's Scrying Bowl", "Talvash'ın Görü Çanağı")
n("Tan-Your-Hide Leatherworks", "Postunu Tabakla Dericilik")
n("Thane's Boots", "Thane'in Çizmeleri")
n("The Rebellion In Eldre'Thalas, Part 1", "Eldre'Thalas'taki İsyan, 1. Bölüm")
n("The Rebellion In Eldre'Thalas, Part 2", "Eldre'Thalas'taki İsyan, 2. Bölüm")
n("The Rebellion In Eldre'Thalas, Part 3", "Eldre'Thalas'taki İsyan, 3. Bölüm")
n("The Rebellion In Eldre'Thalas, Part 4", "Eldre'Thalas'taki İsyan, 4. Bölüm")
n("The Shal'nan's Abdication", "Shal'nan'ın Tahttan Feragati")
n("The Sky-Touched Mystery", "Göğün Dokunduğu Gizem")
n("Things That Go Boom!", "Güm Diye Patlayan Şeyler!")
n("Thrall's Fortress", "Thrall'ın Kalesi")
n("Thunderhoof's Firearms", "Thunderhoof'un Ateşli Silahları")
n("Thunderhorn's Archery", "Thunderhorn'un Okçuluğu")
n("Tirion Fordring's Grave", "Tirion Fordring'in Mezarı")
n("Traveler's Cache", "Gezginin Zulası")
n("Trias' Cheese", "Trias'ın Peyniri")
n("Turn Back!", "Geri Dön!")
n("Tyr's Hand", "Tyr'in Eli")
n("Urok's Tribute Pile", "Urok'un Haraç Yığını")
n("Uther's Tomb Statue", "Uther'in Mezar Heykeli")
n("Venture Co. Copter Pad", "Venture Co. Helikopter Pisti")
n("Venture Co. Stonetalon Mtns. Project", "Venture Co. Stonetalon Dağları Projesi")
n("Venture Co. Wagon (Blue)", "Venture Co. Arabası (Mavi)")
n("Venture Co. Wagon (Red)", "Venture Co. Arabası (Kırmızı)")
n("Videre Elixir Spell Focus (DND)", "Videre İksiri Büyü Odağı (DND)")
n("Wanted: Incinerator Gar'im", "Aranıyor: Yakıcı Gar'im")
n("Wanted: ORCS!", "Aranıyor: ORKLAR!")
n("Warning!!!! Plaguelands", "Uyarı!!!! Plaguelands")
n("Well", "Kuyu")
n("Weller's Arsenal", "Weller'ın Cephaneliği")
n("White Smoke Emitter - scale 0.2", "Beyaz Duman Yayıcı - ölçek 0.2")
n("Wind-Infused Bough", "Rüzgârla Dolu Dal")
n("Worm", "Solucan")
n("Wreath scale 0.75", "Çelenk ölçek 0.75")
n("Xabraxxis' Demon Bag", "Xabraxxis'in İblis Torbası")
n("Yellow aura, very tall column", "Sarı aura, çok uzun sütun")
n("Yelmak's Alchemy and Potions", "Yelmak'ın Simyası ve İksirleri")
n("Ysida's Cagebase", "Ysida'nın Kafes Tabanı")
u("Al'Aketh Missionary", "Al'Aketh Misyoneri")
u("An'drak's Pet", "An'drak'ın Evcil Hayvanı")
u("Armor", "Zırh")
u("Assassin's League", "Suikastçılar Birliği")
u("Axe & Polearm Merchant", "Balta & Kargı Satıcısı")
u("Ban'aethal Citzen", "Ban'aethal Sakini")
u("Ban'aethal Refugee", "Ban'aethal Mültecisi")
u("Bloodmaster of Bolder'ok", "Bolder'ok'un Kan Ustası")
u("Bread & Cheese Vendor", "Ekmek & Peynir Satıcısı")
u("Child of Ur'endra", "Ur'endra'nın Çocuğu")
u("Cloth & Leather Armor", "Kumaş & Deri Zırh")
u("Cloth & Leather Armor Merchant", "Kumaş & Deri Zırh Satıcısı")
u("Crafter's Hall Administrator", "Zanaatkârlar Salonu Yöneticisi")
u("Dagger & Fist Weapon Merchant", "Hançer & Yumruk Silahı Satıcısı")
u("Don't trust me! I'm named Billy!", "Bana güvenme! Adım Billy!")
u("Drazzit's Pack Kodo", "Drazzit'in Yük Kodosu")
u("EZ-Thro Brand Rep", "EZ-Thro Marka Temsilcisi")
u("Explorers' League", "Kâşifler Birliği")
u("Flight Master [NYI]", "Uçuş Ustası [NYI]")
u("Food & Drink", "Yiyecek & İçecek")
u("Food & Drink Vendor", "Yiyecek & İçecek Satıcısı")
u("Has What You Need (Probably)", "İhtiyacın Olanı Bulundurur (Muhtemelen)")
u("Hnaz's Imp", "Hnaz'ın Imp'i")
u("Hnaz's Succubus", "Hnaz'ın Succubus'u")
u("Hnaz's Voidwalker", "Hnaz'ın Voidwalker'ı")
u("Isaac Chan's Companion", "Isaac Chan'in Yoldaşı")
u("Knight-Paladin", "Şövalye-Paladin")
u("Kor'kron Elite", "Kor'kron Seçkini")
u("Librarian's Assistant", "Kütüphaneci Yardımcısı")
u("Magic Skill Trainer *Temp*", "Sihir Becerisi Eğitmeni *Temp*")
u("Master-at-Arms", "Silah Talim Ustası")
u("Mate of Urs'endris", "Urs'endris'in Yoldaşı")
u("Medic", "Sağlıkçı")
u("Mountaineer's Assistant", "Dağcı Yardımcısı")
u("PTR - Crate Turn-In Reagents", "PTR - Sandık Teslim Malzemeleri")
u("PTR - Crates & Writs", "PTR - Sandıklar & Fermanlar")
u("Placeholder!", "Yer Tutucu!")
u("Quel'ana Quickgale's Companion", "Quel'ana Quickgale'in Yoldaşı")
u("Quel'danil Lodge Emissary", "Quel'danil Lodge Elçisi")
u("Reagents & Magical Goods", "Malzemeler & Büyülü Eşyalar")
u("Rogue Trainer?", "Haydut (Rogue) Eğitmeni?")
u("SAF-T Brand Rep", "SAF-T Marka Temsilcisi")
u("Scoutmaster Vargas's Companion", "Scoutmaster Vargas'ın Yoldaşı")
u("Self-Proclaimed Brave Peon", "Kendini Cesur İlan Etmiş Peon")
u("Someone's Minion", "Birinin Uşağı")
u("Steamwheedle Construction Co.", "Steamwheedle İnşaat A.Ş.")
u("Sun Priest of An'she", "An'she'nin Güneş Rahibi")
u("Tai'ree Farsight's Companion", "Tai'ree Farsight'ın Yoldaşı")
u("Tazzik's Bodyguard", "Tazzik'in Koruması")
u("The Moro'gai", "Moro'gai")
u("The People's Militia", "Halkın Milisi")
u("Toughness/Resist Trainer *Temp*", "Dayanıklılık/Direnç Eğitmeni *Temp*")
u("Trinkets & Charms", "Biblolar & Tılsımlar")
u("Visionary, Entrepeneur, Barber", "Vizyoner, Girişimci, Berber")
u("Wands", "Değnekler")
