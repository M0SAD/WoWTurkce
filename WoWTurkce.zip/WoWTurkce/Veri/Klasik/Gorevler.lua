if WoWTurkce.RETAIL or WoWTurkce.FOREVER then return end -- yalnızca Classic Era
-- Görevler: [görevNo] = { b=başlık, a=açıklama, h=hedef, i=ilerleme, t=tamamlama, k=parmak izleri }, görev adları ve metinleri
local G = WoWTurkce
do local function _()
local T = G.VeriEk
T[1658] = {b="Wickerman Festivali'ni Basmak",k={b=1753196180}}
T[1661] = {b="OLD Asalet Kitabı",k={b=1724583257}}
T[4487] = {b="OLD Felsteed Çağırma",k={b=3921290511}}
T[4488] = {b="OLD Felsteed Çağırma",k={b=3921290511}}
T[5126] = {h="Lorax ile konuş. Ne diyeceğini dinle.\n",k={h=3126987908}}
T[8550] = {b="Horde'un Daha Fazla Barışçiçeğine İhtiyacı Var!",k={b=1509798737}}
T[8687] = {h="30 Hive'Zora Tunnelers öldür ve Silithus'taki Cenarion Hold'da bulunan Komutan Mar'alith'e rapor ver.  Bu görevi tamamlamak için ayrıca Savaş Görev Brifingi VII getirmelisin.",k={h=1400158443}}
T[8741] = {a="Bekçi dönüşünü bekliyor, $N. Yeşil asa parçasını Caverns of Time'daki Anachronos'a götür.",h="Yeşil Asa Parçası'nı Tanaris'teki Caverns of Time'da bulunan Anachronos'a götür.",k={a=80987199,h=1323525320}}
T[8829] = {h="Cenarion Hold'daki Aurel Goldleaf'e bir Skin of Shadow, 3 Yıpranmış İğrençlik Dikişi ve 1 Alacakaranlık Tarikatçısı Cübbesi getir.  Bu görevi tamamlamak için ayrıca Lojistik Görev Brifingi XI getirmelisin.",k={h=2684991800}}
end _() end
